# src/setiastro/saspro/nbextract.py
# SetiAstro Suite Pro — Narrowband Channel Extractor
#
#   ███╗   ██╗██████╗ ███████╗██╗  ██╗████████╗██████╗  █████╗  ██████╗████████╗
#   ████╗  ██║██╔══██╗██╔════╝╚██╗██╔╝╚══██╔══╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝
#   ██╔██╗ ██║██████╔╝█████╗   ╚███╔╝    ██║   ██████╔╝███████║██║        ██║
#   ██║╚██╗██║██╔══██╗██╔══╝   ██╔██╗    ██║   ██╔══██╗██╔══██║██║        ██║
#   ██║ ╚████║██████╔╝███████╗██╔╝ ██╗   ██║   ██║  ██║██║  ██║╚██████╗   ██║
#   ╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝   ╚═╝
#
# Copyright (c) 2024 Franklin Marek / SetiAstro
#
# Empirically calibrated dual-band narrowband channel extraction.
#
# Philosophy
# ----------
# Rather than relying on published sensor QE curves (which are often promotional
# approximations), we use stars with known Pickles spectral templates to fit the
# mixing matrix A empirically from the actual image data.  The filter bandwidths
# tell us WHERE to integrate on the SED; the stars tell us HOW MUCH each channel
# responds.  QE uncertainty cancels out because we're fitting ratios against the
# same instrument that took the image.
#
# For a dual-band Ha+OIII filter the system is:
#
#   R_meas = a·Ha_signal  +  b·OIII_signal  +  noise
#   G_meas = c·Ha_signal  +  d·OIII_signal  +  noise
#   B_meas = e·Ha_signal  +  f·OIII_signal  +  noise
#
# With 3 equations and 2 unknowns this is a well-conditioned overdetermined
# system solved per-pixel via non-negative least squares.
#
# Supported filter presets
# ------------------------
#   Ha / OIII   — most common dual-band (L-eXtreme, Antlia ALP-T, ...)
#   SII / OIII  — tri-band variant where SII replaces Ha in the red window
#   SII / Hβ    — less common, but correctly handled
#
# Triband (Ha + OIII + SII in one filter) is explicitly NOT supported for
# 3-line extraction; you still only get 2 reliably separated channels.  The
# tool warns the user accordingly.
#
# Imports shared with sfcc.py
# ---------------------------
# fetch_stars infrastructure, Pickles SED loading, SEP photometry helpers,
# Gaia XP fallback, and the WCS / SIMBAD plumbing all come straight from
# sfcc.py via explicit imports below.  Nothing is duplicated.


from __future__ import annotations

import os
import math
from typing import Optional, Dict, Tuple, List

import numpy as np
from scipy.optimize import nnls

try:
    _trapz = np.trapezoid
except AttributeError:
    _trapz = np.trapz

from astropy.io import fits
from PyQt6.QtCore import Qt, QSettings, QStandardPaths
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLabel, QComboBox, QDoubleSpinBox, QPushButton,
    QCheckBox, QMessageBox, QApplication, QGroupBox,
    QSizePolicy, QWidget, QLineEdit, QSpinBox,
)
from PyQt6.QtGui import QIcon

from matplotlib.figure import Figure
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas

# ── shared helpers from sfcc ──────────────────────────────────────────────────
# Imported at module level; if a circular import occurs at startup, move this
# import inside open_nbextract() or NBExtractDialog.__init__().
from setiastro.saspro.sfcc import (
    pickles_match_for_simbad,
    measure_star_rgb_photometry,
    measure_star_rgb_raw_aperture,
    _ensure_angstrom,
    _sfcc_status,
    _sfcc_busy,
    _force_mpl_no_tex,
    SFCCDialog,
)
from setiastro.saspro.help_support import make_help_button
# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

#: Emission line rest wavelengths in nm (air)
LINE_CENTERS_NM: Dict[str, float] = {
    "Ha":   656.28,
    "OIII": 500.70,
    "SII":  671.64,
    "Hb":   486.13,   # Hβ
}

#: Dual-band filter presets  →  (line1_key, line2_key)
#: "Custom" uses user-supplied line names and centers.
FILTER_PRESETS: Dict[str, Tuple[str, str]] = {
    "Ha / OIII":  ("Ha",  "OIII"),
    "SII / OIII": ("SII", "OIII"),
    "SII / Hβ":   ("SII", "Hb"),
    "Custom":     ("Line1", "Line2"),   # user-defined centers and labels
}

#: Preset name → whether line centers/labels are user-editable
FILTER_PRESET_CUSTOM = "Custom"

#: Default bandwidths (FWHM, nm) for each line — user can override
DEFAULT_BW_NM: Dict[str, float] = {
    "Ha":   7.0,
    "OIII": 6.5,
    "SII":  7.0,
    "Hb":   6.5,
}

#: Settings keys
_SK_PRESET  = "NBExtract/FilterPreset"
_SK_BW1     = "NBExtract/BW_Line1"
_SK_BW2     = "NBExtract/BW_Line2"
_SK_CENTER1 = "NBExtract/Center_Line1"
_SK_CENTER2 = "NBExtract/Center_Line2"
_SK_MAX_CAL = "NBExtract/MaxCalStars"


class NBExtractError(RuntimeError):
    """Raised by the headless NBExtract entry point instead of popping a modal
    dialog.  run_command('nbextract', ...) surfaces this as a CommandError so
    user scripts can catch and report it cleanly."""

# ─────────────────────────────────────────────────────────────────────────────
# Core maths
# ─────────────────────────────────────────────────────────────────────────────

def integrate_sed_over_window(
    sed_wl_nm: np.ndarray,
    sed_fl: np.ndarray,
    center_nm: float,
    bw_nm: float,
) -> float:
    """
    Integrate a Pickles SED over a top-hat passband window.

    Parameters
    ----------
    sed_wl_nm : wavelength array in nm
    sed_fl    : flux array (arbitrary units; only ratios matter)
    center_nm : line center in nm
    bw_nm     : FWHM bandwidth in nm

    Returns
    -------
    Integrated flux (same units as sed_fl × nm).  Returns 0.0 if the
    window falls entirely outside the SED coverage.
    """
    lo = center_nm - bw_nm * 0.5
    hi = center_nm + bw_nm * 0.5

    wl = np.asarray(sed_wl_nm, dtype=np.float64)
    fl = np.asarray(sed_fl,    dtype=np.float64)

    mask = (wl >= lo) & (wl <= hi)
    if not np.any(mask):
        return float(np.interp(center_nm, wl, fl, left=0.0, right=0.0) * bw_nm)

    wl_w = wl[mask].copy()
    fl_w = fl[mask].copy()

    if wl_w[0] > lo:
        fl_lo = float(np.interp(lo, wl, fl))
        wl_w = np.concatenate([[lo], wl_w])
        fl_w = np.concatenate([[fl_lo], fl_w])
    if wl_w[-1] < hi:
        fl_hi = float(np.interp(hi, wl, fl))
        wl_w = np.concatenate([wl_w, [hi]])
        fl_w = np.concatenate([fl_w, [fl_hi]])

    return float(_trapz(fl_w, x=wl_w))


def auto_q_from_condition_number(k: float) -> float:
    """
    Global Q from condition number — used as a baseline / fallback.
    Formula: Q = clip(1 / (1 + 0.1 * k), 0.2, 0.9)
    """
    return float(np.clip(1.0 / (1.0 + 0.1 * k), 0.2, 0.9))


def dominant_channels_from_matrix(A: np.ndarray) -> Tuple[int, int]:
    """
    Determine which RGB channel (0=R, 1=G, 2=B) is the dominant receiver
    for line1 and line2 by reading the column maxima of A.

    Used to select the correct raw channel as the Q-blend prior for each
    line — generalises beyond the Ha→R / OIII→G assumption so custom
    filter types (NII, HeI, Hβ, etc.) work correctly.

    Returns
    -------
    (ch1, ch2) : channel indices 0-2 for line1 and line2 respectively

    Note: the returned indices are used as slice indices into img_float.
    When the top two channels for a line are within 5 percentage points of
    each other the caller should average those two channels rather than
    picking one arbitrarily — see raw_prior_from_matrix().
    """
    ch1 = int(np.argmax(A[:, 0]))   # channel most sensitive to line1
    ch2 = int(np.argmax(A[:, 1]))   # channel most sensitive to line2
    return ch1, ch2


def raw_prior_from_matrix(img_rgb: np.ndarray, A: np.ndarray, line_col: int) -> np.ndarray:
    """
    Build the raw channel prior for one emission line.

    If the top two channels are within 5 percentage points of each other
    in the A matrix column, average them — they are genuinely tied and
    neither is a clearly better prior.  Otherwise use the single dominant
    channel.

    Parameters
    ----------
    img_rgb  : (H, W, 3) float32 image
    A        : (3, 2) mixing matrix
    line_col : 0 for line1, 1 for line2

    Returns
    -------
    (H, W) float32 raw prior array
    """
    col = A[:, line_col]
    total = col.sum()
    if total <= 0:
        # Degenerate column — fall back to argmax channel
        return img_rgb[..., int(np.argmax(col))].copy()

    pct = 100.0 * col / total   # percentage sensitivity per channel

    # Sort channels by sensitivity descending
    order = np.argsort(pct)[::-1]
    best, second = int(order[0]), int(order[1])

    ch_names = {0: "R", 1: "G", 2: "B"}
    if (pct[best] - pct[second]) <= 5.0:
        # Near-tie: average the two highest channels
        prior = 0.5 * (img_rgb[..., best].astype(np.float32) +
                       img_rgb[..., second].astype(np.float32))
        print(
            f"[NBExtract] line{line_col+1} prior: averaging "
            f"{ch_names[best]}({pct[best]:.1f}%) + {ch_names[second]}({pct[second]:.1f}%)"
        )
    else:
        prior = img_rgb[..., best].copy().astype(np.float32)
        print(
            f"[NBExtract] line{line_col+1} prior: {ch_names[best]} "
            f"({pct[best]:.1f}% vs {pct[second]:.1f}% next)"
        )

    return prior


def auto_q_per_channel(A: np.ndarray) -> Tuple[float, float]:
    """
    Derive independent Q values for line1 and line2 by examining how
    well each line direction is resolved in the mixing matrix.

    The dominant channel per line is read from the A matrix itself via
    dominant_channels_from_matrix() — works for any custom filter, not
    just Ha/OIII.

    Returns
    -------
    (q1, q2) : floats in [0.2, 0.9]
    """
    try:
        ch1, ch2 = dominant_channels_from_matrix(A)

        # ── Global condition number → baseline Q ─────────────────────────
        k = float(np.linalg.cond(A))
        q_global = float(np.clip(1.0 / (1.0 + 0.1 * k), 0.2, 0.9))

        # ── SVD: how independently are the two lines resolved? ────────────
        _, sv, _ = np.linalg.svd(A, full_matrices=False)
        sv1, sv2 = float(sv[0]), float(sv[1])
        sv_ratio = sv2 / sv1 if sv1 > 0 else 0.0

        # Q₁ (line1): mainly depends on global conditioning
        q1 = float(np.clip(q_global, 0.2, 0.9))

        # Q₂ (line2): penalised by weak second singular value
        q2_svd = float(np.clip(q_global * sv_ratio, 0.2, 0.9))

        # ── Non-dominant row degeneracy check for line2 ───────────────────
        # Find the two rows that are NOT the dominant channel for line2.
        # If they carry nearly identical line2 sensitivity the inversion
        # is extrapolating noise rather than measuring signal.
        all_rows = {0, 1, 2}
        non_dom_rows = sorted(all_rows - {ch2})
        val_a = float(A[non_dom_rows[0], 1])
        val_b = float(A[non_dom_rows[1], 1])

        row_sum = abs(val_a) + abs(val_b)
        if row_sum > 1e-10:
            similarity = 1.0 - abs(val_a - val_b) / row_sum
        else:
            similarity = 1.0   # both zero — completely degenerate

        # Squared penalty mirrors noise amplification physics (gain ∝ cond²)
        # similarity=0.0 → no penalty,   q2 = q2_svd
        # similarity=0.7 → factor 0.608, q2 = 0.608 * q2_svd
        # similarity=0.9 → factor 0.352, q2 = 0.352 * q2_svd
        # similarity=1.0 → floor 0.2
        q2 = float(np.clip(q2_svd * (1.0 - similarity**2 * 0.8), 0.2, 0.9))

        ch_names = {0: "R", 1: "G", 2: "B"}
        print(
            f"[NBExtract] Auto-Q: k={k:.2f}  sv_ratio={sv_ratio:.3f}  "
            f"row_similarity={similarity:.3f}  "
            f"dominant=({ch_names[ch1]},{ch_names[ch2]})  "
            f"->  Q1={q1:.2f}  Q2={q2:.2f}"
        )

        return q1, q2

    except Exception as e:
        print(f"[NBExtract] auto_q_per_channel failed ({e}), using global fallback")
        k = float(np.linalg.cond(A)) if A is not None else 10.0
        q = auto_q_from_condition_number(k)
        return q, q


def fit_mixing_matrix(
    star_records: List[Dict],
    *,
    sigma_clip: float = 3.0,
    max_iter: int = 3,
) -> Tuple[Optional[np.ndarray], int]:
    """
    Fit the 3x2 empirical mixing matrix A from stellar photometry,
    with iterative sigma clipping to reject outliers.

    Returns
    -------
    (A, n_used) where:
        A      : ndarray shape (3, 2) or None if fitting fails
        n_used : int, number of stars surviving sigma clipping
    """
    if not star_records:
        return None, 0

    S1 = np.array([s["S_line1"] for s in star_records], dtype=np.float64)
    S2 = np.array([s["S_line2"] for s in star_records], dtype=np.float64)
    Rm = np.array([s["R_meas"]  for s in star_records], dtype=np.float64)
    Gm = np.array([s["G_meas"]  for s in star_records], dtype=np.float64)
    Bm = np.array([s["B_meas"]  for s in star_records], dtype=np.float64)

    # Normalise design matrix columns so NNLS isn't fighting scale differences.
    s1_scale = float(np.median(S1)) if np.any(S1 > 0) else 1.0
    s2_scale = float(np.median(S2)) if np.any(S2 > 0) else 1.0
    if s1_scale <= 0: s1_scale = 1.0
    if s2_scale <= 0: s2_scale = 1.0

    S1_n = S1 / s1_scale
    S2_n = S2 / s2_scale

    r_scale = float(np.median(Rm)) if np.any(Rm > 0) else 1.0
    g_scale = float(np.median(Gm)) if np.any(Gm > 0) else 1.0
    b_scale = float(np.median(Bm)) if np.any(Bm > 0) else 1.0
    if r_scale <= 0: r_scale = 1.0
    if g_scale <= 0: g_scale = 1.0
    if b_scale <= 0: b_scale = 1.0

    Rm_n = Rm / r_scale
    Gm_n = Gm / g_scale
    Bm_n = Bm / b_scale

    X_full = np.column_stack([S1_n, S2_n])
    keep   = np.ones(len(star_records), dtype=bool)
    A_n    = np.zeros((3, 2), dtype=np.float64)

    for iteration in range(max_iter):
        X        = X_full[keep]
        channels = [Rm_n[keep], Gm_n[keep], Bm_n[keep]]

        A_iter = np.zeros((3, 2), dtype=np.float64)
        ok = True
        for ch_idx, y in enumerate(channels):
            try:
                coeffs, _ = nnls(X, y)
                A_iter[ch_idx] = coeffs
            except Exception as e:
                print(f"[NBExtract] NNLS failed for channel {ch_idx} iter {iteration}: {e}")
                ok = False
                break
        if not ok:
            break

        A_n = A_iter

        predicted = X_full @ A_n.T
        measured  = np.column_stack([Rm_n, Gm_n, Bm_n])
        with np.errstate(divide="ignore", invalid="ignore"):
            frac_res = np.where(predicted > 0,
                                np.abs(measured - predicted) / predicted,
                                0.0)
        star_res = np.mean(frac_res, axis=1)

        med = np.median(star_res[keep])
        mad = np.median(np.abs(star_res[keep] - med)) * 1.4826
        if mad <= 0:
            break

        new_keep  = keep & (star_res < med + sigma_clip * mad)
        n_clipped = int(np.sum(keep) - np.sum(new_keep))

        if n_clipped == 0:
            break

        print(f"[NBExtract] Sigma clip iter {iteration+1}: "
              f"clipped {n_clipped} stars, {int(np.sum(new_keep))} remaining")

        if np.sum(new_keep) < 6:
            print("[NBExtract] Too few stars after clipping; keeping previous mask.")
            break

        keep = new_keep

    n_used = int(np.sum(keep))

    flux_scales = [r_scale, g_scale, b_scale]
    A = np.zeros((3, 2), dtype=np.float64)
    for ch in range(3):
        A[ch, 0] = A_n[ch, 0] * flux_scales[ch] / s1_scale
        A[ch, 1] = A_n[ch, 1] * flux_scales[ch] / s2_scale

    if np.any(~np.isfinite(A)):
        print("[NBExtract] Mixing matrix contains non-finite values.")
        return None, 0

    try:
        k = float(np.linalg.cond(A))
        if k > 1e8:
            print(
                f"[NBExtract] Mixing matrix is numerically singular (cond={k:.2e}).\n"
                f"  Likely cause: G and B channels are identical (e.g. a synthetic HOO image\n"
                f"  where G=B=OIII). NBExtract requires a real dual-band OSC image where\n"
                f"  the green and blue Bayer pixels have genuinely different responses."
            )
            return None, 0
    except Exception:
        pass

    return A, n_used


def extract_channels_nnls(
    img_rgb: np.ndarray,
    A: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Solve the per-pixel 3x2 system for line1 and line2 channel images.

    Uses the Moore-Penrose pseudo-inverse of A followed by non-negativity
    clipping.  Returns raw linear pseudo-flux arrays — no normalisation or
    scaling is applied here.  The caller is responsible for any stretch.
    """
    H, W = img_rgb.shape[:2]
    pixels = img_rgb.reshape(-1, 3).astype(np.float64)

    # NaN-safety: any pixel non-finite in ANY channel is 'no data' -> NaN in both
    # outputs, so the downstream integrator's NaN handling still works. A finite-0
    # warp border stays 0 (pinv @ [0,0,0] = [0,0]); only NaN/Inf become NaN.
    invalid = ~np.all(np.isfinite(pixels), axis=1)
    filled = np.where(np.isfinite(pixels), pixels, 0.0)

    A_pinv = np.linalg.pinv(A)
    out = (A_pinv @ filled.T).T
    out = np.clip(out, 0.0, None)
    out[invalid, :] = np.nan

    line1 = out[:, 0].reshape(H, W).astype(np.float32)
    line2 = out[:, 1].reshape(H, W).astype(np.float32)

    return line1, line2


def extract_channels_regularized(
    img_rgb: np.ndarray,
    A: np.ndarray,
    q1: Optional[float] = None,
    q2: Optional[float] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Conditioning-aware regularised extraction: q*NNLS + (1-q)*raw_prior per line.

    Same Q-blend the interactive NBExtract uses (auto_q_per_channel +
    raw_prior_from_matrix), but WITHOUT the display median-stretch or unity
    rescale — the output stays linear so it can be normalised / rejected /
    integrated by the stacker. Pure NNLS (Q=1) is too aggressive per-frame: it
    amplifies noise in the faint line and widens sigma-clip thresholds, hurting
    rejection. q1/q2 default to auto_q_per_channel(A) (clipped to [0.2, 0.9]).

    NaN-safe: any pixel non-finite in ANY RGB channel comes out NaN in both
    lines; finite-0 warp borders stay 0.
    """
    line1_nnls, line2_nnls = extract_channels_nnls(img_rgb, A)

    aq1, aq2 = auto_q_per_channel(A)
    if q1 is None:
        q1 = aq1
    if q2 is None:
        q2 = aq2
    q1 = float(np.clip(q1, 0.0, 1.0))
    q2 = float(np.clip(q2, 0.0, 1.0))

    raw1 = np.asarray(raw_prior_from_matrix(img_rgb, A, 0), dtype=np.float32)
    raw2 = np.asarray(raw_prior_from_matrix(img_rgb, A, 1), dtype=np.float32)

    with np.errstate(invalid="ignore"):
        line1 = np.clip(q1 * line1_nnls + (1.0 - q1) * raw1, 0.0, None).astype(np.float32)
        line2 = np.clip(q2 * line2_nnls + (1.0 - q2) * raw2, 0.0, None).astype(np.float32)

    invalid = ~np.all(np.isfinite(img_rgb[..., :3]), axis=2)
    line1[invalid] = np.nan
    line2[invalid] = np.nan
    return line1, line2


def condition_number_warning(A: np.ndarray) -> Tuple[Optional[str], str]:
    """
    Return (warning_text, severity) where severity is one of:
        "ok"      — k < 25,  clean separation
        "caution" — 25 <= k < 100, moderate overlap, auto-Q will compensate
        "severe"  — k >= 100, noise amplification too large for reliable extraction

    warning_text is None when severity is "ok".
    """
    try:
        k = float(np.linalg.cond(A))
        if k >= 100:
            return (
                f"Condition number is {k:.1f} — channel separation is too poor for\n"
                f"reliable NNLS extraction (noise amplified ~{k**2:.0f}×).\n"
                "The stellar flux color mixing fallback will give better results.",
                "severe"
            )
        if k >= 25:
            return (
                f"Condition number is {k:.1f} — moderate channel overlap.\n"
                "Auto-Q has been set conservatively. Check the extracted channels\n"
                "for dark halos and reduce Q further if needed.",
                "caution"
            )
    except Exception:
        pass
    return None, "ok"


# ─────────────────────────────────────────────────────────────────────────────
# Dialog
# ─────────────────────────────────────────────────────────────────────────────

class NBExtractDialog(SFCCDialog):
    """
    Narrowband Channel Extractor dialog.

    Subclasses SFCCDialog to inherit:
        fetch_stars()                   — SIMBAD + Gaia XP star catalogue
        _make_working_base_for_sep()    — SEP-ready image preparation
        Pickles FITS loading machinery
        WCS initialisation

    Adds:
        Filter type + bandwidth UI
        Step 2: empirical mixing matrix calibration (auto-Q from condition number)
        Step 3: per-pixel NNLS channel extraction with Q-blended regularisation
        Two new output documents (line1, line2)
    """

    def __init__(self, doc_manager, sasp_data_path: str, parent=None):
        super().__init__(doc_manager, sasp_data_path, parent)

        _force_mpl_no_tex()
        self.setWindowTitle("Narrowband Channel Extractor (NBExtract)")
        self.setMinimumSize(740, 560)

        # Internal state
        self._A_matrix: Optional[np.ndarray] = None
        self._nb_star_records: List[Dict] = []
        self._fallback_mode: bool = False

        # Headless-run state (set by run_headless / run_nbextract_via_preset)
        self._headless: bool = False
        self._allow_fallback: bool = False
        self._last_output_docs: List = []

        self._inject_nb_ui()
        self._load_nb_settings()

    # ── UI injection ──────────────────────────────────────────────────────────

    def _inject_nb_ui(self):
        _sfcc_only = [
            "r_filter_combo", "g_filter_combo", "b_filter_combo",
            "sens_combo", "lp_filter_combo", "lp_filter_combo2",
            "run_spcc_btn", "run_grad_btn", "grad_method_combo",
            "neutralize_chk", "open_sasp_btn",
            "add_curve_btn", "remove_curve_btn", "star_combo",
            "btn_help",
        ]
        for attr in _sfcc_only:
            w = getattr(self, attr, None)
            if w is not None:
                try:
                    w.hide()
                except Exception:
                    pass

        self._hide_sfcc_filter_labels()

        grp = QGroupBox("Narrowband Filter Configuration")
        grp_lay = QVBoxLayout(grp)

        # Preset selector row
        row_preset = QHBoxLayout()
        row_preset.addWidget(QLabel("Filter type:"))
        self.nb_preset_combo = QComboBox()
        for name in FILTER_PRESETS:
            self.nb_preset_combo.addItem(name)
        self.nb_preset_combo.currentIndexChanged.connect(self._on_preset_changed)
        row_preset.addWidget(self.nb_preset_combo)
        row_preset.addStretch()
        grp_lay.addLayout(row_preset)

        # Line 1 row
        row_l1 = QHBoxLayout()
        self.nb_line1_label = QLabel("Ha center (nm):")
        row_l1.addWidget(self.nb_line1_label)
        self.nb_center1_spin = QDoubleSpinBox()
        self.nb_center1_spin.setRange(400.0, 800.0)
        self.nb_center1_spin.setDecimals(2)
        self.nb_center1_spin.setSingleStep(0.1)
        self.nb_center1_spin.setSuffix(" nm")
        row_l1.addWidget(self.nb_center1_spin)
        row_l1.addSpacing(16)
        row_l1.addWidget(QLabel("Bandwidth (FWHM):"))
        self.nb_bw1_spin = QDoubleSpinBox()
        self.nb_bw1_spin.setRange(1.0, 30.0)
        self.nb_bw1_spin.setDecimals(1)
        self.nb_bw1_spin.setSingleStep(0.5)
        self.nb_bw1_spin.setSuffix(" nm")
        row_l1.addWidget(self.nb_bw1_spin)
        row_l1.addStretch()
        grp_lay.addLayout(row_l1)

        # Line 2 row
        row_l2 = QHBoxLayout()
        self.nb_line2_label = QLabel("OIII center (nm):")
        row_l2.addWidget(self.nb_line2_label)
        self.nb_center2_spin = QDoubleSpinBox()
        self.nb_center2_spin.setRange(400.0, 800.0)
        self.nb_center2_spin.setDecimals(2)
        self.nb_center2_spin.setSingleStep(0.1)
        self.nb_center2_spin.setSuffix(" nm")
        row_l2.addWidget(self.nb_center2_spin)
        row_l2.addSpacing(16)
        row_l2.addWidget(QLabel("Bandwidth (FWHM):"))
        self.nb_bw2_spin = QDoubleSpinBox()
        self.nb_bw2_spin.setRange(1.0, 30.0)
        self.nb_bw2_spin.setDecimals(1)
        self.nb_bw2_spin.setSingleStep(0.5)
        self.nb_bw2_spin.setSuffix(" nm")
        row_l2.addWidget(self.nb_bw2_spin)
        row_l2.addStretch()
        grp_lay.addLayout(row_l2)

        # Custom line name row — only visible for Custom preset
        row_names = QHBoxLayout()
        row_names.addWidget(QLabel("Line 1 name:"))
        self.nb_line1_name = QLineEdit("Line1")
        self.nb_line1_name.setMaximumWidth(80)
        self.nb_line1_name.setPlaceholderText("e.g. NII")
        self.nb_line1_name.setToolTip("Short label for line 1 (used in output document names)")
        row_names.addWidget(self.nb_line1_name)
        row_names.addSpacing(24)
        row_names.addWidget(QLabel("Line 2 name:"))
        self.nb_line2_name = QLineEdit("Line2")
        self.nb_line2_name.setMaximumWidth(80)
        self.nb_line2_name.setPlaceholderText("e.g. HeI")
        self.nb_line2_name.setToolTip("Short label for line 2 (used in output document names)")
        row_names.addWidget(self.nb_line2_name)
        row_names.addStretch()
        self.nb_custom_names_row = QWidget()
        self.nb_custom_names_row.setLayout(row_names)
        self.nb_custom_names_row.setVisible(False)   # hidden until Custom selected
        grp_lay.addWidget(self.nb_custom_names_row)

        # Action buttons row
        row_act = QHBoxLayout()

        self.nb_calibrate_btn = QPushButton("Step 2: Calibrate Mixing Matrix")
        f = self.nb_calibrate_btn.font()
        f.setBold(True)
        self.nb_calibrate_btn.setFont(f)
        self.nb_calibrate_btn.clicked.connect(self._calibrate_mixing_matrix)
        row_act.addWidget(self.nb_calibrate_btn)

        self.nb_extract_btn = QPushButton("Step 3: Extract Channels")
        f2 = self.nb_extract_btn.font()
        f2.setBold(True)
        self.nb_extract_btn.setFont(f2)
        self.nb_extract_btn.setEnabled(False)
        self.nb_extract_btn.clicked.connect(self._extract_channels)
        row_act.addWidget(self.nb_extract_btn)

        self.nb_stretch_chk = QCheckBox("Match output median to source")
        self.nb_stretch_chk.setChecked(True)
        self.nb_stretch_chk.setToolTip(
            "Applies a statistical stretch to each extracted channel so its\n"
            "median matches the corresponding source channel median.\n"
            "Leave checked for a linear output that sits at the same\n"
            "intensity level as the input image."
        )
        row_act.addWidget(self.nb_stretch_chk)
        row_act.addStretch()
        # Max calibration stars
        row_act.addSpacing(16)
        row_act.addWidget(QLabel("Max cal stars:"))
        self.nb_max_cal_spin = QSpinBox()
        self.nb_max_cal_spin.setRange(6, 2000)
        self.nb_max_cal_spin.setValue(300)
        self.nb_max_cal_spin.setSingleStep(50)
        self.nb_max_cal_spin.setToolTip(
            "Maximum number of Gaia XP stars used to fit the mixing matrix.\n"
            "The brightest N re-detected stars are selected.\n"
            "300 is more than sufficient — increase only for very sparse fields."
        )
        row_act.addWidget(self.nb_max_cal_spin)
        self.nb_max_cal_spin.valueChanged.connect(self._save_nb_settings)
        grp_lay.addLayout(row_act)
        # Matrix readout
        self.nb_matrix_label = QLabel("Mixing matrix: (not yet calibrated)")
        self.nb_matrix_label.setWordWrap(True)
        grp_lay.addWidget(self.nb_matrix_label)

        # ── Advanced: per-channel Q blending ─────────────────────────────
        adv_hdr = QHBoxLayout()
        self.nb_adv_btn = QPushButton("Advanced ▸")
        self.nb_adv_btn.setFlat(True)
        self.nb_adv_btn.setStyleSheet("font-size:11px; text-align:left;")
        self.nb_adv_btn.clicked.connect(self._toggle_nb_advanced)

        self.nb_adv_summary = QLabel("Q auto")
        self.nb_adv_summary.setStyleSheet("font-size:10px; color: palette(placeholderText);")
        adv_hdr.addWidget(self.nb_adv_btn)
        adv_hdr.addStretch(1)
        adv_hdr.addWidget(self.nb_adv_summary)
        grp_lay.addLayout(adv_hdr)

        self.nb_adv_panel = QWidget()
        adv_l = QVBoxLayout(self.nb_adv_panel)
        adv_l.setContentsMargins(4, 0, 0, 0)
        adv_l.setSpacing(6)

        # Auto-Q explanation label
        self.nb_q_auto_label = QLabel(
            "Q values are set automatically from the matrix condition number.\n"
            "Lower Q = more conservative (less NNLS correction, closer to raw channel).\n"
            "Override below if needed."
        )
        self.nb_q_auto_label.setStyleSheet("font-size:10px; color: palette(placeholderText);")
        self.nb_q_auto_label.setWordWrap(True)
        adv_l.addWidget(self.nb_q_auto_label)

        # Q1 row (line1)
        q1_row = QHBoxLayout()
        self.nb_q1_label = QLabel("Line 1 (Ha) mixing strength Q:")
        self.nb_q1_label.setStyleSheet("font-size:11px;")
        self.nb_q1_spin = QDoubleSpinBox()
        self.nb_q1_spin.setRange(0.0, 1.0)
        self.nb_q1_spin.setDecimals(2)
        self.nb_q1_spin.setSingleStep(0.05)
        self.nb_q1_spin.setValue(1.0)
        self.nb_q1_spin.setToolTip(
            "Blend between raw R channel (0.0) and full NNLS extraction (1.0).\n"
            "Auto-set from condition number after calibration.\n"
            "If the Ha channel shows dark halos or over-subtraction, reduce toward 0.5-0.7."
        )
        q1_row.addWidget(self.nb_q1_label)
        q1_row.addWidget(self.nb_q1_spin)
        q1_row.addStretch(1)
        adv_l.addLayout(q1_row)

        # Q2 row (line2)
        q2_row = QHBoxLayout()
        self.nb_q2_label = QLabel("Line 2 (OIII) mixing strength Q:")
        self.nb_q2_label.setStyleSheet("font-size:11px;")
        self.nb_q2_spin = QDoubleSpinBox()
        self.nb_q2_spin.setRange(0.0, 1.0)
        self.nb_q2_spin.setDecimals(2)
        self.nb_q2_spin.setSingleStep(0.05)
        self.nb_q2_spin.setValue(1.0)
        self.nb_q2_spin.setToolTip(
            "Blend between raw G channel (0.0) and full NNLS extraction (1.0).\n"
            "Auto-set from condition number after calibration.\n"
            "If the OIII channel shows dark holes or over-subtraction, reduce toward 0.5-0.7."
        )
        q2_row.addWidget(self.nb_q2_label)
        q2_row.addWidget(self.nb_q2_spin)
        q2_row.addStretch(1)
        adv_l.addLayout(q2_row)

        self.nb_q1_spin.valueChanged.connect(self._update_nb_adv_summary)
        self.nb_q2_spin.valueChanged.connect(self._update_nb_adv_summary)

        self.nb_adv_panel.setVisible(False)
        grp_lay.addWidget(self.nb_adv_panel)

        # Insert group above the status label
        layout = self.layout()
        idx = self._find_widget_index_in_layout(layout, self.count_label)
        if idx >= 0:
            layout.insertWidget(idx, grp)
        else:
            layout.addWidget(grp)

        # Wire custom name edits to refresh the center labels live
        self.nb_line1_name.textChanged.connect(
            lambda _: self._on_preset_changed() if self.nb_preset_combo.currentText() == FILTER_PRESET_CUSTOM else None
        )
        self.nb_line2_name.textChanged.connect(
            lambda _: self._on_preset_changed() if self.nb_preset_combo.currentText() == FILTER_PRESET_CUSTOM else None
        )

        self.nb_max_cal_spin.valueChanged.connect(self._redraw_fetch_histogram)
        self._place_nb_help_button()
        self._on_preset_changed()

    def _place_nb_help_button(self):
        """
        Put the NBExtract help button to the right of the inherited
        'Reset View/Close' button at the bottom of the SFCC layout —
        matches the lower-right placement used by every other SASpro tool.
        """
        from PyQt6.QtWidgets import QPushButton

        # Find the Reset View/Close button in the inherited SFCC UI
        reset_btn = None
        for b in self.findChildren(QPushButton):
            txt = b.text() or ""
            if "Reset View" in txt and "Close" in txt:
                reset_btn = b
                break
        if reset_btn is None:
            return

        # Walk the layout tree to find the layout holding the reset button
        def _find_layout(layout, target):
            if layout is None:
                return None
            for i in range(layout.count()):
                item = layout.itemAt(i)
                if item is None:
                    continue
                if item.widget() is target:
                    return (layout, i)
                sub = item.layout()
                if sub is not None:
                    r = _find_layout(sub, target)
                    if r is not None:
                        return r
            return None

        found = _find_layout(self.layout(), reset_btn)
        if found is None:
            return
        layout, idx = found

        # Create the NB help button and insert it just after the Reset button
        self.btn_help = make_help_button("nbextract", self)
        layout.insertWidget(idx + 1, self.btn_help)

    def _hide_sfcc_filter_labels(self):
        layout = self.layout()
        if layout is None:
            return
        _sfcc_label_fragments = (
            "R Filter", "G Filter", "B Filter",
            "Sensor", "LP/Cut", "Select White",
        )
        for i in range(layout.count()):
            item = layout.itemAt(i)
            if item is None:
                continue
            sub = item.layout()
            if sub is None:
                continue
            for j in range(sub.count()):
                sub_item = sub.itemAt(j)
                if sub_item is None:
                    continue
                w = sub_item.widget()
                if isinstance(w, QLabel):
                    if any(frag in w.text() for frag in _sfcc_label_fragments):
                        w.hide()

    @staticmethod
    def _find_widget_index_in_layout(layout, target) -> int:
        for i in range(layout.count()):
            item = layout.itemAt(i)
            if item and item.widget() is target:
                return i
        return -1

    # ── Preset / settings ─────────────────────────────────────────────────────

    def _on_preset_changed(self, _=None):
        preset_name = self.nb_preset_combo.currentText()
        if preset_name not in FILTER_PRESETS:
            return

        is_custom = (preset_name == FILTER_PRESET_CUSTOM)
        l1_key, l2_key = FILTER_PRESETS[preset_name]

        # Show/hide custom name editors
        if hasattr(self, "nb_custom_names_row"):
            self.nb_custom_names_row.setVisible(is_custom)

        # For Custom preset the center/BW spinners are always editable;
        # for named presets they snap to the known values.
        if not is_custom:
            for sp in (self.nb_center1_spin, self.nb_center2_spin,
                       self.nb_bw1_spin, self.nb_bw2_spin):
                sp.blockSignals(True)
            self.nb_center1_spin.setValue(LINE_CENTERS_NM[l1_key])
            self.nb_center2_spin.setValue(LINE_CENTERS_NM[l2_key])
            self.nb_bw1_spin.setValue(DEFAULT_BW_NM[l1_key])
            self.nb_bw2_spin.setValue(DEFAULT_BW_NM[l2_key])
            for sp in (self.nb_center1_spin, self.nb_center2_spin,
                       self.nb_bw1_spin, self.nb_bw2_spin):
                sp.blockSignals(False)
        # Custom: leave spinners at whatever the user last set

        # Update labels — for Custom use the QLineEdit names
        if is_custom:
            n1 = self.nb_line1_name.text().strip() or "Line1"
            n2 = self.nb_line2_name.text().strip() or "Line2"
        else:
            n1, n2 = l1_key, l2_key

        self.nb_line1_label.setText(f"{n1} center (nm):")
        self.nb_line2_label.setText(f"{n2} center (nm):")

        if hasattr(self, "nb_q1_label"):
            self.nb_q1_label.setText(f"Line 1 ({n1}) mixing strength Q:")
        if hasattr(self, "nb_q2_label"):
            self.nb_q2_label.setText(f"Line 2 ({n2}) mixing strength Q:")

        self._A_matrix = None
        self.nb_extract_btn.setEnabled(False)
        self.nb_matrix_label.setText("Mixing matrix: (not yet calibrated)")

    def _toggle_nb_advanced(self):
        show = not self.nb_adv_panel.isVisible()
        self.nb_adv_panel.setVisible(show)
        self.nb_adv_btn.setText("Advanced ▾" if show else "Advanced ▸")
        self.nb_adv_summary.setVisible(not show)

    def _update_nb_adv_summary(self):
        q1 = float(self.nb_q1_spin.value())
        q2 = float(self.nb_q2_spin.value())
        self.nb_adv_summary.setText(f"Q\u2081 {q1:.2f}   Q\u2082 {q2:.2f}")

    def _set_auto_q(self, A: np.ndarray):
        """
        Set Q spinners from the mixing matrix using per-channel SVD analysis.
        Q₁ (line1/Ha) depends on global conditioning.
        Q₂ (line2/OIII) is additionally penalised by G/B row degeneracy —
        the most common cause of OIII over-subtraction.
        """
        k = float(np.linalg.cond(A))
        q1, q2 = auto_q_per_channel(A)

        self.nb_q1_spin.blockSignals(True)
        self.nb_q2_spin.blockSignals(True)
        self.nb_q1_spin.setValue(q1)
        self.nb_q2_spin.setValue(q2)
        self.nb_q1_spin.blockSignals(False)
        self.nb_q2_spin.blockSignals(False)

        self._update_nb_adv_summary()

        if k < 5:
            quality = "well-conditioned — channels separate cleanly"
        elif k < 15:
            quality = "moderate — some channel overlap"
        elif k < 50:
            quality = "poorly conditioned — significant channel overlap"
        else:
            quality = "very poorly conditioned — channels barely separable"

        self.nb_q_auto_label.setText(
            f"Q auto-derived from matrix structure (condition number {k:.2f}, {quality}).\n"
            f"Q₁ = {q1:.2f} ({q1*100:.0f}% NNLS + {(1-q1)*100:.0f}% raw R).\n"
            f"Q₂ = {q2:.2f} ({q2*100:.0f}% NNLS + {(1-q2)*100:.0f}% raw G) — "
            f"penalised by G/B channel similarity in OIII column.\n"
            f"Override below if needed."
        )

    # ── fetch_stars override ──────────────────────────────────────────────────
    def fetch_stars(self):
        super().fetch_stars()
        if not getattr(self, "star_list", None):
            return

        n_gaia_xp = sum(1 for s in self.star_list if s.get("gaia_source_id") is not None)
        n_no_xp   = len(self.star_list) - n_gaia_xp

        self._redraw_fetch_histogram()

        if getattr(self, "count_label", None) is not None:
            self.count_label.setText(
                f"Step 1 complete — {len(self.star_list):,} stars detected  ·  "
                f"{n_gaia_xp:,} Gaia XP spectra available for calibration  ·  "
                f"{n_no_xp:,} no XP spectrum"
            )

    def _redraw_fetch_histogram(self):
        if not getattr(self, "star_list", None):
            return

        n_gaia_xp = sum(1 for s in self.star_list if s.get("gaia_source_id") is not None)
        if n_gaia_xp == 0:
            return

        gmags = [s["gaia_gmag"] for s in self.star_list
                 if s.get("gaia_source_id") is not None
                 and s.get("gaia_gmag") is not None]
        if not gmags:
            return

        try:
            _force_mpl_no_tex()
            self.figure.clf()

            max_cal = int(self.nb_max_cal_spin.value())
            gmags_sorted = sorted(gmags)

            if len(gmags_sorted) >= max_cal:
                limiting_mag = gmags_sorted[max_cal - 1]
                mag_line = f"brightest {max_cal} stars reach G = {limiting_mag:.1f}"
            else:
                limiting_mag = gmags_sorted[-1]
                mag_line = f"all {len(gmags_sorted)} stars used — faintest G = {limiting_mag:.1f}"

            ax = self.figure.add_subplot(111)
            ax.hist(gmags, bins=30, color="#44cc88", edgecolor="none", alpha=0.85)
            ax.axvline(limiting_mag, color="#ffaa44", lw=1.4,
                       linestyle="--", alpha=0.85, label=f"G = {limiting_mag:.1f} cut")
            ax.legend(fontsize=8)
            ax.set_xlabel("Gaia G magnitude")
            ax.set_ylabel("Count")
            ax.set_title(
                f"Gaia XP stars available for NBExtract calibration\n"
                f"n={n_gaia_xp:,} total  ·  {mag_line}"
            )
            ax.grid(axis="y", linestyle="--", alpha=0.3)
            self.figure.tight_layout()
            self.canvas.setVisible(True)
            self.canvas.draw()
        except Exception as e:
            print(f"[NBExtract] Histogram redraw failed: {e}")

    # ── Settings ──────────────────────────────────────────────────────────────

    def _load_nb_settings(self):
        s = QSettings()
        preset = s.value(_SK_PRESET, "Ha / OIII")
        idx = self.nb_preset_combo.findText(preset)
        if idx >= 0:
            self.nb_preset_combo.setCurrentIndex(idx)
        for key, spin in (
            (_SK_BW1,     self.nb_bw1_spin),
            (_SK_BW2,     self.nb_bw2_spin),
            (_SK_CENTER1, self.nb_center1_spin),
            (_SK_CENTER2, self.nb_center2_spin),
        ):
            val = s.value(key, None)
            if val is not None:
                try:
                    spin.setValue(float(val))
                except Exception:
                    pass
        max_cal = s.value(_SK_MAX_CAL, 300)
        if hasattr(self, "nb_max_cal_spin"):
            try:
                self.nb_max_cal_spin.setValue(int(max_cal))
            except Exception:
                pass

    def _save_nb_settings(self):
        s = QSettings()
        s.setValue(_SK_PRESET,  self.nb_preset_combo.currentText())
        s.setValue(_SK_BW1,     self.nb_bw1_spin.value())
        s.setValue(_SK_BW2,     self.nb_bw2_spin.value())
        s.setValue(_SK_CENTER1, self.nb_center1_spin.value())
        s.setValue(_SK_CENTER2, self.nb_center2_spin.value())
        s.setValue(_SK_MAX_CAL, self.nb_max_cal_spin.value()
                   if hasattr(self, "nb_max_cal_spin") else 300)
        
    # ── SED loading ───────────────────────────────────────────────────────────

    def _load_sed_nm(self, extname: str) -> Tuple[np.ndarray, np.ndarray]:
        for path in (self.user_custom_path, self.sasp_data_path):
            try:
                with fits.open(path, memmap=False) as hd:
                    if extname in hd:
                        d      = hd[extname].data
                        wl_raw = d["WAVELENGTH"].astype(np.float64)
                        fl     = d["FLUX"].astype(np.float64)
                        wl_ang = _ensure_angstrom(wl_raw)
                        wl_nm  = wl_ang / 10.0
                        return wl_nm, fl
            except Exception:
                continue
        raise KeyError(f"SED extension '{extname}' not found in FITS data files.")

    # ── Step 2: calibrate mixing matrix ──────────────────────────────────────
    def _calibrate_mixing_matrix(self):
        if not getattr(self, "star_list", None):
            self._nb_abort(
                "No Stars",
                "Please run Step 1: Fetch Stars first.\n"
                "The image must be plate-solved.",
                level="warning",
            )
            return

        doc = self.doc_manager.get_active_document()
        if doc is None or doc.image is None:
            self._nb_abort("Error", "No active document.")
            return

        img = doc.image
        if img.ndim != 3 or img.shape[2] != 3:
            self._nb_abort("Error", "Active document must be RGB (3 channels).")
            return

        center1_nm  = float(self.nb_center1_spin.value())
        center2_nm  = float(self.nb_center2_spin.value())
        bw1_nm      = float(self.nb_bw1_spin.value())
        bw2_nm      = float(self.nb_bw2_spin.value())
        preset_name = self.nb_preset_combo.currentText()
        l1_key, l2_key = FILTER_PRESETS.get(preset_name, ("Ha", "OIII"))
        if preset_name == FILTER_PRESET_CUSTOM:
            l1_key = self.nb_line1_name.text().strip() or "Line1"
            l2_key = self.nb_line2_name.text().strip() or "Line2"

        # ── Prepare image ─────────────────────────────────────────────────
        _sfcc_status(self, "NBExtract XP: preparing image for photometry…")
        QApplication.processEvents()

        img_float = img.astype(np.float32) / (255.0 if img.dtype == np.uint8 else 1.0)
        base = self._make_working_base_for_sep(img_float)

        # Registration/warp borders (all-channel 0.0) and non-finite pixels must
        # not pollute the SEP background, global RMS, detection, or photometry.
        _finite_all  = np.all(np.isfinite(img_float), axis=2)
        _zero_border = np.all(img_float == 0.0, axis=2)
        self._nb_invalid_mask = (~_finite_all) | _zero_border

        # ── SEP re-detection ──────────────────────────────────────────────
        import sep
        gray = np.mean(np.where(np.isfinite(base), base, 0.0), axis=2).astype(np.float32)
        _inv = self._nb_invalid_mask
        if _inv.shape != gray.shape:            # base was resized -> disable masking
            _inv = np.zeros(gray.shape, dtype=bool)
            self._nb_invalid_mask = _inv
        gray[_inv] = 0.0
        gray = np.ascontiguousarray(gray)
        _inv = np.ascontiguousarray(_inv)
        bkg      = sep.Background(gray, mask=_inv)
        data_sub = gray - bkg.back()
        err      = float(bkg.globalrms)

        sep_sigma = float(self.sep_thr_spin.value()) if hasattr(self, "sep_thr_spin") else 5.0
        _sfcc_status(self, f"NBExtract XP: re-detecting stars (SEP σ={sep_sigma:.1f})…")
        QApplication.processEvents()

        sources = sep.extract(data_sub, sep_sigma, err=err, mask=_inv)
        if sources.size == 0:
            self._nb_abort("SEP Error", "SEP found no sources.")
            return

        r_fluxrad, _ = sep.flux_radius(
            gray, sources["x"], sources["y"],
            2.0 * sources["a"], 0.5,
            normflux=sources["flux"], subpix=5,
        )
        mask    = (r_fluxrad > 0.2) & (r_fluxrad <= 10)
        sources = sources[mask]
        if sources.size == 0:
            self._nb_abort("SEP Error",
                           "All SEP detections rejected by radius filter.")
            return

        _sfcc_status(self,
            f"NBExtract XP: {sources.size:,} sources detected — "
            f"matching to Gaia XP catalog…")
        QApplication.processEvents()

        # ── Load Gaia bulk library ─────────────────────────────────────────
        lib = None
        try:
            from setiastro.saspro.gaia_database import get_library
            lib = get_library()
            if not lib.installed_bands():
                lib = None
        except Exception:
            lib = None

        if lib is None:
            self._nb_abort("No Gaia Library",
                "Gaia XP spectral library is required for NBExtract calibration.\n"
                "Please install at least the Ultra-Bright or Bright group.")
            return

        # ── Match star_list XP stars to SEP detections ────────────────────
        # Only keep stars with a gaia_source_id that are re-detected by SEP.
        # Sort by SEP flux descending so we take the 300 brightest/cleanest.
        candidates = []
        for star in self.star_list:
            sid = star.get("gaia_source_id")
            if sid is None:
                continue

            dx = sources["x"] - star["x"]
            dy = sources["y"] - star["y"]
            j  = int(np.argmin(dx * dx + dy * dy))
            if (dx[j] ** 2 + dy[j] ** 2) >= 9.0:
                continue   # not re-detected at this SEP threshold — skip

            candidates.append({
                "star":      star,
                "src_flux":  float(sources["flux"][j]),
                "src_index": j,
                "a":         float(sources["a"][j]),
                "x":         float(sources["x"][j]),
                "y":         float(sources["y"][j]),
            })

        n_matched = len(candidates)
        _sfcc_status(self,
            f"NBExtract XP: {n_matched:,} Gaia XP stars re-detected by SEP — "
            f"selecting 300 brightest for calibration…")
        QApplication.processEvents()

        if n_matched == 0:
            self._nb_abort("No XP Stars Detected",
                "No Gaia XP stars were re-detected by SEP at the current threshold.\n\n"
                "Try lowering the Star detect σ, or install more Gaia XP library groups.",
                level="warning")
            return

        # Sort brightest first, cap at 300
        candidates.sort(key=lambda c: c["src_flux"], reverse=True)
        MAX_CAL_STARS = int(self.nb_max_cal_spin.value()) \
                        if hasattr(self, "nb_max_cal_spin") else 300
        candidates = candidates[:MAX_CAL_STARS]

        _sfcc_status(self,
            f"NBExtract XP: integrating spectra for {len(candidates)} brightest stars "
            f"over {l1_key} ({center1_nm:.2f} nm ± {bw1_nm/2:.1f}) "
            f"and {l2_key} ({center2_nm:.2f} nm ± {bw2_nm/2:.1f})…")
        QApplication.processEvents()

        # ── Aperture photometry + spectrum integration ─────────────────────
        star_records  = []
        n_no_spectrum = 0
        n_xp_used     = 0

        for cand in candidates:
            star = cand["star"]
            sid  = star.get("gaia_source_id")
            x    = cand["x"]
            y    = cand["y"]
            a    = cand["a"]
            r    = float(np.clip(2.0 * a, 2.0, 10.0))

            # Skip stars whose aperture bbox overlaps any invalid (border/NaN) pixel.
            _inv = getattr(self, "_nb_invalid_mask", None)
            if _inv is not None:
                _H, _W = _inv.shape
                _rr = int(np.ceil(r)) + 1
                _x0 = max(0, int(x) - _rr); _x1 = min(_W, int(x) + _rr + 1)
                _y0 = max(0, int(y) - _rr); _y1 = min(_H, int(y) + _rr + 1)
                if _x1 <= _x0 or _y1 <= _y0 or _inv[_y0:_y1, _x0:_x1].any():
                    continue

            phot = measure_star_rgb_raw_aperture(base, x, y, r)
            if phot is None:
                continue

            Rm = float(phot["R_raw"])
            Gm = float(phot["G_raw"])
            Bm = float(phot["B_raw"])

            if not (np.isfinite(Rm) and np.isfinite(Gm) and np.isfinite(Bm)):
                continue
            if Rm <= 0 or Gm <= 0 or Bm <= 0:
                continue

            # Load XP spectrum and normalize to unit total flux
            try:
                spec = lib.get_spectrum(int(sid))
                if spec is None:
                    n_no_spectrum += 1
                    continue
                wl_nm = np.asarray(spec.wavelengths, dtype=np.float64)
                fl    = np.asarray(spec.flux,        dtype=np.float64)
                total = float(np.trapz(fl, wl_nm))
                if total <= 0:
                    n_no_spectrum += 1
                    continue
                fl = fl / total
            except Exception as e:
                print(f"[NBExtract XP] spectrum load failed for {sid}: {e}")
                n_no_spectrum += 1
                continue

            S1 = integrate_sed_over_window(wl_nm, fl, center1_nm, bw1_nm)
            S2 = integrate_sed_over_window(wl_nm, fl, center2_nm, bw2_nm)

            if S1 <= 0.0 or S2 <= 0.0:
                n_no_spectrum += 1
                continue

            n_xp_used += 1
            star_records.append({
                "template": f"GaiaXP_{sid}",
                "x":       x,
                "y":       y,
                "R_meas":  Rm,
                "G_meas":  Gm,
                "B_meas":  Bm,
                "S_line1": S1,
                "S_line2": S2,
            })

        n_used = len(star_records)
        _sfcc_status(self,
            f"NBExtract XP: {n_used} calibration stars ready  ·  "
            f"{n_xp_used} XP spectra integrated  ·  "
            f"{n_no_spectrum} spectra missing from library")
        QApplication.processEvents()

        if n_used < 6:
            if not self._nb_confirm_fallback(
                "Too Few Stars — Use Fallback?",
                f"Only {n_used} Gaia XP calibration stars found (need ≥ 6 for NNLS).\n\n"
                f"  {n_matched:,} XP stars re-detected by SEP\n"
                f"  {n_xp_used} XP spectra successfully integrated\n"
                f"  {n_no_spectrum} spectra missing from local library\n\n"
                "Try installing more Gaia XP library groups, or lower the\n"
                "Star detect σ to detect more stars, or use the fallback.",
            ):
                return
            self._run_wb_fallback(doc, img_float, l1_key, l2_key)
            return

        # ── Fit mixing matrix ─────────────────────────────────────────────
        _sfcc_status(self,
            f"NBExtract XP: fitting {l1_key}/{l2_key} mixing matrix "
            f"from {n_used} Gaia XP stars…")
        QApplication.processEvents()

        A, n_clipped_used = fit_mixing_matrix(star_records)
        if A is None:
            if not self._nb_confirm_fallback(
                "Matrix Fit Failed — Use Fallback?",
                "Could not fit the NNLS mixing matrix.\n\n"
                "Common causes:\n"
                "  • Image is a synthetic palette (e.g. HOO where G=B=OIII exactly)\n"
                "  • Too few spectrally diverse stars survived sigma clipping.\n\n"
                "Use the stellar flux mixing fallback instead?",
            ):
                return
            self._run_wb_fallback(doc, img_float, l1_key, l2_key)
            return

        self._A_matrix        = A
        self._fallback_mode   = False
        self._nb_star_records = star_records
        self._save_nb_settings()

        k = float(np.linalg.cond(A))

        _sfcc_status(self,
            f"NBExtract XP: matrix fitted — condition number {k:.2f}  ·  "
            f"{n_clipped_used}/{n_used} stars used  ·  auto-deriving Q values…")
        QApplication.processEvents()

        self._set_auto_q(A)
        if not self._headless:
            self._plot_calibration_diagnostics(star_records, A, l1_key, l2_key)

        warn_text, warn_severity = condition_number_warning(A)

        def _pct(row, col):
            total = float(A[row, 0] + A[row, 1])
            if total <= 0: return 0.0
            return 100.0 * float(A[row, col]) / total

        q1_val = float(self.nb_q1_spin.value())
        q2_val = float(self.nb_q2_spin.value())

        matrix_lines = [
            f"Calibrated from {n_clipped_used} Gaia XP stars  "
            f"({n_matched:,} re-detected  ·  {n_used - n_clipped_used} outliers clipped)",
            f"Channel sensitivity  ({l1_key} %  |  {l2_key} %):",
            f"  R :  {_pct(0,0):.1f}%  {l1_key}   {_pct(0,1):.1f}%  {l2_key}",
            f"  G :  {_pct(1,0):.1f}%  {l1_key}   {_pct(1,1):.1f}%  {l2_key}",
            f"  B :  {_pct(2,0):.1f}%  {l1_key}   {_pct(2,1):.1f}%  {l2_key}",
            f"  Condition number : {k:.2f}   Q₁={q1_val:.2f}  Q₂={q2_val:.2f}",
        ]
        if warn_text:
            prefix = "  🛑  " if warn_severity == "severe" else "  ⚠  "
            matrix_lines.append(f"{prefix}{warn_text}")
        self.nb_matrix_label.setText("\n".join(matrix_lines))

        if warn_severity == "severe":
            if self._nb_confirm_fallback(
                "Poor Channel Separation — Use Fallback?",
                f"Condition number is {k:.1f} — noise would be amplified "
                f"~{k**2:.0f}× by the NNLS inversion.\n\n"
                f"At this level the extracted channels will be dominated by amplified "
                f"noise rather than real emission signal.\n\n"
                f"Switch to the stellar flux color mixing fallback instead?",
            ):
                self.nb_extract_btn.setEnabled(False)
                self._run_wb_fallback(doc, img_float, l1_key, l2_key)
                return
            self.nb_extract_btn.setEnabled(True)
        else:
            self.nb_extract_btn.setEnabled(True)

        _sfcc_status(self,
            f"NBExtract XP calibration complete — {n_clipped_used} stars  ·  "
            f"condition number {k:.2f}  ·  Q₁={q1_val:.2f}  Q₂={q2_val:.2f}  ·  "
            f"ready for Step 3")

        summary = (
            f"Mixing matrix fitted from {n_clipped_used} Gaia XP stars "
            f"({n_used - n_clipped_used} clipped as outliers)\n"
            f"  {n_matched:,} XP stars re-detected by SEP\n"
            f"  300 brightest selected for calibration\n\n"
            f"Condition number: {k:.2f}\n"
            f"Auto Q₁ = {q1_val:.2f}  Q₂ = {q2_val:.2f}\n\n"
        )
        summary += warn_text if warn_text else "Matrix looks well-conditioned ✓"
        if not self._headless:
            QMessageBox.information(self, "Calibration Complete", summary)

    def _plot_calibration_diagnostics(
        self,
        star_records: List[Dict],
        A: np.ndarray,
        l1_key: str,
        l2_key: str,
    ):
        """
        Two-panel calibration summary:

        Left — Channel sensitivity bar chart.
            Shows what percentage of each channel's response comes from
            line1 vs line2.  Directly answers "what did my filter actually do."

        Right — Fractional residual histogram.
            Distribution of (measured - predicted) / predicted across all
            stars and channels.  Tight peak near zero = good calibration.
            Wide or offset distribution = suspect stars or gradient issues.
        """
        _force_mpl_no_tex()
        self.figure.clf()

        # ── Left: normalized channel sensitivity ────────────────────────────
        # Each line is normalized to its own maximum so the plot shows
        # *relative* sensitivity — which channel dominates each line and
        # how much bleeds into the others.  Absolute cross-talk percentages
        # are shown in the matrix label above; this graph shows the shape.
        ax_bar = self.figure.add_subplot(1, 2, 1)

        # Raw absolute sensitivity per channel per line
        def _abs_sensitivity(col):
            """Absolute sensitivity of each RGB channel for line `col`."""
            vals = np.array([float(A[r, col]) for r in range(3)])
            total = vals.sum()
            return (100.0 * vals / total) if total > 0 else vals

        abs1 = _abs_sensitivity(0)   # line1 (Ha/SII) per-channel %
        abs2 = _abs_sensitivity(1)   # line2 (OIII/Hβ) per-channel %

        # Normalize each line to its own maximum channel
        max1 = float(abs1.max()) if abs1.max() > 0 else 1.0
        max2 = float(abs2.max()) if abs2.max() > 0 else 1.0
        norm1 = abs1 / max1   # peaks at 1.0
        norm2 = abs2 / max2   # peaks at 1.0

        ch_labels = ("R", "G", "B")
        x = np.arange(3)
        width = 0.35

        bars1 = ax_bar.bar(x - width / 2, norm1, width,
                           label=l1_key, color="tomato", edgecolor="none")
        bars2 = ax_bar.bar(x + width / 2, norm2, width,
                           label=l2_key, color="cornflowerblue", edgecolor="none")

        # Annotate each bar with the absolute percentage so the exact number
        # is still readable without needing to read the matrix label
        for bar, abs_val in zip(list(bars1), abs1):
            h = bar.get_height()
            if h > 0.02:
                ax_bar.text(
                    bar.get_x() + bar.get_width() / 2, h + 0.02,
                    f"{abs_val:.0f}%", ha="center", va="bottom", fontsize=7,
                )
        for bar, abs_val in zip(list(bars2), abs2):
            h = bar.get_height()
            if h > 0.02:
                ax_bar.text(
                    bar.get_x() + bar.get_width() / 2, h + 0.02,
                    f"{abs_val:.0f}%", ha="center", va="bottom", fontsize=7,
                )

        ax_bar.set_xticks(x)
        ax_bar.set_xticklabels(ch_labels)
        ax_bar.set_ylabel("Relative sensitivity (normalized to peak)")
        ax_bar.set_title("Filter channel sensitivity")
        ax_bar.set_ylim(0, 1.22)
        ax_bar.axhline(1.0, color="white", lw=0.6, linestyle="--", alpha=0.4)
        ax_bar.legend(fontsize=8)
        ax_bar.grid(axis="y", linestyle="--", alpha=0.3)

        # ── Right: fractional residual histogram ──────────────────────────
        ax_res = self.figure.add_subplot(1, 2, 2)

        S1   = np.array([s["S_line1"] for s in star_records])
        S2   = np.array([s["S_line2"] for s in star_records])
        X    = np.column_stack([S1, S2])
        pred = X @ A.T   # (N, 3)

        meas = np.column_stack([
            [s["R_meas"] for s in star_records],
            [s["G_meas"] for s in star_records],
            [s["B_meas"] for s in star_records],
        ])

        with np.errstate(divide="ignore", invalid="ignore"):
            frac_res = np.where(pred > 0, (meas - pred) / pred, np.nan)

        residuals = frac_res[np.isfinite(frac_res)].ravel()

        if len(residuals) > 0:
            median_res = float(np.median(residuals))
            std_res    = float(np.std(residuals))

            # Set display range to ±3σ around the median, uncapped —
            # outliers show as a natural tail rather than piling at a boundary
            lo = median_res - 3.0 * std_res
            hi = median_res + 3.0 * std_res
            n_outliers = int(np.sum((residuals < lo) | (residuals > hi)))

            ax_res.hist(residuals, bins=40, range=(lo, hi),
                        color="steelblue", edgecolor="none", alpha=0.8)
            ax_res.axvline(0, color="white", lw=1.2, linestyle="--", alpha=0.7)
            ax_res.axvline(median_res, color="tomato", lw=1.0,
                           linestyle="--", alpha=0.8, label=f"median {median_res:+.2f}")
            ax_res.legend(fontsize=7)

            title = f"Fit residuals  (σ={std_res:.2f}"
            if n_outliers > 0:
                title += f",  {n_outliers} beyond ±3σ"
            title += ")"
            ax_res.set_title(title, fontsize=9)
        else:
            ax_res.set_title("Fit residuals (no data)")

        ax_res.set_xlabel("(measured − predicted) / predicted")
        ax_res.set_ylabel("Star count")
        ax_res.grid(axis="y", linestyle="--", alpha=0.3)

        self.figure.suptitle(
            f"NBExtract calibration  —  {l1_key} / {l2_key}  "
            f"({len(star_records)} stars)",
            fontsize=10,
        )
        self.figure.tight_layout()
        self.canvas.setVisible(True)
        self.canvas.draw()

    # ── WB fallback ───────────────────────────────────────────────────────────

    def _run_wb_fallback(self, doc, img_float: np.ndarray, l1_key: str, l2_key: str):
        from setiastro.saspro.imageops.starbasedwhitebalance import (
            apply_star_based_white_balance,
        )

        _sfcc_status(self, "NBExtract fallback: applying stellar flux color mixing…")
        QApplication.processEvents()

        sep_sigma = float(self.sep_thr_spin.value()) if hasattr(self, "sep_thr_spin") else 5.0

        try:
            balanced, star_count, _overlay = apply_star_based_white_balance(
                img_float,
                threshold=sep_sigma,
                autostretch=False,
                reuse_cached_sources=False,
                return_star_colors=False,
                use_color_matrix=True,
            )
        except Exception as e:
            print(f"[NBExtract] WB fallback failed ({e}), using raw channel split.")
            balanced = img_float
            star_count = 0

        # Pick channels by wavelength: <520nm→blue, >600nm→red, else green
        def _wl_to_channel(center_nm: float) -> int:
            if center_nm < 520.0: return 2
            elif center_nm > 600.0: return 0
            else: return 1
        fb_ch1 = _wl_to_channel(float(self.nb_center1_spin.value()))
        fb_ch2 = _wl_to_channel(float(self.nb_center2_spin.value()))
        line1_img = balanced[..., fb_ch1].copy()
        line2_img = balanced[..., fb_ch2].copy()

        if self.nb_stretch_chk.isChecked():
            try:
                from setiastro.saspro.imageops.stretch import stretch_mono_image
                median_1 = float(np.median(img_float[..., fb_ch1]))
                median_2 = float(np.median(img_float[..., fb_ch2]))
                if median_1 > 1e-6:
                    line1_img = stretch_mono_image(
                        line1_img, target_median=median_1,
                        normalize=False, no_black_clip=True,
                    )
                if median_2 > 1e-6:
                    line2_img = stretch_mono_image(
                        line2_img, target_median=median_2,
                        normalize=False, no_black_clip=True,
                    )
            except Exception as e:
                print(f"[NBExtract] WB fallback median match failed: {e}")

        def _linear_scale_to_unity(ch: np.ndarray) -> np.ndarray:
            ch = np.maximum(np.asarray(ch, dtype=np.float32), 0.0)
            mx = float(ch.max())
            return ch / mx if mx > 1.0 else ch

        line1_img = _linear_scale_to_unity(line1_img)
        line2_img = _linear_scale_to_unity(line2_img)

        preset_name = self.nb_preset_combo.currentText()
        l1_key = self.nb_line1_name.text().strip() or "Line1" if preset_name == FILTER_PRESET_CUSTOM else l1_key
        l2_key = self.nb_line2_name.text().strip() or "Line2" if preset_name == FILTER_PRESET_CUSTOM else l2_key
        meta_base   = dict(doc.metadata or {})

        meta1 = {**meta_base, "NBExtract_line": l1_key, "NBExtract_preset": preset_name,
                 "NBExtract_center_nm": float(self.nb_center1_spin.value()),
                 "NBExtract_bw_nm": float(self.nb_bw1_spin.value()),
                 "NBExtract_method": "wb_fallback", "NBExtract_wb_stars": int(star_count)}
        meta2 = {**meta_base, "NBExtract_line": l2_key, "NBExtract_preset": preset_name,
                 "NBExtract_center_nm": float(self.nb_center2_spin.value()),
                 "NBExtract_bw_nm": float(self.nb_bw2_spin.value()),
                 "NBExtract_method": "wb_fallback", "NBExtract_wb_stars": int(star_count)}

        d1 = self._push_new_document(line1_img, meta1, f"{l1_key} (NBExtract)")
        d2 = self._push_new_document(line2_img, meta2, f"{l2_key} (NBExtract)")
        self._last_output_docs = [d for d in (d1, d2) if d is not None]

        self.nb_matrix_label.setText(
            f"Method: Stellar flux color mixing fallback\n"
            f"  {l1_key} = color-corrected R channel\n"
            f"  {l2_key} = color-corrected G channel\n"
            f"  Stars used: {star_count}"
        )
        self.nb_extract_btn.setEnabled(False)

        _sfcc_status(self,
            f"NBExtract color mixing fallback complete — '{l1_key}' and '{l2_key}' "
            f"created from {star_count} stars.")

        if not self._headless:
            QMessageBox.information(
                self, "Color Mixing Fallback Complete",
                f"Created two new documents using stellar flux color mixing:\n"
                f"  •  {l1_key} (NBExtract) — color-corrected R channel\n"
                f"  •  {l2_key} (NBExtract) — color-corrected G channel\n\n"
                f"3×3 color mixing matrix fitted from {star_count} stellar flux measurements.\n"
            )
        return list(self._last_output_docs)

    # ── Headless entry / preset plumbing ──────────────────────────

    def _nb_abort(self, title: str, text: str, level: str = "critical"):
        """Headless → raise NBExtractError; interactive → show a message box."""
        if self._headless:
            raise NBExtractError(text)
        if level == "warning":
            QMessageBox.warning(self, title, text)
        else:
            QMessageBox.critical(self, title, text)

    def _nb_confirm_fallback(self, title: str, text: str) -> bool:
        """Whether to run the stellar-flux WB fallback.

        Interactive: modal Yes/No prompt (Yes default, matching the old flow).
        Headless: no prompt — obey self._allow_fallback.
        """
        if self._headless:
            return bool(self._allow_fallback)
        reply = QMessageBox.question(
            self, title, text,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        return reply == QMessageBox.StandardButton.Yes

    def _apply_preset(self, preset: dict):
        """Push a preset dict onto the dialog widgets (used by headless runs)."""
        name = preset.get("preset", preset.get("filter"))
        if name:
            idx = self.nb_preset_combo.findText(str(name))
            if idx < 0:
                raise NBExtractError(
                    f"Unknown filter preset {name!r}. "
                    f"Options: {list(FILTER_PRESETS.keys())}"
                )
            self.nb_preset_combo.setCurrentIndex(idx)
        # Force a consistent widget state for the (possibly unchanged) selection.
        self._on_preset_changed()

        if self.nb_preset_combo.currentText() == FILTER_PRESET_CUSTOM:
            if preset.get("line1_name"):
                self.nb_line1_name.setText(str(preset["line1_name"]))
            if preset.get("line2_name"):
                self.nb_line2_name.setText(str(preset["line2_name"]))
            for key, spin in (
                ("center1_nm", self.nb_center1_spin),
                ("center2_nm", self.nb_center2_spin),
                ("bw1_nm",     self.nb_bw1_spin),
                ("bw2_nm",     self.nb_bw2_spin),
            ):
                if preset.get(key) is not None:
                    spin.setValue(float(preset[key]))

        if preset.get("max_cal_stars") is not None and hasattr(self, "nb_max_cal_spin"):
            self.nb_max_cal_spin.setValue(int(preset["max_cal_stars"]))
        if preset.get("sep_sigma") is not None and hasattr(self, "sep_thr_spin"):
            self.sep_thr_spin.setValue(float(preset["sep_sigma"]))
        if preset.get("stretch") is not None and hasattr(self, "nb_stretch_chk"):
            self.nb_stretch_chk.setChecked(bool(preset["stretch"]))

    def calibrate_only(self, *, doc=None, preset: Optional[dict] = None):
        """
        Headless Fetch -> Calibrate ONLY (no channel extraction, no new documents).

        Returns (A, star_records, cond):
            A            : (3, 2) mixing matrix
            star_records : raw per-star photometry dicts (R/G/B_meas + S_line1/2),
                           ready to be pooled across subs by the caller
            cond         : float(cond(A))

        The resolved target (doc, else doc_manager.get_active_document()) MUST be a
        plate-solved RGB image. Batch callers typically wrap doc_manager in a shim
        whose get_active_document() returns `doc`.

        Raises NBExtractError on any condition that would normally pop a modal.
        """
        preset = dict(preset or {})
        self._headless = True
        self._allow_fallback = False
        try:
            dm = self.doc_manager
            target = doc if doc is not None else (
                dm.get_active_document() if dm is not None else None
            )
            if target is None or getattr(target, "image", None) is None:
                raise NBExtractError("No document to calibrate NBExtract on.")
            img = target.image
            if img.ndim != 3 or img.shape[2] != 3:
                raise NBExtractError(
                    "NBExtract calibration requires an RGB (3-channel) image."
                )

            self._apply_preset(preset)

            # Always refetch so the star_list matches THIS document, even if the
            # dialog instance is reused across several subs.
            self.star_list = []
            self.fetch_stars()
            if not getattr(self, "star_list", None):
                raise NBExtractError(
                    "Star fetch returned no stars. The image must be plate-solved "
                    "(valid WCS) and lie within Gaia/SIMBAD catalog coverage."
                )

            self._calibrate_mixing_matrix()
            if self._A_matrix is None:
                raise NBExtractError(
                    "Calibration produced no mixing matrix (too few Gaia XP stars, "
                    "or the NNLS fit failed)."
                )
            A = np.asarray(self._A_matrix, dtype=np.float64).copy()
            recs = [dict(r) for r in (self._nb_star_records or [])]
            return A, recs, float(np.linalg.cond(A))
        finally:
            self._headless = False

    def run_headless(self, *, doc=None, preset: Optional[dict] = None):
        """
        Run the full NBExtract pipeline (Fetch → Calibrate → Extract) with no
        user interaction, on the active document.  Returns the list of newly
        created ImageDocuments (line1, line2).

        Raises NBExtractError on any condition that would normally pop a modal
        dialog (no stars, too few calibration stars, ill-conditioned matrix,
        wrong image type, …).

        Recognised preset keys:
            preset / filter   : "Ha / OIII" | "SII / OIII" | "SII / Hβ" | "Custom"
            line1_name/line2_name, center1_nm/center2_nm, bw1_nm/bw2_nm  (Custom)
            max_cal_stars     : int   (default 300)
            sep_sigma         : float (SEP detection threshold, default 5.0)
            stretch           : bool  (match output median to source, default True)
            q1 / q2           : float in [0,1] — override the auto-derived Q blend
            allow_fallback    : bool  — permit the stellar-flux WB fallback when
                                the XP calibration cannot be fitted (default False)
        """
        preset = dict(preset or {})
        self._headless = True
        self._allow_fallback = bool(preset.get("allow_fallback", False))
        self._last_output_docs = []
        try:
            dm = self.doc_manager
            active = dm.get_active_document() if dm is not None else None
            if doc is not None and active is not None and doc is not active:
                same_img = getattr(doc, "image", None) is getattr(active, "image", None)
                if not same_img:
                    raise NBExtractError(
                        "NBExtract (headless) operates on the active document, but a "
                        "different target document was supplied. Focus the intended "
                        "RGB document first, then run."
                    )
            target = doc if doc is not None else active
            if target is None or getattr(target, "image", None) is None:
                raise NBExtractError("No active document to run NBExtract on.")
            img = target.image
            if img.ndim != 3 or img.shape[2] != 3:
                raise NBExtractError("NBExtract requires an RGB (3-channel) image.")

            self._apply_preset(preset)

            # Step 1 — fetch stars (image must be plate-solved).
            if not getattr(self, "star_list", None):
                self.fetch_stars()
            if not getattr(self, "star_list", None):
                raise NBExtractError(
                    "Star fetch returned no stars. The image must be plate-solved "
                    "(valid WCS) and lie within Gaia/SIMBAD catalog coverage."
                )

            # Step 2 — calibrate mixing matrix (may run WB fallback if allowed).
            self._calibrate_mixing_matrix()

            # Fallback path already produced the two output documents.
            if self._last_output_docs:
                return list(self._last_output_docs)

            if self._A_matrix is None:
                raise NBExtractError(
                    "Calibration produced no mixing matrix: too few Gaia XP "
                    "calibration stars, or the NNLS fit failed. Install more Gaia "
                    "XP library groups, lower 'sep_sigma', or pass allow_fallback=True."
                )

            # Optional Q overrides — applied AFTER calibration, because the
            # calibration step auto-derives Q from the condition number.
            if preset.get("q1") is not None:
                self.nb_q1_spin.setValue(float(preset["q1"]))
            if preset.get("q2") is not None:
                self.nb_q2_spin.setValue(float(preset["q2"]))

            # Step 3 — extract.
            self._extract_channels()
            return list(self._last_output_docs)
        finally:
            self._headless = False

    # ── Step 3: extract channels ──────────────────────────────────────────────

    def _extract_channels(self):
        if self._A_matrix is None:
            self._nb_abort("Not Calibrated",
                           "Please run Step 2: Calibrate Mixing Matrix first.",
                           level="warning")
            return

        doc = self.doc_manager.get_active_document()
        if doc is None or doc.image is None:
            self._nb_abort("Error", "No active document.")
            return

        img = doc.image
        if img.ndim != 3 or img.shape[2] != 3:
            self._nb_abort("Error", "Active document must be RGB (3 channels).")
            return

        preset_name = self.nb_preset_combo.currentText()
        l1_key, l2_key = FILTER_PRESETS.get(preset_name, ("Ha", "OIII"))
        if preset_name == FILTER_PRESET_CUSTOM:
            l1_key = self.nb_line1_name.text().strip() or "Line1"
            l2_key = self.nb_line2_name.text().strip() or "Line2"

        img_float = img.astype(np.float32) / (255.0 if img.dtype == np.uint8 else 1.0)

        # Per-channel floor = camera offset + sky pedestal.  Not line emission, so it
        # must not go through pinv(A): the pedestal largely cancels (pseudo-inverse
        # rows are signed) and the negative remainder clips at 0, which is what was
        # zeroing the black point.  Subtract here, add back at the very end.
        ch_min = np.array([float(np.nanmin(img_float[..., c])) for c in range(3)],
                          dtype=np.float32)
        img_float = img_float - ch_min[None, None, :]
        print(f"[NBExtract] per-channel floor subtracted: "
              f"R={ch_min[0]:.5f}  G={ch_min[1]:.5f}  B={ch_min[2]:.5f}")

        _sfcc_status(self, "NBExtract: solving per-pixel mixing system…")
        QApplication.processEvents()

        line1_nnls, line2_nnls = extract_channels_nnls(img_float, self._A_matrix)

        # Build raw priors from A matrix — handles near-tied channels by averaging
        raw1 = raw_prior_from_matrix(img_float, self._A_matrix, 0)
        raw2 = raw_prior_from_matrix(img_float, self._A_matrix, 1)
        # Still need ch1/ch2 for median matching below
        ch1, ch2 = dominant_channels_from_matrix(self._A_matrix)

        def _linear_scale_to_unity(ch: np.ndarray) -> np.ndarray:
            ch = np.asarray(ch, dtype=np.float32)
            ch = np.maximum(ch, 0.0)
            mx = float(ch.max())
            return ch / mx if mx > 1.0 else ch

        # Bring NNLS outputs and raw priors to the same intensity level
        # BEFORE blending so Q operates in a consistent scale.
        if self.nb_stretch_chk.isChecked():
            try:
                from setiastro.saspro.imageops.stretch import stretch_mono_image

                median_1 = float(np.median(img_float[..., ch1]))
                median_2 = float(np.median(img_float[..., ch2]))

                if median_1 > 1e-6:
                    line1_nnls = stretch_mono_image(
                        line1_nnls, target_median=median_1,
                        normalize=False, no_black_clip=True,
                    )
                    raw1 = stretch_mono_image(
                        raw1, target_median=median_1,
                        normalize=False, no_black_clip=True,
                    )
                if median_2 > 1e-6:
                    line2_nnls = stretch_mono_image(
                        line2_nnls, target_median=median_2,
                        normalize=False, no_black_clip=True,
                    )
                    raw2 = stretch_mono_image(
                        raw2, target_median=median_2,
                        normalize=False, no_black_clip=True,
                    )
            except Exception as e:
                print(f"[NBExtract] Median match stretch failed (continuing): {e}")

        # Q was auto-set from condition number at calibration time;
        # user may have overridden in Advanced panel.
        q1 = float(self.nb_q1_spin.value()) if hasattr(self, "nb_q1_spin") else 1.0
        q2 = float(self.nb_q2_spin.value()) if hasattr(self, "nb_q2_spin") else 1.0

        # Add the floor back INSIDE _linear_scale_to_unity — adding it after would
        # push a max-1.0 source to ~1.06 with the guard already past.
        line1_img = _linear_scale_to_unity(
            (q1 * line1_nnls + (1.0 - q1) * raw1).astype(np.float32) + float(ch_min[ch1])
        )
        line2_img = _linear_scale_to_unity(
            (q2 * line2_nnls + (1.0 - q2) * raw2).astype(np.float32) + float(ch_min[ch2])
        )

        meta_base = dict(doc.metadata or {})
        A_list    = self._A_matrix.tolist()
        n_cal     = len(self._nb_star_records)

        meta1 = {**meta_base, "NBExtract_line": l1_key, "NBExtract_preset": preset_name,
                 "NBExtract_center_nm": float(self.nb_center1_spin.value()),
                 "NBExtract_bw_nm": float(self.nb_bw1_spin.value()),
                 "NBExtract_n_cal_stars": n_cal, "NBExtract_A_matrix": A_list,
                 "NBExtract_Q1": q1}
        meta2 = {**meta_base, "NBExtract_line": l2_key, "NBExtract_preset": preset_name,
                 "NBExtract_center_nm": float(self.nb_center2_spin.value()),
                 "NBExtract_bw_nm": float(self.nb_bw2_spin.value()),
                 "NBExtract_n_cal_stars": n_cal, "NBExtract_A_matrix": A_list,
                 "NBExtract_Q2": q2}

        d1 = self._push_new_document(line1_img, meta1, f"{l1_key} (NBExtract)")
        d2 = self._push_new_document(line2_img, meta2, f"{l2_key} (NBExtract)")
        self._last_output_docs = [d for d in (d1, d2) if d is not None]

        k = float(np.linalg.cond(self._A_matrix))
        _sfcc_status(self,
            f"NBExtract complete — '{l1_key}' and '{l2_key}' channels created "
            f"from {n_cal} stars  (Q₁={q1:.2f}  Q₂={q2:.2f}).")

        if not self._headless:
            QMessageBox.information(
                self, "Extraction Complete",
                f"Two new documents created:\n"
                f"  •  {l1_key}  (NBExtract)\n"
                f"  •  {l2_key}  (NBExtract)\n\n"
                f"Calibrated from {n_cal} stars.\n"
                f"Condition number: {k:.2f}\n"
                f"Q₁ = {q1:.2f}   Q₂ = {q2:.2f}  (auto-derived from condition number)\n\n"
                f"Tip: if you see over-subtraction (dark halos/holes), open Advanced\n"
                f"and reduce Q. If under-subtraction (residual bleed), increase Q."
            )
        return list(self._last_output_docs)

    # ── Document / window helpers ─────────────────────────────────────────────

    def closeEvent(self, ev):
        self._A_matrix = None
        self._nb_star_records = []
        self._fallback_mode = False
        self._cleanup()   # call directly instead of relying on super chain
        ev.accept()
        super().closeEvent(ev)

    def _main_window(self):
        p = self.parent()
        while p is not None:
            if hasattr(p, "mdi"):
                return p
            p = p.parent()
        from PyQt6.QtWidgets import QApplication
        for w in QApplication.topLevelWidgets():
            if hasattr(w, "mdi"):
                return w
        return None

    def _push_new_document(self, img_mono: np.ndarray, metadata: dict, title: str):
        dm = self.doc_manager
        mw = self._main_window()

        if dm is None or mw is None or not hasattr(mw, "_spawn_subwindow_for"):
            self._nb_abort("NBExtract",
                f"Cannot create document '{title}':\nDocManager or MainWindow not available.")
            return None

        meta = {**metadata, "display_name": title, "file_path": title,
                "bit_depth": "32-bit floating point", "is_mono": True}
        try:
            doc = dm.create_document(img_mono, metadata=meta, name=title)
            mw._spawn_subwindow_for(doc)
            return doc
        except Exception as e:
            if self._headless:
                raise NBExtractError(f"Failed to create document '{title}': {e}")
            QMessageBox.critical(self, "NBExtract", f"Failed to create document '{title}':\n{e}")
            return None


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def calibrate_matrix_headless(doc_manager, sasp_data_path, *, doc,
                              preset: Optional[dict] = None, parent=None):
    """
    Build a hidden NBExtractDialog and run Fetch -> Calibrate ONLY on `doc`.

    Returns (A, star_records, cond). Raises NBExtractError on failure.

    doc_manager.get_active_document() MUST return `doc` (batch callers pass a shim
    to guarantee this). The dialog is disposed before returning.
    """
    dlg = NBExtractDialog(doc_manager, sasp_data_path, parent=parent)
    try:
        return dlg.calibrate_only(doc=doc, preset=preset)
    finally:
        try:
            dlg.close()
            dlg.deleteLater()
        except Exception:
            pass


def open_nbextract(doc_manager, sasp_data_path: str, parent=None) -> NBExtractDialog:
    """
    Instantiate and show the Narrowband Channel Extractor dialog.

        from setiastro.saspro.nbextract import open_nbextract
        self._nb_dlg = open_nbextract(
            self.doc_manager, self._sasp_data_path, parent=self
        )

    For a non-interactive run from a user script, prefer the command
    registry: ctx.run_command('nbextract', {...}), which dispatches to
    run_nbextract_via_preset() below.
    """
    dlg = NBExtractDialog(
        doc_manager=doc_manager,
        sasp_data_path=sasp_data_path,
        parent=parent,
    )
    dlg.show()
    return dlg


def run_nbextract_via_preset(app=None, doc=None, preset: Optional[dict] = None):
    """
    Headless NBExtract entry point used by the command registry
    (ctx.run_command('nbextract', preset)).

    Builds a hidden NBExtractDialog — so the SFCC star-fetch / photometry /
    WCS machinery is reused verbatim, nothing is duplicated — runs the
    Fetch → Calibrate → Extract pipeline via NBExtractDialog.run_headless(),
    then disposes of the dialog.  Returns the list of created ImageDocuments
    (line1, line2).  Raises NBExtractError (surfaced as CommandError by the
    runner) on any failure that would otherwise be a modal dialog.
    """
    if app is None:
        raise NBExtractError("run_nbextract_via_preset: no application window provided.")

    dm = getattr(app, "doc_manager", None)
    if dm is None:
        raise NBExtractError("run_nbextract_via_preset: app has no doc_manager.")

    data_path = (getattr(app, "_sasp_data_path", None)
                 or getattr(app, "sasp_data_path", None))

    dlg = NBExtractDialog(dm, data_path, parent=app)
    try:
        return dlg.run_headless(doc=doc, preset=preset)
    finally:
        try:
            dlg.close()
            dlg.deleteLater()
        except Exception:
            pass