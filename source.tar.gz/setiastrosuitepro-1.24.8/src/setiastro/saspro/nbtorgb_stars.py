#saspro/nbtorgb_stars.py
from __future__ import annotations
import os
import numpy as np

from PyQt6.QtCore import (
    Qt, QSize, QEvent, QTimer, QPoint, QThread, pyqtSignal, QSettings, QByteArray
)
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
    QFileDialog, QInputDialog, QMessageBox, QGridLayout, QCheckBox, QSizePolicy,
    QSlider
)
from PyQt6.QtGui import (
    QPixmap, QImage, QIcon, QPainter, QPen, QColor, QFont, QFontMetrics,
    QCursor, QMovie
)

# Legacy I/O (same used elsewhere in SASpro)
from setiastro.saspro.legacy.image_manager import load_image as legacy_load_image

from setiastro.saspro.legacy.numba_utils import applySCNR_numba, adjust_saturation_numba
from setiastro.saspro.widgets.themed_buttons import themed_toolbtn
from setiastro.saspro.help_support import make_help_button
from setiastro.saspro.thread_keeper import start_owned_thread

# Optional: your stretch helpers (only used if you’d like to pre-stretch inputs)
# from imageops.stretch import stretch_mono_image, stretch_color_image


class _NBCombineJob(QThread):
    """Preview Combine off the GUI thread: fn(**kwargs) -> dict through
    `ready` ({"error": text} if it raised). No parent: started with
    thread_keeper.start_owned_thread, so the window may close mid-run."""
    ready = pyqtSignal(object)

    def __init__(self, fn, kwargs):
        super().__init__(None)
        self._fn = fn
        self._kwargs = kwargs

    def run(self):
        try:
            out = self._fn(**self._kwargs)
        except Exception as e:
            out = {"error": str(e)}
        self._kwargs = None
        self.ready.emit(out)


class NBtoRGBStars(QWidget):
    """
    SASpro version of NB→RGB Stars:
    - Ha/OIII/SII mono (any subset) and/or OSC stars image
    - Ha↔OIII ratio
    - Optional "star stretch"
    - Live preview on the right (with PPP-style zoom/pan/fit)
    - Push final to a new view via DocManager
    """
    THUMB_ICON_SIZE = QSize(22, 22)  # just for button decoration if icon_path provided

    # Default adjustment values — single source of truth shared by the initial
    # UI build and the Reset button.
    DEFAULT_RATIO        = 30    # Ha:OIII ratio  -> 0.30
    DEFAULT_STAR_STRETCH = True
    DEFAULT_STRETCH      = 500   # stretch factor -> 5.00
    DEFAULT_SAT          = 100   # saturation     -> 1.00x

    def __init__(self, doc_manager=None, parent=None, icon_path: str | None = None):
        super().__init__(parent)
        self.doc_manager = doc_manager
        self.setWindowTitle("NB→RGB Stars")

        if icon_path:
            try:
                self.setWindowIcon(QIcon(icon_path))
            except Exception:
                pass

        # raw inputs (float32 ~[0..1])
        self.ha   : np.ndarray | None = None
        self.oiii : np.ndarray | None = None
        self.sii  : np.ndarray | None = None
        self.osc  : np.ndarray | None = None    # 3-channel stars-only (optional)

        # filenames / metadata (best-effort)
        self._file_ha   = None
        self._file_oiii = None
        self._file_sii  = None
        self._file_osc  = None

        # output
        self.final: np.ndarray | None = None
        self._combine_thread = None      # Preview Combine worker

        # preview pixmap/zoom state
        self._base_pm: QPixmap | None = None
        self._zoom    = 1.0
        self._min_zoom = 0.05
        self._max_zoom = 20.0
        self._panning = False
        self._pan_last: QPoint | None = None
        self._settings = QSettings()
        self._persist_prefix = "nbtorgb_stars"
        self._geom_restored = False
        self._restoring_ui = True  # blocks saves during restore
        self._build_ui()

    def _k(self, key: str) -> str:
        return f"{self._persist_prefix}/{key}"

    def _save_ui_state(self):
        # Don’t save until we have restored once (prevents default geometry overwriting saved one)
        if getattr(self, "_restoring_ui", False) or not getattr(self, "_geom_restored", False):
            return
        try:
            s = self._settings
            s.setValue(self._k("window_geometry"), self.saveGeometry())

            s.setValue(self._k("ratio"), int(self.sld_ratio.value()))
            s.setValue(self._k("star_stretch"), bool(self.chk_star_stretch.isChecked()))
            s.setValue(self._k("stretch"), int(self.sld_stretch.value()))
            s.setValue(self._k("sat"), int(self.sld_sat.value()))

            try:
                s.sync()
            except Exception:
                pass
        except Exception:
            pass

    def _restore_ui_state(self):
        self._restoring_ui = True
        try:
            s = self._settings

            g = s.value(self._k("window_geometry"), None)
            if g is not None:
                self.restoreGeometry(g)

            # restore knobs (block signals so we don’t spam preview)
            r = int(s.value(self._k("ratio"), 30))
            st_on = bool(s.value(self._k("star_stretch"), True, type=bool))
            st = int(s.value(self._k("stretch"), 500))
            sat = int(s.value(self._k("sat"), 100))

            for w in (self.sld_ratio, self.sld_stretch, self.sld_sat, self.chk_star_stretch):
                w.blockSignals(True)
            try:
                self.sld_ratio.setValue(max(0, min(100, r)))
                self.chk_star_stretch.setChecked(bool(st_on))
                self.sld_stretch.setValue(max(0, min(800, st)))
                self.sld_sat.setValue(max(0, min(300, sat)))
            finally:
                for w in (self.sld_ratio, self.sld_stretch, self.sld_sat, self.chk_star_stretch):
                    w.blockSignals(False)

            # refresh labels
            self.lbl_ratio.setText(f"Ha:OIII ratio = {self.sld_ratio.value()/100:.2f}")
            self.lbl_stretch.setText(f"Stretch factor = {self.sld_stretch.value()/100:.2f}")
            self.lbl_sat.setText(f"Saturation = {self.sld_sat.value()/100:.2f}×")

        finally:
            self._restoring_ui = False

    def showEvent(self, e):
        super().showEvent(e)

        if not getattr(self, "_geom_restored", False):
            self._geom_restored = True
            QTimer.singleShot(0, self._restore_ui_state)

        QTimer.singleShot(0, self._center_scrollbars)

    def closeEvent(self, e):
        try:
            self._save_ui_state()
        except Exception:
            pass
        try:
            self._release_memory()
        except Exception:
            pass
        super().closeEvent(e)

    def _release_memory(self):
        """Drop channel arrays and preview pixmap so RAM can be reclaimed on close."""
        if getattr(self, "_memory_released", False):
            return
        self._memory_released = True

        self.ha = self.oiii = self.sii = self.osc = None
        self.final = None
        self._base_pm = None
        self.doc_manager = None
        try:
            self.preview.clear()
        except Exception:
            pass

        try:
            from setiastro.saspro.free_torch_memory import trim_process_memory
            trim_process_memory()
        except Exception:
            pass

    # ---------------- UI ----------------
    def _build_ui(self):
        root = QHBoxLayout(self)

        # -------- left controls
        left = QVBoxLayout()
        left_host = QWidget(self); left_host.setLayout(left); left_host.setFixedWidth(320)

        left.addWidget(QLabel(
            "<b>NB→RGB Stars</b><br>"
            "Load Ha / OIII / (optional SII) and/or OSC stars.<br>"
            "Tune ratio and preview; push to a new view."
        ))

        # Load buttons + status labels
        self.btn_ha   = QPushButton("Load Ha…");   self.btn_ha.clicked.connect(lambda: self._load_channel("Ha"))
        self.btn_oiii = QPushButton("Load OIII…"); self.btn_oiii.clicked.connect(lambda: self._load_channel("OIII"))
        self.btn_sii  = QPushButton("Load SII (optional)…");  self.btn_sii.clicked.connect(lambda: self._load_channel("SII"))
        self.btn_osc  = QPushButton("Load OSC stars (optional)…"); self.btn_osc.clicked.connect(lambda: self._load_channel("OSC"))

        self.lbl_ha   = QLabel("No Ha loaded.")
        self.lbl_oiii = QLabel("No OIII loaded.")
        self.lbl_sii  = QLabel("No SII loaded.")
        self.lbl_osc  = QLabel("No OSC stars loaded.")

        for lab in (self.lbl_ha, self.lbl_oiii, self.lbl_sii, self.lbl_osc):
            lab.setWordWrap(True); lab.setStyleSheet("color:#888; margin-left:8px;")

        for btn, lab in ((self.btn_ha, self.lbl_ha),
                         (self.btn_oiii, self.lbl_oiii),
                         (self.btn_sii, self.lbl_sii),
                         (self.btn_osc, self.lbl_osc)):
            left.addWidget(btn); left.addWidget(lab)

        # Ratio (Ha to OIII)
        row = QHBoxLayout()
        self.lbl_ratio = QLabel("Ha:OIII ratio = 0.30")
        self.sld_ratio = QSlider(Qt.Orientation.Horizontal); self.sld_ratio.setRange(0, 100); self.sld_ratio.setValue(self.DEFAULT_RATIO)
        self.sld_ratio.valueChanged.connect(lambda v: self.lbl_ratio.setText(f"Ha:OIII ratio = {v/100:.2f}"))
        row.addWidget(self.lbl_ratio); left.addLayout(row)
        left.addWidget(self.sld_ratio)

        # Star Stretch
        self.chk_star_stretch = QCheckBox("Enable star stretch"); self.chk_star_stretch.setChecked(self.DEFAULT_STAR_STRETCH)
        left.addWidget(self.chk_star_stretch)

        row2 = QHBoxLayout()
        self.lbl_stretch = QLabel("Stretch factor = 5.00")
        self.sld_stretch = QSlider(Qt.Orientation.Horizontal); self.sld_stretch.setRange(0, 800); self.sld_stretch.setValue(self.DEFAULT_STRETCH)
        self.sld_stretch.valueChanged.connect(lambda v: self.lbl_stretch.setText(f"Stretch factor = {v/100:.2f}"))
        row2.addWidget(self.lbl_stretch); left.addLayout(row2)
        left.addWidget(self.sld_stretch)

        row3 = QHBoxLayout()
        self.lbl_sat = QLabel("Saturation = 1.00×")
        self.sld_sat = QSlider(Qt.Orientation.Horizontal)
        self.sld_sat.setRange(0, 300)         # 0.00× … 3.00×
        self.sld_sat.setValue(self.DEFAULT_SAT)            # 1.00× by default
        self.sld_sat.valueChanged.connect(lambda v: self.lbl_sat.setText(f"Saturation = {v/100:.2f}×"))
        row3.addWidget(self.lbl_sat)
        left.addLayout(row3)
        left.addWidget(self.sld_sat)

        # Actions
        act = QHBoxLayout()
        self.btn_preview = QPushButton("Preview Combine"); self.btn_preview.clicked.connect(self._preview_combine)
        self.btn_push = QPushButton("Push Final to New View"); self.btn_push.clicked.connect(self._push_final)
        act.addWidget(self.btn_preview); act.addWidget(self.btn_push)
        left.addLayout(act)

        from setiastro.saspro.resources import get_resources

        clr_row = QHBoxLayout()
        self.btn_reset = QPushButton("Reset Adjustments")
        self.btn_reset.setToolTip("Restore ratio, star stretch, stretch factor and\n"
                                  "saturation to their defaults (loaded images are kept).")
        self.btn_reset.clicked.connect(self._reset_adjustments)
        self.btn_clear = QPushButton("Clear Inputs")
        self.btn_clear.clicked.connect(self._clear_inputs)
        clr_row.addWidget(self.btn_reset)
        clr_row.addWidget(self.btn_clear)
        left.addLayout(clr_row)

        # Spinner (resource-based)
        self.spinner = QLabel(self)
        self.spinner.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.spinner.hide()

        gif_path = os.path.normpath(get_resources().SPINNER_GIF)
        self.spinner_movie = QMovie(gif_path, parent=self)   # keep ref on self
        self.spinner_movie.setCacheMode(QMovie.CacheMode.CacheAll)
        self.spinner.setMovie(self.spinner_movie)

        left.addWidget(self.spinner)

        left.addStretch(1)
        root.addWidget(left_host, 0)

        # -------- right: preview (zoom/pan like PPP)
        right = QVBoxLayout()

        tools = QHBoxLayout()

        self.btn_zoom_in  = themed_toolbtn("zoom-in", "Zoom In")
        self.btn_zoom_out = themed_toolbtn("zoom-out", "Zoom Out")
        self.btn_fit      = themed_toolbtn("zoom-fit-best", "Fit to Preview")

        self.btn_zoom_in.clicked.connect(lambda: self._zoom_at(1.25))
        self.btn_zoom_out.clicked.connect(lambda: self._zoom_at(0.8))
        self.btn_fit.clicked.connect(self._fit_to_preview)

        tools.addWidget(self.btn_zoom_in)
        tools.addWidget(self.btn_zoom_out)
        tools.addWidget(self.btn_fit)
        tools.addStretch(1)
        self.btn_doc_help = make_help_button("nb_rgb_stars", self)
        tools.addWidget(self.btn_doc_help)
        right.addLayout(tools)


        self.scroll = QScrollArea(self); self.scroll.setWidgetResizable(True)
        self.scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview = QLabel(alignment=Qt.AlignmentFlag.AlignCenter)
        self.scroll.setWidget(self.preview)
        self.preview.setMouseTracking(True)

        # Intercept wheel everywhere to prevent scroll while zooming; pan via drag
        for obj in (self.preview, self.scroll, self.scroll.viewport(),
                    self.scroll.horizontalScrollBar(), self.scroll.verticalScrollBar()):
            obj.installEventFilter(self)

        right.addWidget(self.scroll, 1)
        self.status = QLabel(""); right.addWidget(self.status, 0)

        right_host = QWidget(self); right_host.setLayout(right)
        root.addWidget(right_host, 1)
        # --- persist changes (don’t spam writes while dragging) ---
        self.chk_star_stretch.toggled.connect(lambda *_: self._save_ui_state())
        self.sld_ratio.sliderReleased.connect(lambda: self._save_ui_state())
        self.sld_stretch.sliderReleased.connect(lambda: self._save_ui_state())
        self.sld_sat.sliderReleased.connect(lambda: self._save_ui_state())

        # also save if user types / keyboard nudges (no sliderReleased in that case)
        self.sld_ratio.valueChanged.connect(lambda *_: None)  # already used for label
        self.sld_stretch.valueChanged.connect(lambda *_: None)
        self.sld_sat.valueChanged.connect(lambda *_: None)
        self.setLayout(root)
        self.setMinimumSize(980, 640)

    def _spinner_on(self, text: str = "Working…"):
        # optional: disable button to prevent re-entry
        try:
            self.btn_preview.setEnabled(False)
            self.btn_push.setEnabled(False)
            self.btn_clear.setEnabled(False)
            self.btn_reset.setEnabled(False)
        except Exception:
            pass

        try:
            self.status.setText(text)
        except Exception:
            pass

        if getattr(self, "spinner", None) is None or getattr(self, "spinner_movie", None) is None:
            return

        self.spinner.show()

        # Only start if not already running
        if self.spinner_movie.state() != QMovie.MovieState.Running:
            self.spinner_movie.start()

        # Force a paint so the spinner actually appears before heavy work
        QTimer.singleShot(0, lambda: None)


    def _spinner_off(self):
        try:
            self.btn_preview.setEnabled(True)
            self.btn_push.setEnabled(True)
            self.btn_clear.setEnabled(True)
            self.btn_reset.setEnabled(True)
        except Exception:
            pass

        if getattr(self, "spinner", None) is None or getattr(self, "spinner_movie", None) is None:
            return

        # Stop first, then hide
        try:
            self.spinner_movie.stop()
        except Exception:
            pass
        self.spinner.hide()


    # ---------- file/view loading ----------
    def _set_status_label(self, which: str, text: str | None):
        lab = getattr(self, f"lbl_{which.lower()}")
        if text:
            lab.setText(text); lab.setStyleSheet("color:#2a7; font-weight:600; margin-left:8px;")
        else:
            lab.setText(f"No {which} loaded."); lab.setStyleSheet("color:#888; margin-left:8px;")

    def _load_channel(self, which: str):
        src, ok = QInputDialog.getItem(self, f"Load {which}", "Source:", ["From View", "From File"], 0, False)
        if not ok: return

        out = self._load_from_view(which) if src == "From View" else self._load_from_file(which)
        if out is None: return
        img, header, bit_depth, is_mono, path, label = out

        # Normalize to floats in [0,1]; collapse mono to 2D; ensure OSC is RGB
        if which in ("Ha","OIII","SII"):
            if img.ndim == 3: img = img[...,0]
            setattr(self, which.lower(), self._as_float01(img))
        else:  # OSC
            # Optimization: Store mono OSC as-is (2D) to save memory
            # The combine step will handle expansion.
            if img.ndim == 3 and img.shape[2] == 1:
                img = img[..., 0]
            setattr(self, which.lower(), self._as_float01(img))

        setattr(self, f"_file_{which.lower()}", path)
        self._set_status_label(which, label)
        self.status.setText(f"{which} loaded ({'mono' if img.ndim==2 else 'RGB'}) shape={img.shape}")

    def _load_from_view(self, which):
        views = self._list_open_views()
        if not views:
            QMessageBox.warning(self, "No Views", "No open image views found.")
            return None

        labels = [lab for lab, _ in views]
        choice, ok = QInputDialog.getItem(self, f"Select View for {which}", "Choose a view:", labels, 0, False)
        if not ok or not choice:
            return None

        sub = dict(views)[choice]          # QMdiSubWindow
        view = sub.widget()                # ImageSubWindow
        doc = getattr(view, "document", None)

        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.warning(self, "Empty View", "Selected view has no image.")
            return None

        img = doc.image
        meta = getattr(doc, "metadata", {}) or {}
        header = meta.get("original_header", None)
        bit_depth = meta.get("bit_depth", "Unknown")
        is_mono = (img.ndim == 2) or (img.ndim == 3 and img.shape[2] == 1)
        path = meta.get("file_path", None)
        return img, header, bit_depth, is_mono, path, f"From View: {choice}"

    def _load_from_file(self, which):
        filt = "Images (*.png *.tif *.tiff *.fits *.fit *.xisf)"
        path, _ = QFileDialog.getOpenFileName(self, f"Select {which} File", "", filt)
        if not path: return None
        img, header, bit_depth, is_mono = legacy_load_image(path)
        if img is None:
            QMessageBox.critical(self, "Load Error", f"Could not load {os.path.basename(path)}"); return None
        return img, header, bit_depth, is_mono, path, f"From File: {os.path.basename(path)}"

    # ---------- combine / preview ----------
    def _preview_combine(self):
        if (self.osc is None) and not (self.ha is not None and self.oiii is not None):
            QMessageBox.warning(self, "Missing Images", "Load OSC, or Ha+OIII (SII optional).")
            return

        self._spinner_on("Combining…")
        thr = _NBCombineJob(self._combine_job, dict(
            ha=self.ha, oiii=self.oiii, sii=self.sii, osc=self.osc,
            ratio=self.sld_ratio.value() / 100.0,
            star_stretch=self.chk_star_stretch.isChecked(),
            stretch_k=self.sld_stretch.value() / 100.0,
            sat_factor=self.sld_sat.value() / 100.0))
        thr.ready.connect(self._on_combine_ready)
        self._combine_thread = thr
        start_owned_thread(thr)

    def _on_combine_ready(self, res: dict):
        self._combine_thread = None
        if getattr(self, "_memory_released", False):
            return                       # closed while it ran
        try:
            if "error" in res:
                QMessageBox.critical(self, "Combine Error", res["error"])
                return
            self.final = res["final"]
            self._set_preview_image(res["qimg"])
            self.status.setText("Preview updated.")
        finally:
            self._spinner_off()

    @classmethod
    def _combine_job(cls, ha, oiii, sii, osc, ratio, star_stretch, stretch_k, sat_factor):
        """Worker: the whole Preview Combine on the captured inputs. Returns
        the final image (what Push sends) and its preview QImage."""
        # 1) combine (no SCNR here)
        rgb = cls._combine_arrays(ha, oiii, sii, osc, ratio, star_stretch, stretch_k)

        # 2) ensure float32 & contiguous for numba (no copy when it already is)
        rgb = np.ascontiguousarray(rgb, dtype=np.float32)

        # 3) SCNR (numba)
        rgb = applySCNR_numba(rgb)

        # 4) Saturation (numba)
        if abs(sat_factor - 1.0) > 1e-3:
            rgb = adjust_saturation_numba(rgb, sat_factor)

        # rgb is the kernel's fresh output: clip it in place
        final = np.clip(rgb, 0.0, 1.0, out=rgb)
        return {"final": final, "qimg": cls._to_qimage(final)}

    def _combine_nb_rgb(self, ratio: float, star_stretch: bool, stretch_k: float) -> np.ndarray:
        return self._combine_arrays(self.ha, self.oiii, self.sii, self.osc,
                                    ratio, star_stretch, stretch_k)

    @staticmethod
    def _combine_arrays(ha_in, oiii_in, sii_in, osc, ratio: float, star_stretch: bool,
                        stretch_k: float) -> np.ndarray:
        """
        Combine to RGB:
        - If OSC present: use channels from OSC, optionally blend Ha/SII/OO into them.
        - Else NB-only: R ~ 0.5*(Ha+SII), G ~ mix(Ha, OIII) via ratio, B ~ OIII.
        Shapes must match.
        """
        # Ensure shapes
        shapes = [x.shape[:2] for x in (ha_in, oiii_in, sii_in) if x is not None]
        if osc is not None:
            shapes.append(osc.shape[:2])
        if shapes and len(set(shapes)) != 1:
            raise ValueError(f"Channel sizes differ: {set(shapes)}")

        if osc is not None:
            if osc.ndim == 2:
                r = osc; g = osc; b = osc
            elif osc.ndim == 3 and osc.shape[2] >= 3:
                r = osc[...,0]; g = osc[...,1]; b = osc[...,2]
            else:
                 # fallback for unexpected shapes (e.g. 3D but 1-channel)
                 r = osc.squeeze(); g = r; b = r

            sii = sii_in if sii_in is not None else r
            ha  = ha_in  if ha_in  is not None else r
            oiii= oiii_in if oiii_in is not None else b

            r_out = 0.5*r + 0.5*sii
            g_out = ratio*ha + (1.0 - ratio)*g
            b_out = oiii
        else:
            if ha_in is None or oiii_in is None:
                raise ValueError("Need Ha and OIII if no OSC image is provided.")
            ha = ha_in
            sii = sii_in if sii_in is not None else ha
            oiii = oiii_in
            r_out = 0.5*ha + 0.5*sii
            g_out = ratio*ha + (1.0 - ratio)*oiii
            b_out = oiii

        # In place from here on: the same float32 operations, fewer full-size copies.
        rgb = np.stack([r_out, g_out, b_out], axis=2).astype(np.float32, copy=False)
        np.clip(rgb, 0, 1, out=rgb)

        if star_stretch:
            # Simple non-linear boost; bounded and monotonic
            # ((3^k)*x) / ((3^k - 1)*x + 1)
            t = 3.0 ** float(stretch_k)
            den = (t - 1.0)*rgb
            den += 1.0
            rgb *= t
            rgb /= den
            np.clip(rgb, 0, 1, out=rgb)

        return rgb


    # ---------- preview helpers + zoom/pan ----------
    def _set_preview_image(self, qimg: QImage):
        new_pm = QPixmap.fromImage(qimg)
        old_pm = self._base_pm
        self._base_pm = new_pm

        # First preview, or the inputs changed size: fit the whole image (as PPP does).
        if old_pm is None or old_pm.size() != new_pm.size():
            self._fit_to_preview()
            return

        # Re-combine of the same inputs (slider changes): keep the user's zoom and pan.
        # Same zoom on a same-size image gives the same scroll range, so the
        # scrollbar positions carry over as they are.
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()
        h, v = hbar.value(), vbar.value()
        self._update_preview_pixmap()
        hbar.setValue(h)
        vbar.setValue(v)

    def _update_preview_pixmap(self):
        if self._base_pm is None: return
        scaled = self._base_pm.scaled(
            self._base_pm.size() * self._zoom,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        self.preview.setPixmap(scaled)
        self.preview.resize(scaled.size())

    def _set_zoom(self, new_zoom: float):
        self._zoom = max(self._min_zoom, min(self._max_zoom, new_zoom))
        self._update_preview_pixmap()

    def _zoom_at(self, factor: float = 1.25, anchor_vp: QPoint | None = None):
        if self._base_pm is None: return

        old_zoom = self._zoom
        new_zoom = max(self._min_zoom, min(self._max_zoom, old_zoom * factor))
        ratio = new_zoom / max(1e-6, old_zoom)

        vp = self.scroll.viewport()
        if anchor_vp is None:
            anchor_vp = QPoint(vp.width() // 2, vp.height() // 2)  # center of view

        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()

        content_x = hbar.value() + anchor_vp.x()
        content_y = vbar.value() + anchor_vp.y()

        self._set_zoom(new_zoom)

        if self.preview.width() <= vp.width():
            hbar.setValue((hbar.maximum() + hbar.minimum()) // 2)
        else:
            new_h = int(content_x * ratio - anchor_vp.x())
            hbar.setValue(max(hbar.minimum(), min(hbar.maximum(), new_h)))

        if self.preview.height() <= vp.height():
            vbar.setValue((vbar.maximum() + vbar.minimum()) // 2)
        else:
            new_v = int(content_y * ratio - anchor_vp.y())
            vbar.setValue(max(vbar.minimum(), min(vbar.maximum(), new_v)))

    def _fit_to_preview(self):
        if self._base_pm is None: return
        vp = self.scroll.viewport().size()
        pm = self._base_pm.size()
        if pm.width() == 0 or pm.height() == 0: return
        k = min(vp.width() / pm.width(), vp.height() / pm.height())
        self._set_zoom(max(self._min_zoom, min(self._max_zoom, k)))
        self._center_scrollbars()

    def _center_scrollbars(self):
        h = self.scroll.horizontalScrollBar()
        v = self.scroll.verticalScrollBar()
        h.setValue((h.maximum() + h.minimum()) // 2)
        v.setValue((v.maximum() + v.minimum()) // 2)

    # ---------- utilities ----------
    def _clear_inputs(self):
        self.ha = self.oiii = self.sii = self.osc = None
        self._file_ha = self._file_oiii = self._file_sii = self._file_osc = None
        self.final = None
        self.preview.clear(); self._base_pm = None
        for which in ("Ha","OIII","SII","OSC"):
            self._set_status_label(which, None)
        self.status.setText("Cleared inputs.")

    def _reset_adjustments(self):
        """Restore the ratio / star-stretch / stretch / saturation controls to defaults.

        Loaded images are left untouched (use "Clear Inputs" for those). If a preview
        has already been generated, it is re-combined so it reflects the reset values.
        """
        widgets = (self.sld_ratio, self.sld_stretch, self.sld_sat, self.chk_star_stretch)
        for w in widgets:
            w.blockSignals(True)
        try:
            self.sld_ratio.setValue(self.DEFAULT_RATIO)
            self.chk_star_stretch.setChecked(self.DEFAULT_STAR_STRETCH)
            self.sld_stretch.setValue(self.DEFAULT_STRETCH)
            self.sld_sat.setValue(self.DEFAULT_SAT)
        finally:
            for w in widgets:
                w.blockSignals(False)

        # Signals were blocked, so refresh the value labels ourselves.
        self.lbl_ratio.setText(f"Ha:OIII ratio = {self.sld_ratio.value()/100:.2f}")
        self.lbl_stretch.setText(f"Stretch factor = {self.sld_stretch.value()/100:.2f}")
        self.lbl_sat.setText(f"Saturation = {self.sld_sat.value()/100:.2f}×")

        self._save_ui_state()

        # Only re-run the combine if the user has already produced a preview;
        # otherwise just report, so Reset never kicks off work unprompted.
        if self.final is not None:
            self._preview_combine()
        else:
            self.status.setText("Adjustments reset to defaults.")

    @staticmethod
    def _as_float01(arr):
        a = np.asarray(arr)
        if a.dtype == np.uint8:  return a.astype(np.float32)/255.0
        if a.dtype == np.uint16: return a.astype(np.float32)/65535.0
        return np.clip(a.astype(np.float32), 0.0, 1.0)

    @staticmethod
    def _to_qimage(arr):
        a = np.clip(arr, 0, 1)
        if a.ndim == 2:
            u = (a * 255).astype(np.uint8); h, w = u.shape
            return QImage(u.data, w, h, w, QImage.Format.Format_Grayscale8).copy()
        if a.ndim == 3 and a.shape[2] == 3:
            u = (a * 255).astype(np.uint8); h, w, _ = u.shape
            return QImage(u.data, w, h, w*3, QImage.Format.Format_RGB888).copy()
        raise ValueError(f"Unexpected image shape: {a.shape}")

    def _find_main_window(self):
        from PyQt6.QtWidgets import QMainWindow, QApplication

        # 1) walk parents first
        w = self
        while w is not None:
            if isinstance(w, QMainWindow):
                return w
            w = w.parentWidget()

        app = QApplication.instance()
        if app is None:
            return None

        # 2) prefer active window if it's a QMainWindow
        aw = app.activeWindow()
        if isinstance(aw, QMainWindow):
            return aw

        # 3) prefer one that has an mdi attribute (your real main window does)
        for tlw in app.topLevelWidgets():
            if isinstance(tlw, QMainWindow) and hasattr(tlw, "mdi"):
                return tlw

        # 4) last resort: any QMainWindow
        for tlw in app.topLevelWidgets():
            if isinstance(tlw, QMainWindow):
                return tlw

        return None

    def _list_open_views(self):
        mw = self._find_main_window()
        if mw is None:
            return []

        try:
            from setiastro.saspro.subwindow import ImageSubWindow
        except Exception:
            ImageSubWindow = None

        out = []

        # ── 1) Best source: MDI subWindowList() ─────────────────────────────
        mdi = getattr(mw, "mdi", None)
        if mdi is not None:
            try:
                for sub in mdi.subWindowList():
                    try:
                        view = sub.widget()
                        if ImageSubWindow is not None and not isinstance(view, ImageSubWindow):
                            continue

                        doc = getattr(view, "document", None)
                        img = getattr(doc, "image", None) if doc is not None else None
                        if img is None:
                            continue

                        title = ""
                        try:
                            title = (sub.windowTitle() or "").strip()
                        except Exception:
                            title = ""
                        if not title:
                            try:
                                title = (view._effective_title() or "").strip()
                            except Exception:
                                title = ""
                        if not title:
                            try:
                                title = (doc.display_name() or "").strip()
                            except Exception:
                                title = "Untitled"

                        out.append((title, sub))
                    except Exception:
                        continue
            except Exception:
                pass

        # ── 2) Fallback: registry (if you have it) ──────────────────────────
        if not out and ImageSubWindow is not None:
            try:
                for view in list(ImageSubWindow._registry.values()):
                    try:
                        doc = getattr(view, "document", None)
                        img = getattr(doc, "image", None) if doc is not None else None
                        if img is None:
                            continue

                        sub = None
                        try:
                            sub = view._mdi_subwindow()
                        except Exception:
                            sub = None
                        if sub is None:
                            continue

                        title = ""
                        try:
                            title = (sub.windowTitle() or "").strip()
                        except Exception:
                            title = ""
                        if not title:
                            try:
                                title = (view._effective_title() or "").strip()
                            except Exception:
                                title = ""
                        if not title:
                            try:
                                title = (doc.display_name() or "").strip()
                            except Exception:
                                title = "Untitled"

                        out.append((title, sub))
                    except Exception:
                        continue
            except Exception:
                pass

        # De-dupe titles
        seen = set()
        uniq = []
        for t, sub in out:
            tt = str(t)
            if tt in seen:
                i = 2
                cand = f"{tt} ({i})"
                while cand in seen:
                    i += 1
                    cand = f"{tt} ({i})"
                tt = cand
            seen.add(tt)
            uniq.append((tt, sub))

        return uniq


    def _push_final(self):
        if self.final is None:
            QMessageBox.warning(self, "No Image", "Preview first, then push."); return
        mw = self._find_main_window()
        dm = getattr(mw, "docman", None)
        if not mw or not dm:
            QMessageBox.critical(self, "UI", "Main window or DocManager not available."); return
        title = "NB→RGB Stars"
        try:
            if hasattr(dm, "open_array"):
                doc = dm.open_array(self.final, metadata={"is_mono": False}, title=title)
            elif hasattr(dm, "create_document"):
                doc = dm.create_document(image=self.final, metadata={"is_mono": False}, name=title)
            else:
                raise RuntimeError("DocManager lacks open_array/create_document")
            if hasattr(mw, "_spawn_subwindow_for"):
                mw._spawn_subwindow_for(doc)
            else:
                from setiastro.saspro.subwindow import ImageSubWindow
                sw = ImageSubWindow(doc, parent=mw); sw.setWindowTitle(title); sw.show()
            self.status.setText("Opened final composite in a new view.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open new view:\n{e}")

    # ---------- event filter (zoom/pan like PPP) ----------
    def eventFilter(self, obj, ev):
        # Ctrl+wheel zoom at mouse (prevent scrolling); wheel without Ctrl: eat it (no scroll)
        # Wheel zoom at mouse (plain wheel + Ctrl+wheel); prevent scrolling.
        if ev.type() == QEvent.Type.Wheel and (
            obj is self.preview
            or obj is self.scroll
            or obj is self.scroll.viewport()
            or obj is self.scroll.horizontalScrollBar()
            or obj is self.scroll.verticalScrollBar()
        ):
            ev.accept()

            # safer: compute anchor in viewport coords via global position
            try:
                anchor_vp = self.scroll.viewport().mapFromGlobal(ev.globalPosition().toPoint())
            except Exception:
                vp = self.scroll.viewport()
                anchor_vp = QPoint(vp.width() // 2, vp.height() // 2)

            dy = ev.pixelDelta().y()

            if dy != 0:
                abs_dy = abs(dy)
                ctrl_down = bool(ev.modifiers() & Qt.KeyboardModifier.ControlModifier)

                if abs_dy <= 3:
                    base_factor = 1.012 if ctrl_down else 1.010
                elif abs_dy <= 10:
                    base_factor = 1.025 if ctrl_down else 1.020
                else:
                    base_factor = 1.040 if ctrl_down else 1.030

                factor = base_factor if dy > 0 else 1.0 / base_factor
            else:
                dy = ev.angleDelta().y()
                if dy == 0:
                    return True

                ctrl_down = bool(ev.modifiers() & Qt.KeyboardModifier.ControlModifier)
                step = 1.25 if ctrl_down else 1.15
                factor = step if dy > 0 else 1.0 / step

            self._zoom_at(factor, anchor_vp)
            return True

        # click-drag pan on viewport
        if obj is self.scroll.viewport():
            if ev.type() == QEvent.Type.MouseButtonPress and ev.button() == Qt.MouseButton.LeftButton:
                self._panning = True
                self._pan_last = ev.position().toPoint()
                self.scroll.viewport().setCursor(QCursor(Qt.CursorShape.ClosedHandCursor))
                return True
            if ev.type() == QEvent.Type.MouseMove and self._panning:
                cur = ev.position().toPoint()
                delta = cur - (self._pan_last or cur)
                self._pan_last = cur
                h = self.scroll.horizontalScrollBar()
                v = self.scroll.verticalScrollBar()
                h.setValue(h.value() - delta.x())
                v.setValue(v.value() - delta.y())
                return True
            if ev.type() == QEvent.Type.MouseButtonRelease and ev.button() == Qt.MouseButton.LeftButton:
                self._panning = False
                self._pan_last = None
                self.scroll.viewport().setCursor(QCursor(Qt.CursorShape.ArrowCursor))
                return True

        return super().eventFilter(obj, ev)