# sfcc.py
# SASpro Spectral Flux Color Calibration (SFCC) — "current view" integration
# - Expects a "view adapter" you provide that exposes:
#       get_rgb_image() -> np.ndarray (H,W,3), uint8 or float32 in [0,1]
#       get_metadata() -> dict  (optional; may return {})
#       get_header() -> astropy.io.fits.Header or dict (optional but needed for WCS features)
#       set_rgb_image(img: np.ndarray, metadata: dict | None = None, step_name: str | None = None) -> None
#   If your adapter names differ, tweak _get_img_meta/_get_header/_push_image below (they already try a few fallbacks).
#
# - Call open_sfcc(view_adapter, sasp_data_path) to show the dialog.
# ══════════════════════════════════════════════════════════════════════════════
# DR4 MIGRATION — SFCC ARCHITECTURE ROADMAP
# ══════════════════════════════════════════════════════════════════════════════
#
# BACKGROUND: WHY THE CURRENT APPROACH HAS A CEILING
# ─────────────────────────────────────────────────────
# The current SFCC pipeline (SPCC-style) works as follows:
#
#   S_expected = ∫ flux_star(λ) × T_filter(λ) × QE_sensor(λ) dλ
#
# We then compare S_expected to what the camera actually measured to derive
# a per-channel color correction. The filter transmission curves (Antlia,
# Chroma, Baader etc.) are generally trustworthy — manufacturers measure
# these interferometrically and the curves are physically meaningful.
#
# The sensor QE curves are a different story. Manufacturer QE curves are:
#   - Measured at room temperature; your sensor runs at -10°C to -20°C
#   - Measured with a bare die; your sensor has an AR coating, cover glass,
#     microlenses, and a specific electronics chain
#   - Published as marketing material, not calibration data
#   - Systematically optimistic in the red (Sony IMX sensors especially)
#   - Completely ignorant of your specific telescope's optical throughput,
#     secondary obstruction, mirror coatings, and field flattener transmission
#   - Ignorant of your atmosphere (water vapor, aerosols, airmass)
#
# This is exactly the same problem we hit with PixInsight's DBExtract for
# narrowband work: it presumed it knew the filter/sensor response, and the
# presumption was wrong enough to produce bad results. We abandoned DBExtract
# and built NBExtract, which solves the mixing matrix purely from the data
# using Gaia XP spectra as ground truth. The result was dramatically better.
#
# The 3×3 color matrix attempt in SFCC hit the same wall — with DR3 data,
# per-star photometric scatter dominated over the real cross-channel signal,
# so the matrix faithfully fit the noise instead of the signal. The scalar/
# quadratic model works because it averages noise across hundreds of stars.
# The matrix cannot average in the same way.
#
# ─────────────────────────────────────────────────────────────────────────────
# THE DR4 ARCHITECTURE: LET THE STARS SOLVE THE SENSOR
# ─────────────────────────────────────────────────────
# Gaia DR4 changes the situation in two ways:
#   1. ~10× more XP sources per field (G ≲ 17.5 vs current G ≲ 15.5)
#   2. Improved XP spectral calibration, especially in crowded fields
#      and for faint/cool stars where DR3 had systematic biases
#
# With that density, we can do what Gaia does internally to calibrate its
# own photometric system: recover the effective system throughput empirically
# from the data itself, with no presumption about QE.
#
# The formulation is a blind sensor characterization:
#
#   For each star i and channel c:
#
#     measured_c(i) = k_c × ∫ flux_star_i(λ) × T_filter_c(λ) × R(λ) dλ
#
#   where:
#     - flux_star_i(λ)  is the Gaia XP calibrated spectrum (known)
#     - T_filter_c(λ)   is the filter transmission curve (known, reliable)
#     - R(λ)            is the unknown effective system response:
#                         QE(λ) × atmosphere(λ) × optics(λ) × everything_else
#     - k_c             is an unknown per-channel scalar gain
#
# We want to solve for R(λ) — the true system response — using the stars
# as calibrators. This is identical to what Gaia's internal photometric
# calibration pipeline does (see Carrasco et al. 2021, Riello et al. 2021).
#
# In practice R(λ) is parameterized as a smooth function (e.g. a low-order
# polynomial or a set of basis splines on the 350–1000 nm range). The system
# of equations across all stars and all channels becomes:
#
#   measured_c(i) / ∫ flux_star_i(λ) × T_filter_c(λ) dλ  =  k_c × <R>_c(i)
#
# where <R>_c(i) is the flux-weighted mean of R(λ) through channel c for
# star i. With enough stars of diverse spectral types spanning the full
# color range (O through M), the system is well-determined.
#
# The color correction then becomes:
#
#   corrected_c(i) = measured_c(i) / (k_c × <R>_c(i) / <R>_c(ref))
#
# where ref is the white reference star (e.g. G2V). No QE curve anywhere.
#
# ─────────────────────────────────────────────────────────────────────────────
# WHAT NEEDS TO CHANGE IN THE CODE
# ─────────────────────────────────────────────────────────────────────────────
#
# 1. QUERY: update gaiadr3 → gaiadr4 in _query_gaia_sources_in_field()
#    - mag_limit: 15.5 → 16.5 (verify column names haven't changed)
#    - has_xp_continuous column: verify still exists / same semantics
#
# 2. UI: remove the Sensor (QE) combobox from the dialog entirely.
#    The sensor is no longer an input — it is a *solved output*.
#    Filter curves remain as inputs (R/G/B + LP/cut filters).
#
# 3. NEW: _solve_system_response() method
#    Inputs:  enriched star list (measured flux per channel per star)
#             filter transmission curves T_R, T_G, T_B on wl_grid
#             Gaia XP spectra (already cached in gaia_xp_cache.sqlite)
#    Output:  R(λ) — effective system response on wl_grid
#             per-channel scalar gains k_R, k_G, k_B
#
#    Implementation sketch:
#      - Parameterize R(λ) as a degree-6 polynomial (or 8-knot B-spline)
#        constrained to be non-negative and bounded to [0.05, 1.0]
#      - Build the linear system: for each star i and channel c,
#          measured_c(i) = k_c × ∫ flux_i(λ) × T_c(λ) × R(λ) dλ
#      - Solve via non-negative least squares (scipy.optimize.nnls)
#        or bounded L-BFGS-B with the polynomial coefficients as free params
#      - Sigma clip on per-star residuals (3σ) and re-solve
#      - Require ≥ 50 stars spanning B-V range [-0.3, 1.8] for stable solution
#
# 4. REPLACE run_spcc() Step A/B/F with the new pipeline:
#      Step A: integrate Gaia XP spectra × T_filter (no QE)  [unchanged]
#      Step B: solve R(λ) from star residuals               [new]
#      Step C: photometry                                    [unchanged]
#      Step F: apply correction using solved R(λ)            [updated]
#
# 5. DIAGNOSTICS: add a "Solved System Response" plot showing R(λ) alongside
#    the manufacturer QE curve (for comparison / validation). Users will
#    immediately see how wrong the manufacturer curve was for their setup.
#    This is a compelling visual that justifies dropping QE curves entirely.
#
# 6. PERSISTENCE: cache the solved R(λ) per (telescope, camera, filter_set,
#    date) in QSettings or a sidecar file. Night-to-night variation is mostly
#    atmosphere — the optics/sensor component is stable. This lets the user
#    build up a calibrated system response over time, improving with each run.
#
# ─────────────────────────────────────────────────────────────────────────────
# REFERENCES
# ─────────────────────────────────────────────────────────────────────────────
# Gaia photometric calibration methodology (the approach we are replicating):
#   Carrasco et al. 2021 — "The Gaia photometric science alerts programme"
#   Riello et al. 2021   — "Gaia Early Data Release 3: Photometric content
#                           and validation" (A&A 649, A3)
#   Fabricius et al. 2021 — "Gaia Early Data Release 3: Catalogue validation"
#
# The key insight from Riello et al.: the internal calibration solves for
# both the mean instrument response AND per-observation corrections
# simultaneously using an overconstrained system of calibrator stars.
# With DR4 XP density (~500-2000 stars per typical astrophotography field)
# we have sufficient overconstrained data to do the same thing.
#
# ══════════════════════════════════════════════════════════════════════════════

from __future__ import annotations

from setiastro.saspro.main_helpers import non_blocking_sleep

import os
import re
import cv2
import math
import time
from datetime import datetime
from typing import List, Tuple, Optional, Dict

import numpy as np

try:
    _trapz = np.trapezoid
except AttributeError:
    _trapz = np.trapz

# Patch np.trapz for any third-party or internal code that calls it directly on NumPy 2.x
if not hasattr(np, 'trapz'):
    np.trapz = np.trapezoid

import numpy.ma as ma
import pandas as pd

# ── SciPy bits
from scipy.interpolate import RBFInterpolator, interp1d
from scipy.signal import medfilt

# ── Astropy / Astroquery
from astropy.io import fits
from astropy.wcs import WCS
import astropy.units as u
from astropy.coordinates import SkyCoord
from astroquery.simbad import Simbad
from astropy.wcs.wcs import NoConvergence

# ── SEP (Source Extractor)
import sep
sep.set_extract_pixstack(20000000)

# ── Matplotlib backend for Qt
from matplotlib.figure import Figure
from matplotlib import pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas

from PyQt6.QtCore import (Qt, QPoint, QRect, QMimeData, QSettings, QByteArray,
                          QDataStream, QIODevice, QEvent, QStandardPaths,QThread, pyqtSignal as _Signal)
from PyQt6.QtGui import (QAction, QDrag, QIcon, QMouseEvent, QPixmap, QKeyEvent)
from PyQt6.QtWidgets import (QToolBar, QWidget, QToolButton, QMenu, QApplication, QVBoxLayout, QHBoxLayout, QComboBox, QGroupBox, QGridLayout, QDoubleSpinBox, QSpinBox,
                             QInputDialog, QMessageBox, QDialog, QFileDialog,
    QFormLayout, QDialogButtonBox, QDoubleSpinBox, QCheckBox, QLabel, QRubberBand, QRadioButton, QMainWindow, QPushButton)

from setiastro.saspro.backgroundneutral import run_background_neutral_via_preset
from setiastro.saspro.backgroundneutral import background_neutralize_rgb, auto_rect_50x50
# --- Gaia XP fallback (optional) ---
from setiastro.saspro.gaia_downloader import GaiaDownloader, HAS_GAIAXPY
from setiastro.saspro.help_support import make_help_button
from setiastro.saspro import cds_health

import warnings
from typing import Callable, Dict, Any, Iterable
warnings.filterwarnings(
    "ignore",
    category=ResourceWarning,
    message=r"unclosed <ssl\.SSLSocket.*"
)
ProgressMsgCB = Callable[[str], None]  # status_cb("text...")

try:
    import pandas as pd  # you already have
except Exception:
    pd = None


# gaiaxpy is imported lazily — see _get_gaiaxpy_generate() below.
# gaiaxpy fetches passband configuration from the Gaia archive on first
# import; doing this at module level causes the splash screen to hang.

import io
import re
import contextlib

from setiastro.saspro.gaia_downloader import GaiaSpectraDB, CalibratedSpectrum
from setiastro.saspro.gaia_downloader import download_xp_spectra_only, ensure_saspro_spcc_dirs
from setiastro.saspro.async_task import run_async_blocking

def _get_sfcc_gaia_tap():
    """
    Lazily import and return the astroquery Gaia TAP object.
    Deferred so the archive connection is not attempted at module load time.
    During DR4 migration periods the Gaia archive can be slow or unresponsive;
    importing astroquery.gaia at module level would cause the splash screen
    to hang indefinitely.
    """
    try:
        from astroquery.gaia import Gaia
        return Gaia
    except ImportError:
        return None


def _get_gaiaxpy_generate():
    """
    Lazily import gaiaxpy.generate and PhotometricSystem.
    gaiaxpy fetches passband configuration from the Gaia archive on first
    import; deferring until first use prevents splash screen hangs.
    Returns (generate, PhotometricSystem) or (None, None) if unavailable.
    """
    try:
        from gaiaxpy import generate
        from gaiaxpy.generator.photometric_system import PhotometricSystem
        return generate, PhotometricSystem
    except ImportError:
        return None, None

def _force_mpl_no_tex():
    try:
        import matplotlib
        matplotlib.rcParams["text.usetex"] = False
        matplotlib.rcParams["axes.unicode_minus"] = False
    except Exception:
        pass

def _johnson_bvr_passbands_on_gaia_grid(wl_nm: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Returns (T_B, T_V, T_R) on the Gaia wavelength grid.
    IMPORTANT:
      - Replace these approximations with your preferred real Johnson/Bessell curves.
      - These are smooth approximations meant to unblock caching integration now.
    """
    wl = np.asarray(wl_nm, dtype=np.float64)

    # Simple smooth band approximations (Gaussian-ish)
    # Johnson-ish effective centers (nm): B~440, V~550, R~700
    # Widths are rough; adjust once you plug real curves.
    def gauss(center, fwhm):
        sigma = fwhm / (2.0 * np.sqrt(2.0 * np.log(2.0)))
        return np.exp(-0.5 * ((wl - center) / sigma) ** 2)

    T_B = gauss(440.0, 95.0)
    T_V = gauss(550.0, 85.0)
    T_R = gauss(700.0, 140.0)

    # Clip outside reasonable ranges (keeps tails from polluting)
    T_B *= (wl >= 360) & (wl <= 560)
    T_V *= (wl >= 470) & (wl <= 700)
    T_R *= (wl >= 560) & (wl <= 900)

    # normalize peaks to 1
    for T in (T_B, T_V, T_R):
        m = float(np.max(T)) if T.size else 0.0
        if m > 0:
            T /= m

    return T_B.astype(np.float64), T_V.astype(np.float64), T_R.astype(np.float64)


def _integrate_flux_times_T(flux_w_per_nm: np.ndarray, wl_nm: np.ndarray, T: np.ndarray) -> float:
    """
    Integral of flux * throughput over wavelength.
    Units don't matter for colors/ratios; we just need consistency.
    """
    f = np.asarray(flux_w_per_nm, dtype=np.float64).reshape(-1)
    w = np.asarray(wl_nm, dtype=np.float64).reshape(-1)
    t = np.asarray(T, dtype=np.float64).reshape(-1)
    if f.size != w.size or t.size != w.size:
        raise ValueError("Integration arrays must be same length")
    return float(_trapz(f * t, w))


def _gaiaxp_synth_bvr_cached(
    self,
    source_ids: List[int],
    *,
    db_path: str,
    status_cb=None,
    username=None,
    password=None,
    cache_dir: Optional[str] = None,
    tag: str = "johnson_bvr_v1",
    batch_size: int = 100,
) -> Dict[int, Dict[str, float]]:
    """
    Cached Gaia XP synthetic Johnson B/V/R using the SAME synth_phot table.

    Returns:
      {source_id: {"B": bmag, "V": vmag, "R": rmag}}
    """
    from pathlib import Path

    if status_cb is None:
        status_cb = lambda m: None

    ids = [int(x) for x in source_ids if x is not None]
    ids = sorted(set(ids))
    if not ids:
        return {}

    db = GaiaSpectraDB(db_path)
    try:
        wl_nm = db.wavelengths.astype(np.float64)
        wl_ang = wl_nm * 10.0

        # 1) Define Johnson system key (stable across runs)
        T_B, T_V, T_R = _johnson_bvr_passbands_on_gaia_grid(wl_nm)
        # map into your R,G,B ordering for synth_phot
        #   Sr <- R, Sg <- V, Sb <- B
        system_key = GaiaSpectraDB.make_system_key(
            wl_ang,
            T_R,  # R
            T_V,  # "G" slot used for V
            T_B,  # B
            tag=tag,
        )

        # 2) Pull cached integrals
        cached = db.get_synth_phot(ids, system_key)
        missing = [sid for sid in ids if sid not in cached]

        if missing:
            status_cb(f"[SPCC] Gaia XP: {len(cached)}/{len(ids)} cached, computing {len(missing)} missing…")

            # 3) Ensure spectra exist in DB; download only those not present
            missing_spectra_ids = []
            for sid in missing:
                if db.get_spectrum(sid) is None:
                    missing_spectra_ids.append(sid)

            if missing_spectra_ids:
                status_cb(f"[SPCC] Gaia XP: downloading {len(missing_spectra_ids)} missing XP spectra…")

                # Use the threaded progress dialog so the user can cancel
                # and sees per-batch progress. We need a GaiaDownloader
                # instance that wraps the existing db connection.
                try:
                    dl_worker = GaiaDownloader(db_path)
                    self._download_gaia_spectra_with_progress(
                        missing_spectra_ids, dl_worker, batch_size=25
                    )
                    dl_worker.close()
                except Exception as e:
                    status_cb(f"[SPCC] Gaia XP BVR download failed: {e}")
            # 4) Compute integrals for missing ids, then upsert into synth_phot
            rows_to_upsert: List[Tuple[int, float, float, float]] = []

            for sid in missing:
                spec = db.get_spectrum(sid)
                if spec is None or spec.flux is None:
                    continue

                # integrate on the DB's standard grid (spec.flux is already resampled in add_spectrum)
                Sr = _integrate_flux_times_T(spec.flux, wl_nm, T_R)  # R
                Sg = _integrate_flux_times_T(spec.flux, wl_nm, T_V)  # V
                Sb = _integrate_flux_times_T(spec.flux, wl_nm, T_B)  # B

                # guard against zeros (would blow logs)
                if Sr <= 0 or Sg <= 0 or Sb <= 0:
                    continue

                rows_to_upsert.append((sid, Sr, Sg, Sb))

            if rows_to_upsert:
                db.upsert_synth_phot(rows_to_upsert, system_key)
                # update local cached dict too
                for sid, Sr, Sg, Sb in rows_to_upsert:
                    cached[int(sid)] = (float(Sr), float(Sg), float(Sb))

        # 5) Convert integrals → relative magnitudes
        # Absolute zeropoints would require calibration; for your use (colors/templates),
        # relative mags are usually enough. We can set an arbitrary constant so numbers
        # look like mags (shifts cancel in colors).
        out: Dict[int, Dict[str, float]] = {}
        for sid, (Sr, Sv, Sb) in cached.items():  # note: Sv stored in Sg slot
            # "instrumental" mags
            # m = -2.5 log10(S) + C; choose C=0 (colors unaffected)
            Rm = -2.5 * np.log10(max(Sr, 1e-300))
            Vm = -2.5 * np.log10(max(Sv, 1e-300))
            Bm = -2.5 * np.log10(max(Sb, 1e-300))
            out[int(sid)] = {"B": float(Bm), "V": float(Vm), "R": float(Rm)}

        return out

    finally:
        db.close()

_GAIA_PW_BANNER_RE = re.compile(
    r"passwords of all user accounts have been inactivated", re.IGNORECASE
)

@contextlib.contextmanager
def suppress_gaia_archive_banner():
    buf_out = io.StringIO()
    buf_err = io.StringIO()
    with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
        yield
    # If you ever want to keep *other* messages, you can inspect buf_out/buf_err here.
    # For now, we intentionally drop everything printed during generate().

def _pick_mag_column(df, band: str) -> str | None:
    """
    GaiaXPy returns a DataFrame with columns per band.
    Column names vary by system/version; pick something that looks like "<band>...mag".
    """
    b = band.strip().lower()
    cols = list(df.columns)
    # prefer exact-ish matches first
    preferred = [
        f"{b}_mag", f"{b}mag", f"mag_{b}", f"{b}_magnitude", f"{b}magnitude",
    ]
    lower_map = {c.lower(): c for c in cols}
    for key in preferred:
        if key in lower_map:
            return lower_map[key]

    # fallback: anything containing band and "mag" but not "err"
    for c in cols:
        cl = c.lower()
        if ("mag" in cl) and (b in cl) and ("err" not in cl) and ("error" not in cl):
            return c

    return None


def gaiaxp_synth_bvr_from_source_ids(
    source_ids: Iterable[int],
    *,
    status_cb: ProgressMsgCB | None = None,
    cosmos_username: str | None = None,
    cosmos_password: str | None = None,
    cache_dir: str | None = None,
) -> Dict[int, Dict[str, float]]:
    """
    Returns:
      { source_id: {"B": Bmag, "V": Vmag, "R": Rmag} }

    Uses GaiaXPy `generate()` on the JKC system. `generate()` accepts a list of source ids. :contentReference[oaicite:1]{index=1}
    """
    out: Dict[int, Dict[str, float]] = {}
    ids = [int(x) for x in source_ids if x is not None]
    ids = list(dict.fromkeys(ids))  # de-dupe preserving order

    generate, PhotometricSystem = _get_gaiaxpy_generate()
    if not ids or generate is None or PhotometricSystem is None:
        return out

    # Reduce "it froze" anxiety + stop scary ResourceWarning spam
    warnings.filterwarnings("ignore", category=ResourceWarning)

    # Keep GaiaXPy cache somewhere sane (optional)
    if cache_dir:
        os.environ.setdefault("GAIAXPY_CACHE_DIR", cache_dir)

    # Also avoid any TeX weirdness if any plotting gets triggered somewhere
    os.environ.setdefault("MPLBACKEND", "Agg")
    try:
        import matplotlib
        matplotlib.rcParams["text.usetex"] = False
    except Exception:
        pass

    if status_cb:
        status_cb(f"[SPCC] Gaia XP fallback: fetching synthetic photometry for {len(ids)} Gaia sources… (can take a bit)")

    # GaiaXPy: list-of-source-ids -> DataFrame synthetic photometry :contentReference[oaicite:2]{index=2}
    df = generate(
        ids,
        photometric_system=PhotometricSystem.JKC,
        save_file=False,
        username=cosmos_username,
        password=cosmos_password,
    )

    if df is None or getattr(df, "empty", False):
        return out

    # Identify the source id column
    sid_col = None
    for c in df.columns:
        if c.lower() in ("source_id", "sourceid", "gaia_source_id"):
            sid_col = c
            break
    if sid_col is None:
        # last-ditch: first column that contains "source" and "id"
        for c in df.columns:
            cl = c.lower()
            if "source" in cl and "id" in cl:
                sid_col = c
                break
    if sid_col is None:
        return out

    b_col = _pick_mag_column(df, "B")
    v_col = _pick_mag_column(df, "V")
    r_col = _pick_mag_column(df, "R")
    if not (b_col and v_col and r_col):
        return out

    for _, row in df.iterrows():
        try:
            sid = int(row[sid_col])
            B = float(row[b_col])
            V = float(row[v_col])
            R = float(row[r_col])
        except Exception:
            continue
        out[sid] = {"B": B, "V": V, "R": R}

    if status_cb:
        status_cb(f"[SPCC] Gaia XP fallback: synthetic B/V/R available for {len(out)} sources")

    return out



# ──────────────────────────────────────────────────────────────────────────────
# Utilities
# ──────────────────────────────────────────────────────────────────────────────

# --- Debug/guards -----------------------------------------------------
def _debug_probe_channels(img: np.ndarray, label="input"):
    assert img.ndim == 3 and img.shape[2] == 3, f"[SPCC] {label}: not RGB"
    f = img.astype(np.float32) / (255.0 if img.dtype == np.uint8 else 1.0)
    means = [float(f[...,i].mean()) for i in range(3)]
    stds  = [float(f[...,i].std())  for i in range(3)]
    rg = float(np.corrcoef(f[...,0].ravel(), f[...,1].ravel())[0,1])
    rb = float(np.corrcoef(f[...,0].ravel(), f[...,2].ravel())[0,1])
    gb = float(np.corrcoef(f[...,1].ravel(), f[...,2].ravel())[0,1])
    print(f"[SPCC] {label}: mean={means}, std={stds}, corr(R,G)={rg:.5f}, corr(R,B)={rb:.5f}, corr(G,B)={gb:.5f}")
    return rg, rb, gb

def _maybe_bgr_to_rgb(img: np.ndarray) -> np.ndarray:
    # Heuristic: if channel-2 is consistently brightest in highlights and ch-0 the dimmest → likely BGR.
    f = img.astype(np.float32) / (255.0 if img.dtype == np.uint8 else 1.0)
    lum = np.mean(f, axis=2)
    thr = np.quantile(lum, 0.95)
    m0 = f[...,0][lum >= thr].mean() if np.any(lum >= thr) else f[...,0].mean()
    m1 = f[...,1][lum >= thr].mean() if np.any(lum >= thr) else f[...,1].mean()
    m2 = f[...,2][lum >= thr].mean() if np.any(lum >= thr) else f[...,2].mean()
    if (m2 > m1 >= m0) and (m2 - m0 > 0.02):
        print("[SPCC] Heuristic suggests BGR input → converting to RGB")
        return img[..., ::-1]
    return img

def _ensure_angstrom(wl: np.ndarray) -> np.ndarray:
    """If wavelengths look like nm (≈300–1100), convert to Å."""
    med = float(np.median(wl))
    return wl * 10.0 if 250.0 <= med <= 2000.0 else wl


def pickles_match_for_simbad(simbad_sp: Optional[str], available_extnames: List[str]) -> List[str]:
    if not simbad_sp:   # handles None, "", etc.
        return []
    sp = str(simbad_sp).strip().upper()
    if not sp:
        return []
    m = re.match(r"^([OBAFGKMLT])(\d?)(I{1,3}|IV|V)?", sp)
    if not m:
        return []
    letter_class = m.group(1)
    digit_part   = m.group(2)
    lum_part     = m.group(3)
    subclass = int(digit_part) if digit_part != "" else None

    def parse_pickles_extname(ext: str):
        ext = ext.strip().upper()
        m2 = re.match(r"^([OBAFGKMLT])(\d+)(I{1,3}|IV|V)$", ext)
        if not m2:
            return None, None, None
        return m2.group(1), int(m2.group(2)), m2.group(3)

    parsed_templates = []
    for ext in available_extnames:
        l2, d2, L2 = parse_pickles_extname(ext)
        if l2 is not None:
            parsed_templates.append((ext, l2, d2, L2))

    # Exact
    if subclass is not None and lum_part is not None:
        target = f"{letter_class}{subclass}{lum_part}"
        if target in available_extnames:
            return [target]

    # Same letter (+same lum if we have it)
    same_letter_and_lum = []
    same_letter_any_lum = []
    for (ext, l2, d2, L2) in parsed_templates:
        if l2 != letter_class:
            continue
        if lum_part is not None and L2 == lum_part:
            same_letter_and_lum.append((ext, d2))
        else:
            same_letter_any_lum.append((ext, d2))

    def pick_nearest(candidates: List[Tuple[str, int]], target: int) -> List[str]:
        if not candidates or target is None:
            return []
        arr = np.abs(np.array([d for _, d in candidates]) - target)
        mind = np.min(arr)
        return [candidates[i][0] for i in np.where(arr == mind)[0]]

    if subclass is not None and lum_part is not None:
        if same_letter_and_lum:
            return pick_nearest(same_letter_and_lum, subclass)
        if same_letter_any_lum:
            return pick_nearest(same_letter_any_lum, subclass)

    if subclass is not None and lum_part is None:
        if same_letter_any_lum:
            return pick_nearest(same_letter_any_lum, subclass)

    if subclass is None and lum_part is None:
        return sorted([ext for (ext, l2, _, _) in parsed_templates if l2 == letter_class])

    if subclass is None and lum_part is not None:
        cands = [ (ext, d2) for (ext, l2, d2, L2) in parsed_templates if l2 == letter_class and L2 == lum_part ]
        if cands:
            return sorted([ext for (ext, _) in cands])
        return sorted([ext for (ext, l2, _, _) in parsed_templates if l2 == letter_class])

    return []


def compute_gradient_map(sources, delta_flux, shape, method="poly2"):
    H, W = shape
    xs, ys = sources[:, 0], sources[:, 1]

    if method == "poly2":
        A = np.vstack([np.ones_like(xs), xs, ys, xs**2, xs*ys, ys**2]).T
        coeffs, *_ = np.linalg.lstsq(A, delta_flux, rcond=None)
        YY, XX = np.mgrid[0:H, 0:W]
        return (coeffs[0] + coeffs[1]*XX + coeffs[2]*YY
                + coeffs[3]*XX**2 + coeffs[4]*XX*YY + coeffs[5]*YY**2)

    elif method == "poly3":
        A = np.vstack([
            np.ones_like(xs), xs, ys,
            xs**2, xs*ys, ys**2,
            xs**3, xs**2*ys, xs*ys**2, ys**3
        ]).T
        coeffs, *_ = np.linalg.lstsq(A, delta_flux, rcond=None)
        YY, XX = np.mgrid[0:H, 0:W]
        return (coeffs[0] + coeffs[1]*XX + coeffs[2]*YY
                + coeffs[3]*XX**2 + coeffs[4]*XX*YY + coeffs[5]*YY**2
                + coeffs[6]*XX**3 + coeffs[7]*XX**2*YY + coeffs[8]*XX*YY**2 + coeffs[9]*YY**3)

    elif method == "rbf":
        pts = np.vstack([xs, ys]).T
        rbfi = RBFInterpolator(pts, delta_flux, kernel="thin_plate_spline", smoothing=1.0)
        YY, XX = np.mgrid[0:H, 0:W]
        grid_pts = np.vstack([XX.ravel(), YY.ravel()]).T
        return rbfi(grid_pts).reshape(H, W)

    else:
        raise ValueError("method must be one of 'poly2','poly3','rbf'")

def compute_smooth_rbf_map(
    pts: np.ndarray,
    values: np.ndarray,
    shape: tuple[int, int],
    *,
    smoothing: float = 2.0,
    neighbors: int | None = None,
    kernel: str = "thin_plate_spline",
):
    H, W = shape
    pts = np.asarray(pts, dtype=np.float64)
    values = np.asarray(values, dtype=np.float64)

    rbfi = RBFInterpolator(
        pts,
        values,
        kernel=kernel,
        smoothing=float(smoothing),
        neighbors=neighbors,
    )

    YY, XX = np.mgrid[0:H, 0:W]
    grid_pts = np.column_stack([XX.ravel(), YY.ravel()])
    surf = rbfi(grid_pts).reshape(H, W)
    return surf.astype(np.float32)

def measure_star_rgb_photometry(
    img_rgb_f32: np.ndarray,
    x: float,
    y: float,
    r: float,
    rin: float,
    rout: float,
) -> dict | None:
    R = np.ascontiguousarray(img_rgb_f32[..., 0], dtype=np.float32)
    G = np.ascontiguousarray(img_rgb_f32[..., 1], dtype=np.float32)
    B = np.ascontiguousarray(img_rgb_f32[..., 2], dtype=np.float32)

    xarr = np.array([x], dtype=np.float64)
    yarr = np.array([y], dtype=np.float64)

    ap_area = np.pi * r * r
    ann_area = np.pi * (rout * rout - rin * rin)

    def _measure(ch):
        raw = sep.sum_circle(ch, xarr, yarr, r, subpix=5)
        ann = sep.sum_circann(ch, xarr, yarr, rin, rout, subpix=5)

        if len(raw) == 3:
            raw_sum, _raw_err, raw_flag = raw
        else:
            raw_sum, raw_flag = raw

        if len(ann) == 3:
            ann_sum, _ann_err, ann_flag = ann
        else:
            ann_sum, ann_flag = ann

        raw_sum = float(raw_sum[0])
        ann_sum = float(ann_sum[0])
        flag = int(raw_flag[0]) | int(ann_flag[0])

        if flag != 0:
            return None

        mu_bg = ann_sum / max(ann_area, 1e-12)   # background per pixel
        star_sum = raw_sum - mu_bg * ap_area     # star-only flux

        return {
            "raw_sum": raw_sum,
            "ann_sum": ann_sum,
            "mu_bg": mu_bg,
            "star_sum": star_sum,
        }

    mr = _measure(R)
    mg = _measure(G)
    mb = _measure(B)

    if mr is None or mg is None or mb is None:
        return None

    return {
        "area_ap": float(ap_area),
        "area_ann": float(ann_area),
        "R": mr,
        "G": mg,
        "B": mb,
    }

def measure_star_rgb_raw_aperture(
    img_rgb_f32: np.ndarray,
    x: float,
    y: float,
    r: float,
) -> dict | None:
    R = np.ascontiguousarray(img_rgb_f32[..., 0], dtype=np.float32)
    G = np.ascontiguousarray(img_rgb_f32[..., 1], dtype=np.float32)
    B = np.ascontiguousarray(img_rgb_f32[..., 2], dtype=np.float32)

    xarr = np.array([x], dtype=np.float64)
    yarr = np.array([y], dtype=np.float64)

    ap_area = np.pi * r * r

    def _measure(ch):
        out = sep.sum_circle(ch, xarr, yarr, r, subpix=5)
        if len(out) == 3:
            raw_sum, _raw_err, raw_flag = out
        else:
            raw_sum, raw_flag = out

        raw_sum = float(raw_sum[0])
        flag = int(raw_flag[0])

        if flag != 0:
            return None

        return raw_sum

    rsum = _measure(R)
    gsum = _measure(G)
    bsum = _measure(B)

    if rsum is None or gsum is None or bsum is None:
        return None

    return {
        "area_ap": float(ap_area),
        "R_raw": float(rsum),
        "G_raw": float(gsum),
        "B_raw": float(bsum),
    }

def _pivot_scale_channel(ch: np.ndarray, gain: np.ndarray | float, pivot: float) -> np.ndarray:
    """
    Apply gain around a pivot: pivot + (x - pivot)*gain.
    gain can be scalar or per-pixel array.
    """
    return pivot + (ch - pivot) * gain

# ──────────────────────────────────────────────────────────────────────────────
# Simple responses viewer (unchanged core logic; useful for diagnostics)
# ──────────────────────────────────────────────────────────────────────────────
class SaspViewer(QMainWindow):
    def __init__(self, sasp_data_path: str, user_custom_path: str):
        super().__init__()
        _force_mpl_no_tex()
        self.setWindowTitle(self.tr("SASP Viewer (Pickles + RGB Responses)"))

        self.base_hdul   = fits.open(sasp_data_path,   mode="readonly", memmap=False)
        self.custom_hdul = fits.open(user_custom_path, mode="readonly", memmap=False)

        self.pickles_templates = []
        self.filter_list       = []
        self.sensor_list       = []
        for hdul in (self.custom_hdul, self.base_hdul):
            for hdu in hdul:
                if not isinstance(hdu, fits.BinTableHDU): continue
                c = hdu.header.get("CTYPE","").upper()
                e = hdu.header.get("EXTNAME","")
                if c == "SED":    self.pickles_templates.append(e)
                elif c == "FILTER": self.filter_list.append(e)
                elif c == "SENSOR": self.sensor_list.append(e)

        for lst in (self.pickles_templates, self.filter_list, self.sensor_list):
            lst.sort()
        self.rgb_filter_choices = ["(None)"] + self.filter_list

        central = QWidget(); self.setCentralWidget(central)
        vbox = QVBoxLayout(); central.setLayout(vbox)

        row = QHBoxLayout(); vbox.addLayout(row)
        row.addWidget(QLabel(self.tr("Star Template:")))
        self.star_combo = QComboBox(); self.star_combo.addItems(self.pickles_templates); row.addWidget(self.star_combo)
        row.addWidget(QLabel(self.tr("R-Filter:")))
        self.r_filter_combo = QComboBox(); self.r_filter_combo.addItems(self.rgb_filter_choices); row.addWidget(self.r_filter_combo)
        row.addWidget(QLabel(self.tr("G-Filter:")))
        self.g_filter_combo = QComboBox(); self.g_filter_combo.addItems(self.rgb_filter_choices); row.addWidget(self.g_filter_combo)
        row.addWidget(QLabel(self.tr("B-Filter:")))
        self.b_filter_combo = QComboBox(); self.b_filter_combo.addItems(self.rgb_filter_choices); row.addWidget(self.b_filter_combo)

        row2 = QHBoxLayout(); vbox.addLayout(row2)
        row2.addWidget(QLabel(self.tr("LP/Cut Filter1:")))
        self.lp_filter_combo = QComboBox(); self.lp_filter_combo.addItems(self.rgb_filter_choices); row2.addWidget(self.lp_filter_combo)
        row2.addWidget(QLabel(self.tr("LP/Cut Filter2:")))
        self.lp_filter_combo2 = QComboBox(); self.lp_filter_combo2.addItems(self.rgb_filter_choices); row2.addWidget(self.lp_filter_combo2)
        row2.addSpacing(20); row2.addWidget(QLabel(self.tr("Sensor (QE):")))
        self.sens_combo = QComboBox(); self.sens_combo.addItems(self.sensor_list); row2.addWidget(self.sens_combo)

        self.plot_btn = QPushButton(self.tr("Plot")); self.plot_btn.clicked.connect(self.update_plot); row.addWidget(self.plot_btn)

        self.figure = Figure(figsize=(9, 6)); self.canvas = FigureCanvas(self.figure); vbox.addWidget(self.canvas)
        self.update_plot()

    def closeEvent(self, event):
        self.base_hdul.close(); self.custom_hdul.close()
        super().closeEvent(event)

    def load_any(self, extname, field):
        for hdul in (self.custom_hdul, self.base_hdul):
            if extname in hdul:
                return hdul[extname].data[field].astype(float)
        raise KeyError(f"Extension '{extname}' not found")

    def update_plot(self):
        _force_mpl_no_tex()
        star_ext = self.star_combo.currentText()
        r_filt   = self.r_filter_combo.currentText()
        g_filt   = self.g_filter_combo.currentText()
        b_filt   = self.b_filter_combo.currentText()
        sens_ext = self.sens_combo.currentText()
        lp_ext1  = self.lp_filter_combo.currentText()
        lp_ext2  = self.lp_filter_combo2.currentText()

        wl_star = self.load_any(star_ext, "WAVELENGTH")
        fl_star = self.load_any(star_ext, "FLUX")
        wl_sens = self.load_any(sens_ext, "WAVELENGTH")
        qe_sens = self.load_any(sens_ext, "THROUGHPUT")

        wl_min, wl_max = 1150.0, 10620.0
        common_wl = np.arange(wl_min, wl_max + 1.0, 1.0)

        sed_interp  = interp1d(wl_star, fl_star, kind="linear", bounds_error=False, fill_value=0.0)
        sens_interp = interp1d(wl_sens, qe_sens, kind="linear", bounds_error=False, fill_value=0.0)
        fl_common   = sed_interp(common_wl)
        sens_common = sens_interp(common_wl)

        rgb_data = {}
        for color, filt_name in (("red", r_filt), ("green", g_filt), ("blue", b_filt)):
            if filt_name == "(None)":
                rgb_data[color] = None; continue

            wl_filt = self.load_any(filt_name, "WAVELENGTH")
            tr_filt = self.load_any(filt_name, "THROUGHPUT")
            filt_common = interp1d(wl_filt, tr_filt, bounds_error=False, fill_value=0.0)(common_wl)

            def lp_curve(ext):
                if ext == "(None)": return np.ones_like(common_wl)
                wl_lp = self.load_any(ext, "WAVELENGTH"); tr_lp = self.load_any(ext, "THROUGHPUT")
                return interp1d(wl_lp, tr_lp, bounds_error=False, fill_value=0.0)(common_wl)

            T_LP = lp_curve(lp_ext1) * lp_curve(lp_ext2)
            T_sys = filt_common * sens_common * T_LP
            resp  = fl_common * T_sys

            rgb_data[color] = {"filter_name": filt_name, "T_sys": T_sys, "response": resp}

        mag_texts = []
        if "A0V" in self.pickles_templates:
            wl_veg = self.load_any("A0V", "WAVELENGTH")
            fl_veg = self.load_any("A0V", "FLUX")
            fl_veg_c = interp1d(wl_veg, fl_veg, kind="linear", bounds_error=False, fill_value=0.0)(common_wl)
            for color in ("red","green","blue"):
                data = rgb_data[color]
                if data is not None:
                    S_star = _trapz(data["response"], x=common_wl)
                    S_veg  = _trapz(fl_veg_c * data["T_sys"], x=common_wl)
                    if S_veg>0 and S_star>0:
                        mag = -2.5 * np.log10(S_star / S_veg)
                        mag_texts.append(f"{color[0].upper()}→{data['filter_name']}: {mag:.2f}")
                    else:
                        mag_texts.append(f"{color[0].upper()}→{data['filter_name']}: N/A")
        title_text = " | ".join(mag_texts) if mag_texts else self.tr("No channels selected")

        self.figure.clf()
        ax1 = self.figure.add_subplot(111)
        ax1.plot(common_wl, fl_common, color="black", linewidth=1, label=f"{star_ext} SED")
        for color, data in rgb_data.items():
            if data is not None:
                ax1.plot(common_wl, data["response"], color="gold", linewidth=1.5, label=self.tr("{0} Response").format(color.upper()))
        ax1.set_xlim(wl_min, wl_max); ax1.set_xlabel(self.tr("Wavelength (Å)"))
        ax1.set_ylabel(self.tr("Flux (erg s⁻¹ cm⁻² Å⁻¹)"), color="black"); ax1.tick_params(axis="y", labelcolor="black")

        ax2 = ax1.twinx()
        ax2.set_ylabel(self.tr("Relative Throughput"), color="red"); ax2.tick_params(axis="y", labelcolor="red"); ax2.set_ylim(0.0, 1.0)
        if rgb_data["red"] is not None:   ax2.plot(common_wl, rgb_data["red"]["T_sys"],   color="red",   linestyle="--", linewidth=1, label=self.tr("R filter×QE"))
        if rgb_data["green"] is not None: ax2.plot(common_wl, rgb_data["green"]["T_sys"], color="green", linestyle="--", linewidth=1, label=self.tr("G filter×QE"))
        if rgb_data["blue"] is not None:  ax2.plot(common_wl, rgb_data["blue"]["T_sys"],  color="blue",  linestyle="--", linewidth=1, label=self.tr("B filter×QE"))

        ax1.grid(True, which="both", linestyle="--", alpha=0.3); self.figure.suptitle(title_text, fontsize=10)
        lines1, labels1 = ax1.get_legend_handles_labels(); lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper right")
        self.canvas.draw()

def _sfcc_status(self, msg: str):
    # Prefer label if present, else print
    try:
        if getattr(self, "count_label", None) is not None:
            self.count_label.setText(msg)
    except Exception:
        pass
    print(msg)
    try:
        from PyQt6.QtWidgets import QApplication
        QApplication.processEvents()
    except Exception:
        pass


def _sfcc_busy(self, on: bool, msg: str | None = None):
    """Indeterminate progress if you have a QProgressBar named progress_bar (or similar)."""
    if msg:
        _sfcc_status(self, msg)

    pb = getattr(self, "progress_bar", None) or getattr(self, "progress", None)
    if pb is None:
        return

    try:
        pb.setVisible(on)
        if on:
            pb.setRange(0, 0)   # indeterminate
        else:
            pb.setRange(0, 100)
            pb.setValue(0)
    except Exception:
        pass


def _gaiaxp_synth_bvr(self, source_ids, *, status_cb=None, username=None, password=None, cache_dir=None):
    """
    Returns {source_id: {"B":..., "V":..., "R":...}} using GaiaXPy generate() with JKC system.
    """
    if status_cb is None:
        status_cb = lambda s: None

    # Local-only suppression: kill socket/file ResourceWarnings spam in this worker path
    warnings.filterwarnings("ignore", category=ResourceWarning)

    # Prevent TeX related noise if any plot code runs somewhere
    os.environ.setdefault("MPLBACKEND", "Agg")
    try:
        import matplotlib
        matplotlib.rcParams["text.usetex"] = False
    except Exception:
        pass

    generate, PhotometricSystem = _get_gaiaxpy_generate()
    if generate is None or PhotometricSystem is None:
        return {}
    
    ids = [int(x) for x in source_ids if x is not None]
    ids = list(dict.fromkeys(ids))
    if not ids:
        return {}

    if cache_dir:
        os.environ.setdefault("GAIAXPY_CACHE_DIR", str(cache_dir))

    status_cb(f"[SPCC] Gaia XP: generating synthetic JKC photometry for {len(ids)} Gaia sources…")

    df_parts = []
    total = len(ids)
    chunk = 10  # or 50

    for i in range(0, total, chunk):
        sub = ids[i:i+chunk]
        status_cb(f"[SPCC] Gaia XP: synthetic photometry {i+1}-{min(i+len(sub), total)} of {total}…")
        try:
            from PyQt6.QtWidgets import QApplication
            QApplication.processEvents()
        except Exception:
            pass

        with suppress_gaia_archive_banner():
            df_i = generate(
                sub,
                photometric_system=PhotometricSystem.JKC,
                save_file=False,
                username=username,
                password=password,
            )
        if df_i is not None and not getattr(df_i, "empty", False):
            df_parts.append(df_i)

    df = pd.concat(df_parts, ignore_index=True) if df_parts else None

    if df is None or getattr(df, "empty", False):
        return {}

    # Figure out source-id column
    sid_col = None
    for c in df.columns:
        if c.lower() in ("source_id", "sourceid", "gaia_source_id"):
            sid_col = c
            break
    if sid_col is None:
        for c in df.columns:
            cl = c.lower()
            if "source" in cl and "id" in cl:
                sid_col = c
                break
    if sid_col is None:
        return {}

    def pick_col(band: str):
        b = band.lower()
        # prefer common patterns
        for key in (f"{b}_mag", f"mag_{b}", f"{b}mag"):
            for c in df.columns:
                if c.lower() == key:
                    return c
        # fallback: anything containing band and 'mag' but not err
        for c in df.columns:
            cl = c.lower()
            if b in cl and "mag" in cl and "err" not in cl and "error" not in cl:
                return c
        return None

    b_col = pick_col("B")
    v_col = pick_col("V")
    r_col = pick_col("R")
    if not (b_col and v_col and r_col):
        return {}

    out = {}
    for _, row in df.iterrows():
        try:
            sid = int(row[sid_col])
            out[sid] = {"B": float(row[b_col]), "V": float(row[v_col]), "R": float(row[r_col])}
        except Exception:
            continue

    status_cb(f"[SPCC] Gaia XP: synthetic B/V/R available for {len(out)} sources")
    return out



def _infer_letter_from_bv(bv):
    if bv is None:
        return None
    try:
        bv = float(bv)
    except Exception:
        return None
    if not np.isfinite(bv):
        return None
    if bv < 0.00:
        return "B"
    elif bv < 0.30:
        return "A"
    elif bv < 0.58:
        return "F"
    elif bv < 0.81:
        return "G"
    elif bv < 1.40:
        return "K"
    else:
        return "M"


# ──────────────────────────────────────────────────────────────────────────────
# SFCC Dialog (rewired for "current view")
# ──────────────────────────────────────────────────────────────────────────────
class SFCCDialog(QDialog):
    """
    Spectral Flux Color Calibration dialog, adapted for SASpro's current view.
    Pass a 'view' adapter providing:
       - get_rgb_image(), set_rgb_image(...)
       - get_metadata()  [optional]
       - get_header()    [preferred for WCS; else we look in metadata]
    """
    def __init__(self, doc_manager, sasp_data_path, parent=None):
        super().__init__(parent)
        _force_mpl_no_tex()
        self.setWindowTitle(self.tr("Spectral Photometric Flux Color Calibration"))
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        except Exception:
            pass  # older PyQt6 versions        
        self.setMinimumSize(800, 600)

        self.doc_manager = doc_manager
        self.sasp_data_path = sasp_data_path
        self.user_custom_path = self._ensure_user_custom_fits()
        self.current_image = None
        self.current_header = None
        self.sasp_viewer_window = None
        self.main_win = parent

        # user custom file init … (unchanged)
        # ...
        self._reload_hdu_lists()
        self.star_list = []
        self._build_ui()
        self.load_settings()

        # persist combobox choices
        self.r_filter_combo.currentIndexChanged.connect(self.save_r_filter_setting)
        self.g_filter_combo.currentIndexChanged.connect(self.save_g_filter_setting)
        self.b_filter_combo.currentIndexChanged.connect(self.save_b_filter_setting)
        self.lp_filter_combo.currentIndexChanged.connect(self.save_lp_setting)
        self.lp_filter_combo2.currentIndexChanged.connect(self.save_lp2_setting)
        self.sens_combo.currentIndexChanged.connect(self.save_sensor_setting)
        self.star_combo.currentIndexChanged.connect(self.save_star_setting)
        self.finished.connect(lambda *_: self._cleanup())

        self.grad_method = "poly3"
        self.grad_method_combo.currentTextChanged.connect(lambda m: setattr(self, "grad_method", m))

    # ── View plumbing ───────────────────────────────────────────────────
    def _get_active_image_and_header(self):
        doc = self.doc_manager.get_active_document()
        if doc is None:
            return None, None, None

        img = doc.image
        meta = doc.metadata or {}

        # Prefer the normalized WCS header if present, then fall back
        hdr = (
            meta.get("wcs_header") or
            meta.get("original_header") or
            meta.get("header")
        )

        return img, hdr, meta

    
    def _get_img_meta(self) -> Tuple[Optional[np.ndarray], dict]:
        """Try a few common shapes to obtain image + metadata from the view."""
        meta = {}
        img = None
        if hasattr(self.view, "get_image_and_metadata"):
            try:
                img, meta = self.view.get_image_and_metadata()
            except Exception:
                pass
        if img is None and hasattr(self.view, "get_rgb_image"):
            img = self.view.get_rgb_image()
        if not meta and hasattr(self.view, "get_metadata"):
            try:
                meta = self.view.get_metadata() or {}
            except Exception:
                meta = {}
        return img, (meta or {})

    def _get_header(self):
        header = None
        if hasattr(self.view, "get_header"):
            try:
                header = self.view.get_header()
            except Exception:
                header = None
        if header is None:
            # fall back to metadata
            _, meta = self._get_img_meta()
            header = meta.get("original_header") or meta.get("header")
        return header

    def _push_image(self, img: np.ndarray, meta: Optional[dict], step_name: str):
        """Send image back to the same current view."""
        if hasattr(self.view, "set_rgb_image"):
            self.view.set_rgb_image(img, meta or {}, step_name)
        elif hasattr(self.view, "set_image"):
            self.view.set_image(img, meta or {}, step_name=step_name)
        elif hasattr(self.view, "update_image"):
            self.view.update_image(img, meta or {}, step_name=step_name)
        else:
            # As a last resort, try attribute assignment (for custom apps)
            if hasattr(self.view, "image"):
                self.view.image = img
            if hasattr(self.view, "metadata"):
                self.view.metadata = meta or {}

    # ── File prep ───────────────────────────────────────────────────────

    def _ensure_user_custom_fits(self) -> str:
        app_data = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation)
        os.makedirs(app_data, exist_ok=True)
        path = os.path.join(app_data, "usercustomcurves.fits")
        if not os.path.exists(path):
            fits.HDUList([fits.PrimaryHDU()]).writeto(path)
        return path

    # ── UI ──────────────────────────────────────────────────────────────

    def _build_ui(self):
        layout = QVBoxLayout(self)

        row1 = QHBoxLayout(); layout.addLayout(row1)
        self.fetch_stars_btn = QPushButton(self.tr("Step 1: Fetch Stars & Spectra from Current View"))
        f = self.fetch_stars_btn.font(); f.setBold(True); self.fetch_stars_btn.setFont(f)
        self.fetch_stars_btn.clicked.connect(self.fetch_stars)
        row1.addWidget(self.fetch_stars_btn)

        self.open_sasp_btn = QPushButton(self.tr("Open SASP Viewer"))
        self.open_sasp_btn.clicked.connect(self.open_sasp_viewer)
        row1.addWidget(self.open_sasp_btn)

        row1.addSpacing(20)
        row1.addWidget(QLabel(self.tr("Select White Reference:")))
        self.star_combo = QComboBox()
        self.star_combo.addItem(self.tr("Vega (A0V)"), userData="A0V")
        for sed in getattr(self, "sed_list", []):
            if sed.upper() == "A0V": continue
            self.star_combo.addItem(sed, userData=sed)
        row1.addWidget(self.star_combo)
        idx_g2v = self.star_combo.findData("G2V")
        if idx_g2v >= 0: self.star_combo.setCurrentIndex(idx_g2v)

        row2 = QHBoxLayout(); layout.addLayout(row2)
        row2.addWidget(QLabel(self.tr("R Filter:")))
        self.r_filter_combo = QComboBox(); self.r_filter_combo.addItem("(None)"); self.r_filter_combo.addItems(self.filter_list); row2.addWidget(self.r_filter_combo)
        row2.addSpacing(20); row2.addWidget(QLabel(self.tr("G Filter:")))
        self.g_filter_combo = QComboBox(); self.g_filter_combo.addItem("(None)"); self.g_filter_combo.addItems(self.filter_list); row2.addWidget(self.g_filter_combo)
        row2.addSpacing(20); row2.addWidget(QLabel(self.tr("B Filter:")))
        self.b_filter_combo = QComboBox(); self.b_filter_combo.addItem("(None)"); self.b_filter_combo.addItems(self.filter_list); row2.addWidget(self.b_filter_combo)

        row3 = QHBoxLayout(); layout.addLayout(row3)
        row3.addStretch()
        row3.addWidget(QLabel(self.tr("Sensor (QE):")))
        self.sens_combo = QComboBox(); self.sens_combo.addItem("(None)"); self.sens_combo.addItems(self.sensor_list); row3.addWidget(self.sens_combo)
        row3.addSpacing(20); row3.addWidget(QLabel(self.tr("LP/Cut Filter1:")))
        self.lp_filter_combo = QComboBox(); self.lp_filter_combo.addItem("(None)"); self.lp_filter_combo.addItems(self.filter_list); row3.addWidget(self.lp_filter_combo)
        row3.addSpacing(20); row3.addWidget(QLabel(self.tr("LP/Cut Filter2:")))
        self.lp_filter_combo2 = QComboBox(); self.lp_filter_combo2.addItem("(None)"); self.lp_filter_combo2.addItems(self.filter_list); row3.addWidget(self.lp_filter_combo2)
        row3.addStretch()

        row4 = QHBoxLayout(); layout.addLayout(row4)
        self.run_spcc_btn = QPushButton(self.tr("Step 2: Run Color Calibration"))
        f2 = self.run_spcc_btn.font(); f2.setBold(True); self.run_spcc_btn.setFont(f2)
        self.run_spcc_btn.clicked.connect(self.run_spcc)
        row4.addWidget(self.run_spcc_btn)

        self.neutralize_chk = QCheckBox(self.tr("Background Neutralization")); self.neutralize_chk.setChecked(False); row4.addWidget(self.neutralize_chk)
        self.color_matrix_chk = QCheckBox(self.tr("3×3 Color Matrix Correction"))
        self.color_matrix_chk.setChecked(False)
        self.color_matrix_chk.setToolTip(
            "After the standard per-channel SFCC correction, fits a 3×3 color\n"
            "mixing matrix from the stellar photometry residuals.\n"
            "Corrects cross-channel bleed (e.g. R leaking into G) that\n"
            "per-channel scaling cannot fix.\n\n"
            "Recommended for broadband RGB — not for narrowband/duoband."
        )
        row4.addWidget(self.color_matrix_chk)
        self.run_grad_btn = QPushButton(self.tr("Run Gradient Extraction (Beta)"))
        f3 = self.run_grad_btn.font(); f3.setBold(True); self.run_grad_btn.setFont(f3)
        self.run_grad_btn.clicked.connect(self.run_gradient_extraction)
        row4.addWidget(self.run_grad_btn)

        self.grad_method_combo = QComboBox(); self.grad_method_combo.addItems(["poly2","poly3","rbf"]); self.grad_method_combo.setCurrentText("poly3")
        row4.addWidget(self.grad_method_combo)

        row4.addSpacing(15)
        row4.addWidget(QLabel(self.tr("Star detect σ:")))
        self.sep_thr_spin = QSpinBox()
        self.sep_thr_spin.setRange(2, 100)        # should be enough
        self.sep_thr_spin.setValue(15)            # our current hardcoded value
        self.sep_thr_spin.valueChanged.connect(self.save_sep_threshold_setting)
        row4.addWidget(self.sep_thr_spin)

        # Auto σ (waterfall) — removes the manual guess-and-check.
        # Starts at σ=100 and steps down [100,50,25,12,8,5,3] until the
        # detection returns at least SFCC_AUTO_SIGMA_MIN_STARS (1200) sources,
        # then uses that σ. If none of the trials hit the threshold, the
        # lowest σ in the ladder is used (highest-sensitivity attempt).
        self.auto_sigma_chk = QCheckBox(self.tr("Auto"))
        self.auto_sigma_chk.setToolTip(self.tr(
            "Auto σ waterfall:\n"
            "  Tries σ = 100, 50, 25, 12, 8, 5, 3 in order and stops at the\n"
            "  first value that yields ≥ 1200 detections. Removes the need to\n"
            "  guess a threshold for different fields.\n\n"
            "  Uncheck to use the manual σ value in the spin box."
        ))
        self.auto_sigma_chk.setChecked(True)
        self.auto_sigma_chk.toggled.connect(self._on_auto_sigma_toggled)
        row4.addWidget(self.auto_sigma_chk)
        # Reflect initial state on the spin box
        self.sep_thr_spin.setEnabled(not self.auto_sigma_chk.isChecked())
        row4.addStretch()
        self.add_curve_btn = QPushButton(self.tr("Add Custom Filter/Sensor Curve…"))
        self.add_curve_btn.clicked.connect(self.add_custom_curve); row4.addWidget(self.add_curve_btn)
        self.remove_curve_btn = QPushButton(self.tr("Remove Filter/Sensor Curve…"))
        self.remove_curve_btn.clicked.connect(self.remove_custom_curve); row4.addWidget(self.remove_curve_btn)
        row4.addStretch()
        self.btn_help = make_help_button("sfcc", self)
        row4.addWidget(self.btn_help)
        self.close_btn = QPushButton(self.tr("Close")); self.close_btn.clicked.connect(self.reject); row4.addWidget(self.close_btn)

        self.count_label = QLabel(""); layout.addWidget(self.count_label)

        self.figure = Figure(figsize=(6, 4)); self.canvas = FigureCanvas(self.figure); self.canvas.setVisible(False); layout.addWidget(self.canvas, stretch=1)
        self.reset_btn = QPushButton(self.tr("Reset View/Close")); self.reset_btn.clicked.connect(self.reject); layout.addWidget(self.reset_btn)
        self.color_matrix_chk.toggled.connect(
            lambda v: QSettings().setValue("SFCC/UseColorMatrix", bool(v))
        )
        # hide gradient controls by default (enable if you like)
        self.run_grad_btn.hide(); self.grad_method_combo.hide(); self.color_matrix_chk.hide()


    # ── Settings helpers ────────────────────────────────────────────────

    def _reload_hdu_lists(self):
        self.sed_list = []
        with fits.open(self.sasp_data_path, mode="readonly", memmap=False) as base:
            for hdu in base:
                if isinstance(hdu, fits.BinTableHDU) and hdu.header.get("CTYPE","").upper()=="SED":
                    self.sed_list.append(hdu.header["EXTNAME"])

        self.filter_list = []; self.sensor_list = []
        for path in (self.sasp_data_path, self.user_custom_path):
            with fits.open(path, mode="readonly", memmap=False) as hdul:
                for hdu in hdul:
                    if not isinstance(hdu, fits.BinTableHDU): continue
                    c = hdu.header.get("CTYPE","").upper(); e = hdu.header.get("EXTNAME","")
                    if c=="FILTER": self.filter_list.append(e)
                    elif c=="SENSOR": self.sensor_list.append(e)
        self.sed_list.sort(); self.filter_list.sort(); self.sensor_list.sort()

    def load_settings(self):
        s = QSettings()
        def apply(cb, key):
            val = s.value(key, "")
            if val:
                idx = cb.findText(val)
                if idx != -1:
                    cb.setCurrentIndex(idx)

        # existing stuff...
        saved_star = QSettings().value("SFCC/WhiteReference", "")
        if saved_star:
            idx = self.star_combo.findText(saved_star)
            if idx != -1:
                self.star_combo.setCurrentIndex(idx)
        use_gaia = s.value("SFCC/UseGaiaFallback", True, type=bool)
        if hasattr(self, "gaia_fallback_chk"):
            self.gaia_fallback_chk.setChecked(bool(use_gaia))
        apply(self.r_filter_combo, "SFCC/RFilter")
        apply(self.g_filter_combo, "SFCC/GFilter")
        apply(self.b_filter_combo, "SFCC/BFilter")
        apply(self.sens_combo,     "SFCC/Sensor")
        apply(self.lp_filter_combo,  "SFCC/LPFilter")
        apply(self.lp_filter_combo2, "SFCC/LPFilter2")

        # 👇 NEW: load SEP/star-detect threshold
        sep_thr = int(s.value("SFCC/SEPThreshold", 5))
        if hasattr(self, "sep_thr_spin"):
            self.sep_thr_spin.setValue(sep_thr)

        # Auto-σ waterfall preference (default: ON — removes guess-and-check)
        auto_sig = s.value("SFCC/AutoSigma", True, type=bool)
        if hasattr(self, "auto_sigma_chk"):
            self.auto_sigma_chk.setChecked(bool(auto_sig))
            # Keep spin box enabled state in sync with the restored value
            self.sep_thr_spin.setEnabled(not bool(auto_sig))
        use_cm = s.value("SFCC/UseColorMatrix", False, type=bool)
        if hasattr(self, "color_matrix_chk"):
            self.color_matrix_chk.setChecked(bool(use_cm))

    def save_sep_threshold_setting(self, v: int):
        QSettings().setValue("SFCC/SEPThreshold", int(v))

    # ── Auto-σ waterfall config / helpers ─────────────────────────────
    # Ladder of σ values tried from highest (strictest) to lowest.
    # Highest σ that still yields ≥ SFCC_AUTO_SIGMA_MIN_STARS wins.
    SFCC_AUTO_SIGMA_LADDER = (100.0, 50.0, 25.0, 12.0, 8.0, 5.0, 3.0)
    SFCC_AUTO_SIGMA_MIN_STARS = 1200

    def _on_auto_sigma_toggled(self, on: bool):
        try:
            self.sep_thr_spin.setEnabled(not bool(on))
        except Exception:
            pass
        QSettings().setValue("SFCC/AutoSigma", bool(on))

    def _auto_sigma_enabled(self) -> bool:
        try:
            return bool(self.auto_sigma_chk.isChecked())
        except Exception:
            return False

    def _sep_detect_waterfall(self, data_sub, err, *, status_prefix: str = ""):
        """
        Run sep.extract with the σ waterfall when Auto is enabled, or with
        the manual spin value when Auto is off.

        Returns (sources, used_sigma). `sources` may be empty if nothing was
        detected at any σ in the ladder — callers should handle that case
        exactly as they handled an empty result before.
        """
        if self._auto_sigma_enabled():
            last_sources = None
            last_sigma   = None
            for sig in self.SFCC_AUTO_SIGMA_LADDER:
                if status_prefix:
                    _sfcc_status(self, f"{status_prefix} (trying σ={sig:.1f})…")
                    QApplication.processEvents()
                try:
                    srcs = sep.extract(data_sub, float(sig), err=err)
                except Exception:
                    # Treat as "no detections at this σ" and keep stepping down
                    srcs = None
                last_sources = srcs
                last_sigma   = sig
                n = 0 if srcs is None else int(srcs.size)
                if n >= self.SFCC_AUTO_SIGMA_MIN_STARS:
                    if status_prefix:
                        _sfcc_status(
                            self,
                            f"{status_prefix} — auto σ={sig:.1f} → {n:,} sources."
                        )
                        QApplication.processEvents()
                    return srcs, float(sig)
            # Ladder exhausted — return the last (lowest-σ, most sensitive) try
            n = 0 if last_sources is None else int(last_sources.size)
            if status_prefix:
                _sfcc_status(
                    self,
                    f"{status_prefix} — auto σ ladder exhausted, using σ="
                    f"{(last_sigma or 3.0):.1f} ({n:,} sources)."
                )
                QApplication.processEvents()
            return (last_sources if last_sources is not None
                    else sep.extract(data_sub, 3.0, err=err)), float(last_sigma or 3.0)

        # Manual mode — single shot at the spin value
        sep_sigma = float(self.sep_thr_spin.value()) if hasattr(self, "sep_thr_spin") else 5.0
        if status_prefix:
            _sfcc_status(self, f"{status_prefix} (manual σ={sep_sigma:.1f})…")
            QApplication.processEvents()
        return sep.extract(data_sub, sep_sigma, err=err), sep_sigma

    def save_lp_setting(self, _):  QSettings().setValue("SFCC/LPFilter", self.lp_filter_combo.currentText())
    def save_lp2_setting(self, _): QSettings().setValue("SFCC/LPFilter2", self.lp_filter_combo2.currentText())
    def save_star_setting(self, _): QSettings().setValue("SFCC/WhiteReference", self.star_combo.currentText())
    def save_r_filter_setting(self, _): QSettings().setValue("SFCC/RFilter", self.r_filter_combo.currentText())
    def save_g_filter_setting(self, _): QSettings().setValue("SFCC/GFilter", self.g_filter_combo.currentText())
    def save_b_filter_setting(self, _): QSettings().setValue("SFCC/BFilter", self.b_filter_combo.currentText())
    def save_sensor_setting(self, _):   QSettings().setValue("SFCC/Sensor", self.sens_combo.currentText())
    def save_gaia_fallback_setting(self, v: bool):
        QSettings().setValue("SFCC/UseGaiaFallback", bool(v))

    # ── Curve utilities ─────────────────────────────────────────────────
    def _use_gaia_fallback(self) -> bool:
        return bool(self._gaia_enabled())


    def interpolate_bad_points(self, wl, tr):
        tr = tr.copy()
        bad = (tr < 0.0) | (tr > 1.0)
        good = ~bad
        if not np.any(bad): return tr, np.array([], dtype=int)
        if np.sum(good) < 2: raise RuntimeError("Not enough valid points to interpolate anomalies.")
        tr_corr = tr.copy()
        tr_corr[bad] = np.interp(wl[bad], wl[good], tr[good])
        return tr_corr, np.where(bad)[0]

    def smooth_curve(self, tr, window_size=5):
        return medfilt(tr, kernel_size=window_size)

    def get_calibration_points(self, rgb_img: np.ndarray):
        print("\nClick three calibration points: BL (λmin,0), BR (λmax,0), TL (λmin,1)")
        fig, ax = plt.subplots(figsize=(8, 5)); ax.imshow(rgb_img); ax.set_title(self.tr("Click 3 points, then close"))
        pts = plt.ginput(3, timeout=-1); plt.close(fig)
        if len(pts) != 3: raise RuntimeError(self.tr("Need exactly three clicks for calibration."))
        return pts[0], pts[1], pts[2]

    def build_transforms(self, px_bl, py_bl, px_br, py_br, px_tl, py_tl, λ_min, λ_max, resp_min, resp_max):
        nm_per_px = (λ_max - λ_min) / (px_br - px_bl)
        resp_per_px = (resp_max - resp_min) / (py_bl - py_tl)
        def px_to_λ(px):  return λ_min + (px - px_bl) * nm_per_px
        def py_to_resp(py): return resp_max - (py - py_tl) * resp_per_px
        return px_to_λ, py_to_resp

    def extract_curve(self, gray_img, λ_mapper, resp_mapper, λ_min, λ_max, threshold=50):
        H, W = gray_img.shape
        data = []
        for px in range(W):
            col = gray_img[:, px]
            py_min = int(np.argmin(col)); val_min = int(col[py_min])
            if val_min < threshold:
                lam = λ_mapper(px)
                if λ_min <= lam <= λ_max:
                    data.append((lam, resp_mapper(py_min)))
        if not data:
            raise RuntimeError("No dark pixels found; raise threshold or adjust clicks.")
        df = (pd.DataFrame(data, columns=["wavelength_nm", "response"])
                .sort_values("wavelength_nm").reset_index(drop=True))
        df = df[(df["wavelength_nm"] >= λ_min) & (df["wavelength_nm"] <= λ_max)].copy()
        if df["wavelength_nm"].iloc[0] > λ_min:
            df = pd.concat([pd.DataFrame([[λ_min, 0.0]], columns=["wavelength_nm", "response"]), df], ignore_index=True)
        if df["wavelength_nm"].iloc[-1] < λ_max:
            df = pd.concat([df, pd.DataFrame([[λ_max, 0.0]], columns=["wavelength_nm", "response"])], ignore_index=True)
        return df.sort_values("wavelength_nm").reset_index(drop=True)

    def _query_name_channel(self):
        name_str, ok1 = QInputDialog.getText(self, self.tr("Curve Name"), self.tr("Enter curve name (EXTNAME):"))
        if not (ok1 and name_str.strip()): return False, None, None
        extname = name_str.strip().upper().replace(" ", "_")
        ch_str, ok2 = QInputDialog.getText(self, self.tr("Channel"), self.tr("Enter channel (R,G,B or Q for sensor):"))
        if not (ok2 and ch_str.strip()): return False, None, None
        return True, extname, ch_str.strip().upper()

    def _append_curve_hdu(self, wl_ang, tr_final, extname, ctype, origin):
        col_wl = fits.Column(name="WAVELENGTH", format="E", unit="Angstrom", array=wl_ang.astype(np.float32))
        col_tr = fits.Column(name="THROUGHPUT", format="E", unit="REL",      array=tr_final.astype(np.float32))
        new_hdu = fits.BinTableHDU.from_columns([col_wl, col_tr])
        new_hdu.header["EXTNAME"] = extname
        new_hdu.header["CTYPE"]   = ctype
        new_hdu.header["ORIGIN"]  = origin
        with fits.open(self.user_custom_path, mode="update", memmap=False) as hdul:
            hdul.append(new_hdu); hdul.flush()

    def add_custom_curve(self):
        msg = QMessageBox(self); msg.setWindowTitle(self.tr("Add Custom Curve")); msg.setText(self.tr("Choose how to add the curve:"))
        csv_btn = msg.addButton(self.tr("Import CSV"), QMessageBox.ButtonRole.AcceptRole)
        img_btn = msg.addButton(self.tr("Digitize Image"), QMessageBox.ButtonRole.AcceptRole)
        cancel_btn = msg.addButton(QMessageBox.StandardButton.Cancel)
        msg.exec()
        if msg.clickedButton() == csv_btn: self._import_curve_from_csv()
        elif msg.clickedButton() == img_btn: self._digitize_curve_from_image()

    def _import_curve_from_csv(self):
        csv_path, _ = QFileDialog.getOpenFileName(self, self.tr("Select 2-column CSV (λ_nm, response)"), "", "CSV Files (*.csv);;All Files (*)")
        if not csv_path: return
        try:
            df = (pd.read_csv(csv_path, comment="#", header=None).iloc[:, :2].dropna())
            df.columns = ["wavelength_nm","response"]
            wl_nm = df["wavelength_nm"].astype(float).to_numpy(); tp = df["response"].astype(float).to_numpy()
        except ValueError:
            try:
                df = (pd.read_csv(csv_path, comment="#", header=0).iloc[:, :2].dropna())
                df.columns = ["wavelength_nm","response"]
                wl_nm = df["wavelength_nm"].astype(float).to_numpy(); tp = df["response"].astype(float).to_numpy()
            except Exception as e2:
                QMessageBox.critical(self, self.tr("CSV Error"), self.tr("Could not read CSV:\n{0}").format(e2)); return
        except Exception as e:
            QMessageBox.critical(self, self.tr("CSV Error"), self.tr("Could not read CSV:\n{0}").format(e)); return

        ok, extname_base, channel_val = self._query_name_channel()
        if not ok: return
        wl_ang = (wl_nm * 10.0).astype(np.float32); tr_final = tp.astype(np.float32)
        self._append_curve_hdu(wl_ang, tr_final, extname_base, "SENSOR" if channel_val=="Q" else "FILTER", f"CSV:{os.path.basename(csv_path)}")
        self._reload_hdu_lists(); self.refresh_filter_sensor_lists()
        QMessageBox.information(self, self.tr("Done"), self.tr("CSV curve '{0}' added.").format(extname_base))

    def _digitize_curve_from_image(self):
        img_path_str, _ = QFileDialog.getOpenFileName(self, self.tr("Select Curve Image to Digitize"), "", "Images (*.png *.jpg *.jpeg *.bmp);;All Files (*)")
        if not img_path_str: return
        img_filename = os.path.basename(img_path_str)
        try:
            bgr = cv2.imread(img_path_str)
            if bgr is None: raise RuntimeError(f"cv2.imread returned None for '{img_path_str}'")
            rgb_img = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB); gray_img = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        except Exception as e:
            QMessageBox.critical(self, self.tr("Error"), self.tr("Could not load image:\n{0}").format(e)); return

        try:
            (px_bl, py_bl), (px_br, py_br), (px_tl, py_tl) = self.get_calibration_points(rgb_img)
        except Exception as e:
            QMessageBox.critical(self, self.tr("Digitization Error"), str(e)); return

        λ_min_str, ok1 = QInputDialog.getText(self, self.tr("λ_min"), self.tr("Enter λ_min (in nm):"))
        λ_max_str, ok2 = QInputDialog.getText(self, self.tr("λ_max"), self.tr("Enter λ_max (in nm):"))
        if not (ok1 and ok2 and λ_min_str.strip() and λ_max_str.strip()): return
        try:
            λ_min = float(λ_min_str); λ_max = float(λ_max_str)
        except ValueError:
            QMessageBox.critical(self, self.tr("Input Error"), self.tr("λ_min and λ_max must be numbers.")); return

        ok, extname_base, channel_val = self._query_name_channel()
        if not ok: return

        px_to_λ, py_to_resp = self.build_transforms(px_bl, py_bl, px_br, py_br, px_tl, py_tl, λ_min, λ_max, 0.0, 1.0)
        try:
            df_curve = self.extract_curve(gray_img, px_to_λ, py_to_resp, λ_min, λ_max, threshold=50)
        except Exception as e:
            QMessageBox.critical(self, self.tr("Extraction Error"), str(e)); return

        df_curve["wl_int"] = df_curve["wavelength_nm"].round().astype(int)
        grp = (df_curve.groupby("wl_int")["response"].median().reset_index().sort_values("wl_int"))
        wl = grp["wl_int"].to_numpy(dtype=int); tr = grp["response"].to_numpy(dtype=float)

        try:
            tr_corr, _ = self.interpolate_bad_points(wl, tr)
        except Exception as e:
            QMessageBox.critical(self, self.tr("Interpolation Error"), str(e)); return

        tr_smoothed = self.smooth_curve(tr_corr, window_size=5)
        wl_ang = (wl.astype(float) * 10.0).astype(np.float32); tr_final = tr_smoothed.astype(np.float32)
        self._append_curve_hdu(wl_ang, tr_final, extname_base, "SENSOR" if channel_val=="Q" else "FILTER", f"UserDefined:{img_filename}")
        self._reload_hdu_lists(); self.refresh_filter_sensor_lists()
        QMessageBox.information(self, self.tr("Done"), self.tr("Added curve '{0}'.").format(extname_base))

    def remove_custom_curve(self):
        all_curves = self.filter_list + self.sensor_list
        if not all_curves:
            QMessageBox.information(self, self.tr("Remove Curve"), self.tr("No custom curves to remove.")); return
        curve, ok = QInputDialog.getItem(self, self.tr("Remove Curve"), self.tr("Select a FILTER or SENSOR curve to delete:"), all_curves, 0, False)
        if not ok or not curve: return
        reply = QMessageBox.question(self, self.tr("Confirm Deletion"), self.tr("Delete '{0}'?").format(curve), QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply != QMessageBox.StandardButton.Yes: return

        temp_path = self.user_custom_path + ".tmp"
        try:
            with fits.open(self.user_custom_path, memmap=False) as old_hdul:
                new_hdus = []
                for hdu in old_hdul:
                    if hdu is old_hdul[0]:
                        new_hdus.append(hdu.copy())
                    else:
                        if hdu.header.get("EXTNAME") != curve:
                            new_hdus.append(hdu.copy())
            fits.HDUList(new_hdus).writeto(temp_path, overwrite=True)
            os.replace(temp_path, self.user_custom_path)
        except Exception as e:
            if os.path.exists(temp_path): os.remove(temp_path)
            QMessageBox.critical(self, "Write Error", f"Could not remove curve:\n{e}"); return

        self._reload_hdu_lists(); self.refresh_filter_sensor_lists()
        QMessageBox.information(self, self.tr("Removed"), self.tr("Deleted curve '{0}'.").format(curve))

    def refresh_filter_sensor_lists(self):
        self._reload_hdu_lists()
        current_r = self.r_filter_combo.currentText()
        current_g = self.g_filter_combo.currentText()
        current_b = self.b_filter_combo.currentText()
        current_s = self.sens_combo.currentText()
        current_lp  = self.lp_filter_combo.currentText()
        current_lp2 = self.lp_filter_combo2.currentText()

        for cb, lst, prev in [
            (self.r_filter_combo, self.filter_list, current_r),
            (self.g_filter_combo, self.filter_list, current_g),
            (self.b_filter_combo, self.filter_list, current_b),
        ]:
            cb.clear(); cb.addItem("(None)"); cb.addItems(lst)
            idx = cb.findText(prev);  cb.setCurrentIndex(idx if idx != -1 else 0)

        for cb, prev in [(self.lp_filter_combo, current_lp), (self.lp_filter_combo2, current_lp2)]:
            cb.clear(); cb.addItem("(None)"); cb.addItems(self.filter_list)
            idx = cb.findText(prev);  cb.setCurrentIndex(idx if idx != -1 else 0)

        self.sens_combo.clear(); self.sens_combo.addItem("(None)"); self.sens_combo.addItems(self.sensor_list)
        idx = self.sens_combo.findText(current_s); self.sens_combo.setCurrentIndex(idx if idx != -1 else 0)

    # ── WCS utilities ──────────────────────────────────────────────────
    def calculate_orientation(self, header):
        try:
            cd1_1 = float(header.get("CD1_1", 0.0))
            cd1_2 = float(header.get("CD1_2", 0.0))
            return math.degrees(math.atan2(cd1_2, cd1_1))
        except Exception:
            return None

    def calculate_ra_dec_from_pixel(self, x, y):
        if not hasattr(self, "wcs"): return None, None
        return self.wcs.all_pix2world(x, y, 0)

    # ── Background neutralization ───────────────────────────────────────
    def _neutralize_background(self, rgb_f: np.ndarray, *, remove_pedestal: bool = False) -> np.ndarray:
        img = np.asarray(rgb_f, dtype=np.float32)

        if img.ndim != 3 or img.shape[2] != 3:
            raise ValueError("Expected RGB image (H,W,3)")

        img = np.clip(img, 0.0, 1.0)

        try:
            rect = auto_rect_50x50(img)  # same SASv2-ish auto finder
            out = background_neutralize_rgb(
                img,
                rect,
                mode="pivot1",                # or "offset" if you prefer
                remove_pedestal=remove_pedestal,
            )
            return np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)

        except Exception as e:
            print(f"[SPCC] BN preset failed, falling back to simple neutralization: {e}")
            return self._neutralize_background_simple(img, patch_size=10)

    def _neutralize_background_simple(self, rgb_f: np.ndarray, patch_size: int = 50) -> np.ndarray:
        """
        Simple neutralization: find darkest patch by summed medians,
        then equalize channel medians around the mean.
        Assumes rgb_f is float in [0,1] with no negatives.
        """
        img = np.asarray(rgb_f, dtype=np.float32).copy()
        h, w = img.shape[:2]
        ph, pw = max(1, h // patch_size), max(1, w // patch_size)

        min_sum, best_med = np.inf, None
        for i in range(patch_size):
            for j in range(patch_size):
                y0, x0 = i * ph, j * pw
                patch = img[y0:min(y0 + ph, h), x0:min(x0 + pw, w), :]
                if patch.size == 0:
                    continue
                med = np.median(patch, axis=(0, 1))
                s = float(med.sum())
                if s < min_sum:
                    min_sum, best_med = s, med

        if best_med is None:
            return np.clip(img, 0.0, 1.0)

        target = float(best_med.mean())
        eps = 1e-8
        for c in range(3):
            diff = float(best_med[c] - target)
            if abs(diff) < eps:
                continue
            # Preserve [0,1] scale; keep the same form you were using.
            img[..., c] = np.clip((img[..., c] - diff) / (1.0 - diff), 0.0, 1.0)

        return np.clip(img, 0.0, 1.0)

    def _make_working_base_for_sep(self, img_float: np.ndarray) -> np.ndarray:
        """
        Build a working copy for SEP.

        IMPORTANT:
        - Do NOT do per-channel pedestal removal if you use annulus background subtraction.
        - Keep values stable for SEP by clamping to [0,1] (optional).
        """
        base = np.asarray(img_float, dtype=np.float32, order="C").copy()

        if base.ndim != 3 or base.shape[2] != 3:
            raise ValueError("Expected RGB image (H,W,3)")

        # Optional: clamp only (no shifting)
        base = np.clip(base, 0.0, 1.0)

        return base



    # ── SIMBAD/Star fetch ──────────────────────────────────────────────
    def initialize_wcs_from_header(self, header):
        """
        Build a robust 2D celestial WCS from the provided header.

        - Normalizes deprecated RADECSYS/EPOCH keywords.
        - Uses relax=True.
        - Stores:
            self.wcs (WCS)
            self.wcs_header (fits.Header)
            self.pixscale (arcsec/pixel approx)
            self.center_ra, self.center_dec (deg)
            self.orientation (deg, if derivable)
        """
        if header is None:
            print("[SPCC] No FITS header available; cannot build WCS.")
            self.wcs = None
            return

        try:
            hdr = header.copy()

            # --- normalize deprecated keywords ---
            if "RADECSYS" in hdr and "RADESYS" not in hdr:
                radesys_val = str(hdr["RADECSYS"]).strip()
                hdr["RADESYS"] = radesys_val
                try:
                    del hdr["RADECSYS"]
                except Exception:
                    pass

                # Carry to alternate WCS letters if present (CTYPE1A, CTYPE2A, etc.)
                alt_letters = {
                    k[-1]
                    for k in hdr.keys()
                    if re.match(r"^CTYPE[12][A-Z]$", k)
                }
                for a in alt_letters:
                    key = f"RADESYS{a}"
                    if key not in hdr:
                        hdr[key] = radesys_val

            if "EPOCH" in hdr and "EQUINOX" not in hdr:
                hdr["EQUINOX"] = hdr["EPOCH"]
                try:
                    del hdr["EPOCH"]
                except Exception:
                    pass

            # Build WCS
            self.wcs = WCS(hdr, naxis=2, relax=True)

            # Pixel scale estimate (arcsec/px) from pixel_scale_matrix if available
            try:
                psm = self.wcs.pixel_scale_matrix
                self.pixscale = float(np.hypot(psm[0, 0], psm[1, 0]) * 3600.0)
            except Exception:
                self.pixscale = None

            # CRVAL center
            try:
                self.center_ra, self.center_dec = [float(x) for x in self.wcs.wcs.crval]
            except Exception:
                self.center_ra, self.center_dec = None, None

            # Save normalized header form
            try:
                self.wcs_header = self.wcs.to_header(relax=True)
            except Exception:
                self.wcs_header = None

            # Orientation (optional)
            if "CROTA2" in hdr:
                try:
                    self.orientation = float(hdr["CROTA2"])
                except Exception:
                    self.orientation = None
            else:
                self.orientation = self.calculate_orientation(hdr)


        except Exception as e:
            print("[SPCC] WCS initialization error:\n", e)
            self.wcs = None

    # ── Gaia XP fallback helpers ─────────────────────────────────────────
    def _gaia_enabled(self) -> bool:
        return (GaiaDownloader is not None) and bool(HAS_GAIAXPY)
    
    def _get_gaia_downloader(self):
        """
        Lazy init: downloader holds sqlite DB connection.
        """
        if not hasattr(self, "_gaia_dl") or self._gaia_dl is None:
            self._gaia_dl = GaiaDownloader(self._gaia_db_path())
        return self._gaia_dl

    def _query_gaia_sources_in_field(
        self,
        center_ra_deg: float,
        center_dec_deg: float,
        radius_deg: float,
        mag_limit: float = 15.5,
        max_rows: int = 200000,
        retries: int = 5,
        base_delay: float = 1.5,
    ) -> list[dict]:
        """
        Query Gaia DR3 sources in field that have XP continuous spectra.
        Returns dicts with: source_id, ra, dec, gmag, bp_rp

        Also stores query status on self:
            self._last_gaia_query_ok
            self._last_gaia_query_error
            self._last_gaia_query_attempts
        """
        self._last_gaia_query_ok = False
        self._last_gaia_query_error = None
        self._last_gaia_query_attempts = 0

        Gaia = _get_sfcc_gaia_tap()
        if Gaia is None:
            self._last_gaia_query_error = "Gaia astroquery module unavailable"
            return []

        Gaia.ROW_LIMIT = max_rows
        # ── DR4 migration note ────────────────────────────────────────────
        # When Gaia DR4 releases, update:
        #   gaiadr3.gaia_source  →  gaiadr4.gaia_source  (or gaiaedr4 if early)
        #   has_xp_continuous    →  verify column still exists / same name
        #   mag limit 15.5       →  DR4 XP coverage extends fainter, consider 16.5+
        # ─────────────────────────────────────────────────────────────────
        adql = f"""
        SELECT
            source_id, ra, dec, phot_g_mean_mag, bp_rp
        FROM gaiadr3.gaia_source
        WHERE 1=CONTAINS(
            POINT('ICRS', ra, dec),
            CIRCLE('ICRS', {center_ra_deg}, {center_dec_deg}, {radius_deg})
        )
        AND has_xp_continuous = 'True'
        AND phot_g_mean_mag <= {float(mag_limit)}
        """

        tab = None
        last_err = None

        for attempt in range(1, int(retries) + 1):
            self._last_gaia_query_attempts = attempt
            try:
                msg = f"[SPCC] Gaia query attempt {attempt}/{retries}..."
                print(msg)
                if getattr(self, "count_label", None) is not None:
                    self.count_label.setText(msg)
                QApplication.processEvents()

                def _gaia_tap_query():
                    _job = Gaia.launch_job_async(adql, dump_to_file=False)
                    return _job.get_results()
                tab = run_async_blocking(
                    _gaia_tap_query, parent=self, title="SFCC",
                    label="Querying Gaia archive…", cancellable=False,
                )

                self._last_gaia_query_ok = True
                self._last_gaia_query_error = None
                print(f"[SPCC] Gaia query succeeded on attempt {attempt}/{retries}")
                break

            except Exception as e:
                last_err = e
                self._last_gaia_query_error = str(e)
                print(f"[SPCC] Gaia query failed on attempt {attempt}/{retries}: {e}")

                if attempt >= retries:
                    break

                delay = float(base_delay) * attempt
                retry_msg = f"[SPCC] Gaia query retrying in {delay:.1f}s..."
                print(retry_msg)
                if getattr(self, "count_label", None) is not None:
                    self.count_label.setText(retry_msg)
                QApplication.processEvents()
                non_blocking_sleep(delay)

        if tab is None:
            self._last_gaia_query_ok = False
            print(f"[SPCC] Gaia query failed after {retries} attempts: {last_err}")
            return []

        out = []
        for row in tab:
            try:
                out.append({
                    "source_id": int(row["source_id"]),
                    "ra": float(row["ra"]),
                    "dec": float(row["dec"]),
                    "gmag": float(row["phot_g_mean_mag"]) if row["phot_g_mean_mag"] is not None else None,
                    "bp_rp": float(row["bp_rp"]) if row["bp_rp"] is not None else None,
                })
            except Exception:
                continue

        print(f"[SPCC] Gaia query returned {len(out)} sources")
        return out

    @staticmethod
    def _angsep2_arcsec(ra1, dec1, ra2, dec2) -> float:
        """
        Small-angle approx angular separation in arcsec (good enough for <= few arcsec matching).
        """
        dra = (ra1 - ra2) * math.cos(math.radians((dec1 + dec2) * 0.5))
        ddec = (dec1 - dec2)
        return 3600.0 * math.hypot(dra, ddec)

    def _attach_gaia_ids_to_star_list(
        self,
        *,
        radius_deg: float,
        mag_limit: float = 15.5,
        max_match_arcsec: float = 10.0
    ):
        if not self._gaia_enabled():
            return {
                "query_ok": False,
                "query_error": "Gaia fallback unavailable",
                "gaia_source_count": 0,
                "matched_star_count": 0,
                "needed_star_count": 0,
            }

        if not getattr(self, "center_ra", None) or not getattr(self, "center_dec", None):
            return {
                "query_ok": False,
                "query_error": "Missing field center RA/Dec",
                "gaia_source_count": 0,
                "matched_star_count": 0,
                "needed_star_count": 0,
            }

        needed_star_count = sum(
            1 for st in self.star_list
            if (not st.get("sp_clean")) or (st.get("pickles_match") is None)
        )

        gaia_sources = []

        try:
            from setiastro.saspro.gaia_database import get_library
            lib = get_library()
            if lib.installed_bands():
                _sfcc_status(self, "[SPCC] Matching SIMBAD stars to Gaia source_ids via SIMBAD ids…")
                QApplication.processEvents()

                # ── Step 1: SIMBAD ids batch query for exact Gaia DR3 source_ids ──
                needed_stars = [
                    st for st in self.star_list
                    if ((not st.get("sp_clean")) or (st.get("pickles_match") is None))
                ]
                main_ids_needed = [
                    st["main_id"] for st in needed_stars if st.get("main_id")
                ]

                simbad_to_gaia: Dict[str, int] = {}
                if main_ids_needed and cds_health.simbad_available(
                        status_cb=lambda m: _sfcc_status(self, m)):
                    s = Simbad()
                    try:
                        s.add_votable_fields("ids")
                    except Exception as e:
                        cds_health.note_failure(e, context="add_votable_fields/ids")
                        main_ids_needed = []
                    _ids_budget = cds_health.Budget(30.0)
                    BATCH = 200
                    for i in range(0, len(main_ids_needed), BATCH):
                        # Once the breaker is open or the budget is spent,
                        # abandon the whole loop rather than paying a full
                        # timeout per remaining batch.
                        if _ids_budget.expired() or not cds_health.simbad_available():
                            _sfcc_status(self,
                                "SIMBAD unavailable — skipping remaining id batches.")
                            break
                        batch = main_ids_needed[i:i + BATCH]
                        try:
                            res = s.query_objects(batch)
                            if res is None:
                                continue
                            ids_col = next(
                                (c for c in res.colnames if c.upper() == "IDS"), None)
                            main_id_col = next(
                                (c for c in res.colnames if c.upper() == "MAIN_ID"), None)
                            if ids_col is None:
                                continue
                            for row in res:
                                obj_name = str(row[main_id_col]).strip() if main_id_col else ""
                                ids_str  = str(row[ids_col])
                                for part in ids_str.split("|"):
                                    part = part.strip()
                                    if part.startswith("Gaia DR3 "):
                                        try:
                                            sid = int(part.replace("Gaia DR3 ", "").strip())
                                            simbad_to_gaia[obj_name] = sid
                                        except ValueError:
                                            pass
                                        break
                        except Exception as e:
                            print(f"[SPCC] SIMBAD ids batch failed: {e}")
                            if cds_health.note_failure(e, context="query_objects/ids"):
                                _sfcc_status(self,
                                    "SIMBAD unreachable — skipping remaining id batches.")
                                break
                            continue

                _sfcc_status(self,
                    f"[SPCC] SIMBAD ids resolved {len(simbad_to_gaia)} Gaia DR3 source_ids — "
                    f"running batch spatial match for remainder…")
                QApplication.processEvents()

                # ── Step 2: assign source_ids from SIMBAD ids where available ──
                unmatched_indices = []   # indices into needed_stars that still need positional match
                for idx, st in enumerate(needed_stars):
                    main_id = st.get("main_id")
                    if main_id and main_id in simbad_to_gaia:
                        candidate = simbad_to_gaia[main_id]
                        if lib.has_spectrum(candidate):
                            info = lib.get_source_info(candidate)
                            st["gaia_source_id"]  = int(candidate)
                            st["gaia_bp_rp"]      = None
                            st["gaia_gmag"]       = info["gmag"] if info else None
                            st["gaia_sep_arcsec"] = 0.0
                            st["sp_source"]       = "gaia_xp"
                            gaia_sources.append({"source_id": int(candidate)})
                            continue
                    unmatched_indices.append(idx)

                # ── Step 3: batch spatial match for stars not resolved via SIMBAD ids ──
                if unmatched_indices:
                    _sfcc_status(self,
                        f"[SPCC] Batch spatial match for {len(unmatched_indices)} "
                        f"unresolved stars…")
                    QApplication.processEvents()

                    batch_coords = [
                        (float(needed_stars[i]["ra"]), float(needed_stars[i]["dec"]))
                        for i in unmatched_indices
                    ]
                    batch_results = lib.find_nearest_batch(
                        batch_coords, radius_arcsec=max_match_arcsec)

                    for local_idx, (sid, sep_arcsec) in batch_results.items():
                        st = needed_stars[unmatched_indices[local_idx]]
                        info = lib.get_source_info(sid)
                        st["gaia_source_id"]  = int(sid)
                        st["gaia_bp_rp"]      = None
                        st["gaia_gmag"]       = info["gmag"] if info else None
                        st["gaia_sep_arcsec"] = float(sep_arcsec)
                        st["sp_source"]       = "gaia_xp"
                        gaia_sources.append({"source_id": int(sid)})

                matched_star_count = sum(
                    1 for st in self.star_list
                    if st.get("gaia_source_id") is not None
                    and st.get("sp_source") == "gaia_xp"
                )
                simbad_matched = len(simbad_to_gaia)
                positional_matched = matched_star_count - simbad_matched
                _sfcc_status(self,
                    f"[SPCC] Bulk library match: {matched_star_count} of {needed_star_count} "
                    f"fallback stars matched ({simbad_matched} via SIMBAD ids, "
                    f"{positional_matched} via position) — no Gaia archive query needed.")
                return {
                    "query_ok": True,
                    "query_error": None,
                    "gaia_source_count": len(gaia_sources),
                    "matched_star_count": matched_star_count,
                    "needed_star_count": needed_star_count,
                }
        except Exception as e:
            print(f"[SPCC] Bulk library match failed, falling back to archive: {e}")

        # ── Fall back to Gaia archive query ───────────────────────────────
        _sfcc_status(self, "[SPCC] Matching SIMBAD stars to Gaia source_ids via archive…")
        QApplication.processEvents()

        gaia_sources = self._query_gaia_sources_in_field(
            self.center_ra,
            self.center_dec,
            radius_deg,
            mag_limit=mag_limit
        )

        query_ok = bool(getattr(self, "_last_gaia_query_ok", False))
        query_error = getattr(self, "_last_gaia_query_error", None)

        if not gaia_sources:
            return {
                "query_ok": query_ok,
                "query_error": query_error,
                "gaia_source_count": 0,
                "matched_star_count": 0,
                "needed_star_count": needed_star_count,
            }

        try:
            dl = self._get_gaia_downloader()
            for s in gaia_sources:
                try:
                    dl.db._conn.execute(
                        "INSERT OR IGNORE INTO sources "
                        "(source_id, ra, dec, phot_g_mean_mag, bp_rp) VALUES (?,?,?,?,?)",
                        (s["source_id"], s["ra"], s["dec"], s.get("gmag"), s.get("bp_rp"))
                    )
                except Exception:
                    pass
            dl.db._conn.commit()
        except Exception:
            pass

        matched_star_count = 0
        for st in self.star_list:
            needs_gaia = (not st.get("sp_clean")) or (st.get("pickles_match") is None)
            if not needs_gaia:
                continue

            ra  = float(st["ra"])
            dec = float(st["dec"])
            best     = None
            best_sep = 1e9

            for gs in gaia_sources:
                sep_as = self._angsep2_arcsec(ra, dec, gs["ra"], gs["dec"])
                if sep_as < best_sep:
                    best_sep = sep_as
                    best = gs

            if best is not None and best_sep <= float(max_match_arcsec):
                st["gaia_source_id"]  = int(best["source_id"])
                st["gaia_bp_rp"]      = best.get("bp_rp")
                st["gaia_gmag"]       = best.get("gmag")
                st["gaia_sep_arcsec"] = float(best_sep)
                st["sp_source"]       = "gaia_xp"
                matched_star_count   += 1

        return {
            "query_ok": query_ok,
            "query_error": query_error,
            "gaia_source_count": len(gaia_sources),
            "matched_star_count": matched_star_count,
            "needed_star_count": needed_star_count,
        }

    def _download_gaia_spectra_with_progress(
        self,
        missing_spectra: list,
        dl,
        batch_size: int = 25,
    ) -> int:
        from PyQt6.QtWidgets import QProgressDialog
        from PyQt6.QtCore import Qt, QEventLoop

        total = len(missing_spectra)

        dlg = QProgressDialog(
            f"Downloading Gaia XP spectra (0/{total})…\n"
            f"Gaia archive may be slow — please wait.",
            "Cancel",
            0, total,
            self,
        )
        dlg.setWindowTitle("Gaia XP Spectra Download")
        dlg.setWindowModality(Qt.WindowModality.WindowModal)
        dlg.setMinimumDuration(0)
        dlg.setMinimumWidth(460)
        dlg.setValue(0)
        dlg.setAutoClose(False)
        dlg.setAutoReset(False)
        dlg.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)
        dlg.show()

        loop = QEventLoop()
        stored = 0
        _cancelled = False

        # This flag gates closeEvent — set True only after thread is done.
        _allow_close = False

        # Patch closeEvent on the instance to block closing until we allow it.
        def _blocked_close(event):
            if _allow_close:
                event.accept()
            else:
                event.ignore()
        dlg.closeEvent = _blocked_close

        worker = _GaiaSpectraWorker(dl, missing_spectra, batch_size=batch_size, parent=None)

        def _on_progress(done, total_, msg):
            if _cancelled:
                dlg.setLabelText(
                    f"Cancelling… waiting for current batch to finish.\n"
                    f"({done}/{total_} downloaded so far — please wait)\n\n"
                    f"Please do not close this window."
                )
            else:
                dlg.setValue(done)
                dlg.setLabelText(msg)

        def _on_finished(n):
            nonlocal stored
            stored = n
            loop.quit()

        def _on_failed(err):
            loop.quit()

        def _on_cancel():
            nonlocal _cancelled
            _cancelled = True
            worker.cancel()
            # Qt has already hidden the dialog by the time this slot runs.
            # Show it again and lock it down.
            dlg.setCancelButton(None)
            dlg.setLabelText(
                "Cancelling… waiting for current batch to finish.\n"
                "Please wait — this may take 1–3 minutes.\n\n"
                "Please do not close this window."
            )
            dlg.show()
            dlg.raise_()
            # Do NOT call loop.quit() — wait for _on_finished/_on_failed.

        worker.progress.connect(_on_progress)
        worker.finished.connect(_on_finished)
        worker.failed.connect(_on_failed)
        dlg.canceled.connect(_on_cancel)

        worker.start()
        loop.exec()  # only exits via _on_finished or _on_failed

        if worker.isRunning():
            worker.wait()

        _allow_close = True
        dlg.close()
        return stored

    def _gaia_integrals_for_source_ids(
        self,
        source_ids: list[int],
        wl_grid_ang: np.ndarray,
        T_sys_R: np.ndarray,
        T_sys_G: np.ndarray,
        T_sys_B: np.ndarray,
        *,
        batch_size: int = 25,
    ) -> dict[int, tuple[float, float, float]]:
        """
        Ensure Gaia XP spectra exist in the local cache (download missing ones),
        then integrate Gaia flux * throughput over wl_grid_ang (Å).

        Also caches the synthetic photometry integrals (Sr,Sg,Sb) per (source_id, system_key)
        so subsequent runs are fast.

        Returns dict: source_id -> (S_R, S_G, S_B)
        """
        if not self._gaia_enabled():
            return {}

        dl = self._get_gaia_downloader()

        # ---- sanity on arrays (avoid subtle shape bugs) ----
        wl_grid_ang = np.asarray(wl_grid_ang, dtype=np.float64).reshape(-1)
        T_sys_R = np.asarray(T_sys_R, dtype=np.float64).reshape(-1)
        T_sys_G = np.asarray(T_sys_G, dtype=np.float64).reshape(-1)
        T_sys_B = np.asarray(T_sys_B, dtype=np.float64).reshape(-1)

        n = wl_grid_ang.size
        if not (T_sys_R.size == T_sys_G.size == T_sys_B.size == n):
            raise ValueError(
                f"Throughput arrays must match wl_grid_ang length. "
                f"len(wl)={n}, len(R)={T_sys_R.size}, len(G)={T_sys_G.size}, len(B)={T_sys_B.size}"
            )

        # Normalize + uniquify IDs
        source_ids_i = [int(s) for s in source_ids if s is not None]
        if not source_ids_i:
            return {}

        # Keep order stable but avoid redoing work for duplicates
        seen = set()
        ordered_unique: list[int] = []
        for sid in source_ids_i:
            if sid not in seen:
                seen.add(sid)
                ordered_unique.append(sid)

        # ---- synthetic photometry cache key (depends on wl grid + throughputs) ----
        system_key = dl.db.make_system_key(
            wl_grid_ang, T_sys_R, T_sys_G, T_sys_B, tag="spcc_v1"
        )

        # ---- pull cached integrals first ----
        out: dict[int, tuple[float, float, float]] = {}
        try:
            cached = dl.db.get_synth_phot(ordered_unique, system_key)
            out.update(cached)
        except Exception as e:
            print(f"[SPCC] Gaia synth cache read failed (continuing): {e}")
            cached = {}

        missing_integrals = [sid for sid in ordered_unique if sid not in out]
        if not missing_integrals:
            if getattr(self, "count_label", None) is not None:
                self.count_label.setText(f"Gaia XP: synthetic photometry cache hit ({len(out)} sources).")
            return out
        else:
            if getattr(self, "count_label", None) is not None:
                self.count_label.setText(
                    f"Gaia XP: cache miss for {len(missing_integrals)} sources — preparing spectra…"
                )


        # ---- ensure spectra exist for those missing integrals ----
        missing_spectra: list[int] = []
        for sid in missing_integrals:
            try:
                if dl.db.get_spectrum(int(sid)) is None:
                    missing_spectra.append(int(sid))
            except Exception:
                missing_spectra.append(int(sid))

        # Download missing spectra in batches (GaiaXPy calibrate)
        if missing_spectra:
            try:
                dl_worker = GaiaDownloader(dl.db.db_path)
                self._download_gaia_spectra_with_progress(
                    missing_spectra, dl_worker, batch_size=batch_size
                )
                dl_worker.close()
            except Exception as e:
                print(f"[SPCC] Gaia XP download failed: {e}")

        # ---- integrate anything we can (and cache the results) ----
        eps = 1e-30
        new_rows: list[tuple[int, float, float, float]] = []

        for sid in missing_integrals:
            try:
                spec = dl.db.get_spectrum(int(sid))
                if spec is None or spec.flux is None or spec.wavelengths is None:
                    continue

                # spec.wavelengths are nm in gaia_downloader; convert to Å
                wl_spec_ang = np.asarray(spec.wavelengths, dtype=np.float64).reshape(-1) * 10.0
                fl_spec = np.asarray(spec.flux, dtype=np.float64).reshape(-1)

                if wl_spec_ang.size < 2 or fl_spec.size != wl_spec_ang.size:
                    continue

                # Ensure increasing wavelength for interp
                if wl_spec_ang[0] > wl_spec_ang[-1]:
                    wl_spec_ang = wl_spec_ang[::-1]
                    fl_spec = fl_spec[::-1]

                # Interpolate Gaia flux onto wl_grid_ang (your 3000–11000Å grid)
                fl_i = np.interp(wl_grid_ang, wl_spec_ang, fl_spec, left=0.0, right=0.0)

                Sr = float(_trapz(fl_i * T_sys_R, x=wl_grid_ang))
                Sg = float(_trapz(fl_i * T_sys_G, x=wl_grid_ang))
                Sb = float(_trapz(fl_i * T_sys_B, x=wl_grid_ang))

                if abs(Sg) > eps and np.isfinite(Sr) and np.isfinite(Sg) and np.isfinite(Sb):
                    out[int(sid)] = (Sr, Sg, Sb)
                    new_rows.append((int(sid), Sr, Sg, Sb))

            except Exception:
                continue

        # ---- write synthetic photometry cache for next time ----
        if new_rows:
            try:
                dl.db.upsert_synth_phot(new_rows, system_key)
            except Exception as e:
                print(f"[SPCC] Gaia synth cache write failed (continuing): {e}")

        return out

    def _gaia_db_path(self) -> str:
        """
        Persistent Gaia XP cache DB location (survives between runs).
        """
        base = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation)
        d = os.path.join(base, "gaia")
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, "gaia_xp_cache.sqlite")


    def fetch_stars(self):
        from astropy.coordinates import SkyCoord
        import astropy.units as u
        from astropy.wcs.wcs import NoConvergence
        from astroquery.simbad import Simbad
        from astropy.io import fits
        from PyQt6.QtWidgets import QMessageBox, QApplication
        if getattr(self, "_headless", False):
            # Headless calibration (e.g. NBExtract batch): never pop a modal — it
            # would block the whole run. Failure paths below just return empty and
            # the caller falls back. Interactive use keeps the real dialogs.
            class QMessageBox:  # local no-op shim; shadows the import above
                StandardButton = None
                @staticmethod
                def warning(*a, **k):     return None
                @staticmethod
                def critical(*a, **k):    return None
                @staticmethod
                def information(*a, **k):  return None
                @staticmethod
                def question(*a, **k):     return None

        # 0) Grab current image + header
        img, hdr, _meta = self._get_active_image_and_header()
        self.current_image = img
        self.current_header = hdr

        if self.current_header is None or self.current_image is None:
            QMessageBox.warning(self, "No Plate Solution",
                                "Please plate-solve the active document first.")
            return

        # Pickles templates list (once)
        if not hasattr(self, "pickles_templates"):
            self.pickles_templates = []
            for p in (self.user_custom_path, self.sasp_data_path):
                try:
                    with fits.open(p, memmap=False) as hd:
                        for hdu in hd:
                            if (isinstance(hdu, fits.BinTableHDU)
                                    and hdu.header.get("CTYPE", "").upper() == "SED"):
                                extname = hdu.header.get("EXTNAME", None)
                                if extname and extname not in self.pickles_templates:
                                    self.pickles_templates.append(extname)
                except Exception as e:
                    print(f"[SPCC] Could not load Pickles templates from {p}: {e}")
            self.pickles_templates.sort()

        # Build WCS
        try:
            self.initialize_wcs_from_header(self.current_header)
        except Exception:
            QMessageBox.critical(self, "WCS Error", "Could not build a 2D WCS from header.")
            return

        if not getattr(self, "wcs", None):
            QMessageBox.critical(self, "WCS Error", "Could not build a 2D WCS from header.")
            return

        wcs2 = self.wcs.celestial if hasattr(self.wcs, "celestial") else self.wcs
        H, W = self.current_image.shape[:2]

        # ── Step 1: SEP detection ──────────────────────────────────────────
        _sfcc_status(self, "Detecting stars with SEP…")
        QApplication.processEvents()

        if self.current_image.dtype == np.uint8:
            img_float = self.current_image.astype(np.float32) / 255.0
        else:
            img_float = self.current_image.astype(np.float32, copy=False)

        base  = self._make_working_base_for_sep(img_float)
        gray  = np.mean(base, axis=2).astype(np.float32)
        bkg   = sep.Background(gray)
        data_sub = gray - bkg.back()
        err   = float(bkg.globalrms)

        sources, sep_sigma = self._sep_detect_waterfall(
            data_sub, err, status_prefix="Detecting stars with SEP"
        )

        if sources is None or sources.size == 0:
            QMessageBox.critical(self, "SEP Error", "SEP found no sources.")
            return

        r_fluxrad, _ = sep.flux_radius(
            gray, sources["x"], sources["y"],
            2.0 * sources["a"], 0.5,
            normflux=sources["flux"], subpix=5
        )
        mask = (r_fluxrad > 0.2) & (r_fluxrad <= 10)
        sources = sources[mask]
        if sources.size == 0:
            QMessageBox.critical(self, "SEP Error", "All SEP detections rejected by radius filter.")
            return

        _sfcc_status(self, f"SEP detected {sources.size:,} stars (σ={sep_sigma:.1f}) — converting to sky coords…")
        QApplication.processEvents()

        # ── Step 2: WCS → RA/Dec for every SEP source ─────────────────────
        xs = sources["x"].astype(np.float64)
        ys = sources["y"].astype(np.float64)

        try:
            sky_coords = wcs2.all_pix2world(np.column_stack([xs, ys]), 0)
        except Exception as e:
            QMessageBox.critical(self, "WCS Error", str(e))
            return

        valid_mask = (
            np.isfinite(sky_coords[:, 0]) & np.isfinite(sky_coords[:, 1]) &
            (sky_coords[:, 1] >= -90) & (sky_coords[:, 1] <= 90)
        )
        sources     = sources[valid_mask]
        sky_coords  = sky_coords[valid_mask]

        if sources.size == 0:
            QMessageBox.critical(self, "WCS Error", "No valid sky coordinates after WCS conversion.")
            return

        # ── Step 3: Gaia bulk library positional match ─────────────────────
        self.star_list = []
        gaia_source_map: dict[int, int] = {}   # sep_index → gaia source_id

        if self._use_gaia_fallback():
            try:
                from setiastro.saspro.gaia_database import get_library
                lib = get_library()
                if lib.installed_bands():
                    _sfcc_status(self,
                        f"Matching {sources.size:,} SEP stars against local Gaia library…")
                    QApplication.processEvents()

                    coords_list = [(float(sky_coords[i, 0]), float(sky_coords[i, 1]))
                                   for i in range(len(sources))]
                    batch_results = lib.find_nearest_batch(coords_list, radius_arcsec=3.0)

                    for sep_idx, (sid, sep_arcsec) in batch_results.items():
                        gaia_source_map[sep_idx] = sid

                    _sfcc_status(self,
                        f"Gaia library matched {len(gaia_source_map):,} of "
                        f"{sources.size:,} SEP stars")
                    QApplication.processEvents()
            except Exception as e:
                print(f"[SPCC] Gaia bulk match failed: {e}")

        # ── Step 4: Build star_list from SEP + Gaia matches ───────────────
        for i in range(len(sources)):
            ra_deg  = float(sky_coords[i, 0])
            dec_deg = float(sky_coords[i, 1])
            xpix    = float(sources["x"][i])
            ypix    = float(sources["y"][i])

            sid = gaia_source_map.get(i)
            info = None
            if sid is not None:
                try:
                    from setiastro.saspro.gaia_database import get_library
                    info = get_library().get_source_info(sid)
                except Exception:
                    pass

            self.star_list.append({
                "ra":             ra_deg,
                "dec":            dec_deg,
                "x":              xpix,
                "y":              ypix,
                "a":              float(sources["a"][i]),
                "main_id":        None,
                "sp_clean":       None,
                "pickles_match":  None,
                "sp_source":      None,
                "Bmag":           None,
                "Vmag":           None,
                "Rmag":           None,
                "gaia_source_id": sid,
                "gaia_gmag":      info["gmag"] if info else None,
                "gaia_sep_arcsec": batch_results.get(i, (None, None))[1] if i in gaia_source_map else None,
                "sp_source":      "gaia_xp" if sid is not None else None,
            })

        # ── Step 5: SIMBAD region query for spectral types ─────────────────
        pix_corners = np.array([[W/2, H/2], [0,0], [W,0], [0,H], [W,H]], dtype=float)
        try:
            sky_corners = wcs2.all_pix2world(pix_corners, 0)
        except Exception as e:
            QMessageBox.critical(self, "WCS Error", str(e))
            return

        center_sky  = SkyCoord(ra=float(sky_corners[0,0])*u.deg,
                               dec=float(sky_corners[0,1])*u.deg, frame="icrs")
        corners_sky = SkyCoord(ra=sky_corners[1:,0]*u.deg,
                               dec=sky_corners[1:,1]*u.deg, frame="icrs")
        radius = center_sky.separation(corners_sky).max() * 1.05

        # Probe + mirror failover + bounded timeouts; see cds_health.
        # Also routes the query off the GUI thread, which the old direct
        # Simbad.query_region() call did not do.
        self._simbad_budget = cds_health.Budget()
        _simbad = cds_health.prepare_simbad(
            status_cb=lambda m: _sfcc_status(self, m), timeout=30.0)

        simbad_result = None
        if _simbad is not None:
            _sfcc_status(self, "Querying SIMBAD for spectral types…")
            QApplication.processEvents()
            simbad_result = cds_health.call_simbad(
                _simbad.query_region, center_sky,
                radius=radius,
                runner=lambda f, *a, **k: run_async_blocking(
                    f, *a, parent=self, title="SFCC",
                    label="Querying SIMBAD…", cancellable=False, **k),
                status_cb=lambda m: _sfcc_status(self, m),
                budget=self._simbad_budget,
                attempts=2,
                label="SIMBAD region query",
            )

        # ── Step 6: Cross-match SIMBAD results onto star_list by position ──
        templates_for_hist = []

        if simbad_result is not None and len(simbad_result) > 0:
            cols_lower = {c.lower(): c for c in simbad_result.colnames}
            ra_col  = (cols_lower.get("ra")  or cols_lower.get("ra(d)")  or
                       cols_lower.get("ra_d"))
            dec_col = (cols_lower.get("dec") or cols_lower.get("dec(d)") or
                       cols_lower.get("dec_d"))
            b_col   = cols_lower.get("b") or cols_lower.get("flux_b")
            v_col   = cols_lower.get("v") or cols_lower.get("flux_v")
            r_col   = cols_lower.get("r") or cols_lower.get("flux_r")
            main_id_col = cols_lower.get("main_id")

            def _unmask_num(x):
                try:
                    if x is None: return None
                    if ma.isMaskedArray(x) and ma.is_masked(x): return None
                    return float(x)
                except Exception:
                    return None

            def infer_letter(bv):
                if bv is None or (isinstance(bv, float) and np.isnan(bv)):
                    return None
                if bv < 0.00: return "B"
                elif bv < 0.30: return "A"
                elif bv < 0.58: return "F"
                elif bv < 0.81: return "G"
                elif bv < 1.40: return "K"
                else: return "M"

            # Build numpy arrays of star_list coords for fast matching
            sl_ras  = np.array([s["ra"]  for s in self.star_list], dtype=np.float64)
            sl_decs = np.array([s["dec"] for s in self.star_list], dtype=np.float64)

            matched_simbad = 0
            for row in simbad_result:
                if ra_col is None or dec_col is None:
                    continue
                sra  = _unmask_num(row[ra_col])
                sdec = _unmask_num(row[dec_col])
                if sra is None or sdec is None:
                    continue

                # Find closest star_list entry within 3"
                cosd = max(1e-6, abs(math.cos(math.radians(sdec))))
                dras  = (sl_ras - sra) * cosd
                ddecs = sl_decs - sdec
                seps  = np.hypot(dras, ddecs) * 3600.0
                j = int(np.argmin(seps))
                if seps[j] > 3.0:
                    continue

                st = self.star_list[j]

                # Attach SIMBAD data
                raw_sp = None
                if "SP_TYPE" in simbad_result.colnames:
                    raw_sp = row["SP_TYPE"]
                elif "sp_type" in simbad_result.colnames:
                    raw_sp = row["sp_type"]

                bmag = _unmask_num(row[b_col]) if b_col else None
                vmag = _unmask_num(row[v_col]) if v_col else None
                rmag = _unmask_num(row[r_col]) if r_col else None

                sp_clean  = None
                sp_source = None
                if raw_sp and str(raw_sp).strip():
                    sp = str(raw_sp).strip().upper()
                    if not (sp.startswith("SN") or sp.startswith("KA")):
                        sp_clean  = sp
                        sp_source = "simbad"
                elif bmag is not None and vmag is not None:
                    sp_clean  = infer_letter(bmag - vmag)
                    sp_source = "bv_inferred"

                match_list   = pickles_match_for_simbad(sp_clean, self.pickles_templates) if sp_clean else []
                best_template = match_list[0] if match_list else None

                st["main_id"]       = str(row[main_id_col]).strip() if main_id_col and row[main_id_col] else None
                st["sp_clean"]      = sp_clean
                st["sp_source"]     = sp_source if st["sp_source"] != "gaia_xp" else "gaia_xp"
                st["pickles_match"] = best_template
                st["Bmag"]          = float(bmag) if bmag is not None else None
                st["Vmag"]          = float(vmag) if vmag is not None else None
                st["Rmag"]          = float(rmag) if rmag is not None else None

                if best_template:
                    templates_for_hist.append(best_template)
                matched_simbad += 1

            _sfcc_status(self,
                f"SIMBAD matched {matched_simbad} stars — "
                f"{len(gaia_source_map):,} have Gaia XP spectra")
            QApplication.processEvents()

        # ── Step 7: For Gaia-matched stars without Pickles, get SIMBAD ids
        #           then compute synthetic B/V/R from XP spectra ───────────
        if self._use_gaia_fallback():
            # SIMBAD ids lookup for stars that have main_id but no Gaia source_id yet
            # (handles stars SIMBAD matched but Gaia positional missed)
            needs_simbad_ids = [
                st for st in self.star_list
                if st.get("main_id") and st.get("gaia_source_id") is None
                and ((not st.get("sp_clean")) or st.get("pickles_match") is None)
            ]
            if needs_simbad_ids:
                try:
                    from setiastro.saspro.gaia_database import get_library
                    lib = get_library()
                    if lib.installed_bands():
                        _sfcc_status(self,
                            f"SIMBAD ids lookup for {len(needs_simbad_ids)} unmatched stars…")
                        QApplication.processEvents()

                        s_obj = Simbad()
                        try:
                            s_obj.add_votable_fields("ids")
                        except Exception as e:
                            cds_health.note_failure(e, context="add_votable_fields/ids")
                        main_ids = ([st["main_id"] for st in needs_simbad_ids]
                                    if cds_health.simbad_available() else [])
                        BATCH = 200
                        _ids_budget = cds_health.Budget(30.0)
                        simbad_to_gaia: dict[str, int] = {}
                        for i in range(0, len(main_ids), BATCH):
                            if _ids_budget.expired() or not cds_health.simbad_available():
                                _sfcc_status(self,
                                    "SIMBAD unavailable — skipping remaining id batches.")
                                break
                            batch = main_ids[i:i+BATCH]
                            try:
                                res = s_obj.query_objects(batch)
                                if res is None:
                                    continue
                                ids_col     = next((c for c in res.colnames if c.upper() == "IDS"), None)
                                mid_col     = next((c for c in res.colnames if c.upper() == "MAIN_ID"), None)
                                if ids_col is None:
                                    continue
                                for row in res:
                                    obj_name = str(row[mid_col]).strip() if mid_col else ""
                                    for part in str(row[ids_col]).split("|"):
                                        part = part.strip()
                                        if part.startswith("Gaia DR3 "):
                                            try:
                                                sid = int(part.replace("Gaia DR3 ", "").strip())
                                                simbad_to_gaia[obj_name] = sid
                                            except ValueError:
                                                pass
                                            break
                            except Exception as e:
                                print(f"[SPCC] SIMBAD ids batch failed: {e}")

                        for st in needs_simbad_ids:
                            mid = st.get("main_id")
                            if mid and mid in simbad_to_gaia:
                                candidate = simbad_to_gaia[mid]
                                if lib.has_spectrum(candidate):
                                    info = lib.get_source_info(candidate)
                                    st["gaia_source_id"]  = int(candidate)
                                    st["gaia_gmag"]       = info["gmag"] if info else None
                                    st["gaia_sep_arcsec"] = 0.0
                                    st["sp_source"]       = "gaia_xp"
                                    gaia_source_map[self.star_list.index(st)] = candidate
                except Exception as e:
                    print(f"[SPCC] SIMBAD ids fallback failed: {e}")

            # Compute synthetic B/V/R for all Gaia-matched stars
            gaia_ids_all = [
                st["gaia_source_id"] for st in self.star_list
                if st.get("gaia_source_id") is not None
            ]
            if gaia_ids_all:
                try:
                    _sfcc_busy(self, True,
                        f"Inferring spectral types from Gaia XP for {len(gaia_ids_all):,} unclassified stars…")
                    needs_bvr = sorted(set(
                        int(st["gaia_source_id"]) for st in self.star_list
                        if st.get("gaia_source_id") is not None
                        and (st.get("gaia_B") is None or st.get("gaia_V") is None)
                    ))
                    if needs_bvr:
                        user = getattr(self, "cosmos_username", None)
                        pw   = getattr(self, "cosmos_password", None)
                        cache_dir = os.path.join(
                            QStandardPaths.writableLocation(
                                QStandardPaths.StandardLocation.AppDataLocation),
                            "gaiaxpy_cache")
                        os.makedirs(cache_dir, exist_ok=True)
                        bvr_map = _gaiaxp_synth_bvr_cached(
                            self, needs_bvr,
                            db_path=self._gaia_db_path(),
                            status_cb=lambda m: _sfcc_status(self, m),
                            username=user, password=pw, cache_dir=cache_dir,
                        )
                        got = 0
                        for st in self.star_list:
                            sid_i = st.get("gaia_source_id")
                            if sid_i is None or int(sid_i) not in bvr_map:
                                continue
                            bvr = bvr_map[int(sid_i)]
                            st["gaia_B"] = bvr["B"]
                            st["gaia_V"] = bvr["V"]
                            st["gaia_R"] = bvr["R"]
                            got += 1
                            if st.get("Bmag") is None: st["Bmag"] = bvr["B"]
                            if st.get("Vmag") is None: st["Vmag"] = bvr["V"]
                            if st.get("Rmag") is None: st["Rmag"] = bvr["R"]
                            if not st.get("sp_clean"):
                                bv = bvr["B"] - bvr["V"]
                                letter = _infer_letter_from_bv(bv)
                                if letter:
                                    st["sp_clean"]  = letter
                                    st["sp_source"] = "bv_inferred"
                            if st.get("sp_clean") and not st.get("pickles_match"):
                                ml = pickles_match_for_simbad(st["sp_clean"], self.pickles_templates)
                                st["pickles_match"] = ml[0] if ml else None
                                if st["pickles_match"]:
                                    templates_for_hist.append(st["pickles_match"])
                        _sfcc_status(self,
                            f"Inferred Spectral Types computed for {got:,} stars")
                except Exception as e:
                    _sfcc_status(self, f"[SPCC] Gaia XP BVR failed: {e}")
                finally:
                    _sfcc_busy(self, False)

        # ── Summary ───────────────────────────────────────────────────────
        n_gaia    = sum(1 for s in self.star_list if s.get("gaia_source_id") is not None)
        n_pickles = sum(1 for s in self.star_list if s.get("pickles_match") is not None)
        n_bv      = sum(1 for s in self.star_list if s.get("sp_source") == "bv_inferred")

        # ── DO NOT cache star_list into document metadata ─────────────────
        # update_active_document fires activeDocumentChanged which causes
        # sluggish active-view switching after Step 1 completes.
        # self.star_list lives on the dialog instance and is all we need.

        # ── Summary plot ──────────────────────────────────────────────────
        if getattr(self, "figure", None) is not None:
            self.figure.clf()

        if getattr(self, "figure", None) is not None and getattr(self, "canvas", None) is not None:
            fig = self.figure
            
            # Left: spectral type distribution (Pickles + B-V inferred)
            ax1 = fig.add_subplot(1, 2, 1)
            if templates_for_hist:
                uniq, cnt = np.unique(templates_for_hist, return_counts=True)
                ax1.bar(uniq, cnt, edgecolor="black", color="#5588cc", label="Pickles")
            # overlay B-V inferred
            bv_types = [s["sp_clean"] for s in self.star_list
                        if s.get("sp_source") == "bv_inferred" and s.get("sp_clean")]
            if bv_types:
                bv_uniq, bv_cnt = np.unique(bv_types, return_counts=True)
                ax1.bar(bv_uniq, bv_cnt, edgecolor="black", color="#cc8844",
                        alpha=0.7, label="B-V inferred")
            ax1.set_xlabel("Spectral Type")
            ax1.set_ylabel("Count")
            ax1.set_title("Spectral Type Distribution")
            ax1.tick_params(axis="x", rotation=90)
            ax1.grid(axis="y", linestyle="--", alpha=0.3)
            ax1.legend(fontsize=8)

            # Right: source breakdown pie — mutually exclusive buckets
            ax2 = fig.add_subplot(1, 2, 2)

            n_gaia_xp        = sum(1 for s in self.star_list
                                   if s.get("gaia_source_id") is not None)
            n_simbad_pickles = sum(1 for s in self.star_list
                                   if s.get("gaia_source_id") is None
                                   and s.get("sp_source") == "simbad"
                                   and s.get("pickles_match") is not None)
            n_bv_pickles     = sum(1 for s in self.star_list
                                   if s.get("gaia_source_id") is None
                                   and s.get("sp_source") == "bv_inferred")
            n_none           = len(self.star_list) - n_gaia_xp - n_simbad_pickles - n_bv_pickles

            labels, sizes, colors = [], [], []
            for label, size, color in [
                (f"Gaia XP ({n_gaia_xp})",               n_gaia_xp,        "#44cc88"),
                (f"Pickles/SIMBAD ({n_simbad_pickles})",  n_simbad_pickles, "#5588cc"),
                (f"Pickles/B-V ({n_bv_pickles})",         n_bv_pickles,     "#cc8844"),
                (f"No spectrum ({n_none})",                n_none,           "#555555"),
            ]:
                if size > 0:
                    labels.append(label)
                    sizes.append(size)
                    colors.append(color)

            if sizes:
                ax2.pie(sizes, labels=labels, colors=colors, autopct="%1.0f%%",
                        textprops={"fontsize": 8})
            ax2.set_title("Calibration Source Breakdown")

            fig.tight_layout()
            self.canvas.setVisible(True)
            _force_mpl_no_tex()
            self.canvas.draw()

        _sfcc_status(self,
            f"Step 1 complete — {len(self.star_list):,} stars detected  ·  "
            f"{n_gaia_xp:,} Gaia XP  ·  {n_simbad_pickles:,} Pickles/SIMBAD  ·  "
            f"{n_bv_pickles:,} Pickles/B-V  ·  {n_none:,} unclassified")

    def _fit_and_apply_color_matrix(
        self,
        img: np.ndarray,
        enriched: list,
        gaia_integrals: dict,
        simbad_to_pickles: dict,
        template_integrals: dict,
    ) -> np.ndarray:
        """
        Fit a 3×3 color rotation matrix from the stellar locus.

        Each star gives us two points in (R/G, B/G) ratio space:
          - measured:  where the star actually lands in the image
          - expected:  where it should land given its XP/Pickles spectrum

        We fit M such that M @ [Rm/Gm, 1, Bm/Gm] ≈ [Sr/Sg, 1, Sb/Sg]

        This is a pure color rotation — M should look like a near-identity
        matrix with small off-diagonal terms. If it doesn't, the data is
        too noisy or degenerate (checked via condition number).

        Applied in ratio space: correct R/G and B/G ratios per pixel,
        G channel unchanged.
        """
        eps = 1e-12

        src_rows = []  # measured ratio vectors
        dst_rows = []  # expected ratio vectors

        for e in enriched:
            Rm = float(e["R_meas"])
            Gm = float(e["G_meas"])
            Bm = float(e["B_meas"])
            Sr = float(e["S_star_R"])
            Sg = float(e["S_star_G"])
            Sb = float(e["S_star_B"])

            if not all(np.isfinite(v) for v in (Rm, Gm, Bm, Sr, Sg, Sb)):
                continue
            if Rm <= 0 or Gm <= 0 or Bm <= 0 or Sr <= 0 or Sg <= 0 or Sb <= 0:
                continue

            # Both vectors in ratio space — G is always 1.0
            # This is the key: we're comparing ratios to ratios,
            # not ADU counts to spectral integrals
            src_rows.append([Rm / Gm, 1.0, Bm / Gm])
            dst_rows.append([Sr / Sg, 1.0, Sb / Sg])

        if len(src_rows) < 6:
            print(f"[SPCC-CM] Too few stars for matrix fit ({len(src_rows)}), skipping.")
            return img

        src = np.array(src_rows, dtype=np.float64)  # (N, 3)
        dst = np.array(dst_rows, dtype=np.float64)  # (N, 3)

        # Sigma clip on residuals from an initial fit
        init_M = np.linalg.lstsq(src, dst, rcond=None)[0].T  # (3, 3)
        pred   = (init_M @ src.T).T
        resid  = np.sqrt(np.mean((pred - dst) ** 2, axis=1))
        med    = np.median(resid)
        mad    = np.median(np.abs(resid - med)) * 1.4826
        keep   = resid < med + 3.0 * mad if mad > 0 else np.ones(len(resid), dtype=bool)

        src_k = src[keep]
        dst_k = dst[keep]
        n_clipped = int(np.sum(~keep))

        if len(src_k) < 6:
            print(f"[SPCC-CM] Too few stars after clipping ({len(src_k)}), skipping.")
            return img

        # Solve row by row
        M = np.zeros((3, 3), dtype=np.float64)
        for ch in range(3):
            coeffs, _, _, _ = np.linalg.lstsq(src_k, dst_k[:, ch], rcond=None)
            M[ch] = coeffs

        # Force the G row to [0, 1, 0] — G channel is our reference,
        # it must map to itself exactly. This is what keeps the matrix
        # near-identity and well-conditioned.
        M[1] = [0.0, 1.0, 0.0]

        cond = float(np.linalg.cond(M))
        diag = np.diag(M)
        offdiag = M - np.diag(diag)

        print(f"[SPCC-CM] Color matrix ({len(src_k)} stars, {n_clipped} clipped, cond={cond:.2f}):")
        print(np.round(M, 4))

        if cond > 50.0:
            print(f"[SPCC-CM] Matrix poorly conditioned (cond={cond:.1f}), skipping.")
            return img

        if np.any(np.abs(diag) > 3.0) or np.any(np.abs(offdiag) > 1.5):
            print(f"[SPCC-CM] Matrix out of bounds, skipping.")
            return img

        # Apply in ratio space: for each pixel compute R/G and B/G,
        # transform via M, reconstruct RGB with G unchanged
        H, W = img.shape[:2]
        out = img.astype(np.float64)
        G_ch = out[..., 1].copy()
        G_safe = np.where(G_ch > 1e-8, G_ch, 1e-8)

        ratio_img = np.stack([
            out[..., 0] / G_safe,
            np.ones((H, W), dtype=np.float64),
            out[..., 2] / G_safe,
        ], axis=-1)  # (H, W, 3)

        flat     = ratio_img.reshape(-1, 3)
        out_flat = (M @ flat.T).T
        out_ratio = out_flat.reshape(H, W, 3)

        corrected = np.stack([
            out_ratio[..., 0] * G_safe,
            G_ch,
            out_ratio[..., 2] * G_safe,
        ], axis=-1)

        # Fix per-pixel negatives
        pixel_mins = np.min(corrected, axis=-1, keepdims=True)
        if np.any(pixel_mins < 0.0):
            corrected = np.where(pixel_mins < 0.0, corrected - pixel_mins, corrected)

        # Compress highlights
        mx = float(np.nanmax(corrected))
        if mx > 1.0:
            lum = (0.2126 * corrected[..., 0] +
                   0.7152 * corrected[..., 1] +
                   0.0722 * corrected[..., 2])
            lum_pivot = float(np.median(lum))
            a = (1.0 - lum_pivot) / max(mx - lum_pivot, 1e-8)
            corrected = lum_pivot + (corrected - lum_pivot) * a

        print(f"[SPCC-CM] Applied. Off-diagonal max: {np.abs(offdiag).max():.4f}")
        return np.clip(corrected, 0.0, 1.0).astype(np.float32)

    # -- Step 2: Core color calibration using matched stars + synthetic photometry ---------
    def run_spcc(self):
        ref_sed_name = self.star_combo.currentData()
        r_filt  = self.r_filter_combo.currentText()
        g_filt  = self.g_filter_combo.currentText()
        b_filt  = self.b_filter_combo.currentText()
        sens_name = self.sens_combo.currentText()
        lp_filt   = self.lp_filter_combo.currentText()
        lp_filt2  = self.lp_filter_combo2.currentText()

        if not ref_sed_name:
            QMessageBox.warning(self, "Error", "Select a reference spectral type (e.g. A0V).")
            return
        if r_filt == "(None)" and g_filt == "(None)" and b_filt == "(None)":
            QMessageBox.warning(self, "Error", "Pick at least one of R, G or B filters.")
            return
        if sens_name == "(None)":
            QMessageBox.warning(self, "Error", "Select a sensor QE curve.")
            return

        doc = self.doc_manager.get_active_document()
        if doc is None or doc.image is None:
            QMessageBox.critical(self, "Error", "No active document.")
            return

        img = doc.image
        H, W = img.shape[:2]
        if img.ndim != 3 or img.shape[2] != 3:
            QMessageBox.critical(self, "Error", "Active document must be RGB (3 channels).")
            return

        if not getattr(self, "star_list", None):
            QMessageBox.warning(self, "Error", "Run Step 1: Fetch Stars before running color calibration.")
            return

        # ── Float working space ───────────────────────────────────────────
        if img.dtype == np.uint8:
            img_float = img.astype(np.float32) / 255.0
        else:
            img_float = img.astype(np.float32, copy=False)

        base = self._make_working_base_for_sep(img_float)
        if self.neutralize_chk.isChecked():
            base = self._neutralize_background(base, remove_pedestal=False)

        # ── SEP re-detection ──────────────────────────────────────────────
        gray     = np.mean(base, axis=2).astype(np.float32)
        bkg      = sep.Background(gray)
        data_sub = gray - bkg.back()
        err      = float(bkg.globalrms)

        sources, sep_sigma = self._sep_detect_waterfall(
            data_sub, err, status_prefix="Re-detecting stars for photometry"
        )

        if sources is not None and sources.size > 300_000:
            QMessageBox.warning(self, "Too many detections",
                f"SEP found {sources.size:,} sources with σ={sep_sigma:.1f}.\n"
                f"Increase the threshold and rerun.")
            return
        if sources is None or sources.size == 0:
            QMessageBox.critical(self, "SEP Error", "SEP found no sources.")
            return

        _sfcc_status(self, f"SEP found {sources.size:,} sources (σ={sep_sigma:.1f}) — applying radius filter…")
        QApplication.processEvents()

        r_fluxrad, _ = sep.flux_radius(
            gray, sources["x"], sources["y"],
            2.0 * sources["a"], 0.5,
            normflux=sources["flux"], subpix=5)
        mask = (r_fluxrad > 0.2) & (r_fluxrad <= 10)
        sources = sources[mask]
        if sources.size == 0:
            QMessageBox.critical(self, "SEP Error", "All SEP detections rejected by radius filter.")
            return

        # ── Match star_list → current SEP sources ─────────────────────────
        _sfcc_status(self, f"Matching {sources.size:,} SEP sources to star catalog…")
        QApplication.processEvents()

        raw_matches = []
        for i, star in enumerate(self.star_list):
            dx = sources["x"] - star["x"]
            dy = sources["y"] - star["y"]
            j  = int(np.argmin(dx * dx + dy * dy))
            if (dx[j]**2 + dy[j]**2) < (3.0**2):
                raw_matches.append({
                    "sim_index": i,
                    "template":  star.get("pickles_match") or star.get("sp_clean") or "",
                    "src_index": j,
                    "x":         float(sources["x"][j]),
                    "y":         float(sources["y"][j]),
                    "x_pix":     float(sources["x"][j]),
                    "y_pix":     float(sources["y"][j]),
                    "a":         float(sources["a"][j]),
                    "sep_flux":  float(sources["flux"][j]),
                })

        if not raw_matches:
            QMessageBox.warning(self, "No Matches",
                "No catalog stars matched to SEP detections.")
            return

        # ── Cap to brightest 500 by SEP flux ──────────────────────────────
        MAX_PHOT_STARS = 500
        if len(raw_matches) > MAX_PHOT_STARS:
            raw_matches.sort(key=lambda m: m["sep_flux"], reverse=True)
            n_before = len(raw_matches)
            raw_matches = raw_matches[:MAX_PHOT_STARS]
            _sfcc_status(self,
                f"Capped to {MAX_PHOT_STARS} brightest of {n_before:,} matched stars…")
            QApplication.processEvents()

        _sfcc_status(self, f"Matched {len(raw_matches):,} stars — loading filter/sensor curves…")
        QApplication.processEvents()

        # ── Load curves + build throughput arrays ─────────────────────────
        wl_min, wl_max = 3000, 11000
        wl_grid = np.arange(wl_min, wl_max + 1)

        def load_curve(ext):
            for p in (self.user_custom_path, self.sasp_data_path):
                with fits.open(p, memmap=False) as hd:
                    if ext in hd:
                        d  = hd[ext].data
                        wl = _ensure_angstrom(d["WAVELENGTH"].astype(float))
                        tp = d["THROUGHPUT"].astype(float)
                        return wl, tp
            raise KeyError(f"Curve '{ext}' not found")

        def load_sed(ext):
            for p in (self.user_custom_path, self.sasp_data_path):
                with fits.open(p, memmap=False) as hd:
                    if ext in hd:
                        d  = hd[ext].data
                        wl = _ensure_angstrom(d["WAVELENGTH"].astype(float))
                        fl = d["FLUX"].astype(float)
                        return wl, fl
            raise KeyError(f"SED '{ext}' not found")

        interp_tp = lambda wl_o, tp_o: np.interp(wl_grid, wl_o, tp_o, left=0.0, right=0.0)

        T_R = interp_tp(*load_curve(r_filt)) if r_filt != "(None)" else np.ones_like(wl_grid)
        T_G = interp_tp(*load_curve(g_filt)) if g_filt != "(None)" else np.ones_like(wl_grid)
        T_B = interp_tp(*load_curve(b_filt)) if b_filt != "(None)" else np.ones_like(wl_grid)
        QE  = interp_tp(*load_curve(sens_name)) if sens_name != "(None)" else np.ones_like(wl_grid)
        LP1 = interp_tp(*load_curve(lp_filt))   if lp_filt  != "(None)" else np.ones_like(wl_grid)
        LP2 = interp_tp(*load_curve(lp_filt2))  if lp_filt2 != "(None)" else np.ones_like(wl_grid)
        LP  = LP1 * LP2

        T_sys_R = T_R * QE * LP
        T_sys_G = T_G * QE * LP
        T_sys_B = T_B * QE * LP

        wl_ref, fl_ref = load_sed(ref_sed_name)
        fr_i    = np.interp(wl_grid, wl_ref, fl_ref, left=0.0, right=0.0)
        S_ref_R = _trapz(fr_i * T_sys_R, x=wl_grid)
        S_ref_G = _trapz(fr_i * T_sys_G, x=wl_grid)
        S_ref_B = _trapz(fr_i * T_sys_B, x=wl_grid)

        # ── Step A: Gaia XP integrals for all matched stars that have one ──
        _sfcc_status(self, "Computing Gaia XP synthetic photometry integrals…")
        QApplication.processEvents()

        gaia_integrals: dict[int, tuple[float, float, float]] = {}
        if self._use_gaia_fallback():
            try:
                gaia_ids_needed = sorted(set(
                    int(self.star_list[int(m["sim_index"])]["gaia_source_id"])
                    for m in raw_matches
                    if 0 <= int(m["sim_index"]) < len(self.star_list)
                    and self.star_list[int(m["sim_index"])].get("gaia_source_id") is not None
                ))
                if gaia_ids_needed:
                    gaia_integrals = self._gaia_integrals_for_source_ids(
                        gaia_ids_needed,
                        wl_grid_ang=wl_grid.astype(np.float64),
                        T_sys_R=T_sys_R.astype(np.float64),
                        T_sys_G=T_sys_G.astype(np.float64),
                        T_sys_B=T_sys_B.astype(np.float64),
                        batch_size=25,
                    )
                    _sfcc_status(self,
                        f"Gaia XP: {len(gaia_integrals):,} integrals computed — "
                        f"computing Pickles integrals for remaining stars…")
                    QApplication.processEvents()
            except Exception as e:
                print(f"[SPCC] Gaia XP integrals failed: {e}")
        else:
            _sfcc_status(self, "Gaia XP fallback disabled — computing Pickles integrals…")
            QApplication.processEvents()

        # ── Step B: Pickles integrals for stars without a Gaia XP integral ─
        types_needing_pickles: set[str] = set()
        simbad_to_pickles:     dict[str, str] = {}

        for m in raw_matches:
            si  = int(m["sim_index"])
            sid = self.star_list[si].get("gaia_source_id") if 0 <= si < len(self.star_list) else None
            if sid is not None and int(sid) in gaia_integrals:
                continue
            sp = m["template"]
            if not sp:
                continue
            cands = pickles_match_for_simbad(sp, getattr(self, "pickles_templates", []))
            if cands:
                pname = cands[0]
                simbad_to_pickles[sp] = pname
                types_needing_pickles.add(pname)

        template_integrals: dict[str, tuple[float, float, float]] = {}
        for pname in types_needing_pickles:
            try:
                wl_s, fl_s = load_sed(pname)
                fs_i = np.interp(wl_grid, wl_s, fl_s, left=0.0, right=0.0)
                template_integrals[pname] = (
                    _trapz(fs_i * T_sys_R, x=wl_grid),
                    _trapz(fs_i * T_sys_G, x=wl_grid),
                    _trapz(fs_i * T_sys_B, x=wl_grid),
                )
            except Exception as e:
                print(f"[SPCC] Warning: failed to integrate Pickles template {pname}: {e}")

        # ── Filter to only stars with a spectrum before photometry ────────
        # No point measuring aperture photometry on stars we can't calibrate.
        raw_matches_with_spectrum = [
            m for m in raw_matches
            if (
                self.star_list[int(m["sim_index"])].get("gaia_source_id") is not None
                and int(self.star_list[int(m["sim_index"])]["gaia_source_id"]) in gaia_integrals
            ) or (
                simbad_to_pickles.get(m["template"]) is not None
            )
        ]

        n_total_matches = len(raw_matches_with_spectrum)

        _sfcc_status(self,
            f"Measuring stellar flux — "
            f"{len(gaia_integrals):,} Gaia XP + {len(template_integrals):,} Pickles  ·  "
            f"{n_total_matches:,} of {len(raw_matches):,} matched stars have a spectrum…")
        QApplication.processEvents()

        if n_total_matches == 0:
            QMessageBox.warning(self, "No Stars with Spectra",
                "No matched stars have a Gaia XP spectrum or Pickles template.\n\n"
                "Try installing more Gaia XP library groups, or ensure\n"
                "SIMBAD returned spectral types for this field.")
            return

        # ── Step C: Parallel aperture photometry ──────────────────────────
        import concurrent.futures
        import os

        _sfcc_status(self, f"Measuring stellar flux for {n_total_matches} stars (parallel)…")
        QApplication.processEvents()

        diag_meas_RG, diag_exp_RG = [], []
        diag_meas_BG, diag_exp_BG = [], []
        enriched = []

        base_ro = np.ascontiguousarray(base, dtype=np.float32)

        def _measure_one(m):
            si  = int(m["sim_index"])
            x   = float(m["x"])
            y   = float(m["y"])
            a   = float(m.get("a", 1.5))
            r   = float(np.clip(2.5 * a, 2.0, 12.0))
            rin  = float(np.clip(3.0 * r,       6.0,       40.0))
            rout = float(np.clip(5.0 * r, rin + 2.0,       60.0))

            phot = measure_star_rgb_photometry(base_ro, x, y, r, rin, rout)
            if phot is None:
                return None

            Rm = float(phot["R"]["star_sum"])
            Gm = float(phot["G"]["star_sum"])
            Bm = float(phot["B"]["star_sum"])

            if not (np.isfinite(Rm) and np.isfinite(Gm) and np.isfinite(Bm)):
                return None
            if Gm <= 0 or Rm <= 0 or Bm <= 0:
                return None

            sid = None
            if 0 <= si < len(self.star_list):
                sid = self.star_list[si].get("gaia_source_id")

            integrals = gaia_integrals.get(int(sid)) if sid is not None else None

            if integrals is None:
                sp    = m["template"]
                pname = simbad_to_pickles.get(sp)
                integrals = template_integrals.get(pname) if pname else None

            if integrals is None:
                return None

            S_sr, S_sg, S_sb = integrals
            if not (np.isfinite(S_sr) and np.isfinite(S_sg) and np.isfinite(S_sb)):
                return None
            if S_sg <= 0 or S_sr <= 0 or S_sb <= 0:
                return None

            exp_RG  = S_sr / S_sg
            exp_BG  = S_sb / S_sg
            meas_RG = Rm   / Gm
            meas_BG = Bm   / Gm

            if not (np.isfinite(exp_RG) and np.isfinite(exp_BG) and
                    np.isfinite(meas_RG) and np.isfinite(meas_BG)):
                return None

            return {
                **m,
                "r_ap":      float(r),
                "r_in":      float(rin),
                "r_out":     float(rout),
                "ap_area":   float(phot["area_ap"]),
                "ann_area":  float(phot["area_ann"]),
                "R_raw":     float(phot["R"]["raw_sum"]),
                "G_raw":     float(phot["G"]["raw_sum"]),
                "B_raw":     float(phot["B"]["raw_sum"]),
                "R_ann_sum": float(phot["R"]["ann_sum"]),
                "G_ann_sum": float(phot["G"]["ann_sum"]),
                "B_ann_sum": float(phot["B"]["ann_sum"]),
                "R_bg_pp":   float(phot["R"]["mu_bg"]),
                "G_bg_pp":   float(phot["G"]["mu_bg"]),
                "B_bg_pp":   float(phot["B"]["mu_bg"]),
                "R_meas":    float(Rm),
                "G_meas":    float(Gm),
                "B_meas":    float(Bm),
                "S_star_R":  float(S_sr),
                "S_star_G":  float(S_sg),
                "S_star_B":  float(S_sb),
                "exp_RG":    float(exp_RG),
                "exp_BG":    float(exp_BG),
                "meas_RG":   float(meas_RG),
                "meas_BG":   float(meas_BG),
                "used_gaia": sid is not None and int(sid) in gaia_integrals,
            }

        n_workers = min(8, max(1, os.cpu_count() or 4))
        done_count = 0

        with concurrent.futures.ThreadPoolExecutor(max_workers=n_workers) as pool:
            futures = {pool.submit(_measure_one, m): m for m in raw_matches_with_spectrum}
            for fut in concurrent.futures.as_completed(futures):
                done_count += 1
                if done_count % 25 == 0 or done_count == n_total_matches:
                    _sfcc_status(self,
                        f"Measuring stellar flux — "
                        f"{done_count}/{n_total_matches} stars  ·  "
                        f"{len(enriched)} valid so far…")
                    QApplication.processEvents()
                try:
                    result = fut.result()
                except Exception as e:
                    print(f"[SPCC] Photometry worker failed: {e}")
                    continue
                if result is None:
                    continue
                enriched.append(result)
                diag_meas_RG.append(result["meas_RG"])
                diag_exp_RG.append(result["exp_RG"])
                diag_meas_BG.append(result["meas_BG"])
                diag_exp_BG.append(result["exp_BG"])

        _sfcc_status(self,
            f"Photometry complete — {len(enriched)} valid of {n_total_matches} stars measured")
        QApplication.processEvents()

        self._last_matched = enriched

        diag_meas_RG = np.asarray(diag_meas_RG, dtype=np.float64)
        diag_exp_RG  = np.asarray(diag_exp_RG,  dtype=np.float64)
        diag_meas_BG = np.asarray(diag_meas_BG, dtype=np.float64)
        diag_exp_BG  = np.asarray(diag_exp_BG,  dtype=np.float64)

        if diag_meas_RG.size == 0 or diag_meas_BG.size == 0:
            QMessageBox.information(self, "No Valid Stars",
                "No stars with valid measured vs expected ratios.")
            return

        n_stars    = int(diag_meas_RG.size)
        n_used_xp  = sum(1 for e in enriched if e.get("used_gaia"))
        n_used_pkl = n_stars - n_used_xp

        # ── Step D: Fit color correction model ────────────────────────────
        _sfcc_status(self,
            f"Fitting color correction model — {n_stars} stars "
            f"({n_used_xp} Gaia XP, {n_used_pkl} Pickles)…")
        QApplication.processEvents()

        def rms_frac(pred, exp):
            return float(np.sqrt(np.mean(((pred / exp) - 1.0) ** 2)))

        slope_only = lambda x, m:    m * x
        affine     = lambda x, m, b: m * x + b
        quad       = lambda x, a, b, c: a * x**2 + b * x + c

        denR  = float(np.sum(diag_meas_RG**2))
        denB  = float(np.sum(diag_meas_BG**2))
        mR_s  = float(np.sum(diag_meas_RG * diag_exp_RG)) / denR if denR > 0 else 1.0
        mB_s  = float(np.sum(diag_meas_BG * diag_exp_BG)) / denB if denB > 0 else 1.0
        rms_s = (rms_frac(slope_only(diag_meas_RG, mR_s), diag_exp_RG) +
                 rms_frac(slope_only(diag_meas_BG, mB_s), diag_exp_BG))

        mR_a, bR_a = np.linalg.lstsq(
            np.vstack([diag_meas_RG, np.ones_like(diag_meas_RG)]).T,
            diag_exp_RG, rcond=None)[0]
        mB_a, bB_a = np.linalg.lstsq(
            np.vstack([diag_meas_BG, np.ones_like(diag_meas_BG)]).T,
            diag_exp_BG, rcond=None)[0]
        rms_a = (rms_frac(affine(diag_meas_RG, mR_a, bR_a), diag_exp_RG) +
                 rms_frac(affine(diag_meas_BG, mB_a, bB_a), diag_exp_BG))

        quad_ok = diag_meas_RG.size >= 6 and diag_meas_BG.size >= 6
        if quad_ok:
            try:
                aR_q, bR_q, cR_q = np.polyfit(diag_meas_RG, diag_exp_RG, 2)
                aB_q, bB_q, cB_q = np.polyfit(diag_meas_BG, diag_exp_BG, 2)
                rms_q = (rms_frac(quad(diag_meas_RG, aR_q, bR_q, cR_q), diag_exp_RG) +
                         rms_frac(quad(diag_meas_BG, aB_q, bB_q, cB_q), diag_exp_BG))
            except Exception:
                aR_q, bR_q, cR_q = 0.0, 1.0, 0.0
                aB_q, bB_q, cB_q = 0.0, 1.0, 0.0
                rms_q = np.inf
        else:
            aR_q, bR_q, cR_q = 0.0, 1.0, 0.0
            aB_q, bB_q, cB_q = 0.0, 1.0, 0.0
            rms_q = np.inf

        idx = int(np.argmin([rms_s, rms_a, rms_q]))
        if idx == 0:
            coeff_R, coeff_B, model_choice = (
                (0.0, float(mR_s), 0.0), (0.0, float(mB_s), 0.0), "slope-only")
        elif idx == 1:
            coeff_R, coeff_B, model_choice = (
                (0.0, float(mR_a), float(bR_a)),
                (0.0, float(mB_a), float(bB_a)), "affine")
        else:
            coeff_R, coeff_B, model_choice = (
                (float(aR_q), float(bR_q), float(cR_q)),
                (float(aB_q), float(bB_q), float(cB_q)), "quadratic")

        poly = lambda c, x: c[0] * x**2 + c[1] * x + c[2]

        # ── Step E: Diagnostics plot ──────────────────────────────────────
        self.figure.clf()
        res0_RG = (diag_meas_RG / diag_exp_RG) - 1.0
        res0_BG = (diag_meas_BG / diag_exp_BG) - 1.0
        res1_RG = (poly(coeff_R, diag_meas_RG) / diag_exp_RG) - 1.0
        res1_BG = (poly(coeff_B, diag_meas_BG) / diag_exp_BG) - 1.0

        ymin = float(np.min(np.concatenate([res0_RG, res0_BG])))
        ymax = float(np.max(np.concatenate([res0_RG, res0_BG])))
        pad  = 0.05 * (ymax - ymin) if ymax > ymin else 0.02
        y_lim = (ymin - pad, ymax + pad)

        def shade(ax, yvals, color):
            q1, q3 = np.percentile(yvals, [25, 75])
            ax.axhspan(q1, q3, color=color, alpha=0.10, zorder=0)

        ax2 = self.figure.add_subplot(1, 2, 1)
        ax2.axhline(0, color="0.65", ls="--", lw=1)
        shade(ax2, res0_RG, "firebrick"); shade(ax2, res0_BG, "royalblue")
        ax2.scatter(diag_exp_RG, res0_RG, c="firebrick", marker="o", alpha=0.7, label="R/G residual")
        ax2.scatter(diag_exp_BG, res0_BG, c="royalblue", marker="s", alpha=0.7, label="B/G residual")
        ax2.set_ylim(*y_lim)
        ax2.set_xlabel("Expected (band/G)")
        ax2.set_ylabel("Frac residual (meas/exp − 1)")
        ax2.set_title("Residuals • BEFORE")
        ax2.legend(frameon=False, fontsize=7, loc="lower right")

        ax3 = self.figure.add_subplot(1, 2, 2)
        ax3.axhline(0, color="0.65", ls="--", lw=1)
        shade(ax3, res1_RG, "firebrick"); shade(ax3, res1_BG, "royalblue")
        ax3.scatter(diag_exp_RG, res1_RG, c="firebrick", marker="o", alpha=0.7)
        ax3.scatter(diag_exp_BG, res1_BG, c="royalblue", marker="s", alpha=0.7)
        ax3.set_ylim(*y_lim)
        ax3.set_xlabel("Expected (band/G)")
        ax3.set_ylabel("Frac residual (corrected/exp − 1)")
        ax3.set_title("Residuals • AFTER")

        self.canvas.setVisible(True)
        self.figure.tight_layout(w_pad=2.0)
        self.canvas.draw()

        # ── Step F: Apply per-channel correction ──────────────────────────
        _sfcc_status(self, "Applying SFCC color scales to image…")
        QApplication.processEvents()

        calibrated = img_float.copy()
        R = calibrated[..., 0]
        G = calibrated[..., 1]
        B = calibrated[..., 2]
        eps = 1e-8

        RG = R / np.maximum(G, eps)
        BG = B / np.maximum(G, eps)

        aR, bR, cR = coeff_R
        aB, bB, cB = coeff_B
        mR = np.clip(aR * RG**2 + bR * RG + cR, 0.25, 4.0)
        mB = np.clip(aB * BG**2 + bB * BG + cB, 0.25, 4.0)

        calibrated[..., 0] = _pivot_scale_channel(R, mR, float(np.median(R)))
        calibrated[..., 2] = _pivot_scale_channel(B, mB, float(np.median(B)))
        calibrated = np.clip(calibrated, 0.0, 1.0)

        # ── Step G: Optional 3×3 color matrix correction ─────────────────
        if getattr(self, "color_matrix_chk", None) is not None \
                and self.color_matrix_chk.isChecked() and enriched:
            _sfcc_status(self, "Fitting 3×3 color matrix from stellar residuals…")
            QApplication.processEvents()
            try:
                calibrated = self._fit_and_apply_color_matrix(
                    calibrated,
                    enriched,
                    gaia_integrals,
                    simbad_to_pickles,
                    template_integrals,
                )
                _sfcc_status(self, "3×3 color matrix applied ✓")
                QApplication.processEvents()
            except Exception as e:
                print(f"[SPCC] Color matrix failed (continuing): {e}")

        if self.neutralize_chk.isChecked():
            try:
                _debug_probe_channels(calibrated, "final_before_BN")
                calibrated = self._neutralize_background(calibrated, remove_pedestal=True)
                _debug_probe_channels(calibrated, "final_after_BN")
            except Exception as e:
                print(f"[SPCC] Final BN failed: {e}")

        out_img = ((np.clip(calibrated, 0.0, 1.0) * 255.0).astype(np.uint8)
                   if img.dtype == np.uint8
                   else np.clip(calibrated, 0.0, 1.0).astype(np.float32))

        new_meta = dict(doc.metadata or {})
        new_meta.update({
            "SFCC_applied":            True,
            "SFCC_timestamp":          datetime.now().isoformat(),
            "SFCC_model":              model_choice,
            "SFCC_coeff_R":            [float(v) for v in coeff_R],
            "SFCC_coeff_B":            [float(v) for v in coeff_B],
            "SFCC_num_stars":          int(n_stars),
            "SFCC_num_gaia_xp":        int(n_used_xp),
            "SFCC_num_pickles":        int(n_used_pkl),
            "SFCC_num_enriched_stars": int(len(enriched)),
        })

        self.doc_manager.update_active_document(
            out_img, metadata=new_meta,
            step_name="SFCC Calibrated", doc=doc)

        use_cm = getattr(self, "color_matrix_chk", None) is not None \
                 and self.color_matrix_chk.isChecked()

        _sfcc_status(self,
            f"SFCC complete — {n_stars} stars  ·  "
            f"{n_used_xp} Gaia XP  ·  {n_used_pkl} Pickles  ·  model: {model_choice}"
            + ("  ·  3×3 matrix ✓" if use_cm else ""))
        QApplication.processEvents()

        def pretty(coeff):
            return float(coeff[0] + coeff[1] + coeff[2])

        QMessageBox.information(self, "SFCC Complete",
            f"Applied SFCC using {n_stars} stars\n"
            f"  Gaia XP spectra:   {n_used_xp}\n"
            f"  Pickles templates: {n_used_pkl}\n"
            f"  Model: {model_choice}\n"
            #f"  3×3 color matrix:  {'ON' if use_cm else 'OFF'}\n"
            f"  R ratio @ x=1: {pretty(coeff_R):.4f}\n"
            f"  B ratio @ x=1: {pretty(coeff_B):.4f}\n"
            f"  Background neutralisation: "
            f"{'ON' if self.neutralize_chk.isChecked() else 'OFF'}")

        self.current_image = out_img

    # ── Chromatic gradient (optional) ──────────────────────────────────
    def run_gradient_extraction(self):
        print("[SPCC-GRAD] start")

        if not getattr(self, "star_list", None):
            QMessageBox.warning(self, "No Stars", "Fetch Stars first, then run SPCC.")
            return

        doc = self.doc_manager.get_active_document()
        if doc is None or doc.image is None:
            QMessageBox.critical(self, "Error", "No active document.")
            return

        img = doc.image
        if img.ndim != 3 or img.shape[2] != 3:
            QMessageBox.critical(self, "Error", "Active document must be RGB.")
            return

        is_u8 = (img.dtype == np.uint8)
        img_float = img.astype(np.float32) / (255.0 if is_u8 else 1.0)
        H, W = img_float.shape[:2]

        mode = getattr(self, "grad_method", "poly3")
        _sfcc_status(self, f"Gradient: preparing image (mode={mode})…")
        QApplication.processEvents()

        base = self._make_working_base_for_sep(img_float)

        # ── SEP detection ─────────────────────────────────────────────────
        gray     = np.mean(base, axis=2).astype(np.float32)
        bkg      = sep.Background(gray)
        data_sub = gray - bkg.back()
        err      = float(bkg.globalrms)

        sources, sep_sigma = self._sep_detect_waterfall(
            data_sub, err, status_prefix="Gradient: detecting stars"
        )
        if sources is None or sources.size == 0:
            QMessageBox.critical(self, "SEP Error", "SEP found no sources.")
            return

        r_fluxrad, _ = sep.flux_radius(
            gray, sources["x"], sources["y"],
            2.0 * sources["a"], 0.5,
            normflux=sources["flux"], subpix=5,
        )
        mask    = (r_fluxrad > 0.2) & (r_fluxrad <= 10)
        sources = sources[mask]
        if sources.size == 0:
            QMessageBox.critical(self, "SEP Error", "All SEP detections rejected by radius filter.")
            return

        _sfcc_status(self, f"Gradient: {sources.size:,} sources detected — matching to catalog…")
        QApplication.processEvents()

        # ── Load filter/sensor curves ─────────────────────────────────────
        r_filt    = self.r_filter_combo.currentText()
        g_filt    = self.g_filter_combo.currentText()
        b_filt    = self.b_filter_combo.currentText()
        sens_name = self.sens_combo.currentText()
        lp_filt   = self.lp_filter_combo.currentText()
        lp_filt2  = self.lp_filter_combo2.currentText()

        if sens_name == "(None)":
            QMessageBox.warning(self, "Error",
                "Select a sensor QE curve before running gradient extraction.")
            return

        wl_min, wl_max = 3000, 11000
        wl_grid = np.arange(wl_min, wl_max + 1)

        def load_curve(ext):
            for p in (self.user_custom_path, self.sasp_data_path):
                with fits.open(p, memmap=False) as hd:
                    if ext in hd:
                        d  = hd[ext].data
                        wl = _ensure_angstrom(d["WAVELENGTH"].astype(float))
                        tp = d["THROUGHPUT"].astype(float)
                        return wl, tp
            raise KeyError(f"Curve '{ext}' not found")

        def load_sed(ext):
            for p in (self.user_custom_path, self.sasp_data_path):
                with fits.open(p, memmap=False) as hd:
                    if ext in hd:
                        d  = hd[ext].data
                        wl = _ensure_angstrom(d["WAVELENGTH"].astype(float))
                        fl = d["FLUX"].astype(float)
                        return wl, fl
            raise KeyError(f"SED '{ext}' not found")

        interp_tp = lambda wl_o, tp_o: np.interp(wl_grid, wl_o, tp_o, left=0.0, right=0.0)

        T_R = interp_tp(*load_curve(r_filt)) if r_filt != "(None)" else np.ones_like(wl_grid)
        T_G = interp_tp(*load_curve(g_filt)) if g_filt != "(None)" else np.ones_like(wl_grid)
        T_B = interp_tp(*load_curve(b_filt)) if b_filt != "(None)" else np.ones_like(wl_grid)
        QE  = interp_tp(*load_curve(sens_name))
        LP1 = interp_tp(*load_curve(lp_filt))  if lp_filt  != "(None)" else np.ones_like(wl_grid)
        LP2 = interp_tp(*load_curve(lp_filt2)) if lp_filt2 != "(None)" else np.ones_like(wl_grid)
        LP  = LP1 * LP2

        T_sys_R = T_R * QE * LP
        T_sys_G = T_G * QE * LP
        T_sys_B = T_B * QE * LP

        # ── Match star_list to SEP detections ─────────────────────────────
        raw_matches = []
        for i, star in enumerate(self.star_list):
            dx = sources["x"] - star["x"]
            dy = sources["y"] - star["y"]
            if dx.size == 0:
                continue
            j  = int(np.argmin(dx * dx + dy * dy))
            d2 = float(dx[j] ** 2 + dy[j] ** 2)
            if d2 < (3.0 ** 2):
                raw_matches.append({
                    "sim_index": i,
                    "x":  float(sources["x"][j]),
                    "y":  float(sources["y"][j]),
                    "a":  float(sources["a"][j]),
                    "flux": float(sources["flux"][j]),
                })

        _sfcc_status(self,
            f"Gradient: {len(raw_matches):,} catalog stars re-detected — "
            f"computing spectral integrals…")
        QApplication.processEvents()

        if not raw_matches:
            QMessageBox.warning(self, "No Matches",
                "No catalog stars matched current SEP detections.")
            return

        # ── Gaia XP integrals (primary) ───────────────────────────────────
        gaia_integrals: dict[int, tuple[float, float, float]] = {}
        if self._use_gaia_fallback():
            gaia_ids_needed = sorted(set(
                int(self.star_list[m["sim_index"]]["gaia_source_id"])
                for m in raw_matches
                if self.star_list[m["sim_index"]].get("gaia_source_id") is not None
            ))
            if gaia_ids_needed:
                _sfcc_status(self,
                    f"Gradient: integrating {len(gaia_ids_needed):,} Gaia XP spectra…")
                QApplication.processEvents()
                try:
                    gaia_integrals = self._gaia_integrals_for_source_ids(
                        gaia_ids_needed,
                        wl_grid_ang=wl_grid.astype(np.float64),
                        T_sys_R=T_sys_R.astype(np.float64),
                        T_sys_G=T_sys_G.astype(np.float64),
                        T_sys_B=T_sys_B.astype(np.float64),
                        batch_size=128,
                    )
                    _sfcc_status(self,
                        f"Gradient: {len(gaia_integrals):,} Gaia XP integrals ready — "
                        f"computing Pickles fallback for remainder…")
                    QApplication.processEvents()
                except Exception as e:
                    print(f"[SPCC-GRAD] Gaia XP integrals failed: {e}")

        # ── Pickles integrals (fallback for stars without XP) ─────────────
        pickles_templates_needed: set[str] = set()
        simbad_to_pickles:        dict[str, str] = {}

        for m in raw_matches:
            st  = self.star_list[m["sim_index"]]
            sid = st.get("gaia_source_id")
            if sid is not None and int(sid) in gaia_integrals:
                continue   # already covered by XP
            sp = st.get("pickles_match") or st.get("sp_clean") or ""
            if not sp:
                # B-V inferred: use the letter as a Pickles lookup
                sp = st.get("sp_clean") or ""
            if sp:
                cands = pickles_match_for_simbad(sp, getattr(self, "pickles_templates", []))
                if cands:
                    simbad_to_pickles[sp] = cands[0]
                    pickles_templates_needed.add(cands[0])

        template_integrals: dict[str, tuple[float, float, float]] = {}
        for pname in pickles_templates_needed:
            try:
                wl_s, fl_s = load_sed(pname)
                fs_i = np.interp(wl_grid, wl_s, fl_s, left=0.0, right=0.0)
                template_integrals[pname] = (
                    float(_trapz(fs_i * T_sys_R, x=wl_grid)),
                    float(_trapz(fs_i * T_sys_G, x=wl_grid)),
                    float(_trapz(fs_i * T_sys_B, x=wl_grid)),
                )
            except Exception as e:
                print(f"[SPCC-GRAD] Pickles template {pname} failed: {e}")

        _sfcc_status(self,
            f"Gradient: {len(gaia_integrals):,} Gaia XP + "
            f"{len(template_integrals):,} Pickles templates — "
            f"measuring aperture photometry…")
        QApplication.processEvents()

        # ── Aperture photometry + differential magnitude residuals ─────────
        # For each star: dm_channel = -2.5 * log10(measured / expected)
        # A spatial trend in dm means a gradient in that channel.
        # We subtract the field median so only the *spatial variation* remains.
        meas_rows = []
        n_xp = n_pkl = n_bv = n_none = 0

        for m in raw_matches:
            st  = self.star_list[m["sim_index"]]
            sid = st.get("gaia_source_id")
            x   = m["x"]
            y   = m["y"]
            a   = m["a"]
            r   = float(np.clip(2.5 * a, 2.0, 12.0))

            # Resolve integrals: XP → Pickles → B-V Pickles
            integrals = None
            source_tag = "none"

            if sid is not None:
                integrals = gaia_integrals.get(int(sid))
                if integrals is not None:
                    source_tag = "xp"

            if integrals is None:
                sp    = st.get("pickles_match") or st.get("sp_clean") or ""
                pname = simbad_to_pickles.get(sp)
                if pname:
                    integrals  = template_integrals.get(pname)
                    source_tag = "pickles" if integrals is not None else "none"

            if integrals is None:
                n_none += 1
                continue

            S_sr, S_sg, S_sb = integrals
            if not (np.isfinite(S_sr) and np.isfinite(S_sg) and np.isfinite(S_sb)):
                n_none += 1
                continue
            if S_sr <= 0 or S_sg <= 0 or S_sb <= 0:
                n_none += 1
                continue

            phot = measure_star_rgb_raw_aperture(base, x, y, r)
            if phot is None:
                n_none += 1
                continue

            R_raw = float(phot["R_raw"])
            G_raw = float(phot["G_raw"])
            B_raw = float(phot["B_raw"])

            if not (np.isfinite(R_raw) and np.isfinite(G_raw) and np.isfinite(B_raw)):
                n_none += 1
                continue
            if R_raw <= 0 or G_raw <= 0 or B_raw <= 0:
                n_none += 1
                continue

            if source_tag == "xp":
                n_xp += 1
            elif source_tag == "pickles":
                n_pkl += 1
            else:
                n_bv += 1

            meas_rows.append({
                "x":       x,
                "y":       y,
                "R_raw":   R_raw,
                "G_raw":   G_raw,
                "B_raw":   B_raw,
                "S_R":     S_sr,
                "S_G":     S_sg,
                "S_B":     S_sb,
                "source":  source_tag,
            })

        _sfcc_status(self,
            f"Gradient: {len(meas_rows):,} valid stars  ·  "
            f"{n_xp} Gaia XP  ·  {n_pkl} Pickles  ·  {n_bv} B-V  ·  "
            f"{n_none} no spectrum")
        QApplication.processEvents()

        print(f"[SPCC-GRAD] valid stars: {len(meas_rows)} "
              f"(XP={n_xp}, Pickles={n_pkl}, B-V={n_bv}, none={n_none})")

        if len(meas_rows) < 10:
            QMessageBox.warning(self, "Too Few Stars",
                f"Only {len(meas_rows)} valid stars for gradient fitting (need ≥ 10).\n\n"
                f"  {n_xp} Gaia XP spectra\n"
                f"  {n_pkl} Pickles templates\n"
                f"  {n_none} no spectrum available\n\n"
                "Try lowering Star detect σ, or install more Gaia XP library groups.")
            return

        # ── Build differential magnitude arrays ───────────────────────────
        eps = 1e-12
        pts = np.array([[r["x"], r["y"]] for r in meas_rows], dtype=np.float64)
        dmR = np.array([-2.5 * np.log10(r["R_raw"] / max(r["S_R"], eps)) for r in meas_rows])
        dmG = np.array([-2.5 * np.log10(r["G_raw"] / max(r["S_G"], eps)) for r in meas_rows])
        dmB = np.array([-2.5 * np.log10(r["B_raw"] / max(r["S_B"], eps)) for r in meas_rows])

        # Remove global zero-point offset — only spatial variation matters
        dmR -= np.median(dmR)
        dmG -= np.median(dmG)
        dmB -= np.median(dmB)

        print(f"[SPCC-GRAD] dm ranges after median removal: "
              f"R=[{dmR.min():.3f},{dmR.max():.3f}]  "
              f"G=[{dmG.min():.3f},{dmG.max():.3f}]  "
              f"B=[{dmB.min():.3f},{dmB.max():.3f}]")

        # ── Sigma clip ────────────────────────────────────────────────────
        def sigma_clip(pts_in, vals, sigma=2.5):
            med = np.median(vals)
            mad = np.median(np.abs(vals - med)) * 1.4826
            if mad <= 0:
                return pts_in, vals
            keep = np.abs(vals - med) < sigma * mad
            return pts_in[keep], vals[keep]

        ptsR, dmR = sigma_clip(pts, dmR)
        ptsG, dmG = sigma_clip(pts, dmG)
        ptsB, dmB = sigma_clip(pts, dmB)

        print(f"[SPCC-GRAD] after sigma clip: R={len(dmR)}, G={len(dmG)}, B={len(dmB)}")

        if len(dmR) < 5 or len(dmG) < 5 or len(dmB) < 5:
            QMessageBox.warning(self, "Too Few Stars",
                "Too few stars survived sigma clipping for gradient fitting.")
            return

        # ── Fit surface ───────────────────────────────────────────────────
        _sfcc_status(self, f"Gradient: fitting {mode} surfaces from {len(dmR)} stars…")
        QApplication.processEvents()

        def fit_surface(pts_in, vals, shape, method):
            if method == "rbf":
                return compute_smooth_rbf_map(
                    pts_in, vals, shape,
                    smoothing=2.0, kernel="thin_plate_spline",
                ).astype(np.float32)
            else:
                return compute_gradient_map(
                    pts_in, vals, shape, method=method
                ).astype(np.float32)

        surfR = fit_surface(ptsR, dmR, (H, W), mode)
        surfG = fit_surface(ptsG, dmG, (H, W), mode)
        surfB = fit_surface(ptsB, dmB, (H, W), mode)

        # Re-center after fitting (polynomial extrapolation can shift the mean)
        surfR -= np.median(surfR)
        surfG -= np.median(surfG)
        surfB -= np.median(surfB)

        peak_R = float(np.max(np.abs(surfR)))
        peak_G = float(np.max(np.abs(surfG)))
        peak_B = float(np.max(np.abs(surfB)))
        print(f"[SPCC-GRAD] surface peaks: R={peak_R:.4f} G={peak_G:.4f} B={peak_B:.4f} mag")

        # Clamp to ±0.3 mag — beyond that something went wrong
        MAX_MAG = 0.3
        for surf, name in ((surfR, "R"), (surfG, "G"), (surfB, "B")):
            peak = float(np.max(np.abs(surf)))
            if peak > MAX_MAG:
                surf *= MAX_MAG / peak
                print(f"[SPCC-GRAD] {name} surface clamped from {peak:.3f} to {MAX_MAG:.3f} mag")

        # ── Apply correction ──────────────────────────────────────────────
        # dm = log10(measured/expected), so correction factor = 10^(-0.4 * dm)
        # divide the image by this to remove the gradient
        _sfcc_status(self, "Gradient: applying differential magnitude correction…")
        QApplication.processEvents()

        scaleR = np.power(10.0, -0.4 * surfR).astype(np.float32)
        scaleG = np.power(10.0, -0.4 * surfG).astype(np.float32)
        scaleB = np.power(10.0, -0.4 * surfB).astype(np.float32)

        corrected = img_float.copy()
        corrected[..., 0] = np.clip(corrected[..., 0] / np.maximum(scaleR, 1e-8), 0.0, 1.0)
        corrected[..., 1] = np.clip(corrected[..., 1] / np.maximum(scaleG, 1e-8), 0.0, 1.0)
        corrected[..., 2] = np.clip(corrected[..., 2] / np.maximum(scaleB, 1e-8), 0.0, 1.0)

        # ── Diagnostics plot ──────────────────────────────────────────────
        _force_mpl_no_tex()
        self.figure.clf()

        vmax = max(float(np.max(np.abs(surfR))),
                   float(np.max(np.abs(surfG))),
                   float(np.max(np.abs(surfB))),
                   0.01)

        for i, (surf, lbl, col) in enumerate([
            (surfR, f"R gradient ({peak_R:.3f} mag pk)", "Reds_r"),
            (surfG, f"G gradient ({peak_G:.3f} mag pk)", "Greens_r"),
            (surfB, f"B gradient ({peak_B:.3f} mag pk)", "Blues_r"),
        ], start=1):
            ax = self.figure.add_subplot(1, 3, i)
            im = ax.imshow(surf, origin="lower", cmap="RdBu",
                           vmin=-vmax, vmax=vmax)
            ax.set_title(lbl, fontsize=9)
            self.figure.colorbar(im, ax=ax, label="Δmag")

            # Overlay star positions used for this channel
            pts_used = ptsR if i == 1 else (ptsG if i == 2 else ptsB)
            ax.scatter(pts_used[:, 0], pts_used[:, 1],
                       s=6, c="yellow", alpha=0.5, linewidths=0)

        self.figure.suptitle(
            f"Spectrophotometric gradient  —  {mode}  ·  "
            f"{len(meas_rows)} stars  ({n_xp} XP · {n_pkl} Pickles)",
            fontsize=9,
        )
        self.figure.tight_layout()
        self.canvas.setVisible(True)
        self.canvas.draw()

        # ── Save result ───────────────────────────────────────────────────
        out = (corrected * 255.0).astype(np.uint8) if is_u8 else corrected.astype(np.float32)

        meta = dict(doc.metadata or {})
        meta.update({
            "SPCC_GradientRemoved":    True,
            "SPCC_GradientMethod":     mode,
            "SPCC_GradientNumStars":   len(meas_rows),
            "SPCC_GradientNumXP":      n_xp,
            "SPCC_GradientNumPickles": n_pkl,
            "SPCC_GradientPeakR_mag":  round(peak_R, 4),
            "SPCC_GradientPeakG_mag":  round(peak_G, 4),
            "SPCC_GradientPeakB_mag":  round(peak_B, 4),
        })

        self.doc_manager.update_active_document(
            out, metadata=meta,
            step_name=f"SPCC Gradient Removed ({mode})",
            doc=doc,
        )

        _sfcc_status(self,
            f"Gradient correction complete ✓  —  {mode}  ·  {len(meas_rows)} stars  ·  "
            f"peaks: R={peak_R:.3f} G={peak_G:.3f} B={peak_B:.3f} mag")

        QMessageBox.information(self, "Gradient Correction Complete",
            f"Spectrophotometric gradient removed.\n\n"
            f"  Method:       {mode}\n"
            f"  Stars used:   {len(meas_rows)}  ({n_xp} Gaia XP · {n_pkl} Pickles)\n\n"
            f"  Peak gradient magnitude:\n"
            f"    R: {peak_R:.3f} mag\n"
            f"    G: {peak_G:.3f} mag\n"
            f"    B: {peak_B:.3f} mag\n\n"
            f"If the result looks overcorrected, try 'poly2' instead of '{mode}'.")
        
    # ── Viewer, close ──────────────────────────────────────────────────

    def open_sasp_viewer(self):
        if self.sasp_viewer_window is not None:
            if self.sasp_viewer_window.isVisible():
                self.sasp_viewer_window.raise_()
            else:
                self.sasp_viewer_window.show()
            return

        self.sasp_viewer_window = SaspViewer(
            sasp_data_path=self.sasp_data_path,
            user_custom_path=self.user_custom_path
        )
        self.sasp_viewer_window.show()
        self.sasp_viewer_window.destroyed.connect(self._on_sasp_closed)

    def _cleanup(self):
        # 1) Close/cleanup child window (SaspViewer)
        try:
            if getattr(self, "sasp_viewer_window", None) is not None:
                try:
                    self.sasp_viewer_window.destroyed.disconnect(self._on_sasp_closed)
                except Exception:
                    pass
                try:
                    self.sasp_viewer_window.close()
                except Exception:
                    pass
                self.sasp_viewer_window = None
        except Exception:
            pass

        # 2) Disconnect any long-lived external signals (add these if/when used)
        # Example patterns:
        try:
            self.doc_manager.activeDocumentChanged.disconnect(self._on_active_doc_changed)
        except Exception:
            pass
        try:
            self.main_win.currentDocumentChanged.disconnect(self._on_active_doc_changed)
        except Exception:
            pass

        # 3) Release large caches/refs (important since dialog may not be deleted)
        try:
            self.current_image = None
            self.current_header = None
            self.star_list = []
            self._last_matched = []
            if hasattr(self, "wcs"):
                self.wcs = None
            if hasattr(self, "wcs_header"):
                self.wcs_header = None
        except Exception:
            pass

        # 4) Matplotlib cleanup
        try:
            if getattr(self, "figure", None) is not None:
                self.figure.clf()
            if getattr(self, "canvas", None) is not None:
                self.canvas.setVisible(False)
                self.canvas.draw_idle()
        except Exception:
            pass
        try:
            if getattr(self, "_gaia_dl", None) is not None:
                try:
                    self._gaia_dl.close()   # if you added it
                except Exception:
                    try:
                        self._gaia_dl.db.close()
                    except Exception:
                        pass
                self._gaia_dl = None
        except Exception:
            pass

    def _on_sasp_closed(self, _=None):
        # Called when the SaspViewer window is destroyed
        self.sasp_viewer_window = None
        self._cleanup()

    def closeEvent(self, event):
        self._cleanup()
        event.accept()
        super().closeEvent(event)


# ──────────────────────────────────────────────────────────────────────────────
# Helper to open the dialog from your app
# ──────────────────────────────────────────────────────────────────────────────

def open_sfcc(doc_manager, sasp_data_path: str, parent=None) -> SFCCDialog:
    dlg = SFCCDialog(doc_manager=doc_manager, sasp_data_path=sasp_data_path, parent=parent)
    dlg.show()
    return dlg



class _GaiaSpectraWorker(QThread):
    """
    Downloads and caches Gaia XP spectra in batches on a background thread.
    Emits progress after each batch; checks cancel flag between batches.
    """
    progress   = _Signal(int, int, str)   # (done, total, message)
    finished   = _Signal(int)             # spectra_stored count
    failed     = _Signal(str)             # error message

    def __init__(
        self,
        dl,                               # GaiaDownloader instance
        missing_spectra: list,
        batch_size: int = 100,
        parent=None,
    ):
        super().__init__(parent)
        self._dl           = dl
        self._missing      = list(missing_spectra)
        self._batch_size   = int(batch_size)
        self._cancel_flag  = False

    def cancel(self):
        self._cancel_flag = True

    def run(self):
        total   = len(self._missing)
        stored  = 0
        try:
            for i in range(0, total, self._batch_size):
                if self._cancel_flag:
                    self.progress.emit(stored, total, "Cancelled.")
                    self.finished.emit(stored)
                    return

                batch = self._missing[i:i + self._batch_size]
                done_so_far = min(i + len(batch), total)

                self.progress.emit(
                    i, total,
                    f"Downloading Gaia XP spectra {i+1}–{done_so_far} of {total}…\n"
                    f"(Gaia archive may be slow — each batch can take 1–3 min)"
                )

                try:
                    spectra = self._dl.download_xp_spectra(batch, batch_size=len(batch))
                    if spectra:
                        self._dl.db.add_spectra(spectra)
                        stored += len(spectra)
                except Exception as e:
                    print(f"[SPCC] Gaia batch {i//self._batch_size+1} failed: {e}")
                    # continue to next batch — partial results are fine

                self.progress.emit(done_so_far, total,
                    f"Batch complete ({done_so_far}/{total})…")

            self.finished.emit(stored)

        except Exception as e:
            self.failed.emit(str(e))