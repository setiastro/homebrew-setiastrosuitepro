# setiastro/saspro/cosmicclarity.py
from __future__ import annotations
import os
import sys
import glob
import time
import tempfile
import uuid
import numpy as np

from PyQt6.QtCore import Qt, QTimer, QSettings, QThread, pyqtSignal, QFileSystemWatcher, QEvent, QTimer
from PyQt6.QtGui import QIcon, QAction, QImage, QPixmap
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGroupBox, QGridLayout, QLabel, QPushButton,
    QSlider, QCheckBox, QComboBox, QMessageBox, QWidget, QRadioButton, QProgressBar,
    QTextEdit, QFileDialog, QTreeWidget, QTreeWidgetItem, QMenu, QInputDialog, QDoubleSpinBox
)
from PyQt6.QtCore import QProcess

# ---- bring in your image IO helpers ----
# Adjust these imports to your project structure if needed.
from setiastro.saspro.legacy.image_manager import load_image, save_image  

from setiastro.saspro.imageops.stretch import stretch_mono_image, stretch_color_image
# (deleted — aberration_ai is no longer used; kept only as dead code in worker)
from setiastro.saspro.resources import get_icons

from setiastro.saspro.cosmicclarity_engines.sharpen_engine import sharpen_rgb01
from setiastro.saspro.help_support import make_help_button
from setiastro.saspro.cosmicclarity_engines.denoise_engine import denoise_rgb01
from setiastro.saspro.cosmicclarity_engines.superres_engine import superres_rgb01
from setiastro.saspro.cosmicclarity_engines.satellite_engine import (
    get_satellite_models,
    satellite_remove_image,
)
from setiastro.saspro.cosmicclarity_headless import (
    resolve_overlap_px,
    parse_overlap_pct,
    nearest_overlap_pct,
    OVERLAP_PCT_CHOICES,
    DEFAULT_OVERLAP_PCT,
)
# Import centralized preview dialog
from setiastro.saspro.widgets.preview_dialogs import ImagePreviewDialog

import shutil
import subprocess


def _save_fmt_and_bitdepth_from_path_for_legacy(path: str):
    ext = os.path.splitext(path)[1].lower()

    if ext in (".fit", ".fits", ".fits.gz", ".fit.gz", ".fz"):
        return "fits", "32-bit floating point"

    if ext in (".tif", ".tiff"):
        return "tif", "32-bit floating point"

    if ext == ".xisf":
        return "xisf", "32-bit floating point"

    if ext == ".png":
        return "png", None  # legacy always saves 8-bit PNG

    if ext in (".jpg", ".jpeg"):
        return "jpg", None  # legacy always saves 8-bit JPG

    return None, None


def _save_image_no_auto_legacy(img, dst_path: str, hdr, mono, *, image_meta=None, file_meta=None, wcs_header=None):
    fmt, bd = _save_fmt_and_bitdepth_from_path_for_legacy(dst_path)

    # Unknown/unsupported extension -> force FITS output
    if fmt is None:
        base, _ = os.path.splitext(dst_path)
        dst_path = base + ".fits"
        fmt, bd = "fits", "32-bit floating point"

    save_image(
        img,
        dst_path,
        fmt,
        bd,
        hdr,
        mono,
        image_meta=image_meta,
        file_meta=file_meta,
        wcs_header=wcs_header,
    )
    return dst_path


def _cc_models_installed(kind: str = "core") -> tuple[bool, str]:
    """
    Returns (ok, detail)

    kind:
        "core"      -> normal Cosmic Clarity (sharpen / denoise / superres)
        "satellite" -> satellite removal only
        "all"       -> require both core + satellite
    """
    models_dir = ""
    try:
        from setiastro.saspro.resources import get_models_dir
        models_dir = get_models_dir()
    except Exception:
        pass

    if not models_dir or not os.path.isdir(models_dir):
        return False, "Models directory is missing."

    # Pick one stable sentinel per feature set.
    sentinels = {
        "core": [
            "deep_sharp_stellar_AI4.pth",  

        ],
        "satellite": [
            "satelliteRemovalAI4.pth",
        ],
        "all": [
            "deep_sharp_stellar_AI4.pth",
            "satelliteRemovalAI4.pth",
        ],
    }

    required = sentinels.get(kind, sentinels["core"])

    missing = [name for name in required if not os.path.exists(os.path.join(models_dir, name))]
    if missing:
        return False, "Missing model(s): " + ", ".join(missing)

    return True, ""

def _warn_models_missing_and_close(parent: QWidget, detail: str = ""):
    msg = (
        "Cosmic Clarity AI models are not installed.\n\n"
        "Please go to Setting->Preferences to Download and Install.\n"
    )
    if detail:
        msg += f"\nDetails: {detail}\n"

    QMessageBox.warning(parent, "Cosmic Clarity", msg)


def resolve_cosmic_root(parent=None) -> str:
    s = QSettings()
    root = s.value("paths/cosmic_clarity", "", type=str) or ""
    if root and os.path.isdir(root):
        return root

    # Try common relatives to the app executable
    appdir = os.path.dirname(os.path.abspath(sys.argv[0]))
    candidates = [
        appdir,
        os.path.join(appdir, "cosmic_clarity"),
        os.path.join(appdir, "CosmicClarity"),
        os.path.dirname(appdir),  # one up
    ]
    exe_names = {
        "win": ["SetiAstroCosmicClarity.exe", "SetiAstroCosmicClarity_denoise.exe"],
        "mac": ["SetiAstroCosmicClaritymac", "SetiAstroCosmicClarity_denoisemac"],
        "nix": ["SetiAstroCosmicClarity", "SetiAstroCosmicClarity_denoise"],
    }
    key = "win" if os.name == "nt" else ("mac" if sys.platform=="darwin" else "nix")

    for c in candidates:
        if all(os.path.exists(os.path.join(c, name)) for name in exe_names[key]):
            # ensure in/out exist
            os.makedirs(os.path.join(c, "input"), exist_ok=True)
            os.makedirs(os.path.join(c, "output"), exist_ok=True)
            s.setValue("paths/cosmic_clarity", c); s.sync()
            return c

    #sasprompt user once
    QMessageBox.information(parent, "Cosmic Clarity",
        "Please select your Cosmic Clarity folder (the one that contains the CC executables and input/output).")
    folder = QFileDialog.getExistingDirectory(parent, "Select Cosmic Clarity Folder", "")
    if folder:
        s.setValue("paths/cosmic_clarity", folder); s.sync()
        os.makedirs(os.path.join(folder, "input"), exist_ok=True)
        os.makedirs(os.path.join(folder, "output"), exist_ok=True)
        return folder
    return ""  # caller should handle "not set"


# =============================================================================
# Small helpers
# =============================================================================
def _satellite_exe_name() -> str:
    base = "setiastrocosmicclarity_satellite"
    return f"{base}.exe" if os.name == "nt" else base




class WaitDialog(QDialog):
    cancelled = pyqtSignal()

    def __init__(self, title="Processing…", parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)

        v = QVBoxLayout(self)
        self.lbl = QLabel("Processing, please wait…")
        self.txt = QTextEdit()
        self.txt.setReadOnly(True)

        self.pb = QProgressBar()
        self.pb.setRange(0, 100)
        self.pb.setValue(0)
        self.pb.setFormat("%p%")

        btn = QPushButton("Cancel")
        btn.clicked.connect(self.cancelled.emit)

        v.addWidget(self.lbl)
        v.addWidget(self.txt)
        v.addWidget(self.pb)
        v.addWidget(btn)

    def append_output(self, line: str):
        self.txt.append(line)

    def set_progress(self, done: int, total: int | None = None):
        """
        Supports both:
            set_progress(percent)
        and:
            set_progress(done, total)
        """

        # Percent mode (legacy CC dialog usage)
        if total is None:
            pct = max(0, min(100, int(done)))
            self.lbl.setText("Processing…")
            self.pb.setRange(0, 100)
            self.pb.setValue(pct)
            self.pb.setFormat("%p%")
            return

        # Indeterminate mode
        if total <= 0:
            self.lbl.setText("Waiting for files…")
            self.pb.setRange(0, 0)
            return

        # done / total mode
        done = max(0, min(int(done), int(total)))
        self.lbl.setText("Batch processing files…")
        self.pb.setRange(0, int(total))
        self.pb.setValue(done)
        self.pb.setFormat(f"{done} / {total} files")

class CosmicClarityEngineWorker(QThread):
    progress = pyqtSignal(int)      # 0..100
    log      = pyqtSignal(str)
    result   = pyqtSignal(object, str)  # (np.ndarray float32 RGB01, final_step_title)
    error    = pyqtSignal(str)

    def __init__(self, img_rgb01: np.ndarray, preset: dict, parent=None):
        super().__init__(parent)
        self._img = np.asarray(img_rgb01, dtype=np.float32)
        self._preset = dict(preset)
        self._cancel = False

    def cancel(self):
        self._cancel = True

    # ---- progress adapter ----
    def _mk_progress_cb(self, stage_label: str, stage_weight: float, base_pct: float, total_stages: int):
        """
        stage_weight: fraction of total progress reserved for this stage (0..1)
        base_pct: starting % for this stage
        """
        def _cb(done: int, total: int):
            if self._cancel or self.isInterruptionRequested():
                return False
            if total <= 0:
                return True
            frac = float(done) / float(total)
            pct = base_pct + stage_weight * 100.0 * frac
            self.progress.emit(int(max(0, min(100, round(pct)))))
            # optional: throttle logs; keep it quiet
            return True
        return _cb

    def run(self):
        try:
            p = self._preset
            mode = str(p.get("mode", "sharpen")).lower()

            use_gpu = bool(p.get("gpu", True))
            create_new_view = bool(p.get("create_new_view", False))  # not used here; dialog decides
            temp_stretch = bool(p.get("temp_stretch", False))
            target_median = float(p.get("target_median", 0.25))
            target_median = max(0.01, min(0.50, target_median))
            img = np.clip(self._img, 0.0, 1.0).astype(np.float32, copy=False)
            apply_aberration = bool(p.get("aberration_first", False))
            ab_patch = int(p.get("aberration_patch", 512))
            ab_overlap = int(p.get("aberration_overlap", 64))
            ab_border = int(p.get("aberration_border_px", 10))
            ab_auto_gpu = bool(p.get("aberration_auto_gpu", True))
            ab_provider = p.get("aberration_provider", None)

            # Decide stage plan
            stages = []
            if apply_aberration:
                stages.append("aberration")
            if mode == "sharpen":
                stages.append("sharpen")
            elif mode == "denoise":
                stages.append("denoise")
            elif mode == "both":
                stages.extend(["sharpen", "denoise"])
            elif mode == "superres":
                stages.append("superres")
            else:
                stages = ["sharpen"]

            n = max(1, len(stages))
            stage_weight = 1.0 / float(n)

            out = img
            self.progress.emit(0)

            for si, st in enumerate(stages):
                if self._cancel:
                    self.error.emit("Cancelled.")
                    return

                base_pct = (100.0 * si) / float(n)
                self.log.emit(f"Running {st}…")

                if st == "sharpen":
                    sharpening_mode = p.get("sharpening_mode", "Both")
                    stellar_amount = float(p.get("stellar_amount", 0.5))
                    nonstellar_amount = float(p.get("nonstellar_amount", 0.5))
                    nonstellar_psf = float(p.get("nonstellar_psf", 3.0))
                    auto_psf = bool(p.get("auto_psf", True))
                    sharpen_sep = bool(p.get("sharpen_channels_separately", False))

                    prog = self._mk_progress_cb("sharpen", stage_weight, base_pct, n)

                    sharpen_execution_mode = str(
                        p.get("sharpen_execution_mode", p.get("execution_mode", "auto"))
                    )
                    sharpen_batch_override = int(
                        p.get("sharpen_batch_size_override", p.get("batch_size_override", 0))
                    )

                    self.log.emit(f"Sharpen execution mode: {sharpen_execution_mode}")

                    out = sharpen_rgb01(
                        out,
                        sharpening_mode=str(sharpening_mode),
                        stellar_amount=float(stellar_amount),
                        nonstellar_amount=float(nonstellar_amount),
                        nonstellar_strength=float(nonstellar_psf),
                        auto_detect_psf=bool(auto_psf),
                        separate_channels=bool(sharpen_sep),
                        use_gpu=bool(use_gpu),
                        temp_stretch=temp_stretch,
                        target_median=target_median,
                        chunk_size=int(p.get("chunk_size", 256)),
                        overlap=resolve_overlap_px(p),
                        execution_mode=sharpen_execution_mode,
                        batch_size_override=sharpen_batch_override,
                        stellar_correct_mode=str(p.get("stellar_correct_mode", "sharpen_only")),
                        correct_model_version=str(p.get("correct_model_version", "V2 (latest)")),
                        correct_conservative=bool(p.get("correct_conservative", False)),
                        progress_cb=prog,
                    )

                elif st == "denoise":
                    prog = self._mk_progress_cb("denoise", stage_weight, base_pct, n)

                    self.log.emit(
                        f"Denoise execution mode: {self._preset.get('denoise_execution_mode', 'auto')}"
                    )

                    out = denoise_rgb01(
                        out,
                        denoise_strength=float(self._preset.get("denoise_luma", 0.5)),
                        denoise_mode=str(self._preset.get("denoise_mode", "luminance")),
                        separate_channels=bool(self._preset.get("separate_channels", False)),
                        color_denoise_strength=float(self._preset.get("denoise_color", 0.5)),
                        chunk_size=int(self._preset.get("chunk_size", 256)),
                        overlap=resolve_overlap_px(self._preset),
                        use_gpu=bool(self._preset.get("gpu", True)),
                        lite=bool(self._preset.get("denoise_lite", False)),
                        walking=bool(self._preset.get("denoise_walking", False)),  # ← new
                        temp_stretch=bool(self._preset.get("temp_stretch", False)),
                        target_median=float(self._preset.get("target_median", 0.25)),
                        progress_cb=prog,
                        execution_mode=str(self._preset.get("denoise_execution_mode", "auto")),
                        batch_size_override=int(self._preset.get("denoise_batch_size_override", 0)),
                    )
                elif st == "aberration":
                    pass  # aberration stage removed

                elif st == "superres":
                    scale = int(p.get("scale", 2))
                    prog = self._mk_progress_cb("superres", stage_weight, base_pct, n)

                    out = superres_rgb01(
                        out,
                        scale=int(scale),
                        use_gpu=True,   # keep matching your old UI behavior (GPU hidden for SR)
                        progress_cb=prog,
                    )

                else:
                    raise RuntimeError(f"Unknown stage: {st}")

            self.progress.emit(100)

            # Title for history
            if mode == "both":
                step_title = "Cosmic Clarity – Sharpen + Denoise"
            elif mode == "superres":
                step_title = "Cosmic Clarity – Super Resolution"
            else:
                step_title = f"Cosmic Clarity – {mode.title()}"

            self.result.emit(np.clip(out, 0.0, 1.0).astype(np.float32, copy=False), step_title)

        except Exception as e:
            self.error.emit(str(e))


# =============================================================================
# Dialog
# =============================================================================
class CosmicClarityDialogPro(QDialog):
    """
    Pro port of SASv2 Cosmic Clarity panel:
      • Modes: Sharpen, Denoise, Both, Super Resolution
      • GPU toggle
      • PSF, stellar/nonstellar amounts
      • Denoise strengths/mode
      • Super-res scale
      • Apply target: overwrite / new view
    Uses QSettings key: paths/cosmic_clarity
    """
    def __init__(self, parent, doc, icon: QIcon | None = None, *, headless: bool=False, bypass_guard: bool=False):
        super().__init__(parent)
        self._engine_thread = None
        self._closing_after_cancel = False
        self._wait = None
        self.icons = get_icons()
        self._orig_was_mono = False
 
        # Hard guard unless explicitly bypassed (used by preset runner)
        if not bypass_guard and self._headless_guard_active():
            try:
                self.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
            QTimer.singleShot(0, self.reject)
            return
 
        ok, detail = _cc_models_installed("core")
        if not ok:
            _warn_models_missing_and_close(self, detail)
            try:
                self.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)
            except Exception:
                pass
            QTimer.singleShot(0, self.reject)
            return
 
        self.setWindowTitle(self.tr("Cosmic Clarity"))
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        except Exception:
            pass
 
        if icon:
            try:
                self.setWindowIcon(icon)
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
 
        self.parent_ref = parent
        self.doc = doc
        self._engine_thread = None
        self._closing_after_cancel = False
        _orig = np.clip(np.asarray(doc.image, dtype=np.float32), 0.0, 1.0)
        if _orig.ndim == 2:
            _orig = np.stack([_orig, _orig, _orig], axis=-1)
        elif _orig.ndim == 3 and _orig.shape[2] == 1:
            _orig = np.repeat(_orig, 3, axis=2)
        self.orig = _orig
        self.cosmic_root = ""
 
        # ------------------------------------------------------------------
        # Helpers
        # ------------------------------------------------------------------
        def _add_inline_slider(layout: QGridLayout, row: int, label: QLabel, slider: QSlider, col_span: int = 1):
            layout.addWidget(label, row, 0)
            layout.addWidget(slider, row, 1, 1, col_span)
 
        # ------------------------------------------------------------------
        # Main layout
        # ------------------------------------------------------------------
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)
        outer.setSpacing(8)
 
        # ---------------- Header ----------------
        header = QHBoxLayout()
        header.setSpacing(10)
 
        self.lbl_logo = QLabel(self)
        self.lbl_logo.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        try:
            pm = QPixmap(self.icons.COSMICCLARITY)
            if not pm.isNull():
                self.lbl_logo.setPixmap(
                    pm.scaledToWidth(220, Qt.TransformationMode.SmoothTransformation)
                )
                header.addWidget(self.lbl_logo, 0)
        except Exception:
            pass
 
        hdr_text = QVBoxLayout()
        hdr_text.setContentsMargins(0, 0, 0, 0)
        text_wrap = QWidget()
        text_lay = QVBoxLayout(text_wrap)
        text_lay.setContentsMargins(0, 0, 0, 0)
        text_lay.setSpacing(2)
        lbl_title = QLabel(self.tr("Cosmic Clarity"))
        try:
            f = lbl_title.font()
            f.setBold(True)
            f.setPointSize(max(f.pointSize(), 12))
            lbl_title.setFont(f)
        except Exception:
            pass
        lbl_sub = QLabel(self.tr("Sharpen, denoise, and super-resolution for the active image."))
        lbl_sub.setWordWrap(True)
        text_lay.addWidget(lbl_title)
        text_lay.addWidget(lbl_sub)
        hdr_text.addStretch(1)
        hdr_text.addWidget(text_wrap, 0, Qt.AlignmentFlag.AlignVCenter)
        hdr_text.addStretch(1)
        header.addLayout(hdr_text, 1)
        outer.addLayout(header)
 
        # ---------------- General group ----------------
        grp_general = QGroupBox(self.tr("General"))
        gen = QGridLayout(grp_general)
        gen.setContentsMargins(8, 8, 8, 8)
        gen.setHorizontalSpacing(8)
        gen.setVerticalSpacing(6)
 
        gen.addWidget(QLabel(self.tr("Mode:")), 0, 0)
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["Sharpen", "Denoise", "Both", "Super Resolution"])
        gen.addWidget(self.cmb_mode, 0, 1)
 
        self.lbl_gpu = QLabel(self.tr("Use GPU:"))
        gen.addWidget(self.lbl_gpu, 0, 2)
        self.cmb_gpu = QComboBox()
        self.cmb_gpu.addItems([self.tr("Yes"), self.tr("No")])
        gen.addWidget(self.cmb_gpu, 0, 3)
 
        gen.addWidget(QLabel(self.tr("Apply to:")), 1, 0)
        self.cmb_target = QComboBox()
        self.cmb_target.addItems(["Overwrite active view", "Create new view"])
        gen.addWidget(self.cmb_target, 1, 1, 1, 3)
 
        gen.setColumnStretch(1, 1)
        gen.setColumnStretch(3, 1)
        outer.addWidget(grp_general)
 
        # ---------------- Two-column body ----------------
        body = QHBoxLayout()
        body.setSpacing(10)
        left_col = QVBoxLayout()
        left_col.setSpacing(8)
        right_col = QVBoxLayout()
        right_col.setSpacing(8)
 
        # ---------------- Sharpen group ----------------
        grp_sh = QGroupBox(self.tr("Sharpen"))
        sh = QGridLayout(grp_sh)
        sh.setContentsMargins(8, 8, 8, 8)
        sh.setHorizontalSpacing(8)
        sh.setVerticalSpacing(6)
 
        self.lbl_stellar_correct = QLabel("Stellar Correction:")
        sh.addWidget(self.lbl_stellar_correct, 0, 0)
 
        corr_row = QHBoxLayout()
        self.rb_correct_only    = QRadioButton("Correct Only")
        self.rb_correct_sharpen = QRadioButton("Correct + Sharpen")
        self.rb_sharpen_only    = QRadioButton("Sharpen Only")
        self.rb_correct_sharpen.setChecked(True)
        self.rb_correct_only.setToolTip(
            "Run the Aberration Correction model only.\n"
            "Fixes pinched optics, coma, spherical aberration, chromatic aberration etc.\n"
            "No sharpening is applied."
        )
        self.rb_correct_sharpen.setToolTip(
            "Run Aberration Correction first, then Stellar Sharpening.\n"
            "Best for images with both shape aberrations and soft stars."
        )
        self.rb_sharpen_only.setToolTip(
            "Standard Cosmic Clarity stellar sharpening — no correction pre-pass."
        )
        corr_row.addWidget(self.rb_correct_only)
        corr_row.addWidget(self.rb_correct_sharpen)
        corr_row.addWidget(self.rb_sharpen_only)
        corr_row.addStretch(1)
        sh.addLayout(corr_row, 0, 1)
         # V1 / V2 model selector — shown only when correction is available
        self.lbl_correct_ver = QLabel("Correction Model:")
        self.cmb_correct_ver = QComboBox()
        self.cmb_correct_ver.addItems(["V2 (latest)", "V1"])
        self.cmb_correct_ver.setToolTip(
            "V2: Updated weights, improved correction quality (recommended).\n"
            "V1: Original correction model."
        )
        sh.addWidget(self.lbl_correct_ver, 1, 0)
        sh.addWidget(self.cmb_correct_ver, 1, 1)

        self.lbl_sh_mode = QLabel("Sharpening Mode:")
        self.cmb_sh_mode = QComboBox()
        self.cmb_sh_mode.addItems(["Both", "Stellar Only", "Non-Stellar Only"])
        sh.addWidget(self.lbl_sh_mode, 2, 0)
        sh.addWidget(self.cmb_sh_mode, 2, 1)
 
        self.chk_sh_sep = QCheckBox("Sharpen RGB channels separately")
        self.chk_sh_sep.setToolTip(
            "Run the mono sharpening model independently on R, G, and B instead of a shared color model.\n"
            "Use for difficult color data where channels need slightly different sharpening."
        )
        sh.addWidget(self.chk_sh_sep, 3, 0, 1, 2)
 
        self.chk_auto_psf = QCheckBox("Auto Detect PSF")
        self.chk_auto_psf.setChecked(True)
        sh.addWidget(self.chk_auto_psf, 4, 0, 1, 2)
 
        self.lbl_psf = QLabel("Non-Stellar PSF (1.0–8.0): 3.0")
        self.sld_psf = QSlider(Qt.Orientation.Horizontal)
        self.sld_psf.setRange(10, 80)
        self.sld_psf.setValue(30)
        _add_inline_slider(sh, 5, self.lbl_psf, self.sld_psf)
 
        self.lbl_st_amt = QLabel("Stellar Amount (0–1): 0.50")
        self.sld_st_amt = QSlider(Qt.Orientation.Horizontal)
        self.sld_st_amt.setRange(0, 100)
        self.sld_st_amt.setValue(50)
        _add_inline_slider(sh, 6, self.lbl_st_amt, self.sld_st_amt)
 
        self.lbl_nst_amt = QLabel("Non-Stellar Amount (0–1): 0.50")
        self.sld_nst_amt = QSlider(Qt.Orientation.Horizontal)
        self.sld_nst_amt.setRange(0, 100)
        self.sld_nst_amt.setValue(50)
        _add_inline_slider(sh, 7, self.lbl_nst_amt, self.sld_nst_amt)

        self.chk_correct_conservative = QCheckBox("Conservative White Compression (reduces tiling on high-contrast images)")
        self.chk_correct_conservative.setToolTip(
            "When enabled, uses stronger white point compression during aberration correction.\n"
            "Reduces tiling artifacts on images with extreme bright/dark contrast within a single tile.\n"
        )
        sh.addWidget(self.chk_correct_conservative, 8, 0, 1, 2)

        sh.setColumnStretch(1, 1)
        left_col.addWidget(grp_sh)
 
        # ---------------- Denoise group ----------------
        grp_dn = QGroupBox(self.tr("Denoise"))
        dn = QGridLayout(grp_dn)
        dn.setContentsMargins(8, 8, 8, 8)
        dn.setHorizontalSpacing(8)
        dn.setVerticalSpacing(6)
 
        self.lbl_dn_lum = QLabel("Luminance Denoise (0–1): 0.50")
        self.sld_dn_lum = QSlider(Qt.Orientation.Horizontal)
        self.sld_dn_lum.setRange(0, 100)
        self.sld_dn_lum.setValue(50)
        _add_inline_slider(dn, 0, self.lbl_dn_lum, self.sld_dn_lum)
 
        self.lbl_dn_col = QLabel("Color Denoise (0–1): 0.50")
        self.sld_dn_col = QSlider(Qt.Orientation.Horizontal)
        self.sld_dn_col.setRange(0, 100)
        self.sld_dn_col.setValue(50)
        _add_inline_slider(dn, 1, self.lbl_dn_col, self.sld_dn_col)
 
        self.lbl_dn_mode = QLabel("Denoise Mode:")
        self.cmb_dn_mode = QComboBox()
        self.cmb_dn_mode.addItems(["full", "luminance"])
        dn.addWidget(self.lbl_dn_mode, 2, 0)
        dn.addWidget(self.cmb_dn_mode, 2, 1)
 
        self.chk_dn_sep = QCheckBox("Denoise RGB channels separately")
        dn.addWidget(self.chk_dn_sep, 3, 0, 1, 2)
 
        self.lbl_dn_model = QLabel("Denoise Model:")
        self.cmb_dn_model = QComboBox()
        self.cmb_dn_model.addItems(["Standard", "Walking Noise", "Lite (faster)"])
        self.cmb_dn_model.setToolTip(
            "Standard: general-purpose AI4 denoise model.\n"
            "Walking Noise: specialist model for fixed-pattern drift streaks\n"
            "  (polar misalignment, no guiding). Also handles normal noise.\n"
            "Lite: smaller faster model, slightly less detail."
        )
        dn.addWidget(self.lbl_dn_model, 4, 0)
        dn.addWidget(self.cmb_dn_model, 4, 1)
 
        self.chk_dn_compat = QCheckBox("GPU Compatibility Mode (slower, safer)")
        self.chk_dn_compat.setToolTip(
            "Uses safer inference settings for Cosmic Clarity processing.\n"
            "Recommended if sharpen or denoise fails, hangs, or produces GPU errors on older or fragile hardware."
        )
        dn.addWidget(self.chk_dn_compat, 5, 0, 1, 2)
 
        dn.setColumnStretch(1, 1)
        left_col.addWidget(grp_dn)
        left_col.addStretch(1)
 
        # ---------------- Super Resolution group ----------------
        grp_sr = QGroupBox(self.tr("Super Resolution"))
        sr = QGridLayout(grp_sr)
        sr.setContentsMargins(8, 8, 8, 8)
        sr.setHorizontalSpacing(8)
        sr.setVerticalSpacing(6)
        self.lbl_scale = QLabel("Scale Factor:")
        self.cmb_scale = QComboBox()
        self.cmb_scale.addItems(["2x", "3x", "4x"])
        sr.addWidget(self.lbl_scale, 0, 0)
        sr.addWidget(self.cmb_scale, 0, 1)
        sr.setColumnStretch(1, 1)
        right_col.addWidget(grp_sr)
 
        # ---------------- Advanced group ----------------
        grp_adv = QGroupBox(self.tr("Advanced"))
        adv = QGridLayout(grp_adv)
        adv.setContentsMargins(8, 8, 8, 8)
        adv.setHorizontalSpacing(8)
        adv.setVerticalSpacing(6)
 
        self.chk_temp_stretch = QCheckBox("Temporary Stretch for AI (linear assist)")
        self.chk_temp_stretch.setChecked(True)
        self.chk_temp_stretch.setToolTip(
            "Optionally applies a temporary stretch before AI inference (then reverses it).\n"
            "Useful for very linear / low-signal data. If off, engines use automatic behavior."
        )
        adv.addWidget(self.chk_temp_stretch, 0, 0, 1, 2)
 
        self.lbl_target_median = QLabel("Target Median (0.01–0.50): 0.25")
        self.sld_target_median = QSlider(Qt.Orientation.Horizontal)
        self.sld_target_median.setRange(1, 50)
        self.sld_target_median.setValue(25)
        _add_inline_slider(adv, 1, self.lbl_target_median, self.sld_target_median)
 
        self.chk_aberration_first = QCheckBox("Run Aberration Remover first")
        self.chk_aberration_first.setChecked(False)   # permanently disabled
        self.chk_aberration_first.setVisible(False)   # hidden — superseded by native correction
        adv.addWidget(self.chk_aberration_first, 2, 0, 1, 2)
 
        self.lbl_chunk = QLabel("Chunk Size:")
        self.cmb_chunk = QComboBox()
        self.cmb_chunk.addItems(["128", "192", "256", "320", "384", "512", "640", "768", "1024"])
        self.cmb_chunk.setCurrentText("256")
        adv.addWidget(self.lbl_chunk, 3, 0)
        adv.addWidget(self.cmb_chunk, 3, 1)
 
        self.lbl_ov = QLabel("Overlap (% of tile):")
        self.cmb_ov = QComboBox()
        self.cmb_ov.addItems([f"{c}%" for c in OVERLAP_PCT_CHOICES])
        self.cmb_ov.setCurrentText(f"{int(DEFAULT_OVERLAP_PCT)}%")
        self.cmb_ov.setToolTip(
            "Tile overlap as a percentage of the chunk size.\n"
            "Higher overlap reduces edge seams but is slower — runtime climbs\n"
            "steeply as overlap grows, so it is capped at 50% of the tile.\n"
            "25% is a good default."
        )
        adv.addWidget(self.lbl_ov, 4, 0)
        adv.addWidget(self.cmb_ov, 4, 1)
 
        adv.setColumnStretch(1, 1)
        right_col.addWidget(grp_adv)
        right_col.addStretch(1)
 
        body.addLayout(left_col, 1)
        body.addLayout(right_col, 1)
        outer.addLayout(body, 1)
 
        # ---------------- Buttons ----------------
        row = QHBoxLayout()
        self.btn_clear_cache = QPushButton(self.tr("Clear AI Cache"))
        self.btn_clear_cache.setToolTip(
            "Clears cached AI models from RAM/VRAM.\n"
            "This makes the next run slower (models must reload).\n\n"
            "Use if you are low on memory or troubleshooting."
        )
        self.btn_clear_cache.clicked.connect(self._clear_ai_cache_clicked)
        b_run = QPushButton(self.tr("Execute"))
        b_run.clicked.connect(self._run_main)
        b_close = QPushButton(self.tr("Close"))
        b_close.clicked.connect(self.reject)
        row.addWidget(self.btn_clear_cache)
        row.addStretch(1)
        row.addWidget(make_help_button("cosmic_clarity", self))
        row.addWidget(b_run)
        row.addWidget(b_close)
        outer.addLayout(row)

        # --- preset drag handle (grip), pinned lower-left ---
        try:
            from setiastro.saspro.shortcuts import PresetDragHandle
            try:
                from setiastro.saspro.resources import cosmic_path
                _grip_icon = QIcon(cosmic_path)
            except Exception:
                _grip_icon = QIcon()
            drag_row = QHBoxLayout()
            drag_row.setContentsMargins(0, 0, 0, 0)
            self.preset_drag_handle = PresetDragHandle(
                "cosmic_clarity", self.get_preset, icon=_grip_icon,
                tooltip=self.tr(
                    "Drag to the canvas to create a Cosmic Clarity shortcut with these settings.\n"
                    "Drop directly on an image to apply them headlessly."),
                parent=self,
            )
            drag_row.addWidget(self.preset_drag_handle)
            drag_row.addStretch(1)   # push grip hard to the LEFT edge
            outer.addLayout(drag_row)
        except Exception:
            pass
 
        # ------------------------------------------------------------------
        # Step 1: load chunk/overlap (no save signals yet)
        # ------------------------------------------------------------------
        self._load_chunk_overlap_settings()
 
        # chunk/overlap have their own save keys — wire those now.
        # (Overlap is a % of the tile capped at 50%, so it is always valid
        #  relative to chunk size — no cross-enforcement needed.)
        self.cmb_chunk.currentTextChanged.connect(self._save_chunk_overlap_settings)
        self.cmb_ov.currentTextChanged.connect(self._save_chunk_overlap_settings)
 
        # ------------------------------------------------------------------
        # Step 2: load all other settings with ALL signals blocked
        # ------------------------------------------------------------------
        self._load_cc_ui_settings()
 
        # ------------------------------------------------------------------
        # Step 3: wire correct model availability FIRST so _mode_changed sees it
        # ------------------------------------------------------------------
        from setiastro.saspro.resources import get_resources
        _r = get_resources()
        _cp  = getattr(_r, "CC_C_PTH",  None)
        _cp2 = getattr(_r, "CC_C2_PTH", None)
        self._correct_available    = bool((_cp and os.path.exists(_cp)) or (_cp2 and os.path.exists(_cp2)))
        self._correct_v2_available = bool(_cp2 and os.path.exists(_cp2))

        # Disable V2 option if not installed
        v2_idx = self.cmb_correct_ver.findText("V2 (latest)")
        if v2_idx >= 0:
            item_flags = self.cmb_correct_ver.model().item(v2_idx).flags()
            from PyQt6.QtCore import Qt as _Qt
            from PyQt6.QtGui import QStandardItem
            item = self.cmb_correct_ver.model().item(v2_idx)
            if self._correct_v2_available:
                item.setFlags(item.flags() | _Qt.ItemFlag.ItemIsEnabled | _Qt.ItemFlag.ItemIsSelectable)
                item.setToolTip("V2 correction model — installed")
            else:
                item.setFlags(item.flags() & ~_Qt.ItemFlag.ItemIsEnabled & ~_Qt.ItemFlag.ItemIsSelectable)
                item.setToolTip("V2 correction model — not installed (click Download/Update Models in Preferences)")

        # Default selection
        if not self._correct_v2_available:
            self.cmb_correct_ver.setCurrentText("V1")
        else:
            self.cmb_correct_ver.setCurrentText("V2 (latest)")

        # ------------------------------------------------------------------
        # Step 4: now that _correct_available is set, apply dependent UI state
        # ------------------------------------------------------------------
        self._mode_changed()
        self._update_denoise_dependent_ui()

        # Sync temp-stretch enable state without saving
        self.lbl_target_median.setEnabled(self.chk_temp_stretch.isChecked())
        self.sld_target_median.setEnabled(self.chk_temp_stretch.isChecked())

        # Sync PSF label
        self._psf_label()
        self._on_st_amt(self.sld_st_amt.value())
        self._on_nst_amt(self.sld_nst_amt.value())
        self.lbl_dn_lum.setText(f"Luminance Denoise (0–1): {self.sld_dn_lum.value()/100:.2f}")
        self.lbl_dn_col.setText(f"Color Denoise (0–1): {self.sld_dn_col.value()/100:.2f}")
        tm = self.sld_target_median.value()
        self.lbl_target_median.setText(f"Target Median (0.01–0.50): {tm/100:.2f}")
 
        # ------------------------------------------------------------------
        # Step 5: wire headless flag
        # ------------------------------------------------------------------
        self._headless = bool(headless)
        if self._headless:
            try:
                self.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
 
        self._wait = None
 
        # ------------------------------------------------------------------
        # Step 6: connect ALL signals that trigger saves — LAST
        # ------------------------------------------------------------------
        # Label-update only (no save)
        self.sld_psf.valueChanged.connect(self._psf_label)
        self.sld_st_amt.valueChanged.connect(self._on_st_amt)
        self.sld_nst_amt.valueChanged.connect(self._on_nst_amt)
        self.sld_dn_lum.valueChanged.connect(lambda v: self.lbl_dn_lum.setText(f"Luminance Denoise (0–1): {v/100:.2f}"))
        self.sld_dn_col.valueChanged.connect(lambda v: self.lbl_dn_col.setText(f"Color Denoise (0–1): {v/100:.2f}"))
        self.sld_target_median.valueChanged.connect(self._on_target_median)
        self.chk_temp_stretch.toggled.connect(self._temp_stretch_changed)
        self.chk_dn_sep.toggled.connect(self._dn_sep_changed)
 
        # Mode visibility
        self.cmb_mode.currentIndexChanged.connect(self._mode_changed)
        self.rb_correct_only.toggled.connect(self._mode_changed)
        self.rb_correct_sharpen.toggled.connect(self._mode_changed)
        self.rb_sharpen_only.toggled.connect(self._mode_changed)
        self.cmb_dn_model.currentIndexChanged.connect(self._dn_model_changed)
 
        # Save on any user change
        self.sld_st_amt.valueChanged.connect(self._save_cc_ui_settings)
        self.sld_nst_amt.valueChanged.connect(self._save_cc_ui_settings)
        self.sld_psf.valueChanged.connect(self._save_cc_ui_settings)
        self.sld_dn_lum.valueChanged.connect(self._save_cc_ui_settings)
        self.sld_dn_col.valueChanged.connect(self._save_cc_ui_settings)
        self.sld_target_median.valueChanged.connect(self._save_cc_ui_settings)
        self.chk_auto_psf.toggled.connect(self._save_cc_ui_settings)
        self.chk_sh_sep.toggled.connect(self._save_cc_ui_settings)
        self.chk_dn_sep.toggled.connect(self._save_cc_ui_settings)
        self.chk_dn_compat.toggled.connect(self._save_cc_ui_settings)
        self.chk_aberration_first.toggled.connect(self._save_cc_ui_settings)
        self.cmb_correct_ver.currentTextChanged.connect(self._save_cc_ui_settings)
        self.chk_temp_stretch.toggled.connect(self._save_cc_ui_settings)
        self.cmb_sh_mode.currentTextChanged.connect(self._save_cc_ui_settings)
        self.cmb_dn_mode.currentTextChanged.connect(self._save_cc_ui_settings)
        self.cmb_mode.currentIndexChanged.connect(self._save_cc_ui_settings)
        self.cmb_gpu.currentIndexChanged.connect(self._save_cc_ui_settings)
        self.cmb_target.currentIndexChanged.connect(self._save_cc_ui_settings)
        self.cmb_scale.currentTextChanged.connect(self._save_cc_ui_settings)
        self.rb_correct_only.toggled.connect(self._save_cc_ui_settings)
        self.rb_correct_sharpen.toggled.connect(self._save_cc_ui_settings)
        self.rb_sharpen_only.toggled.connect(self._save_cc_ui_settings)
        self.chk_correct_conservative.toggled.connect(self._save_cc_ui_settings)
 
        self.setMinimumSize(760, 520)
        self._restore_cc_geometry()
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(0, self._deferred_resize)


    def _dn_model_changed(self, idx: int):
            self._save_cc_ui_settings()

    def _clear_ai_cache_clicked(self):
        # Don’t allow cache clearing mid-run (can invalidate active model refs)
        if self._engine_thread is not None and self._engine_thread.isRunning():
            QMessageBox.information(self, "Cosmic Clarity", "Please wait for the current run to finish before clearing cache.")
            return

        # Optional: “aggressive” flush
        aggressive = True  # set False if you want gentler behavior

        try:
            # Denoise cache
            try:
                from setiastro.saspro.cosmicclarity_engines.denoise_engine import clear_denoise_models_cache
                clear_denoise_models_cache(aggressive=aggressive, status_cb=print)
            except Exception as e:
                print(f"[CC] clear_denoise_models_cache failed: {type(e).__name__}: {e}")

            # Sharpen cache (if exists)
            try:
                from setiastro.saspro.cosmicclarity_engines.sharpen_engine import clear_sharpen_models_cache
                clear_sharpen_models_cache(aggressive=aggressive, status_cb=print)
            except Exception:
                pass

            # Superres cache (if you have one)
            # try:
            #     from setiastro.saspro.cosmicclarity_engines.superres_engine import clear_superres_models_cache
            #     clear_superres_models_cache(aggressive=aggressive, status_cb=print)
            # except Exception:
            #     pass

            QMessageBox.information(
                self,
                "Cosmic Clarity",
                "AI cache cleared.\n\nNext AI run will take longer because models must reload."
            )

        except Exception as e:
            QMessageBox.warning(self, "Cosmic Clarity", f"Failed to clear AI cache:\n{e}")

    def _on_target_median(self, v: int):
        tm = max(0.01, min(0.50, v / 100.0))
        self.lbl_target_median.setText(f"Target Median (0.01–0.50): {tm:.2f}")
        self._save_cc_ui_settings()

    def _temp_stretch_changed(self, checked: bool):
        self.lbl_target_median.setEnabled(bool(checked))
        self.sld_target_median.setEnabled(bool(checked))
        self._save_cc_ui_settings()

 
    def _load_cc_ui_settings(self):
        """Load all persisted settings, blocking all widget signals to prevent save-during-load."""
        s = QSettings()
 
        # Collect every widget that might fire a signal during setValue/setChecked
        all_widgets = [
            self.cmb_dn_model, self.chk_dn_compat, self.chk_temp_stretch,
            self.sld_target_median, self.chk_aberration_first,
            self.sld_st_amt, self.sld_nst_amt, self.sld_psf,
            self.chk_auto_psf, self.chk_sh_sep, self.cmb_sh_mode,
            self.sld_dn_lum, self.sld_dn_col, self.cmb_dn_mode, self.chk_dn_sep,
            self.cmb_mode, self.cmb_gpu, self.cmb_target, self.cmb_scale,
            self.rb_correct_only, self.rb_correct_sharpen, self.rb_sharpen_only,self.cmb_correct_ver,
            self.chk_correct_conservative,
        ]
 
        # Block all signals before touching any widget
        for w in all_widgets:
            w.blockSignals(True)
 
        try:
            # Denoise model + compat
            dn_model = s.value("cc/denoise_model", "Standard")
            idx = self.cmb_dn_model.findText(str(dn_model))
            self.cmb_dn_model.setCurrentIndex(max(0, idx))
 
            compat = s.value("cc/gpu_compat_mode", None)
            if compat is None:
                compat = s.value("cc/denoise_compat_mode", False, type=bool)
            else:
                compat = s.value("cc/gpu_compat_mode", False, type=bool)
            self.chk_dn_compat.setChecked(bool(compat))
 
            # Temp stretch + target median
            self.chk_temp_stretch.setChecked(s.value("cc/temp_stretch", True, type=bool))
            try:
                tm = max(1, min(50, int(float(s.value("cc/target_median", 0.25)) * 100)))
            except Exception:
                tm = 25
            self.sld_target_median.setValue(tm)
 
            self.chk_aberration_first.setChecked(False) 
 
            # Sharpen sliders
            try:
                self.sld_st_amt.setValue(int(s.value("cc/stellar_amount", 50)))
            except Exception:
                self.sld_st_amt.setValue(50)
            try:
                self.sld_nst_amt.setValue(int(s.value("cc/nonstellar_amount", 50)))
            except Exception:
                self.sld_nst_amt.setValue(50)
            try:
                self.sld_psf.setValue(int(s.value("cc/nonstellar_psf", 30)))
            except Exception:
                self.sld_psf.setValue(30)
 
            self.chk_auto_psf.setChecked(s.value("cc/auto_psf", True, type=bool))
            self.chk_sh_sep.setChecked(s.value("cc/sharpen_sep", False, type=bool))
            corr_ver = s.value("cc/correct_model_version", "V2 (latest)", type=str)
            idx = self.cmb_correct_ver.findText(corr_ver)
            self.cmb_correct_ver.setCurrentIndex(max(0, idx))
            self.chk_correct_conservative.setChecked(s.value("cc/correct_conservative", False, type=bool))
            sh_mode = str(s.value("cc/sharpening_mode", "Both"))
            if self.cmb_sh_mode.findText(sh_mode) >= 0:
                self.cmb_sh_mode.setCurrentText(sh_mode)
 
            # Denoise sliders
            try:
                self.sld_dn_lum.setValue(int(s.value("cc/denoise_luma", 50)))
            except Exception:
                self.sld_dn_lum.setValue(50)
            try:
                self.sld_dn_col.setValue(int(s.value("cc/denoise_color", 50)))
            except Exception:
                self.sld_dn_col.setValue(50)
 
            dn_mode = str(s.value("cc/denoise_mode", "full"))
            if self.cmb_dn_mode.findText(dn_mode) >= 0:
                self.cmb_dn_mode.setCurrentText(dn_mode)
 
            self.chk_dn_sep.setChecked(s.value("cc/denoise_sep", False, type=bool))
 
            # General combos
            try:
                self.cmb_mode.setCurrentIndex(int(s.value("cc/mode", 0)))
            except Exception:
                self.cmb_mode.setCurrentIndex(0)
            try:
                self.cmb_gpu.setCurrentIndex(int(s.value("cc/gpu", 0)))
            except Exception:
                self.cmb_gpu.setCurrentIndex(0)
            try:
                self.cmb_target.setCurrentIndex(int(s.value("cc/target", 0)))
            except Exception:
                self.cmb_target.setCurrentIndex(0)
 
            scale = str(s.value("cc/scale", "2x"))
            if self.cmb_scale.findText(scale) >= 0:
                self.cmb_scale.setCurrentText(scale)
 
            # Stellar correct mode radio
            scm = str(s.value("cc/stellar_correct_mode", "correct_sharpen"))
            if scm == "correct_only":
                self.rb_correct_only.setChecked(True)
            elif scm == "sharpen_only":
                self.rb_sharpen_only.setChecked(True)
            else:
                self.rb_correct_sharpen.setChecked(True)
 
        finally:
            # Always unblock — even if something raised
            for w in all_widgets:
                w.blockSignals(False)


    def _save_cc_ui_settings(self):
        s = QSettings()
        s.setValue("cc/denoise_model", self.cmb_dn_model.currentText())
        s.setValue("cc/gpu_compat_mode", self.chk_dn_compat.isChecked())
        s.setValue("cc/denoise_compat_mode", self.chk_dn_compat.isChecked())
        s.setValue("cc/temp_stretch", self.chk_temp_stretch.isChecked())
        s.setValue("cc/target_median", self.sld_target_median.value() / 100.0)
        s.setValue("cc/aberration_first", self.chk_aberration_first.isChecked())
        s.setValue("cc/stellar_amount", self.sld_st_amt.value())
        s.setValue("cc/correct_model_version", self.cmb_correct_ver.currentText())
        s.setValue("cc/correct_conservative", self.chk_correct_conservative.isChecked())
        s.setValue("cc/nonstellar_amount", self.sld_nst_amt.value())
        s.setValue("cc/nonstellar_psf", self.sld_psf.value())
        s.setValue("cc/auto_psf", self.chk_auto_psf.isChecked())
        s.setValue("cc/sharpen_sep", self.chk_sh_sep.isChecked())
        s.setValue("cc/sharpening_mode", self.cmb_sh_mode.currentText())
        s.setValue("cc/denoise_luma", self.sld_dn_lum.value())
        s.setValue("cc/denoise_color", self.sld_dn_col.value())
        s.setValue("cc/denoise_mode", self.cmb_dn_mode.currentText())
        s.setValue("cc/denoise_sep", self.chk_dn_sep.isChecked())
        s.setValue("cc/mode", self.cmb_mode.currentIndex())
        s.setValue("cc/gpu", self.cmb_gpu.currentIndex())
        s.setValue("cc/target", self.cmb_target.currentIndex())
        s.setValue("cc/scale", self.cmb_scale.currentText())
        s.setValue("cc/stellar_correct_mode",
            "correct_only"    if self.rb_correct_only.isChecked()    else
            "correct_sharpen" if self.rb_correct_sharpen.isChecked() else
            "sharpen_only"
        )



    def _dn_sep_changed(self, checked: bool):
        """Separate-channels means mono model per RGB channel, so disable chroma controls."""
        self._update_denoise_dependent_ui()

    def _update_denoise_dependent_ui(self):
        # Only relevant when Denoise controls are currently in play (Denoise or Both mode)
        idx = self.cmb_mode.currentIndex()
        denoise_active = idx in (1, 2)  # 1 Denoise, 2 Both
        if not denoise_active:
            return

        sep = bool(self.chk_dn_sep.isChecked())

        # Option A: DISABLE (recommended: user sees it exists but is inactive)
        self.lbl_dn_col.setEnabled(not sep)
        self.sld_dn_col.setEnabled(not sep)

        self.lbl_dn_mode.setEnabled(not sep)
        self.cmb_dn_mode.setEnabled(not sep)

        # Optional: tooltip explanation when disabled
        tip = ("Disabled because 'Process RGB channels separately' uses the mono model on R/G/B "
            "and does not use the color model.")
        if sep:
            self.lbl_dn_col.setToolTip(tip)
            self.sld_dn_col.setToolTip(tip)
            self.lbl_dn_mode.setToolTip(tip)
            self.cmb_dn_mode.setToolTip(tip)
        else:
            self.lbl_dn_col.setToolTip("")
            self.sld_dn_col.setToolTip("")
            self.lbl_dn_mode.setToolTip("")
            self.cmb_dn_mode.setToolTip("")


    def _set_overlap_pct(self, pct):
        """Select the overlap combo item nearest to the given percentage."""
        self.cmb_ov.setCurrentText(f"{nearest_overlap_pct(pct)}%")

    def _load_chunk_overlap_settings(self):
        s = QSettings()
        chunk = s.value("cc/chunk_size", "256")
        if self.cmb_chunk.findText(str(chunk)) >= 0:
            self.cmb_chunk.setCurrentText(str(chunk))

        # Overlap is now stored as a percentage of the tile (0-50).
        pct = s.value("cc/overlap_pct", None)
        if pct is None:
            # Migrate a legacy pixel overlap -> percentage using the saved chunk.
            try:
                legacy_px = float(s.value("cc/overlap", 64))
                ck = int(self.cmb_chunk.currentText())
                pct = round(100.0 * legacy_px / max(1, ck))
            except Exception:
                pct = DEFAULT_OVERLAP_PCT
        self._set_overlap_pct(pct)

    def _save_chunk_overlap_settings(self):
        s = QSettings()
        s.setValue("cc/chunk_size", self.cmb_chunk.currentText())
        s.setValue("cc/overlap_pct", int(parse_overlap_pct(self.cmb_ov.currentText())))


    def _ensure_models_installed_or_bail(self) -> bool:
        ok, detail = _cc_models_installed("core")
        if ok:
            return True

        msg = (
            "Cosmic Clarity AI models are not installed (or are incomplete).\n\n"
            "To install them:\n"
            "  Preferences → AI Models → Download/Update Models\n"
        )
        if detail:
            msg += f"\nDetails: {detail}\n"

        QMessageBox.warning(self, "Cosmic Clarity", msg)
        QTimer.singleShot(0, self.reject)
        return False



    # ----- UI helpers -----
    def _headless_guard_active(self) -> bool:
        # 1) fast path: flags on the main window
        try:
            p = self.parent()
            if p and (getattr(p, "_cosmicclarity_guard", False) or getattr(p, "_cosmicclarity_headless_running", False)):
                return True
        except Exception:
            pass
        # 2) cross-module path: QSettings flag set by the preset runner
        try:
            s = QSettings()
            v = s.value("cc/headless_in_progress", False, type=bool)
            return bool(v)
        except Exception:
            # fallback if type kwarg unsupported in some Qt builds
            try:
                return bool(QSettings().value("cc/headless_in_progress", False))
            except Exception:
                return False

    # Never show if guard is active
    def showEvent(self, e):
        if self._headless_guard_active():
            e.ignore()
            QTimer.singleShot(0, self.reject)
            return
        return super().showEvent(e)

    # Never exec if guard is active
    def exec(self) -> int:
        if self._headless_guard_active():
            return 0
        return super().exec()


    def _on_st_amt(self, v: int): self.lbl_st_amt.setText(f"Stellar Amount (0–1): {v/100:.2f}")
    def _on_nst_amt(self, v: int): self.lbl_nst_amt.setText(f"Non-Stellar Amount (0–1): {v/100:.2f}")

    def _psf_label(self):
        self.lbl_psf.setText(f"Non-Stellar PSF (1.0–8.0): {self.sld_psf.value()/10:.1f}")

    def _mode_changed(self):
        idx = self.cmb_mode.currentIndex()  # 0 Sharpen, 1 Denoise, 2 Both, 3 Super-Res
        show_sh = idx in (0, 2)
        show_dn = idx in (1, 2)
        show_sr = idx == 3
        show_gpu = not show_sr
 
        # Correction radio buttons only visible when Sharpen group is shown AND model is installed
        _ca = getattr(self, "_correct_available", False)
        _cv2 = getattr(self, "_correct_v2_available", False)
        corr_active = show_sh and _ca
        for w in (self.lbl_stellar_correct,
                  self.rb_correct_only, self.rb_correct_sharpen, self.rb_sharpen_only):
            w.setVisible(corr_active)

        # Show version selector only when correction is active and at least one version installed
        self.lbl_correct_ver.setVisible(corr_active)
        self.cmb_correct_ver.setVisible(corr_active)
        self.chk_correct_conservative.setVisible(corr_active)
 
        # Sharpening sub-controls hidden when Correct Only is selected
        _ca = getattr(self, "_correct_available", False)
        sharpen_active = show_sh and not (_ca and self.rb_correct_only.isChecked())
        for w in (self.lbl_sh_mode, self.cmb_sh_mode, self.chk_sh_sep,
                  self.chk_auto_psf, self.lbl_psf, self.sld_psf,
                  self.lbl_st_amt, self.sld_st_amt,
                  self.lbl_nst_amt, self.sld_nst_amt):
            w.setVisible(sharpen_active)
 
        for w in (self.lbl_dn_lum, self.sld_dn_lum,
                  self.lbl_dn_col, self.sld_dn_col,
                  self.lbl_dn_mode, self.cmb_dn_mode,
                  self.chk_dn_sep, self.cmb_dn_model, self.lbl_dn_model):
            w.setVisible(show_dn)
 
        self.chk_dn_compat.setVisible(idx in (0, 1, 2))
 
        for w in (self.lbl_scale, self.cmb_scale):
            w.setVisible(show_sr)
 
        self.lbl_gpu.setVisible(show_gpu)
        self.cmb_gpu.setVisible(show_gpu)
 
        self._update_denoise_dependent_ui()
        self._relayout_after_visibility_change()

    def _relayout_after_visibility_change(self):
        from PyQt6.QtCore import QTimer
        def _do():
            try:
                self.layout().activate()
                for child in self.findChildren(QGroupBox):
                    child.layout().activate()
                    child.updateGeometry()
                self.adjustSize()
                # if we have a saved geometry, don't let adjustSize shrink below it
                s = QSettings()
                g = s.value("cc/dialog_geometry")
                if g:
                    self.restoreGeometry(g)
            except Exception:
                pass
        QTimer.singleShot(0, _do)

    # ----- Validation -----
    def _validate_root(self) -> bool:
        return True

    # ----- Execution -----
    def _run_main(self):
        # --- Basic safety: make sure we have an image ---
        try:
            img = np.asarray(getattr(self.doc, "image", None))
            if img is None or img.size == 0:
                QMessageBox.warning(self, "Cosmic Clarity", "No image loaded in the active view.")
                return
        except Exception:
            QMessageBox.warning(self, "Cosmic Clarity", "No image loaded in the active view.")
            return

        # --- Register this run as "last action" for replay (same as you had) ---
        try:
            main = self.parent_ref or self.parent()
            if main is not None:
                preset = self.build_preset_from_ui()
                if hasattr(main, "_remember_last_headless_command"):
                    main._remember_last_headless_command(
                        "cosmic_clarity", preset,
                        description=f"Cosmic Clarity ({preset.get('mode', 'sharpen')})"
                    )
                else:
                    main._last_headless_command = {
                        "command_id": "cosmic_clarity",
                        "preset": preset,
                    }
                    if hasattr(main, "_update_replay_button"):
                        main._update_replay_button()
        except Exception:
            pass

        # --- Snapshot UI preset ---
        # --- Snapshot UI preset ---
        preset = self.build_preset_from_ui()
        mode = str(preset.get("mode", "sharpen")).lower()

        # --- Walking noise model availability check ---
        if preset.get("denoise_walking", False) and mode in ("denoise", "both"):
            try:
                from setiastro.saspro.resources import get_resources
                R = get_resources()
                mono_path  = getattr(R, "CC_DENOISE_MONO_WALKING_PTH", None)
                color_path = getattr(R, "CC_DENOISE_COLOR_WALKING_PTH", None)
                import os as _os
                missing = []
                if not mono_path or not _os.path.exists(mono_path):
                    missing.append("deep_denoise_mono_AI4.1w_weights.pth")
                if not color_path or not _os.path.exists(color_path):
                    missing.append("deep_denoise_color_AI4.1w_weights.pth")
                if missing:
                    QMessageBox.warning(
                        self,
                        "Walking Noise Model Not Installed",
                        "The Walking Noise denoise model is not installed:\n\n"
                        + "\n".join(f"  • {m}" for m in missing)
                        + "\n\nPlease go to Settings → Preferences → AI Models "
                        "to download and install the latest models."
                    )
                    return
            except Exception:
                pass

        arr = np.asarray(self.doc.image, dtype=np.float32)

        # Track mono BEFORE expanding to 3-channel for the engine
        orig_was_mono = (arr.ndim == 2) or (arr.ndim == 3 and arr.shape[2] == 1)

        if arr.ndim == 2:
            arr = np.repeat(arr[..., None], 3, axis=2)
        elif arr.ndim == 3 and arr.shape[2] == 1:
            arr = np.repeat(arr, 3, axis=2)
        elif arr.ndim == 3 and arr.shape[2] >= 3:
            arr = arr[..., :3]
        else:
            QMessageBox.critical(self, "Cosmic Clarity", f"Unsupported image shape: {arr.shape}")
            return

        arr = np.clip(arr, 0.0, 1.0).astype(np.float32, copy=False)

        # Stash for use in result handler
        self._orig_was_mono = orig_was_mono

        # --- Show wait/progress UI ---
        title = "Cosmic Clarity – " + (
            "Sharpen + Denoise" if mode == "both" else
            "Super Resolution"  if mode == "superres" else
            mode.title()
        )
        self._wait = WaitDialog(title, self)
        self._wait.set_progress(0)
        self._wait.append_output("Starting…")
        self._wait.cancelled.connect(self._cancel_all_engine)
        self._wait.show()

        # --- Run the in-process engine worker ---
        self._engine_thread = CosmicClarityEngineWorker(arr, preset, parent=self)

        self._engine_thread.progress.connect(lambda p: self._wait.set_progress(int(p)) if self._wait else None)
        self._engine_thread.log.connect(lambda s: self._wait.append_output(str(s)) if self._wait else None)
        self._engine_thread.error.connect(self._on_engine_error)
        self._engine_thread.result.connect(self._on_engine_result)

        # IMPORTANT: cleanup when the thread actually finishes
        self._engine_thread.finished.connect(self._engine_cleanup_and_maybe_close)
        # disable cache clearing during an active run
        try:
            self.btn_clear_cache.setEnabled(False)
        except Exception:
            pass
        self._engine_thread.start()


    def _cancel_all_engine(self):
        thr = getattr(self, "_engine_thread", None)
        if thr is not None:
            try:
                thr.cancel()                # your flag
                thr.requestInterruption()   # Qt-native interruption request
            except Exception:
                pass

        # Keep the wait dialog open (or show "Canceling…") instead of closing immediately
        if self._wait:
            self._wait.append_output("Cancel requested… waiting for worker to stop.")
            self._wait.set_progress(0)
            # optionally disable cancel button to avoid spam clicks:
            # (you'd need to store the cancel button in WaitDialog to disable it)

            # If you really want to hide it, do hide() not close() (close may cascade deletes)
            # self._wait.hide()


    def _on_engine_error(self, msg: str):
        if self._wait:
            self._wait.close()
            self._wait = None

        text = str(msg)

        # Runtime-diagnosed acceleration problems: show the message runtime_torch
        # composed, not a fixed generic one. It already carries the missing-package
        # list AND, when the in-process fallback tripped over a real error (typical
        # cases: a torch and torchvision built against different releases surface
        # as ``operator torchvision::nms does not exist``; a HIP/CUDA library the
        # installed torch expects but the driver does not really support surfaces
        # as an ``undefined symbol`` or a load failure), the underlying error too.
        # That detail is the searchable string a user actually needs. The old
        # handler swallowed it and told everyone to click Install/Repair, which
        # does not help when the runtime is installed-but-broken.
        if "GPU acceleration runtime" in text or "Hardware acceleration runtime" in text:
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Icon.Warning)
            box.setWindowTitle("Cosmic Clarity")
            box.setText("Hardware acceleration is not usable for this run.")
            box.setInformativeText(text)
            box.setStandardButtons(QMessageBox.StandardButton.Ok)
            box.exec()
            return

        QMessageBox.critical(self, "Cosmic Clarity", text)

    def _on_engine_result(self, out_arr: np.ndarray, step_title: str):
        if self._wait:
            self._wait.close()
            self._wait = None

        # Capture preset HERE on the main thread before any processing
        preset = {}
        try:
            preset = self.build_preset_from_ui()
        except Exception:
            pass

        if getattr(self, "_orig_was_mono", False):
            if out_arr.ndim == 3:
                out_arr = out_arr.mean(axis=2).astype(np.float32)

        out_arr = self._blend_with_mask(out_arr)

        create_new = (self.cmb_target.currentIndex() == 1)
        if create_new:
            ok = self._spawn_new_doc_from_numpy(out_arr, step_title)
            if not ok:
                self._apply_to_active(out_arr, step_title, preset=preset)
        else:
            self._apply_to_active(out_arr, step_title, preset=preset)

        self.accept()


    def _base_name(self) -> str:
        fp = getattr(self.doc, "file_path", None)
        if isinstance(fp, str) and fp:
            return os.path.splitext(os.path.basename(fp))[0]
        name = getattr(self.doc, "display_name", None)
        if callable(name):
            try:
                n = name() or ""
                if n:
                    return "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in n).strip("_") or "image"
            except Exception:
                pass
        return "image"

    def _active_mask_id(self) -> str | None:
        return getattr(self.doc, "active_mask_id", None) or None

    def _blend_with_mask(self, processed: np.ndarray) -> np.ndarray:
        mid = self._active_mask_id()
        if not mid:
            return processed

        layer = getattr(self.doc, "masks", {}).get(mid)
        if layer is None:
            return processed

        m = np.asarray(getattr(layer, "data", None))
        if m is None or m.size == 0:
            return processed

        m = m.astype(np.float32)
        # Guard against uint mask or float mask with values > 1
        if m.dtype.kind in "ui":
            imax = float(np.iinfo(m.dtype).max)
            m = m / imax if imax > 0 else m
        else:
            mx = float(m.max()) if m.size else 0.0
            if mx > 1.0:
                m = m / mx
            elif mx == 0.0:
                return processed  # ← blank mask = no effect, return unmodified

        m = np.clip(m, 0.0, 1.0)

        mh, mw = m.shape[:2]
        oh, ow = processed.shape[:2]
        if (mh, mw) != (oh, ow):
            yi = np.linspace(0, mh - 1, oh).astype(np.int32)
            xi = np.linspace(0, mw - 1, ow).astype(np.int32)
            m = m[yi][:, xi]

        src = self.orig.astype(np.float32)  # always 3-channel now

        out = processed.astype(np.float32)

        if out.ndim == 3 and out.shape[2] >= 3:
            m = m[..., None]
            if src.ndim == 2:
                src = np.stack([src] * 3, axis=-1)
        elif out.ndim == 2:
            if src.ndim == 3:
                src = src[..., 0]

        result = m * out + (1.0 - m) * src
        if not np.isfinite(result).all():
            return processed  # ← safety net: never return NaN to the document
        return result.astype(np.float32)

    def _apply_to_active(self, arr: np.ndarray, step_title: str, preset: dict | None = None):
        mid = self._active_mask_id()

        if preset is None:
            preset = {}

        meta = {
            "step_name": step_title,
            "command_id": "cosmic_clarity",
            "preset": preset,
            "masked": bool(mid),
            "mask_id": mid,
            "mask_blend": "m*out+(1-m)*src",
        }
        if hasattr(self.doc, "apply_edit"):
            self.doc.apply_edit(arr, meta, step_name=step_title)
        elif hasattr(self.doc, "set_image"):
            self.doc.set_image(arr, step_name=step_title)
        else:
            self.doc.image = arr

    def _spawn_new_doc_from_numpy(self, arr: np.ndarray, step_title: str) -> bool:
        """Create a brand-new document + view from a numpy array. Returns True on success."""
        mw = self.parent()
        dm = getattr(mw, "docman", None)
        if dm is None:
            return False

        # build a reasonable title and metadata
        base_name = getattr(self.doc, "display_name", None)
        base = base_name() if callable(base_name) else (base_name or "Image")
        title = f"{base} [{step_title}]"

        meta = {
            "bit_depth": "32-bit floating point",
            "is_mono": (arr.ndim == 2) or (arr.ndim == 3 and arr.shape[2] == 1),
            "source": "Cosmic Clarity",
            "original_header": getattr(self.doc, "original_header", None),
        }

        try:
            new_doc = dm.open_array(arr.astype(np.float32, copy=False), metadata=meta, title=title)
            if hasattr(mw, "_spawn_subwindow_for"):   # same hook used in ABE
                mw._spawn_subwindow_for(new_doc)
            return True
        except Exception as e:
            QMessageBox.critical(self, "Cosmic Clarity", f"Failed to create new view:\n{e}")
            return False


    # ----- Super-resolution -----

    def apply_preset(self, p: dict):
        # Mode
        mode = str(p.get("mode","sharpen")).lower()
        self.cmb_mode.setCurrentIndex({"sharpen":0,"denoise":1,"both":2,"superres":3}.get(mode,0))
        # GPU
        self.cmb_gpu.setCurrentIndex(0 if p.get("gpu", True) else 1)
        # Target
        self.cmb_target.setCurrentIndex(1 if p.get("create_new_view", False) else 0)
        # Sharpen
        self.cmb_sh_mode.setCurrentText(p.get("sharpening_mode","Both"))
        self.chk_auto_psf.setChecked(bool(p.get("auto_psf", True)))
        self.sld_psf.setValue(int(max(10, min(80, round(float(p.get("nonstellar_psf",3.0))*10)))))
        self.sld_st_amt.setValue(int(max(0, min(100, round(float(p.get("stellar_amount", 0.5)) * 100)))))
        self.sld_nst_amt.setValue(int(max(0, min(100, round(float(p.get("nonstellar_amount",0.5))*100)))))
        self.chk_correct_conservative.setChecked(bool(p.get("correct_conservative", False)))
        # NEW: allow presets to opt into per-channel sharpen (still defaults off without a preset)
        self.chk_sh_sep.setChecked(bool(p.get("sharpen_channels_separately", False)))
        scm = p.get("stellar_correct_mode", "sharpen_only")
        self.rb_correct_only.setChecked(scm == "correct_only")
        self.rb_correct_sharpen.setChecked(scm == "correct_sharpen")
        self.rb_sharpen_only.setChecked(scm not in ("correct_only", "correct_sharpen"))
        self._mode_changed()   # refresh sub-control visibility
        corr_ver = p.get("correct_model_version", "V2 (latest)")
        idx = self.cmb_correct_ver.findText(corr_ver)
        if idx >= 0:
            self.cmb_correct_ver.setCurrentIndex(idx)
        if "chunk_size" in p:
            self.cmb_chunk.setCurrentText(str(int(p["chunk_size"])))
        if p.get("overlap_pct") is not None:
            self._set_overlap_pct(p["overlap_pct"])
        elif "overlap" in p:
            # Legacy pixel overlap -> percentage of this preset's chunk size.
            try:
                ck = int(p.get("chunk_size", self.cmb_chunk.currentText()))
                self._set_overlap_pct(round(100.0 * float(p["overlap"]) / max(1, ck)))
            except Exception:
                self._set_overlap_pct(DEFAULT_OVERLAP_PCT)
        # Denoise
        self.sld_dn_lum.setValue(int(max(0, min(100, round(float(p.get("denoise_luma",0.5))*100)))))
        self.sld_dn_col.setValue(int(max(0, min(100, round(float(p.get("denoise_color",0.5))*100)))))
        # Denoise model variant
        if p.get("denoise_walking", False):
            self.cmb_dn_model.setCurrentText("Walking Noise")
        elif p.get("denoise_lite", False):
            self.cmb_dn_model.setCurrentText("Lite (faster)")
        else:
            self.cmb_dn_model.setCurrentText("Standard")
        self.chk_dn_sep.setChecked(bool(p.get("separate_channels", False)))

        self.chk_dn_compat.setChecked(bool(
            p.get("compat_mode", p.get("denoise_compat_mode", False))
        ))
        # NEW: temp stretch
        self.chk_temp_stretch.setChecked(bool(p.get("temp_stretch", False)))
        self.chk_aberration_first.setChecked(bool(p.get("aberration_first", False)))
        try:
            tm = float(p.get("target_median", 0.25))
        except Exception:
            tm = 0.25
        tm = max(0.01, min(0.50, tm))
        self.sld_target_median.setValue(int(round(tm * 100)))
        self._temp_stretch_changed(self.chk_temp_stretch.isChecked())
        self._update_denoise_dependent_ui()
        # Super-Res
        self.cmb_scale.setCurrentText(str(int(p.get("scale",2))))

    def build_preset_from_ui(self) -> dict:
        """Snapshot current UI state into a preset dict usable by headless runner / replay."""
        idx = self.cmb_mode.currentIndex()  # 0 Sharpen, 1 Denoise, 2 Both, 3 Super-Res
        mode = {0: "sharpen", 1: "denoise", 2: "both", 3: "superres"}.get(idx, "sharpen")

        compat = self.chk_dn_compat.isChecked()

        preset: dict = {
            "mode": mode,
            "gpu": (self.cmb_gpu.currentIndex() == 0),
            "create_new_view": (self.cmb_target.currentIndex() == 1),
            "aberration_first": False,

            # global compatibility controls
            "compat_mode": compat,
            "execution_mode": "compatibility" if compat else "auto",
            "batch_size_override": 1 if compat else 0,
        }


        # Sharpen / Both block
        # Sharpen / Both block
        if mode in ("sharpen", "both"):
            preset.update({
                "sharpening_mode": self.cmb_sh_mode.currentText(),
                "auto_psf": self.chk_auto_psf.isChecked(),
                "nonstellar_psf": self.sld_psf.value() / 10.0,
                "stellar_amount": (self.sld_st_amt.value() / 100.0),
                "nonstellar_amount": self.sld_nst_amt.value() / 100.0,
                "sharpen_channels_separately": self.chk_sh_sep.isChecked(),
                "correct_model_version": self.cmb_correct_ver.currentText(),
                "correct_conservative": self.chk_correct_conservative.isChecked(),
                "chunk_size": int(self.cmb_chunk.currentText()),
                "overlap_pct": parse_overlap_pct(self.cmb_ov.currentText()),
                "temp_stretch": self.chk_temp_stretch.isChecked(),
                "target_median": self.sld_target_median.value() / 100.0,
                "stellar_correct_mode": (
                    (
                        "correct_only"    if self.rb_correct_only.isChecked()    else
                        "correct_sharpen" if self.rb_correct_sharpen.isChecked() else
                        "sharpen_only"
                    ) if getattr(self, "_correct_available", False) else "sharpen_only"
                ),

                # sharpen compatibility controls
                "sharpen_execution_mode": "compatibility" if compat else "auto",
                "sharpen_batch_size_override": 1 if compat else 0,
            })

        # Denoise / Both block
        if mode in ("denoise", "both"):
            dn_model = self.cmb_dn_model.currentText()
            preset.update({
                "denoise_luma": self.sld_dn_lum.value() / 100.0,
                "denoise_color": self.sld_dn_col.value() / 100.0,
                "denoise_mode": self.cmb_dn_mode.currentText(),
                "separate_channels": self.chk_dn_sep.isChecked(),
                "denoise_lite":    (dn_model == "Lite (faster)"),
                "denoise_walking": (dn_model == "Walking Noise"),
                "denoise_compat_mode": compat,
                "denoise_execution_mode": "compatibility" if compat else "auto",
                "denoise_batch_size_override": 1 if compat else 0,
                "temp_stretch": self.chk_temp_stretch.isChecked(),
                "target_median": self.sld_target_median.value() / 100.0,
            })
        # Super-res
        if mode == "superres":
            try:
                scale_txt = self.cmb_scale.currentText()
                # can be "2x" in the main dialog or just "2" in the preset dialog
                scale_txt = scale_txt.replace("x", "")
                preset["scale"] = int(scale_txt)
            except Exception:
                preset["scale"] = 2

        return preset

    # ── preset emit / seed (grip + double-click) ───────────────────────
    def get_preset(self) -> dict:
        try:
            p = self.build_preset_from_ui()
            return p
        except Exception as e:
            import traceback
            print(f"[CC-GRIP] get_preset RAISED: {type(e).__name__}: {e}", flush=True)
            traceback.print_exc()
            raise

    def seed_from_preset(self, p: dict | None):
        """Seed side for double-click — exact inverse of get_preset. apply_preset
        already inverts every divisor, sets mode first, and drives _mode_changed
        itself, so it is the seed. (dict(p or {}) guards the None case, which
        apply_preset does not.)"""
        self.apply_preset(dict(p or {}))

    def _deferred_resize(self):
        self.adjustSize()
        s = QSettings()
        g = s.value("cc/dialog_geometry")
        if g:
            self.restoreGeometry(g)

    def _restore_cc_geometry(self):
        s = QSettings()
        g = s.value("cc/dialog_geometry")
        if g:
            self.restoreGeometry(g)
        else:
            self.resize(860, 560)

    def closeEvent(self, e):
        thr = getattr(self, "_engine_thread", None)
        if thr is not None and thr.isRunning():
            self._closing_after_cancel = True
            self._cancel_all_engine()
            e.ignore()
            return
        try:
            QSettings().setValue("cc/dialog_geometry", self.saveGeometry())
            QSettings().sync()
        except Exception:
            pass
        super().closeEvent(e)

    def reject(self):
        thr = getattr(self, "_engine_thread", None)
        if thr is not None and thr.isRunning():
            self._closing_after_cancel = True
            self._cancel_all_engine()
            return
        QSettings().setValue("cc/dialog_geometry", self.saveGeometry())
        super().reject()

    def _engine_cleanup_and_maybe_close(self):
        # Called when thread has truly stopped
        try:
            if self._engine_thread is not None:
                self._engine_thread.deleteLater()
        except Exception:
            pass
        self._engine_thread = None

        # ✅ re-enable cache button
        try:
            if hasattr(self, "btn_clear_cache") and self.btn_clear_cache is not None:
                self.btn_clear_cache.setEnabled(True)
        except Exception:
            pass

        if self._closing_after_cancel:
            self._closing_after_cancel = False
            super().reject()

def open_cosmic_clarity_with_preset(main_window, preset: dict | None = None):
    doc = None
    try:
        sw = main_window.mdi.activeSubWindow()
        if sw is not None:
            doc = getattr(sw.widget(), "document", None)
    except Exception:
        doc = None
    if doc is None:
        dm = getattr(main_window, "doc_manager", getattr(main_window, "docman", None))
        if dm is not None:
            try:
                doc = (dm.get_active_document() if hasattr(dm, "get_active_document")
                       else getattr(dm, "active_document", None))
            except Exception:
                doc = None
    if doc is None:
        try:
            ad = getattr(main_window, "_active_doc", None)
            if callable(ad):
                doc = ad()
        except Exception:
            doc = None
    if doc is None or getattr(doc, "image", None) is None:
        return None

    _icon = QIcon()
    try:
        from setiastro.saspro.resources import cosmic_path
        _icon = QIcon(cosmic_path)
    except Exception:
        _icon = QIcon()

    # Interactive open. bypass_guard stays False so a genuine in-progress headless
    # run still blocks a second panel; the guard is inactive during normal use.
    dlg = CosmicClarityDialogPro(main_window, doc, icon=_icon)

    # If __init__ early-rejected (models missing / guard active), its widgets were
    # never built — don't seed a zombie; let its own scheduled reject fire.
    if not hasattr(dlg, "cmb_mode"):
        return dlg

    try:
        dlg.seed_from_preset(preset or {})
    except Exception:
        pass
    try:
        main_window._cosmic_clarity_dialog = dlg   # retain against GC (WA_DeleteOnClose)
    except Exception:
        pass
    dlg.show(); dlg.raise_(); dlg.activateWindow()
    return dlg

# =============================================================================
# Satellite removal 
# =============================================================================


class CosmicClaritySatelliteDialogPro(QDialog):
    """
    Pro dialog that mirrors SASv2 Cosmic Clarity Satellite tab:
      • Select input/output folders, live monitor, or batch process
      • GPU toggle, mode (full/luminance), clip trail, sensitivity, skip-save
      • Tree views for input/output with preview (autostretch + zoom)
    Uses QSettings key: paths/cosmic_clarity
    """
    def __init__(self, parent, doc=None, icon: QIcon | None = None):
        super().__init__(parent)
        self._engine_thread = None
        self._closing_after_cancel = False
        self._wait = None
        ok, detail = _cc_models_installed("satellite")
        if not ok:
            _warn_models_missing_and_close(self, detail)
            try:
                self.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)
            except Exception:
                pass
            QTimer.singleShot(0, self.reject)
            return

        self.setWindowTitle("Cosmic Clarity – Satellite Removal")
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)
        if icon:
            try: self.setWindowIcon(icon)
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

        self.settings = QSettings()
        self.icons = get_icons()

        self.input_folder  = ""
        self.output_folder = ""
        self.sensitivity = 0.10  # 0.01–0.50
        self.doc = doc

        self.file_watcher = QFileSystemWatcher()
        self.file_watcher.directoryChanged.connect(self._on_folder_changed)

        self._sat_thread = None
        self._wait = None

        self._build_ui()
        self._load_satellite_settings()

    # ---------- UI ----------
    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 8, 8, 8)
        outer.setSpacing(8)

        self.lbl_logo = QLabel(self)
        self.lbl_logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        try:
            pm = QPixmap(self.icons.COSMICCLARITYSAT)
            if not pm.isNull():
                self.lbl_logo.setPixmap(
                    pm.scaledToWidth(280, Qt.TransformationMode.SmoothTransformation)
                )
                outer.addWidget(self.lbl_logo, 0, Qt.AlignmentFlag.AlignHCenter)
        except Exception:
            pass

        content = QHBoxLayout()

        # Left controls
        left = QVBoxLayout()

        row_io = QHBoxLayout()
        self.btn_in  = QPushButton("Select Input Folder");  self.btn_in.clicked.connect(self._choose_input)
        self.btn_out = QPushButton("Select Output Folder"); self.btn_out.clicked.connect(self._choose_output)
        row_io.addWidget(self.btn_in)
        row_io.addWidget(self.btn_out)
        row_io.addWidget(make_help_button("cosmic_clarity_satellite", self))
        left.addLayout(row_io)

        left.addWidget(QLabel("Use GPU Acceleration:"))
        self.cmb_gpu = QComboBox()
        self.cmb_gpu.addItems(["Yes", "No"])
        left.addWidget(self.cmb_gpu)

        self.chk_gpu_compat = QCheckBox("GPU Compatibility Mode (slower, safer for low-VRAM GPUs)")
        self.chk_gpu_compat.setChecked(False)
        left.addWidget(self.chk_gpu_compat)

        left.addWidget(QLabel("Satellite Removal Mode:"))
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["Full", "Luminance"])
        left.addWidget(self.cmb_mode)

        self.chk_clip = QCheckBox("Clip Satellite Trail to 0.000")
        self.chk_clip.setChecked(True)
        left.addWidget(self.chk_clip)

        row_sens = QHBoxLayout()
        row_sens.addWidget(QLabel("Clipping Sensitivity (Lower = more aggressive):"))
        self.sld_sens = QSlider(Qt.Orientation.Horizontal)
        self.sld_sens.setRange(1, 50)
        self.sld_sens.setValue(int(self.sensitivity * 100))
        self.sld_sens.setTickInterval(1)
        self.sld_sens.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.sld_sens.valueChanged.connect(self._on_sens_change)
        row_sens.addWidget(self.sld_sens)
        self.lbl_sens_val = QLabel(f"{self.sensitivity:.2f}")
        row_sens.addWidget(self.lbl_sens_val)
        left.addLayout(row_sens)

        self.chk_skip = QCheckBox("Skip Save if No Satellite Trail Detected")
        self.chk_skip.setChecked(False)
        left.addWidget(self.chk_skip)

        self.chk_delete_original = QCheckBox("Delete Original Image After Saving")
        self.chk_delete_original.setChecked(False)
        left.addWidget(self.chk_delete_original)

        row_proc = QHBoxLayout()
        self.btn_single = QPushButton("Process Single Image")
        self.btn_single.clicked.connect(self._process_single_image)
        self.btn_batch = QPushButton("Batch Process Input Folder")
        self.btn_batch.clicked.connect(self._batch_process)
        row_proc.addWidget(self.btn_single)
        row_proc.addWidget(self.btn_batch)
        left.addLayout(row_proc)

        self.btn_monitor = QPushButton("Live Monitor Input Folder")
        self.btn_monitor.clicked.connect(self._live_monitor)
        left.addWidget(self.btn_monitor)

        left.addStretch(1)

        # Right side
        right = QVBoxLayout()
        right.addWidget(QLabel("Input Folder Files:"))
        self.tree_in = QTreeWidget()
        self.tree_in.setHeaderLabels(["Filename"])
        self.tree_in.itemDoubleClicked.connect(lambda *_: self._preview_from_tree(self.tree_in, is_input=True))
        self.tree_in.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree_in.customContextMenuRequested.connect(lambda pos: self._context_menu(self.tree_in, pos, is_input=True))
        right.addWidget(self.tree_in)

        right.addWidget(QLabel("Output Folder Files:"))
        self.tree_out = QTreeWidget()
        self.tree_out.setHeaderLabels(["Filename"])
        self.tree_out.itemDoubleClicked.connect(lambda *_: self._preview_from_tree(self.tree_out, is_input=False))
        self.tree_out.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree_out.customContextMenuRequested.connect(lambda pos: self._context_menu(self.tree_out, pos, is_input=False))
        right.addWidget(self.tree_out)

        content.addLayout(left, 2)
        content.addLayout(right, 1)

        outer.addLayout(content, 1)

        self.resize(900, 600)

    def _load_satellite_settings(self):
        s = self.settings
        
        # Folders
        self.input_folder = s.value("satellite/input_folder", "", type=str) or ""
        self.output_folder = s.value("satellite/output_folder", "", type=str) or ""
        if self.input_folder:
            self.btn_in.setText(f"Input: {os.path.basename(self.input_folder)}")
            self._watch(self.input_folder)
            self._refresh_tree(self.tree_in, self.input_folder)
        if self.output_folder:
            self.btn_out.setText(f"Output: {os.path.basename(self.output_folder)}")
            self._watch(self.output_folder)
            self._refresh_tree(self.tree_out, self.output_folder)

        gpu = s.value("satellite/use_gpu", "Yes", type=str)
        self.cmb_gpu.setCurrentText(gpu if gpu in ("Yes", "No") else "Yes")
        self.chk_gpu_compat.setChecked(s.value("satellite/gpu_compat", False, type=bool))

        mode = s.value("satellite/mode", "Full", type=str)
        idx = self.cmb_mode.findText(mode)
        self.cmb_mode.setCurrentIndex(idx if idx >= 0 else 0)

        self.chk_clip.setChecked(s.value("satellite/clip_trail", True, type=bool))

        sens = s.value("satellite/sensitivity", 10, type=int)
        self.sld_sens.setValue(max(1, min(50, sens)))

        self.chk_skip.setChecked(s.value("satellite/skip_save", False, type=bool))
        self.chk_delete_original.setChecked(s.value("satellite/delete_original", False, type=bool))

    def _save_satellite_settings(self):
        s = self.settings
        s.setValue("satellite/input_folder", self.input_folder)
        s.setValue("satellite/output_folder", self.output_folder)
        s.setValue("satellite/use_gpu", self.cmb_gpu.currentText())
        s.setValue("satellite/gpu_compat", self.chk_gpu_compat.isChecked())
        s.setValue("satellite/mode", self.cmb_mode.currentText())
        s.setValue("satellite/clip_trail", self.chk_clip.isChecked())
        s.setValue("satellite/sensitivity", self.sld_sens.value())
        s.setValue("satellite/skip_save", self.chk_skip.isChecked())
        s.setValue("satellite/delete_original", self.chk_delete_original.isChecked())
        s.sync()

    def _confirm_delete_originals(self) -> bool:
        """If delete-original is enabled, show ONE warning before a run.
        Returns True to proceed, False to abort."""
        if not self.chk_delete_original.isChecked():
            return True
        resp = QMessageBox.warning(
            self,
            "Delete Originals Enabled",
            "The 'Delete Original Image After Saving' option is checked.\n\n"
            "After each image is successfully processed and saved, the ORIGINAL "
            "file will be permanently deleted. This cannot be undone.\n\n"
            "If satellite removal produces an unexpected result, the original "
            "sub will be gone.\n\n"
            "Do you want to proceed?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        return resp == QMessageBox.StandardButton.Yes

    # ---------- IO folders ----------
    def _choose_input(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Input Folder", self.input_folder or "")
        if not folder:
            return
        self.input_folder = folder
        self.btn_in.setText(f"Input: {os.path.basename(folder)}")
        self._watch(folder)
        self._refresh_tree(self.tree_in, folder)
        self._save_satellite_settings()

    def _choose_output(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Output Folder", self.output_folder or "")
        if not folder:
            return
        self.output_folder = folder
        self.btn_out.setText(f"Output: {os.path.basename(folder)}")
        self._watch(folder)
        self._refresh_tree(self.tree_out, folder)
        self._save_satellite_settings()

    def _watch(self, folder):
        try:
            if folder and folder not in self.file_watcher.directories():
                self.file_watcher.addPath(folder)
        except Exception:
            pass

    def _on_folder_changed(self, path):
        if path == self.input_folder:
            self._refresh_tree(self.tree_in, self.input_folder)
        if path == self.output_folder:
            self._refresh_tree(self.tree_out, self.output_folder)

    def _refresh_tree(self, tree: QTreeWidget, folder: str):
        tree.clear()
        if not folder or not os.path.isdir(folder): return
        for fn in sorted(os.listdir(folder)):
            if fn.lower().endswith(('.png', '.tif', '.tiff', '.fit', '.fits', '.xisf',
                                    '.cr2', '.nef', '.arw', '.dng', '.raf', '.orf', '.rw2', '.pef', '.jpg', '.jpeg')):
                QTreeWidgetItem(tree, [fn])

    # ---------- Sensitivity ----------
    def _on_sens_change(self, v: int):
        self.sensitivity = v / 100.0
        self.lbl_sens_val.setText(f"{self.sensitivity:.2f}")

    # ---------- Context menu ----------
    def _context_menu(self, tree: QTreeWidget, pos, is_input: bool):
        item = tree.itemAt(pos)
        if not item: return
        menu = QMenu(self)
        act_del = QAction("Delete File", self)
        act_ren = QAction("Rename File", self)
        act_del.triggered.connect(lambda: self._delete_file(tree, is_input))
        act_ren.triggered.connect(lambda: self._rename_file(tree, is_input))
        menu.addAction(act_del); menu.addAction(act_ren)
        menu.exec(tree.viewport().mapToGlobal(pos))

    def _folder_of(self, is_input: bool) -> str:
        return self.input_folder if is_input else self.output_folder

    def _delete_file(self, tree: QTreeWidget, is_input: bool):
        item = tree.currentItem()
        if not item: return
        folder = self._folder_of(is_input)
        fp = os.path.join(folder, item.text(0))
        if not os.path.exists(fp): return
        if QMessageBox.question(self, "Confirm Delete", f"Delete {item.text(0)}?",
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes:
            os.remove(fp)
            self._refresh_tree(tree, folder)

    def _rename_file(self, tree: QTreeWidget, is_input: bool):
        item = tree.currentItem()
        if not item: return
        folder = self._folder_of(is_input)
        fp = os.path.join(folder, item.text(0))
        new, ok = QInputDialog.getText(self, "Rename File", "Enter new name:", text=item.text(0))
        if ok and new:
            np = os.path.join(folder, new)
            os.rename(fp, np)
            self._refresh_tree(tree, folder)

    # ---------- Preview ----------
    def _preview_from_tree(self, tree: QTreeWidget, is_input: bool):
        item = tree.currentItem()
        if not item: return
        folder = self._folder_of(is_input)
        fp = os.path.join(folder, item.text(0))
        if not os.path.isfile(fp): return
        try:
            img, _, _, is_mono = load_image(fp)
            if img is None:
                QMessageBox.critical(self, "Error", "Failed to load image for preview.")
                return
            dlg = ImagePreviewDialog(img, is_mono=is_mono, parent=self)
            dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
            dlg.show()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to preview image:\n{e}")

    # ---------- Single image processing ----------
    def _process_single_image(self):
        from PyQt6.QtCore import QCoreApplication, Qt
        from PyQt6.QtWidgets import QMessageBox, QFileDialog, QInputDialog, QProgressDialog

        from setiastro.saspro.cosmicclarity_engines.satellite_engine import (
            get_satellite_models,
            satellite_remove_image,
        )

        # ----------------------------
        # Decide source: view or file
        # ----------------------------
        views = self._collect_open_views()
        use_view = False
        compatibility_mode = bool(self.chk_gpu_compat.isChecked())

        if views:
            mb = QMessageBox(self)
            mb.setWindowTitle("Process Single Image")
            mb.setText("Choose the source to process:")
            btn_view = mb.addButton("Open View", QMessageBox.ButtonRole.AcceptRole)
            btn_file = mb.addButton("File on Disk", QMessageBox.ButtonRole.AcceptRole)
            mb.addButton(QMessageBox.StandardButton.Cancel)
            mb.exec()

            if mb.clickedButton() is btn_view:
                use_view = True
            elif mb.clickedButton() is btn_file:
                use_view = False
            else:
                return

        # ----------------------------
        # Gather engine params from UI
        # ----------------------------
        use_gpu = (self.cmb_gpu.currentText() == "Yes")
        mode = self.cmb_mode.currentText().lower()
        clip_trail = bool(self.chk_clip.isChecked())
        sensitivity = float(self.sensitivity)
        skip_if_none = bool(self.chk_skip.isChecked())

        # ----------------------------------------------------
        # Acquire input image FIRST (no progress dialog yet)
        # ----------------------------------------------------
        hdr = None
        mono = False
        chosen_doc = None
        file_path = None

        if use_view:
            # Choose which doc
            if len(views) == 1:
                chosen_doc = views[0][1]
            else:
                titles = [t for (t, _) in views]
                sel, ok = QInputDialog.getItem(self, "Select View", "Choose an open view:", titles, 0, False)
                if not ok:
                    return
                chosen_doc = views[titles.index(sel)][1]

            if chosen_doc is None or getattr(chosen_doc, "image", None) is None:
                QMessageBox.warning(self, "Warning", "Selected view has no image.")
                return

            try:
                img = np.asarray(chosen_doc.image, dtype=np.float32)
                img = np.clip(img, 0.0, 1.0)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to read image from view:\n{e}")
                return

        else:
            file_path, _ = QFileDialog.getOpenFileName(
                self, "Select Image", "",
                "Image Files (*.png *.tif *.tiff *.fit *.fits *.xisf *.cr2 *.nef *.arw *.dng *.raf *.orf *.rw2 *.pef *.jpg *.jpeg)"
            )
            if not file_path:
                return  # user cancelled file dialog
            if not file_path:
                return  # user cancelled file dialog

            if not self._confirm_delete_originals():
                return
            try:
                result = load_image(file_path, return_metadata=True)
                if result is None or result[0] is None:
                    raise RuntimeError("load_image returned None.")
                img, hdr, bd, mono, meta = result
                img = np.asarray(img, dtype=np.float32)
                img = np.clip(img, 0.0, 1.0)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load image:\n{e}")
                return

        # ----------------------------
        # Load/cached models ONCE
        # ----------------------------
        try:
            import traceback as _tb
            models = get_satellite_models(use_gpu=use_gpu, status_cb=lambda s: None)
        except Exception as e:
            detail = _tb.format_exc()
            QMessageBox.critical(
                self, "Error",
                f"Failed to load Satellite models:\n{e}\n\n{detail}"
            )
            return

        # ----------------------------
        #sasprogress dialog helper
        #   IMPORTANT: create/show AFTER input is chosen
        # ----------------------------
        pd = QProgressDialog("Satellite removal…", "Cancel", 0, 100, self)
        pd.setWindowModality(Qt.WindowModality.WindowModal)
        pd.setMinimumDuration(250)   # helps prevent weird cancel behavior
        pd.setAutoClose(True)
        pd.setAutoReset(True)
        pd.setValue(0)

        cancelled = {"flag": False}

        def _on_cancel():
            cancelled["flag"] = True

        pd.canceled.connect(_on_cancel)

        def _progress(done: int, total: int):
            if total > 0:
                pd.setValue(int((done * 100) / total))
            else:
                pd.setValue(0)

            QCoreApplication.processEvents()

            # IMPORTANT: return True to continue, False to cancel
            return (not cancelled["flag"]) and (not pd.wasCanceled())

        # ----------------------------
        # Run engine
        # ----------------------------
        try:
            cancelled["flag"] = False  # reset right before run
            pd.show()

            out, detected = satellite_remove_image(
                img,
                models=models,
                mode=mode,
                clip_trail=clip_trail,
                sensitivity=sensitivity,
                compatibility_mode=compatibility_mode,
                progress_cb=_progress,
            )

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error processing image:\n{e}")
            return

        finally:
            pass

        # ----------------------------
        # Handle cancel / skip-save
        # ----------------------------
        if cancelled["flag"]:
            QMessageBox.information(self, "Cancelled", "Operation cancelled.")
            return

        if skip_if_none and (not detected):
            QMessageBox.information(self, "Satellite Removal", "No satellite trail detected (skip-save enabled).")
            return

        out = np.asarray(out, dtype=np.float32, order="C")

        # ----------------------------
        # Apply or save
        # ----------------------------
        if use_view:
            if hasattr(chosen_doc, "set_image"):
                chosen_doc.set_image(out, step_name="Cosmic Clarity – Satellite Removal")
            else:
                chosen_doc.image = out
            return

        # file path save
        try:
            base, ext = os.path.splitext(file_path)
            dst = base + "_satellited" + ext

            image_meta = meta.get("xisf_meta") if meta else None
            if image_meta is not None and not isinstance(image_meta, list):
                image_meta = [image_meta]

            fmt, _ = _save_fmt_and_bitdepth_from_path_for_legacy(dst)
            save_image(
                out, dst, fmt or "fits",
                bd or "32-bit floating point",
                hdr, mono,
                image_meta=image_meta,
                file_meta=None,
            )
            QMessageBox.information(self, "Success", f"Processed image saved to:\n{dst}")

            if self.chk_delete_original.isChecked():
                try:
                    if os.path.abspath(file_path) != os.path.abspath(dst):
                        os.remove(file_path)
                        self._refresh_tree(self.tree_in, self.input_folder)
                except Exception as ex:
                    QMessageBox.warning(
                        self, "Delete Original",
                        f"Could not delete original:\n{ex}"
                    )
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save result:\n{e}")

    def _collect_open_views(self):
        """
        Return a list of (title, doc) for all open MDI views with an image.
        Includes self.doc if supplied and valid.
        """
        views = []
        # include self.doc first if valid
        if getattr(self, "doc", None) is not None and getattr(self.doc, "image", None) is not None:
            title = getattr(self.doc, "display_name", lambda: "Active View")()
            views.append((title, self.doc))

        # try to enumerate MDI subwindows on the parent main window
        try:
            main = self.parent()
            mdi = getattr(main, "mdi", None)
            if mdi is not None:
                for sw in mdi.subWindowList():
                    w = sw.widget()
                    d = getattr(w, "document", None)
                    if d is not None and getattr(d, "image", None) is not None:
                        t = w.windowTitle() if hasattr(w, "windowTitle") else getattr(d, "display_name", lambda:"View")()
                        # don’t duplicate self.doc if it’s the same object
                        if not any(d is existing for _, existing in views):
                            views.append((t, d))
        except Exception:
            pass

        return views

    def _base_name_for_doc(self, d):
        """Derive a simple basename for staging temp files from a document."""
        fp = getattr(d, "file_path", None)
        if isinstance(fp, str) and fp:
            return os.path.splitext(os.path.basename(fp))[0]
        name = getattr(d, "display_name", None)
        if callable(name):
            try:
                n = name() or ""
                if n:
                    return "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in n).strip("_") or "image"
            except Exception:
                pass
        return "image"


    def _batch_process(self):
        if not self.input_folder or not self.output_folder:
            QMessageBox.warning(self, "Warning", "Please select both input and output folders.")
            return
        if not self._confirm_delete_originals():
            return
        self._run_engine_thread(monitor=False, title="Satellite – Batch processing")


    def _live_monitor(self):
        if not self.input_folder or not self.output_folder:
            QMessageBox.warning(self, "Warning", "Please select both input and output folders.")
            return
        if not self._confirm_delete_originals():
            return
        self.sld_sens.setEnabled(False)
        self._run_engine_thread(monitor=True, title="Satellite – Live monitoring",
                                on_finish=lambda: self.sld_sens.setEnabled(True))

    def _run_engine_thread(self, *, monitor: bool, title: str, on_finish=None):
        use_gpu = (self.cmb_gpu.currentText() == "Yes")
        mode = self.cmb_mode.currentText().lower()  # "full" / "luminance"
        clip_trail = bool(self.chk_clip.isChecked())
        sensitivity = float(self.sensitivity)
        skip_save = bool(self.chk_skip.isChecked())
        compatibility_mode = bool(self.chk_gpu_compat.isChecked())
        delete_original = bool(self.chk_delete_original.isChecked())
        self._wait = WaitDialog(title, self)
        self._wait.show()

        self._sat_thread = SatelliteEngineThread(
            input_dir=self.input_folder,
            output_dir=self.output_folder,
            use_gpu=use_gpu,
            mode=mode,
            clip_trail=clip_trail,
            sensitivity=sensitivity,
            skip_save=skip_save,
            monitor=monitor,
            compatibility_mode=compatibility_mode,
            delete_original=delete_original,
        )
        self._sat_thread.log_signal.connect(self._wait.append_output)
        self._sat_thread.progress_signal.connect(self._on_sat_progress)
        self._sat_thread.finished_signal.connect(lambda: self._on_thread_finished(on_finish))
        self._wait.cancelled.connect(self._cancel_sat_thread)
        self._sat_thread.start()

    def _on_sat_progress(self, done: int, total: int):
        if not self._wait:
            return
        self._wait.set_progress(done, total)

    # ---------- Command / run ----------

    def _cancel_sat_thread(self):
        if self._sat_thread:
            self._sat_thread.cancel()
        if self._wait:
            self._wait.close()
            self._wait = None

    def _on_thread_finished(self, on_finish):
        if self._wait: self._wait.close(); self._wait = None
        if callable(on_finish):
            try: on_finish()
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
        QMessageBox.information(self, "Done", "Processing finished.")

    def closeEvent(self, e):
        self._save_satellite_settings()
        super().closeEvent(e)
        
    # ---------- Utils ----------
    @staticmethod
    def _create_temp_folder(base="~"):
        user_dir = os.path.expanduser(base)
        temp_folder = os.path.join(user_dir, "CosmicClarityTemp")
        os.makedirs(temp_folder, exist_ok=True)
        return temp_folder

class SatelliteEngineThread(QThread):
    log_signal = pyqtSignal(str)
    finished_signal = pyqtSignal()
    progress_signal = pyqtSignal(int, int)  # done, total

    def __init__(self, *, input_dir: str, output_dir: str,
                use_gpu: bool, mode: str, clip_trail: bool,
                sensitivity: float, skip_save: bool, monitor: bool,
                compatibility_mode: bool,
                delete_original: bool = False,
                poll_seconds: float = 1.0):
        super().__init__()
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.use_gpu = use_gpu
        self.mode = mode
        self.clip_trail = clip_trail
        self.sensitivity = sensitivity
        self.skip_save = skip_save
        self.monitor = monitor
        self.poll_seconds = poll_seconds
        self.compatibility_mode = compatibility_mode
        self.delete_original = delete_original

        self._cancel = False
        self._seen = set()

    def cancel(self):
        self._cancel = True

    def _iter_files(self):
        exts = ('.png', '.tif', '.tiff', '.fit', '.fits', '.xisf',
                '.cr2', '.nef', '.arw', '.dng', '.raf', '.orf', '.rw2', '.pef', '.jpg', '.jpeg')
        try:
            for fn in sorted(os.listdir(self.input_dir)):
                stem = os.path.splitext(fn)[0]
                # Skip files we already processed
                if stem.endswith('_satellited'):
                    continue
                if fn.lower().endswith(exts):
                    yield fn
        except Exception:
            return

    def run(self):
        try:
            from setiastro.saspro.cosmicclarity_engines.satellite_engine import (
                get_satellite_models, satellite_remove_image,
                satellite_detect_tiles,
                ArtifactMapBuilder,
            )

            self.log_signal.emit("Loading Satellite models...")
            try:
                models = get_satellite_models(use_gpu=self.use_gpu, status_cb=self.log_signal.emit)
            except Exception as e:
                import traceback as _tb
                self.log_signal.emit(f"Failed to load Satellite models: {e}\n{_tb.format_exc()}")
                return
            self.log_signal.emit("Models loaded.")

            os.makedirs(self.output_dir, exist_ok=True)

            # ── PASS 1 (batch only): fixed-pattern artifact map ─────────────
            #
            # Build it per IMAGE SHAPE, since a pixel map cannot be shared
            # across sensors and shape is the only grouping key available from
            # a bare folder listing. Shapes are read during the detection scan
            # itself, so nothing extra is loaded.
            #
            # LIVE MONITOR DELIBERATELY OPTS OUT: frames arrive one at a time
            # and the output is written before persistence could ever be
            # established. There is no safe veto to apply there.
            clean_files: set = set()     # scanned and known to have no real trail
            real_tiles_by_file: dict = {}   # fn -> REAL trail tiles from pass 1

            def _build_artifact_maps(file_names):
                """Scan the batch: builds the fixed-pattern map AND records
                which files have no real trail at all.

                The scan runs even when the batch is too small for the map,
                because knowing a file is clean is worth having on its own —
                pass 2 can then skip it outright instead of re-deriving the
                same answer through a full load + pad + tile + detect."""
                if self.monitor or not file_names:
                    return

                self.log_signal.emit(
                    f"Pass 1 of 2: scanning {len(file_names)} file(s) for "
                    f"diffraction spikes / amp glow (nothing is written)…"
                )
                builder = ArtifactMapBuilder()
                scanned_any = False
                for i, fn in enumerate(file_names):
                    if self._cancel:
                        return
                    fp = os.path.join(self.input_dir, fn)
                    try:
                        res = load_image(fp, return_metadata=True)
                        if res is None or res[0] is None:
                            continue
                        im = np.clip(np.asarray(res[0], dtype=np.float32), 0.0, 1.0)
                        shape_hw = tuple(int(v) for v in im.shape[:2])
                        tiles = satellite_detect_tiles(
                            im, models,
                            # MUST be 0: the persistence map is tested back
                            # against whole tiles, so the scan grid has to be
                            # fixed and non-overlapping or a fixed artifact
                            # lands in a different tile subset each frame and
                            # the mask shrinks to an unusable sliver.
                            overlap=0,
                            compatibility_mode=self.compatibility_mode,
                            stop_after=None,
                            status_cb=lambda _m: None,
                        )
                    except Exception as e:
                        self.log_signal.emit(f"Pass 1 skipped {fn}: {e}")
                        continue

                    # Group by Object/Filter/Exposure/Instrument, NOT by shape:
                    # Ha and Green off one camera share a shape, and pooling
                    # them hides the Ha amp glow below the persistence
                    # threshold so every Ha frame flags.
                    builder.add(fn, res[1], shape_hw, tiles)
                    scanned_any = True
                    self.progress_signal.emit(i + 1, len(file_names))

                if self._cancel or not scanned_any:
                    return

                # Same engine helper Blink and Calibrate_Lights use, so all
                # three agree on what counts as fixed-pattern structure.
                _clean, _real, _n_art = builder.finalize(
                    status_cb=self.log_signal.emit)
                clean_files.update(_clean)
                real_tiles_by_file.update(_real)
                self.log_signal.emit(
                    f"Fixed-pattern filter: {_n_art} tile(s) ignored across "
                    f"{builder.n_groups} group(s); {len(_real)} file(s) have "
                    f"real trails, {len(_clean)} are clean."
                )

            def process_one(fp_in: str, fp_out: str, known_tiles=None):
                result = load_image(fp_in, return_metadata=True)
                if result is None or result[0] is None:
                    self.log_signal.emit(f"Failed to load: {os.path.basename(fp_in)}")
                    return
                img, hdr, bd, mono, meta = result

                img = np.asarray(img, dtype=np.float32)
                img = np.clip(img, 0.0, 1.0)

                out, detected = satellite_remove_image(
                    img,
                    models=models,
                    mode=self.mode,
                    clip_trail=self.clip_trail,
                    sensitivity=float(self.sensitivity),
                    compatibility_mode=self.compatibility_mode,
                    progress_cb=None,
                    detect_tiles=known_tiles,
                    status_cb=self.log_signal.emit,
                )

                if self.skip_save and (not detected):
                    self.log_signal.emit(f"Skip (no trail): {os.path.basename(fp_in)}")
                    return

                out = np.asarray(out, dtype=np.float32, order="C")
                out = np.clip(out, 0.0, 1.0)

                # Extract image_meta and file_meta for XISF round-trip
                image_meta = meta.get("xisf_meta") if meta else None
                if image_meta is not None and not isinstance(image_meta, list):
                    image_meta = [image_meta]

                fmt, _ = _save_fmt_and_bitdepth_from_path_for_legacy(fp_out)
                save_image(
                    out, fp_out, fmt or "fits",
                    bd or "32-bit floating point",
                    hdr, mono,
                    image_meta=image_meta,
                    file_meta=None,
                )
                self.log_signal.emit(f"Saved: {os.path.basename(fp_out)}")

                if self.delete_original:
                    try:
                        # never delete the file we just wrote
                        if os.path.abspath(fp_in) != os.path.abspath(fp_out):
                            os.remove(fp_in)
                            self.log_signal.emit(f"Deleted original: {os.path.basename(fp_in)}")
                    except Exception as e:
                        self.log_signal.emit(f"Could not delete original {os.path.basename(fp_in)}: {e}")

            # -------- batch (two-pass) OR monitor (loop, single-pass) --------
            _maps_built = False
            while not self._cancel:
                files = list(self._iter_files())

                # monitor: only process new files
                todo = [fn for fn in files if fn not in self._seen]

                # Pass 1 runs once, over the batch we are about to process.
                if not _maps_built:
                    _maps_built = True
                    _build_artifact_maps(todo)
                    if self._cancel:
                        break
                    if not self.monitor:
                        self.log_signal.emit("Pass 2 of 2: removing trails…")

                total = len(todo)
                done = 0
                self.progress_signal.emit(done, total)

                for fn in todo:
                    if self._cancel:
                        break

                    self._seen.add(fn)
                    fp_in = os.path.join(self.input_dir, fn)
                    stem, ext = os.path.splitext(fn)
                    fp_out = os.path.join(self.output_dir, f"{stem}_satellited{ext}")

                    # if output already exists, treat as done
                    if os.path.exists(fp_out):
                        self.log_signal.emit(f"Exists, skipping: {fn}")
                        done += 1
                        self.progress_signal.emit(done, total)
                        continue

                    # Pass 1 already established this file has no real trail.
                    # Running the pipeline would reproduce that answer at the
                    # cost of a load, a 512px reflect pad, a full tiling and a
                    # detection sweep — all to hand back the input unchanged.
                    if fn in clean_files:
                        if self.skip_save:
                            # No output wanted, and NOT deleting the original:
                            # that matches process_one, which returns before
                            # its delete block on the skip-save path. Deleting
                            # here would destroy a frame we never wrote out.
                            self.log_signal.emit(f"Skip (no trail): {fn}")
                        else:
                            # The pipeline's output for a no-trail frame is the
                            # input round-tripped through load+save, so copy the
                            # bytes instead — identical data, no decode/encode,
                            # and nothing for the round-trip to drop.
                            try:
                                import shutil as _sh
                                _sh.copy2(fp_in, fp_out)
                                self.log_signal.emit(f"No trail, copied: {fn}")
                                if self.delete_original and \
                                        os.path.abspath(fp_in) != os.path.abspath(fp_out):
                                    try:
                                        os.remove(fp_in)
                                        self.log_signal.emit(f"Deleted original: {fn}")
                                    except Exception as e:
                                        self.log_signal.emit(
                                            f"Could not delete original {fn}: {e}")
                            except Exception as e:
                                self.log_signal.emit(f"Copy failed for {fn}: {e}")
                        done += 1
                        self.progress_signal.emit(done, total)
                        continue

                    self.log_signal.emit(f"Processing: {fn}")
                    try:
                        process_one(fp_in, fp_out, real_tiles_by_file.get(fn))
                    except Exception as e:
                        self.log_signal.emit(f"Error {fn}: {e}")

                    done += 1
                    self.progress_signal.emit(done, total)

                if not self.monitor:
                    break

                # monitor mode: sleep/poll
                self.msleep(int(max(50, self.poll_seconds * 1000)))

            if self._cancel:
                self.log_signal.emit("Cancelled.")
            else:
                self.log_signal.emit("Done.")

        except Exception as e:
            self.log_signal.emit(f"Unexpected error: {e}")
        finally:
            self.finished_signal.emit()