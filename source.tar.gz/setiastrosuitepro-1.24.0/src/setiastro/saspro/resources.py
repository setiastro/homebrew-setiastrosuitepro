#saspro/resources.py
"""
Centralized resource paths for Seti Astro Suite Pro.

This module provides a single source of truth for all icon and resource paths,
handling both PyInstaller frozen builds and development environments.

Usage:
    from setiastro.saspro.resources import Icons, Resources
    
    icon = QIcon(Icons.WRENCH)
    data_path = Resources.SASP_DATA
"""
from __future__ import annotations
import os
import sys
from functools import lru_cache
from pathlib import Path

from setiastro.saspro.icon_packs import icon_override


def _get_base_path() -> str:
    """Get base path for resources (PyInstaller, installed package, or development)."""
    if hasattr(sys, '_MEIPASS'):
        return sys._MEIPASS

    # Most reliable: resources.py is always at src/setiastro/saspro/resources.py
    # Images are always at src/setiastro/images/
    # Use __file__ directly — works on all platforms in both dev and installed.
    current_file = os.path.abspath(__file__)
    # Go up: resources.py -> saspro/ -> setiastro/
    package_dir = os.path.dirname(os.path.dirname(current_file))
    if os.path.exists(os.path.join(package_dir, 'images')):
        return package_dir

    # Frozen/installed fallback: walk up from package_dir looking for images/
    search_dir = package_dir
    for _ in range(6):
        if os.path.exists(os.path.join(search_dir, 'images')):
            return search_dir
        parent = os.path.dirname(search_dir)
        if parent == search_dir:
            break
        search_dir = parent

    # Last resort: return package_dir and let _resource_path handle candidates
    return package_dir


def _resource_path(filename: str) -> str:
    base = _get_base_path()
    fn = filename

    is_img = fn.lower().endswith(('.png','.ico','.gif','.icns','.svg','.jpg','.jpeg','.bmp'))
    if is_img:
        override = icon_override(fn)
        if override:
            return override

        candidates = [
            os.path.join(base, 'images', fn),
            os.path.join(base, 'setiastro', 'images', fn),
            os.path.join(base, 'setiastro', 'saspro', 'images', fn),
        ]
        for p in candidates:
            if os.path.exists(p):
                return p

    # data / other files
    candidates = [
        os.path.join(base, fn),
        os.path.join(base, 'setiastro', fn),
        os.path.join(base, 'setiastro', 'saspro', fn),
    ]
    for p in candidates:
        if os.path.exists(p):
            return p

    return os.path.join(base, fn)

def _dev_model_path(preferred: str, fallback: str) -> str:
    """
    Silently prefer a dev/experimental model if it exists in the models dir,
    otherwise fall back to the standard production model.
    Dev models are never distributed — this is a local-only override.
    """
    preferred_path = model_path(preferred)
    try:
        if os.path.exists(preferred_path):
            return preferred_path
    except Exception:
        pass
    return model_path(fallback)

class Icons:
    """
    Centralized icon paths.
    
    All paths are computed lazily and cached.
    Access via class attributes: Icons.WRENCH, Icons.HISTOGRAM, etc.
    """
    
    # Application
    APP = property(lambda self: _resource_path('astrosuitepro.png'))
    APP_ICO = property(lambda self: _resource_path('astrosuitepro.ico'))
    BACKGROUND = property(lambda self: _resource_path('background.png')) 
    
    #sasprocessing tools
    GREEN = property(lambda self: _resource_path('green.png'))
    NEUTRAL = property(lambda self: _resource_path('neutral.png'))
    WHITE_BALANCE = property(lambda self: _resource_path('whitebalance.png'))
    TEXTURE_CLARITY = property(lambda self: _resource_path('TextureClarity.svg'))
    MORPHOLOGY = property(lambda self: _resource_path('morpho.png'))
    CLAHE = property(lambda self: _resource_path('clahe.png'))
    HDR = property(lambda self: _resource_path('hdr.png'))
    INVERT = property(lambda self: _resource_path('invert.png'))
    
    # Star operations
    STARNET = property(lambda self: _resource_path('starnet.png'))
    STAR_ADD = property(lambda self: _resource_path('staradd.png'))
    STAR_ALIGN = property(lambda self: _resource_path('staralign.png'))
    STAR_REGISTRATION = property(lambda self: _resource_path('starregistration.png'))
    STAR_SPIKE = property(lambda self: _resource_path('starspike.png'))
    ASTRO_SPIKE = property(lambda self: _resource_path('Astro_Spikes.png'))
    STAR_STRETCH = property(lambda self: _resource_path('starstretch.png'))
    COSMETIC_CORRECTION = property(lambda self: _resource_path('cosmeticcorrection.png'))
    
    # Luminance
    L_EXTRACT = property(lambda self: _resource_path('LExtract.png'))
    L_INSERT = property(lambda self: _resource_path('LInsert.png'))
    
    # Slots (0-9)
    SLOT_0 = property(lambda self: _resource_path('slot0.png'))
    SLOT_1 = property(lambda self: _resource_path('slot1.png'))
    SLOT_2 = property(lambda self: _resource_path('slot2.png'))
    SLOT_3 = property(lambda self: _resource_path('slot3.png'))
    SLOT_4 = property(lambda self: _resource_path('slot4.png'))
    SLOT_5 = property(lambda self: _resource_path('slot5.png'))
    SLOT_6 = property(lambda self: _resource_path('slot6.png'))
    SLOT_7 = property(lambda self: _resource_path('slot7.png'))
    SLOT_8 = property(lambda self: _resource_path('slot8.png'))
    SLOT_9 = property(lambda self: _resource_path('slot9.png'))
    
    # RGB operations
    RGB_COMBO = property(lambda self: _resource_path('rgbcombo.png'))
    RGB_EXTRACT = property(lambda self: _resource_path('rgbextract.png'))
    RGB_ALIGN = property(lambda self: _resource_path('rgbalign.png'))
    COPY_SLOT = property(lambda self: _resource_path('copyslot.png'))
    
    # External tools
    GRAXPERT = property(lambda self: _resource_path('graxpert.png'))
    COSMIC = property(lambda self: _resource_path('cosmic.png'))
    COSMIC_SAT = property(lambda self: _resource_path('cosmicsat.png'))
    COSMICCLARITY = property(lambda self: _resource_path('cosmicclarity.png'))
    COSMICCLARITYSAT = property(lambda self: _resource_path('cosmicclaritysat.png'))
    COSMICCLARITYDARK = property(lambda self: _resource_path('cosmicclaritydark.png'))
    
    # Image operations
    CROP = property(lambda self: _resource_path('cropicon.png'))
    OPEN_FILE = property(lambda self: _resource_path('openfile.png'))
    ABE = property(lambda self: _resource_path('abeicon.png'))
    SRGC = property(lambda self: _resource_path('srgc.png'))
    BLASTER = property(lambda self: _resource_path('blaster.png'))
    CLONESTAMP = property(lambda self: _resource_path('clonestamp.png'))
    
    # Undo/Redo
    UNDO = property(lambda self: _resource_path('undoicon.png'))
    REDO = property(lambda self: _resource_path('redoicon.png'))
    
    # Transformations
    FLIP_HORIZONTAL = property(lambda self: _resource_path('fliphorizontal.png'))
    FLIP_VERTICAL = property(lambda self: _resource_path('flipvertical.png'))
    ROTATE_CW = property(lambda self: _resource_path('rotateclockwise.png'))
    ROTATE_CCW = property(lambda self: _resource_path('rotatecounterclockwise.png'))
    ROTATE_180 = property(lambda self: _resource_path('rotate180.png'))
    ROTATE_ANY      = property(lambda self: _resource_path('rotatearbitrary.png'))
    RESCALE = property(lambda self: _resource_path('rescale.png'))
    RESIZECANVAS = property(lambda self: _resource_path('resizecanvas.png'))
    
    # Masks
    MASK_CREATE = property(lambda self: _resource_path('maskcreate.png'))
    MASK_APPLY = property(lambda self: _resource_path('maskapply.png'))
    MASK_REMOVE = property(lambda self: _resource_path('maskremove.png'))
    
    # Analysis
    PIXEL_MATH = property(lambda self: _resource_path('pixelmath.png'))
    HISTOGRAM = property(lambda self: _resource_path('histogram.png'))
    HISTOGRAM_TRANSFORM = property(lambda self: _resource_path('histogram_transform.png'))
    MOSAIC = property(lambda self: _resource_path('mosaic.png'))
    SURFACEMOSAIC = property(lambda self: _resource_path('surfacemosaic.png'))
    PLATE_SOLVE = property(lambda self: _resource_path('platesolve.png'))
    UNWARP = property(lambda self: _resource_path('unwarp.png'))
    PSF = property(lambda self: _resource_path('psf.png'))
    ISOPHOTE = property(lambda self: _resource_path('isophote.png'))
    
    # Stacking
    STACKING = property(lambda self: _resource_path('stacking.png'))
    LIVE_STACKING = property(lambda self: _resource_path('livestacking.png'))
    DITHER_ANALYSIS = property(lambda self: _resource_path('ditheranalysis.png'))
    IMAGE_COMBINE = property(lambda self: _resource_path('imagecombine.png'))
    PLANETARY_STACKER = property(lambda self: _resource_path('planetarystacker.png'))
    PLANET_PROJECTION = property(lambda self: _resource_path('3dplanet.png'))   
    
    # Moon phase (WIMS)
    MOON_NEW            = property(lambda self: _resource_path('new_moon.png'))
    MOON_WAXING_CRES_1  = property(lambda self: _resource_path('waxing_crescent_1.png'))
    MOON_WAXING_CRES_2  = property(lambda self: _resource_path('waxing_crescent_2.png'))
    MOON_WAXING_CRES_3  = property(lambda self: _resource_path('waxing_crescent_3.png'))
    MOON_WAXING_CRES_4  = property(lambda self: _resource_path('waxing_crescent_4.png'))
    MOON_WAXING_CRES_5  = property(lambda self: _resource_path('waxing_crescent_5.png'))

    MOON_FIRST_QUARTER  = property(lambda self: _resource_path('first_quarter.png'))

    MOON_WAXING_GIB_1   = property(lambda self: _resource_path('waxing_gibbous_1.png'))
    MOON_WAXING_GIB_2   = property(lambda self: _resource_path('waxing_gibbous_2.png'))
    MOON_WAXING_GIB_3   = property(lambda self: _resource_path('waxing_gibbous_3.png'))
    MOON_WAXING_GIB_4   = property(lambda self: _resource_path('waxing_gibbous_4.png'))
    MOON_WAXING_GIB_5   = property(lambda self: _resource_path('waxing_gibbous_5.png'))

    MOON_FULL           = property(lambda self: _resource_path('full_moon.png'))

    MOON_WANING_GIB_1   = property(lambda self: _resource_path('waning_gibbous_1.png'))
    MOON_WANING_GIB_2   = property(lambda self: _resource_path('waning_gibbous_2.png'))
    MOON_WANING_GIB_3   = property(lambda self: _resource_path('waning_gibbous_3.png'))
    MOON_WANING_GIB_4   = property(lambda self: _resource_path('waning_gibbous_4.png'))
    MOON_WANING_GIB_5   = property(lambda self: _resource_path('waning_gibbous_5.png'))

    MOON_LAST_QUARTER   = property(lambda self: _resource_path('last_quarter.png'))

    MOON_WANING_CRES_1  = property(lambda self: _resource_path('waning_crescent_1.png'))
    MOON_WANING_CRES_2  = property(lambda self: _resource_path('waning_crescent_2.png'))
    MOON_WANING_CRES_3  = property(lambda self: _resource_path('waning_crescent_3.png'))
    MOON_WANING_CRES_4  = property(lambda self: _resource_path('waning_crescent_4.png'))
    MOON_WANING_CRES_5  = property(lambda self: _resource_path('waning_crescent_5.png'))


    # Special features
    SUPERNOVA = property(lambda self: _resource_path('supernova.png'))
    PEDESTAL = property(lambda self: _resource_path('pedestal.png'))
    APERTURE = property(lambda self: _resource_path('aperture.png'))
    JWST_PUPIL = property(lambda self: _resource_path('jwstpupil.png'))
    SIGNATURE = property(lambda self: _resource_path('pen.png'))
    HR_DIAGRAM = property(lambda self: _resource_path('HRDiagram.png'))
    EXOPLANET = property(lambda self: _resource_path('exoicon.png'))
    ATLAS = property(lambda self: _resource_path('atlas.png'))
    FLYTHROUGH = property(lambda self: _resource_path('flythrough.png'))
    
    # Deconvolution & filters
    CONVO = property(lambda self: _resource_path('convo.png'))
    FREQ_SEP = property(lambda self: _resource_path('freqsep.png'))
    MULTISCALE_DECOMP = property(lambda self: _resource_path('multiscale_decomp.png'))
    CONT_SUB = property(lambda self: _resource_path('contsub.png'))
    NBI = property(lambda self: _resource_path('contadd.png'))
    HALO = property(lambda self: _resource_path('halo.png'))
    ABERRATION = property(lambda self: _resource_path('aberration.png'))
    SYQON = property(lambda self: _resource_path('syqon.png'))
    RCASTRO = property(lambda self: _resource_path('rcastro.png'))
    
    # Color
    SPCC = property(lambda self: _resource_path('spcc.png'))
    SSSC = property(lambda self: _resource_path('sssc.png'))
    NBEXTRACT = property(lambda self: _resource_path('nbextract.png'))
    MAGNITUDE = property(lambda self: _resource_path('magnitude.png'))
    SNR_TOOL = property(lambda self: _resource_path('snr.png'))
    DSE = property(lambda self: _resource_path('dse.png'))
    COLOR_WHEEL = property(lambda self: _resource_path('colorwheel.png'))
    SELECTIVE_COLOR = property(lambda self: _resource_path('selectivecolor.png'))
    SELECTIVE_LUM = property(lambda self: _resource_path('selectiveluma.png'))
    NB_TO_RGB = property(lambda self: _resource_path('nbtorgb.png'))
    NARROWBANDNORMALIZATION = property(lambda self: _resource_path('narrowbandnormalization.png'))
    GAIA = property(lambda self: _resource_path('gaia.png'))
    SATCHROMA = property(lambda self: _resource_path('satchroma.png'))
    FX = property(lambda self: _resource_path('fx.png'))
    
    # Stretching
    STAT_STRETCH = property(lambda self: _resource_path('statstretch.png'))
    CURVES = property(lambda self: _resource_path('curves.png'))
    UHS = property(lambda self: _resource_path('uhs.png'))
    
    # UI elements
    WRENCH = property(lambda self: _resource_path('wrench_icon.png'))
    EYE = property(lambda self: _resource_path('eye.png'))
    DISK = property(lambda self: _resource_path('disk.png'))
    NUKE = property(lambda self: _resource_path('nuke.png'))
    GRID = property(lambda self: _resource_path('gridicon.png'))
    FONT = property(lambda self: _resource_path('font.png'))
    CSV = property(lambda self: _resource_path('cvs.png'))
    PPP = property(lambda self: _resource_path('ppp.png'))
    SCRIPT = property(lambda self: _resource_path('script.png'))
    ACV = property(lambda self: _resource_path('acv_icon.png'))
    
    # Blink & comparison
    BLINK = property(lambda self: _resource_path('blink.png'))
    HUBBLE = property(lambda self: _resource_path('hubble.png'))
    COLLAGE = property(lambda self: _resource_path('collage.png'))
    ANNOTATED = property(lambda self: _resource_path('annotated.png'))
    SLAP = property(lambda self: _resource_path('slap.png'))
    
    # WIMS/WIMI
    WIMS = property(lambda self: _resource_path('wims.png'))
    WIMI = property(lambda self: _resource_path('wimi_icon_256x256.png'))
    
    # Other
    LINEAR_FIT = property(lambda self: _resource_path('linearfit.png'))
    DEBAYER = property(lambda self: _resource_path('debayer.png'))
    FUNCTION_BUNDLES = property(lambda self: _resource_path('functionbundle.png'))
    VIEW_BUNDLES = property(lambda self: _resource_path('viewbundle.png'))
    FINDER_CHART = property(lambda self: _resource_path('finderchart.png'))
    SYQON_PRISM = property(lambda self: _resource_path('prism.png'))
    SYQON_AXIOM = property(lambda self: _resource_path('axiom.png'))
    SYQON_PARALLAX = property(lambda self: _resource_path('parallax.png'))

    # Dock panel rail icons
    PANEL_CONSOLE   = property(lambda self: _resource_path('consolepanel.png'))
    PANEL_EXPLORER  = property(lambda self: _resource_path('explorerpanel.png'))
    PANEL_HEADER    = property(lambda self: _resource_path('headerpanel.png'))
    PANEL_LAYERS    = property(lambda self: _resource_path('layerspanel.png'))
    PANEL_MINIMIZED = property(lambda self: _resource_path('minimizedpanel.png'))
    PANEL_MONITOR   = property(lambda self: _resource_path('monitorpanel.png'))
    PANEL_STACKING  = property(lambda self: _resource_path('stackingpanel.png'))
    PANEL_SYSTEM    = property(lambda self: _resource_path('systempanel.png'))
    PANEL_SEARCH    = property(lambda self: _resource_path('searchpanel.png'))

# Singleton instances for easy access
_icons_instance = None
_resources_instance = None


def get_icons() -> Icons:
    """Get the Icons singleton instance."""
    global _icons_instance
    if _icons_instance is None:
        _icons_instance = Icons()
    return _icons_instance


def get_resources() -> Resources:
    """Get the Resources singleton instance."""
    global _resources_instance
    if _resources_instance is None:
        _resources_instance = Resources()
    return _resources_instance


# Convenience functions for direct path access
@lru_cache(maxsize=128)
def get_icon_path(name: str) -> str:
    """
    Get icon path by name.
    
    Args:
        name: Icon filename (with or without extension)
        
    Returns:
        Full path to icon file
        
    Example:
        path = get_icon_path('wrench_icon.png')
        path = get_icon_path('histogram')  # .png added automatically
    """
    if not name.endswith(('.png', '.ico', '.gif', '.svg')):
        name = f"{name}.png"
    return _resource_path(name)


@lru_cache(maxsize=32)
def get_data_path(name: str) -> str:
    """
    Get data file path by name.
    
    Args:
        name: Data filename
        
    Returns:
        Full path to data file
    """
    return _resource_path(name)

# ---------------- Legacy compatibility (LAZY) ----------------
# These names match the original module-level variables used in older code.

_LEGACY_ICON_MAP = {
    'icon_path': 'astrosuitepro.png',
    'windowslogo_path': 'astrosuitepro.ico',
    'green_path': 'green.png',
    'neutral_path': 'neutral.png',
    'whitebalance_path': 'whitebalance.png',
    'texture_clarity_path': 'TextureClarity.svg',
    'morpho_path': 'morpho.png',
    'clahe_path': 'clahe.png',
    'starnet_path': 'starnet.png',
    'staradd_path': 'staradd.png',
    'LExtract_path': 'LExtract.png',
    'LInsert_path': 'LInsert.png',
    'slot0_path': 'slot0.png',
    'slot1_path': 'slot1.png',
    'slot2_path': 'slot2.png',
    'slot3_path': 'slot3.png',
    'slot4_path': 'slot4.png',
    'slot5_path': 'slot5.png',
    'slot6_path': 'slot6.png',
    'slot7_path': 'slot7.png',
    'slot8_path': 'slot8.png',
    'slot9_path': 'slot9.png',
    'acv_icon_path': 'acv_icon.png',

    'moon_new_path': 'new_moon.png',
    'moon_waxing_crescent_1_path': 'waxing_crescent_1.png',
    'moon_waxing_crescent_2_path': 'waxing_crescent_2.png',
    'moon_waxing_crescent_3_path': 'waxing_crescent_3.png',
    'moon_waxing_crescent_4_path': 'waxing_crescent_4.png',
    'moon_waxing_crescent_5_path': 'waxing_crescent_5.png',
    'moon_first_quarter_path': 'first_quarter.png',
    'moon_waxing_gibbous_1_path': 'waxing_gibbous_1.png',
    'moon_waxing_gibbous_2_path': 'waxing_gibbous_2.png',
    'moon_waxing_gibbous_3_path': 'waxing_gibbous_3.png',
    'moon_waxing_gibbous_4_path': 'waxing_gibbous_4.png',
    'moon_waxing_gibbous_5_path': 'waxing_gibbous_5.png',
    'moon_full_path': 'full_moon.png',
    'moon_waning_gibbous_1_path': 'waning_gibbous_1.png',
    'moon_waning_gibbous_2_path': 'waning_gibbous_2.png',
    'moon_waning_gibbous_3_path': 'waning_gibbous_3.png',
    'moon_waning_gibbous_4_path': 'waning_gibbous_4.png',
    'moon_waning_gibbous_5_path': 'waning_gibbous_5.png',
    'moon_last_quarter_path': 'last_quarter.png',
    'moon_waning_crescent_1_path': 'waning_crescent_1.png',
    'moon_waning_crescent_2_path': 'waning_crescent_2.png',
    'moon_waning_crescent_3_path': 'waning_crescent_3.png',
    'moon_waning_crescent_4_path': 'waning_crescent_4.png',
    'moon_waning_crescent_5_path': 'waning_crescent_5.png',

    'rgbcombo_path': 'rgbcombo.png',
    'rgbextract_path': 'rgbextract.png',
    'copyslot_path': 'copyslot.png',
    'graxperticon_path': 'graxpert.png',
    'cropicon_path': 'cropicon.png',
    'openfile_path': 'openfile.png',
    'abeicon_path': 'abeicon.png',
    'srgc_path': 'srgc.png',
    'undoicon_path': 'undoicon.png',
    'redoicon_path': 'redoicon.png',
    'blastericon_path': 'blaster.png',
    'clonestampicon_path': 'clonestamp.png',
    'hdr_path': 'hdr.png',
    'invert_path': 'invert.png',
    'fliphorizontal_path': 'fliphorizontal.png',
    'flipvertical_path': 'flipvertical.png',
    'rotateclockwise_path': 'rotateclockwise.png',
    'rotatecounterclockwise_path': 'rotatecounterclockwise.png',
    'rotate180_path': 'rotate180.png',
    'resizecanvas_path': 'resizecanvas.png',
    'rotatearbitrary_path': 'rotatearbitrary.png',
    'maskcreate_path': 'maskcreate.png',
    'maskapply_path': 'maskapply.png',
    'maskremove_path': 'maskremove.png',
    'pixelmath_path': 'pixelmath.png',
    'histogram_path': 'histogram.png',
    'histogram_transform_path': 'histogram_transform.png',
    'mosaic_path': 'mosaic.png',
    'rescale_path': 'rescale.png',
    'staralign_path': 'staralign.png',
    'dithericon_path': 'ditheranalysis.png',
    'mask_path': 'maskapply.png',
    'platesolve_path': 'platesolve.png',
    'psf_path': 'psf.png',
    'supernova_path': 'supernova.png',
    'starregistration_path': 'starregistration.png',
    'stacking_path': 'stacking.png',
    'pedestal_icon_path': 'pedestal.png',
    'surfacemosaic_path': 'surfacemosaic.png',
    'cosmeticcorrection_path': 'cosmeticcorrection.png',
    'starspike_path': 'starspike.png',
    'astrospike_path': 'Astro_Spikes.png',
    'aperture_path': 'aperture.png',
    'jwstpupil_path': 'jwstpupil.png',
    'signature_icon_path': 'pen.png',
    'livestacking_path': 'livestacking.png',
    'hrdiagram_path': 'HRDiagram.png',
    'convoicon_path': 'convo.png',
    'spcc_icon_path': 'spcc.png',
    'nbextract_icon': 'nbextract.png',
    'atlas_path': 'atlas.png',
    'gaia_path': 'gaia.png',
    'flythrough_path': 'flythrough.png',
    'sssc_path': 'sssc.png',
    'rcastro_path': 'rcastro.png',
    'parallex_path': 'parallax.png',
    'satchroma_path': 'satchroma.png',
    'fx_path': 'fx.png',
    'unwarp_path': 'unwarp.png',
    'exoicon_path': 'exoicon.png',
    'peeker_icon': 'gridicon.png',
    'dse_icon_path': 'dse.png',
    'isophote_path': 'isophote.png',
    'statstretch_path': 'statstretch.png',
    'starstretch_path': 'starstretch.png',
    'curves_path': 'curves.png',
    'disk_path': 'disk.png',
    'uhs_path': 'uhs.png',
    'blink_path': 'blink.png',
    'ppp_path': 'ppp.png',
    'nbtorgb_path': 'nbtorgb.png',
    'freqsep_path': 'freqsep.png',
    'multiscale_decomp_path': 'multiscale_decomp.png',
    'slap_path': 'slap.png',
    'contsub_path': 'contsub.png',
    'nbi_path': 'contadd.png',
    'halo_path': 'halo.png',
    'cosmic_path': 'cosmic.png',
    'satellite_path': 'cosmicsat.png',
    'imagecombine_path': 'imagecombine.png',
    'wrench_path': 'wrench_icon.png',
    'eye_icon_path': 'eye.png',
    'disk_icon_path': 'disk.png',
    'nuke_path': 'nuke.png',
    'hubble_path': 'hubble.png',
    'collage_path': 'collage.png',
    'annotated_path': 'annotated.png',
    'colorwheel_path': 'colorwheel.png',
    'narrowbandnormalization_path': 'narrowbandnormalization.png',
    'font_path': 'font.png',
    'csv_icon_path': 'cvs.png',
    'wims_path': 'wims.png',
    'wimi_path': 'wimi_icon_256x256.png',
    'linearfit_path': 'linearfit.png',
    'debayer_path': 'debayer.png',
    'aberration_path': 'aberration.png',
    'functionbundles_path': 'functionbundle.png',
    'planetarystacker_path': 'planetarystacker.png',
    'viewbundles_path': 'viewbundle.png',
    'selectivecolor_path': 'selectivecolor.png',
    'selectivelum_path': 'selectiveluma.png',
    'rgbalign_path': 'rgbalign.png',
    'background_path': 'background.png',
    'script_icon_path': 'script.png',
    'planetprojection_path': '3dplanet.png',
    'finderchart_path': 'finderchart.png',
    'magnitude_path': 'magnitude.png',
    'snr_path': 'snr.png',
    'syqon_path': 'syqon.png',
}

_LEGACY_DATA_MAP = {
    'sasp_data_path': 'data/SASP_data.fits',
    'astrobin_filters_csv_path': 'data/catalogs/astrobin_filters.csv',
    'spinner_path': 'spinner.gif',
}

def __getattr__(name: str):
    if name in _LEGACY_ICON_MAP:
        return get_icon_path(_LEGACY_ICON_MAP[name])
    if name in _LEGACY_DATA_MAP:
        return get_data_path(_LEGACY_DATA_MAP[name])

    if name == 'background_startup_path':
        return _resource_path('Background_startup.jpg')

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

def __dir__():
    return (
        list(globals().keys())
        + list(_LEGACY_ICON_MAP.keys())
        + list(_LEGACY_DATA_MAP.keys())
        + ['background_startup_path', 'resource_monitor_qml']
    )


class Resources:
    """
    Centralized data resource paths.
    """
    SASP_DATA = property(lambda self: _resource_path('data/SASP_data.fits'))
    ASTROBIN_FILTERS_CSV = property(lambda self: _resource_path('data/catalogs/astrobin_filters.csv'))
    SPINNER_GIF = property(lambda self: _resource_path('spinner.gif'))

    # --- Models root ---
    MODELS_DIR = property(lambda self: get_models_dir())

    # --- Cosmic Clarity Sharpen ---
    CC_STELLAR_SHARP_PTH  = property(lambda self: model_path('deep_sharp_stellar_cnn_AI3_5s.pth'))
    CC_STELLAR_SHARP_ONNX = property(lambda self: model_path('deep_sharp_stellar_cnn_AI3_5s.onnx'))

    CC_NS1_PTH  = property(lambda self: model_path('deep_nonstellar_sharp_cnn_radius_1AI3_5s.pth'))
    CC_NS1_ONNX = property(lambda self: model_path('deep_nonstellar_sharp_cnn_radius_1AI3_5s.onnx'))

    CC_NS2_PTH  = property(lambda self: model_path('deep_nonstellar_sharp_cnn_radius_2AI3_5s.pth'))
    CC_NS2_ONNX = property(lambda self: model_path('deep_nonstellar_sharp_cnn_radius_2AI3_5s.onnx'))
    CC_NS4_PTH  = property(lambda self: model_path('deep_nonstellar_sharp_cnn_radius_4AI3_5s.pth'))
    CC_NS4_ONNX = property(lambda self: model_path('deep_nonstellar_sharp_cnn_radius_4AI3_5s.onnx'))

    CC_NS8_PTH  = property(lambda self: model_path('deep_nonstellar_sharp_cnn_radius_8AI3_5s.pth'))
    CC_NS8_ONNX = property(lambda self: model_path('deep_nonstellar_sharp_cnn_radius_8AI3_5s.onnx'))

    CC_S_PTH = property(lambda self: model_path('deep_sharp_stellar_AI4.pth'))
    CC_STELLAR_NAF_ONNX = property(lambda self: model_path('deep_sharp_stellar_AI4.onnx'))
    CC_NS_PTH = property(lambda self: model_path('deep_nonstellar_sharp_conditional_psf_AI4.pth'))
    CC_NS_COND_NAF_ONNX = property(lambda self: model_path('deep_nonstellar_sharp_conditional_psf_AI4.onnx'))
    CC_C_PTH = property(lambda self: optional_model_path('deep_correct_stellar_AI4.pth'))
    CC_C2_PTH = property(lambda self: optional_model_path('deep_correct_stellar_V2_AI4.pth'))

    # --- Cosmic Clarity Denoise (NAFNet AI4) ---
    CC_DENOISE_MONO_PTH  = property(lambda self: model_path('deep_denoise_mono_AI4.pth'))
    CC_DENOISE_MONO_ONNX = property(lambda self: model_path('deep_denoise_mono_AI4.onnx'))

    CC_DENOISE_COLOR_PTH  = property(lambda self: model_path('deep_denoise_color_AI4.pth'))
    CC_DENOISE_COLOR_ONNX = property(lambda self: model_path('deep_denoise_color_AI4.onnx'))

    CC_DENOISE_MONO_PTH_LITE  = property(lambda self: model_path('deep_denoise_mono_AI4_lite.pth'))
    CC_DENOISE_MONO_ONNX_LITE = property(lambda self: model_path('deep_denoise_mono_AI4_lite.onnx'))

    CC_DENOISE_COLOR_PTH_LITE  = property(lambda self: model_path('deep_denoise_color_AI4_lite.pth'))
    CC_DENOISE_COLOR_ONNX_LITE = property(lambda self: model_path('deep_denoise_color_AI4_lite.onnx'))

    # --- Cosmic Clarity Denoise — Walking Noise specialist (AI4.1w, full arch only) ---
    CC_DENOISE_MONO_WALKING_PTH   = property(lambda self: model_path('deep_denoise_mono_AI4_1w.pth'))
    CC_DENOISE_MONO_WALKING_ONNX  = property(lambda self: model_path('deep_denoise_mono_AI4_1w.onnx'))
    CC_DENOISE_COLOR_WALKING_PTH  = property(lambda self: model_path('deep_denoise_color_AI4_1w.pth'))
    CC_DENOISE_COLOR_WALKING_ONNX = property(lambda self: model_path('deep_denoise_color_AI4_1w.onnx'))

    CC_DENOISE_PTH  = property(lambda self: model_path('deep_denoise_cnn_AI3_6.pth'))
    CC_DENOISE_ONNX = property(lambda self: model_path('deep_denoise_cnn_AI3_6.onnx'))

    # --- Super Resolution ---
    CC_SUPERRES_2X_PTH  = property(lambda self: model_path('superres_2x.pth'))
    CC_SUPERRES_2X_ONNX = property(lambda self: model_path('superres_2x.onnx'))
    CC_SUPERRES_3X_PTH  = property(lambda self: model_path('superres_3x.pth'))
    CC_SUPERRES_3X_ONNX = property(lambda self: model_path('superres_3x.onnx'))

    CC_SUPERRES_4X_PTH  = property(lambda self: model_path('superres_4x.pth'))
    CC_SUPERRES_4X_ONNX = property(lambda self: model_path('superres_4x.onnx'))

    # --- Dark Star (Star Removal) ---
    CC_DARKSTAR_MONO_PTH   = property(lambda self: model_path('darkstar_mono_AI4.pt'))
    CC_DARKSTAR_MONO_ONNX  = property(lambda self: model_path('darkstar_mono_AI4.onnx'))
    CC_DARKSTAR_COLOR_PTH  = property(lambda self: model_path('darkstar_color_AI4.pt'))
    CC_DARKSTAR_COLOR_ONNX = property(lambda self: model_path('darkstar_color_AI4.onnx'))

    # --- Cosmic Clarity Satellite Removal ---
    CC_SAT_DETECT1_PTH  = property(lambda self: model_path('satellite_trail_detector_AI3.5.pth'))
    CC_SAT_DETECT1_ONNX = property(lambda self: model_path('satellite_trail_detector_AI3.5.onnx'))
    CC_SAT_DETECT2_PTH  = property(lambda self: model_path('satellite_trail_detector_mobilenetv2.5.pth'))
    CC_SAT_DETECT2_ONNX = property(lambda self: model_path('satellite_trail_detector_mobilenetv2.5.onnx'))

    CC_SAT_REMOVE_PTH   = property(lambda self: model_path('satelliteRemovalAI4.pth'))
    CC_SAT_REMOVE_ONNX  = property(lambda self: model_path('satelliteRemovalAI4.onnx'))

@lru_cache(maxsize=8)
def get_models_dir() -> str:
    """
    Models are NOT packaged resources. They must be installed via the model manager.
    This returns the user models root and never falls back to _internal/data/models.
    """
    from setiastro.saspro.model_manager import models_root
    p = Path(models_root())
    # Ensure dir exists (models_root should already do this, but harmless)
    p.mkdir(parents=True, exist_ok=True)
    return str(p)


def _assert_not_internal_models_path(p: str):
    s = str(p).lower().replace("/", "\\")
    if "\\_internal\\" in s and "\\data\\models\\" in s:
        raise RuntimeError(f"Legacy internal model path detected: {p}")

def model_path(filename: str) -> str:
    from setiastro.saspro.model_manager import require_model
    p = str(require_model(filename))
    _assert_not_internal_models_path(p)
    return p

def optional_model_path(filename: str) -> str | None:
    from setiastro.saspro.model_manager import optional_model_path as _opt
    p = _opt(filename)
    if p is None:
        return None
    _assert_not_internal_models_path(str(p))
    return str(p)

# Export list for `from setiastro.saspro.resources import *`
__all__ = [
    'Icons', 'Resources',
    'get_icons', 'get_resources',
    'get_icon_path', 'get_data_path',
    'background_startup_path',
] + list(_LEGACY_ICON_MAP.keys()) + list(_LEGACY_DATA_MAP.keys())