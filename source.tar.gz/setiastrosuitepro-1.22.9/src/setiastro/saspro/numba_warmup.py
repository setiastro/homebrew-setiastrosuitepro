#saspro/numba_warmup.py
"""
Background Numba JIT warmup module.

Triggers compilation of frequently-used Numba functions in a background thread
after the main UI has loaded. This ensures the first actual use of these
functions is fast, while not blocking the application startup.
"""
from __future__ import annotations
import threading
import numpy as np
import logging

_warmup_thread: threading.Thread | None = None
_warmup_done = threading.Event()

def _do_warmup():
    """
    Compile critical numba functions with small dummy arrays.
    This runs in a background thread after the UI is visible.
    
    Expanded to cover 25+ frequently-used functions for:
    - Image blending operations (7 functions)
    - Geometric transforms (6 functions)
    - Image processing (5 functions)
    - Statistical operations (5 functions)
    - Calibration (2+ functions)
    """
    try:
        #print("[numba] warmup thread started")
        # Guard against the CPython 3.14 TBB access violation on Windows — must
        # be set BEFORE the first numba import. setdefault respects any explicit
        # override the user (or the bootstrap) already set.
        #
        # WINDOWS ONLY: a hard NUMBA_THREADING_LAYER pin beats the priority
        # steering numba_bootstrap sets, so applying it on every platform forced
        # the NON-threadsafe 'workqueue' layer even where omp/tbb were available.
        # That is exactly what put a Linux (StellarMate) user on workqueue and
        # into the blink concurrent-access abort. numba_bootstrap already makes
        # tbb unreachable via priority, so this pin is redundant for crash-safety
        # and could be dropped entirely once omp-on-Windows is confirmed healthy;
        # for now keep it as a belt-and-suspenders guard on Windows alone.
        import os as _os, sys as _sys
        if _sys.platform.startswith("win"):
            _os.environ.setdefault("NUMBA_THREADING_LAYER", "workqueue")

        # Import numba functions - expanded set
        from setiastro.saspro.legacy.numba_utils import (
            # Blending operations (7)
            blend_add_numba,
            blend_subtract_numba,
            blend_multiply_numba,
            blend_divide_numba,
            blend_screen_numba,
            blend_overlay_numba,
            blend_difference_numba,
            # Geometric transforms
            rescale_image_numba,
            flip_horizontal_numba,
            flip_vertical_numba,
            rotate_180_numba,
            bin2x2_numba,
            # Image processing
            invert_image_numba,
            apply_flat_division_numba,
            subtract_dark,
            # Statistical operations
            kappa_sigma_clip_weighted,
            windsorized_sigma_clip_weighted,
        )
        
        # Create small dummy arrays for warmup
        dummy_rgb = np.random.rand(32, 32, 3).astype(np.float32)
        dummy_mono = np.random.rand(32, 32).astype(np.float32)
        dummy_3d_mono = np.random.rand(8, 32, 32).astype(np.float32)  # Stack of 8 frames
        dummy_3d_rgb = np.random.rand(8, 32, 32, 3).astype(np.float32)  # Stack of 8 RGB frames
        dummy_4d = np.random.rand(4, 2, 32, 32).astype(np.float32)  # 4 frames, 2 channels
        
        # Warm up blending operations
        warmup_funcs = [
            (blend_add_numba, [dummy_rgb, dummy_rgb, 0.5]),
            (blend_subtract_numba, [dummy_rgb, dummy_rgb, 0.5]),
            (blend_multiply_numba, [dummy_rgb, dummy_rgb, 0.5]),
            (blend_divide_numba, [dummy_rgb, dummy_rgb, 0.5]),
            (blend_screen_numba, [dummy_rgb, dummy_rgb, 0.5]),
            (blend_overlay_numba, [dummy_rgb, dummy_rgb, 0.5]),
            (blend_difference_numba, [dummy_rgb, dummy_rgb, 0.5]),
            # Geometric transforms
            (rescale_image_numba, [dummy_rgb, 0.5]),
            (flip_horizontal_numba, [dummy_rgb]),
            (flip_vertical_numba, [dummy_rgb]),
            (rotate_180_numba, [dummy_mono]),
            (bin2x2_numba, [dummy_mono]),
            # Image processing
            (invert_image_numba, [dummy_rgb]),
            (apply_flat_division_numba, [dummy_rgb, dummy_rgb]),
            (subtract_dark, [dummy_3d_mono, dummy_mono]),
            # Statistical operations (with multiple frames)
            (kappa_sigma_clip_weighted, [dummy_3d_mono, np.ones(8)]),
            (windsorized_sigma_clip_weighted, [dummy_3d_mono, np.ones(8)]),
        ]
        
        for func, args in warmup_funcs:
            try:
                _ = func(*args)
            except Exception:
                # Silently skip functions that may not be available or fail
                pass
        
        logging.debug("Numba warmup completed successfully")

        # Log the resolved numba threading layer. Requires that at least one
        # parallel=True kernel above actually executed (the reduction/blend
        # kernels do). workqueue is NOT threadsafe; the blink loader stays safe
        # via NUMBA_PARALLEL_LOCK regardless, but a workqueue fallback here is
        # the signal that a user is on the config that can hit concurrent-numba
        # races — so surface it in the log for future diagnosis.
        try:
            import numba
            _layer = numba.threading_layer()
            #print(f"[numba] threading layer resolved: {_layer}")
            logging.info("Numba threading layer resolved: %s", _layer)
            # Pin the resolved layer into numba_utils NOW, at the one place we
            # already know it, so the lazy NUMBA_PARALLEL_LOCK decides correctly
            # for the very first concurrent parallel region (e.g. the blink
            # loader) instead of falling back to an OS guess before warmup ran.
            try:
                from setiastro.saspro.legacy import numba_utils as _nu
                _nu.record_numba_threading_layer(str(_layer))
            except Exception:
                pass
            if _layer not in ("tbb", "omp"):
                logging.warning("Numba resolved to '%s' (NOT threadsafe).", _layer)
        except Exception as _e:
            #print(f"[numba] layer probe skipped: {_e!r}")
            logging.info("Numba threading-layer probe skipped: %r", _e)
        
        # serialized-warmup: astroalign folded into _do_warmup
        # Run the astroalign JIT warmup in THIS thread, sequentially.
        # Triggering the first parallel=True compile from two threads at
        # once can access-violate in numba's compiler_lock on some
        # Windows/TBB configs, so we do it single-threaded here.
        try:
            from setiastro.saspro.astroalign import warmup_jit as _aa_warmup_jit
            _aa_warmup_jit()
        except Exception:
            pass
        
    except Exception as e:
        import traceback
        #print(f"[numba] warmup failed: {e!r}")
        traceback.print_exc()
        logging.warning("Numba warmup failed (non-critical): %r", e)
    finally:
        _warmup_done.set()


def start_background_warmup():
    """
    Start the Numba warmup in a background thread.
    Call this after the main window is visible.
    """
    global _warmup_thread
    
    if _warmup_thread is not None and _warmup_thread.is_alive():
        return  # Already running
    
    _warmup_thread = threading.Thread(target=_do_warmup, daemon=True, name="NumbaWarmup")
    _warmup_thread.start()


def wait_for_warmup(timeout: float = 5.0) -> bool:
    """
    Wait for the warmup to complete.
    
    Args:
        timeout: Maximum time to wait in seconds.
        
    Returns:
        True if warmup completed, False if timeout.
    """
    return _warmup_done.wait(timeout=timeout)


def is_warmup_done() -> bool:
    """Check if warmup has completed."""
    return _warmup_done.is_set()