# ============================================================
#  ____       _   _      _       _
# / ___|  ___| |_(_)    / \  ___| |_ _ __ ___
# \___ \ / _ \ __| |   / _ \/ __| __| '__/ _ \
#  ___) |  __/ |_| |  / ___ \__ \ |_| | | (_) |
# |____/ \___|\__|_|_/_/   \_\__/\__|_|  \___/
#
#  SASpro – Stacking Execution Monitor
#  Franklin Marek  |  www.setiastro.com
# ============================================================
from __future__ import annotations

import os
import re
import shutil
import time
from typing import Optional

from PyQt6.QtCore import Qt, QSettings, pyqtSlot, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QDialog, QHBoxLayout, QLabel, QPushButton,
    QSizePolicy, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QHeaderView, QWidget,
)

# ── palette (matches SASpro dark theme) ──────────────────────────────────
_BG      = "#1a1a2e"
_PANEL   = "#16213e"
_ACCENT  = "#e94560"
_ACCENT2 = "#0f3460"
_FG      = "#eaeaea"
_DIM     = "#888888"
_GREEN   = "#4caf50"
_YELLOW  = "#ffc107"
_RED     = "#e94560"
_ORANGE  = "#ff9800"


# ── Column indices ────────────────────────────────────────────────────────
_COL_OP      = 0
_COL_GROUP   = 1
_COL_ELAPSED = 2
_COL_STATUS  = 3
_COL_NOTE    = 4
_NCOLS       = 5

# ── Status constants ──────────────────────────────────────────────────────
_ST_RUNNING = "running"
_ST_OK      = "success"
_ST_WARN    = "warning"
_ST_FAIL    = "failed"
_ST_INFO    = "info"


# ── Disk helpers (self-contained; no cross-module import) ─────────────────
def _human_bytes(n) -> str:
    """Human-readable base-1024 byte count, e.g. 1536 -> '1.50 KB'."""
    try:
        n = float(n)
    except Exception:
        return "?"
    sign = "-" if n < 0 else ""
    n = abs(n)
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if n < 1024.0 or unit == "PB":
            if unit == "B":
                return f"{sign}{int(n)} {unit}"
            return f"{sign}{n:.2f} {unit}"
        n /= 1024.0
    return f"{sign}{n:.2f} PB"


def _disk_free_bytes(path):
    """Free bytes on the volume holding `path` (walks up to an existing dir)."""
    try:
        p = os.path.abspath(path or ".")
        while p and not os.path.isdir(p):
            parent = os.path.dirname(p)
            if parent == p:
                break
            p = parent
        if not p or not os.path.isdir(p):
            return None
        return int(shutil.disk_usage(p).free)
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════════════════
#  Message classifier
# ═══════════════════════════════════════════════════════════════════════════

# Each entry: (regex_pattern, operation_label, status_hint, group_capture_group_or_None)
# Patterns are tried in order; first match wins.
_RULES: list[tuple[re.Pattern, str, str, Optional[int]]] = []

def _r(pat: str, op: str, st: str, grp: Optional[int] = None):
    _RULES.append((re.compile(pat, re.IGNORECASE), op, st, grp))

# ── Master dark ───────────────────────────────────────────────────────────
_r(r"Starting Master Dark",                         "Master Darks",      _ST_RUNNING)
_r(r"🟢 Processing \d+ darks for (.+?) in session", "Master Darks",      _ST_RUNNING, 1)
_r(r"✅ Master Dark saved and added to UI",          "Master Darks",      _ST_OK)
_r(r"⚠️.*dark.*skip",                               "Master Darks",      _ST_WARN)

# ── Master flat ───────────────────────────────────────────────────────────
_r(r"Starting Master Flat",                         "Master Flats",      _ST_RUNNING)
_r(r"🟢 Processing \d+ flats for .+?\[(.+?)\]",     "Master Flats",      _ST_RUNNING, 1)
# create_master_flat now writes master FITS files on a background thread
# pool and emits "✅ Master Flat queued: …" the moment the main-thread work
# for a group is done (the actual on-disk save completes shortly after and
# is drained in the function's finally). The old "Master Flat saved" rule
# never matched the new wording, so the LAST group's Master Flats row kept
# ticking forever until the whole dialog closed — polluting the "total
# time" readout. Accept the queued message as the per-group terminator;
# the final "✅ All master flats saved" message after the drain serves as
# a belt-and-braces closer when every group finishes together.
_r(r"✅ Master Flat queued",                         "Master Flats",      _ST_OK)
_r(r"✅ Master Flat saved",                          "Master Flats",      _ST_OK)
_r(r"✅ All master flats saved",                     "Master Flats",      _ST_OK)
_r(r"⚠️.*flat.*skip",                               "Master Flats",      _ST_WARN)

# ── Calibration — specific rules BEFORE generic catch-alls ───────────────
_r(r"📦 Loading master calibration frames",         "Calibration",       _ST_RUNNING)
_r(r"🎚️ Interactive flat",                          "Calibration",       _ST_RUNNING)
_r(r"🔧 Calibration frames ready",                  "Calibration",       _ST_INFO)
_r(r"📷 Calibrating group: (.+)",                   "Calibration",       _ST_RUNNING, 1)
_r(r"📷 Progress: .+ — \d+/\d+ frames",             "Calibration",       _ST_RUNNING)
_r(r"📷 Calibration pipeline complete",             "Calibration",       _ST_OK)
_r(r"📷 All light groups calibrated",               "Calibration",       _ST_OK)
_r(r"✅ Calibration Complete",                      "Calibration",       _ST_OK)
_r(r"❌ (?:ERROR|CALIBRATION ERROR)",               "Calibration",       _ST_FAIL)

# ── Satellite trail removal (post-calibration phase 2) ───────────────────
_r(r"✅ Satellite trail removal complete",          "Satellite Trails",  _ST_OK)
_r(r"⏹ Satellite pass cancelled",                   "Satellite Trails",  _ST_WARN)
_r(r"🛰️ Satellite trail removal — (\d+ frame\(s\))", "Satellite Trails", _ST_RUNNING, 1)
_r(r"🛰️ \d+/\d+:",                                  "Satellite Trails",  _ST_RUNNING)

# ── Measurements ─────────────────────────────────────────────────────────
# Register path opens on "📏 Phase: Measurements starting"; the integrate-
# already-registered path uses a different opener ("📊 Found N aligned/
# normalized frames. Measuring in parallel previews…") and finishes on
# "✅ All chunks complete! Measured N frames total." — without these two
# the integrate path has NO Measurements row and the elapsed time silently
# rolls into the next phase.
_r(r"📏 Phase: Measurements starting",              "Measurements",      _ST_RUNNING)
_r(r"📊 Found \d+ aligned/normalized frames",       "Measurements",      _ST_RUNNING)
_r(r"📦 Measured \d+/\d+ frames",                   "Measurements",      _ST_RUNNING)
_r(r"📏 Phase: Measurements complete",              "Measurements",      _ST_OK)
_r(r"✅ All chunks complete! Measured \d+ frames",   "Measurements",      _ST_OK)

# ── Frame weights ────────────────────────────────────────────────────────
# The integrate-already-registered path scores and weights frames after its
# preview measurements complete. Without an explicit rule the terminal
# "✅ Frame weights computed!" was being caught by the generic ^✅ catch-all
# and spawned an orphan "Complete" row with 0s elapsed (no matching start).
# Match the start message too so the elapsed cell actually ticks, and capture
# the weighting mode as the group label.
_r(r"⚖️ Computing frame weights.*?\(mode:\s*([^)]+)\)", "Frame Weights", _ST_RUNNING, 1)
_r(r"⚖️ Computing frame weights",                   "Frame Weights",     _ST_RUNNING)
_r(r"✅ Frame weights computed",                     "Frame Weights",     _ST_OK)
_r(r"⚖️ Frame weights computed",                     "Frame Weights",     _ST_OK)

# ── Normalization ─────────────────────────────────────────────────────────
_r(r"📏 Phase: Normalization starting",             "Normalization",     _ST_RUNNING)
_r(r"🌀 Normalizing chunk \d+/\d+",                 "Normalization",     _ST_RUNNING)
_r(r"📏 Phase: Normalization complete",             "Normalization",     _ST_OK)

# ── Reference frame ───────────────────────────────────────────────────────
_r(r"Auto-selected reference|Using user-specified reference", "Ref Frame Selection", _ST_OK)
_r(r"📌 Reference for alignment",                  "Ref Frame Selection", _ST_INFO)

# ── Star alignment ────────────────────────────────────────────────────────
_r(r"📏 Phase: Star alignment starting",            "Registration",      _ST_RUNNING)
_r(r"(?:📐\s*)?Aligning stars… \(\d+/\d+\)",         "Registration",      _ST_RUNNING)
_r(r"📏 Phase: Star alignment complete",            "Registration",      _ST_OK)
_r(r"Alignment summary: (\d+ succeeded)",           "Registration",      _ST_OK,   1)
_r(r"🚨 Rejected \d+ frame",                        "Registration",      _ST_WARN)

# ── Integration ───────────────────────────────────────────────────────────
_r(r"📏 Phase: Integration starting",               "Integration",       _ST_RUNNING)
_r(r"Starting integration for group '(.+?)' with",  "Integration",       _ST_RUNNING, 1)
_r(r"📊 Stacking group '(.+?)' with (.+)",           "Integration",       _ST_RUNNING, 1)
_r(r"🔧 \[LowRAM\] Tile \d+/\d+",                   "Integration",       _ST_RUNNING)
_r(r"🔧 Tile \d+/\d+",                              "Integration",       _ST_RUNNING)
_r(r"Post-align finalize from prepass",             "Integration",       _ST_RUNNING)
_r(r"🔹 .* Finalizing '(.+?)' from prepass",         "Integration",       _ST_RUNNING, 1)
_r(r"✅ Saved integrated image.*for '(.+?)'",        "Integration",       _ST_OK,   1)
_r(r"Integration complete for group '([^']+)'",     "Integration",       _ST_OK,   1)
_r(r"✅ \[LowRAM\] Integration complete",            "Integration",       _ST_OK)
_r(r"📐 Drizzle for '(.+?)'",                        "Integration",       _ST_RUNNING, 1)
_r(r"✅ Drizzle .*saved",                            "Integration",       _ST_OK)
_r(r"⚠️ Drizzle failed for '([^']+)'",               "Integration",       _ST_FAIL, 1)

# ── Star Trail ────────────────────────────────────────────────────────────
_r(r"🌠 Star-Trail Mode enabled",                        "Star Trail",            _ST_INFO)
_r(r"📂 Star-Trail: Loading \d+ frames",                 "Star Trail: Loading",   _ST_RUNNING)
_r(r"📂 Loading frame \d+/\d+",                          "Star Trail: Loading",   _ST_RUNNING)
_r(r"✅ Star-Trail: Loading complete",                    "Star Trail: Loading",   _ST_OK)
_r(r"🔄 Star-Trail: Normalizing \d+ frames",             "Star Trail: Normalize", _ST_RUNNING)
_r(r"🔄 Normalizing frame \d+/\d+",                      "Star Trail: Normalize", _ST_RUNNING)
_r(r"✅ Star-Trail: Normalization complete",              "Star Trail: Normalize", _ST_OK)
_r(r"📊 Star-Trail: Stacking \d+ frames",                "Star Trail: Stack",     _ST_RUNNING)
_r(r"💾 Loading normalized frames into memory",          "Star Trail: Stack",     _ST_RUNNING)
_r(r"⚡ Running max-value projection",                   "Star Trail: Stack",     _ST_RUNNING)
_r(r"✅ Star-Trail image saved",                          "Star Trail: Stack",     _ST_OK)

# ── Autocrop ──────────────────────────────────────────────────────────────
# Terminal rules FIRST — the greedy running rule below also matches the word
# "auto-cropped" (…crop…); with it first it swallowed every "Saved auto-
# cropped" message, so the Autocrop row never left the running state. The
# negative lookahead on "saved" keeps the running rule from grabbing the
# MF / comet / drizzle "Saved … (auto-cropped)" messages, which have their
# own terminal rules.
#
# Note the two different wordings coming out of the suite:
#   normal integration → "✂️ Saved auto-cropped image for 'group': …"
#   drizzle            → "✂️ Drizzle (auto-cropped) saved: …"
# The drizzle path phrases "saved" after "(auto-cropped)", so the first
# rule's "✂️ Saved auto-cropped" prefix never matches it and the Autocrop
# row stays running forever (even though the running rule's lookahead on
# "saved" correctly refuses to re-open the row on the drizzle message).
# Second terminator pins the drizzle wording so both paths close cleanly.
_r(r"✂️ Saved auto-cropped",                         "Autocrop",          _ST_OK)
_r(r"✂️ Drizzle \(auto-cropped\) saved",             "Autocrop",          _ST_OK)
_r(r"✂️(?!.*[Ss]aved).*[Cc]rop",                    "Autocrop",          _ST_RUNNING)

# ── Astrometric solution ──────────────────────────────────────────────────
_r(r"Transform file saved.*\.sasd \(v2\)",          "Alignment Transforms", _ST_OK)
# The integrate-already-registered path reconstructs transforms from aligned
# frame headers instead of solving them, so it emits a different message.
_r(r"✅ Wrote alignment_transforms\.sasd",           "Alignment Transforms", _ST_OK)

# ── MF Deconvolution ──────────────────────────────────────────────────────
_r(r"MFDeconv launched for (\d+) group",            "MF Deconvolution",  _ST_RUNNING, 1)
_r(r"Deconvolving '(.+?)' \(\d+ frames\)",           "MF Deconvolution",  _ST_RUNNING, 1)
_r(r"⚙️ MFDeconv engine",                           "MF Deconvolution",  _ST_RUNNING)
_r(r"✅ MFDeconv complete for all groups",           "MF Deconvolution",  _ST_OK)
_r(r"⚠️ MFDeconv finished with failures",           "MF Deconvolution",  _ST_WARN)
_r(r"❌ MFDeconv failed for '(.+?)'",               "MF Deconvolution",  _ST_FAIL, 1)
_r(r"✂️ \(MF\) Saved auto-cropped",                  "MF Deconvolution",  _ST_OK)
_r(r"Post-MF finalize failed",                      "MF Deconvolution",  _ST_WARN)

# ── Comet stacking ────────────────────────────────────────────────────────
_r(r"🌠 Comet mode enabled",                        "Comet Stack",       _ST_RUNNING)
_r(r"🟢 Measuring comet centers",                   "Comet Stack",       _ST_RUNNING)
_r(r"🟠 Comet-aligned integration",                 "Comet Stack",       _ST_RUNNING)
_r(r"✅ Saved CometOnly",                           "Comet Stack",       _ST_OK)
_r(r"🌠 Comet anchor in reference frame",           "Comet Stack",       _ST_INFO)
_r(r"◦ user confirmed",                             "Comet Stack",       _ST_INFO)
_r(r"◦ seed xy=",                                  "Comet Stack",       _ST_INFO)

# ── Comet star removal ────────────────────────────────────────────────────
_r(r"✨ Comet star removal enabled",                "Comet StarRemoval", _ST_RUNNING)
_r(r"✓ \[\d+/\d+\] starless saved",                "Comet StarRemoval", _ST_RUNNING)
_r(r"✨ Using comet-aligned STARLESS",              "Comet StarRemoval", _ST_OK)
_r(r"⚠️ star removal failed",                      "Comet StarRemoval", _ST_WARN)
_r(r"⚠️ Comet star removal pre-process aborted",   "Comet StarRemoval", _ST_FAIL)

# ── Comet blend ───────────────────────────────────────────────────────────
_r(r"🟡 Blending Stars\+Comet",                    "Comet Blend",       _ST_RUNNING)
_r(r"✅ Saved CometBlend",                          "Comet Blend",       _ST_OK)

# ── Satellite trail removal (calibration Phase 2) ─────────────────────────
# calibrate_lights defers satellite removal to a dedicated pass that runs
# AFTER calibration finishes. Without these rules those messages are
# unrecognised (suppressed), so the last calibration row stays "running" and
# silently accrues the entire satellite-pass duration. Give the pass its own
# row. A per-frame failure keeps the row RUNNING (updates the note) instead
# of terminating the whole pass on a single bad frame.
_r(r"🛰️ Satellite trail removal",                   "Satellite Removal", _ST_RUNNING)
_r(r"🛰️ \d+/\d+:",                                   "Satellite Removal", _ST_RUNNING)
_r(r"✅ Satellite trail removal complete",            "Satellite Removal", _ST_OK)
_r(r"⏹ Satellite pass cancelled",                    "Satellite Removal", _ST_WARN)
_r(r"⚠️ Satellite pass failed on",                    "Satellite Removal", _ST_RUNNING)

# ── Advanced dual-band NB split (matrix) ──────────────────────────────────
# OSC dual-band frames (e.g. L-eXtreme) are split into Ha / OIII after
# alignment. The "advanced" path first solves a per-scene mixing matrix from
# a few subs — its condition number reports how well-posed that solve was —
# then applies it to every frame. Two rows are tracked: the outer split
# (opened by "🌈 Splitting…", closed by "Dual-band split … complete") and the
# inner matrix calibration (opened by "calibrating … mixing matrix", closed
# by "Advanced NB matrix"). Keeping the matrix as its own row parks the
# cond/star-count on screen. Any fallback to a raw split (import failure,
# pooled-fit failure, or a severely ill-conditioned matrix — all end in
# "raw split") closes the matrix row as a warning; the split itself carries
# on and still reports its own completion. Per-frame "↳ NB cal …" chatter is
# left unrecognised (suppressed), as is the "ℹ️ No dual-band frames …" no-op.
_r(r"🌈 Splitting aligned dual-band .*? into ([^…]+)",    "Dual-Band Split", _ST_RUNNING, 1)
_r(r"Advanced NB split: calibrating (\S+) mixing matrix", "NB Matrix Cal",   _ST_RUNNING, 1)
_r(r"Advanced NB split.*raw split",                       "NB Matrix Cal",   _ST_WARN)
_r(r"✅ Advanced NB matrix",                               "NB Matrix Cal",   _ST_OK)
_r(r"✅ Dual-band split .*complete",                       "Dual-Band Split", _ST_OK)

# ── Generic catch-alls — MUST be last ─────────────────────────────────────
_r(r"^✅",   "Complete",  _ST_OK)
_r(r"^⚠️",  "Warning",   _ST_WARN)
_r(r"^❌",   "Error",     _ST_FAIL)

# ── Noise patterns to suppress (tile-level chatter) ──────────────────────
_SUPPRESS = re.compile(
    r"Creating temp memmap"
    r"|memmap:"
    r"|Before saving:"
    r"|min ="
    r"|max ="
    r"|LIGHT final"
    r"|💾 Saved:"
    r"|  ✓ GPU calibrated:"
    r"|  ✓ Dark loaded:"
    r"|  ✓ Flat loaded:"
    r"|  Mask saved:"
    r"|🗂️"
    r"|📦 \d+ tiles"
    r"|🧭 Total tiles"
    r"|⚙️.*reducer"
    r"|🌍 Load"
    r"|🌍 Meas"
    r"|✅ Master Dark saved: "
    r"|scale_guess"
    r"|✅ Prepass '"
    r"|✅ SASD v2"
    r"|✅ Saved rejection map"
    r"|🔹 \[\d+/\d+\] Finalizing"
    r"|Rejection prepass:"
    r"|🔹 .* Finalizing '.+?' from prepass"
    r"|preview median"
    r"|Debayer"
    r"|↻ 180"
    r"|🔧 Resamp"
    r"|📏 Pixel-scale norm"
    r"|🔎 CFA"
    r"|💡 For best"
    r"|refine_if"
    r"|Image Registration Started"
    r"|🔄 Image Registration"
    r"|Measuring chunk"
    # "✅ All chunks complete! Measured N frames total." is handled by a
    # dedicated Measurements OK rule above (needed for the integrate-already-
    # registered path, which has no "📏 Phase: Measurements complete").
    r"|Updated self\.light_files"
    r"|Transform file saved.*alignment_transforms\.sasd(?! \(v2\))"
    r"|_n\.fit"
    r"|ABE Poly"
    r"|Gradient removal"
    r"|🧪 MF prepass payload"
    r"|🌟 MFDeconv star-mask"
    r"|MF prepass payload for"
    r"|Integrating comet tile \d+"
    r"|◦ applying rejection algorithm"
    r"|◦ Tile source: STARLESS"
    r"|◦ DarkStar comet"
    r"|◦ StarNet comet"
    r"|◦ using user seed"
    r"|◦ seeding first registered"
    r"|Comet High-Clip"
    r"|Comet Lower-Trim"
    r"|comet preview skipped"
    r"|🌟 MFDeconv star-mask reference"
    r"|rejection_map="
    r"|seed_image="
    r"|🧪 Rejection prepass: \d+ group"
    r"|🔹 \[\d+/\d+\] Rejection prepass",
    re.IGNORECASE
)

def _classify(msg: str) -> Optional[tuple[str, str, str]]:
    """
    Returns (operation, group_hint, status) or None if message should be suppressed.
    """
    # Strip ANSI escapes and leading whitespace
    clean = re.sub(r"\x1b\[[0-9;]*m", "", msg).strip()

    if _SUPPRESS.search(clean):
        return None

    for pat, op, st, grp_idx in _RULES:
        m = pat.search(clean)
        if m:
            group = ""
            if grp_idx is not None:
                try:
                    group = m.group(grp_idx).strip()
                except Exception:
                    group = ""
            return op, group, st

    return None   # unrecognised — suppress


# ═══════════════════════════════════════════════════════════════════════════
#  MonitorRow — one logical step tracked by the monitor
# ═══════════════════════════════════════════════════════════════════════════
class _MonitorRow:
    def __init__(self, operation: str, group: str, status: str, note: str = ""):
        self.operation  = operation
        self.group      = group
        self.status     = status
        self.note       = note
        self.t_start    = time.monotonic()
        self.t_end: Optional[float] = None

    def elapsed_str(self) -> str:
        t = (self.t_end or time.monotonic()) - self.t_start
        if t < 60:
            return f"{t:.0f}s"
        m, s = divmod(int(t), 60)
        return f"{m:02d}:{s:02d}"

    def finish(self, status: str, note: str = ""):
        self.t_end  = time.monotonic()
        self.status = status
        if note:
            self.note = note


# ═══════════════════════════════════════════════════════════════════════════
#  StackingMonitorDialog
# ═══════════════════════════════════════════════════════════════════════════
class StackingMonitorDialog(QDialog):
    cancel_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Stacking Execution Monitor")
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, False)
        self.setMinimumSize(960, 500)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)

        self._settings  = QSettings("SetiAstro", "SASpro")
        self._rows: list[_MonitorRow] = []
        self._open: dict[str, int] = {}
        self._run_start: Optional[float] = None
        self._log_bus   = None

        # ── bottom-label run state ─────────────────────────────────────────
        # While True, _tick_elapsed repaints the summary label with a live
        # "Running · MM:SS" so it never sits on "Ready." mid-run. Terminal
        # states (finish_run/finish_all/mark_stopped) and clear() flip it off.
        self._running_active: bool = False
        self._running_caption: str = "Running"

        # ── disk-budget state (persistent label; live-polled on tick) ──
        self._disk_dir: Optional[str] = None   # volume to poll for free space
        self._disk_est: int = 0                # estimated bytes for current step
        self._disk_step: str = ""              # short step label ("Register", …)
        self._disk_tick: int = 0               # throttles the free-space poll

        self._build_ui()
        self._restore_geometry()
        self._connect_bus()
        from PyQt6.QtCore import QTimer
        self._tick_timer = QTimer(self)
        self._tick_timer.setInterval(1000)
        self._tick_timer.timeout.connect(self._tick_elapsed)
        self._tick_timer.start()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 8)
        root.setSpacing(8)

        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #e6e6e6;
            }
            QLabel#monitor_title {
                font-size: 16px;
                font-weight: bold;
                color: #FF4500;
            }
            QTableWidget {
                background-color: #2b2b2b;
                color: #e6e6e6;
                gridline-color: #444444;
                border: 1px solid #555;
                border-radius: 6px;
                font-size: 12px;
            }
            QHeaderView::section {
                background-color: #3a3a3a;
                color: #ffffff;
                font-weight: bold;
                font-size: 12px;
                border: none;
                border-right: 1px solid #555;
                padding: 5px 8px;
            }
            QTableWidget::item {
                padding: 4px 8px;
                border-bottom: 1px solid #333;
            }
            QTableWidget::item:selected {
                background-color: #FF4500;
                color: #ffffff;
            }
            QPushButton {
                background-color: #3a3a3a;
                color: #dddddd;
                border: 1px solid #666;
                border-radius: 5px;
                padding: 5px 14px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #FF4500;
                color: #ffffff;
                border: 1px solid #FF4500;
            }
            QLabel#elapsed_label {
                color: #bbbbbb;
                font-size: 11px;
            }
            QLabel#disk_label {
                font-size: 11px;
            }
        """)

        # header row
        hdr_row = QHBoxLayout()
        title = QLabel("Stacking Execution Monitor")
        title.setObjectName("monitor_title")
        hdr_row.addWidget(title)
        hdr_row.addStretch(1)

        # Persistent disk-space readout (right side of the header). Shows the
        # current free space on the target volume versus the estimated output
        # for the running step, and updates live as frames are written.
        self._disk_label = QLabel("")
        self._disk_label.setObjectName("disk_label")
        self._disk_label.setTextFormat(Qt.TextFormat.RichText)
        self._disk_label.setToolTip(
            "Free space on the stacking volume vs. the estimated output size "
            "for the current step. Updates as files are written."
        )
        self._disk_label.setVisible(False)
        hdr_row.addWidget(self._disk_label)
        root.addLayout(hdr_row)

        # table
        self._table = QTableWidget(0, _NCOLS)
        self._table.setHorizontalHeaderLabels(
            ["Operation", "Group", "Elapsed", "Status", "Note"]
        )
        self._table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self._table.verticalHeader().setVisible(False)
        self._table.setShowGrid(True)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet(
            self._table.styleSheet() +
            "QTableWidget { alternate-background-color: #252525; }"
        )

        hh = self._table.horizontalHeader()
        hh.setSectionResizeMode(_COL_OP,      QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(_COL_GROUP,   QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(_COL_ELAPSED, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(_COL_STATUS,  QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(_COL_NOTE,    QHeaderView.ResizeMode.Stretch)

        vh = self._table.verticalHeader()
        vh.setDefaultSectionSize(28)

        root.addWidget(self._table, stretch=1)

        # bottom bar
        bot = QHBoxLayout()
        self._lbl_total = QLabel("Ready.")
        self._lbl_total.setObjectName("elapsed_label")
        bot.addWidget(self._lbl_total, stretch=1)

        self.btn_stop = QPushButton("■ Stop")
        self.btn_stop.setFixedHeight(26)
        self.btn_stop.setToolTip("Request a graceful stop after the current tile/frame")
        self.btn_stop.clicked.connect(self._on_stop_clicked)
        self.btn_stop.setEnabled(False)
        bot.addWidget(self.btn_stop)

        btn_clear = QPushButton("Clear")
        btn_clear.setFixedHeight(26)
        btn_clear.clicked.connect(self.clear)
        bot.addWidget(btn_clear)

        btn_close = QPushButton("Close")
        btn_close.setFixedHeight(26)
        btn_close.clicked.connect(self.hide)
        bot.addWidget(btn_close)
        root.addLayout(bot)

        footer = QLabel(
            '<a href="https://www.setiastro.com" '
            'style="color:#FF4500;text-decoration:none;">'
            'Franklin Marek  ·  www.setiastro.com</a>'
        )
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        footer.setOpenExternalLinks(True)
        footer.setStyleSheet("font-size:10px; color:#888; padding-top:2px;")
        root.addWidget(footer)

    def _tick_elapsed(self):
        """Called every second to refresh the elapsed time on all running rows."""
        for op, idx in self._open.items():
            if idx < self._table.rowCount():
                item = self._table.item(idx, _COL_ELAPSED)
                if item is not None:
                    item.setText(self._rows[idx].elapsed_str())

        # The summary line is a static state word ("In Progress"); the live
        # ticking lives in the per-row Elapsed cells above, so nothing to
        # repaint here.

        # Refresh the free-space figure every ~3 s so the readout tracks the
        # disk filling up during a long write phase without polling too often.
        if self._disk_dir:
            self._disk_tick += 1
            if self._disk_tick % 3 == 0:
                self._refresh_disk_label()

    # ------------------------------------------------------- disk budget API
    def set_disk_budget(self, target_dir, est_bytes, *, step_label: str = ""):
        """
        Show the free-space-vs-estimate readout for the step about to run.

        target_dir : any path on the volume that will receive the output.
        est_bytes  : estimated bytes this step will write.
        step_label : short label for the step, e.g. "Register", "Integrate".
        Safe to call from the GUI thread; never raises.
        """
        try:
            self._disk_dir = str(target_dir) if target_dir else None
            self._disk_est = int(max(0, est_bytes))
            self._disk_step = str(step_label or "")
            self._disk_tick = 0
            self._refresh_disk_label()
        except Exception:
            pass

    def clear_disk_budget(self):
        """Hide the disk readout (e.g. when no step is queued)."""
        self._disk_dir = None
        self._disk_est = 0
        self._disk_step = ""
        try:
            self._disk_label.setVisible(False)
            self._disk_label.setText("")
        except Exception:
            pass

    def _refresh_disk_label(self):
        """Recompute free space and repaint the header disk readout."""
        try:
            if not self._disk_dir:
                self._disk_label.setVisible(False)
                return

            free = _disk_free_bytes(self._disk_dir)
            est = int(self._disk_est or 0)
            step = f"{self._disk_step} · " if self._disk_step else ""

            if free is None:
                self._disk_label.setText(
                    f"<span style='color:{_DIM};'>💽 {step}"
                    f"est. {_human_bytes(est)} · free space unknown</span>"
                )
                self._disk_label.setVisible(True)
                return

            # Colour by how much of the *current* free space the estimate uses.
            # Green: comfortable. Yellow: tight (>75%). Red: won't fit (>100%).
            ratio = (est / free) if free > 0 else float("inf")
            if ratio >= 1.0:
                colour = _RED
            elif ratio >= 0.75:
                colour = _ORANGE
            else:
                colour = _GREEN

            pct = f"{ratio * 100:.0f}%" if free > 0 else "—"
            self._disk_label.setText(
                f"💽 {step}"
                f"<span style='color:{_FG};'>free </span>"
                f"<span style='color:{colour};font-weight:bold;'>{_human_bytes(free)}</span>"
                f"<span style='color:{_DIM};'>  /  est. </span>"
                f"<span style='color:{_FG};'>{_human_bytes(est)}</span>"
                f"<span style='color:{colour};'> ({pct})</span>"
            )
            self._disk_label.setVisible(True)
        except Exception:
            pass

    # ---------------------------------------------------------------- bus
    def _connect_bus(self):
        from PyQt6.QtWidgets import QApplication
        app = QApplication.instance()
        if app and hasattr(app, "_sasd_log_bus"):
            self._log_bus = app._sasd_log_bus
            self._log_bus.posted.connect(
                self._on_message, Qt.ConnectionType.QueuedConnection
            )

    def _disconnect_bus(self):
        if self._log_bus is not None:
            try:
                self._log_bus.posted.disconnect(self._on_message)
            except Exception:
                pass
            self._log_bus = None

    # ----------------------------------------------------------- public API
    def _set_stop_available(self, enabled: bool, *, stopping: bool = False):
        try:
            if stopping:
                self.btn_stop.setText("Stopping…")
                self.btn_stop.setEnabled(False)
            else:
                self.btn_stop.setText("■ Stop")
                self.btn_stop.setEnabled(bool(enabled))
        except Exception:
            pass

    def start_run(self):
        self.clear()
        self._run_start = time.monotonic()
        self._set_stop_available(True)
        self._tick_timer.start()
        # Replace the "Ready." placeholder with a simple in-progress state.
        self._set_running_label("In Progress")
        self.show()
        self.raise_()
        self.activateWindow()

    # ------------------------------------------------- bottom-label helpers
    def _process_seconds(self) -> int:
        """Total *processing* time: the sum of each finished step's own
        duration (t_end − t_start). This reconciles with the per-row Elapsed
        column and deliberately excludes the idle gaps between steps that a
        wall-clock run total would otherwise fold in."""
        total = 0.0
        for r in self._rows:
            if r.t_end is not None:
                total += max(0.0, r.t_end - r.t_start)
        return int(total)

    @staticmethod
    def _mmss(seconds: float) -> str:
        m, s = divmod(int(seconds), 60)
        return f"{m:02d}:{s:02d}"

    def _set_running_label(self, caption: str = "In Progress"):
        """Show a simple live 'in progress' state on the summary line. The
        per-row Elapsed cells carry the ticking; this line only states that
        work is ongoing — no wall-clock total, which would drift from the
        summed row times."""
        self._running_caption = caption
        self._running_active = True
        self._lbl_total.setText(f"⟳ {caption}…")
        self._lbl_total.setStyleSheet(
            "color:#f0c040; font-size:11px; font-weight:bold;"
        )


    def _phase_label(self) -> str:
        # Name the phase from the operations that actually ran, so a
        # calibration-only run doesn't report as "Integration". Later phases
        # win when several are present (a full run ends on Integration).
        ops = {(r.operation or "").lower() for r in self._rows}
        if any("integration" in o for o in ops):
            return "Integration phase done"
        if any("registration" in o for o in ops):
            return "Registration phase done"
        if any("calibration" in o for o in ops):
            return "Calibration phase complete"
        return "Phase complete"

    def finish_run(self, ok: bool, summary: str = ""):
        # Close any rows that are still marked running
        for op, idx in list(self._open.items()):
            row = self._rows[idx]
            if row.status == _ST_RUNNING:
                row.finish(_ST_OK if ok else _ST_FAIL)
                self._refresh_row(idx)
        self._open.clear()

        # Only stop the timer if no new operations could still arrive.
        # For drizzle/MFD pipelines, finish_run is called after integration
        # but before the post-processing phase — so we leave the timer running
        # and let _on_message restart it if needed. We stop it here only as
        # a soft stop; _on_message will restart if new RUNNING ops appear.
        self._tick_timer.stop()

        # Processing-time total (sum of step durations), not wall clock, so it
        # matches the per-row Elapsed column.
        total_s = self._mmss(self._process_seconds())

        # Soft finish: hand the summary line over to a phase caption. If a
        # later phase posts a running op, _on_message re-arms the live label.
        self._running_active = False

        # Show as "integration complete" rather than fully done,
        # since drizzle/MFD may still follow
        if ok:
            self._lbl_total.setText(f"{self._phase_label()} ({total_s})")
            self._lbl_total.setStyleSheet(
                "color:#f0c040; font-size:11px; font-weight:bold;"
            )
        else:
            self._lbl_total.setText(f"Executed in {total_s}   ✗ Failed")
            self._lbl_total.setStyleSheet(
                "color:#ff4d4f; font-size:12px; font-weight:bold;"
            )
        self._set_stop_available(False)

    def finish_all(self, ok: bool, summary: str = ""):
        """Call this when the entire pipeline is done including drizzle/MFD."""
        for op, idx in list(self._open.items()):
            row = self._rows[idx]
            if row.status == _ST_RUNNING:
                row.finish(_ST_OK if ok else _ST_FAIL)
                self._refresh_row(idx)
        self._open.clear()
        self._tick_timer.stop()
        self._running_active = False

        total_s = self._mmss(self._process_seconds())

        if ok:
            self._lbl_total.setText(f"Executed in {total_s}   ✓ Complete")
            self._lbl_total.setStyleSheet(
                "color:#52c41a; font-size:12px; font-weight:bold;"
            )
        else:
            self._lbl_total.setText(f"Executed in {total_s}   ✗ Failed")
            self._lbl_total.setStyleSheet(
                "color:#ff4d4f; font-size:12px; font-weight:bold;"
            )
        self._set_stop_available(False)

    def _on_stop_clicked(self):
        self._set_stop_available(False, stopping=True)
        print("[CANCEL] _on_stop_clicked: emitting cancel_requested")
        self.cancel_requested.emit()
        print("[CANCEL] _on_stop_clicked: emit returned")

    def mark_stopped(self):
        """Terminal 'stopped by user' state — amber, not failure-red."""
        for op, idx in list(self._open.items()):
            row = self._rows[idx]
            row.finish(_ST_WARN, "stopped")
            self._refresh_row(idx)
        self._open.clear()
        self._tick_timer.stop()
        self._running_active = False
        total_s = self._mmss(self._process_seconds())
        self._lbl_total.setText(f"⏹ Stopped by user ({total_s})")
        self._lbl_total.setStyleSheet("color:#ffa726; font-size:12px; font-weight:bold;")
        self._set_stop_available(False)

    def clear(self):
        self._table.setRowCount(0)
        self._rows.clear()
        self._open.clear()
        self._run_start = None
        self._running_active = False
        self._lbl_total.setText("Ready.")
        self._lbl_total.setStyleSheet(f"color:{_DIM};font-size:10px;")
        self.clear_disk_budget()
        self._set_stop_available(False)

    # ---------------------------------------------------- message handler
    @pyqtSlot(str)
    def _on_message(self, msg: str):
        result = _classify(msg)
        if result is None:
            return

        op, group, status = result

        note = re.sub(
            r"^[\U0001F300-\U0001FFFF\u2600-\u26FF\u2700-\u27BF✅❌⚠️🔹📌✂️▶️🔄📊📐🧪🧱🔎💡↻⏭️⚡⏸]+\s*",
            "", msg
        ).strip()
        if len(note) > 120:
            note = note[:117] + "…"

        # ── If a new RUNNING op arrives after the run was marked complete,
        #    resume the timer — drizzle/MFD start after integration finishes
        if status == _ST_RUNNING:
            if self.btn_stop.text() != "Stopping…":
                self._set_stop_available(True)
            if not self._tick_timer.isActive():
                self._tick_timer.start()
            # A running op after a soft finish means a later phase (drizzle,
            # MFDeconv, a fresh mosaic set) has begun — flip the summary line
            # back to a live running caption so a stale "…done" doesn't linger.
            if not self._running_active:
                self._set_running_label("In Progress (post-integration phase)")

        # ── finishing transitions ─────────────────────────────────────────
        if status in (_ST_OK, _ST_FAIL, _ST_WARN) and op in self._open:
            idx = self._open.pop(op)
            row = self._rows[idx]
            # Keep the last filter's own note; summary messages like
            # "All light groups calibrated" would otherwise overwrite it.
            finish_note = "" if (op == "Calibration" and row.group and status == _ST_OK) else note
            row.finish(status, finish_note)
            self._refresh_row(idx)
            return

        # "✅ Calibration Complete" after a dedicated satellite pass would
        # otherwise spawn an empty extra Calibration success row.
        if (
            status in (_ST_OK, _ST_FAIL, _ST_WARN)
            and op == "Calibration"
            and op not in self._open
        ):
            return

        # ── continuing a running row ──────────────────────────────────────
        if status == _ST_RUNNING and op in self._open:
            idx = self._open[op]
            row = self._rows[idx]

            # NEW: if the group changed, the previous group finished —
            # close the old row and open a fresh one for the new group
            if group and row.group and group != row.group:
                # finish the previous group row
                row.finish(_ST_OK)
                self._refresh_row(idx)
                self._open.pop(op)

                # fall through to create a new row below
            else:
                # same group, just update note/group
                if group and not row.group:
                    row.group = group
                row.note = note
                self._refresh_row(idx)
                return

        # Satellite trail removal is a distinct phase after all groups.
        # Close the last Calibration row so its elapsed time stops there.
        if (
            status == _ST_RUNNING
            and op == "Satellite Trails"
            and "Calibration" in self._open
        ):
            idx = self._open.pop("Calibration")
            self._rows[idx].finish(_ST_OK)
            self._refresh_row(idx)

        # A later mosaic set starts measuring / aligning after the previous
        # set's drizzle already finished. Without a terminal Integration rule
        # (or if that message was missed), the old Integration row would stay
        # "running" next to Registration.
        if (
            status == _ST_RUNNING
            and op in ("Measurements", "Normalization", "Registration")
            and "Integration" in self._open
        ):
            idx = self._open.pop("Integration")
            self._rows[idx].finish(_ST_OK)
            self._refresh_row(idx)

        # Generic ✅/⚠️/❌ catch-alls must not spawn orphan rows while a real
        # phase is still open — e.g. "✅ SASD v2: loaded…" right after
        # "📐 Drizzle for …" was showing a false "Complete" under a running
        # Integration/Drizzle row.
        if op in ("Complete", "Warning", "Error") and self._open:
            return

        # ── new row ───────────────────────────────────────────────────────
        r = _MonitorRow(op, group, status, note)
        self._rows.append(r)
        idx = len(self._rows) - 1

        if status == _ST_RUNNING:
            self._open[op] = idx

        self._insert_table_row(idx)
        self._table.scrollToBottom()

    # ---------------------------------------------------- table rendering
    def _insert_table_row(self, idx: int):
        row = self._rows[idx]
        self._table.insertRow(idx)
        self._write_row(idx, row)

    def _refresh_row(self, idx: int):
        row = self._rows[idx]
        self._write_row(idx, row)


    def _write_row(self, idx: int, row: _MonitorRow):
        def _item(text: str, color: Optional[str] = None,
                  bold: bool = False, center: bool = False) -> QTableWidgetItem:
            it = QTableWidgetItem(text)
            it.setFlags(Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled)
            if color:
                it.setForeground(QColor(color))
            if bold:
                f = it.font()
                f.setBold(True)
                it.setFont(f)
            if center:
                it.setTextAlignment(
                    Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter
                )
            return it

        status_map = {
            _ST_RUNNING: ("⟳ running", "#f0c040"),
            _ST_OK:      ("✓ success", "#52c41a"),
            _ST_WARN:    ("⚠ warning", "#ff9800"),
            _ST_FAIL:    ("✗ failed",  "#ff4d4f"),
            _ST_INFO:    ("ℹ info",    "#888888"),
        }
        st_text, st_color = status_map.get(row.status, ("?", "#888888"))

        self._table.setItem(idx, _COL_OP,
            _item(row.operation, color="#ffffff", bold=True))
        self._table.setItem(idx, _COL_GROUP,
            _item(row.group, color="#cccccc"))
        self._table.setItem(idx, _COL_ELAPSED,
            _item(row.elapsed_str(), color="#aaaaaa", center=True))
        self._table.setItem(idx, _COL_STATUS,
            _item(st_text, color=st_color, center=True))
        self._table.setItem(idx, _COL_NOTE,
            _item(row.note, color="#888888"))

        # subtle row tint for finished states
        tint = {
            _ST_OK:   "#1a2e1a",
            _ST_FAIL: "#2e1a1a",
            _ST_WARN: "#2e221a",
        }.get(row.status)
        if tint:
            for c in range(_NCOLS):
                item = self._table.item(idx, c)
                if item:
                    item.setBackground(QColor(tint))

    # ---------------------------------------------------------------- geo
    def _restore_geometry(self):
        g = self._settings.value("StackingMonitor/geometry")
        if g:
            self.restoreGeometry(g)

    def closeEvent(self, event):
        self._tick_timer.stop()
        self._settings.setValue("StackingMonitor/geometry", self.saveGeometry())
        self._disconnect_bus()
        event.accept()

    def hideEvent(self, event):
        self._settings.setValue("StackingMonitor/geometry", self.saveGeometry())
        super().hideEvent(event)