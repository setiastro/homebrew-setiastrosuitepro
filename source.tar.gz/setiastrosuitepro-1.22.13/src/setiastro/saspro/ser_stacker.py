# src/setiastro/saspro/ser_stacker.py
from __future__ import annotations
import os
import threading

from concurrent.futures import ThreadPoolExecutor, as_completed

from dataclasses import dataclass
from typing import Optional, Tuple, List, Dict, Any

import numpy as np

import cv2
cv2.setNumThreads(1)

from setiastro.saspro.imageops.serloader import SERReader
from setiastro.saspro.ser_stack_config import SERStackConfig
from setiastro.saspro.ser_tracking import PlanetaryTracker, SurfaceTracker, _to_mono01
from setiastro.saspro.imageops.serloader import open_planetary_source, PlanetaryFrameSource
from setiastro.saspro.derotate import derotate_stack_lonshift, _build_lonlat_grids
# === SASpro flat calibration wiring (v1) ===
from setiastro.saspro.ser_calibration import load_flat_for_run as _load_flat_for_run


_BAYER_TO_CV2 = {
    "RGGB": cv2.COLOR_BayerRG2RGB,
    "BGGR": cv2.COLOR_BayerBG2RGB,
    "GRBG": cv2.COLOR_BayerGR2RGB,
    "GBRG": cv2.COLOR_BayerGB2RGB,
}

def _conform_to_ref_shape(img: np.ndarray, ref_shape: tuple) -> np.ndarray:
    """
    Pad (reflect) or crop a frame to match ref_shape (H, W) or (H, W, C).
    Preference is padding so no data is discarded.
    """
    ref_h, ref_w = int(ref_shape[0]), int(ref_shape[1])
    h, w = img.shape[0], img.shape[1]

    if h == ref_h and w == ref_w:
        return img

    # Pad if smaller, crop if larger — per axis independently
    # Step 1: pad
    pad_h = max(0, ref_h - h)
    pad_w = max(0, ref_w - w)

    if pad_h > 0 or pad_w > 0:
        if img.ndim == 2:
            img = np.pad(img, ((0, pad_h), (0, pad_w)), mode="reflect")
        else:
            img = np.pad(img, ((0, pad_h), (0, pad_w), (0, 0)), mode="reflect")

    # Step 2: crop if still oversized
    if img.shape[0] > ref_h or img.shape[1] > ref_w:
        img = img[:ref_h, :ref_w] if img.ndim == 2 else img[:ref_h, :ref_w, :]

    return img.astype(img.dtype, copy=False)

def _cfg_bayer_pattern(cfg) -> str | None:
    # cfg.bayer_pattern might be missing in older saved projects; be defensive
    return getattr(cfg, "bayer_pattern", None)

def _rotate_about(img: np.ndarray, cx: float, cy: float, ang_deg: float) -> np.ndarray:
    if abs(float(ang_deg)) < 1e-8:
        return img
    H, W = img.shape[:2]
    M = cv2.getRotationMatrix2D((float(cx), float(cy)), float(ang_deg), 1.0)
    interp = cv2.INTER_LINEAR
    return cv2.warpAffine(
        img, M, (W, H),
        flags=interp,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0
    )

def _rotate_about_rgb(img: np.ndarray, cx: float, cy: float, ang_deg: float) -> np.ndarray:
    if img.ndim == 2:
        return _rotate_about(img, cx, cy, ang_deg)
    # warpAffine works per-channel if you pass 3-ch, OpenCV is fine with that
    return _rotate_about(img, cx, cy, ang_deg)


def _get_frame(src, idx: int, *, roi, debayer: bool, to_float01: bool, force_rgb: bool, bayer_pattern: str | None):
    """
    Drop-in wrapper:
    - passes cfg.bayer_pattern down to sources that support it
    - stays compatible with sources whose get_frame() doesn't accept bayer_pattern yet
    """
    try:
        return src.get_frame(
            int(idx),
            roi=roi,
            debayer=debayer,
            to_float01=to_float01,
            force_rgb=force_rgb,
            bayer_pattern=bayer_pattern,
        )
    except TypeError:
        # Back-compat: older PlanetaryFrameSource implementations
        return src.get_frame(
            int(idx),
            roi=roi,
            debayer=debayer,
            to_float01=to_float01,
            force_rgb=force_rgb,
        )


# ---------------------------------------------------------------------------
class _CalibratedSource:
    """
    Wraps a PlanetaryFrameSource so every frame returned by get_frame() is
    already flat-corrected (frame / flat, clipped to [0,1]).

    The flat is prepared ONCE at full sensor size by load_flat_for_run();
    per-call ROI cropping happens here via view-slicing (no copy).  The
    wrapper delegates every other attribute to the inner source so callers
    that reach for .meta, .close, cache handles, etc. keep working.
    """
    __slots__ = ("_inner", "_flat")

    def __init__(self, inner, flat):
        self._inner = inner
        self._flat = flat  # np.ndarray or None

    @property
    def meta(self):
        return self._inner.meta

    def get_frame(self, idx, *, roi=None, debayer=True, to_float01=True,
                  force_rgb=False, bayer_pattern=None):
        try:
            img = self._inner.get_frame(
                int(idx), roi=roi, debayer=debayer, to_float01=to_float01,
                force_rgb=force_rgb, bayer_pattern=bayer_pattern,
            )
        except TypeError:
            img = self._inner.get_frame(
                int(idx), roi=roi, debayer=debayer, to_float01=to_float01,
                force_rgb=force_rgb,
            )
        if self._flat is None:
            return img
        # Inline the divide (avoids the setiastro.ser_calibration import
        # cost per frame; apply_flat semantics duplicated here on purpose).
        import numpy as _np
        f = _np.asarray(img, dtype=_np.float32)
        if roi is not None:
            x, y, w, h = int(roi[0]), int(roi[1]), int(roi[2]), int(roi[3])
            fl = self._flat[y:y + h, x:x + w]
        else:
            fl = self._flat
        if f.ndim == 3 and fl.ndim == 2:
            fl = fl[..., None]
        if fl.shape[:2] != f.shape[:2]:
            # Fall through to no-op rather than corrupt a frame; the caller
            # will still get a valid image and the run continues.
            return f
        out = f / fl
        _np.clip(out, 0.0, 1.0, out=out)
        return out

    def close(self):
        try:
            self._inner.close()
        except Exception:
            pass

    def __getattr__(self, name):
        # Delegate anything not overridden (cache handles, private helpers)
        return getattr(self._inner, name)
# ---------------------------------------------------------------------------

@dataclass
class AnalyzeResult:
    frames_total: int
    roi_used: Optional[Tuple[int, int, int, int]]
    track_mode: str
    quality: np.ndarray
    dx: np.ndarray
    dy: np.ndarray
    conf: np.ndarray
    order: np.ndarray
    ref_mode: str
    ref_count: int
    ref_image: np.ndarray
    ap_centers: Optional[np.ndarray] = None
    ap_size: int = 64
    ap_multiscale: bool = False
    coarse_conf: Optional[np.ndarray] = None
    ang: Optional[np.ndarray] = None
    ang_conf: Optional[np.ndarray] = None
    ref_cx: float = 0.0
    ref_cy: float = 0.0
    planet_derotate: bool = False
    surface_anchor_rot_cx: Optional[float] = None
    surface_anchor_rot_cy: Optional[float] = None
    # Per-frame per-channel dispersion offsets (shape n×3, columns R/G/B).
    # disp_dx[i, c] = extra dx to apply to channel c of frame i so it
    # aligns to the G-channel centroid.  G column is always 0.
    disp_dx: Optional[np.ndarray] = None   # (n, 3) float32
    disp_dy: Optional[np.ndarray] = None   # (n, 3) float32
    # Full-sensor normalised flat (per-channel mean=1.0). When present,
    # every _ensure_source() call that receives it returns frames
    # already divided by the flat.
    flat: Optional[np.ndarray] = None

@dataclass
class FrameEval:
    idx: int
    score: float
    dx: float
    dy: float
    conf: float

def _print_surface_debug(
    *,
    dx: np.ndarray,
    dy: np.ndarray,
    conf: np.ndarray,
    coarse_conf: np.ndarray | None,
    floor: float = 0.05,
    prefix: str = "[SER][Surface]"
) -> None:
    try:
        dx = np.asarray(dx, dtype=np.float32)
        dy = np.asarray(dy, dtype=np.float32)
        conf = np.asarray(conf, dtype=np.float32)

        dx_min = float(np.min(dx)) if dx.size else 0.0
        dx_max = float(np.max(dx)) if dx.size else 0.0
        dy_min = float(np.min(dy)) if dy.size else 0.0
        dy_max = float(np.max(dy)) if dy.size else 0.0

        conf_mean = float(np.mean(conf)) if conf.size else 0.0
        conf_min = float(np.min(conf)) if conf.size else 0.0

        msg = (
            f"{prefix} dx[min,max]=({dx_min:.2f},{dx_max:.2f})  "
            f"dy[min,max]=({dy_min:.2f},{dy_max:.2f})  "
            f"conf[mean,min]=({conf_mean:.3f},{conf_min:.3f})"
        )

        if coarse_conf is not None:
            cc = np.asarray(coarse_conf, dtype=np.float32)
            cc_mean = float(np.mean(cc)) if cc.size else 0.0
            cc_min = float(np.min(cc)) if cc.size else 0.0
            cc_bad = float(np.mean(cc < 0.2)) if cc.size else 0.0
            msg += f"  coarse_conf[mean,min]=({cc_mean:.3f},{cc_min:.3f})  frac<0.2={cc_bad:.2%}"

        if conf_mean <= floor + 1e-6:
            msg += f"  ⚠ conf.mean near floor ({floor}); alignment likely failing"
        print(msg)
    except Exception as e:
        print(f"{prefix} debug print failed: {e}")


def _clamp_roi_in_bounds(roi: Tuple[int, int, int, int], w: int, h: int) -> Tuple[int, int, int, int]:
    x, y, rw, rh = [int(v) for v in roi]
    x = max(0, min(w - 1, x))
    y = max(0, min(h - 1, y))
    rw = max(1, min(w - x, rw))
    rh = max(1, min(h - y, rh))
    return x, y, rw, rh

def _grad_img(m: np.ndarray) -> np.ndarray:
    """Simple, robust edge image for SSD refine."""
    m = m.astype(np.float32, copy=False)
    if cv2 is None:
        # fallback: finite differences
        gx = np.zeros_like(m); gx[:, 1:] = m[:, 1:] - m[:, :-1]
        gy = np.zeros_like(m); gy[1:, :] = m[1:, :] - m[:-1, :]
        g = np.abs(gx) + np.abs(gy)
        g -= float(g.mean())
        s = float(g.std()) + 1e-6
        return g / s

    gx = cv2.Sobel(m, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(m, cv2.CV_32F, 0, 1, ksize=3)
    g = cv2.magnitude(gx, gy)
    g -= float(g.mean())
    s = float(g.std()) + 1e-6
    return (g / s).astype(np.float32, copy=False)

def _ssd_prepare_ref(ref_m: np.ndarray, crop: float = 0.80):
    """
    Precompute reference gradient + crop window once.

    Returns:
      rg   : full reference gradient image (float32)
      rgc  : cropped view of rg
      sl   : (y0,y1,x0,x1) crop slices
    """
    ref_m = ref_m.astype(np.float32, copy=False)
    rg = _grad_img(ref_m)  # compute ONCE

    H, W = rg.shape[:2]
    cfx = max(8, int(W * (1.0 - float(crop)) * 0.5))
    cfy = max(8, int(H * (1.0 - float(crop)) * 0.5))
    x0, x1 = cfx, W - cfx
    y0, y1 = cfy, H - cfy

    rgc = rg[y0:y1, x0:x1]  # view
    return rg, rgc, (y0, y1, x0, x1)

def _subpixel_quadratic_1d(vm: float, v0: float, vp: float) -> float:
    """
    Given SSD at (-1,0,+1): (vm, v0, vp), return vertex offset in [-0.5,0.5]-ish.
    Works for minimizing SSD.
    """
    denom = (vm - 2.0 * v0 + vp)
    if abs(denom) < 1e-12:
        return 0.0
    # vertex of parabola fit through -1,0,+1
    t = 0.5 * (vm - vp) / denom
    return float(np.clip(t, -0.75, 0.75))


def _ssd_confidence_prepared(
    rgc: np.ndarray,
    cgc0: np.ndarray,
    dx_i: int,
    dy_i: int,
) -> float:
    """
    Compute SSD between rgc and cgc0 shifted by (dx_i,dy_i) using slicing overlap.
    Returns SSD (lower is better).

    NOTE: This is integer-only and extremely fast (no warps).
    """
    H, W = rgc.shape[:2]

    # Overlap slices for rgc and shifted cgc0
    x0r = max(0, dx_i)
    x1r = min(W, W + dx_i)
    y0r = max(0, dy_i)
    y1r = min(H, H + dy_i)

    x0c = max(0, -dx_i)
    x1c = min(W, W - dx_i)
    y0c = max(0, -dy_i)
    y1c = min(H, H - dy_i)

    rr = rgc[y0r:y1r, x0r:x1r]
    cc = cgc0[y0c:y1c, x0c:x1c]

    d = rr - cc
    return float(np.mean(d * d))


def _ssd_confidence(
    ref_m: np.ndarray,
    cur_m: np.ndarray,
    dx: float,
    dy: float,
    *,
    crop: float = 0.80,
) -> float:
    """
    Original API: confidence from gradient SSD, higher=better (0..1).

    Optimized:
      - computes ref grad once per call (still OK if used standalone)
      - uses one warp for (dx,dy)
      - no extra work beyond necessary

    For iterative search, use _refine_shift_ssd() which avoids redoing work.
    """
    ref_m = ref_m.astype(np.float32, copy=False)
    cur_m = cur_m.astype(np.float32, copy=False)

    # shift current by the proposed shift
    cur_s = _shift_image(cur_m, float(dx), float(dy))

    rg, rgc, sl = _ssd_prepare_ref(ref_m, crop=crop)
    y0, y1, x0, x1 = sl

    cg = _grad_img(cur_s)
    cgc = cg[y0:y1, x0:x1]

    d = rgc - cgc
    ssd = float(np.mean(d * d))

    scale = 0.002
    conf = float(np.exp(-ssd / max(1e-12, scale)))
    return float(np.clip(conf, 0.0, 1.0))


def _refine_shift_ssd(
    ref_m: np.ndarray,
    cur_m: np.ndarray,
    dx0: float,
    dy0: float,
    *,
    radius: int = 10,
    crop: float = 0.80,
    bruteforce: bool = False,
    max_steps: int | None = None,
) -> tuple[float, float, float]:
    """
    Returns (dx_refine, dy_refine, conf) where you ADD refine to (dx0,dy0).

    CPU-optimized:
      - precompute ref gradient crop once
      - apply (dx0,dy0) shift ONCE
      - compute gradient ONCE for shifted cur
      - evaluate integer candidates via slicing overlap SSD (no warps)

    If bruteforce=True, does full window scan in [-r,r]^2 (fast).
    Otherwise does 8-neighbor hill-climb over integer offsets (very fast).

    Optional subpixel polish:
      - after choosing best integer (best_dx,best_dy), do a tiny separable quadratic
        fit along x and y using SSD at +/-1 around the best integer.
      - does NOT require any new gradients/warps (just 4 extra SSD evals).
    """
    r = int(max(0, radius))
    if r == 0:
        # nothing to do; just compute confidence at dx0/dy0
        c = _ssd_confidence(ref_m, cur_m, dx0, dy0, crop=crop)
        return 0.0, 0.0, float(c)

    # Prepare ref grad crop ONCE
    _, rgc, sl = _ssd_prepare_ref(ref_m, crop=crop)
    y0, y1, x0, x1 = sl

    # Shift cur by the current estimate ONCE, then gradient ONCE
    cur_m = cur_m.astype(np.float32, copy=False)
    cur0 = _shift_image(cur_m, float(dx0), float(dy0))
    cg0 = _grad_img(cur0)
    cgc0 = cg0[y0:y1, x0:x1]

    # Helper: parabola vertex for minimizing SSD, using (-1,0,+1) samples
    def _quad_min_offset(vm: float, v0: float, vp: float) -> float:
        denom = (vm - 2.0 * v0 + vp)
        if abs(denom) < 1e-12:
            return 0.0
        t = 0.5 * (vm - vp) / denom
        return float(np.clip(t, -0.75, 0.75))

    if bruteforce:
        # NOTE: your bruteforce path currently includes a subpixel step already.
        # If you want to keep using that exact implementation, just call it:
        dxr, dyr, conf = _refine_shift_ssd_bruteforce(ref_m, cur_m, dx0, dy0, radius=r, crop=crop)
        return float(dxr), float(dyr), float(conf)

    # Hill-climb in integer space minimizing SSD
    if max_steps is None:
        max_steps = max(1, min(r, 6))  # small cap helps speed; tune if you want

    best_dx = 0
    best_dy = 0
    best_ssd = _ssd_confidence_prepared(rgc, cgc0, 0, 0)

    neigh = ((-1,0),(1,0),(0,-1),(0,1),(-1,-1),(-1,1),(1,-1),(1,1))

    for _ in range(int(max_steps)):
        improved = False
        for sx, sy in neigh:
            cand_dx = best_dx + sx
            cand_dy = best_dy + sy
            if abs(cand_dx) > r or abs(cand_dy) > r:
                continue

            ssd = _ssd_confidence_prepared(rgc, cgc0, cand_dx, cand_dy)
            if ssd < best_ssd:
                best_ssd = ssd
                best_dx = cand_dx
                best_dy = cand_dy
                improved = True

        if not improved:
            break

    # ---- subpixel quadratic polish around best integer (cheap) ----
    # Uses SSD at +/-1 around best integer in X and Y (separable).
    dx_sub = 0.0
    dy_sub = 0.0
    if r >= 1:
        # X samples at (best_dx-1, best_dy), (best_dx, best_dy), (best_dx+1, best_dy)
        if abs(best_dx - 1) <= r:
            s_xm = _ssd_confidence_prepared(rgc, cgc0, best_dx - 1, best_dy)
        else:
            s_xm = best_ssd
        s_x0 = best_ssd
        if abs(best_dx + 1) <= r:
            s_xp = _ssd_confidence_prepared(rgc, cgc0, best_dx + 1, best_dy)
        else:
            s_xp = best_ssd
        dx_sub = _quad_min_offset(s_xm, s_x0, s_xp)

        # Y samples at (best_dx, best_dy-1), (best_dx, best_dy), (best_dx, best_dy+1)
        if abs(best_dy - 1) <= r:
            s_ym = _ssd_confidence_prepared(rgc, cgc0, best_dx, best_dy - 1)
        else:
            s_ym = best_ssd
        s_y0 = best_ssd
        if abs(best_dy + 1) <= r:
            s_yp = _ssd_confidence_prepared(rgc, cgc0, best_dx, best_dy + 1)
        else:
            s_yp = best_ssd
        dy_sub = _quad_min_offset(s_ym, s_y0, s_yp)

    best_dx_f = float(best_dx) + float(dx_sub)
    best_dy_f = float(best_dy) + float(dy_sub)

    # Confidence: keep based on best *integer* SSD (no subpixel warp needed)
    scale = 0.002
    conf = float(np.exp(-best_ssd / max(1e-12, scale)))
    conf = float(np.clip(conf, 0.0, 1.0))

    return float(best_dx_f), float(best_dy_f), float(conf)



def _refine_shift_ssd_bruteforce(
    ref_m: np.ndarray,
    cur_m: np.ndarray,
    dx0: float,
    dy0: float,
    *,
    radius: int = 2,
    crop: float = 0.80,
) -> tuple[float, float, float]:
    """
    Full brute-force scan in [-radius,+radius]^2, but optimized:
      - shift by (dx0,dy0) ONCE
      - compute gradients ONCE
      - evaluate candidates via slicing overlap SSD (no warps)
      - keep your separable quadratic subpixel fit
    """
    ref_m = ref_m.astype(np.float32, copy=False)
    cur_m = cur_m.astype(np.float32, copy=False)

    r = int(max(0, radius))
    if r == 0:
        c = _ssd_confidence(ref_m, cur_m, dx0, dy0, crop=crop)
        return 0.0, 0.0, float(c)

    # Apply current estimate once
    cur0 = _shift_image(cur_m, float(dx0), float(dy0))

    # Gradients once
    rg = _grad_img(ref_m)
    cg0 = _grad_img(cur0)

    H, W = rg.shape[:2]
    cfx = max(8, int(W * (1.0 - float(crop)) * 0.5))
    cfy = max(8, int(H * (1.0 - float(crop)) * 0.5))
    x0, x1 = cfx, W - cfx
    y0, y1 = cfy, H - cfy

    rgc = rg[y0:y1, x0:x1]
    cgc0 = cg0[y0:y1, x0:x1]

    # brute-force integer search
    best = (0, 0)
    best_ssd = float("inf")
    ssds: dict[tuple[int, int], float] = {}

    for j in range(-r, r + 1):
        for i in range(-r, r + 1):
            ssd = _ssd_confidence_prepared(rgc, cgc0, i, j)
            ssds[(i, j)] = ssd
            if ssd < best_ssd:
                best_ssd = ssd
                best = (i, j)

    bx, by = best

    # Subpixel quadratic fit (separable) if neighbors exist
    def _quad_peak(vm, v0, vp):
        denom = (vm - 2.0 * v0 + vp)
        if abs(denom) < 1e-12:
            return 0.0
        return 0.5 * (vm - vp) / denom

    dx_sub = 0.0
    dy_sub = 0.0
    if (bx - 1, by) in ssds and (bx + 1, by) in ssds:
        dx_sub = _quad_peak(ssds[(bx - 1, by)], ssds[(bx, by)], ssds[(bx + 1, by)])
    if (bx, by - 1) in ssds and (bx, by + 1) in ssds:
        dy_sub = _quad_peak(ssds[(bx, by - 1)], ssds[(bx, by)], ssds[(bx, by + 1)])

    dxr = float(bx + np.clip(dx_sub, -0.75, 0.75))
    dyr = float(by + np.clip(dy_sub, -0.75, 0.75))

    # Confidence: use your “sharpness” idea (median neighbor vs best)
    neigh = [v for (k, v) in ssds.items() if k != (bx, by)]
    neigh_med = float(np.median(np.asarray(neigh, np.float32))) if neigh else best_ssd
    sharp = max(0.0, neigh_med - best_ssd)
    conf = float(np.clip(sharp / max(1e-6, neigh_med), 0.0, 1.0))

    return dxr, dyr, conf

def _bandpass(m: np.ndarray) -> np.ndarray:
    """Illumination-robust image for tracking (float32)."""
    m = m.astype(np.float32, copy=False)

    # remove large-scale illumination (terminator gradient)
    lo = cv2.GaussianBlur(m, (0, 0), 6.0)
    hi = cv2.GaussianBlur(m, (0, 0), 1.2)
    bp = hi - lo

    # normalize
    bp -= float(bp.mean())
    s = float(bp.std()) + 1e-6
    bp = bp / s

    # window to reduce FFT edge artifacts
    hann_y = np.hanning(bp.shape[0]).astype(np.float32)
    hann_x = np.hanning(bp.shape[1]).astype(np.float32)
    bp *= (hann_y[:, None] * hann_x[None, :])

    return bp

def _reject_ap_outliers(ap_dx: np.ndarray, ap_dy: np.ndarray, ap_cf: np.ndarray, *, z: float = 3.5) -> np.ndarray:
    """
    Return a boolean mask of APs to keep based on MAD distance from median.
    """
    dx = np.asarray(ap_dx, np.float32)
    dy = np.asarray(ap_dy, np.float32)
    cf = np.asarray(ap_cf, np.float32)

    good = cf > 0.15
    if not np.any(good):
        return good

    dxg = dx[good]
    dyg = dy[good]

    mx = float(np.median(dxg))
    my = float(np.median(dyg))

    rx = np.abs(dxg - mx)
    ry = np.abs(dyg - my)

    madx = float(np.median(rx)) + 1e-6
    mady = float(np.median(ry)) + 1e-6

    zx = rx / madx
    zy = ry / mady

    keep_g = (zx < z) & (zy < z)
    keep = np.zeros_like(good)
    keep_idx = np.where(good)[0]
    keep[keep_idx] = keep_g
    return keep


def _coarse_surface_ref_locked(
    source_obj,
    *,
    n: int,
    roi,
    roi_used=None,
    debayer: bool,
    to_rgb: bool,
    bayer_pattern: Optional[str] = None,
    progress_cb=None,
    progress_every: int = 25,
    # tuning:
    down: int = 2,
    template_size: int = 256,
    search_radius: int = 96,
    bandpass: bool = True,
    # ✅ NEW: parallel coarse
    workers: int | None = None,
    stride: int = 16,
    flat=None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Surface coarse tracking that DOES NOT DRIFT:
    - Locks to frame0 reference (in roi=roi_track coords).
    - Uses NCC + subpixel phaseCorr.
    - Optional parallelization by chunking time into segments of length=stride.
      Each segment runs sequentially (keeps pred window), segments run in parallel.
    """
    if cv2 is None:
        dx = np.zeros((n,), np.float32)
        dy = np.zeros((n,), np.float32)
        cc = np.ones((n,), np.float32)
        return dx, dy, cc

    dx = np.zeros((n,), dtype=np.float32)
    dy = np.zeros((n,), dtype=np.float32)
    cc = np.zeros((n,), dtype=np.float32)

    def _downN(m: np.ndarray) -> np.ndarray:
        if down <= 1:
            return m.astype(np.float32, copy=False)
        H, W = m.shape[:2]
        return cv2.resize(
            m,
            (max(2, W // down), max(2, H // down)),
            interpolation=cv2.INTER_AREA,
        ).astype(np.float32, copy=False)

    def _pick_anchor_center_ds(W: int, H: int) -> tuple[int, int]:
        cx = W // 2
        cy = H // 2
        if roi_used is None or roi is None:
            return int(cx), int(cy)
        try:
            xt, yt, wt, ht = [int(v) for v in roi]
            xu, yu, wu, hu = [int(v) for v in roi_used]
            cux = xu + (wu * 0.5)
            cuy = yu + (hu * 0.5)
            cx_full = cux - xt
            cy_full = cuy - yt
            cx = int(round(cx_full / max(1, int(down))))
            cy = int(round(cy_full / max(1, int(down))))
            cx = max(0, min(W - 1, cx))
            cy = max(0, min(H - 1, cy))
        except Exception:
            pass
        return int(cx), int(cy)

    # ---------------------------
    # Prep ref/template once
    # ---------------------------
    src0, owns0 = _ensure_source(source_obj, cache_items=2, flat=flat)
    try:
        img0 = _get_frame(src0, 0, roi=roi, debayer=debayer, to_float01=True, force_rgb=bool(to_rgb), bayer_pattern=bayer_pattern)

        _src0_shape = img0.shape  # stash for conforming subsequent frames
        ref0 = _to_mono01(img0).astype(np.float32, copy=False)
        ref0 = _downN(ref0)
        ref0p = _bandpass(ref0) if bandpass else (ref0 - float(ref0.mean()))

        H, W = ref0p.shape[:2]
        ts = int(max(64, min(template_size, min(H, W) - 4)))
        half = ts // 2

        cx0, cy0 = _pick_anchor_center_ds(W, H)
        rx0 = max(0, min(W - ts, cx0 - half))
        ry0 = max(0, min(H - ts, cy0 - half))
        ref_t = ref0p[ry0:ry0 + ts, rx0:rx0 + ts].copy()
    finally:
        if owns0:
            try:
                src0.close()
            except Exception:
                pass

    dx[0] = 0.0
    dy[0] = 0.0
    cc[0] = 1.0

    if progress_cb:
        progress_cb(0, n, "Surface: coarse (ref-locked NCC+subpix)…")

    # If no workers requested (or too small), fall back to sequential
    if workers is None:
        cpu = os.cpu_count() or 4
        workers = max(1, min(cpu, 48))
    workers = int(max(1, workers))
    stride = int(max(4, stride))

    # ---------------------------
    # Core "one frame" matcher
    # ---------------------------
    def _match_one(curp: np.ndarray, pred_x: float, pred_y: float, r: int) -> tuple[float, float, float, float, float]:
        # returns (mx_ds, my_ds, dx_full, dy_full, conf)
        x0 = int(max(0, min(W - 1, pred_x - r)))
        y0 = int(max(0, min(H - 1, pred_y - r)))
        x1 = int(min(W, pred_x + r + ts))
        y1 = int(min(H, pred_y + r + ts))

        win = curp[y0:y1, x0:x1]
        if win.shape[0] < ts or win.shape[1] < ts:
            return float(pred_x), float(pred_y), 0.0, 0.0, 0.0

        res = cv2.matchTemplate(win, ref_t, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        conf_ncc = float(np.clip(max_val, 0.0, 1.0))

        mx_ds = float(x0 + max_loc[0])
        my_ds = float(y0 + max_loc[1])

        # subpix refine on the matched patch
        mx_i = int(round(mx_ds))
        my_i = int(round(my_ds))
        cur_t = curp[my_i:my_i + ts, mx_i:mx_i + ts]
        if cur_t.shape == ref_t.shape:
            (sdx, sdy), resp = cv2.phaseCorrelate(ref_t.astype(np.float32), cur_t.astype(np.float32))
            sub_dx = float(sdx)
            sub_dy = float(sdy)
            conf_pc = float(np.clip(resp, 0.0, 1.0))
        else:
            sub_dx = 0.0
            sub_dy = 0.0
            conf_pc = 0.0

        dx_ds = float(rx0 - mx_ds) + sub_dx
        dy_ds = float(ry0 - my_ds) + sub_dy
        dx_full = float(dx_ds * down)
        dy_full = float(dy_ds * down)

        conf = float(np.clip(0.65 * conf_ncc + 0.35 * conf_pc, 0.0, 1.0))
        return float(mx_ds), float(my_ds), dx_full, dy_full, conf

    # ---------------------------
    # Keyframe boundary pass (sequential)
    # ---------------------------
    boundaries = list(range(0, n, stride))
    start_pred = {}  # b -> (pred_x, pred_y)
    start_pred[0] = (float(rx0), float(ry0))

    # We use a slightly larger radius for boundary frames to be extra safe
    r_key = int(max(16, int(search_radius) * 2))

    srck, ownsk = _ensure_source(source_obj, cache_items=2, flat=flat)
    try:
        pred_x, pred_y = float(rx0), float(ry0)
        for b in boundaries[1:]:
            img = _get_frame(srck, b, roi=roi, debayer=debayer, to_float01=True, force_rgb=bool(to_rgb), bayer_pattern=bayer_pattern)
            img = _conform_to_ref_shape(img, img0.shape) if 'img0' in dir() else img
            cur = _to_mono01(img).astype(np.float32, copy=False)
            cur = _downN(cur)
            curp = _bandpass(cur) if bandpass else (cur - float(cur.mean()))

            mx_ds, my_ds, dx_b, dy_b, conf_b = _match_one(curp, pred_x, pred_y, r_key)

            # store boundary predictor (template top-left in this frame)
            start_pred[b] = (mx_ds, my_ds)

            # update for next boundary
            pred_x, pred_y = mx_ds, my_ds

            # also fill boundary output immediately (optional but nice)
            dx[b] = dx_b
            dy[b] = dy_b
            cc[b] = conf_b
            if conf_b < 0.15 and b > 0:
                dx[b] = dx[b - 1]
                dy[b] = dy[b - 1]
    finally:
        if ownsk:
            try:
                srck.close()
            except Exception:
                pass

    # ---------------------------
    # Parallel per-chunk scan (each chunk sequential)
    # ---------------------------
    r = int(max(16, search_radius))

    def _run_chunk(b: int, e: int) -> int:
        src, owns = _ensure_source(source_obj, cache_items=0, flat=flat)
        try:
            pred_x, pred_y = start_pred.get(b, (float(rx0), float(ry0)))
            # if boundary already computed above, keep it; start after b
            i0 = b
            if b in start_pred and b != 0:
                i0 = b + 1   # boundary already solved with r_key

            if i0 == 0:
                i0 = 1
            for i in range(i0, e):
                if i in start_pred:
                    pred_x, pred_y = start_pred[i]
                    continue

                img = _get_frame(src, i, roi=roi, debayer=debayer, to_float01=True, force_rgb=bool(to_rgb), bayer_pattern=bayer_pattern)
                img = _conform_to_ref_shape(img, _src0_shape)
                cur = _to_mono01(img).astype(np.float32, copy=False)
                cur = _downN(cur)
                curp = _bandpass(cur) if bandpass else (cur - float(cur.mean()))

                mx_ds, my_ds, dx_i, dy_i, conf_i = _match_one(curp, pred_x, pred_y, r)

                dx[i] = dx_i
                dy[i] = dy_i
                cc[i] = conf_i

                pred_x, pred_y = mx_ds, my_ds

                if conf_i < 0.15 and i > 0:
                    dx[i] = dx[i - 1]
                    dy[i] = dy[i - 1]
            return (e - b)
        finally:
            if owns:
                try:
                    src.close()
                except Exception:
                    pass

    if workers <= 1 or n <= stride * 2:
        # small job: just do sequential scan exactly like before
        src, owns = _ensure_source(source_obj, cache_items=2, flat=flat)
        try:
            pred_x, pred_y = float(rx0), float(ry0)
            for i in range(1, n):
                img = _get_frame(src, i, roi=roi, debayer=debayer, to_float01=True, force_rgb=bool(to_rgb), bayer_pattern=bayer_pattern)
                img = _conform_to_ref_shape(img, _src0_shape)
                cur = _to_mono01(img).astype(np.float32, copy=False)
                cur = _downN(cur)
                curp = _bandpass(cur) if bandpass else (cur - float(cur.mean()))

                mx_ds, my_ds, dx_i, dy_i, conf_i = _match_one(curp, pred_x, pred_y, r)
                dx[i] = dx_i
                dy[i] = dy_i
                cc[i] = conf_i
                pred_x, pred_y = mx_ds, my_ds

                if conf_i < 0.15:
                    dx[i] = dx[i - 1]
                    dy[i] = dy[i - 1]

                if progress_cb and (i % int(max(1, progress_every)) == 0 or i == n - 1):
                    progress_cb(i, n, "Surface: coarse (ref-locked NCC+subpix)…")
        finally:
            if owns:
                try:
                    src.close()
                except Exception:
                    pass
        return dx, dy, cc

    # Parallel chunks
    done = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = []
        for b in boundaries:
            e = min(n, b + stride)
            futs.append(ex.submit(_run_chunk, b, e))

        for fut in as_completed(futs):
            done += int(fut.result())
            if progress_cb:
                # best-effort: done is "frames processed" not exact index
                progress_cb(min(done, n - 1), n, "Surface: coarse (ref-locked NCC+subpix)…")

    return dx, dy, cc


def _shift_image(img01: np.ndarray, dx: float, dy: float) -> np.ndarray:
    """
    Shift image by (dx,dy) in pixel units. Positive dx shifts right, positive dy shifts down.
    Uses cv2.warpAffine if available; else nearest-ish roll (wrap) fallback.
    """
    if abs(dx) < 1e-6 and abs(dy) < 1e-6:
        return img01

    if cv2 is not None:
        # border replicate is usually better than constant black for planetary
        h, w = img01.shape[:2]
        M = np.array([[1.0, 0.0, dx],
                      [0.0, 1.0, dy]], dtype=np.float32)
        if img01.ndim == 2:
            return cv2.warpAffine(img01, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        else:
            return cv2.warpAffine(img01, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    # very rough fallback (wraps!)
    rx = int(round(dx))
    ry = int(round(dy))
    out = np.roll(img01, shift=ry, axis=0)
    out = np.roll(out, shift=rx, axis=1)
    return out


def _channel_centroid_shifts(
    img: np.ndarray,
    tracker,
    ref_cx: float,
    ref_cy: float,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Compute per-channel (R, G, B) centroid shifts relative to the G channel.
 
    Given a 3-channel float32 frame (already globally translated so the
    planet is roughly centred), find the centroid of each colour channel
    independently and return the additional (dx, dy) needed to align R and B
    to G.  The G entry is always (0, 0).
 
    Returns:
        ch_dx : float32 array shape (3,)  — dx for R, G, B
        ch_dy : float32 array shape (3,)  — dy for R, G, B
    """
    ch_dx = np.zeros(3, dtype=np.float32)
    ch_dy = np.zeros(3, dtype=np.float32)
 
    if img.ndim != 3 or img.shape[2] < 3:
        # mono frame — nothing to correct
        return ch_dx, ch_dy
 
    # Find G centroid first (index 1)
    g_chan = img[:, :, 1].astype(np.float32, copy=False)
    gcx, gcy, gcc = tracker.compute_center(g_chan)
    if gcc <= 0.0:
        # G centroid failed — fall back to image centre
        gcx = float(g_chan.shape[1] * 0.5)
        gcy = float(g_chan.shape[0] * 0.5)
 
    # For R (0) and B (2), find centroid and compute shift to align to G
    for c_idx in (0, 2):
        chan = img[:, :, c_idx].astype(np.float32, copy=False)
        ccx, ccy, ccc = tracker.compute_center(chan)
        if ccc <= 0.0:
            # centroid failed — no correction for this channel
            continue
        # shift needed: move this channel's centroid to where G is
        ch_dx[c_idx] = gcx - ccx
        ch_dy[c_idx] = gcy - ccy
 
    return ch_dx, ch_dy


def _downsample_mono01(img01: np.ndarray, max_dim: int = 512) -> np.ndarray:
    """
    Convert to mono and downsample for analysis/tracking. Returns float32 in [0,1].
    """
    m = _to_mono01(img01).astype(np.float32, copy=False)
    H, W = m.shape[:2]
    mx = int(max(1, max_dim))
    if max(H, W) <= mx:
        return m

    if cv2 is None:
        # crude fallback
        scale = mx / float(max(H, W))
        nh = max(2, int(round(H * scale)))
        nw = max(2, int(round(W * scale)))
        # nearest-ish
        ys = (np.linspace(0, H - 1, nh)).astype(np.int32)
        xs = (np.linspace(0, W - 1, nw)).astype(np.int32)
        return m[ys[:, None], xs[None, :]].astype(np.float32)

    scale = mx / float(max(H, W))
    nh = max(2, int(round(H * scale)))
    nw = max(2, int(round(W * scale)))
    return cv2.resize(m, (nw, nh), interpolation=cv2.INTER_AREA).astype(np.float32, copy=False)


def _phase_corr_shift(ref_m: np.ndarray, cur_m: np.ndarray) -> tuple[float, float, float]:
    """
    Returns (dx, dy, response) such that shifting cur by (dx,dy) aligns to ref.
    Uses cv2.phaseCorrelate if available.
    """
    if cv2 is None:
        return 0.0, 0.0, 1.0

    # phaseCorrelate expects float32/float64
    ref = ref_m.astype(np.float32, copy=False)
    cur = cur_m.astype(np.float32, copy=False)
    (dx, dy), resp = cv2.phaseCorrelate(ref, cur)  # shift cur -> ref
    return float(dx), float(dy), float(resp)

def _estimate_rotation_fm(ref_m: np.ndarray, cur_m: np.ndarray, *, max_dim: int = 512) -> tuple[float, float]:
    """
    Estimate rotation (degrees) between ref and cur using a Fourier–Mellin style approach:
      - take FFT magnitude spectra
      - log-polar transform
      - phaseCorrelate to get x-shift => rotation

    Returns: (angle_deg, conf) where conf in [0..1].
    Positive angle means: rotate cur by +angle to better match ref (best-effort).
    """
    if cv2 is None:
        return 0.0, 0.0

    ref = _downsample_mono01(ref_m, max_dim=max_dim).astype(np.float32, copy=False)
    cur = _downsample_mono01(cur_m, max_dim=max_dim).astype(np.float32, copy=False)

    # windowing helps stability
    H, W = ref.shape[:2]
    wy = np.hanning(H).astype(np.float32)
    wx = np.hanning(W).astype(np.float32)
    win = (wy[:, None] * wx[None, :]).astype(np.float32, copy=False)
    refw = ref * win
    curw = cur * win

    # FFT magnitude spectra
    Fr = np.fft.fft2(refw)
    Fc = np.fft.fft2(curw)
    Mr = np.log1p(np.abs(np.fft.fftshift(Fr))).astype(np.float32, copy=False)
    Mc = np.log1p(np.abs(np.fft.fftshift(Fc))).astype(np.float32, copy=False)

    # highpass a bit (optional) to reduce DC dominance
    Mr -= float(np.median(Mr))
    Mc -= float(np.median(Mc))

    # log-polar transform
    cy = (H - 1) * 0.5
    cx = (W - 1) * 0.5
    rmax = min(cx, cy)
    if rmax <= 8:
        return 0.0, 0.0

    # width of log-polar image controls angular resolution
    lp_w = max(128, int(round(W)))
    lp_h = max(128, int(round(H)))

    Mr_lp = cv2.warpPolar(
        Mr, (lp_w, lp_h), (cx, cy), rmax,
        flags=cv2.WARP_POLAR_LOG | cv2.INTER_LINEAR
    )
    Mc_lp = cv2.warpPolar(
        Mc, (lp_w, lp_h), (cx, cy), rmax,
        flags=cv2.WARP_POLAR_LOG | cv2.INTER_LINEAR
    )

    # phase correlate in log-polar:
    # x shift corresponds to rotation
    (dx, dy), resp = cv2.phaseCorrelate(Mr_lp.astype(np.float32), Mc_lp.astype(np.float32))

    # dx pixels over lp_w corresponds to degrees
    ang = -360.0 * (float(dx) / float(lp_w))  # sign chosen so "rotate cur by ang" tends to align
    conf = float(np.clip(resp, 0.0, 1.0))
    # keep angle in a reasonable range
    if ang > 180.0:
        ang -= 360.0
    elif ang < -180.0:
        ang += 360.0

    return float(ang), float(conf)


def _pick_surface_anchor_xy(
    *,
    roi_used: Optional[Tuple[int, int, int, int]],
    surface_anchor,
    ref_img01: np.ndarray
) -> tuple[float, float]:
    """
    Return anchor (cx,cy) in ROI coords.
    surface_anchor may be:
      - None => ROI center
      - tuple/list (x,y) already in ROI coords
      - dict-like with keys x/y or cx/cy
    """
    H, W = ref_img01.shape[:2]
    cx = float(W * 0.5)
    cy = float(H * 0.5)

    if surface_anchor is None:
        return cx, cy

    try:
        if isinstance(surface_anchor, (tuple, list)) and len(surface_anchor) >= 2:
            return float(surface_anchor[0]), float(surface_anchor[1])
        if isinstance(surface_anchor, dict):
            if "cx" in surface_anchor and "cy" in surface_anchor:
                return float(surface_anchor["cx"]), float(surface_anchor["cy"])
            if "x" in surface_anchor and "y" in surface_anchor:
                return float(surface_anchor["x"]), float(surface_anchor["y"])
    except Exception:
        pass

    return cx, cy

def _find_best_rotation_ssd(
    ref_m: np.ndarray,
    cur_m: np.ndarray,
    dx: float,
    dy: float,
    *,
    cx: float,
    cy: float,
    max_deg: float = 5.0,
    step_deg: float = 0.5,
    crop: float = 0.80,
    hysteresis_deg: float = 5.0,
    frame_idx: int = -1,
    coarse_step_deg: float = 2.0,
    fine_window_deg: float = 3.0,
    log_cb=None,
    max_eval_size: int = 640,   # cap the working patch to this in each dimension
) -> tuple[float, float]:
    """
    Two-pass rotation search on a center-cropped patch at full resolution.
    Cropping to max_eval_size keeps warpAffine cost bounded without losing
    gradient detail — rotation is measured on real pixels, just fewer of them.
    """
    H, W = ref_m.shape[:2]

    # ---- Center crop both images to max_eval_size at full resolution ----
    # Crop is centered on (cx, cy) so the rotation center stays in the middle,
    # which is where rotation signal is most reliable anyway.
    if max(H, W) > max_eval_size:
        half = max_eval_size // 2
        # crop center, clamped to image bounds
        x0c = int(max(0, min(W - max_eval_size, int(round(cx)) - half)))
        y0c = int(max(0, min(H - max_eval_size, int(round(cy)) - half)))
        x1c = x0c + min(max_eval_size, W)
        y1c = y0c + min(max_eval_size, H)
        ref_work = ref_m[y0c:y1c, x0c:x1c].astype(np.float32, copy=False)
        cur_work = cur_m[y0c:y1c, x0c:x1c].astype(np.float32, copy=False)
        # rotation center in crop coords
        cx_work = float(cx) - x0c
        cy_work = float(cy) - y0c
        dx_work = float(dx)   # shift is still in full-frame pixels but
        dy_work = float(dy)   # warpAffine on the crop handles it correctly
    else:
        ref_work = ref_m.astype(np.float32, copy=False)
        cur_work = cur_m.astype(np.float32, copy=False)
        cx_work = float(cx)
        cy_work = float(cy)
        dx_work = float(dx)
        dy_work = float(dy)

    cur_shifted = _shift_image(cur_work, dx_work, dy_work)
    _, rgc, sl = _ssd_prepare_ref(ref_work, crop=crop)
    y0, y1, x0, x1 = sl

    hyst_steps = max(1, int(round(float(hysteresis_deg) / float(step_deg))))
    extended_max = float(max_deg) + hyst_steps * float(step_deg)

    # ------------------------------------------------------------------
    # Pass 1 — coarse scan
    # ------------------------------------------------------------------
    coarse_step = float(max(float(step_deg), float(coarse_step_deg)))
    coarse_angles = np.arange(-extended_max, extended_max + 1e-9, coarse_step)

    coarse_ssds: list[float] = []
    for ang in coarse_angles:
        rotated = _rotate_about(cur_shifted, cx_work, cy_work, float(ang))
        cg = _grad_img(rotated)
        cgc = cg[y0:y1, x0:x1]
        d = rgc - cgc
        coarse_ssds.append(float(np.mean(d * d)))

    coarse_arr = np.asarray(coarse_ssds, dtype=np.float32)
    coarse_best_idx = int(np.argmin(coarse_arr))
    coarse_best_ang = float(coarse_angles[coarse_best_idx])

    # ------------------------------------------------------------------
    # Pass 2 — fine scan around coarse minimum
    # ------------------------------------------------------------------
    fine_step = float(step_deg)
    fine_half = float(fine_window_deg) + hyst_steps * fine_step
    fine_lo = max(-extended_max, coarse_best_ang - fine_half)
    fine_hi = min(extended_max, coarse_best_ang + fine_half)

    angles = np.arange(fine_lo, fine_hi + 1e-9, fine_step)
    if len(angles) == 0:
        return 0.0, 0.0

    ssds: list[tuple[float, float]] = []
    for ang in angles:
        rotated = _rotate_about(cur_shifted, cx_work, cy_work, float(ang))
        cg = _grad_img(rotated)
        cgc = cg[y0:y1, x0:x1]
        d = rgc - cgc
        ssd = float(np.mean(d * d))
        ssds.append((float(ang), ssd))

    ssd_values = np.asarray([s for _, s in ssds], dtype=np.float32)
    angle_values = np.asarray([a for a, _ in ssds], dtype=np.float32)

    best_idx = int(np.argmin(ssd_values))
    best_ang = float(angle_values[best_idx])
    best_ssd = float(ssd_values[best_idx])

    # ------------------------------------------------------------------
    # Hysteresis check on fine pass
    # ------------------------------------------------------------------
    left_start = max(0, best_idx - hyst_steps)
    right_end = min(len(ssd_values) - 1, best_idx + hyst_steps)

    left_ok = True
    right_ok = True

    if best_idx > 0 and left_start < best_idx:
        left_ok = bool(np.all(ssd_values[left_start:best_idx] >= best_ssd))
    else:
        left_ok = False

    if best_idx < len(ssd_values) - 1 and right_end > best_idx:
        right_ok = bool(np.all(ssd_values[best_idx + 1:right_end + 1] >= best_ssd))
    else:
        right_ok = False

    left_edge_ssd = float(ssd_values[left_start]) if left_start < best_idx else best_ssd
    right_edge_ssd = float(ssd_values[right_end]) if right_end > best_idx else best_ssd
    ssd_range = float(np.max(ssd_values) - best_ssd)
    min_lift = max(1e-8, best_ssd * 0.002)

    hysteresis_confirmed = (
        left_ok and right_ok
        and (left_edge_ssd - best_ssd) >= min_lift
        and (right_edge_ssd - best_ssd) >= min_lift
    )

    if not hysteresis_confirmed:
        if log_cb is not None:
            log_cb(
                f"Frame {frame_idx:4d}  REJECTED  "
                f"best_ang={best_ang:+.3f}°  ssd_range={ssd_range:.6f}  "
                f"left_lift={left_edge_ssd - best_ssd:.6f}  right_lift={right_edge_ssd - best_ssd:.6f}"
            )
        return 0.0, 0.0

    # Subpixel quadratic polish
    ang_sub = 0.0
    if 0 < best_idx < len(ssd_values) - 1:
        vm = float(ssd_values[best_idx - 1])
        v0 = best_ssd
        vp = float(ssd_values[best_idx + 1])
        denom = vm - 2.0 * v0 + vp
        if abs(denom) > 1e-12:
            ang_sub = 0.5 * (vm - vp) / denom * fine_step
            ang_sub = float(np.clip(ang_sub, -fine_step * 0.75, fine_step * 0.75))

    best_ang_f = best_ang + ang_sub
    lift = min(left_edge_ssd - best_ssd, right_edge_ssd - best_ssd)
    conf = float(np.clip(lift / max(1e-6, best_ssd * 0.05), 0.0, 1.0))

    if log_cb is not None:
        log_cb(
            f"Frame {frame_idx:4d}  ang={best_ang_f:+7.3f}° "
            f"ssd_range={ssd_range:.6f}  "
        )

    return float(best_ang_f), float(conf)

def _ensure_source(source, cache_items: int = 10, *, flat=None) -> tuple[PlanetaryFrameSource, bool]:
    """
    Returns (src, owns_src)

    Accepts:
      - PlanetaryFrameSource-like object (duck typed: get_frame/meta/close)
      - path string
      - list/tuple of paths

    When ``flat`` is provided (numpy array), the returned source is
    wrapped in _CalibratedSource so every get_frame() call yields a
    flat-corrected frame.  The wrapper owns the same lifecycle as the
    inner source (owns_src flag applies to the wrapped object).
    """
    # Already an opened source-like object
    if source is not None and hasattr(source, "get_frame") and hasattr(source, "meta") and hasattr(source, "close"):
        # Don't double-wrap: if caller handed us a source that is already
        # a _CalibratedSource, honor its existing flat.
        if flat is not None and not isinstance(source, _CalibratedSource):
            return _CalibratedSource(source, flat), False
        return source, False

    # allow tuple -> list
    if isinstance(source, tuple):
        source = list(source)

    src = open_planetary_source(source, cache_items=cache_items)
    if flat is not None:
        src = _CalibratedSource(src, flat)
    return src, True

def stack_ser(
    source: str | list[str] | PlanetaryFrameSource,
    *,
    roi=None,
    debayer: bool = True,
    keep_percent: float = 20.0,
    track_mode: str = "planetary",
    surface_anchor=None,
    to_rgb: bool = False,
    bayer_pattern: Optional[str] = None,
    analysis: AnalyzeResult | None = None,
    max_dim: int = 512,
    progress_cb=None,
    cache_items: int = 10,
    workers: int | None = None,
    chunk_size: int | None = None,
    drizzle_scale: float = 1.0,
    drizzle_pixfrac: float = 0.80,
    drizzle_kernel: str = "gaussian",
    drizzle_sigma: float = 0.0,
    keep_mask=None,
    planet_pole_pa_deg: float | None = None,
    planet_axis_tilt_ba: float | None = None,
    planet_rot_deg_per_frame: float | None = None,
    planet_cx: float | None = None,
    planet_cy: float | None = None,
    planet_r: float | None = None,
    center_planet: bool = False,
) -> tuple[np.ndarray, dict]:
    source_obj = source

    # ---- Worker count ----
    if workers is None:
        cpu = os.cpu_count() or 4
        workers = max(1, min(cpu, 48))

    if cv2 is not None:
        try:
            cv2.setNumThreads(1)
        except Exception:
            pass

    # ---- Validate analysis ----
    if analysis is None or analysis.ref_image is None or analysis.ap_centers is None:
        raise ValueError("stack_ser expects analysis with ref_image + ap_centers (run Analyze first).")

    if getattr(analysis, "ang", None) is None:
        analysis.ang = np.zeros((int(analysis.frames_total),), dtype=np.float32)

    ref_img = analysis.ref_image.astype(np.float32, copy=False)
    planet_derotate = bool(getattr(analysis, "planet_derotate", False))
    flat = getattr(analysis, "flat", None)

    # ---- Planetary derotation params ----
    if planet_pole_pa_deg is None:
        planet_pole_pa_deg = float(getattr(analysis, "planet_pole_pa_deg", 0.0))
    if planet_axis_tilt_ba is None:
        planet_axis_tilt_ba = float(getattr(analysis, "planet_axis_tilt_ba", 1.0))
    if planet_rot_deg_per_frame is None:
        planet_rot_deg_per_frame = float(getattr(analysis, "planet_rot_deg_per_frame", 0.0))

    if planet_cx is None:
        planet_cx = float(getattr(analysis, "ref_cx", ref_img.shape[1] * 0.5))
    if planet_cy is None:
        planet_cy = float(getattr(analysis, "ref_cy", ref_img.shape[0] * 0.5))
    if planet_r is None:
        planet_r = float(min(ref_img.shape[0], ref_img.shape[1]) * 0.45)

    ba = float(np.clip(float(planet_axis_tilt_ba), 0.0, 1.0))
    subobs_lat_rad = float(np.arccos(ba)) if ba > 1e-8 else float(np.pi * 0.5)
    pole_angle_rad = float(np.deg2rad(float(planet_pole_pa_deg)))

    drizzle_scale = float(drizzle_scale)
    drizzle_on = drizzle_scale > 1.0001
    drizzle_pixfrac = float(drizzle_pixfrac)
    # Always gaussian — only kernel that avoids grid artifacts
    drizzle_kernel = "gaussian"
    drizzle_sigma = float(drizzle_sigma)

    # ---- Open once to get meta + first frame shape ----
    src0, owns0 = _ensure_source(source_obj, cache_items=cache_items, flat=flat)
    try:
        n = int(src0.meta.frames)
        keep_percent = max(0.1, min(100.0, float(keep_percent)))
        k = max(1, int(round(n * (keep_percent / 100.0))))

        order = np.asarray(analysis.order, np.int32)
        keep_idx = order[:k].astype(np.int32, copy=False)

        if keep_mask is not None:
            km = np.asarray(keep_mask, dtype=bool)
            if km.ndim != 1 or km.shape[0] != n:
                raise ValueError(f"keep_mask must be 1D bool of length {n}, got shape {km.shape}")
            keep_idx = keep_idx[km[keep_idx]]
            if keep_idx.size == 0:
                raise ValueError("keep_mask rejected all frames in the Keep% set.")
        # ── Quality weights ───────────────────────────────────────────────
        # analysis.quality already has the half-pedestal subtraction applied
        # in analyze_ser, so we use it directly as weights.
        # Build a per-frame-index lookup so _warp_chunk can pass the weight
        # back without any shared state.
        _q_all = analysis.quality.astype(np.float32, copy=False)
        _weight_for: dict[int, float] = {
            int(idx): max(float(_q_all[int(idx)]), 1e-6)
            for idx in keep_idx
        }

        ref_img = analysis.ref_image.astype(np.float32, copy=False)
        ref_m = _to_mono01(ref_img).astype(np.float32, copy=False)
        ap_centers_all = np.asarray(analysis.ap_centers, np.int32)
        ap_size = int(getattr(analysis, "ap_size", 64) or 64)
        use_multiscale = bool(getattr(analysis, "ap_multiscale", False))
        derot_ref_i = int(keep_idx[0])
        first = _get_frame(
            src0, int(keep_idx[0]),
            roi=roi, debayer=debayer, to_float01=True,
            force_rgb=bool(to_rgb),
            bayer_pattern=bayer_pattern
        )
        acc_shape = first.shape
    finally:
        if owns0:
            try:
                src0.close()
            except Exception:
                pass

    # ---- Progress (thread-safe) ----
    done_lock = threading.Lock()
    done_ct = 0
    total_ct = int(len(keep_idx))

    def _bump_progress(delta: int, phase: str = "Stack"):
        nonlocal done_ct
        if progress_cb is None:
            return
        with done_lock:
            done_ct += int(delta)
            d = done_ct
        progress_cb(d, total_ct, phase)

    # ---- Chunking ----
    idx_list = keep_idx.tolist()
    if chunk_size is None:
        chunk_size = max(8, int(np.ceil(len(idx_list) / float(workers * 2))))
    chunks: list[list[int]] = [idx_list[i:i + chunk_size] for i in range(0, len(idx_list), chunk_size)]

    if progress_cb:
        progress_cb(0, total_ct, "Stack")

    # ---- Drizzle setup ----
    if drizzle_on:
        from setiastro.saspro.legacy.numba_utils import (
            drizzle_deposit_kernel_mono_fast,
            drizzle_deposit_kernel_color_fast,
            finalize_drizzle_2d,
            finalize_drizzle_3d,
        )

        kernel_code = 2  # always gaussian

        if drizzle_sigma <= 1e-9:
            drizzle_sigma_eff = max(1e-3, float(drizzle_pixfrac) * 0.5)
        else:
            drizzle_sigma_eff = float(drizzle_sigma)

        H, W = int(acc_shape[0]), int(acc_shape[1])
        outH = int(round(H * drizzle_scale))
        outW = int(round(W * drizzle_scale))

        # Shared drizzle buffers — written serially on main thread, no locking needed
        if len(acc_shape) == 2:
            dbuf_total = np.zeros((outH, outW), dtype=np.float32)
            cbuf_total = np.zeros((outH, outW), dtype=np.float32)
        else:
            dbuf_total = np.zeros((outH, outW, acc_shape[2]), dtype=np.float32)
            cbuf_total = np.zeros((outH, outW, acc_shape[2]), dtype=np.float32)

        # Pre-allocate scratch tile ONCE — reused every frame, zero GC pressure.
        # Gaussian r = ceil(3 * sigma_out), sigma_out = sigma_eff * drizzle_scale
        _sigma_out_est = max(drizzle_sigma_eff * drizzle_scale, 1e-6)
        _r_est = int(np.ceil(3.0 * _sigma_out_est)) + 2  # +2 safety margin
        _tile_side = max(16, 2 * _r_est + 1)
        scratch = np.zeros((_tile_side, _tile_side), dtype=np.float32)
    # Surface rotation center for field rotation correction
    _surface_rot_cx: float | None = None
    _surface_rot_cy: float | None = None
    sa = getattr(analysis, "surface_anchor_rot_cx", None)
    if sa is not None:
        _surface_rot_cx = float(sa)
        _surface_rot_cy = float(getattr(analysis, "surface_anchor_rot_cy", ref_img.shape[0] * 0.5))
        
    # ---- Worker: aligns + warps, returns list of (warped, frac_dx, frac_dy) ----
    def _warp_chunk(chunk: list[int]) -> list[tuple[np.ndarray, float, float]]:
        src, owns = _ensure_source(source_obj, cache_items=0, flat=flat)
        results: list[tuple[np.ndarray, float, float]] = []
        try:
            for i in chunk:
                img = _get_frame(
                    src, int(i), roi=roi, debayer=debayer,
                    to_float01=True, force_rgb=bool(to_rgb),
                    bayer_pattern=bayer_pattern
                ).astype(np.float32, copy=False)
                img = _conform_to_ref_shape(img, ref_img.shape)

                gdx = float(analysis.dx[int(i)]) if analysis.dx is not None else 0.0
                gdy = float(analysis.dy[int(i)]) if analysis.dy is not None else 0.0

                # Global translation first
                warped_g = _shift_image(img, gdx, gdy)
                # Field rotation correction (about centroid for planetary,
                # surface anchor center for surface)
                ang_i = float(analysis.ang[int(i)]) if (
                    getattr(analysis, "ang", None) is not None
                    and analysis.ang is not None
                ) else 0.0

                if abs(ang_i) > 1e-6:
                    if track_mode == "planetary":
                        rot_cx = float(planet_cx)
                        rot_cy = float(planet_cy)
                    else:
                        rot_cx = float(ref_img.shape[1] * 0.5)
                        rot_cy = float(ref_img.shape[0] * 0.5)
                        # try to use surface anchor center
                        sa = getattr(analysis, "roi_used", None)
                        # surface_anchor is passed via stack_ser kwarg — add it
                        if _surface_rot_cx is not None:
                            rot_cx = _surface_rot_cx
                            rot_cy = _surface_rot_cy
                    warped_g = _rotate_about(warped_g, rot_cx, rot_cy, ang_i)
                # Planetary derotation (before local warp)
                if track_mode == "planetary" and planet_derotate and abs(planet_rot_deg_per_frame) > 1e-12:
                    dframes = float(int(i) - int(derot_ref_i))
                    dlon_rad = float(np.deg2rad(planet_rot_deg_per_frame * dframes))

                    if not hasattr(_warp_chunk, "_derot_precomp"):
                        _warp_chunk._derot_precomp = None
                    if _warp_chunk._derot_precomp is None:
                        Hh, Ww = warped_g.shape[:2]
                        _warp_chunk._derot_precomp = _build_lonlat_grids(
                            Hh, Ww, planet_cx, planet_cy, planet_r,
                            pole_angle_rad, subobs_lat_rad,
                        )
                    warped_g = derotate_stack_lonshift(
                        warped_g,
                        cx=planet_cx, cy=planet_cy, r=planet_r,
                        dlon_rad=dlon_rad,
                        pole_angle_rad=pole_angle_rad,
                        subobs_lat_rad=subobs_lat_rad,
                        border_value=0.0,
                        precomp=_warp_chunk._derot_precomp,
                    )

                # ── Atmospheric dispersion correction ─────────────────────
                # Apply per-channel (R/G/B) prismatic shift so all channels
                # are aligned to the G-channel centroid before the local warp.
                _disp_dx = getattr(analysis, "disp_dx", None)
                _disp_dy = getattr(analysis, "disp_dy", None)
                if (_disp_dx is not None
                        and warped_g.ndim == 3
                        and warped_g.shape[2] >= 3):
                    cdx = _disp_dx[int(i)]   # shape (3,)
                    cdy = _disp_dy[int(i)]
                    # Only correct R and B; G is the reference (shift = 0)
                    corrected = warped_g.copy()
                    for c_idx in (0, 2):
                        if abs(cdx[c_idx]) > 1e-6 or abs(cdy[c_idx]) > 1e-6:
                            corrected[:, :, c_idx] = _shift_image(
                                warped_g[:, :, c_idx],
                                float(cdx[c_idx]),
                                float(cdy[c_idx]),
                            )
                    warped_g = corrected

                # ---- Local AP warp — always, for both planetary and surface ----
                # After global translation (and derotation if planetary), compute
                # per-AP residual shifts and build a dense displacement field.
                # This corrects differential seeing across the disc/surface.
                if cv2 is not None and ap_centers_all is not None and len(ap_centers_all) > 0:
                    cur_m_g = _to_mono01(warped_g).astype(np.float32, copy=False)

                    if use_multiscale:
                        # Compute per-AP shifts at multiple scales and combine
                        s2, s1, s05 = _scaled_ap_sizes(ap_size)

                        def _per_ap_one_scale(s_ap: int):
                            rdx, rdy, resp = _ap_phase_shifts_per_ap(
                                ref_m, cur_m_g,
                                ap_centers=ap_centers_all,
                                ap_size=s_ap,
                                max_dim=max_dim,
                            )
                            return rdx, rdy, np.clip(resp.astype(np.float32, copy=False), 0.0, 1.0)

                        rdx2, rdy2, cf2 = _per_ap_one_scale(s2)
                        rdx1, rdy1, cf1 = _per_ap_one_scale(s1)
                        rdx0, rdy0, cf0 = _per_ap_one_scale(s05)

                        # Weighted combination per AP
                        w2 = np.maximum(cf2, 1e-3) * 1.25
                        w1 = np.maximum(cf1, 1e-3) * 1.00
                        w0 = np.maximum(cf0, 1e-3) * 0.85
                        wsum = w2 + w1 + w0

                        ap_rdx = (w2 * rdx2 + w1 * rdx1 + w0 * rdx0) / wsum
                        ap_rdy = (w2 * rdy2 + w1 * rdy1 + w0 * rdy0) / wsum
                        ap_cf  = np.clip((w2 * cf2 + w1 * cf1 + w0 * cf0) / wsum, 0.0, 1.0)
                    else:
                        ap_rdx, ap_rdy, ap_resp = _ap_phase_shifts_per_ap(
                            ref_m, cur_m_g,
                            ap_centers=ap_centers_all,
                            ap_size=ap_size,
                            max_dim=max_dim,
                        )
                        ap_cf = np.clip(ap_resp.astype(np.float32, copy=False), 0.0, 1.0)

                    keep = _reject_ap_outliers(ap_rdx, ap_rdy, ap_cf, z=3.5)
                    if np.any(keep):
                        dx_field, dy_field = _dense_field_from_ap_shifts(
                            warped_g.shape[0], warped_g.shape[1],
                            ap_centers_all[keep], ap_rdx[keep], ap_rdy[keep], ap_cf[keep],
                            grid=32, power=2.0, conf_floor=0.15,
                            radius=float(ap_size) * 3.0,
                        )
                        warped = _warp_by_dense_field(warped_g, dx_field, dy_field)
                    else:
                        warped = warped_g
                else:
                    warped = warped_g

                frac_dx = float(gdx) - round(float(gdx))
                frac_dy = float(gdy) - round(float(gdy))

                if track_mode == "surface" or (drizzle_on and center_planet):
                    rng = np.random.default_rng(seed=int(i))
                    dither = rng.uniform(-0.45, 0.45, size=2)
                    frac_dx += float(dither[0])
                    frac_dy += float(dither[1])

                results.append((warped, frac_dx, frac_dy, int(i)))

        finally:
            if owns:
                try:
                    src.close()
                except Exception:
                    pass

        _bump_progress(len(chunk), "Warp" if not drizzle_on else "Align")
        return results

    # ---- Parallel warp → serial drizzle (avoids numba GIL contention + allocation storm) ----
    if drizzle_on:
        drizzle_done = 0
        drizzle_total = int(len(keep_idx))
        if progress_cb:
            progress_cb(0, drizzle_total, "Drizzle")

        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(_warp_chunk, c) for c in chunks if c]
            for fut in as_completed(futs):
                for warped, frac_dx, frac_dy, frame_idx in fut.result():
                    w = _weight_for.get(int(frame_idx), 1.0)
 
                    T_frame = np.zeros((2, 3), dtype=np.float32)
                    T_frame[0, 0] = 1.0
                    T_frame[1, 1] = 1.0
                    T_frame[0, 2] = frac_dx
                    T_frame[1, 2] = frac_dy
 
                    if warped.ndim == 2:
                        drizzle_deposit_kernel_mono_fast(
                            warped, T_frame, dbuf_total, cbuf_total,
                            drizzle_factor=drizzle_scale,
                            drop_shrink=drizzle_pixfrac,
                            frame_weight=w,
                            kernel_code=kernel_code,
                            gaussian_sigma_or_radius=drizzle_sigma_eff,
                            scratch=scratch,
                        )
                    else:
                        drizzle_deposit_kernel_color_fast(
                            warped, T_frame, dbuf_total, cbuf_total,
                            drizzle_factor=drizzle_scale,
                            drop_shrink=drizzle_pixfrac,
                            frame_weight=w,
                            kernel_code=kernel_code,
                            gaussian_sigma_or_radius=drizzle_sigma_eff,
                            scratch=scratch,
                        )
 
                    drizzle_done += 1
                    if progress_cb:
                        progress_cb(drizzle_done, drizzle_total, "Drizzle")


        if len(acc_shape) == 2:
            out = np.zeros((outH, outW), dtype=np.float32)
            finalize_drizzle_2d(dbuf_total, cbuf_total, out)
        else:
            out = np.zeros((outH, outW, acc_shape[2]), dtype=np.float32)
            finalize_drizzle_3d(dbuf_total, cbuf_total, out)

        out = np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)

    else:
        # Non-drizzle: parallel warp + quality-weighted serial accumulate
        acc_total  = np.zeros(acc_shape, dtype=np.float32)
        wacc_total = 0.0
 
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(_warp_chunk, c) for c in chunks if c]
            for fut in as_completed(futs):
                for warped, _fdx, _fdy, frame_idx in fut.result():
                    w = _weight_for.get(int(frame_idx), 1.0)
                    acc_total  += warped * w
                    wacc_total += w
 
        out = np.clip(acc_total / max(1e-6, wacc_total), 0.0, 1.0).astype(np.float32, copy=False)


    diag = {
        "frames_total": int(n),
        "frames_kept": int(len(keep_idx)),
        "roi_used": roi,
        "track_mode": track_mode,
        "local_warp": True,  # always on
        "use_multiscale": use_multiscale,
        "workers": int(workers),
        "chunk_size": int(chunk_size),
        "drizzle_scale": float(drizzle_scale),
        "drizzle_pixfrac": float(drizzle_pixfrac),
        "drizzle_kernel": str(drizzle_kernel),
        "drizzle_sigma": float(drizzle_sigma),
    }
    return out, diag

def _build_reference(
    src: PlanetaryFrameSource,
    *,
    order: np.ndarray,
    roi,
    debayer: bool,
    to_rgb: bool,
    ref_mode: str,
    ref_count: int,
    bayer_pattern=None,
) -> np.ndarray:
    """
    ref_mode:
      - "best_frame": return best single frame
      - "best_stack": return mean of best ref_count frames
    """
    best_idx = int(order[0])
    f0 = _get_frame(src, best_idx, roi=roi, debayer=debayer, to_float01=True, force_rgb=bool(to_rgb), bayer_pattern=bayer_pattern)
    if ref_mode != "best_stack" or ref_count <= 1:
        return f0.astype(np.float32, copy=False)

    k = int(max(2, min(ref_count, len(order))))
    acc = np.zeros_like(f0, dtype=np.float32)
    for j in range(k):
        idx = int(order[j])
        fr = _get_frame(src, idx, roi=roi, debayer=debayer, to_float01=True, force_rgb=bool(to_rgb), bayer_pattern=bayer_pattern)
        fr = _conform_to_ref_shape(fr, f0.shape)
        acc += fr.astype(np.float32, copy=False)
    ref = acc / float(k)
    return np.clip(ref, 0.0, 1.0).astype(np.float32, copy=False)


def _load_flat_from_cfg(cfg, source_obj, *, debayer, to_rgb, bayer_pattern,
                        log_cb=None, progress_cb=None):
    """
    Returns a normalised flat (np.ndarray) if cfg has flat calibration
    enabled AND a valid flat_path, else None.

    Reads the following optional attrs off cfg (all via getattr so old cfgs
    still work):
        flat_enabled : bool
        flat_path    : str
        flat_stack_method : "median" | "mean"  (SER video flats only)
    """
    if not bool(getattr(cfg, "flat_enabled", False)):
        return None
    flat_path = getattr(cfg, "flat_path", None)
    if not flat_path:
        return None

    #sasprobe the source at full frame so the flat matches what get_frame
    # (roi=None) will return in this run.  flat=None here on purpose — we're
    # loading the flat, not applying one.
    src_p, owns_p = _ensure_source(source_obj, cache_items=1, flat=None)
    try:
        first = _get_frame(
            src_p, 0, roi=None, debayer=bool(debayer),
            to_float01=True, force_rgb=bool(to_rgb),
            bayer_pattern=bayer_pattern,
        )
        frame_shape = tuple(first.shape)
    finally:
        if owns_p:
            try:
                src_p.close()
            except Exception:
                pass

    method = str(getattr(cfg, "flat_stack_method", "median")).lower() or "median"

    if log_cb:
        log_cb(f"Flat: loading {os.path.basename(str(flat_path))} "
               f"(method={method}, target={frame_shape})")
    return _load_flat_for_run(
        str(flat_path),
        frame_shape=frame_shape,
        debayer=bool(debayer),
        force_rgb=bool(to_rgb),
        bayer_pattern=bayer_pattern,
        ser_stack_method=method,
        progress_cb=progress_cb,
        log_cb=log_cb,
    )


def _cfg_get_source(cfg) -> Any:
    """
    Back-compat: prefer cfg.source (new), else cfg.ser_path (old).
    cfg.source may be:
      - path string (ser/avi/mp4/etc)
      - list of image paths
      - PlanetaryFrameSource
    """
    src = getattr(cfg, "source", None)
    if src is not None and src != "":
        return src
    return getattr(cfg, "ser_path", None)


def _quality_score(m: np.ndarray) -> float:
    """
    Quality metric for a single downsampled mono frame (float32, 0..1).
 
    Two components, both computed only over pixels with signal > 0.05
    (excludes black background around the planetary disc / empty sky):
 
    1. Sharpness  — variance of the Laplacian within the signal mask.
                    Variance punishes frames where sharpness is spatially
                    inconsistent (e.g. half the disc in focus, half not),
                    unlike mean-abs which can be fooled by a few bright edges.
 
    2. Feature richness — fraction of signal-mask pixels whose gradient
                    magnitude exceeds a threshold (75th percentile of the
                    in-mask gradient).  Rewards frames that have lots of
                    visible fine structure, not just a sharp limb edge.
 
    Final score = 0.70 * sharpness_norm + 0.30 * richness
 
    Both components are individually normalised to [0, 1] via a soft
    log-scale so extreme outliers don't dominate.  The raw score is
    returned un-clamped so the caller can decide on normalisation across
    the frame set (scores are comparable within a single clip).
    """
    m = np.asarray(m, dtype=np.float32)
 
    # ── Signal mask: exclude background and hot pixels ───────────────────
    SIGNAL_FLOOR = 0.05
    mask = m > SIGNAL_FLOOR          # bool (H, W)
    n_sig = int(np.count_nonzero(mask))
 
    if n_sig < 16 or cv2 is None:
        # Fallback: simple finite-difference gradient mean (cv2 unavailable
        # or frame is essentially empty)
        gx = float(np.abs(m[:, 1:] - m[:, :-1]).mean())
        gy = float(np.abs(m[1:, :] - m[:-1, :]).mean())
        return float(gx + gy)
 
    # ── Laplacian (ksize=5 is slightly more noise-resistant than 3) ──────
    lap = cv2.Laplacian(m, cv2.CV_32F, ksize=5)
 
    lap_sig = lap[mask]              # values inside the signal region only
 
    # Variance of Laplacian — the primary sharpness measure.
    # A perfectly sharp frame has high, consistent edge responses → high var.
    # A blurry frame has small, uniform Laplacian → low var.
    # A noisy-but-soft frame has moderate random values → moderate var.
    sharpness = float(np.var(lap_sig))
 
    # ── Gradient magnitude for feature richness ──────────────────────────
    gx = cv2.Sobel(m, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(m, cv2.CV_32F, 0, 1, ksize=3)
    gmag = cv2.magnitude(gx, gy)    # (H, W)
 
    gmag_sig = gmag[mask]
 
    # Richness = fraction of signal pixels with gradient above the 75th
    # percentile of the in-mask gradient distribution.
    # This rewards frames with lots of fine structure uniformly spread
    # across the disc, not just a sharp limb or a single bright feature.
    p75 = float(np.percentile(gmag_sig, 75))
    if p75 < 1e-9:
        richness = 0.0
    else:
        richness = float(np.mean(gmag_sig > p75))
        # Note: by definition this is always ~0.25 for a uniform dist,
        # but real data varies because the threshold is absolute within the
        # mask — frames with more fine detail will have more pixels above
        # the 75th percentile of *their own* distribution... actually we
        # want a fixed threshold, not percentile-within-frame.
        # Use mean gradient magnitude as a more discriminating richness:
        richness = float(np.mean(gmag_sig)) / max(1e-9, float(gmag_sig.max()))
 
    # ── Combine ──────────────────────────────────────────────────────────
    # Sharpness is on an arbitrary scale (variance of Laplacian of a
    # float32 image).  Apply log1p so the metric doesn't compress the
    # distribution at the top end when one exceptional frame is much
    # sharper than the rest.
    sharpness_log = float(np.log1p(sharpness * 1e4))   # scale factor keeps
                                                         # typical values in
                                                         # a comfortable range
 
    # richness is already in [0, 1]
    q = 0.70 * sharpness_log + 0.30 * richness
 
    return float(q)


def analyze_ser(
    cfg: SERStackConfig,
    *,
    debayer: bool = True,
    to_rgb: bool = False,
    smooth_sigma: float = 1.5,
    thresh_pct: float = 92.0,
    ref_mode: str = "best_frame",
    bayer_pattern: Optional[str] = None,
    ref_count: int = 5,
    max_dim: int = 512,
    progress_cb=None,
    workers: Optional[int] = None,
    log_cb=None, 
) -> AnalyzeResult:

    source_obj = _cfg_get_source(cfg)
    bpat = bayer_pattern or _cfg_bayer_pattern(cfg)

    if not source_obj:
        raise ValueError("SERStackConfig.source/ser_path is empty")

    # === SASpro flat hotfix v1: pre-initialize flat ===
    flat = None  # populated below by _load_flat_from_cfg; declared here
                 # so the metadata probe and early-return paths never hit
                 # an UnboundLocalError on flat=flat.

    src0, owns0 = _ensure_source(source_obj, cache_items=2, flat=flat)
    try:
        meta = src0.meta
        base_roi = cfg.roi
        if base_roi is not None:
            base_roi = _clamp_roi_in_bounds(base_roi, meta.width, meta.height)
        n = int(meta.frames)
        if n <= 0:
            raise ValueError("Source contains no frames")
        src_w = int(meta.width)
        src_h = int(meta.height)
    finally:
        if owns0:
            try:
                src0.close()
            except Exception:
                pass

    # ---- Flat-field calibration (optional; noop if cfg.flat_enabled is False)
    try:
        flat = _load_flat_from_cfg(
            cfg, source_obj,
            debayer=debayer, to_rgb=to_rgb, bayer_pattern=bpat,
            log_cb=log_cb, progress_cb=progress_cb,
        )
    except Exception as _flat_err:
        if log_cb:
            log_cb(f"Flat: FAILED to load — proceeding uncalibrated ({_flat_err})")
        flat = None

    if workers is None:
        cpu = os.cpu_count() or 4
        workers = max(1, min(cpu, 48))

    if cv2 is not None:
        try:
            cv2.setNumThreads(1)
        except Exception:
            pass

    def _surface_tracking_roi() -> Optional[Tuple[int, int, int, int]]:
        if base_roi is None:
            return None
        margin = int(getattr(cfg, "surface_track_margin", 256))
        x, y, w, h = [int(v) for v in base_roi]
        x0 = max(0, x - margin)
        y0 = max(0, y - margin)
        x1 = min(src_w, x + w + margin)
        y1 = min(src_h, y + h + margin)
        return _clamp_roi_in_bounds((x0, y0, x1 - x0, y1 - y0), src_w, src_h)

    roi_track = _surface_tracking_roi() if cfg.track_mode == "surface" else base_roi
    roi_used = base_roi

    # ---- Pass 1: quality ----
    quality = np.zeros((n,), dtype=np.float32)
    idxs = np.arange(n, dtype=np.int32)
    n_chunks = max(5, int(workers) * int(getattr(cfg, "progress_chunk_factor", 5)))
    n_chunks = max(1, min(int(n), n_chunks))
    chunks = np.array_split(idxs, n_chunks)

    if progress_cb:
        progress_cb(0, n, "Quality")

    def _q_chunk(chunk: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        out_i: list[int] = []
        out_q: list[float] = []
        src, owns = _ensure_source(source_obj, cache_items=0, flat=flat)
        try:
            for i in chunk.tolist():
                img = _get_frame(src, int(i), roi=roi_used, debayer=debayer,
                                 to_float01=True, force_rgb=bool(to_rgb), bayer_pattern=bpat)
                m = _downsample_mono01(img, max_dim=max_dim)
                q = _quality_score(m)
                out_i.append(int(i))
                out_q.append(q)
        finally:
            if owns:
                try:
                    src.close()
                except Exception:
                    pass
        return np.asarray(out_i, np.int32), np.asarray(out_q, np.float32)

    done_ct = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = [ex.submit(_q_chunk, c) for c in chunks if c.size > 0]
        for fut in as_completed(futs):
            ii, qq = fut.result()
            quality[ii] = qq
            done_ct += int(ii.size)
            if progress_cb:
                progress_cb(done_ct, n, "Quality")

    # ── Half-pedestal subtraction ─────────────────────────────────────
    # Subtract half the minimum score from all frames.
    # This removes the DC offset / pedestal that the log1p scaling
    # introduces, broadening the relative spread so that score
    # differences are more proportionally meaningful.
    # The adjusted scores are stored back into quality so the graph,
    # keep% ordering, and weighted stacking all see the same values.
    _q_min = float(quality.min())
    quality -= _q_min * 0.5
    quality  = np.maximum(quality, 0.0).astype(np.float32)


    order = np.argsort(-quality).astype(np.int32, copy=False)

    # ---- Build reference ----
    ref_count = int(max(1, min(int(ref_count), n)))
    ref_mode = "best_stack" if ref_mode == "best_stack" else "best_frame"

    src_ref, owns_ref = _ensure_source(source_obj, cache_items=2, flat=flat)
    if progress_cb:
        progress_cb(0, n, f"Building reference ({ref_mode}, N={ref_count})…")
    try:
        if cfg.track_mode == "surface":
            ref_img = _get_frame(src_ref, 0, roi=roi_used, debayer=debayer,
                                 to_float01=True, force_rgb=bool(to_rgb),
                                 bayer_pattern=bpat).astype(np.float32, copy=False)
            ref_mode = "first_frame"
            ref_count = 1
        else:
            ref_img = _build_reference(src_ref, order=order, roi=roi_used,
                                       debayer=debayer, to_rgb=to_rgb,
                                       ref_mode=ref_mode, ref_count=ref_count,
                                       bayer_pattern=bpat).astype(np.float32, copy=False)
    finally:
        if owns_ref:
            try:
                src_ref.close()
            except Exception:
                pass

    # ---- Autoplace APs ----
    if progress_cb:
        progress_cb(0, n, "Placing alignment points…")

    ap_size = int(getattr(cfg, "ap_size", 64) or 64)
    ap_centers = _autoplace_aps(
        ref_img,
        ap_size=ap_size,
        ap_spacing=int(getattr(cfg, "ap_spacing", 48)),
        ap_min_mean=float(getattr(cfg, "ap_min_mean", 0.03)),
    )

    # ---- Pass 2: shifts ----
    dx = np.zeros((n,), dtype=np.float32)
    dy = np.zeros((n,), dtype=np.float32)
    conf = np.ones((n,), dtype=np.float32)
    coarse_conf: Optional[np.ndarray] = None
    ang = np.zeros((n,), dtype=np.float32)
    ang_conf = np.zeros((n,), dtype=np.float32)
    correct_disp = bool(getattr(cfg, "correct_atm_dispersion", False))
    disp_dx = np.zeros((n, 3), dtype=np.float32)   # per-frame R/G/B dx
    disp_dy = np.zeros((n, 3), dtype=np.float32)   # per-frame R/G/B dy

    if cfg.track_mode == "off" or cv2 is None:
        return AnalyzeResult(
            frames_total=n, roi_used=roi_used, track_mode=cfg.track_mode,
            quality=quality, dx=dx, dy=dy, conf=conf, order=order,
            ref_mode=ref_mode, ref_count=ref_count, ref_image=ref_img,
            ap_centers=ap_centers, ap_size=ap_size,
            ap_multiscale=bool(getattr(cfg, "ap_multiscale", False)),
            coarse_conf=None,
            flat=flat,
        )

    ref_m_full = _to_mono01(ref_img).astype(np.float32, copy=False)
    use_multiscale = bool(getattr(cfg, "ap_multiscale", False))
    correct_rot = bool(getattr(cfg, "correct_field_rotation", False))
    rot_max = float(getattr(cfg, "field_rotation_max_deg", 5.0))
    rot_step = float(getattr(cfg, "field_rotation_step_deg", 0.5))

    # ---- Surface coarse drift ----
    if cfg.track_mode == "surface":
        coarse_conf = np.zeros((n,), dtype=np.float32)
        if progress_cb:
            progress_cb(0, n, "Surface: coarse drift (ref-locked NCC+subpix)…")

        dx_chain, dy_chain, cc_chain = _coarse_surface_ref_locked(
            source_obj, n=n, roi=roi_track, roi_used=roi_used,
            debayer=debayer, to_rgb=to_rgb, bayer_pattern=bpat,
            progress_cb=progress_cb, progress_every=25,
            down=2, template_size=256, search_radius=96, bandpass=True,
            workers=min(workers, 8), stride=16,
            flat=flat,
        )
        dx[:] = dx_chain
        dy[:] = dy_chain
        coarse_conf[:] = cc_chain

    # ---- Surface rotation center ----
    surface_anchor_rot_cx: Optional[float] = None
    surface_anchor_rot_cy: Optional[float] = None
    if cfg.track_mode == "surface" and correct_rot:
        sa = getattr(cfg, "surface_anchor", None)
        if sa is not None:
            try:
                ax, ay, aw, ah = [int(v) for v in sa]
                surface_anchor_rot_cx = float(ax + aw * 0.5)
                surface_anchor_rot_cy = float(ay + ah * 0.5)
            except Exception:
                pass
        if surface_anchor_rot_cx is None:
            surface_anchor_rot_cx = float(ref_img.shape[1] * 0.5)
            surface_anchor_rot_cy = float(ref_img.shape[0] * 0.5)

    # ---- Chunked refine ----
    idxs2 = np.arange(n, dtype=np.int32)
    chunk_factor = int(getattr(cfg, "progress_chunk_factor", 5))
    n_chunks2 = max(5, int(workers) * chunk_factor)
    n_chunks2 = max(1, min(int(n), n_chunks2))
    chunks2 = np.array_split(idxs2, n_chunks2)

    if progress_cb:
        progress_cb(0, n, "SSD Refine")

    if cfg.track_mode == "surface":
        def _shift_chunk(chunk: np.ndarray):
            out_i: list[int] = []
            out_dx: list[float] = []
            out_dy: list[float] = []
            out_cf: list[float] = []
            out_ang: list[float] = []
            out_acf: list[float] = []

            src, owns = _ensure_source(source_obj, cache_items=0, flat=flat)
            try:
                for i in chunk.tolist():
                    img = _get_frame(src, int(i), roi=roi_used, debayer=debayer,
                                     to_float01=True, force_rgb=bool(to_rgb), bayer_pattern=bpat)
                    img = _conform_to_ref_shape(img, ref_img.shape)
                    cur_m = _to_mono01(img).astype(np.float32, copy=False)

                    coarse_dx = float(dx[int(i)])
                    coarse_dy = float(dy[int(i)])
                    cc_i = float(coarse_conf[int(i)]) if coarse_conf is not None else 0.5

                    cur_m_g = _shift_image(cur_m, coarse_dx, coarse_dy)

                    if use_multiscale:
                        s2, s1, s05 = _scaled_ap_sizes(ap_size)

                        def _one_scale(s_ap: int):
                            rdx, rdy, resp = _ap_phase_shifts_per_ap(
                                ref_m_full, cur_m_g, ap_centers=ap_centers,
                                ap_size=s_ap, max_dim=max_dim)
                            cf = np.clip(resp.astype(np.float32, copy=False), 0.0, 1.0)
                            keep = _reject_ap_outliers(rdx, rdy, cf, z=3.5)
                            if not np.any(keep):
                                return 0.0, 0.0, 0.25
                            return (float(np.median(rdx[keep])),
                                    float(np.median(rdy[keep])),
                                    float(np.median(cf[keep])))

                        dx2, dy2, cf2 = _one_scale(s2)
                        dx1, dy1, cf1 = _one_scale(s1)
                        dx0, dy0, cf0 = _one_scale(s05)
                        w2 = max(1e-3, float(cf2)) * 1.25
                        w1 = max(1e-3, float(cf1)) * 1.00
                        w0 = max(1e-3, float(cf0)) * 0.85
                        wsum = w2 + w1 + w0
                        dx_res = (w2 * dx2 + w1 * dx1 + w0 * dx0) / wsum
                        dy_res = (w2 * dy2 + w1 * dy1 + w0 * dy0) / wsum
                        cf_ap = float(np.clip((w2 * cf2 + w1 * cf1 + w0 * cf0) / wsum, 0.0, 1.0))
                    else:
                        rdx, rdy, resp = _ap_phase_shifts_per_ap(
                            ref_m_full, cur_m_g, ap_centers=ap_centers,
                            ap_size=ap_size, max_dim=max_dim)
                        cf = np.clip(resp.astype(np.float32, copy=False), 0.0, 1.0)
                        keep = _reject_ap_outliers(rdx, rdy, cf, z=3.5)
                        if np.any(keep):
                            dx_res = float(np.median(rdx[keep]))
                            dy_res = float(np.median(rdy[keep]))
                            cf_ap = float(np.median(cf[keep]))
                        else:
                            dx_res, dy_res, cf_ap = 0.0, 0.0, 0.25

                    dx_i = float(coarse_dx + dx_res)
                    dy_i = float(coarse_dy + dy_res)

                    dxr, dyr, c_ssd = _refine_shift_ssd(
                        ref_m_full, cur_m, dx_i, dy_i, radius=5, crop=0.80,
                        bruteforce=bool(getattr(cfg, "ssd_refine_bruteforce", False)))
                    dx_i += float(dxr)
                    dy_i += float(dyr)

                    cf_i = float(np.clip(0.60 * cc_i + 0.40 * float(cf_ap), 0.0, 1.0))
                    cf_i = float(np.clip(0.85 * cf_i + 0.15 * float(c_ssd), 0.05, 1.0))

                    # Field rotation — always runs when checkbox checked, no conf gate
                    ang_i = 0.0
                    ang_cf_i = 0.0
                    if correct_rot:
                        rot_cx = float(surface_anchor_rot_cx) if surface_anchor_rot_cx is not None else float(ref_m_full.shape[1] * 0.5)
                        rot_cy = float(surface_anchor_rot_cy) if surface_anchor_rot_cy is not None else float(ref_m_full.shape[0] * 0.5)
                        ang_i, ang_cf_i = _find_best_rotation_ssd(
                            ref_m_full, cur_m, dx_i, dy_i,
                            cx=rot_cx, cy=rot_cy,
                            max_deg=rot_max, step_deg=rot_step, crop=0.80,
                            frame_idx=int(i),
                            log_cb=log_cb,)

                    out_i.append(int(i))
                    out_dx.append(dx_i)
                    out_dy.append(dy_i)
                    out_cf.append(cf_i)
                    out_ang.append(ang_i)
                    out_acf.append(ang_cf_i)

            finally:
                if owns:
                    try:
                        src.close()
                    except Exception:
                        pass

            return (np.asarray(out_i, np.int32), np.asarray(out_dx, np.float32),
                    np.asarray(out_dy, np.float32), np.asarray(out_cf, np.float32),
                    np.asarray(out_ang, np.float32), np.asarray(out_acf, np.float32))

    else:
        # planetary tracking
        tracker = PlanetaryTracker(
            smooth_sigma=float(getattr(cfg, "planet_smooth_sigma", 1.5)),
            simple_thresh=float(getattr(cfg, "planet_simple_thresh", 0.5)),
        )

        ref_cx, ref_cy, ref_cc = tracker.compute_center(ref_img)
        if ref_cc <= 0.0:
            mref = _to_mono01(ref_img)
            ref_cx = float(mref.shape[1] * 0.5)
            ref_cy = float(mref.shape[0] * 0.5)

        ref_m_full = _to_mono01(ref_img).astype(np.float32, copy=False)

        center_on_planet = bool(getattr(cfg, "center_on_planet", False))
        if center_on_planet:
            ref_center = (float(ref_m_full.shape[1] * 0.5), float(ref_m_full.shape[0] * 0.5))
        else:
            ref_center = (float(ref_cx), float(ref_cy))

        planet_derotate = bool(getattr(cfg, "planet_derotate", False))

        def _shift_chunk(chunk: np.ndarray):
            out_i = []
            out_dx = []
            out_dy = []
            out_cf = []
            out_ang = []
            out_acf = []
            out_cdx: list[np.ndarray] = []
            out_cdy: list[np.ndarray] = []

            src, owns = _ensure_source(source_obj, cache_items=0, flat=flat)
            try:
                for i in chunk.tolist():
                    img = _get_frame(src, int(i), roi=roi_used, debayer=debayer,
                                     to_float01=True, force_rgb=bool(to_rgb), bayer_pattern=bpat)
                    img = _conform_to_ref_shape(img, ref_img.shape)

                    dx_i, dy_i, cf_i = tracker.shift_to_ref(img, ref_center)
                    ang_i = 0.0
                    ang_cf_i = 0.0

                    # Always compute cur_m — needed for both SSD refine and rotation search
                    cur_m = _to_mono01(img).astype(np.float32, copy=False)

                    # SSD refine gated on centroid confidence
                    if float(cf_i) >= 0.25:
                        dxr, dyr, c_ssd = _refine_shift_ssd(
                            ref_m_full, cur_m, dx_i, dy_i, radius=5, crop=0.80,
                            bruteforce=bool(getattr(cfg, "ssd_refine_bruteforce", False)))
                        dx_i += dxr
                        dy_i += dyr
                        cf_i = float(np.clip(0.85 * float(cf_i) + 0.15 * c_ssd, 0.05, 1.0))

                    # ── Atmospheric dispersion correction ─────────────────
                    # Split into R/G/B, find each channel's centroid relative
                    # to G, store the per-channel shift for use in _warp_chunk.
                    cdx_i = np.zeros(3, dtype=np.float32)
                    cdy_i = np.zeros(3, dtype=np.float32)
                    if correct_disp and img.ndim == 3 and img.shape[2] >= 3:
                        # Apply global shift first so centroid is on-disc
                        img_shifted = _shift_image(img, float(dx_i), float(dy_i))
                        cdx_i, cdy_i = _channel_centroid_shifts(
                            img_shifted, tracker, float(ref_cx), float(ref_cy))


                    # Field rotation — gated only on the checkbox, NOT on centroid confidence.
                    # Has its own internal hysteresis quality gate.
                    if correct_rot:
                        ang_i, ang_cf_i = _find_best_rotation_ssd(
                            ref_m_full, cur_m, dx_i, dy_i,
                            cx=float(ref_cx), cy=float(ref_cy),
                            max_deg=rot_max, step_deg=rot_step, crop=0.80,
                            frame_idx=int(i),
                            log_cb=log_cb,)
                    elif planet_derotate:
                        if float(cf_i) >= 0.25:
                            a_i, a_cf = _estimate_rotation_fm(ref_m_full, cur_m, max_dim=max_dim)
                            if float(a_cf) > 0.15:
                                ang_i = float(a_i)
                                ang_cf_i = float(a_cf)

                    out_i.append(int(i))
                    out_dx.append(float(dx_i))
                    out_dy.append(float(dy_i))
                    out_cf.append(float(cf_i))
                    out_ang.append(float(ang_i))
                    out_acf.append(float(ang_cf_i))
                    out_cdx.append(cdx_i)
                    out_cdy.append(cdy_i)


            finally:
                if owns:
                    try:
                        src.close()
                    except Exception:
                        pass

            return (np.asarray(out_i, np.int32),
                    np.asarray(out_dx,  np.float32),
                    np.asarray(out_dy,  np.float32),
                    np.asarray(out_cf,  np.float32),
                    np.asarray(out_ang, np.float32),
                    np.asarray(out_acf, np.float32),
                    np.stack(out_cdx, axis=0).astype(np.float32),   # (chunk, 3)
                    np.stack(out_cdy, axis=0).astype(np.float32))

    done_ct = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = [ex.submit(_shift_chunk, c) for c in chunks2 if c.size > 0]
        for fut in as_completed(futs):
            if cfg.track_mode == "surface":
                ii, ddx, ddy, ccf, aang, acf = fut.result()
            else:
                ii, ddx, ddy, ccf, aang, acf, ccdx, ccdy = fut.result()
                if correct_disp:
                    disp_dx[ii] = ccdx
                    disp_dy[ii] = ccdy
            dx[ii]       = ddx
            dy[ii]       = ddy
            conf[ii]     = np.clip(ccf, 0.05, 1.0)
            ang[ii]      = aang
            ang_conf[ii] = acf
            done_ct += int(ii.size)
            if progress_cb:
                progress_cb(done_ct, n, "SSD Refine")

    # ---- Penalize rotation-rejected frames ----
    # ang_cf == 0.0 means hysteresis failed (rejected) — NOT a genuine measurement.
    # The reference frame genuinely measures 0° but still gets ang_cf > 0.
    # Zero out quality for rejected frames so they sort to the end of keep% ordering.
    if correct_rot:
        rejected_mask = (np.abs(ang_conf) < 1e-9)  # ang_cf == 0.0
        rejected_mask[int(order[0])] = False        # never penalize the reference frame
        n_rejected = int(np.count_nonzero(rejected_mask))
        if n_rejected > 0:
            quality[rejected_mask] = 0.0
            order[:] = np.argsort(-quality).astype(np.int32, copy=False)
            if log_cb is not None:
                log_cb(f"Rotation: {n_rejected} frames rejected (flat curve) — moved to end of quality order.")

    if cfg.track_mode == "surface":
        _print_surface_debug(dx=dx, dy=dy, conf=conf, coarse_conf=coarse_conf,
                             floor=0.05, prefix="[SER][Surface]")

    return AnalyzeResult(
        frames_total=n, roi_used=roi_used, track_mode=cfg.track_mode,
        quality=quality, dx=dx, dy=dy, conf=conf, order=order,
        ref_mode=ref_mode, ref_count=ref_count, ref_image=ref_img,
        ap_centers=ap_centers, ap_size=ap_size, ap_multiscale=use_multiscale,
        coarse_conf=coarse_conf, ang=ang, ang_conf=ang_conf,
        ref_cx=float(ref_cx) if cfg.track_mode == "planetary" else 0.0,
        ref_cy=float(ref_cy) if cfg.track_mode == "planetary" else 0.0,
        planet_derotate=planet_derotate if cfg.track_mode == "planetary" else False,
        surface_anchor_rot_cx=surface_anchor_rot_cx,
        surface_anchor_rot_cy=surface_anchor_rot_cy,
        disp_dx=disp_dx if correct_disp else None,
        disp_dy=disp_dy if correct_disp else None,
        flat=flat,
    )

def realign_ser(
    cfg: SERStackConfig,
    analysis: AnalyzeResult,
    *,
    debayer: bool = True,
    to_rgb: bool = False,
    max_dim: int = 512,
    progress_cb=None,
    bayer_pattern: Optional[str] = None,
    workers: Optional[int] = None,
    log_cb=None,
) -> AnalyzeResult:
    """
    Re-run the AP-level shift refinement after the user edits alignment points.

    What we KEEP from the existing analysis (unchanged by AP edits):
      - quality, order          — frame scoring is independent of APs
      - ref_image, ref_cx/cy   — reference frame doesn't change
      - ang, ang_conf           — field rotation search is independent of APs
      - disp_dx, disp_dy        — chromatic dispersion is independent of APs
      - coarse_conf             — surface coarse drift is independent of APs

    What we RECOMPUTE (the only thing AP edits actually affect):
      - dx, dy, conf            — SSD refine using the new AP layout as a
                                  starting point on top of the existing global
                                  centroid / coarse drift shifts

    For planetary: the existing dx/dy from the centroid tracker are already
    good starting points — we just re-run SSD refine on top of them with the
    updated ap_centers stored in analysis.

    For surface: the coarse NCC drift (dx/dy) is already stored in analysis
    from the original analyze_ser run — we re-run the AP-level SSD refine
    on top of those, exactly as before but without repeating the expensive
    coarse pass.
    """
    bpat = bayer_pattern or _cfg_bayer_pattern(cfg)

    if analysis is None:
        raise ValueError("analysis is None")
    if analysis.ref_image is None:
        raise ValueError("analysis.ref_image is missing")

    source_obj = _cfg_get_source(cfg)
    if not source_obj:
        raise ValueError("SERStackConfig.source/ser_path is empty")

    flat = getattr(analysis, "flat", None)

    n          = int(analysis.frames_total)
    roi_used   = analysis.roi_used
    ref_img    = analysis.ref_image

    if cfg.track_mode == "off" or cv2 is None:
        # Nothing to refine — zero out shifts and return
        analysis.dx   = np.zeros((n,), dtype=np.float32)
        analysis.dy   = np.zeros((n,), dtype=np.float32)
        analysis.conf = np.ones((n,),  dtype=np.float32)
        return analysis

    # ── Update AP centers from cfg (the whole point of calling realign) ──────
    ap_size    = int(getattr(cfg, "ap_size",    64) or 64)
    ap_spacing = int(getattr(cfg, "ap_spacing", 48) or 48)
    ap_min_mean = float(getattr(cfg, "ap_min_mean", 0.03))

    ap_centers = getattr(analysis, "ap_centers", None)
    if ap_centers is None or np.asarray(ap_centers).size == 0:
        ap_centers = _autoplace_aps(ref_img, ap_size=ap_size,
                                    ap_spacing=ap_spacing,
                                    ap_min_mean=ap_min_mean)
    analysis.ap_centers = ap_centers
    analysis.ap_size    = ap_size

    if workers is None:
        cpu = os.cpu_count() or 4
        workers = max(1, min(cpu, 48))
    if cv2 is not None:
        try:
            cv2.setNumThreads(1)
        except Exception:
            pass

    # ── Shared state read from existing analysis ──────────────────────────────
    ref_m        = _to_mono01(ref_img).astype(np.float32, copy=False)
    use_multiscale = bool(getattr(cfg, "ap_multiscale", False))
    correct_rot  = bool(getattr(cfg, "correct_field_rotation", False))
    rot_max      = float(getattr(cfg, "field_rotation_max_deg",  5.0))
    rot_step     = float(getattr(cfg, "field_rotation_step_deg", 0.5))
    correct_disp = bool(getattr(cfg, "correct_atm_dispersion", False))
    bruteforce   = bool(getattr(cfg, "ssd_refine_bruteforce", False))

    # Existing global shifts — used as warm starts for SSD refine
    prev_dx  = np.asarray(analysis.dx,  dtype=np.float32).copy()
    prev_dy  = np.asarray(analysis.dy,  dtype=np.float32).copy()

    # Output arrays (conf will be refreshed; dx/dy may be nudged by SSD)
    dx   = prev_dx.copy()
    dy   = prev_dy.copy()
    conf = np.ones((n,), dtype=np.float32)

    # ── Chunking ─────────────────────────────────────────────────────────────
    idxs          = np.arange(n, dtype=np.int32)
    chunk_factor  = int(getattr(cfg, "progress_chunk_factor", 5))
    n_chunks      = max(5, min(int(n), int(workers) * chunk_factor))
    chunks        = np.array_split(idxs, n_chunks)

    if progress_cb:
        progress_cb(0, n, "SSD Refine")

    # ── Surface branch ────────────────────────────────────────────────────────
    if cfg.track_mode == "surface":
        surface_anchor_rot_cx = getattr(analysis, "surface_anchor_rot_cx", None)
        surface_anchor_rot_cy = getattr(analysis, "surface_anchor_rot_cy", None)
        coarse_conf = getattr(analysis, "coarse_conf", None)

        def _shift_chunk_surface(chunk: np.ndarray):
            out_i:  list[int]   = []
            out_dx: list[float] = []
            out_dy: list[float] = []
            out_cf: list[float] = []

            src, owns = _ensure_source(source_obj, cache_items=0, flat=flat)
            try:
                for i in chunk.tolist():
                    img   = _get_frame(src, int(i), roi=roi_used, debayer=debayer,
                                       to_float01=True, force_rgb=bool(to_rgb),
                                       bayer_pattern=bpat)
                    img   = _conform_to_ref_shape(img, ref_img.shape)
                    cur_m = _to_mono01(img).astype(np.float32, copy=False)

                    # Warm-start from the coarse drift already stored in analysis
                    coarse_dx = float(prev_dx[int(i)])
                    coarse_dy = float(prev_dy[int(i)])
                    cc_i = (float(coarse_conf[int(i)])
                            if coarse_conf is not None else 0.5)

                    cur_m_g = _shift_image(cur_m, coarse_dx, coarse_dy)

                    # AP-level residual shift
                    if use_multiscale:
                        s2, s1, s05 = _scaled_ap_sizes(ap_size)

                        def _one_scale(s_ap: int):
                            rdx, rdy, resp = _ap_phase_shifts_per_ap(
                                ref_m, cur_m_g, ap_centers=ap_centers,
                                ap_size=s_ap, max_dim=max_dim)
                            cf = np.clip(resp.astype(np.float32, copy=False), 0.0, 1.0)
                            keep = _reject_ap_outliers(rdx, rdy, cf, z=3.5)
                            if not np.any(keep):
                                return 0.0, 0.0, 0.25
                            return (float(np.median(rdx[keep])),
                                    float(np.median(rdy[keep])),
                                    float(np.median(cf[keep])))

                        dx2, dy2, cf2 = _one_scale(s2)
                        dx1, dy1, cf1 = _one_scale(s1)
                        dx0, dy0, cf0 = _one_scale(s05)
                        w2   = max(1e-3, float(cf2)) * 1.25
                        w1   = max(1e-3, float(cf1)) * 1.00
                        w0   = max(1e-3, float(cf0)) * 0.85
                        wsum = w2 + w1 + w0
                        dx_res = (w2 * dx2 + w1 * dx1 + w0 * dx0) / wsum
                        dy_res = (w2 * dy2 + w1 * dy1 + w0 * dy0) / wsum
                        cf_ap  = float(np.clip(
                            (w2 * cf2 + w1 * cf1 + w0 * cf0) / wsum, 0.0, 1.0))
                    else:
                        rdx, rdy, resp = _ap_phase_shifts_per_ap(
                            ref_m, cur_m_g, ap_centers=ap_centers,
                            ap_size=ap_size, max_dim=max_dim)
                        cf   = np.clip(resp.astype(np.float32, copy=False), 0.0, 1.0)
                        keep = _reject_ap_outliers(rdx, rdy, cf, z=3.5)
                        if np.any(keep):
                            dx_res = float(np.median(rdx[keep]))
                            dy_res = float(np.median(rdy[keep]))
                            cf_ap  = float(np.median(cf[keep]))
                        else:
                            dx_res, dy_res, cf_ap = 0.0, 0.0, 0.25

                    dx_i = float(coarse_dx + dx_res)
                    dy_i = float(coarse_dy + dy_res)

                    dxr, dyr, c_ssd = _refine_shift_ssd(
                        ref_m, cur_m, dx_i, dy_i,
                        radius=5, crop=0.80, bruteforce=bruteforce)
                    dx_i += float(dxr)
                    dy_i += float(dyr)

                    cf_i = float(np.clip(0.60 * cc_i + 0.40 * cf_ap, 0.0, 1.0))
                    cf_i = float(np.clip(0.85 * cf_i + 0.15 * c_ssd, 0.05, 1.0))

                    out_i.append(int(i))
                    out_dx.append(dx_i)
                    out_dy.append(dy_i)
                    out_cf.append(cf_i)

            finally:
                if owns:
                    try:
                        src.close()
                    except Exception:
                        pass

            return (np.asarray(out_i,  np.int32),
                    np.asarray(out_dx,  np.float32),
                    np.asarray(out_dy,  np.float32),
                    np.asarray(out_cf,  np.float32))

        done_ct = 0
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(_shift_chunk_surface, c) for c in chunks if c.size > 0]
            for fut in as_completed(futs):
                ii, ddx, ddy, ccf = fut.result()
                dx[ii]   = ddx
                dy[ii]   = ddy
                conf[ii] = np.clip(ccf, 0.05, 1.0).astype(np.float32)
                done_ct += int(ii.size)
                if progress_cb:
                    progress_cb(done_ct, n, "SSD Refine")

    # ── Planetary branch ──────────────────────────────────────────────────────
    else:
        ref_cx = float(getattr(analysis, "ref_cx", ref_img.shape[1] * 0.5))
        ref_cy = float(getattr(analysis, "ref_cy", ref_img.shape[0] * 0.5))
        ref_m_full = _to_mono01(ref_img).astype(np.float32, copy=False)

        def _shift_chunk_planetary(chunk: np.ndarray):
            out_i:  list[int]   = []
            out_dx: list[float] = []
            out_dy: list[float] = []
            out_cf: list[float] = []

            src, owns = _ensure_source(source_obj, cache_items=0, flat=flat)
            try:
                for i in chunk.tolist():
                    img   = _get_frame(src, int(i), roi=roi_used, debayer=debayer,
                                       to_float01=True, force_rgb=bool(to_rgb),
                                       bayer_pattern=bpat)
                    img   = _conform_to_ref_shape(img, ref_img.shape)
                    cur_m = _to_mono01(img).astype(np.float32, copy=False)

                    # Warm-start from the centroid shifts already in analysis
                    dx_i = float(prev_dx[int(i)])
                    dy_i = float(prev_dy[int(i)])

                    # Re-run SSD refine from the existing warm start
                    dxr, dyr, c_ssd = _refine_shift_ssd(
                        ref_m_full, cur_m, dx_i, dy_i,
                        radius=5, crop=0.80, bruteforce=bruteforce)
                    dx_i += float(dxr)
                    dy_i += float(dyr)
                    cf_i  = float(np.clip(c_ssd, 0.05, 1.0))

                    out_i.append(int(i))
                    out_dx.append(dx_i)
                    out_dy.append(dy_i)
                    out_cf.append(cf_i)

            finally:
                if owns:
                    try:
                        src.close()
                    except Exception:
                        pass

            return (np.asarray(out_i,  np.int32),
                    np.asarray(out_dx,  np.float32),
                    np.asarray(out_dy,  np.float32),
                    np.asarray(out_cf,  np.float32))

        done_ct = 0
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(_shift_chunk_planetary, c) for c in chunks if c.size > 0]
            for fut in as_completed(futs):
                ii, ddx, ddy, ccf = fut.result()
                dx[ii]   = ddx
                dy[ii]   = ddy
                conf[ii] = np.clip(ccf, 0.05, 1.0).astype(np.float32)
                done_ct += int(ii.size)
                if progress_cb:
                    progress_cb(done_ct, n, "SSD Refine")

    # ── Write back only what changed ─────────────────────────────────────────
    # ang, ang_conf, disp_dx, disp_dy, quality, order, ref_image, ref_cx/cy,
    # coarse_conf — all preserved from the original analyze_ser run.
    analysis.dx   = dx
    analysis.dy   = dy
    analysis.conf = conf

    if cfg.track_mode == "surface":
        _print_surface_debug(dx=dx, dy=dy, conf=conf,
                             coarse_conf=getattr(analysis, "coarse_conf", None),
                             floor=0.05, prefix="[SER][Surface][realign]")

    return analysis

def _autoplace_aps(ref_img01: np.ndarray, ap_size: int, ap_spacing: int, ap_min_mean: float) -> np.ndarray:
    """
    Return AP centers as int32 array of shape (M,2) with columns (cx, cy) in ROI coords.
    We grid-scan by spacing and keep patches whose mean brightness exceeds ap_min_mean.
    """
    m = _to_mono01(ref_img01).astype(np.float32, copy=False)
    H, W = m.shape[:2]
    s = int(max(16, ap_size))
    step = int(max(4, ap_spacing))

    half = s // 2
    xs = list(range(half, max(half + 1, W - half), step))
    ys = list(range(half, max(half + 1, H - half), step))

    pts = []
    for cy in ys:
        y0 = cy - half
        y1 = y0 + s
        if y0 < 0 or y1 > H:
            continue
        for cx in xs:
            x0 = cx - half
            x1 = x0 + s
            if x0 < 0 or x1 > W:
                continue
            patch = m[y0:y1, x0:x1]
            if float(patch.mean()) >= float(ap_min_mean):
                pts.append((cx, cy))

    if not pts:
        # absolute fallback: a single center point (behaves like single-point)
        pts = [(W // 2, H // 2)]

    return np.asarray(pts, dtype=np.int32)

def _scaled_ap_sizes(base: int) -> tuple[int, int, int]:
    b = int(base)
    s2 = int(round(b * 2.0))
    s1 = int(round(b * 1.0))
    s05 = int(round(b * 0.5))
    # clamp to sane limits
    s2 = max(16, min(256, s2))
    s1 = max(16, min(256, s1))
    s05 = max(16, min(256, s05))
    return s2, s1, s05

def _dense_field_from_ap_shifts(
    H: int, W: int,
    ap_centers: np.ndarray,        # (M,2)
    ap_dx: np.ndarray,             # (M,)
    ap_dy: np.ndarray,             # (M,)
    ap_cf: np.ndarray,             # (M,)
    *,
    grid: int = 32,                # coarse grid resolution (32 or 48 are good)
    power: float = 2.0,
    conf_floor: float = 0.15,
    radius: float | None = None,   # optional clamp in pixels (ROI coords)
) -> tuple[np.ndarray, np.ndarray]:
    """
    Returns dense (dx_field, dy_field) as float32 arrays (H,W) in ROI pixels.
    Computed on coarse grid then upsampled.
    """
    # coarse grid points
    gh = max(4, int(grid))
    gw = max(4, int(round(grid * (W / max(1, H)))))

    ys = np.linspace(0, H - 1, gh, dtype=np.float32)
    xs = np.linspace(0, W - 1, gw, dtype=np.float32)
    gx, gy = np.meshgrid(xs, ys)  # (gh,gw)

    pts = ap_centers.astype(np.float32)
    px = pts[:, 0].reshape(-1, 1, 1)  # (M,1,1)
    py = pts[:, 1].reshape(-1, 1, 1)  # (M,1,1)

    cf = np.maximum(ap_cf.astype(np.float32), 0.0)
    good = cf >= float(conf_floor)

    if not np.any(good):
        dxg = np.zeros((gh, gw), np.float32)
        dyg = np.zeros((gh, gw), np.float32)
    else:
        px = px[good]
        py = py[good]
        dx = ap_dx[good].astype(np.float32).reshape(-1, 1, 1)
        dy = ap_dy[good].astype(np.float32).reshape(-1, 1, 1)
        cw = cf[good].astype(np.float32).reshape(-1, 1, 1)

        dxp = px - gx[None, :, :]   # (M,gh,gw)
        dyp = py - gy[None, :, :]   # (M,gh,gw)
        d2 = dxp * dxp + dyp * dyp  # (M,gh,gw)

        if radius is not None:
            r2 = float(radius) * float(radius)
            far = d2 > r2
        else:
            far = None

        w = 1.0 / np.maximum(d2, 1.0) ** (power * 0.5)
        w *= cw

        if far is not None:
            w = np.where(far, 0.0, w)

        wsum = np.sum(w, axis=0)  # (gh,gw)

        dxg = np.sum(w * dx, axis=0) / np.maximum(wsum, 1e-6)
        dyg = np.sum(w * dy, axis=0) / np.maximum(wsum, 1e-6)


    # upsample to full res
    dx_field = cv2.resize(dxg, (W, H), interpolation=cv2.INTER_CUBIC).astype(np.float32, copy=False)
    dy_field = cv2.resize(dyg, (W, H), interpolation=cv2.INTER_CUBIC).astype(np.float32, copy=False)
    return dx_field, dy_field

def _warp_by_dense_field(img01: np.ndarray, dx_field: np.ndarray, dy_field: np.ndarray) -> np.ndarray:
    """
    img01 (H,W) or (H,W,3)
    dx_field/dy_field are (H,W) in pixels: shifting cur by (dx,dy) aligns to ref.
    """
    H, W = dx_field.shape
    # remap wants map_x/map_y = source sampling coordinates
    # If we want output aligned-to-ref, we sample from cur at (x - dx, y - dy)
    xs, ys = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
    map_x = xs - dx_field
    map_y = ys - dy_field

    if img01.ndim == 2:
        return cv2.remap(img01, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    else:
        return cv2.remap(img01, map_x, map_y, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)

def _ap_phase_shift(
    ref_m: np.ndarray,
    cur_m: np.ndarray,
    ap_centers: np.ndarray,
    ap_size: int,
    max_dim: int,
) -> tuple[float, float, float]:
    """
    Compute a robust global shift from multiple local AP shifts.
    Returns (dx, dy, conf) in ROI pixel units.
    conf is median of per-AP phase correlation responses.
    """
    s = int(max(16, ap_size))
    half = s // 2

    H, W = ref_m.shape[:2]
    dxs = []
    dys = []
    resps = []

    # downsample reference patches once per AP? (fast enough as-is; M is usually modest)
    for (cx, cy) in ap_centers.tolist():
        x0 = cx - half
        y0 = cy - half
        x1 = x0 + s
        y1 = y0 + s
        if x0 < 0 or y0 < 0 or x1 > W or y1 > H:
            continue

        ref_patch = ref_m[y0:y1, x0:x1]
        cur_patch = cur_m[y0:y1, x0:x1]

        rp = _downsample_mono01(ref_patch, max_dim=max_dim)
        cp = _downsample_mono01(cur_patch, max_dim=max_dim)

        if rp.shape != cp.shape:
            cp = cv2.resize(cp, (rp.shape[1], rp.shape[0]), interpolation=cv2.INTER_AREA)

        sdx, sdy, resp = _phase_corr_shift(rp, cp)

        # scale back to ROI pixels (patch pixels -> ROI pixels)
        sx = float(s) / float(rp.shape[1])
        sy = float(s) / float(rp.shape[0])

        dxs.append(float(sdx * sx))
        dys.append(float(sdy * sy))
        resps.append(float(resp))

    if not dxs:
        return 0.0, 0.0, 0.5

    dx_med = float(np.median(np.asarray(dxs, np.float32)))
    dy_med = float(np.median(np.asarray(dys, np.float32)))
    conf = float(np.median(np.asarray(resps, np.float32)))

    return dx_med, dy_med, conf

def _ap_phase_shifts_per_ap(
    ref_m: np.ndarray,
    cur_m: np.ndarray,
    ap_centers: np.ndarray,
    ap_size: int,
    max_dim: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Per-AP phase correlation shifts (NO SEARCH).
    Returns arrays (ap_dx, ap_dy, ap_resp) in ROI pixels, where shifting cur by (dx,dy)
    aligns it to ref for each AP.
    """
    s = int(max(16, ap_size))
    half = s // 2

    H, W = ref_m.shape[:2]
    M = int(ap_centers.shape[0])

    ap_dx = np.zeros((M,), np.float32)
    ap_dy = np.zeros((M,), np.float32)
    ap_resp = np.zeros((M,), np.float32)

    if cv2 is None or M == 0:
        ap_resp[:] = 0.5
        return ap_dx, ap_dy, ap_resp

    for j, (cx, cy) in enumerate(ap_centers.tolist()):
        x0 = int(cx - half)
        y0 = int(cy - half)
        x1 = x0 + s
        y1 = y0 + s
        if x0 < 0 or y0 < 0 or x1 > W or y1 > H:
            ap_resp[j] = 0.0
            continue

        ref_patch = ref_m[y0:y1, x0:x1]
        cur_patch = cur_m[y0:y1, x0:x1]

        rp = _downsample_mono01(ref_patch, max_dim=max_dim)
        cp = _downsample_mono01(cur_patch, max_dim=max_dim)

        if rp.shape != cp.shape and cv2 is not None:
            cp = cv2.resize(cp, (rp.shape[1], rp.shape[0]), interpolation=cv2.INTER_AREA)

        sdx, sdy, resp = _phase_corr_shift(rp, cp)

        # scale to ROI pixels
        sx = float(s) / float(rp.shape[1])
        sy = float(s) / float(rp.shape[0])

        ap_dx[j] = float(sdx * sx)
        ap_dy[j] = float(sdy * sy)
        ap_resp[j] = float(resp)

    return ap_dx, ap_dy, ap_resp


def _ap_phase_shift_multiscale(
    ref_m: np.ndarray,
    cur_m: np.ndarray,
    ap_centers: np.ndarray,
    base_ap_size: int,
    max_dim: int,
) -> tuple[float, float, float]:
    """
    Multi-scale AP shift:
    - compute shifts at 2×, 1×, ½× AP sizes using same centers
    - combine using confidence weights (favoring coarser slightly)
    Returns (dx, dy, conf) in ROI pixels.
    """
    s2, s1, s05 = _scaled_ap_sizes(base_ap_size)

    dx2, dy2, cf2 = _ap_phase_shift(ref_m, cur_m, ap_centers, s2, max_dim)
    dx1, dy1, cf1 = _ap_phase_shift(ref_m, cur_m, ap_centers, s1, max_dim)
    dx0, dy0, cf0 = _ap_phase_shift(ref_m, cur_m, ap_centers, s05, max_dim)

    # weights: confidence * slight preference for larger scale (stability)
    w2 = max(1e-3, float(cf2)) * 1.25
    w1 = max(1e-3, float(cf1)) * 1.00
    w0 = max(1e-3, float(cf0)) * 0.85

    wsum = (w2 + w1 + w0)
    dx = (w2 * dx2 + w1 * dx1 + w0 * dx0) / wsum
    dy = (w2 * dy2 + w1 * dy1 + w0 * dy0) / wsum
    conf = float(np.clip((w2 * cf2 + w1 * cf1 + w0 * cf0) / wsum, 0.0, 1.0))

    return float(dx), float(dy), float(conf)

import struct as _struct

def _write_ser_header(f, *, width: int, height: int, frames: int, color_id: int = 0) -> None:
    """Write a minimal SER v3 header for a uint16 mono or RGB file."""
    sig = b"LUCAM-RECORDER\x00"[:14].ljust(14, b"\x00")
    # color_id: 0=MONO, 24=RGB
    # pixel_depth: 16
    # little_endian: 1
    hdr = bytearray(178)
    hdr[:14] = sig
    _struct.pack_into("<7I", hdr, 14,
        0,           # LuID
        color_id,    # ColorID
        1,           # LittleEndian
        int(width),
        int(height),
        16,          # PixelDepth
        int(frames),
    )
    f.write(bytes(hdr))


def export_aligned_ser(
    source: str | list[str] | PlanetaryFrameSource,
    out_path: str,
    analysis: AnalyzeResult,
    *,
    roi=None,
    debayer: bool = True,
    to_rgb: bool = False,
    bayer_pattern: Optional[str] = None,
    frame_indices=None,          # None = all frames, else list/array of frame indices
    apply_field_rotation: bool = True,
    apply_planet_derotation: bool = True,
    apply_local_warp: bool = True,
    planet_cx: float | None = None,
    planet_cy: float | None = None,
    planet_r: float | None = None,
    planet_pole_pa_deg: float | None = None,
    planet_axis_tilt_ba: float | None = None,
    planet_rot_deg_per_frame: float | None = None,
    max_dim: int = 512,
    progress_cb=None,
    workers: int | None = None,
) -> None:
    """
    Apply all analysis transforms (translation, field rotation, planet derotation,
    optional local AP warp) to every selected frame and write a uint16 SER file.

    The output SER can be loaded back into the planetary stacker and stacked
    with track_mode='off' for fast restacking without re-analysis.
    """
    source_obj = source

    if analysis is None or analysis.ref_image is None:
        raise ValueError("export_aligned_ser requires a completed AnalyzeResult.")

    flat = getattr(analysis, "flat", None)

    if getattr(analysis, "ang", None) is None:
        analysis.ang = np.zeros((int(analysis.frames_total),), dtype=np.float32)

    if workers is None:
        cpu = os.cpu_count() or 4
        workers = max(1, min(cpu, 16))

    if cv2 is not None:
        try:
            cv2.setNumThreads(1)
        except Exception:
            pass

    ref_img = analysis.ref_image.astype(np.float32, copy=False)
    track_mode = str(getattr(analysis, "track_mode", "planetary"))

    # ---- Planet derotation params ----
    planet_derotate = bool(getattr(analysis, "planet_derotate", False)) and apply_planet_derotation
    if planet_pole_pa_deg is None:
        planet_pole_pa_deg = float(getattr(analysis, "planet_pole_pa_deg", 0.0))
    if planet_axis_tilt_ba is None:
        planet_axis_tilt_ba = float(getattr(analysis, "planet_axis_tilt_ba", 1.0))
    if planet_rot_deg_per_frame is None:
        planet_rot_deg_per_frame = float(getattr(analysis, "planet_rot_deg_per_frame", 0.0))
    if planet_cx is None:
        planet_cx = float(getattr(analysis, "ref_cx", ref_img.shape[1] * 0.5))
    if planet_cy is None:
        planet_cy = float(getattr(analysis, "ref_cy", ref_img.shape[0] * 0.5))
    if planet_r is None:
        planet_r = float(min(ref_img.shape[0], ref_img.shape[1]) * 0.45)

    ba = float(np.clip(float(planet_axis_tilt_ba), 0.0, 1.0))
    subobs_lat_rad = float(np.arccos(ba)) if ba > 1e-8 else float(np.pi * 0.5)
    pole_angle_rad = float(np.deg2rad(float(planet_pole_pa_deg)))

    # Surface rotation center
    _surface_rot_cx: float | None = None
    _surface_rot_cy: float | None = None
    sa = getattr(analysis, "surface_anchor_rot_cx", None)
    if sa is not None:
        _surface_rot_cx = float(sa)
        _surface_rot_cy = float(getattr(analysis, "surface_anchor_rot_cy", ref_img.shape[0] * 0.5))

    # ---- Frame list ----
    n_total = int(analysis.frames_total)
    if frame_indices is None:
        indices = list(range(n_total))
    else:
        indices = [int(i) for i in frame_indices]

    n_out = len(indices)
    if n_out == 0:
        raise ValueError("No frames to export.")

    # ---- Probe first frame for shape ----
    src0, owns0 = _ensure_source(source_obj, cache_items=2, flat=flat)
    try:
        first = _get_frame(
            src0, indices[0],
            roi=roi, debayer=debayer, to_float01=True,
            force_rgb=bool(to_rgb), bayer_pattern=bayer_pattern
        )
        frame_shape = first.shape
    finally:
        if owns0:
            try:
                src0.close()
            except Exception:
                pass

    is_color = (len(frame_shape) == 3 and frame_shape[2] >= 3)
    color_id = 24 if is_color else 0  # RGB or MONO
    H, W = int(frame_shape[0]), int(frame_shape[1])

    # AP warp setup
    ref_m = _to_mono01(ref_img).astype(np.float32, copy=False)
    ap_centers_all = np.asarray(analysis.ap_centers, np.int32) if analysis.ap_centers is not None else None
    ap_size = int(getattr(analysis, "ap_size", 64) or 64)
    use_multiscale = bool(getattr(analysis, "ap_multiscale", False))
    derot_ref_i = int(indices[0])

    # Planet derotation precompute
    _derot_precomp = None
    if planet_derotate and abs(planet_rot_deg_per_frame) > 1e-12:
        try:
            _derot_precomp = _build_lonlat_grids(
                H, W, planet_cx, planet_cy, planet_r,
                pole_angle_rad, subobs_lat_rad,
            )
        except Exception:
            _derot_precomp = None

    # ---- Progress ----
    done_lock = threading.Lock()
    done_ct = 0

    def _bump(delta: int):
        nonlocal done_ct
        if progress_cb is None:
            return
        with done_lock:
            done_ct += int(delta)
            d = done_ct
        progress_cb(d, n_out, "Export aligned SER")

    if progress_cb:
        progress_cb(0, n_out, "Export aligned SER")

    # ---- Warp one frame ----
    def _warp_one(i: int, src) -> np.ndarray:
        img = _get_frame(
            src, int(i), roi=roi, debayer=debayer,
            to_float01=True, force_rgb=bool(to_rgb),
            bayer_pattern=bayer_pattern
        ).astype(np.float32, copy=False)

        gdx = float(analysis.dx[int(i)]) if analysis.dx is not None else 0.0
        gdy = float(analysis.dy[int(i)]) if analysis.dy is not None else 0.0
        warped = _shift_image(img, gdx, gdy)

        # Field rotation
        if apply_field_rotation:
            ang_i = float(analysis.ang[int(i)]) if analysis.ang is not None else 0.0
            if abs(ang_i) > 1e-6:
                if track_mode == "planetary":
                    rot_cx, rot_cy = float(planet_cx), float(planet_cy)
                else:
                    if _surface_rot_cx is not None:
                        rot_cx, rot_cy = _surface_rot_cx, float(_surface_rot_cy)
                    else:
                        rot_cx, rot_cy = float(W * 0.5), float(H * 0.5)
                warped = _rotate_about(warped, rot_cx, rot_cy, ang_i)

        # Planet axial derotation
        if planet_derotate and abs(planet_rot_deg_per_frame) > 1e-12:
            dframes = float(int(i) - int(derot_ref_i))
            dlon_rad = float(np.deg2rad(planet_rot_deg_per_frame * dframes))
            try:
                warped = derotate_stack_lonshift(
                    warped,
                    cx=planet_cx, cy=planet_cy, r=planet_r,
                    dlon_rad=dlon_rad,
                    pole_angle_rad=pole_angle_rad,
                    subobs_lat_rad=subobs_lat_rad,
                    border_value=0.0,
                    precomp=_derot_precomp,
                )
            except Exception:
                pass

        # Local AP warp
        if apply_local_warp and cv2 is not None and ap_centers_all is not None and len(ap_centers_all) > 0:
            cur_m_g = _to_mono01(warped).astype(np.float32, copy=False)
            if use_multiscale:
                s2, s1, s05 = _scaled_ap_sizes(ap_size)
                def _one(s):
                    rdx, rdy, resp = _ap_phase_shifts_per_ap(ref_m, cur_m_g, ap_centers=ap_centers_all, ap_size=s, max_dim=max_dim)
                    cf = np.clip(resp.astype(np.float32, copy=False), 0.0, 1.0)
                    return rdx, rdy, cf
                rdx2, rdy2, cf2 = _one(s2)
                rdx1, rdy1, cf1 = _one(s1)
                rdx0, rdy0, cf0 = _one(s05)
                w2 = np.maximum(cf2, 1e-3) * 1.25
                w1 = np.maximum(cf1, 1e-3) * 1.00
                w0 = np.maximum(cf0, 1e-3) * 0.85
                wsum = w2 + w1 + w0
                ap_rdx = (w2*rdx2 + w1*rdx1 + w0*rdx0) / wsum
                ap_rdy = (w2*rdy2 + w1*rdy1 + w0*rdy0) / wsum
                ap_cf  = np.clip((w2*cf2 + w1*cf1 + w0*cf0) / wsum, 0.0, 1.0)
            else:
                ap_rdx, ap_rdy, ap_resp = _ap_phase_shifts_per_ap(ref_m, cur_m_g, ap_centers=ap_centers_all, ap_size=ap_size, max_dim=max_dim)
                ap_cf = np.clip(ap_resp.astype(np.float32, copy=False), 0.0, 1.0)

            keep = _reject_ap_outliers(ap_rdx, ap_rdy, ap_cf, z=3.5)
            if np.any(keep):
                dx_field, dy_field = _dense_field_from_ap_shifts(
                    warped.shape[0], warped.shape[1],
                    ap_centers_all[keep], ap_rdx[keep], ap_rdy[keep], ap_cf[keep],
                    grid=32, power=2.0, conf_floor=0.15,
                    radius=float(ap_size) * 3.0,
                )
                warped = _warp_by_dense_field(warped, dx_field, dy_field)

        return warped

    def _frame_to_uint16(warped: np.ndarray) -> bytes:
        """Convert float32 [0..1] frame to uint16 little-endian bytes."""
        clipped = np.clip(warped, 0.0, 1.0)
        u16 = (clipped * 65535.0).astype(np.uint16)
        if not u16.flags["C_CONTIGUOUS"]:
            u16 = np.ascontiguousarray(u16)
        return u16.tobytes()

    # ---- Write SER serially to avoid seek contention ----
    # Warp in parallel chunks, write serially in index order.
    chunk_size = max(4, int(np.ceil(n_out / float(max(1, workers) * 2))))
    idx_chunks = [indices[i:i+chunk_size] for i in range(0, n_out, chunk_size)]

    # Pre-warp chunks in parallel, collect ordered results, write serially
    chunk_results: dict[int, list[np.ndarray]] = {}

    def _warp_chunk(chunk_start: int, chunk: list[int]) -> tuple[int, list[np.ndarray]]:
        src, owns = _ensure_source(source_obj, cache_items=0, flat=flat)
        results = []
        try:
            for i in chunk:
                results.append(_warp_one(i, src))
        finally:
            if owns:
                try:
                    src.close()
                except Exception:
                    pass
        return chunk_start, results

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)

    with open(out_path, "wb") as f:
        _write_ser_header(f, width=W, height=H, frames=n_out, color_id=color_id)

        with ThreadPoolExecutor(max_workers=workers) as ex:
            # Map chunk_index -> future for ordered retrieval
            chunk_futs = [ex.submit(_warp_chunk, i * chunk_size, chunk)
                          for i, chunk in enumerate(idx_chunks)]

            # Retrieve in submission order so frames are written in sequence
            for fut in chunk_futs:
                _, warped_frames = fut.result()
                for warped in warped_frames:
                    f.write(_frame_to_uint16(warped))
                    _bump(1)

    if progress_cb:
        progress_cb(n_out, n_out, "Export aligned SER")