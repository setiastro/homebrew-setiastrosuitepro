#saspro/perfect_palette_picker.py
from __future__ import annotations
import os
import numpy as np
from PIL import Image
import cv2
from PyQt6.QtCore import Qt, QSize, QEvent, QTimer, QPoint, pyqtSignal, QSettings, QByteArray
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
    QFileDialog, QInputDialog, QMessageBox, QGridLayout, QCheckBox, QSizePolicy, QDialog
)
from PyQt6.QtGui import QPixmap, QImage, QIcon, QPainter, QPen, QColor, QFont, QFontMetrics, QCursor

# legacy loader (same one DocManager uses)
from setiastro.saspro.legacy.image_manager import load_image as legacy_load_image

# your statistical stretch (mono + color) like SASv2
# (same signatures you use elsewhere)
from setiastro.saspro.imageops.stretch import stretch_mono_image, stretch_color_image
from setiastro.saspro.widgets.themed_buttons import themed_toolbtn
from setiastro.saspro.help_support import make_help_button

class PaletteAdjustDialog(QDialog):
    adjusted_image = pyqtSignal(np.ndarray)

    def __init__(self, base_rgb, palette_name, ha_src, oiii_src, sii_src, owner):
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea, QSlider
        from PyQt6.QtCore import QTimer, Qt, QPoint, QEvent
        super().__init__(owner)
        self.setWindowTitle("Adjust Palette Intensities")
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)
        #self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

        self.base_rgb     = base_rgb.astype(np.float32)
        self.palette_name = palette_name
        self.ha_src       = ha_src
        self.oiii_src     = oiii_src
        self.sii_src      = sii_src
        self.owner        = owner

        self.ha_factor = 1.0
        self.oiii_factor = 1.0
        self.sii_factor = 1.0

        self._debounce = QTimer(self); self._debounce.setInterval(300); self._debounce.setSingleShot(True)
        self._debounce.timeout.connect(self._update_preview)

        self.zoom_factor = 1.0
        self._dragging = False
        self._last_pos = QPoint()

        vlayout = QVBoxLayout(self)

        # Zoom controls
        zoom_layout = QHBoxLayout()

        self.btn_zoom_in  = themed_toolbtn("zoom-in", "Zoom In")
        self.btn_zoom_out = themed_toolbtn("zoom-out", "Zoom Out")
        self.btn_fit      = themed_toolbtn("zoom-fit-best", "Fit to Preview")

        self.btn_zoom_in.clicked.connect(lambda: self._change_zoom(1.25))
        self.btn_zoom_out.clicked.connect(lambda: self._change_zoom(0.8))
        self.btn_fit.clicked.connect(self._fit_to_preview)

        zoom_layout.addStretch(1)
        zoom_layout.addWidget(self.btn_zoom_out)
        zoom_layout.addWidget(self.btn_zoom_in)
        zoom_layout.addWidget(self.btn_fit)
        zoom_layout.addStretch(1)

        vlayout.addLayout(zoom_layout)

        # Preview
        self.preview_area = QScrollArea(self); self.preview_area.setWidgetResizable(True)
        self.preview_label = QLabel(alignment=Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setCursor(Qt.CursorShape.OpenHandCursor)
        self.preview_label.setMouseTracking(True)
        self.preview_area.setWidget(self.preview_label)
        self.preview_label.installEventFilter(self)
        vlayout.addWidget(self.preview_area, stretch=1)

        # Sliders
        for name in ("Ha","OIII","SII"):
            row = QHBoxLayout()
            row.addWidget(QLabel(f"{name} Intensity:", self))
            sl = QSlider(Qt.Orientation.Horizontal, self); sl.setRange(0,200); sl.setValue(100)
            sl.valueChanged.connect(self._on_slider_change)
            setattr(self, f"_{name.lower()}_slider", sl)
            row.addWidget(sl)
            vlayout.addLayout(row)

        # Buttons
        btns = QHBoxLayout(); btns.addStretch()
        accept  = QPushButton("Accept", self); accept.clicked.connect(self._on_accept)
        reset   = QPushButton("Reset",  self); reset.clicked.connect(self._on_reset)
        discard = QPushButton("Discard",self); discard.clicked.connect(self.reject)
        btns.addWidget(accept); btns.addWidget(reset); btns.addWidget(discard)
        vlayout.addLayout(btns)

        self._update_preview()

    def _on_slider_change(self, _):
        self.ha_factor   = self._ha_slider.value()/100.0
        self.oiii_factor = self._oiii_slider.value()/100.0
        self.sii_factor  = self._sii_slider.value()/100.0
        self._debounce.start()

    def _update_preview(self):
        ha = (self.ha_src   * self.ha_factor)   if self.ha_src   is not None else None
        oo = (self.oiii_src * self.oiii_factor) if self.oiii_src is not None else None
        si = (self.sii_src  * self.sii_factor)  if self.sii_src  is not None else None

        r,g,b = self.owner._map_channels_or_special(self.palette_name, ha, oo, si)

        # --- make sure channels match the base palette size ---
        H, W = self.base_rgb.shape[:2]
        def fit(ch):
            if ch is None: return None
            if ch.shape[:2] != (H, W):
                return self.owner._resize_to(ch, (W, H))
            return ch
        r, g, b = fit(r), fit(g), fit(b)
        # ------------------------------------------------------

        img = np.zeros_like(self.base_rgb, dtype=np.float32)
        if r is not None: img[...,0] = r
        if g is not None: img[...,1] = g
        if b is not None: img[...,2] = b
        m = float(img.max()) or 1.0
        img = np.clip(img/m, 0.0, 1.0)

        qimg = self.owner._to_qimage(img)
        self._base_pixmap = QPixmap.fromImage(qimg)
        self._rescale_pixmap()

    def _rescale_pixmap(self):
        if not hasattr(self, "_base_pixmap"): return
        w = int(self._base_pixmap.width()  * self.zoom_factor)
        h = int(self._base_pixmap.height() * self.zoom_factor)
        scaled = self._base_pixmap.scaled(w, h, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self._current_pixmap = scaled
        self.preview_label.setPixmap(scaled)
        self.preview_label.resize(scaled.size())

    def _change_zoom(self, factor: float):
        self.zoom_factor = max(0.1, min(10.0, self.zoom_factor * factor))
        self._rescale_pixmap()

    def _fit_to_preview(self):
        if not hasattr(self, "_base_pixmap"):
            return
        vp = self.preview_area.viewport().size()
        pm = self._base_pixmap.size()
        if pm.width() <= 0 or pm.height() <= 0:
            return
        k = min(vp.width() / pm.width(), vp.height() / pm.height())
        self.zoom_factor = max(0.1, min(10.0, k))
        self._rescale_pixmap()


    def _on_reset(self):
        for s in (self._ha_slider, self._oiii_slider, self._sii_slider):
            s.setValue(100)
        self._on_slider_change(None)

    def _on_accept(self):
        ha = (self.ha_src   * self.ha_factor)   if self.ha_src   is not None else None
        oo = (self.oiii_src * self.oiii_factor) if self.oiii_src is not None else None
        si = (self.sii_src  * self.sii_factor)  if self.sii_src  is not None else None

        r,g,b = self.owner._map_channels_or_special(self.palette_name, ha, oo, si)

        # match base size
        H, W = self.base_rgb.shape[:2]
        def fit(ch):
            if ch is None: return None
            if ch.shape[:2] != (H, W):
                return self.owner._resize_to(ch, (W, H))
            return ch
        r, g, b = fit(r), fit(g), fit(b)

        final = np.zeros_like(self.base_rgb, dtype=np.float32)
        if r is not None: final[...,0] = r
        if g is not None: final[...,1] = g
        if b is not None: final[...,2] = b

        m = float(final.max()) or 1.0
        final = np.clip(final/m, 0.0, 1.0)

        self.adjusted_image.emit(final)
        self.accept()

    def eventFilter(self, obj, evt):
        if obj is self.preview_label:
            if evt.type() == QEvent.Type.MouseButtonPress and evt.button() == Qt.MouseButton.LeftButton:
                self._dragging = True; self._last_pos = evt.pos()
                self.preview_label.setCursor(Qt.CursorShape.ClosedHandCursor); return True
            if evt.type() == QEvent.Type.MouseMove and self._dragging:
                d = evt.pos() - self._last_pos; self._last_pos = evt.pos()
                self.preview_area.horizontalScrollBar().setValue(self.preview_area.horizontalScrollBar().value() - d.x())
                self.preview_area.verticalScrollBar().setValue(self.preview_area.verticalScrollBar().value() - d.y())
                return True
            if evt.type() == QEvent.Type.MouseButtonRelease and evt.button() == Qt.MouseButton.LeftButton:
                self._dragging = False; self.preview_label.setCursor(Qt.CursorShape.OpenHandCursor); return True
            if evt.type() == QEvent.Type.Wheel:
                self._change_zoom(1.1 if evt.angleDelta().y() > 0 else 0.9); return True
        return super().eventFilter(obj, evt)

class PaletteGridWindow(QDialog):
    """Non-modal companion window holding the palette thumbnail grid."""
    def __init__(self, owner, grid_host):
        super().__init__(owner)
        self.setWindowTitle("Palette Gallery")
        self.setWindowFlag(Qt.WindowType.Window, True)
        self.setModal(False)
        self._owner = owner

        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 8, 8, 8)
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setWidget(grid_host)
        lay.addWidget(scroll)

    def closeEvent(self, e):
        # Don't destroy the grid; just hide so the toggle can reopen it.
        try:
            self._owner.btn_gallery.setChecked(False)
        except Exception:
            pass
        self.hide()
        e.ignore()


class PerfectPalettePicker(QWidget):
    THUMB_CROP = 512  # side length for thumbnail center crops
    PALETTES = [
        "HHO","HOO","HOS","HSO",
        "HSS","OHH","OHS","OOS",
        "OSH","OSS","SHH","SHO",
        "SOH","SOO",
        "Realistic1","Realistic2","Foraxx",
        "Dynamic Inverse",
    ]

    def __init__(self, doc_manager=None, parent=None):
        super().__init__(parent)
        self.doc_manager = doc_manager
        self.setWindowFlag(Qt.WindowType.Window, True)
        self.setWindowTitle("Perfect Palette Picker")
        self._settings = QSettings()
        self._persist_prefix = "perfect_palette_picker"
        self._geom_restored = False
        # raw channels (float32 ~[0..1])
        self.ha   = None
        self.oiii = None
        self.sii  = None
        self.osc1 = None
        self.osc2 = None
        self._dim_mismatch_accepted = False

        # stretched cache (per input name → stretched array)
        self._stretched: dict[str, np.ndarray] = {}

        self.final = None
        self.current_palette = None
        self._thumb_base_pm: dict[str, QPixmap] = {}   # palette name -> base pixmap (image only)
        self._selected_name: str | None = None

        # thumbs
        self._thumb_buttons: dict[str, QPushButton] = {}

        self._base_pm: QPixmap | None = None
        self._zoom = 1.0
        self._min_zoom = 0.05
        self._max_zoom = 6.0
        self._panning = False
        self._pan_last: QPoint | None = None

        self._build_ui()

        # Ensure PPP (and its gallery) don't outlive the application.
        from PyQt6.QtWidgets import QApplication
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self._on_app_quit)

    def _k(self, key: str) -> str:
        return f"{self._persist_prefix}/{key}"

    # ---------------- UI ----------------
    def _build_ui(self):
        root = QHBoxLayout(self)

        # -------- left controls
        left = QVBoxLayout()
        left_host = QWidget(self); left_host.setLayout(left); left_host.setFixedWidth(300)

        left.addWidget(QLabel("<b>Load channels</b>"))

        # Load buttons + status labels
        self.btn_ha   = QPushButton("Load Ha…");   self.btn_ha.clicked.connect(lambda: self._load_channel("Ha"))
        self.btn_oiii = QPushButton("Load OIII…"); self.btn_oiii.clicked.connect(lambda: self._load_channel("OIII"))
        self.btn_sii  = QPushButton("Load SII…");  self.btn_sii.clicked.connect(lambda: self._load_channel("SII"))
        self.btn_osc1 = QPushButton("Load OSC1 (Ha/OIII)…"); self.btn_osc1.clicked.connect(lambda: self._load_channel("OSC1"))
        self.btn_osc2 = QPushButton("Load OSC2 (SII/OIII)…"); self.btn_osc2.clicked.connect(lambda: self._load_channel("OSC2"))

        self.lbl_ha   = QLabel("No Ha loaded.")
        self.lbl_oiii = QLabel("No OIII loaded.")
        self.lbl_sii  = QLabel("No SII loaded.")
        self.lbl_osc1 = QLabel("No OSC1 loaded.")
        self.lbl_osc2 = QLabel("No OSC2 loaded.")
        for lab in (self.lbl_ha, self.lbl_oiii, self.lbl_sii, self.lbl_osc1, self.lbl_osc2):
            lab.setWordWrap(True); lab.setStyleSheet("color:#888; margin-left:8px;")

        for btn, lab in (
            (self.btn_ha, self.lbl_ha),
            (self.btn_oiii, self.lbl_oiii),
            (self.btn_sii, self.lbl_sii),
            (self.btn_osc1, self.lbl_osc1),
            (self.btn_osc2, self.lbl_osc2),
        ):
            left.addWidget(btn); left.addWidget(lab)

        # Linear toggle (stretch BEFORE palette build)
        self.chk_linear = QCheckBox("Linear input (apply statistical stretch before build)")
        self.chk_linear.setChecked(True)
        self.chk_linear.stateChanged.connect(self._rebuild_stretch_cache_for_all)
        left.addSpacing(6); left.addWidget(self.chk_linear)

        # Actions
        self.btn_clear = QPushButton("Clear Loaded Channels")
        self.btn_clear.clicked.connect(self._clear_channels)
        left.addWidget(self.btn_clear)

        self.btn_create = QPushButton("Create Palettes")
        self.btn_create.clicked.connect(self._create_palettes)
        left.addWidget(self.btn_create)

        self.btn_push = QPushButton("Push Final to New View")
        self.btn_push.clicked.connect(self._push_final)
        left.addWidget(self.btn_push)

        self.btn_gallery = QPushButton("Show Palette Gallery")
        self.btn_gallery.setCheckable(True)
        self.btn_gallery.setChecked(True)
        self.btn_gallery.toggled.connect(self._toggle_gallery)
        left.addWidget(self.btn_gallery)

        left.addStretch(1)
        root.addWidget(left_host, 0)

        # -------- right: preview + fixed-size 4×3 grid
        right = QVBoxLayout()

        # zoom toolbar
        # zoom toolbar (themed)
        tools = QHBoxLayout()
        self.btn_zoom_in  = themed_toolbtn("zoom-in", "Zoom In")
        self.btn_zoom_out = themed_toolbtn("zoom-out", "Zoom Out")
        self.btn_fit      = themed_toolbtn("zoom-fit-best", "Fit to Preview")

        self.btn_zoom_in.clicked.connect(lambda: self._zoom_at(1.25))
        self.btn_zoom_out.clicked.connect(lambda: self._zoom_at(0.8))
        self.btn_fit.clicked.connect(self._fit_to_preview)

        tools.addStretch(1)
        tools.addWidget(self.btn_zoom_out)
        tools.addWidget(self.btn_zoom_in)
        tools.addWidget(self.btn_fit)
        tools.addStretch(1)
        self.btn_doc_help = make_help_button("perfect_palette_picker", self)
        tools.addWidget(self.btn_doc_help)
        right.addLayout(tools)


        # main preview (expands)
        self.scroll = QScrollArea(self); self.scroll.setWidgetResizable(True)
        self.scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview = QLabel(alignment=Qt.AlignmentFlag.AlignCenter)
        self.scroll.setWidget(self.preview)
        self.preview.setMouseTracking(True)
        self.preview.installEventFilter(self)
        self.scroll.viewport().installEventFilter(self)     
        self.scroll.installEventFilter(self)  
        self.scroll.horizontalScrollBar().installEventFilter(self)  # NEW
        self.scroll.verticalScrollBar().installEventFilter(self)    # NEW        
        right.addWidget(self.scroll, 1)

        # fixed-size grid
        self.grid = QGridLayout()
        self.grid.setHorizontalSpacing(8); self.grid.setVerticalSpacing(8)
        self.grid.setContentsMargins(8, 8, 8, 8)

        self.thumb_size = QSize(220, 110)
        btn_w = self.thumb_size.width() + 2
        btn_h = self.thumb_size.height() + 2
        cols = 6            # was 4  →  18 palettes = clean 3×6
        rows = (len(self.PALETTES) + cols - 1) // cols

        for idx, name in enumerate(self.PALETTES):
            r, c = divmod(idx, cols)
            b = QPushButton("")  # we draw the text onto the icon itself
            b.setToolTip(name)
            b.setIconSize(self.thumb_size)
            b.setFixedSize(btn_w, btn_h)
            b.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
            b.clicked.connect(lambda _=None, n=name: self._on_palette_clicked(n))
            b.setStyleSheet("QPushButton{background:#222;border:1px solid #333;} QPushButton:hover{border-color:#555;}")
            self._thumb_buttons[name] = b
            self.grid.addWidget(b, r, c)

        grid_host = QWidget(); grid_host.setLayout(self.grid)
        hspacing = self.grid.horizontalSpacing(); vspacing = self.grid.verticalSpacing()
        m = self.grid.contentsMargins()
        grid_w = cols*btn_w + (cols-1)*hspacing + m.left() + m.right()
        grid_h = rows*btn_h + (rows-1)*vspacing + m.top() + m.bottom()
        grid_host.setMinimumSize(grid_w, grid_h)   # was setFixedSize
        self._grid_host = grid_host                 # stash for the popout

        # grid now lives in its own non-modal gallery window (created below)
        self._gallery = PaletteGridWindow(self, grid_host)
        self._gallery.resize(grid_w + 40, grid_h + 40)

        self.status = QLabel(""); right.addWidget(self.status, 0)

        right_host = QWidget(self); right_host.setLayout(right)
        root.addWidget(right_host, 1)
        self.chk_linear.stateChanged.connect(lambda *_: self._save_ui_state())
        self.setLayout(root)
        self.setMinimumSize(left_host.width() + 480, 560)

    def _resize_to(self, arr: np.ndarray | None, size: tuple[int, int]) -> np.ndarray | None:
        """Resize np array to (w,h). Keeps dtype/scale. Uses INTER_AREA for downsizing."""
        if arr is None:
            return None
        w, h = size
        if arr.ndim == 2:
            src_h, src_w = arr.shape
        else:
            src_h, src_w = arr.shape[:2]
        if (src_w, src_h) == (w, h):
            return arr
        if cv2 is None:
            # ultra-simple fallback: nearest; OK for thumbs if OpenCV isn't present
            if arr.ndim == 2:
                return np.array(Image.fromarray((arr*255).astype(np.uint8)).resize((w, h))).astype(np.float32) / 255.0
            return np.array(Image.fromarray((arr*255).astype(np.uint8)).resize((w, h))).astype(np.float32) / 255.0
        interp = cv2.INTER_AREA if (w < src_w or h < src_h) else cv2.INTER_LINEAR
        if arr.ndim == 2:
            return cv2.resize(arr, (w, h), interpolation=interp)
        return cv2.resize(arr, (w, h), interpolation=interp)

    def _save_ui_state(self):
        try:
            s = self._settings
            s.setValue(self._k("window_geometry"), self.saveGeometry())
            s.setValue(self._k("linear"), bool(self.chk_linear.isChecked()))
            if getattr(self, "_gallery", None) is not None:
                s.setValue(self._k("gallery_geometry"), self._gallery.saveGeometry())
                s.setValue(self._k("gallery_visible"), bool(self._gallery.isVisible()))
            try:
                s.sync()
            except Exception:
                pass
        except Exception:
            pass


    def _restore_ui_state(self):
        try:
            s = self._settings

            g = s.value(self._k("window_geometry"), None)
            if g is not None:
                self.restoreGeometry(g)

            linear = bool(s.value(self._k("linear"), True, type=bool))
            self.chk_linear.blockSignals(True)
            self.chk_linear.setChecked(linear)
            self.chk_linear.blockSignals(False)

            gg = s.value(self._k("gallery_geometry"), None)
            if gg is not None and getattr(self, "_gallery", None) is not None:
                self._gallery.restoreGeometry(gg)

        except Exception:
            pass

    def _capture_view_state(self):
        """Capture current view center in base-image coordinates + zoom."""
        if self._base_pm is None:
            return None
        vp = self.scroll.viewport()
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()

        # center of viewport in viewport coords
        anchor_vp = QPoint(vp.width() // 2, vp.height() // 2)

        # convert to label coords (scaled image coords)
        anchor_lbl = self.preview.mapFrom(vp, anchor_vp)

        # scaled -> base image coords
        base_x = anchor_lbl.x() / max(self._zoom, 1e-6)
        base_y = anchor_lbl.y() / max(self._zoom, 1e-6)

        pm = self._base_pm.size()
        fx = 0.5 if pm.width()  <= 0 else (base_x / pm.width())
        fy = 0.5 if pm.height() <= 0 else (base_y / pm.height())

        return {"zoom": float(self._zoom), "fx": float(fx), "fy": float(fy)}

    def _restore_view_state(self, state):
        """Restore zoom and pan using stored base-image fractions."""
        if not state or self._base_pm is None:
            return

        # restore zoom first
        self._zoom = max(self._min_zoom, min(self._max_zoom, float(state["zoom"])))
        self._update_preview_pixmap()

        # now restore center point
        pm = self._base_pm.size()
        fx = float(state.get("fx", 0.5))
        fy = float(state.get("fy", 0.5))

        base_x = fx * pm.width()
        base_y = fy * pm.height()

        # base -> scaled label coords
        lbl_x = int(base_x * self._zoom)
        lbl_y = int(base_y * self._zoom)

        vp = self.scroll.viewport()
        anchor_vp = QPoint(vp.width() // 2, vp.height() // 2)

        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()
        hbar.setValue(max(hbar.minimum(), min(hbar.maximum(), lbl_x - anchor_vp.x())))
        vbar.setValue(max(vbar.minimum(), min(vbar.maximum(), lbl_y - anchor_vp.y())))

    # ---------- status helpers ----------
    def _set_status_label(self, which: str, text: str | None):
        lab = getattr(self, f"lbl_{which.lower()}")
        if text:
            lab.setText(text)
            lab.setStyleSheet("color:#2a7; font-weight:600; margin-left:8px;")
        else:
            lab.setText(f"No {which} loaded.")
            lab.setStyleSheet("color:#888; margin-left:8px;")

    # ------------- load by view/file -------------
    def _load_channel(self, which: str):
        src, ok = QInputDialog.getItem(
            self, f"Load {which}", "Source:", ["From View", "From File"], 0, False
        )
        if not ok:
            return

        if src == "From View":
            out = self._load_from_view(which)
        else:
            out = self._load_from_file(which)
        if out is None:
            return

        img, header, bit_depth, is_mono, path, label = out

        # NB channels → mono; OSC → RGB
        if which in ("Ha","OIII","SII"):
            if img.ndim == 3:
                img = img[:, :, 0]
        else:
            if img.ndim == 2:
                img = np.stack([img]*3, axis=-1)

        # store raw, normalized
        setattr(self, which.lower(), self._as_float01(img))
        self._set_status_label(which, label)
        self.status.setText(f"{which} loaded ({'mono' if img.ndim==2 else 'RGB'}) shape={img.shape}")

        # build/clear stretched cache for this input
        self._cache_stretch(which)

        if self.current_palette is None:
            self.current_palette = "SHO"

    def _load_from_view(self, which):
        views = self._list_open_views()
        if not views:
            QMessageBox.warning(self, "No Views", "No open image views were found.")
            return None

        labels = [lab for lab, _ in views]
        choice, ok = QInputDialog.getItem(
            self, f"Select View for {which}", "Choose a view (by name):", labels, 0, False
        )
        if not ok or not choice:
            return None

        sw = dict(views)[choice]
        vw = sw.widget()
        doc = getattr(vw, "document", None)

        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.warning(self, "Empty View", "Selected view has no image.")
            return None

        img = doc.image
        meta = getattr(doc, "metadata", {}) or {}
        header = meta.get("original_header", None)
        bit_depth = meta.get("bit_depth", "Unknown")
        is_mono = (img.ndim == 2) or (img.ndim == 3 and img.shape[2] == 1)
        path = meta.get("file_path", None)
        return img, header, bit_depth, is_mono, path, f"From View: {choice}"

    def _load_from_file(self, which):
        filt = "Images (*.png *.tif *.tiff *.fits *.fit *.xisf)"
        path, _ = QFileDialog.getOpenFileName(self, f"Select {which} File", "", filt)
        if not path:
            return None
        img, header, bit_depth, is_mono = legacy_load_image(path)
        if img is None:
            QMessageBox.critical(self, "Load Error", f"Could not load {os.path.basename(path)}")
            return None
        label = f"From File: {os.path.basename(path)}"
        return img, header, bit_depth, is_mono, path, label

    def showEvent(self, e):
        super().showEvent(e)
        if self._geom_restored:
            return
        self._geom_restored = True

        def _after():
            self._restore_ui_state()
            # Open the palette gallery alongside the main window,
            # honoring last session's visibility (default: open).
            if getattr(self, "_gallery", None) is not None:
                want_visible = bool(self._settings.value(
                    self._k("gallery_visible"), True, type=bool))
                self.btn_gallery.blockSignals(True)
                self.btn_gallery.setChecked(want_visible)
                self.btn_gallery.blockSignals(False)
                if want_visible:
                    self._gallery.show()
                    self._gallery.raise_()
            # center scrollbars if nothing loaded yet
            if self._base_pm is None:
                self._center_scrollbars()
        QTimer.singleShot(0, _after)

    def _on_app_quit(self):
        try:
            self._save_ui_state()
        except Exception:
            pass
        if getattr(self, "_gallery", None) is not None:
            self._gallery.deleteLater()
        self.close()

    def closeEvent(self, e):
        try:
            self._save_ui_state()
        except Exception:
            pass
        if getattr(self, "_gallery", None) is not None:
            self._gallery.deleteLater()
        super().closeEvent(e)

    # ------------- build/caches -------------
    def _cache_stretch(self, which: str):
        """Compute and cache stretched version of a just-loaded input (if linear checked)."""
        arr = getattr(self, which.lower())
        if arr is None:
            self._stretched.pop(which, None); return
        if not self.chk_linear.isChecked():
            self._stretched.pop(which, None); return
        self._stretched[which] = self._stretch_input(arr)

    def _rebuild_stretch_cache_for_all(self, _state: int):
        """Rebuild (or clear) stretched cache for all loaded inputs when checkbox toggles."""
        for which in ("Ha","OIII","SII","OSC1","OSC2"):
            self._cache_stretch(which)

    def _render_thumb(self, name: str):
        base = self._thumb_base_pm.get(name)
        if base is None:
            return
        pm = base.copy()

        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        font = QFont("Helvetica", 10, QFont.Weight.DemiBold)
        p.setFont(font)
        fm = QFontMetrics(font)

        pad = 6
        strip_h = fm.height() + pad * 2
        strip = pm.rect().adjusted(0, pm.height() - strip_h, 0, 0)

        # translucent bottom strip
        p.fillRect(strip, QColor(0, 0, 0, 160))
        color = QColor(102, 255, 102) if self._selected_name == name else QColor(255, 255, 255)
        p.setPen(QPen(color))
        p.drawText(strip, Qt.AlignmentFlag.AlignCenter, name)
        p.end()

        btn = self._thumb_buttons[name]
        btn.setIcon(QIcon(pm))
        btn.setIconSize(self.thumb_size)  # <- ensures no clipping

    # ------------- thumbnails -------------
    def _create_palettes(self):
        """
        Build the 12 palette thumbnails from a **center crop of the stretched inputs**
        and draw the palette name directly on each thumbnail. Names turn green when selected.
        """
        ha, oo, si = self._prepared_channels(for_thumbs=True)
        has_narrowband = sum(x is not None for x in (ha, oo, si))
        if has_narrowband < 2:
            QMessageBox.warning(self, "Need Channels",
                "Load any two of Ha / OIII / SII, or one OSC image.")
            return

        built = 0
        for name in self.PALETTES:
            r, g, b = self._map_channels_or_special(name, ha, oo, si)
            if any(ch is None for ch in (r, g, b)):
                self._thumb_base_pm.pop(name, None)
                self._thumb_buttons[name].setIcon(QIcon())
                continue

            r = np.clip(np.nan_to_num(r), 0, 1)
            g = np.clip(np.nan_to_num(g), 0, 1)
            b = np.clip(np.nan_to_num(b), 0, 1)
            rgb = np.stack([r, g, b], axis=2).astype(np.float32)

            # scale the thumbnail to EXACTLY the button icon size first
            pm = QPixmap.fromImage(self._to_qimage(rgb)).scaled(
                self.thumb_size, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            self._thumb_base_pm[name] = pm
            self._render_thumb(name) 
            built += 1

        self.status.setText(f"Created {built} palette previews.")


    def _on_palette_clicked(self, name: str):
        self._selected_name = name
        for n in self.PALETTES:
            self._render_thumb(n)
        self.current_palette = name
        self._generate_for_palette(name)

    # ------------- palette build helpers -------------
    def _center_crop(self, img: np.ndarray, side: int) -> np.ndarray:
        """Center-crop to a square of size 'side' (no upscaling)."""
        h, w = img.shape[:2]; s = min(side, h, w)
        y0 = (h - s) // 2; x0 = (w - s) // 2
        return img[y0:y0+s, x0:x0+s] if img.ndim == 2 else img[y0:y0+s, x0:x0+s, :]

    def _center_crop_all_to_side(self, side: int, *imgs):
        """Center-crop all provided images to the same square side (no upscaling)."""
        s = None
        for im in imgs:
            if im is None: continue
            h, w = im.shape[:2]
            s = min(side, h, w) if s is None else min(s, h, w, side)
        if s is None: s = side
        return [self._center_crop(im, s) if im is not None else None for im in imgs], s

    def _prepared_channels(self, for_thumbs: bool = False):
        """
        Build Ha/OIII/SII bases from inputs. If 'Linear input' is checked,
        **use stretched versions** (cached). Then optionally center-crop for thumbnails.
        """
        # choose raw vs stretched
        def pick(name):
            if self.chk_linear.isChecked() and (name in self._stretched):
                return self._stretched[name]
            return getattr(self, name.lower())

        ha = pick("Ha")
        oo = pick("OIII")
        si = pick("SII")
        o1 = pick("OSC1")
        o2 = pick("OSC2")

        # synthesize from stretched OSC first (stretch-before-crop)
        if o1 is not None:  # OSC1: R≈Ha, mean(G,B)≈OIII
            h1 = o1[..., 0]
            g1b1 = o1[..., 1:3].mean(axis=2)
            ha = h1 if ha is None else 0.5*ha + 0.5*h1
            oo = g1b1 if oo is None else 0.5*oo + 0.5*g1b1

        if o2 is not None:  # OSC2: R≈SII, mean(G,B)≈OIII
            s2 = o2[..., 0]
            g2b2 = o2[..., 1:3].mean(axis=2)
            si = s2 if si is None else 0.5*si + 0.5*s2
            oo = g2b2 if oo is None else 0.5*oo + 0.5*g2b2

        # shapes must match for full-size
        # shapes must match for full-size
        shapes = [x.shape[:2] for x in (ha, oo, si) if x is not None]
        if len(shapes) and len(set(shapes)) > 1 and not for_thumbs:
            # pick a reference size (prefer Ha, then OIII, then SII)
            ref = ha if ha is not None else (oo if oo is not None else si)
            ref_name = "Ha" if ha is not None else ("OIII" if oo is not None else "SII")
            ref_h, ref_w = ref.shape[:2]

            # Only prompt once per session unless you want every time
            if not self._dim_mismatch_accepted:
                msg = (
                    "The loaded channels have different image dimensions.\n\n"
                    f"• Ha:   {None if ha is None else ha.shape}\n"
                    f"• OIII: {None if oo is None else oo.shape}\n"
                    f"• SII:  {None if si is None else si.shape}\n\n"
                    f"SASpro can resize (warp) the channels to match the reference frame:\n"
                    f"• Reference: {ref_name}\n"
                    f"• Target size: ({ref_w} × {ref_h})\n\n"
                    "Proceed and resize mismatched channels?"
                )
                ret = QMessageBox.question(
                    self,
                    "Channel Size Mismatch",
                    msg,
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes
                )
                if ret != QMessageBox.StandardButton.Yes:
                    return None, None, None

                self._dim_mismatch_accepted = True

            # resize to reference
            ha = self._resize_to(ha, (ref_w, ref_h)) if ha is not None else None
            oo = self._resize_to(oo, (ref_w, ref_h)) if oo is not None else None
            si = self._resize_to(si, (ref_w, ref_h)) if si is not None else None

        # thumbnails: crop AFTER stretch/synth
        if for_thumbs:
            # choose a reference (prefer OIII, then Ha, then SII)
            ref = oo if oo is not None else (ha if ha is not None else si)
            if ref is not None:
                ref_h, ref_w = ref.shape[:2]

                # 1) first, size-match all channels to the reference full frame
                ha = self._resize_to(ha, (ref_w, ref_h)) if ha is not None else None
                oo = self._resize_to(oo, (ref_w, ref_h)) if oo is not None else None
                si = self._resize_to(si, (ref_w, ref_h)) if si is not None else None

                # 2) then, make a 50% view of the full rectangle
                half_w = max(1, int(ref_w * 0.5))
                half_h = max(1, int(ref_h * 0.5))
                ha = self._resize_to(ha, (half_w, half_h)) if ha is not None else None
                oo = self._resize_to(oo, (half_w, half_h)) if oo is not None else None
                si = self._resize_to(si, (half_w, half_h)) if si is not None else None

        return ha, oo, si

    def _generate_for_palette(self, pal: str):
        ha, oo, si = self._prepared_channels()
        has_narrowband = sum(x is not None for x in (ha, oo, si))
        if has_narrowband < 2:
            return

        r,g,b = self._map_channels_or_special(pal, ha, oo, si)
        if any(ch is None for ch in (r,g,b)):
            QMessageBox.critical(self, "Palette Error", f"Could not build palette {pal}."); return

        r = np.clip(np.nan_to_num(r), 0, 1)
        g = np.clip(np.nan_to_num(g), 0, 1)
        b = np.clip(np.nan_to_num(b), 0, 1)
        rgb = np.stack([r,g,b], axis=2).astype(np.float32)

        mx = float(rgb.max()) or 1.0
        self.final = (rgb / mx).astype(np.float32)

        # Fit only when there wasn't an existing preview yet
        first = (self._base_pm is None)
        self._set_preview_image(self._to_qimage(self.final), fit=first, preserve_view=True)
        self.status.setText(f"Preview generated: {pal}")

    def _set_preview_image(self, qimg: QImage, *, fit: bool = False, preserve_view: bool = True):
        state = None
        if preserve_view and (not fit) and (self._base_pm is not None):
            state = self._capture_view_state()

        self._base_pm = QPixmap.fromImage(qimg)

        # If we’re fitting, ignore old zoom/pan.
        if fit or state is None:
            self._zoom = 1.0
            self._update_preview_pixmap()
            if fit:
                QTimer.singleShot(0, self._fit_to_preview)
            else:
                QTimer.singleShot(0, self._center_scrollbars)
            return

        # restore prior zoom/pan
        self._restore_view_state(state)


    def _update_preview_pixmap(self):
        if self._base_pm is None:
            return
        # explicit int size (QSize * float can crash on some PyQt6 builds)
        base_sz = self._base_pm.size()
        w = max(1, int(base_sz.width() * self._zoom))
        h = max(1, int(base_sz.height() * self._zoom))
        scaled = self._base_pm.scaled(
            w, h,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        self.preview.setPixmap(scaled)
        self.preview.resize(scaled.size())

    def _set_zoom(self, new_zoom: float):
        self._zoom = max(self._min_zoom, min(self._max_zoom, new_zoom))
        self._update_preview_pixmap()

    def _zoom_at(self, factor: float = 1.25, anchor_vp: QPoint | None = None):
        if self._base_pm is None:
            return

        vp = self.scroll.viewport()
        if anchor_vp is None:
            anchor_vp = QPoint(vp.width() // 2, vp.height() // 2)  # view center

        # label coords under the anchor *before* zoom
        lbl_before = self.preview.mapFrom(vp, anchor_vp)

        old_zoom = self._zoom
        new_zoom = max(self._min_zoom, min(self._max_zoom, old_zoom * factor))
        ratio = new_zoom / max(old_zoom, 1e-6)
        if abs(ratio - 1.0) < 1e-6:
            return

        # apply zoom (updates label size & scrollbar ranges)
        self._zoom = new_zoom
        self._update_preview_pixmap()

        # desired label coords *after* zoom
        lbl_after_x = int(lbl_before.x() * ratio)
        lbl_after_y = int(lbl_before.y() * ratio)

        # move scrollbars so anchor_vp keeps the same content point
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()
        hbar.setValue(max(hbar.minimum(), min(hbar.maximum(), lbl_after_x - anchor_vp.x())))
        vbar.setValue(max(vbar.minimum(), min(vbar.maximum(), lbl_after_y - anchor_vp.y())))


    def _fit_to_preview(self):
        if self._base_pm is None:
            return
        vp = self.scroll.viewport().size()
        pm = self._base_pm.size()
        if pm.width() == 0 or pm.height() == 0:
            return
        k = min(vp.width() / pm.width(), vp.height() / pm.height())
        self._set_zoom(max(self._min_zoom, min(self._max_zoom, k)))
        self._center_scrollbars()

    def _center_scrollbars(self):
        # center the view on the image
        h = self.scroll.horizontalScrollBar()
        v = self.scroll.verticalScrollBar()
        h.setValue((h.maximum() + h.minimum()) // 2)
        v.setValue((v.maximum() + v.minimum()) // 2)

    def _foraxx_gate(self, x):
        """Foraxx-style dynamic gate: x^(1-x), clipped to [0,1] domain.
        Rises 0→1 across the input but stays high through the midrange,
        so blends lean toward the 'present' signal without hard thresholds."""
        x = np.clip(np.nan_to_num(x), 1e-6, 1.0)
        return x ** (1.0 - x)

    def _map_channels_or_special(self, name, ha, oo, si):
        # Record TRUE presence before substitution masks it, so Foraxx can
        # pick real-tricolor vs bicolor correctly.
        has_real_si = si is not None
        has_real_ha = ha is not None

        # substitution — fill the missing channel from the other two (or clone
        # the one available).  Any two of {Ha, OIII, SII} are enough.
        if ha is None and si is not None: ha = si
        if si is None and ha is not None: si = ha
        if oo is None:
            if ha is not None: oo = ha
            elif si is not None: oo = si

        basic = {
            "SHO": (si, ha, oo),
            "HOO": (ha, oo, oo),
            "HSO": (ha, si, oo),
            "HOS": (ha, oo, si),
            "OSS": (oo, si, si),
            "OHH": (oo, ha, ha),
            "OSH": (oo, si, ha),
            "OHS": (oo, ha, si),
            "HSS": (ha, si, si),
            "SOH": (si, oo, ha),   # completes the 6 full permutations
            "SHH": (si, ha, ha),   # SII-red bicolor
            "SOO": (si, oo, oo),   # SII-red / OIII bicolor
            "HHO": (ha, ha, oo),   # Ha-forward warm bicolor
            "OOS": (oo, oo, si),   # OIII-forward cool bicolor            
        }
        if name in basic:
            return basic[name]

        try:
            if name == "Realistic1":
                r = (ha + si)/2 if (ha is not None and si is not None) else (ha if ha is not None else 0)
                g = 0.3*(ha if ha is not None else 0) + 0.7*(oo if oo is not None else 0)
                b = 0.9*(oo if oo is not None else 0) + 0.1*(ha if ha is not None else 0)
                return r,g,b
            if name == "Realistic2":
                r = 0.7*(ha if ha is not None else 0) + 0.3*(si if si is not None else 0)
                g = 0.3*(si if si is not None else 0) + 0.7*(oo if oo is not None else 0)
                b = (oo if oo is not None else 0)
                return r,g,b
            if name == "Foraxx":
                # Bicolor Foraxx: Ha + OIII only (no real SII)
                if has_real_ha and oo is not None and not has_real_si:
                    r = ha
                    b = oo
                    t = self._foraxx_gate(ha * oo)
                    g = t * ha + (1.0 - t) * oo
                    return r, g, b
                # Tricolor Foraxx: real Ha + OIII + SII
                if has_real_si and oo is not None and (ha is not None):
                    t  = self._foraxx_gate(oo)
                    r  = t * si + (1.0 - t) * ha
                    t2 = self._foraxx_gate(ha * oo)
                    g  = t2 * ha + (1.0 - t2) * oo
                    b  = oo
                    return r, g, b
                return basic["SHO"]
            if name == "Dynamic Inverse":
                S = np.clip(np.nan_to_num(ha), 0.0, 1.0)
                O = np.clip(np.nan_to_num(oo), 0.0, 1.0)
                H = np.clip(np.nan_to_num(si), 0.0, 1.0)

                # Red: Ha in OIII-voids, SII in OIII-rich zones.
                tO = 1.0 - O
                r  = tO * H + (1.0 - tO) * S

                # Green: OIII fills the Ha gaps (gated by Ha absence).
                tH = self._foraxx_gate(1.0 - H)
                g  = (1.0 - tH) * H + tH * O

                # Blue: OIII, biased into Ha-free regions.
                b  = tH * O + (1.0 - tH) * (0.5 * O)

                r = np.clip(r, 0.0, 1.0)
                g = np.clip(g, 0.0, 1.0)
                b = np.clip(b, 0.0, 1.0)
                return r, g, b
        except Exception:
            return basic.get("SHO", (ha, oo, si))

        return basic.get("SHO", (ha, oo, si))

    def _toggle_gallery(self, on: bool):
        if on:
            self._gallery.show()
            self._gallery.raise_()
        else:
            self._gallery.hide()

    # ------------- push to new subwindow -------------
    def _get_doc_manager(self):
        """
        Try several ways to get a DocManager:
        1) explicit doc_manager passed into PerfectPalettePicker
        2) main window's .docman or .doc_manager attribute
        """
        if self.doc_manager is not None:
            return self.doc_manager

        mw = self._find_main_window()
        if mw is None:
            return None

        return getattr(mw, "docman", None) or getattr(mw, "doc_manager", None)

    def _push_final(self):
        if self.final is None:
            QMessageBox.warning(self, "No Image", "Generate a palette first.")
            return

        # Use the SAME prepared channels the palette was built with
        ha_prep, oo_prep, si_prep = self._prepared_channels()
        has_narrowband = sum(x is not None for x in (ha_prep, oo_prep, si_prep))
        if has_narrowband < 2:
            QMessageBox.warning(self, "Need Channels",
                "Load any two of Ha / OIII / SII, or one OSC image.")
            return

        dlg = PaletteAdjustDialog(
            base_rgb     = self.final,                           # fully formed palette
            palette_name = self.current_palette or "SHO",
            ha_src       = ha_prep,                              # prepared (stretched/OSC-synth)
            oiii_src     = oo_prep,
            sii_src      = si_prep,
            owner        = self
        )
        adjusted = {"img": None}
        dlg.adjusted_image.connect(lambda img: adjusted.__setitem__("img", img))
        dlg.exec()

        if adjusted["img"] is None:
            return  # user canceled

        # Update preview with adjusted result and set as final
        self.final = adjusted["img"]
        self._set_preview_image(self._to_qimage(self.final))

        title = self.current_palette or "Palette"

        # ---- get DocManager the robust way ----
        dm = self._get_doc_manager()

        if dm is None:
            # Fallback: open a simple viewer instead of erroring out
            viewer = QDialog(self)
            viewer.setWindowTitle(title)
            vlayout = QVBoxLayout(viewer)
            lbl = QLabel()
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl.setPixmap(QPixmap.fromImage(self._to_qimage(self.final)))
            vlayout.addWidget(lbl)
            viewer.resize(lbl.pixmap().size())
            viewer.show()
            # keep ref so it isn't GC'd
            self._last_popup_viewer = viewer
            self.status.setText("DocManager not found; opened palette in stand-alone viewer.")
            return

        # ---- normal SAS path: create a new document ----
        try:
            if hasattr(dm, "open_array"):
                # many of your tools already use this signature
                doc = dm.open_array(self.final, metadata={"is_mono": False}, title=title)
            elif hasattr(dm, "create_document"):
                doc = dm.create_document(image=self.final, metadata={"is_mono": False}, name=title)
            else:
                raise RuntimeError("DocManager lacks open_array/create_document")

            # If DocManager or main window auto-spawns subwindows on new docs,
            # this is all we need. If not, you can optionally keep the
            # _spawn_subwindow_for hook here.
            self.status.setText("Opened final palette in a new view.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open new view:\n{e}")



    # ------------- utilities -------------
    def _clear_channels(self):
        self.ha = self.oiii = self.sii = self.osc1 = self.osc2 = None
        self._stretched.clear()
        self._dim_mismatch_accepted = False
        self.final = None
        self.preview.clear()
        for which in ("Ha","OIII","SII","OSC1","OSC2"):
            self._set_status_label(which, None)
        for name, b in self._thumb_buttons.items():
            b.setIcon(QIcon())
        self._thumb_base_pm.clear()
        self._selected_name = None
        for b in self._thumb_buttons.values():
            b.setIcon(QIcon())
        self.status.setText("Cleared all loaded channels.")

    def _as_float01(self, arr):
        a = np.asarray(arr)
        if a.dtype == np.uint8:  return a.astype(np.float32)/255.0
        if a.dtype == np.uint16: return a.astype(np.float32)/65535.0
        return np.clip(a.astype(np.float32), 0.0, 1.0)

    def _stretch_input(self, img):
        """Run statistical stretch on mono or color inputs (target_median=0.25)."""
        if img.ndim == 2:
            return np.clip(stretch_mono_image(img, target_median=0.25), 0.0, 1.0)
        if img.ndim == 3 and img.shape[2] == 3:
            return np.clip(stretch_color_image(img, target_median=0.25, linked=False), 0.0, 1.0)
        if img.ndim == 3 and img.shape[2] == 1:
            mono = img[...,0]
            return np.clip(stretch_mono_image(mono, target_median=0.25), 0.0, 1.0)
        return img

    def _to_qimage(self, arr):
        a = np.clip(arr, 0, 1)
        if a.ndim == 2:
            u = (a * 255).astype(np.uint8); h, w = u.shape
            return QImage(u.data, w, h, w, QImage.Format.Format_Grayscale8).copy()
        if a.ndim == 3 and a.shape[2] == 3:
            u = (a * 255).astype(np.uint8); h, w, _ = u.shape
            return QImage(u.data, w, h, w*3, QImage.Format.Format_RGB888).copy()
        raise ValueError(f"Unexpected image shape: {a.shape}")

    def _find_main_window(self):
        from PyQt6.QtWidgets import QMainWindow, QApplication

        # 1) walk parents first
        w = self
        while w is not None:
            if isinstance(w, QMainWindow):
                return w
            w = w.parentWidget()

        app = QApplication.instance()
        if app is None:
            return None

        # 2) prefer active window if it's a QMainWindow
        aw = app.activeWindow()
        if isinstance(aw, QMainWindow):
            return aw

        # 3) prefer one that has an mdi attribute (your real main window does)
        for tlw in app.topLevelWidgets():
            if isinstance(tlw, QMainWindow) and hasattr(tlw, "mdi"):
                return tlw

        # 4) last resort: any QMainWindow
        for tlw in app.topLevelWidgets():
            if isinstance(tlw, QMainWindow):
                return tlw

        return None

    def _list_open_views(self):
        mw = self._find_main_window()
        if mw is None:
            return []

        # Import ImageSubWindow (same class you showed)
        try:
            from setiastro.saspro.subwindow import ImageSubWindow
        except Exception:
            ImageSubWindow = None

        out = []

        # ── 1) Best source: MDI subWindowList() ─────────────────────────────
        mdi = getattr(mw, "mdi", None)
        if mdi is not None:
            try:
                for sub in mdi.subWindowList():
                    try:
                        view = sub.widget()  # should be ImageSubWindow
                        if ImageSubWindow is not None and not isinstance(view, ImageSubWindow):
                            continue

                        doc = getattr(view, "document", None)
                        img = getattr(doc, "image", None) if doc is not None else None
                        if img is None:
                            continue

                        # Clean, user-visible title (your view emits clean core titles already)
                        title = ""
                        try:
                            title = (sub.windowTitle() or "").strip()
                        except Exception:
                            title = ""
                        if not title:
                            try:
                                title = (view._effective_title() or "").strip()
                            except Exception:
                                title = ""
                        if not title:
                            try:
                                title = (doc.display_name() or "").strip()
                            except Exception:
                                title = "Untitled"

                        out.append((title, sub))
                    except Exception:
                        continue
            except Exception:
                pass

        # ── 2) Fallback: your registry (VERY reliable) ──────────────────────
        if not out and ImageSubWindow is not None:
            try:
                # registry holds ImageSubWindow widgets
                for view in list(ImageSubWindow._registry.values()):
                    try:
                        doc = getattr(view, "document", None)
                        img = getattr(doc, "image", None) if doc is not None else None
                        if img is None:
                            continue

                        sub = None
                        try:
                            sub = view._mdi_subwindow()
                        except Exception:
                            sub = None
                        if sub is None:
                            continue

                        title = ""
                        try:
                            title = (sub.windowTitle() or "").strip()
                        except Exception:
                            title = ""
                        if not title:
                            try:
                                title = (view._effective_title() or "").strip()
                            except Exception:
                                title = ""
                        if not title:
                            try:
                                title = (doc.display_name() or "").strip()
                            except Exception:
                                title = "Untitled"

                        out.append((title, sub))
                    except Exception:
                        continue
            except Exception:
                pass

        # De-dupe titles (keep stable order; disambiguate duplicates)
        seen = set()
        uniq = []
        for t, sub in out:
            tt = str(t)
            if tt in seen:
                i = 2
                cand = f"{tt} ({i})"
                while cand in seen:
                    i += 1
                    cand = f"{tt} ({i})"
                tt = cand
            seen.add(tt)
            uniq.append((tt, sub))

        return uniq

    
    def eventFilter(self, obj, ev):
        # Ctrl+wheel = zoom at mouse (no scrolling). Wheel without Ctrl = eaten.
        # Wheel = zoom at mouse (plain wheel + Ctrl+wheel). No scrolling.
        if ev.type() == QEvent.Type.Wheel and (
            obj is self.preview
            or obj is self.scroll
            or obj is self.scroll.viewport()
            or obj is self.scroll.horizontalScrollBar()
            or obj is self.scroll.verticalScrollBar()
        ):
            # always stop the wheel from scrolling
            ev.accept()

            # Get mouse position in global screen coords and map into the viewport
            vp = self.scroll.viewport()
            anchor_vp = vp.mapFromGlobal(ev.globalPosition().toPoint())

            # Clamp to viewport rect (robust if the event originated on scrollbars)
            r = vp.rect()
            if not r.contains(anchor_vp):
                anchor_vp.setX(max(r.left(),  min(r.right(),  anchor_vp.x())))
                anchor_vp.setY(max(r.top(),   min(r.bottom(), anchor_vp.y())))

            dy = ev.pixelDelta().y()

            if dy != 0:
                abs_dy = abs(dy)
                ctrl_down = bool(ev.modifiers() & Qt.KeyboardModifier.ControlModifier)

                if abs_dy <= 3:
                    base_factor = 1.012 if ctrl_down else 1.010
                elif abs_dy <= 10:
                    base_factor = 1.025 if ctrl_down else 1.020
                else:
                    base_factor = 1.040 if ctrl_down else 1.030

                factor = base_factor if dy > 0 else 1.0 / base_factor
            else:
                dy = ev.angleDelta().y()
                if dy == 0:
                    return True

                ctrl_down = bool(ev.modifiers() & Qt.KeyboardModifier.ControlModifier)
                step = 1.25 if ctrl_down else 1.15
                factor = step if dy > 0 else 1.0 / step

            self._zoom_at(factor, anchor_vp)
            return True
        # click-drag pan on viewport
        if obj is self.scroll.viewport():
            if ev.type() == QEvent.Type.MouseButtonPress and ev.button() == Qt.MouseButton.LeftButton:
                self._panning = True
                self._pan_last = ev.position().toPoint()
                self.scroll.viewport().setCursor(QCursor(Qt.CursorShape.ClosedHandCursor))
                return True
            if ev.type() == QEvent.Type.MouseMove and self._panning:
                cur = ev.position().toPoint()
                delta = cur - (self._pan_last or cur)
                self._pan_last = cur
                h = self.scroll.horizontalScrollBar()
                v = self.scroll.verticalScrollBar()
                h.setValue(h.value() - delta.x())
                v.setValue(v.value() - delta.y())
                return True
            if ev.type() == QEvent.Type.MouseButtonRelease and ev.button() == Qt.MouseButton.LeftButton:
                self._panning = False
                self._pan_last = None
                self.scroll.viewport().setCursor(QCursor(Qt.CursorShape.ArrowCursor))
                return True

        return super().eventFilter(obj, ev)    