# src/setiastro/saspro/cosmicclarity_engines/denoise_engine.py
from __future__ import annotations

import os
import warnings
from dataclasses import dataclass
from typing import Optional, Dict, Any, Tuple

import numpy as np

import cv2


from setiastro.saspro.resources import get_resources
from setiastro.saspro.runtime_torch import _user_runtime_dir, _venv_paths, _check_cuda_in_venv
from setiastro.saspro.runtime_torch import np_to_torch, torch_to_np, mps_is_usable

warnings.filterwarnings("ignore")

from typing import Callable

ProgressCB = Callable[[int, int], bool]  # True=continue, False=cancel

from setiastro.saspro.cosmicclarity_engines._backend_guard import (
    DeviceLostError,
    EngineCancelled as DenoiseCancelled,
    safe_exception_str,
    is_device_lost_error as _is_device_lost_error,
    is_backend_unusable_error as _is_backend_unusable_error,
    is_recoverable_batch_error as _is_recoverable_batch_error,
    iter_batch_sizes as _iter_batch_sizes,
    dml_disabled as _dml_disabled,
    disable_dml as _disable_dml,
    prefer_ort_dml as _prefer_ort_dml,
    cap_chunk_size_for_device as _cap_chunk_size_for_device,
    tick as _tick,
)
from setiastro.saspro.cosmicclarity_engines import _backend_guard as _bg


def _evict_models(models) -> None:
    _bg.evict_models(_MODELS_CACHE, models, tag="CC Denoise")

def _get_torch(*, prefer_cuda: bool, prefer_dml: bool, status_cb=print):
    from setiastro.saspro.runtime_torch import import_torch
    return import_torch(
        prefer_cuda=prefer_cuda,
        prefer_xpu=False,
        prefer_dml=prefer_dml,
        status_cb=status_cb,
    )

def _get_ort(status_cb=print):
    try:
        import onnxruntime as ort
        return ort
    except ImportError as e:
        try:
            status_cb(f"CosmicClarity Denoise: onnxruntime not installed ({e})")
        except Exception:
            pass
        return None
    except Exception as e:
        # Catches load errors like missing libcudart — ORT is installed but broken
        try:
            status_cb(f"CosmicClarity Denoise: onnxruntime failed to load ({type(e).__name__}: {e}) — falling back to torch backend.")
        except Exception:
            pass
        return None


def _nullcontext():
    from contextlib import nullcontext
    return nullcontext()


def _autocast_context(torch, device) -> Any:
    try:
        dev = str(getattr(device, "type", device)).lower()
        
        # privateuseone = torch-directml — no autocast support
        if dev == "privateuseone":
            return _nullcontext()

        if dev == "cuda":
            major, minor = torch.cuda.get_device_capability()
            if float(f"{major}.{minor}") >= 8.0:
                if hasattr(torch, "amp") and hasattr(torch.amp, "autocast"):
                    return torch.amp.autocast(device_type="cuda")
                return torch.cuda.amp.autocast()

        elif dev == "mps":
            if hasattr(torch, "amp") and hasattr(torch.amp, "autocast"):
                return torch.amp.autocast(device_type="mps")

    except Exception:
        pass

    return _nullcontext()


# ============================
# DROP-IN REPLACEMENT METHODS
# for: src/setiastro/saspro/cosmicclarity_engines/denoise_engine.py
# (NAFNet-style model bundle + backend resolution + padded infer like sharpen_engine)
# ============================

# ---- NEW: match sharpen_engine-style NAFNet configs ----
_DENOISE_NAFNET_FULL = dict(
    width=64,
    enc_blk_nums=(2, 4, 6, 8),
    dec_blk_nums=(2, 2, 2, 2),
    middle_blk_num=4,
)

_DENOISE_NAFNET_LITE = dict(
    width=32,
    enc_blk_nums=(2, 4, 6, 8),
    dec_blk_nums=(2, 2, 2, 2),
    middle_blk_num=4,
)

# ---- NEW: dataclass bundle like sharpen ----
@dataclass
class DenoiseModels:
    device: Any
    is_onnx: bool
    mono: Any
    color: Any
    torch: Any | None = None
    variant: str = "full"   # "full", "lite", or "walking"
    mono_path: str = ""
    color_path: str = ""

# Cache by (backend_tag, resolved_backend)
_MODELS_CACHE: dict[tuple[str, str], DenoiseModels] = {}
_BACKEND_TAG = "cc_denoise_ai4_nafnet"

# DeviceLostError, DenoiseCancelled, _prefer_ort_dml, _is_device_lost_error,
# _tick and _evict_models all come from _backend_guard now — see the import
# block at the top of this file. The local copies that used to live here were
# shadowing those imports, which meant this module's DeviceLostError was a
# different class object from the one _backend_guard.is_device_lost_error()
# isinstance-checks against, and no other engine could catch it.


def _pad2d_to_multiple(x: np.ndarray, mult: int = 16, mode: str = "reflect") -> tuple[np.ndarray, int, int]:
    """Pad 2D array on bottom/right so H,W are multiples of `mult`."""
    h, w = x.shape
    ph = (mult - (h % mult)) % mult
    pw = (mult - (w % mult)) % mult
    if ph == 0 and pw == 0:
        return x, h, w
    xp = np.pad(x, ((0, ph), (0, pw)), mode=mode)
    return xp, h, w


def _ort_pick_io_names_single_input(session) -> tuple[str, str]:
    """
    Returns: (img_name, out_name) for a 1-input denoise model.
    If exporter ever produces extra inputs, we still pick the rank-4 input as image.
    """
    ins = session.get_inputs()
    out = session.get_outputs()[0].name

    img_name = None
    for i in ins:
        shp = i.shape
        rank = len(shp) if shp is not None else 0
        if rank == 4:
            img_name = i.name
            break

    if img_name is None:
        img_name = ins[0].name

    return img_name, out


def _load_onnx_models(ort, *, lite: bool, walking: bool = False) -> DenoiseModels:
    prov = ["DmlExecutionProvider", "CPUExecutionProvider"]
    R = get_resources()

    def s(path: str):
        so = ort.SessionOptions()
        so.intra_op_num_threads = 1
        so.inter_op_num_threads = 1
        return ort.InferenceSession(path, sess_options=so, providers=prov)

    if walking:
        mono_path  = R.CC_DENOISE_MONO_WALKING_ONNX
        color_path = R.CC_DENOISE_COLOR_WALKING_ONNX
    elif lite:
        mono_path  = R.CC_DENOISE_MONO_ONNX_LITE
        color_path = R.CC_DENOISE_COLOR_ONNX_LITE
    else:
        mono_path  = R.CC_DENOISE_MONO_ONNX
        color_path = R.CC_DENOISE_COLOR_ONNX

    mono_sess  = s(mono_path)
    color_sess = s(color_path)

    return DenoiseModels(
        device="DirectML",
        is_onnx=True,
        mono=mono_sess,
        color=color_sess,
        torch=None,
        variant=("walking" if walking else "lite" if lite else "full"),
        mono_path=str(mono_path),
        color_path=str(color_path),
    )

def _load_torch_models(torch, device, *, lite: bool, walking: bool = False) -> DenoiseModels:
    import torch.nn as nn

    # ---- NAFNet blocks (same style as sharpen_engine) ----
    class LayerNorm2d(nn.Module):
        def __init__(self, channels, eps=1e-6):
            super().__init__()
            self.weight = nn.Parameter(torch.ones(1, channels, 1, 1))
            self.bias   = nn.Parameter(torch.zeros(1, channels, 1, 1))
            self.eps = eps

        def forward(self, x):
            mean = x.mean(dim=1, keepdim=True)
            var  = (x - mean).pow(2).mean(dim=1, keepdim=True)
            x = (x - mean) / torch.sqrt(var + self.eps)
            return x * self.weight + self.bias

    class SimpleGate(nn.Module):
        def forward(self, x):
            x1, x2 = x.chunk(2, dim=1)
            return x1 * x2

    class GlobalAvgPool2d(nn.Module):
        """
        Drop-in for nn.AdaptiveAvgPool2d(1). Numerically identical, but avoids
        the adaptive-pool op, which is a long-standing weak spot on
        torch-directml. Parameterless, so state_dict keys are unchanged.
        """
        def forward(self, x):
            return x.mean(dim=(2, 3), keepdim=True)

    class NAFBlock(nn.Module):
        def __init__(self, channels):
            super().__init__()
            self.norm1 = LayerNorm2d(channels)
            self.conv1 = nn.Conv2d(channels, channels * 2, 1, bias=True)
            self.dwconv = nn.Conv2d(
                channels * 2, channels * 2, 3,
                padding=1, groups=channels * 2, bias=True
            )
            self.sg = SimpleGate()
            self.sca = nn.Sequential(
                GlobalAvgPool2d(),
                nn.Conv2d(channels, channels, 1, bias=True),
            )
            self.conv2 = nn.Conv2d(channels, channels, 1, bias=True)

            self.norm2 = LayerNorm2d(channels)
            self.ffn1 = nn.Conv2d(channels, channels * 2, 1, bias=True)
            self.ffn2 = nn.Conv2d(channels, channels, 1, bias=True)

            self.beta  = nn.Parameter(torch.zeros(1, channels, 1, 1))
            self.gamma = nn.Parameter(torch.zeros(1, channels, 1, 1))

        def forward(self, x):
            y = self.norm1(x)
            y = self.conv1(y)
            y = self.dwconv(y)
            y = self.sg(y)
            y = y * self.sca(y)
            y = self.conv2(y)
            x = x + y * self.beta

            y = self.norm2(x)
            y = self.ffn1(y)
            y = self.sg(y)
            y = self.ffn2(y)
            x = x + y * self.gamma
            return x

    class NAFNetDenoise(nn.Module):
        """
        RGB->RGB denoise. Uses residual-out (y = x + delta) by default like sharpen.
        (If your training exported absolute output, set residual_out=False.)
        """
        def __init__(
            self,
            in_ch=3, out_ch=3, width=32,
            enc_blk_nums=(2, 4, 6, 8),
            dec_blk_nums=(2, 2, 2, 2),
            middle_blk_num=4,
            residual_out=True,
            clamp_out=False,
        ):
            super().__init__()
            self.intro = nn.Conv2d(in_ch, width, 3, padding=1, bias=True)

            self.encoders = nn.ModuleList()
            self.downs    = nn.ModuleList()
            self.decoders = nn.ModuleList()
            self.ups      = nn.ModuleList()

            ch = width
            for n in enc_blk_nums:
                self.encoders.append(nn.Sequential(*[NAFBlock(ch) for _ in range(n)]))
                self.downs.append(nn.Conv2d(ch, ch * 2, 2, stride=2, bias=True))
                ch *= 2

            self.middle = nn.Sequential(*[NAFBlock(ch) for _ in range(middle_blk_num)])

            for n in dec_blk_nums:
                self.ups.append(nn.Sequential(nn.Conv2d(ch, ch * 2, 1, bias=True), nn.PixelShuffle(2)))
                ch //= 2
                self.decoders.append(nn.Sequential(*[NAFBlock(ch) for _ in range(n)]))

            self.ending = nn.Conv2d(width, out_ch, 3, padding=1, bias=True)

            self.residual_out = bool(residual_out)
            self.clamp_out = bool(clamp_out)

        def forward_delta(self, x):
            x = self.intro(x)
            skips = []
            for enc, down in zip(self.encoders, self.downs):
                x = enc(x); skips.append(x); x = down(x)
            x = self.middle(x)
            for up, dec in zip(self.ups, self.decoders):
                x = up(x)
                sk = skips.pop()
                if x.shape != sk.shape:
                    x = x[:, :, :sk.shape[2], :sk.shape[3]]
                x = x + sk
                x = dec(x)
            return self.ending(x)

        def forward(self, x):
            delta = self.forward_delta(x)
            if self.residual_out:
                if x.shape != delta.shape:
                    x = x[:, :, :delta.shape[2], :delta.shape[3]]
                y = x + delta
            else:
                y = delta
            if self.clamp_out:
                y = y.clamp(0.0, 1.0)
            return y

    R = get_resources()

    cfg = _DENOISE_NAFNET_LITE if lite else _DENOISE_NAFNET_FULL

    def m_naf_rgb(path: str, cfg: dict):
        net = NAFNetDenoise(**cfg, residual_out=True, clamp_out=False)
        sd = torch.load(path, map_location="cpu")
        if isinstance(sd, dict) and "model_state_dict" in sd:
            sd = sd["model_state_dict"]
        net.load_state_dict(sd)
        net.eval()
        return net.to(device)

    if walking:
        mono_path  = getattr(R, "CC_DENOISE_MONO_WALKING_PTH", None)
        color_path = getattr(R, "CC_DENOISE_COLOR_WALKING_PTH", None)
    elif lite:
        mono_path  = getattr(R, "CC_DENOISE_MONO_PTH_LITE", None)
        color_path = getattr(R, "CC_DENOISE_COLOR_PTH_LITE", None)
    else:
        mono_path  = getattr(R, "CC_DENOISE_MONO_PTH", None)
        color_path = getattr(R, "CC_DENOISE_COLOR_PTH", None)

    if not mono_path or not os.path.exists(mono_path):
        raise RuntimeError("Denoise: MONO model not found for selected variant.")
    if not color_path or not os.path.exists(color_path):
        raise RuntimeError("Denoise: COLOR model not found for selected variant.")

    mono  = m_naf_rgb(mono_path,  cfg)
    color = m_naf_rgb(color_path, cfg)

    return DenoiseModels(
        device=device,
        is_onnx=False,
        mono=mono,
        color=color,
        torch=torch,
        variant=("walking" if walking else "lite" if lite else "full"),
        mono_path=str(mono_path),
        color_path=str(color_path),
    )


def load_models(use_gpu: bool = True, *, lite: bool = False, walking: bool = False, status_cb=print) -> DenoiseModels:
    # walking overrides lite — no lite walking model
    if walking:
        lite = False
    backend_tag = _BACKEND_TAG + ("_walking" if walking else "_lite" if lite else "_full")
    is_windows = (os.name == "nt")

    torch = _get_torch(
        prefer_cuda=bool(use_gpu),
        prefer_dml=bool(use_gpu and is_windows),
        status_cb=status_cb,
    )
    ort = _get_ort(status_cb=status_cb)

    # 1) CUDA
    if use_gpu:
        try:
            cuda_ok = bool(getattr(torch, "cuda", None) and torch.cuda.is_available())
        except Exception:
            cuda_ok = False

        if cuda_ok:
            cache_key = (backend_tag, "cuda")
            if cache_key in _MODELS_CACHE:
                return _MODELS_CACHE[cache_key]

            device = torch.device("cuda")
            models = _load_torch_models(torch, device, lite=lite, walking=walking)
            _MODELS_CACHE[cache_key] = models
            return models

    # 2) MPS
    if use_gpu:
        try:
            # is_available() is True on Intel Macs with a Metal-capable Radeon,
            # but MPS faults on first use there ("Numpy is not available"). The
            # shared gate is Apple-Silicon-only, so Intel falls through to CPU.
            mps_ok = mps_is_usable(torch)
        except Exception:
            mps_ok = False

        if mps_ok:
            cache_key = (backend_tag, "mps")
            if cache_key in _MODELS_CACHE:
                return _MODELS_CACHE[cache_key]

            device = torch.device("mps")
            models = _load_torch_models(torch, device, lite=lite, walking=walking)
            _MODELS_CACHE[cache_key] = models
            return models

    # 3) Torch-DirectML
    if use_gpu and is_windows and not _dml_disabled() and not _prefer_ort_dml():
        try:
            from setiastro.saspro.runtime_torch import directml_probe_ok
            if not directml_probe_ok(status_cb):
                raise RuntimeError("torch-directml unavailable (subprocess probe failed)")
            import torch_directml
            cache_key = (backend_tag, "dml_torch")
            if cache_key in _MODELS_CACHE:
                return _MODELS_CACHE[cache_key]

            dml = torch_directml.device()
            _ = (torch.ones(1, device=dml) + 1).to("cpu").item()

            models = _load_torch_models(torch, dml, lite=lite, walking=walking)
            _MODELS_CACHE[cache_key] = models
            return models

        except Exception as e:
            status_cb(f"CosmicClarity Denoise: DirectML (torch-directml) failed, falling back. {type(e).__name__}: {e}")

    # 4) ORT DirectML
    # Also gated on _dml_disabled(): if the adapter just hung under
    # torch-directml it will hang again under ORT on the same workload. Drop the
    # `and not _dml_disabled()` here if you'd rather try ORT before CPU.
    if use_gpu and ort is not None and not _dml_disabled():
        try:
            prov = ort.get_available_providers()
        except Exception:
            prov = []

        if "DmlExecutionProvider" in prov:
            cache_key = (backend_tag, "dml_ort")
            if cache_key in _MODELS_CACHE:
                return _MODELS_CACHE[cache_key]

            models = _load_onnx_models(ort, lite=lite, walking=walking)
            _MODELS_CACHE[cache_key] = models
            return models

    # 5) CPU
    cache_key = (backend_tag, "cpu")
    if cache_key in _MODELS_CACHE:
        return _MODELS_CACHE[cache_key]

    device = torch.device("cpu")
    models = _load_torch_models(torch, device, lite=lite, walking=walking)
    _MODELS_CACHE[cache_key] = models
    return models

def _infer_chunk_rgb(models: DenoiseModels, model: Any, chunk_rgb: np.ndarray) -> np.ndarray:
    """
    Single-tile fallback helper.
    """
    chunk_rgb = np.asarray(chunk_rgb, np.float32)
    h0, w0 = chunk_rgb.shape[:2]

    ph = (16 - (h0 % 16)) % 16
    pw = (16 - (w0 % 16)) % 16
    if ph or pw:
        chunk_p = np.pad(chunk_rgb, ((0, ph), (0, pw), (0, 0)), mode="reflect")
    else:
        chunk_p = chunk_rgb

    if models.is_onnx:
        inp = np.ascontiguousarray(np.transpose(chunk_p, (2, 0, 1))[None, ...])  # (1,3,H,W)
        name_img, name_out = _ort_pick_io_names_single_input(model)
        out = model.run([name_out], {name_img: inp})[0]
        if out.ndim != 4:
            raise RuntimeError(f"Unexpected ONNX output shape: {out.shape}")
        y = np.transpose(out[0], (1, 2, 0))
        return y[:h0, :w0].astype(np.float32, copy=False)

    torch = models.torch
    dev = models.device

    inp = np.ascontiguousarray(np.transpose(chunk_p, (2, 0, 1))[None, ...])  # (1,3,H,W)
    t = np_to_torch(inp, device=dev, torch=torch)

    with torch.no_grad(), _autocast_context(torch, dev):
        y = torch_to_np(model(t)[0].detach().float())

    y = np.transpose(y, (1, 2, 0))
    return y[:h0, :w0].astype(np.float32, copy=False)

def _infer_chunk_2d(models: DenoiseModels, model: Any, chunk2d: np.ndarray) -> np.ndarray:
    """
    Single-tile fallback helper.
    Kept lean, but batching is where the real win is.
    """
    chunk2d = np.asarray(chunk2d, np.float32)
    chunk_p, h0, w0 = _pad2d_to_multiple(chunk2d, mult=16, mode="reflect")

    if models.is_onnx:
        inp = np.repeat(chunk_p[None, None, :, :], 3, axis=1).astype(np.float32, copy=False)
        name_img, name_out = _ort_pick_io_names_single_input(model)
        out = model.run([name_out], {name_img: inp})[0]

        if out.ndim == 4:
            y = out[0, 0]
        elif out.ndim == 3:
            y = out[0]
            if y.shape[0] in (1, 3):
                y = y[0]
        else:
            raise RuntimeError(f"Unexpected ONNX output shape: {out.shape}")

        return y[:h0, :w0].astype(np.float32, copy=False)

    torch = models.torch
    dev = models.device

    t = np_to_torch(chunk_p, device=dev, torch=torch).unsqueeze(0).unsqueeze(0)
    t3 = t.expand(-1, 3, -1, -1).contiguous()

    with torch.no_grad(), _autocast_context(torch, dev):
        y = model(t3)
        y = torch_to_np(y[0, 0].detach().float())

    return y[:h0, :w0].astype(np.float32, copy=False)

# ----------------------------
# Your helpers: luminance/chroma, chunks, borders, stretch
# (paste your existing implementations here)
# ----------------------------
def extract_luminance(image: np.ndarray):
    """
    Input: mono HxW, mono HxWx1, or RGB HxWx3 float32 in [0,1].
    Output: (Y, Cb, Cr) where:
      - Y is HxW
      - Cb/Cr are HxW in [0,1] (with +0.5 offset already applied)
    """
    x = np.asarray(image, dtype=np.float32)

    # Ensure 3-channel
    if x.ndim == 2:
        x = np.stack([x, x, x], axis=-1)
    elif x.ndim == 3 and x.shape[-1] == 1:
        x = np.repeat(x, 3, axis=-1)

    if x.ndim != 3 or x.shape[-1] != 3:
        raise ValueError("extract_luminance expects HxW, HxWx1, or HxWx3")

    # RGB -> YCbCr (BT.601) (same numbers as your sharpen_engine)
    M = np.array([[0.299, 0.587, 0.114],
                  [-0.168736, -0.331264, 0.5],
                  [0.5, -0.418688, -0.081312]], dtype=np.float32)

    ycbcr = x @ M.T
    y  = ycbcr[..., 0]
    cb = ycbcr[..., 1] + 0.5
    cr = ycbcr[..., 2] + 0.5
    return y, cb, cr

def ycbcr_to_rgb(y: np.ndarray, cb: np.ndarray, cr: np.ndarray) -> np.ndarray:
    y = np.asarray(y, np.float32)
    cb = np.asarray(cb, np.float32) - 0.5
    cr = np.asarray(cr, np.float32) - 0.5
    ycbcr = np.stack([y, cb, cr], axis=-1)

    M = np.array([[1.0, 0.0, 1.402],
                  [1.0, -0.344136, -0.714136],
                  [1.0, 1.772, 0.0]], dtype=np.float32)

    rgb = ycbcr @ M.T
    return np.clip(rgb, 0.0, 1.0)


def merge_luminance(y: np.ndarray, cb: np.ndarray, cr: np.ndarray) -> np.ndarray:
    return ycbcr_to_rgb(np.clip(y, 0, 1), np.clip(cb, 0, 1), np.clip(cr, 0, 1))

def _tile_grid_and_pad(shape_hw, chunk_size: int, overlap: int):
    """
    Returns:
        Hp, Wp, coords, step

    Pads the image on bottom/right so every extracted tile is exactly
    chunk_size x chunk_size. This lets us batch tiles efficiently.
    """
    H, W = int(shape_hw[0]), int(shape_hw[1])
    chunk_size = int(max(64, chunk_size))
    overlap = int(max(0, min(chunk_size - 1, overlap)))
    step = max(1, chunk_size - overlap)

    if H <= chunk_size:
        Hp = chunk_size
    else:
        rem_h = (H - chunk_size) % step
        Hp = H if rem_h == 0 else (H + (step - rem_h))

    if W <= chunk_size:
        Wp = chunk_size
    else:
        rem_w = (W - chunk_size) % step
        Wp = W if rem_w == 0 else (W + (step - rem_w))

    coords = []
    for y in range(0, Hp - chunk_size + 1, step):
        for x in range(0, Wp - chunk_size + 1, step):
            coords.append((y, x))

    return Hp, Wp, coords, step


def _safe_pad_mode_for_shape(h: int, w: int) -> str:
    # np.pad(..., mode="reflect") needs dimensions > 1
    if h <= 1 or w <= 1:
        return "edge"
    return "reflect"


def _make_blend_weight_2d(chunk_size: int, border_size: int = 16) -> np.ndarray:
    """
    Weight map used during stitched reconstruction.
    Equivalent spirit to your old 'ignore border' approach, but works nicely
    with batched accumulation.
    """
    w = np.ones((chunk_size, chunk_size), dtype=np.float32)

    b = int(max(0, min(border_size, chunk_size // 2)))
    if b <= 0:
        return w

    w[:b, :] = 0.0
    w[-b:, :] = 0.0
    w[:, :b] = 0.0
    w[:, -b:] = 0.0

    # Safety: if tile is too small and the inner area vanished, fall back to all-ones
    if not np.any(w > 0):
        w.fill(1.0)

    return w

def _auto_batch_size(models, chunk_size, *, rgb, execution_mode="auto", batch_size_override=0):
    if batch_size_override and batch_size_override > 0:
        return int(batch_size_override)
    if execution_mode == "compatibility":
        return 1

    dev = _device_type(models)
    cs = int(chunk_size)
    is_walking = getattr(models, "variant", "") == "walking"

    if models.is_onnx:
        if cs <= 256: return 8 if rgb else 12
        if cs <= 384: return 4 if rgb else 8
        if cs <= 512: return 2 if rgb else 4
        return 1

    if dev == "cuda":
        try:
            torch = models.torch
            major, minor = torch.cuda.get_device_capability()
            if major < 8:
                if cs <= 256: return 4 if rgb else 6
                if cs <= 384: return 2 if rgb else 4
                return 1
        except Exception:
            pass
        if cs <= 256: return 16 if rgb else 24
        if cs <= 384: return 8 if rgb else 12
        if cs <= 512: return 4 if rgb else 8
        return 2

    if dev == "dml":
        # DirectML has no autocast (fp32 only) and runs against the Windows TDR
        # watchdog: one oversized dispatch past TdrDelay and the D3D12 device is
        # lost permanently. This is a *latency* budget, not a VRAM budget — a
        # 16GB card does not help. Stay small on the full-width NAFNet.
        if is_walking:
            return 1
        if getattr(models, "variant", "") == "lite":
            if cs <= 256: return 2 if rgb else 4
            return 1
        return 1

    if dev == "mps":
        if is_walking:
            return 1
        if cs <= 256: return 4 if rgb else 6
        if cs <= 384: return 2 if rgb else 4
        return 1

    # CPU fallback
    if cs <= 256: return 4 if rgb else 6
    if cs <= 384: return 2 if rgb else 4
    return 1

def _legacy_denoise_rgb_with_color_model(
    img_rgb,
    models,
    *,
    chunk_size=256,
    overlap=64,
    progress_cb=None,
):
    """
    Old slow-but-stable RGB single-tile path for the color model.
    """
    img_rgb = np.asarray(img_rgb, np.float32)
    chunks = split_image_into_chunks_with_overlap(img_rgb, chunk_size=chunk_size, overlap=overlap)

    out = np.zeros_like(img_rgb, dtype=np.float32)
    wts = np.zeros(img_rgb.shape[:2], dtype=np.float32)

    total = len(chunks)
    for idx, (chunk, i, j) in enumerate(chunks):
        den = _infer_chunk_rgb(models, models.color, chunk)  # HxWx3

        h, w = den.shape[:2]
        bh = min(16, h // 2)
        bw = min(16, w // 2)

        y0 = i + bh
        y1 = i + h - bh
        x0 = j + bw
        x1 = j + w - bw
        if y1 <= y0 or x1 <= x0:
            continue

        inner = den[bh:h-bh, bw:w-bw, :]  # (hi, wi, 3)

        yy0 = max(0, y0)
        yy1 = min(img_rgb.shape[0], y1)
        xx0 = max(0, x0)
        xx1 = min(img_rgb.shape[1], x1)
        if yy1 <= yy0 or xx1 <= xx0:
            continue

        sy0 = yy0 - y0
        sy1 = sy0 + (yy1 - yy0)
        sx0 = xx0 - x0
        sx1 = sx0 + (xx1 - xx0)
        src = inner[sy0:sy1, sx0:sx1, :]

        out[yy0:yy1, xx0:xx1, :] += src
        wts[yy0:yy1, xx0:xx1] += 1.0

        _tick(progress_cb, idx + 1, total)

    out /= np.maximum(wts[..., None], 1.0)
    return out.astype(np.float32, copy=False)

def denoise_rgb_with_color_model(
    img_rgb,
    models,
    *,
    chunk_size=256,
    overlap=64,
    progress_cb=None,
    execution_mode: str = "auto",
    batch_size_override: int = 0,
):
    """
    Batched RGB denoise with automatic batch-size fallback.
    Falls back to legacy single-tile path if batching still fails.
    """
    img_rgb = np.asarray(img_rgb, np.float32)
    H, W = img_rgb.shape[:2]

    Hp, Wp, coords, _step = _tile_grid_and_pad((H, W), chunk_size, overlap)
    pad_mode = _safe_pad_mode_for_shape(H, W)
    padded = np.pad(img_rgb, ((0, Hp - H), (0, Wp - W), (0, 0)), mode=pad_mode)

    weight = _make_blend_weight_2d(int(chunk_size), border_size=16)
    weight3 = weight[..., None]
    total = len(coords)

    initial_bs = _auto_batch_size(
        models,
        int(chunk_size),
        rgb=True,
        execution_mode=execution_mode,
        batch_size_override=batch_size_override,
    )

    last_err = None

    for batch_size in _iter_batch_sizes(initial_bs):
        try:
            acc = np.zeros((Hp, Wp, 3), dtype=np.float32)
            wts = np.zeros((Hp, Wp), dtype=np.float32)

            if models.is_onnx:
                name_img, name_out = _ort_pick_io_names_single_input(models.color)

                for start in range(0, total, batch_size):
                    batch_coords = coords[start:start + batch_size]

                    batch_np = np.stack(
                        [padded[y:y + chunk_size, x:x + chunk_size, :] for (y, x) in batch_coords],
                        axis=0
                    ).astype(np.float32, copy=False)  # (B,H,W,3)

                    inp = np.ascontiguousarray(np.transpose(batch_np, (0, 3, 1, 2)))  # (B,3,H,W)
                    out = models.color.run([name_out], {name_img: inp})[0]

                    if out.ndim != 4:
                        raise RuntimeError(f"Unexpected ONNX output shape: {out.shape}")

                    pred = np.transpose(out, (0, 2, 3, 1)).astype(np.float32, copy=False)  # (B,H,W,3)

                    for k, (y, x) in enumerate(batch_coords):
                        acc[y:y + chunk_size, x:x + chunk_size, :] += pred[k] * weight3
                        wts[y:y + chunk_size, x:x + chunk_size] += weight

                    _tick(progress_cb, min(start + len(batch_coords), total), total)

            else:
                torch = models.torch
                dev = models.device

                for start in range(0, total, batch_size):
                    batch_coords = coords[start:start + batch_size]

                    batch_np = np.stack(
                        [padded[y:y + chunk_size, x:x + chunk_size, :] for (y, x) in batch_coords],
                        axis=0
                    ).astype(np.float32, copy=False)  # (B,H,W,3)

                    inp = np.ascontiguousarray(np.transpose(batch_np, (0, 3, 1, 2)))  # (B,3,H,W)
                    t = np_to_torch(inp, device=dev, torch=torch)

                    with torch.no_grad(), _autocast_context(torch, dev):
                        out = models.color(t)  # (B,3,H,W)
                        pred = torch_to_np(out.detach().float())

                    pred = np.transpose(pred, (0, 2, 3, 1)).astype(np.float32, copy=False)

                    for k, (y, x) in enumerate(batch_coords):
                        acc[y:y + chunk_size, x:x + chunk_size, :] += pred[k] * weight3
                        wts[y:y + chunk_size, x:x + chunk_size] += weight

                    _tick(progress_cb, min(start + len(batch_coords), total), total)

            out = acc / np.maximum(wts[..., None], 1e-8)
            return out[:H, :W, :].astype(np.float32, copy=False)

        except DenoiseCancelled:
            raise
        except Exception as e:
            last_err = e
            if _is_device_lost_error(e):
                # Do NOT shrink the batch and do NOT fall through to the legacy
                # single-tile path — both would re-enter inference on a device
                # that no longer exists.
                raise DeviceLostError(safe_exception_str(e)) from e
            if batch_size == 1 or not _is_recoverable_batch_error(e):
                break
            print(f"[CC Denoise] RGB batched path failed at batch_size={batch_size}, retrying smaller batch. {safe_exception_str(e)}")

    if last_err is not None and _is_device_lost_error(last_err):
        raise DeviceLostError(safe_exception_str(last_err)) from last_err
    print(f"[CC Denoise] RGB batched path failed, falling back to legacy single-tile path. {safe_exception_str(last_err)}")
    return _legacy_denoise_rgb_with_color_model(
        img_rgb,
        models,
        chunk_size=chunk_size,
        overlap=overlap,
        progress_cb=progress_cb,
    )

# Function to split an image into chunks with overlap
def split_image_into_chunks_with_overlap(image, chunk_size, overlap):
    height, width = image.shape[:2]
    chunks = []
    step_size = chunk_size - overlap

    for i in range(0, height, step_size):
        for j in range(0, width, step_size):
            end_i = min(i + chunk_size, height)
            end_j = min(j + chunk_size, width)
            if end_i <= i or end_j <= j:
                continue
            chunk = image[i:end_i, j:end_j]
            chunks.append((chunk, i, j))
    return chunks


def blend_images(before, after, amount):
    return (1 - amount) * before + amount * after

def stitch_chunks_ignore_border(chunks, image_shape, border_size: int = 16):
    """
    chunks: list of (chunk, i, j) or (chunk, i, j, is_edge)
    image_shape: (H,W)
    Robust to boundary clipping (prevents 256x256 -> 256x0 broadcasts).
    """
    H, W = image_shape
    stitched = np.zeros((H, W), dtype=np.float32)
    weights  = np.zeros((H, W), dtype=np.float32)

    for entry in chunks:
        if len(entry) == 3:
            chunk, i, j = entry
        else:
            chunk, i, j, _ = entry

        h, w = chunk.shape[:2]
        if h <= 0 or w <= 0:
            continue

        bh = min(border_size, h // 2)
        bw = min(border_size, w // 2)

        # inner region in chunk coords
        y0 = i + bh
        y1 = i + h - bh
        x0 = j + bw
        x1 = j + w - bw

        if y1 <= y0 or x1 <= x0:
            continue

        inner = chunk[bh:h-bh, bw:w-bw]

        # clip destination to image bounds
        yy0 = max(0, y0)
        yy1 = min(H, y1)
        xx0 = max(0, x0)
        xx1 = min(W, x1)

        if yy1 <= yy0 or xx1 <= xx0:
            continue

        # clip source to match clipped destination
        sy0 = yy0 - y0
        sy1 = sy0 + (yy1 - yy0)
        sx0 = xx0 - x0
        sx1 = sx0 + (xx1 - xx0)

        src = inner[sy0:sy1, sx0:sx1]

        stitched[yy0:yy1, xx0:xx1] += src
        weights[yy0:yy1,  xx0:xx1] += 1.0

    stitched /= np.maximum(weights, 1.0)
    return stitched


def replace_border(original_image, processed_image, border_size=16):
    # Ensure the dimensions of both images match
    if original_image.shape != processed_image.shape:
        raise ValueError("Original image and processed image must have the same dimensions.")
    
    # Replace the top border
    processed_image[:border_size, :] = original_image[:border_size, :]
    
    # Replace the bottom border
    processed_image[-border_size:, :] = original_image[-border_size:, :]
    
    # Replace the left border
    processed_image[:, :border_size] = original_image[:, :border_size]
    
    # Replace the right border
    processed_image[:, -border_size:] = original_image[:, -border_size:]
    
    return processed_image

def stretch_image_unlinked(image: np.ndarray, target_median: float = 0.25):
    x = np.asarray(image, np.float32).copy()
    orig_min = float(np.min(x))
    x -= orig_min

    t = float(target_median)

    if x.ndim == 2:
        m0 = float(np.median(x))
        orig_meds = [m0]
        if m0 != 0.0:
            denom = (m0 * (t + x - 1.0) - t * x)
            # avoid divide-by-zero
            x = np.where(np.abs(denom) > 1e-12, ((m0 - 1.0) * t * x) / denom, x)
        return x, orig_min, orig_meds

    orig_meds = [float(np.median(x[..., c])) for c in range(3)]
    for c in range(3):
        m0 = float(orig_meds[c])
        if m0 != 0.0:
            denom = (m0 * (t + x[..., c] - 1.0) - t * x[..., c])
            x[..., c] = np.where(np.abs(denom) > 1e-12, ((m0 - 1.0) * t * x[..., c]) / denom, x[..., c])
    return x, orig_min, orig_meds


def unstretch_image_unlinked(image: np.ndarray, orig_meds, orig_min: float, target_median: float = 0.25):
    y = np.asarray(image, np.float32).copy()
    t = float(target_median)

    def inv(yc: np.ndarray, m0: float) -> np.ndarray:
        # x = y*m0*(t-1) / ( t*(m0 - 1 + y) - y*m0 )
        denom = (t * (m0 - 1.0 + yc) - yc * m0)
        num = (yc * m0 * (t - 1.0))
        return np.where(np.abs(denom) > 1e-12, num / denom, yc)

    if y.ndim == 2:
        m0 = float(orig_meds[0])
        if m0 != 0.0:
            y = inv(y, m0)
        y += float(orig_min)
        return y

    for c in range(3):
        m0 = float(orig_meds[c])
        if m0 != 0.0:
            y[..., c] = inv(y[..., c], m0)

    y += float(orig_min)
    return y


# Backwards-compatible names used by denoise_rgb01()
def stretch_image(image: np.ndarray, *, target_median: float = 0.25):
    return stretch_image_unlinked(image, target_median=float(target_median))

def unstretch_image(image: np.ndarray, original_medians, original_min: float, *, target_median: float = 0.25):
    return unstretch_image_unlinked(image, original_medians, original_min, target_median=float(target_median))


def add_border(image, border_size=16):
    if image.ndim == 2:                                # mono
        med = np.median(image)
        return np.pad(image,
                      ((border_size, border_size), (border_size, border_size)),
                      mode="constant",
                      constant_values=med)

    elif image.ndim == 3 and image.shape[2] == 3:       # RGB
        meds = np.median(image, axis=(0, 1)).astype(image.dtype)  # (3,)
        padded = [np.pad(image[..., c],
                         ((border_size, border_size), (border_size, border_size)),
                         mode="constant",
                         constant_values=float(meds[c]))
                  for c in range(3)]
        return np.stack(padded, axis=-1)
    else:
        raise ValueError("add_border expects mono or RGB image.")

def remove_border(image, border_size: int = 16):
    if image.ndim == 2:
        return image[border_size:-border_size, border_size:-border_size]
    return image[border_size:-border_size, border_size:-border_size, :]

def _device_type(models: "DenoiseModels") -> str:
    """Normalize device type string — torch-directml reports 'privateuseone'."""
    dev = getattr(models.device, "type", None) or str(models.device)
    dev = str(dev).lower()
    if dev == "privateuseone":
        return "dml"
    return dev

def _legacy_denoise_channel(
    channel,
    models: DenoiseModels,
    *,
    which="mono",
    chunk_size=256,
    overlap=64,
    progress_cb=None,
):
    """
    Old slow-but-stable single-tile path.
    Uses _infer_chunk_2d() one tile at a time, then stitches.
    """
    model = models.mono if which == "mono" else models.color
    chunks = split_image_into_chunks_with_overlap(channel, chunk_size=chunk_size, overlap=overlap)

    out_chunks = []
    total = len(chunks)

    for idx, (chunk, i, j) in enumerate(chunks):
        den2d = _infer_chunk_2d(models, model, chunk)
        out_chunks.append((den2d, i, j))

        _tick(progress_cb, idx + 1, total)

    return stitch_chunks_ignore_border(out_chunks, channel.shape, border_size=16)

def denoise_channel(
    channel,
    models: DenoiseModels,
    *,
    which="mono",
    chunk_size=256,
    overlap=64,
    progress_cb=None,
    execution_mode: str = "auto",
    batch_size_override: int = 0,
):
    """
    Batched mono-channel denoise with automatic batch-size fallback.
    Falls back to old single-tile path if batching still fails.
    """
    model = models.mono if which == "mono" else models.color

    channel = np.asarray(channel, np.float32)
    H, W = channel.shape[:2]

    Hp, Wp, coords, _step = _tile_grid_and_pad((H, W), chunk_size, overlap)
    pad_mode = _safe_pad_mode_for_shape(H, W)
    padded = np.pad(channel, ((0, Hp - H), (0, Wp - W)), mode=pad_mode)

    weight = _make_blend_weight_2d(int(chunk_size), border_size=16)
    total = len(coords)

    initial_bs = _auto_batch_size(
        models,
        int(chunk_size),
        rgb=False,
        execution_mode=execution_mode,
        batch_size_override=batch_size_override,
    )

    last_err = None

    for batch_size in _iter_batch_sizes(initial_bs):
        try:
            acc = np.zeros((Hp, Wp), dtype=np.float32)
            wts = np.zeros((Hp, Wp), dtype=np.float32)

            if models.is_onnx:
                name_img, name_out = _ort_pick_io_names_single_input(model)

                for start in range(0, total, batch_size):
                    batch_coords = coords[start:start + batch_size]

                    batch_np = np.stack(
                        [padded[y:y + chunk_size, x:x + chunk_size] for (y, x) in batch_coords],
                        axis=0
                    ).astype(np.float32, copy=False)  # (B,H,W)

                    inp = np.repeat(batch_np[:, None, :, :], 3, axis=1)  # (B,3,H,W)
                    out = model.run([name_out], {name_img: inp})[0]

                    if out.ndim == 4:
                        pred = out[:, 0, :, :]
                    elif out.ndim == 3:
                        pred = out
                        if pred.shape[1] == chunk_size and pred.shape[2] == chunk_size:
                            pass
                        elif pred.shape[0] in (1, 3):
                            pred = pred[0:1, ...]
                        else:
                            raise RuntimeError(f"Unexpected ONNX output shape: {out.shape}")
                    else:
                        raise RuntimeError(f"Unexpected ONNX output shape: {out.shape}")

                    pred = np.asarray(pred, dtype=np.float32)

                    for k, (y, x) in enumerate(batch_coords):
                        acc[y:y + chunk_size, x:x + chunk_size] += pred[k] * weight
                        wts[y:y + chunk_size, x:x + chunk_size] += weight

                    _tick(progress_cb, min(start + len(batch_coords), total), total)

            else:
                torch = models.torch
                dev = models.device

                for start in range(0, total, batch_size):
                    batch_coords = coords[start:start + batch_size]

                    batch_np = np.stack(
                        [padded[y:y + chunk_size, x:x + chunk_size] for (y, x) in batch_coords],
                        axis=0
                    ).astype(np.float32, copy=False)  # (B,H,W)

                    t = np_to_torch(batch_np, device=dev, torch=torch).unsqueeze(1)
                    t3 = t.expand(-1, 3, -1, -1).contiguous()

                    with torch.no_grad(), _autocast_context(torch, dev):
                        out = model(t3)  # (B,3,H,W)
                        pred = torch_to_np(out[:, 0, :, :].detach().float())

                    for k, (y, x) in enumerate(batch_coords):
                        acc[y:y + chunk_size, x:x + chunk_size] += pred[k] * weight
                        wts[y:y + chunk_size, x:x + chunk_size] += weight

                    _tick(progress_cb, min(start + len(batch_coords), total), total)

            out = acc / np.maximum(wts, 1e-8)
            return out[:H, :W].astype(np.float32, copy=False)

        except DenoiseCancelled:
            raise
        except Exception as e:
            last_err = e
            if _is_device_lost_error(e):
                raise DeviceLostError(safe_exception_str(e)) from e
            if batch_size == 1 or not _is_recoverable_batch_error(e):
                break
            print(f"[CC Denoise] mono batched path failed at batch_size={batch_size}, retrying smaller batch. {safe_exception_str(e)}")

    if last_err is not None and _is_device_lost_error(last_err):
        raise DeviceLostError(safe_exception_str(last_err)) from last_err
    print(f"[CC Denoise] mono batched path failed, falling back to legacy single-tile path. {safe_exception_str(last_err)}")
    return _legacy_denoise_channel(
        channel,
        models,
        which=which,
        chunk_size=chunk_size,
        overlap=overlap,
        progress_cb=progress_cb,
    )

def denoise_rgb01(
    img_rgb01: np.ndarray,
    *,
    denoise_strength: float,
    denoise_mode: str = "luminance",
    separate_channels: bool = False,
    color_denoise_strength: Optional[float] = None,
    chunk_size: int = 256,
    overlap: int = 64,
    use_gpu: bool = True,
    lite: bool = False,
    walking: bool = False,        # ← new
    temp_stretch: bool = False,
    target_median: float = 0.25,
    progress_cb=None,
    execution_mode: str = "auto",
    batch_size_override: int = 0,
) -> np.ndarray:

    if execution_mode == "compatibility":
        batch_size_override = 1
        chunk_size = min(int(chunk_size), 256)

    models = load_models(use_gpu=use_gpu, lite=lite, walking=walking, status_cb=print)

    # Applied here, before _tile_count_2d and the progress totals are derived
    # from it, so the tile grid and the progress bar agree.
    chunk_size = _cap_chunk_size_for_device(models.device, int(chunk_size))

    tm = float(np.clip(target_median, 0.01, 0.50))

    def _log(msg: str):
        try:
            print(msg)
        except Exception:
            pass

    try:
        backend = "onnx/DirectML" if models.is_onnx else "torch"
        dev = _device_type(models)
        _log(
            f"[CC Denoise] variant={getattr(models,'variant','?')} "
            f"(lite={lite}) backend={backend} device={dev} "
            f"mono={os.path.basename(getattr(models,'mono_path',''))} "
            f"color={os.path.basename(getattr(models,'color_path',''))}"
        )
    except Exception:
        pass

    def _run_with(active_models) -> np.ndarray:
        arr = np.asarray(img_rgb01, np.float32)

        def _is_triplicated_mono(rgb: np.ndarray, eps: float = 1e-7) -> bool:
            if rgb.ndim != 3 or rgb.shape[2] != 3:
                return False
            r = rgb[..., 0]; g = rgb[..., 1]; b = rgb[..., 2]
            return (np.max(np.abs(r - g)) <= eps) and (np.max(np.abs(r - b)) <= eps)

        def _tile_count_2d(h: int, w: int) -> int:
            return max(1, len(_tile_grid_and_pad((h, w), chunk_size, overlap)[2]))

        def _make_subprogress(offset_units: int, span_units: int, total_units: int):
            if progress_cb is None:
                return None

            def _cb(done: int, total: int):
                try:
                    total_local = max(1, int(total) if total else int(span_units))
                    done_local = max(0, min(int(done), total_local))

                    mapped = int(round(offset_units + (span_units * (done_local / total_local))))
                    mapped = max(0, min(int(total_units), mapped))
                    return progress_cb(mapped, total_units)
                except Exception:
                    return True

            return _cb

        mono_input = (
            (arr.ndim == 2)
            or (arr.ndim == 3 and arr.shape[2] == 1)
            or _is_triplicated_mono(arr)
        )

        if mono_input:
            mono = arr if arr.ndim == 2 else arr[..., 0]

            if bool(temp_stretch):
                stretch_needed = True
            else:
                stretch_needed = (np.median(mono - np.min(mono)) < 0.05)

            if stretch_needed:
                mono_s, original_min, original_meds = stretch_image(mono, target_median=tm)
            else:
                mono_s = mono.astype(np.float32, copy=False)
                original_min = float(np.min(mono))
                original_meds = [float(np.median(mono_s))]

            mono_s = add_border(mono_s, border_size=16)

            total_units = _tile_count_2d(*mono_s.shape[:2])
            _tick(progress_cb, 0, total_units)

            den_m = denoise_channel(
                mono_s,
                active_models,
                which="mono",
                chunk_size=chunk_size,
                overlap=overlap,
                progress_cb=_make_subprogress(0, total_units, total_units),
                execution_mode=execution_mode,
                batch_size_override=batch_size_override,
            )
            mono_out = blend_images(mono_s, den_m, denoise_strength)
            mono_out = np.clip(mono_out, 0.0, 1.0)

            if stretch_needed:
                mono_out = unstretch_image(mono_out, original_meds, original_min, target_median=tm)

            mono_out = remove_border(mono_out, border_size=16)
            mono_out = np.clip(mono_out, 0.0, 1.0).astype(np.float32, copy=False)

            if progress_cb is not None:
                progress_cb(total_units, total_units)

            return np.stack([mono_out, mono_out, mono_out], axis=-1)

        if bool(temp_stretch):
            stretch_needed = True
        else:
            stretch_needed = (np.median(arr - np.min(arr)) < 0.05)

        if stretch_needed:
            stretched_core, original_min, original_medians = stretch_image(arr, target_median=tm)
        else:
            stretched_core = arr.astype(np.float32, copy=False)
            original_min = float(np.min(arr))
            original_medians = [float(np.median(arr[..., c])) for c in range(3)]

        stretched = add_border(stretched_core, border_size=16)
        tile_units = _tile_count_2d(stretched.shape[0], stretched.shape[1])

        if separate_channels or denoise_mode == "separate":
            total_units = tile_units * 3
            _tick(progress_cb, 0, total_units)

            out_ch = []
            for c in range(3):
                dch = denoise_channel(
                    stretched[..., c],
                    active_models,
                    which="mono",
                    chunk_size=chunk_size,
                    overlap=overlap,
                    progress_cb=_make_subprogress(c * tile_units, tile_units, total_units),
                    execution_mode=execution_mode,
                    batch_size_override=batch_size_override,
                )
                out_ch.append(blend_images(stretched[..., c], dch, denoise_strength))

            den = np.stack(out_ch, axis=-1)

        elif denoise_mode == "luminance":
            total_units = tile_units
            _tick(progress_cb, 0, total_units)

            y, cb, cr = extract_luminance(stretched)
            den_y = denoise_channel(
                y,
                active_models,
                which="mono",
                chunk_size=chunk_size,
                overlap=overlap,
                progress_cb=_make_subprogress(0, tile_units, total_units),
                execution_mode=execution_mode,
                batch_size_override=batch_size_override,
            )
            y2 = blend_images(y, den_y, denoise_strength)
            den = merge_luminance(y2, cb, cr)

        else:
            # full mode = luminance pass + color pass
            total_units = tile_units * 2
            _tick(progress_cb, 0, total_units)

            y, cb, cr = extract_luminance(stretched)

            den_y = denoise_channel(
                y,
                active_models,
                which="mono",
                chunk_size=chunk_size,
                overlap=overlap,
                progress_cb=_make_subprogress(0, tile_units, total_units),
                execution_mode=execution_mode,
                batch_size_override=batch_size_override,
            )
            y2 = blend_images(y, den_y, denoise_strength)

            den_rgb = denoise_rgb_with_color_model(
                stretched,
                active_models,
                chunk_size=chunk_size,
                overlap=overlap,
                progress_cb=_make_subprogress(tile_units, tile_units, total_units),
                execution_mode=execution_mode,
                batch_size_override=batch_size_override,
            )

            cs = denoise_strength if color_denoise_strength is None else float(color_denoise_strength)
            cs = float(np.clip(cs, 0.0, 1.0))

            _y_d, cb_d, cr_d = extract_luminance(den_rgb)
            cb2 = (1.0 - cs) * cb + cs * cb_d
            cr2 = (1.0 - cs) * cr + cs * cr_d

            den = merge_luminance(y2, cb2, cr2)

        den = np.clip(den, 0.0, 1.0)
        if stretch_needed:
            den = unstretch_image(den, original_medians, original_min, target_median=tm)

        den = remove_border(den, border_size=16)
        den = np.clip(den, 0.0, 1.0).astype(np.float32, copy=False)

        if progress_cb is not None:
            progress_cb(total_units, total_units)

        return den

    try:
        return _run_with(models)

    except DenoiseCancelled:
        raise

    except Exception as e:
        try:
            dev = _device_type(models) if models is not None else "unknown"
        except Exception:
            dev = "unknown"

        hard = _is_device_lost_error(e)   # adapter is gone — poison DirectML
        soft = _is_backend_unusable_error(e)   # backend can't run it — fall back only

        if use_gpu and dev != "cpu" and (hard or soft):
            _log(f"[CC Denoise] GPU path failed on backend={dev}: {safe_exception_str(e)}")

            if hard and dev == "dml":
                #sasprocess-wide. Sharpen and every other CC engine must stop
                # handing out DirectML for the rest of this session.
                _disable_dml("Adapter was removed or hung during denoising.", status_cb=_log)

            if hard:
                _evict_models(models)
                models = None

            _log("[CC Denoise] Retrying on CPU.")
            cpu_models = load_models(use_gpu=False, lite=lite, walking=walking, status_cb=_log)
            return _run_with(cpu_models)

        raise


# ---------------------------------------------------------------------
# Public: Clear cached models (manual troubleshooting)
# ---------------------------------------------------------------------
def clear_denoise_models_cache(*, aggressive: bool = False, status_cb=print) -> None:
    """
    Clears the in-process denoise model cache so RAM/VRAM can be reclaimed.
    - aggressive=False: clears Python references; leaves backend allocators alone.
    - aggressive=True : also tries to flush torch CUDA/MPS caches and runs gc.collect().
    """
    global _MODELS_CACHE
    try:
        n = len(_MODELS_CACHE)
        _MODELS_CACHE.clear()
        status_cb(f"[CC Denoise] Cleared model cache entries: {n}")
    except Exception as e:
        try:
            status_cb(f"[CC Denoise] Cache clear failed: {type(e).__name__}: {e}")
        except Exception:
            pass

    if not aggressive:
        return

    # Aggressive cleanup: best-effort only
    try:
        import gc
        gc.collect()
    except Exception:
        pass

    # Try flushing torch allocator (CUDA/MPS)
    try:
        from setiastro.saspro.runtime_torch import import_torch
        torch = import_torch(prefer_cuda=True, prefer_xpu=False, prefer_dml=True, status_cb=lambda s: None)

        # CUDA
        try:
            if getattr(torch, "cuda", None) and torch.cuda.is_available():
                torch.cuda.empty_cache()
                # Optional: collect IPC blocks if available
                if hasattr(torch.cuda, "ipc_collect"):
                    torch.cuda.ipc_collect()
                status_cb("[CC Denoise] torch.cuda.empty_cache() called")
        except Exception:
            pass

        # MPS
        try:
            if hasattr(torch, "backends") and hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                # newer torch has this
                if hasattr(torch, "mps") and hasattr(torch.mps, "empty_cache"):
                    torch.mps.empty_cache()
                    status_cb("[CC Denoise] torch.mps.empty_cache() called")
        except Exception:
            pass

    except Exception:
        pass