# whatsinmysky.py
from __future__ import annotations

# --- stdlib ---
import os
import sys
import shutil
import warnings
import webbrowser
from datetime import datetime
from decimal import getcontext
from typing import Optional

# --- third-party ---
import numpy as np
import pandas as pd
import pytz
from astropy import units as u
from astropy.coordinates import SkyCoord, EarthLocation, AltAz, get_sun, get_body
from astropy.time import Time

# --- Qt / PyQt6 ---
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSettings, QTimer
from PyQt6.QtGui import QIcon, QPixmap, QAction
from PyQt6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QComboBox, QCheckBox, QRadioButton, QButtonGroup,
    QPushButton, QGridLayout, QTreeWidget, QTreeWidgetItem, QHeaderView, QFileDialog,
    QScrollArea, QInputDialog, QMessageBox, QWidget, QHBoxLayout, QVBoxLayout,
    QSplitter, QFrame, QTabWidget, QTextEdit, QMenu
)
from setiastro.saspro.help_support import make_help_button
try:
    import pyqtgraph as pg
    _HAS_PG = True
except ImportError:
    _HAS_PG = False

from setiastro.saspro.altaz_field_rotation import AltAzFieldRotationDialog

# ---------------------------------------------------
#  paths / globals
# ---------------------------------------------------
def _app_root() -> str:
    return getattr(sys, "_MEIPASS", os.path.dirname(__file__))

def imgs_path(*parts) -> str:
    return os.path.join(_app_root(), "imgs", *parts)

from setiastro.saspro.resources import get_icon_path

getcontext().prec = 24
warnings.filterwarnings("ignore")

ATLAS_CATALOG_URL = "https://f005.backblazeb2.com/file/setiastro-atlas/catalog.json"

class AtlasCatalogThread(QThread):
    """Fetch the community atlas catalog.json in the background."""
    finished = pyqtSignal(list)   # list of atlas entries, or [] on failure
 
    def run(self):
        import urllib.request
        import json as _json
 
        for attempt in range(3):
            try:
                with urllib.request.urlopen(ATLAS_CATALOG_URL, timeout=8) as resp:
                    data = _json.loads(resp.read().decode("utf-8"))
                    entries = data if isinstance(data, list) else data.get("entries", [])
                    self.finished.emit(entries)
                    return
            except Exception:
                if attempt < 2:
                    import time
                    time.sleep(1.5)
        # All attempts failed — emit empty list silently
        self.finished.emit([])

def _ra_in_atlas(ra_deg: float, dec_deg: float, atlas_entries: list) -> bool:
    """
    Returns True if (ra_deg, dec_deg) falls within the bounding box of any
    atlas entry's four corner coordinates.
 
    Fast enough for thousands of WIMS objects against a small atlas catalog.
    Handles RA wrap-around at 0/360.
    """
    for entry in atlas_entries:
        c_ra  = entry.get("corners_ra",  [])
        c_dec = entry.get("corners_dec", [])
        if len(c_ra) != 4 or len(c_dec) != 4:
            # Fallback: use center + half-FOV bounding box
            ra_c   = entry.get("ra_center",  0.0)
            dec_c  = entry.get("dec_center", 0.0)
            fov_w  = entry.get("fov_w_deg",  0.0)
            fov_h  = entry.get("fov_h_deg",  0.0)
            if abs(dec_deg - dec_c) > fov_h / 2.0:
                continue
            # RA delta with wrap
            dra = abs(ra_deg - ra_c) % 360
            if dra > 180:
                dra = 360 - dra
            if dra <= fov_w / 2.0:
                return True
            continue
 
        dec_min = min(c_dec)
        dec_max = max(c_dec)
        if not (dec_min <= dec_deg <= dec_max):
            continue
 
        ra_min = min(c_ra)
        ra_max = max(c_ra)
        ra_span = ra_max - ra_min
 
        if ra_span > 180:
            # Footprint straddles 0/360 — check outside the gap
            if ra_deg >= ra_min or ra_deg <= ra_max:
                return True
        else:
            if ra_min <= ra_deg <= ra_max:
                return True
 
    return False


class WeeklyScoreThread(QThread):
    result_ready = pyqtSignal(list)   # list of (date_str, score, phase_pct)

    def __init__(self, ra_deg, dec_deg, lat, lon, center_date_str, tz_name,
                 days_before=7, days_after=7, horizon_points=None):
        super().__init__()
        self.ra_deg          = ra_deg
        self.dec_deg         = dec_deg
        self.lat             = lat
        self.lon             = lon
        self.center_date_str = center_date_str
        self.tz_name         = tz_name
        self.days_before     = days_before
        self.days_after      = days_after
        self.horizon_points = horizon_points or []

    def run(self):
        from datetime import timedelta
        results = []
        try:
            center = datetime.strptime(self.center_date_str, "%Y-%m-%d")
            for offset in range(-self.days_before, self.days_after + 1):
                d     = center + timedelta(days=offset)
                d_str = d.strftime("%Y-%m-%d")
                score, phase = _score_target_for_date(
                    self.ra_deg, self.dec_deg,
                    self.lat, self.lon, d_str, self.tz_name,
                    horizon_points=self.horizon_points)
                results.append((d_str, score, phase))
        except Exception:
            pass
        self.result_ready.emit(results)

class ScoreChartDialog(QDialog):
    """Shows a bar/line chart of observability score across ±7 days."""

    def __init__(self, item_data: dict, observer: dict, parent=None):
        super().__init__(parent)
        self.item_data = item_data
        self.observer  = observer
        name = item_data.get("name", "Object")
        self.setWindowTitle(f"Weekly Score — {name}")
        self.resize(820, 420)
        self._thread = None
        self._build_ui()
        self._start_compute()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)

        self.status_lbl = QLabel("Computing scores…")
        self.status_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        outer.addWidget(self.status_lbl)

        if _HAS_PG:
            self.plot = pg.PlotWidget()
            self.plot.setLabel("bottom", "Date")
            self.plot.setLabel("left", "Score (0–100)")
            self.plot.showGrid(x=True, y=True, alpha=0.3)
            self.plot.setYRange(0, 100, padding=0.05)
            outer.addWidget(self.plot, 1)
        else:
            self.text = QTextEdit()
            self.text.setReadOnly(True)
            outer.addWidget(self.text, 1)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.close)
        row = QHBoxLayout()
        row.addStretch()
        row.addWidget(close_btn)
        outer.addLayout(row)

    def _start_compute(self):
        self._thread = WeeklyScoreThread(
            self.item_data["ra"], self.item_data["dec"],
            self.observer["lat"], self.observer["lon"],
            self.observer["date"], self.observer["tz"],
            horizon_points=self.observer.get("horizon_points", []),
        )
        self._thread.result_ready.connect(self._on_results)
        self._thread.start()

    def _on_results(self, results):
        self.status_lbl.setText(
            f"{self.item_data.get('name','')} — observability score over ±7 days  "
            f"(40% altitude quality · 35% moon avoidance · 25% imaging window)")

        if not results:
            if not _HAS_PG:
                self.text.setPlainText("No results.")
            return

        dates  = [r[0] for r in results]
        scores = [r[1] for r in results]
        phases = [r[2] for r in results]
        center = self.observer["date"]

        if _HAS_PG:
            pw = self.plot
            pw.clear()

            # X axis: integer indices, label with dates
            xs = list(range(len(dates)))
            ticks = [(i, d[5:]) for i, d in enumerate(dates)]   # MM-DD
            pw.getAxis("bottom").setTicks([ticks])

            # Moon phase backdrop — light grey fill proportional to phase
            for i, phase in enumerate(phases):
                alpha = int(phase * 0.6)   # 0 = new moon (transparent), 60 = full
                pw.addItem(pg.LinearRegionItem(
                    values=(i - 0.4, i + 0.4),
                    orientation='vertical',
                    brush=pg.mkBrush(200, 200, 220, alpha),
                    pen=pg.mkPen(None),
                    movable=False,
                ))

            # Score bars
            bg = pg.BarGraphItem(
                x=xs, height=scores, width=0.6,
                brush=pg.mkBrush(80, 180, 255, 180),
                pen=pg.mkPen("w", width=0.5),
            )
            pw.addItem(bg)

            # Score line
            pw.plot(xs, scores,
                    pen=pg.mkPen("y", width=2),
                    symbol="o", symbolSize=6,
                    symbolBrush=pg.mkBrush("y"))

            # Highlight the target date
            try:
                ci = dates.index(center)
                pw.addLine(x=ci, pen=pg.mkPen("r", width=2,
                           style=Qt.PenStyle.DashLine))
            except ValueError:
                pass

            # Score labels above bars
            for i, (s, p) in enumerate(zip(scores, phases)):
                text = pg.TextItem(f"{s:.0f}\n🌙{p}%", anchor=(0.5, 1.0),
                                   color="w")
                text.setPos(i, s + 2)
                pw.addItem(text)

        else:
            lines = ["Date         Score  Moon%"]
            for d, s, p in results:
                marker = " ◀" if d == center else ""
                lines.append(f"{d}   {s:5.1f}  {p:3d}%{marker}")
            self.text.setPlainText("\n".join(lines))

class ObjectSearchThread(QThread):
    progress     = pyqtSignal(int)
    result_ready = pyqtSignal(list)

    def __init__(self, ra_deg, dec_deg, lat, lon, tz_name, start_date_str,
                 horizon_points=None):
        super().__init__()
        self.ra_deg         = ra_deg
        self.dec_deg        = dec_deg
        self.lat            = lat
        self.lon            = lon
        self.tz_name        = tz_name
        self.start_date_str = start_date_str
        self.horizon_points = horizon_points or []

    def run(self):
        from datetime import timedelta
        from concurrent.futures import ThreadPoolExecutor, as_completed

        try:
            start = datetime.strptime(self.start_date_str, "%Y-%m-%d")
            all_dates = [
                (start + timedelta(days=i)).strftime("%Y-%m-%d")
                for i in range(365)
            ]

            # Group into 12 chunks (~30 days each) — one thread per month
            chunk_size = 31
            chunks = [all_dates[i:i+chunk_size]
                      for i in range(0, len(all_dates), chunk_size)]

            results = {}
            completed = 0

            def _score_chunk(date_list):
                out = []
                for d_str in date_list:
                    score, phase = _score_target_for_date(
                        self.ra_deg, self.dec_deg,
                        self.lat, self.lon, d_str, self.tz_name,
                        horizon_points=self.horizon_points)
                    out.append((d_str, score, phase))
                return out

            with ThreadPoolExecutor(max_workers=min(12, len(chunks))) as pool:
                futures = {pool.submit(_score_chunk, chunk): i
                           for i, chunk in enumerate(chunks)}
                for future in as_completed(futures):
                    chunk_results = future.result()
                    for item in chunk_results:
                        results[item[0]] = item
                    completed += 1
                    self.progress.emit(int(completed / len(chunks) * 100))

            # Return in chronological order
            ordered = [results[d] for d in all_dates if d in results]
            self.progress.emit(100)
            self.result_ready.emit(ordered)

        except Exception:
            self.progress.emit(100)
            self.result_ready.emit([])


class ObjectSearchResultDialog(QDialog):
    def __init__(self, obj_data: dict, observer: dict, yearly_results: list, parent=None):
        super().__init__(parent)
        self.obj_data       = obj_data
        self.observer       = observer
        self.yearly_results = yearly_results  # [(date_str, score, phase_pct), ...]
        name = obj_data.get("name", "Object")
        self.setWindowTitle(f"Object Search — {name}")
        self.resize(1000, 700)
        self._build_ui()

    def _build_ui(self):
        from collections import defaultdict
        import calendar

        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)
        outer.setSpacing(8)

        name = self.obj_data.get("name", "")
        ra   = self.obj_data.get("ra", 0.0)
        dec  = self.obj_data.get("dec", 0.0)

        # ── Summary header ────────────────────────────────────────────────
        if self.yearly_results:
            best       = max(self.yearly_results, key=lambda r: r[1])
            best_date  = best[0]
            best_score = best[1]
            best_dt    = datetime.strptime(best_date, "%Y-%m-%d")
            best_month = best_dt.strftime("%B %Y")

            month_scores = defaultdict(list)
            for d_str, score, _ in self.yearly_results:
                month_key = d_str[:7]
                month_scores[month_key].append(score)
            best_month_key = max(month_scores, key=lambda k: sum(month_scores[k]) / len(month_scores[k]))
            best_month_avg  = sum(month_scores[best_month_key]) / len(month_scores[best_month_key])
            bm_dt = datetime.strptime(best_month_key + "-01", "%Y-%m-%d")
            best_month_name = bm_dt.strftime("%B %Y")
            badge = _score_badge(best_score)
            month_badge = _score_badge(best_month_avg)
            summary = QLabel(
                f"<b>{name}</b>   RA {ra:.3f}°  Dec {dec:+.3f}°  |  "
                f"Best night: <b>{best_date}</b> (score {best_score:.0f}/100 {badge})  |  "
                f"Best month: <b>{best_month_name}</b> (avg {best_month_avg:.0f}/100 {month_badge})"
            )
        else:
            summary = QLabel(
                f"<b>{name}</b>   RA {ra:.3f}°  Dec {dec:+.3f}°  |  "
                f"No observability data available."
            )
        summary.setWordWrap(True)
        summary.setStyleSheet("font-size: 12px; padding: 4px;")
        outer.addWidget(summary)

        # ── Tabs ──────────────────────────────────────────────────────────
        tabs = QTabWidget()
        outer.addWidget(tabs, 1)

        # Tab 1: 12-month score chart
        if _HAS_PG and self.yearly_results:
            month_tab = QWidget()
            mt_lay = QVBoxLayout(month_tab)
            mt_lay.setContentsMargins(4, 4, 4, 4)

            pw = pg.PlotWidget()
            pw.setLabel("bottom", "Month")
            pw.setLabel("left", "Avg Score (0–100)")
            pw.showGrid(x=False, y=True, alpha=0.3)
            pw.setYRange(0, 100, padding=0.05)

            # Build monthly averages in order
            month_scores_ordered = defaultdict(list)
            for d_str, score, phase in self.yearly_results:
                month_scores_ordered[d_str[:7]].append(score)

            sorted_months = sorted(month_scores_ordered.keys())
            xs     = list(range(len(sorted_months)))
            avgs   = [sum(month_scores_ordered[m]) / len(month_scores_ordered[m])
                      for m in sorted_months]
            labels = [(i, datetime.strptime(m + "-01", "%Y-%m-%d").strftime("%b '%y"))
                      for i, m in enumerate(sorted_months)]

            pw.getAxis("bottom").setTicks([labels])

            # Color bars by score
            for i, (avg, month) in enumerate(zip(avgs, sorted_months)):
                r = int(255 * (1 - avg / 100))
                g = int(200 * avg / 100)
                bar = pg.BarGraphItem(
                    x=[i], height=[avg], width=0.7,
                    brush=pg.mkBrush(r, g, 80, 200),
                    pen=pg.mkPen("w", width=0.3),
                )
                pw.addItem(bar)

                # Score label above bar
                badge = _score_badge(avg)
                txt = pg.TextItem(f"{avg:.0f} {badge}", anchor=(0.5, 1.0), color="w")
                txt.setPos(i, avg + 1)
                pw.addItem(txt)

            # Highlight best month
            try:
                bi = sorted_months.index(best_month_key)
                pw.addLine(x=bi, pen=pg.mkPen("y", width=2,
                           style=Qt.PenStyle.DashLine))
            except Exception:
                pass

            # Daily score line overlay
            # Aggregate into per-day xs mapped to fractional month position
            day_xs, day_ys = [], []
            for d_str, score, _ in self.yearly_results:
                m_key = d_str[:7]
                if m_key in sorted_months:
                    mi  = sorted_months.index(m_key)
                    dom = int(d_str[8:10])
                    _, mdays = calendar.monthrange(
                        int(d_str[:4]), int(d_str[5:7]))
                    frac = mi + (dom - 1) / mdays
                    day_xs.append(frac)
                    day_ys.append(score)

            pw.plot(day_xs, day_ys,
                    pen=pg.mkPen((255, 255, 100, 80), width=1),
                    name="Daily score")

            mt_lay.addWidget(pw)
            tabs.addTab(month_tab, "Monthly Overview")

        # Tab 2: Best night altitude curve
        alt_best_tab = QWidget()
        ab_lay = QVBoxLayout(alt_best_tab)
        ab_lay.setContentsMargins(4, 4, 4, 4)
        if _HAS_PG and best_date and best_date != "—":
            try:
                obs_best = dict(self.observer)
                obs_best["date"] = best_date
                obs_best["time"] = "22:00"
                self._add_alt_plot(ab_lay, ra, dec, obs_best,
                                   f"Altitude on best night ({best_date})")
            except Exception as e:
                ab_lay.addWidget(QLabel(f"Could not plot: {e}"))
        else:
            ab_lay.addWidget(QLabel("pyqtgraph not installed." if not _HAS_PG
                                    else "No results available."))
        tabs.addTab(alt_best_tab, f"Best Night ({best_date})")

        # Tab 3: Tonight altitude curve
        alt_now_tab = QWidget()
        an_lay = QVBoxLayout(alt_now_tab)
        an_lay.setContentsMargins(4, 4, 4, 4)
        tonight = self.observer.get("date", datetime.now().strftime("%Y-%m-%d"))
        if _HAS_PG:
            try:
                self._add_alt_plot(an_lay, ra, dec, self.observer,
                                   f"Altitude tonight ({tonight})")
            except Exception as e:
                an_lay.addWidget(QLabel(f"Could not plot: {e}"))
        else:
            an_lay.addWidget(QLabel("pyqtgraph not installed."))
        tabs.addTab(alt_now_tab, f"Tonight ({tonight})")

        # Tab 4: SIMBAD (reuse existing thread)
        simbad_tab = QWidget()
        sb_lay = QVBoxLayout(simbad_tab)
        self._simbad_text = QTextEdit()
        self._simbad_text.setReadOnly(True)
        self._simbad_text.setPlainText("Querying SIMBAD…")
        sb_lay.addWidget(self._simbad_text)
        tabs.addTab(simbad_tab, "SIMBAD Details")
        self._start_simbad(name, ra, dec)

        # Bottom row
        btn_row = QHBoxLayout()
        btn_row.addStretch()
 
        btn_vis = QPushButton("Full Visibility Dialog…")
        btn_vis.clicked.connect(self._open_full_visibility)
        btn_row.addWidget(btn_vis)
 
        btn_aladin = QPushButton("Open in Aladin")
        btn_aladin.clicked.connect(lambda: webbrowser.open(
            f"https://aladin.cds.unistra.fr/AladinLite/"
            f"?target={ra:.5f}+{dec:+.5f}&fov=0.5&survey=P/DSS2/color"))
        btn_row.addWidget(btn_aladin)
 
        btn_finder = QPushButton("Finder Chart…")
        btn_finder.clicked.connect(self._open_finder_chart)
        btn_row.addWidget(btn_finder)
 
        btn_fieldrot = QPushButton("🔄 Field Rotation…")
        btn_fieldrot.clicked.connect(self._open_field_rotation)
        btn_row.addWidget(btn_fieldrot)
 
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        btn_row.addWidget(btn_close)
        outer.addLayout(btn_row)


    def _open_finder_chart(self):
        try:
            from setiastro.saspro.finder_chart import FinderChartFromCoordDialog
            from PyQt6.QtCore import QSettings
        except ImportError as e:
            QMessageBox.warning(self, "Finder Chart",
                f"Finder chart module not available:\n{e}")
            return

        dlg = FinderChartFromCoordDialog(
            name=self.obj_data.get("name", "Object"),
            ra_deg=self.obj_data.get("ra", 0.0),
            dec_deg=self.obj_data.get("dec", 0.0),
            settings=QSettings(),
            parent=self,
        )
        dlg.show()

    def _add_alt_plot(self, layout, ra, dec, observer, title):
        times, hrs, obj_alts, sun_alts, moon_alts, loc = _compute_alt_curve(
            ra, dec,
            observer["lat"], observer["lon"],
            observer["date"], observer["tz"]
        )

        obj_coord_az = SkyCoord(ra=ra * u.deg, dec=dec * u.deg)
        frame_az     = AltAz(obstime=times, location=loc)
        obj_az       = obj_coord_az.transform_to(frame_az).az.deg

        pw = pg.PlotWidget(title=title)
        pw.setLabel("bottom", "Local Time (h)")
        pw.setLabel("left", "Altitude (°)")
        pw.showGrid(x=True, y=True, alpha=0.3)
        pw.setYRange(-10, 90)
        pw.setXRange(12, 36, padding=0)

        ticks = [(h, str(h if h <= 23 else h - 24)) for h in range(12, 37, 2)]
        pw.getAxis("bottom").setTicks([ticks])
        pw.setBackground(pg.mkColor(40, 55, 120, 255))

        # Night shading
        astro_mask = sun_alts < -18
        changes = np.where(np.diff(astro_mask.astype(int)))[0]
        if len(changes) >= 2:
            night_start = float(hrs[changes[0]])
            night_end   = float(hrs[changes[-1]])
            region = pg.LinearRegionItem(
                values=(night_start, night_end),
                orientation='vertical',
                brush=pg.mkBrush(0, 0, 20, 180),
                pen=pg.mkPen(None),
                movable=False,
            )
            pw.addItem(region)

        pw.plot(hrs, obj_alts,
                pen=pg.mkPen("y", width=2.5),
                name=self.obj_data.get("name", "Object"))
        pw.plot(hrs, moon_alts,
                pen=pg.mkPen((180, 180, 180), width=1.2,
                            style=Qt.PenStyle.DashLine),
                name="Moon")
        pw.addLine(y=0,  pen=pg.mkPen("w", width=1, style=Qt.PenStyle.DashLine))
        pw.addLine(y=30, pen=pg.mkPen("g", width=1, style=Qt.PenStyle.DotLine))

        # ── Custom horizon overlay ────────────────────────────────────────────
        horizon_pts = observer.get("horizon_points", [])
        h_lim = None
        if horizon_pts:
            try:
                obj_coord_h = SkyCoord(ra=ra * u.deg, dec=dec * u.deg)
                frame_h     = AltAz(obstime=times, location=loc)
                altaz_h     = obj_coord_h.transform_to(frame_h)
                obj_az      = altaz_h.az.deg
                h_lim = np.array([
                    _horizon_min_alt(float(az), horizon_pts)
                    for az in obj_az
                ], dtype=float)
                h_top  = pg.PlotDataItem(hrs, h_lim)
                h_bot  = pg.PlotDataItem(hrs, np.zeros_like(h_lim))
                h_fill = pg.FillBetweenItem(
                    h_bot, h_top,
                    brush=pg.mkBrush(255, 140, 0, 90),
                )
                pw.addItem(h_fill)
                pw.plot(hrs, h_lim,
                        pen=pg.mkPen((255, 140, 0), width=1.5,
                                    style=Qt.PenStyle.DashLine),
                        name="Horizon limit")
            except Exception:
                pass

        # ── Azimuth compass labels ────────────────────────────────────────────
        try:
            def _az_to_compass(az: float) -> str:
                dirs = ["N","NNE","NE","ENE","E","ESE","SE","SSE",
                        "S","SSW","SW","WSW","W","WNW","NW","NNW"]
                idx = int((az + 11.25) / 22.5) % 16
                return dirs[idx]

            step = max(1, len(hrs) // 12)
            labeled_xs = set()
            for i in range(0, len(hrs), step):
                alt_val = float(obj_alts[i])
                if alt_val < -5:
                    continue
                x = float(hrs[i])
                y = float(alt_val)
                too_close = any(abs(x - lx) < 1.5 for lx in labeled_xs)
                if too_close:
                    continue
                labeled_xs.add(x)
                compass = _az_to_compass(float(obj_az[i]))
                lbl = pg.TextItem(
                    compass,
                    anchor=(0.5, 1.2),
                    color=(220, 180, 80),
                )
                lbl.setFont(__import__('PyQt6.QtGui', fromlist=['QFont']).QFont("", 7))
                lbl.setPos(x, y)
                pw.addItem(lbl)
        except Exception:
            pass

        pw.addLegend()

        # ── Peak marker ───────────────────────────────────────────────────────
        peak_idx = int(np.argmax(obj_alts))
        peak_alt = float(obj_alts[peak_idx])
        peak_hr  = float(hrs[peak_idx])
        pw.addLine(x=peak_hr, pen=pg.mkPen("r", width=1,
                style=Qt.PenStyle.DashLine))
        txt = pg.TextItem(f"Peak {peak_alt:.0f}°", color="r", anchor=(0, 1))
        txt.setPos(peak_hr, peak_alt)
        pw.addItem(txt)

        layout.addWidget(pw)

        # ── Stats label ───────────────────────────────────────────────────────
        imaging_hrs = float(np.sum((obj_alts >= 20) & (sun_alts < -18))) * (24.0 / len(times))

        if horizon_pts and h_lim is not None:
            try:
                effective_mask = (obj_alts >= np.maximum(h_lim, 20.0)) & (sun_alts < -18)
                effective_hrs  = float(np.sum(effective_mask)) * (24.0 / len(times))
                stats = QLabel(
                    f"Peak altitude: {peak_alt:.1f}°  |  "
                    f"Imaging window (>20°, astro night): {imaging_hrs:.1f} h  |  "
                    f"Effective above horizon: {effective_hrs:.1f} h"
                )
            except Exception:
                stats = QLabel(
                    f"Peak altitude: {peak_alt:.1f}°  |  "
                    f"Imaging window (>20°, astro night): {imaging_hrs:.1f} h"
                )
        else:
            stats = QLabel(
                f"Peak altitude: {peak_alt:.1f}°  |  "
                f"Imaging window (>20°, astro night): {imaging_hrs:.1f} h"
            )
        stats.setStyleSheet("font-size: 11px; padding: 2px 4px;")
        layout.addWidget(stats)


    def _open_field_rotation(self):
        """
        Open the Alt/Az Field Rotation Calculator for this object, using the
        best viewing night discovered by the year-long score sweep.
 
        We compute the full altitude curve for the best night, find the moment
        of peak altitude (transit), and use that alt/az as the pre-fill.  This
        gives the *worst-case* rotation for the night — which is the most
        informative single-point value — while the night curve in the dialog
        shows the full picture across the night.
        """
        name     = self.obj_data.get("name", "Object")
        ra       = self.obj_data.get("ra",  0.0)
        dec      = self.obj_data.get("dec", 0.0)
        lat      = self.observer["lat"]
        lon      = self.observer["lon"]
        tz       = self.observer["tz"]
 
        # Use the best night if the yearly sweep found one, else fall back to
        # the observer's current date.
        if self.yearly_results:
            best_date = max(self.yearly_results, key=lambda r: r[1])[0]
        else:
            best_date = self.observer.get("date", "")
 
        alt_prefill = None
        az_prefill  = None
 
        if best_date:
            try:
                # Reuse _compute_alt_curve — same function used everywhere else
                times, hrs, obj_alts, sun_alts, moon_alts, loc = \
                    _compute_alt_curve(ra, dec, lat, lon, best_date, tz)
 
                from astropy import units as u
                from astropy.coordinates import SkyCoord, AltAz
 
                peak_idx = int(np.argmax(obj_alts))
                frame    = AltAz(obstime=times, location=loc)
                altaz    = SkyCoord(ra=ra * u.deg,
                                    dec=dec * u.deg).transform_to(frame)
                alt_prefill = float(altaz.alt.deg[peak_idx])
                az_prefill  = float(altaz.az.deg[peak_idx])
            except Exception:
                pass   # fall through to manual entry if ephemeris fails
 
        from setiastro.saspro.altaz_field_rotation import AltAzFieldRotationDialog
        dlg = AltAzFieldRotationDialog(
            lat=lat,
            lon=lon,
            alt=alt_prefill,
            az=az_prefill,
            ra_deg=ra,
            dec_deg=dec,
            date_str=best_date or None,
            tz_name=tz,
            target_name=name,
            settings=QSettings(),
            parent=self,
        )
        dlg.show()
 


    def _start_simbad(self, name, ra, dec):
        alt_name = self.obj_data.get("alt_name", "")
        self._simbad_thread = ObjectDetailThread(name, ra, dec, alt_name=alt_name)
        self._simbad_thread.result_ready.connect(self._on_simbad_ready)
        self._simbad_thread.start()

    def _on_simbad_ready(self, info: dict):
        s = info.get("simbad", {})
        if not s:
            self._simbad_text.setPlainText(
                f"No SIMBAD match found for '{info.get('name', '')}'.")
            return
        maj = s.get("maj_axis", "—")
        mn  = s.get("min_axis", "—")
        size_str = f"{maj}′ × {mn}′" if maj != "—" else "—"
        lines = [
            f"Main ID:       {s.get('main_id','—')}",
            f"Object type:   {s.get('otype','—')}",
            f"",
            f"V magnitude:   {s.get('vmag','—')}",
            f"B magnitude:   {s.get('bmag','—')}",
            f"Spectral type: {s.get('sp_type','—')}",
            f"Angular size:  {size_str}",
            f"",
            f"Radial vel.:   {s.get('rv','—')} km/s",
            f"Redshift z:    {s.get('redshift','—')}",
            f"",
            f"RA:            {info.get('ra', 0):.5f}°",
            f"Dec:           {info.get('dec', 0):.5f}°",
        ]
        self._simbad_text.setPlainText("\n".join(lines))

    def _open_full_visibility(self):
        data = dict(self.obj_data)
        data["horizon_points"] = self.observer.get("horizon_points", [])
        dlg = ObjectVisibilityDialog(data, self.observer, parent=self)
        dlg.show()

def _parse_ra_dec(ra_str: str, dec_str: str):
    """
    Parse RA and Dec from flexible string formats.
    RA accepts:  81.629  |  5h26m31.2s  |  5:26:31.2  |  5h 26m 31.2s
    Dec accepts: 60.05   |  60d03m00s   |  60:03:00   |  -60d03m00s
    Returns (ra_deg, dec_deg) on success, or (None, error_message) on failure.
    """
    import re
    from astropy.coordinates import Angle
    import astropy.units as u

    def _parse_ra(s: str):
        s = s.strip()
        if not s:
            raise ValueError("RA is empty")

        # Normalize separators: 5:26:31.2 → 5h26m31.2s
        # but only if it looks like hms (has colons and no h/d markers)
        if re.match(r'^[\d]+:[\d]+', s) and 'h' not in s and 'd' not in s:
            parts = s.split(':')
            if len(parts) == 3:
                s = f"{parts[0]}h{parts[1]}m{parts[2]}s"
            elif len(parts) == 2:
                s = f"{parts[0]}h{parts[1]}m"

        # Add missing unit markers: "5h26m31.2" → "5h26m31.2s"
        s = re.sub(r'(\d+\.?\d*)\s*h\s*(\d+\.?\d*)\s*m\s*(\d+\.?\d*)$',
                   r'\1h\2m\3s', s)
        s = re.sub(r'(\d+\.?\d*)\s*h\s*(\d+\.?\d*)$',
                   r'\1h\2m', s)

        # Try as plain degrees first if no letters
        if re.match(r'^-?\d+\.?\d*$', s):
            val = float(s)
            if not (0 <= val <= 360):
                raise ValueError(f"RA degrees must be 0–360, got {val}")
            return val

        # Try hourangle
        try:
            return float(Angle(s, unit=u.hourangle).deg) % 360
        except Exception:
            pass

        # Try degrees with letter markers
        try:
            return float(Angle(s, unit=u.deg).deg) % 360
        except Exception:
            pass

        raise ValueError(f"Could not parse RA: '{s}'")

    def _parse_dec(s: str):
        s = s.strip()
        if not s:
            raise ValueError("Dec is empty")

        negative = s.startswith('-')

        # Normalize colon-separated: 60:03:00 → 60d03m00s
        if re.match(r'^-?[\d]+:[\d]+', s) and 'h' not in s and 'd' not in s:
            sign = '-' if negative else ''
            parts = s.lstrip('-').split(':')
            if len(parts) == 3:
                s = f"{sign}{parts[0]}d{parts[1]}m{parts[2]}s"
            elif len(parts) == 2:
                s = f"{sign}{parts[0]}d{parts[1]}m"

        # Add missing trailing unit: "60d03m00" → "60d03m00s"
        s = re.sub(r'(\d+\.?\d*)\s*d\s*(\d+\.?\d*)\s*m\s*(\d+\.?\d*)$',
                   r'\1d\2m\3s', s)

        # Plain degrees
        if re.match(r'^-?\d+\.?\d*$', s):
            val = float(s)
            if not (-90 <= val <= 90):
                raise ValueError(f"Dec degrees must be -90–90, got {val}")
            return val

        try:
            val = float(Angle(s, unit=u.deg).deg)
            if not (-90 <= val <= 90):
                raise ValueError(f"Dec out of range: {val}")
            return val
        except Exception:
            pass

        raise ValueError(f"Could not parse Dec: '{s}'")

    try:
        ra_deg  = _parse_ra(ra_str)
        dec_deg = _parse_dec(dec_str)
        return ra_deg, dec_deg
    except ValueError as e:
        return None, str(e)
    
class ObjectSearchDialog(QDialog):
    """
    Search the celestial catalog by name, then show a full analysis
    of the best viewing period for the selected object.
    """

    def __init__(self, catalog_file: str, observer: dict, parent=None):
        super().__init__(parent)
        self.catalog_file = catalog_file
        self.observer     = observer
        self._df          = None
        self._search_thread = None
        self.setWindowTitle("Object Search")
        self.resize(560, 420)
        self._build_ui()
        self._load_catalog()

    def _load_catalog(self):
        try:
            self._df = _load_full_catalog(self.catalog_file)
        except Exception as e:
            self._status.setText(f"Could not load catalog: {e}")

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(8)

        # Search row
        search_row = QHBoxLayout()
        self._search_box = QLineEdit()
        self._search_box.setPlaceholderText("Type object name, e.g. M42, NGC 891, Abell 1242…")
        self._search_box.returnPressed.connect(self._do_search)
        search_row.addWidget(self._search_box, 1)
        btn_search = QPushButton("Search")
        btn_search.clicked.connect(self._do_search)
        search_row.addWidget(btn_search)
        search_row.addSpacing(20)
        btn_manual = QPushButton("Manual RA/Dec…")
        btn_manual.clicked.connect(self._on_manual_radec)
        search_row.addWidget(btn_manual)

        outer.addLayout(search_row)

        self._status = QLabel("Enter an object name to search the catalog.")
        self._status.setStyleSheet("font-size:11px; color: palette(placeholderText);")
        outer.addWidget(self._status)

        # Results list
        from PyQt6.QtWidgets import QListWidget
        self._results_list = QListWidget()
        self._results_list.itemDoubleClicked.connect(self._on_item_selected)
        outer.addWidget(self._results_list, 1)

        #sasprogress bar (hidden until needed)
        from PyQt6.QtWidgets import QProgressBar
        self._progress = QProgressBar()
        self._progress.setRange(0, 100)
        self._progress.hide()
        outer.addWidget(self._progress)

        # Bottom buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        self._btn_analyse = QPushButton("Analyse Selected Object…")
        self._btn_analyse.setEnabled(False)
        self._btn_analyse.clicked.connect(self._on_analyse)
        btn_row.addWidget(self._btn_analyse)
        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.reject)
        btn_row.addWidget(btn_close)
        outer.addLayout(btn_row)

        self._results_list.currentRowChanged.connect(
            lambda row: self._btn_analyse.setEnabled(row >= 0))

        # Store matched rows for lookup
        self._matched_rows = []

    def _on_manual_radec(self):
        from PyQt6.QtWidgets import QDialog, QFormLayout, QDialogButtonBox

        dlg = QDialog(self)
        dlg.setWindowTitle("Manual RA / Dec Entry")
        dlg.setMinimumWidth(380)
        form = QFormLayout(dlg)
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)

        name_edit = QLineEdit()
        name_edit.setPlaceholderText("e.g. OU4, Squid Nebula…")

        ra_edit = QLineEdit()
        ra_edit.setPlaceholderText("81.629  or  5h26m31.2s  or  5:26:31.2")

        dec_edit = QLineEdit()
        dec_edit.setPlaceholderText("60.05  or  60d03m00s  or  60:03:00")

        hint = QLabel(
            "<small>RA accepts degrees, h m s, or hh:mm:ss.s<br>"
            "Dec accepts degrees, d m s, or dd:mm:ss.s  (prefix − for south)</small>"
        )
        hint.setWordWrap(True)

        form.addRow("Name / label:", name_edit)
        form.addRow("RA:", ra_edit)
        form.addRow("Dec:", dec_edit)
        form.addRow(hint)

        err_lbl = QLabel("")
        err_lbl.setStyleSheet("color: red; font-size: 11px;")
        err_lbl.setWordWrap(True)
        form.addRow(err_lbl)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel
        )
        form.addRow(buttons)
        buttons.rejected.connect(dlg.reject)

        def _try_accept():
            ra_deg, dec_deg = _parse_ra_dec(ra_edit.text(), dec_edit.text())
            if ra_deg is None:
                err_lbl.setText(dec_deg)  # dec_deg holds error message on failure
                return
            dlg._ra  = ra_deg
            dlg._dec = dec_deg
            dlg.accept()

        buttons.accepted.connect(_try_accept)

        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        ra  = dlg._ra
        dec = dlg._dec
        name = name_edit.text().strip() or f"RA {ra:.4f}° Dec {dec:+.4f}°"

        obj = {"name": name, "alt_name": "", "ra": ra, "dec": dec}

        self._btn_analyse.setEnabled(False)
        self._progress.setValue(0)
        self._progress.show()
        self._status.setText(f"Computing yearly visibility for {name}…")

        start = self.observer.get("date", datetime.now().strftime("%Y-%m-%d"))
        self._search_thread = ObjectSearchThread(
            ra, dec,
            self.observer["lat"], self.observer["lon"],
            self.observer["tz"], start,
            horizon_points=self.observer.get("horizon_points", []),
        )
        self._search_thread.progress.connect(self._progress.setValue)
        self._search_thread.result_ready.connect(
            lambda results, o=obj: self._on_results_ready(o, results))
        self._current_obj = obj
        self._search_thread.start()

    def _do_search(self):
        query = self._search_box.text().strip()
        if not query:
            return
        if self._df is None:
            self._status.setText("Catalog not loaded.")
            return

        import re as _re
        q = query.lower().strip()

        # ── PK → PN-G translation ─────────────────────────────────────────
        # Users may type "PK 064.6+48.2" or "PK064.6+48.2" — map to PN-G
        def _pk_to_png(s: str) -> str:
            return _re.sub(r'^pk\s*', 'pn-g ', s.strip().lower())

        q_is_pk = _re.match(r'^pk[\s\d]', q) is not None
        q_png   = _pk_to_png(q) if q_is_pk else q   # "pn-g 064.6+48.2"

        q_spaced = _re.sub(
            r'^(ngc|ic|m|ugc|pgc|aco|lbn|ldn|sh2|png|pn-g|abell|sh2-?|pk|arp)\s*(\d)',
            r'\1 \2', q
        )
        q_compact = _re.sub(r'\s+', '', q)
        q_png_spaced  = _re.sub(r'\s+', ' ', q_png).strip() if q_is_pk else q_spaced
        q_png_compact = _re.sub(r'\s+', '', q_png)          if q_is_pk else q_compact

        def _normalize(s):
            s = str(s).lower().strip()
            # Normalize PK → PN-G in catalog data too
            s = _re.sub(r'^pk\s*', 'pn-g ', s)
            return _re.sub(
                r'^(ngc|ic|m|ugc|pgc|aco|lbn|ldn|sh2|png|pn-g|abell|sh2-?)\s*(\d)',
                r'\1 \2', s
            )

        name_col    = self._df["Name"].astype(str).apply(_normalize)
        altname_col = self._df.get("Alt Name", pd.Series(dtype=str)).astype(str).apply(_normalize)

        mask = (
            name_col.str.contains(_re.escape(q),           na=False) |
            name_col.str.contains(_re.escape(q_spaced),    na=False) |
            name_col.str.contains(_re.escape(q_compact),   na=False) |
            altname_col.str.contains(_re.escape(q),        na=False) |
            altname_col.str.contains(_re.escape(q_spaced), na=False) |
            self._df["Name"].astype(str).str.lower().str.contains(
                _re.escape(q_compact), na=False)
        )

        # If PK query, also search the PN-G translated forms
        if q_is_pk:
            mask = mask | (
                name_col.str.contains(_re.escape(q_png),         na=False) |
                name_col.str.contains(_re.escape(q_png_spaced),  na=False) |
                name_col.str.contains(_re.escape(q_png_compact), na=False)
            )

        matches = self._df[mask].head(50)

        self._results_list.clear()
        self._matched_rows = []

        if matches.empty:
            self._status.setText(f"No matches found for '{query}'.")
            return

        self._status.setText(f"{len(matches)} match{'es' if len(matches)!=1 else ''} found.")
        for _, row in matches.iterrows():
            alt  = str(row.get("Alt Name", "")) if pd.notna(row.get("Alt Name", "")) else ""
            typ  = str(row.get("Type", ""))     if pd.notna(row.get("Type", ""))     else ""
            mag  = str(row.get("Magnitude","")) if pd.notna(row.get("Magnitude","")) else ""
            disp = row["Name"]
            if alt and alt != row["Name"]:
                disp += f"  /  {alt}"
            if typ:
                disp += f"  [{typ}]"
            if mag:
                disp += f"  mag {mag}"
            self._results_list.addItem(disp)
            self._matched_rows.append(row)

    def _on_item_selected(self, item):
        self._on_analyse()

    def _on_analyse(self):
        idx = self._results_list.currentRow()
        if idx < 0 or idx >= len(self._matched_rows):
            return

        row = self._matched_rows[idx]
        obj = {
            "name":     str(row["Name"]),
            "alt_name": str(row.get("Alt Name", "") or ""),
            "ra":       float(row["RA"]),
            "dec":      float(row["Dec"]),
        }

        if not self.observer:
            QMessageBox.information(self, "Object Search",
                "Run Calculate in WIMS first so the observer location is known.")
            return

        # Show a loading state and kick off the year-long score sweep
        self._btn_analyse.setEnabled(False)
        self._progress.setValue(0)
        self._progress.show()
        self._status.setText(f"Computing yearly visibility for {obj['name']}…")

        start = self.observer.get("date", datetime.now().strftime("%Y-%m-%d"))
        self._search_thread = ObjectSearchThread(
            obj["ra"], obj["dec"],
            self.observer["lat"], self.observer["lon"],
            self.observer["tz"],
            start,
            horizon_points=self.observer.get("horizon_points", []),
        )
        self._search_thread.progress.connect(self._progress.setValue)
        self._search_thread.result_ready.connect(
            lambda results, o=obj: self._on_results_ready(o, results))
        self._current_obj = obj
        self._search_thread.start()

    def _on_results_ready(self, obj, results):
        self._progress.hide()
        self._btn_analyse.setEnabled(True)
        self._status.setText(f"Done. Showing results for {obj['name']}.")
        dlg = ObjectSearchResultDialog(obj, self.observer, results, parent=self)
        dlg.show()


# ── Module-level constants (add near top of whatsinmysky.py) ──────────────────
USER_OBJECTS_PATH    = os.path.join(os.path.expanduser("~"), "saspro_user_objects.csv")
_USER_OBJECTS_COLS   = ["Name", "RA", "Dec", "Alt Name", "Type", "Magnitude", "Info", "Catalog"]


def _migrate_user_objects_from_home_catalog():
    """
    One-time migration: if the old celestial_catalog.csv exists in user home
    and contains User catalog rows, extract them into saspro_user_objects.csv
    before we stop using the home copy.
    Called once at startup.
    """
    old_path = os.path.join(os.path.expanduser("~"), "celestial_catalog.csv")
    if not os.path.exists(old_path):
        return
    if os.path.exists(USER_OBJECTS_PATH):
        return  # already migrated

    try:
        old_df   = pd.read_csv(old_path, encoding="ISO-8859-1", quotechar='"', quoting=0)
        user_rows = old_df[old_df["Catalog"].astype(str).str.strip().str.upper() == "USER"]
        if user_rows.empty:
            print("[WIMS] No user objects found in old home catalog — nothing to migrate.")
        else:
            # Ensure all expected columns exist
            for col in _USER_OBJECTS_COLS:
                if col not in user_rows.columns:
                    user_rows = user_rows.copy()
                    user_rows[col] = ""
            user_rows[_USER_OBJECTS_COLS].to_csv(
                USER_OBJECTS_PATH, index=False, encoding="utf-8")
            print(f"[WIMS] Migrated {len(user_rows)} user object(s) → {USER_OBJECTS_PATH}")
    except Exception as e:
        print(f"[WIMS] Migration failed: {e}")


def _load_full_catalog(catalog_file: str) -> pd.DataFrame:
    """
    Load bundled catalog + user objects CSV, merged into one DataFrame.
    The bundled catalog is never written to. User objects live separately.
    """
    frames = []

    if catalog_file and os.path.exists(catalog_file):
        try:
            frames.append(pd.read_csv(catalog_file, encoding="ISO-8859-1",
                                      quotechar='"', quoting=0))
        except Exception as e:
            print(f"[WIMS] Could not load bundled catalog: {e}")

    if os.path.exists(USER_OBJECTS_PATH):
        try:
            user_df = pd.read_csv(USER_OBJECTS_PATH, encoding="utf-8",
                                  quotechar='"', quoting=0)
            # Force Catalog column to "User" in case it got blank somehow
            user_df["Catalog"] = "User"
            frames.append(user_df)
        except Exception as e:
            print(f"[WIMS] Could not load user objects: {e}")

    if not frames:
        return pd.DataFrame(columns=_USER_OBJECTS_COLS)

    return pd.concat(frames, ignore_index=True)
# ---------------------------------------------------
#  Worker thread
# ---------------------------------------------------
class CalculationThread(QThread):
    calculation_complete   = pyqtSignal(pd.DataFrame, str)
    lunar_phase_calculated = pyqtSignal(int, str, str)
    lst_calculated         = pyqtSignal(str)
    status_update          = pyqtSignal(str)

    def __init__(self, latitude, longitude, date, time, timezone,
                min_altitude, catalog_filters, object_limit,
                horizon_points=None, type_filters=None, sort_by_score=False):  
        super().__init__()
        self.latitude        = float(latitude)
        self.longitude       = float(longitude)
        self.date            = date
        self.time            = time
        self.timezone        = timezone
        self.min_altitude    = float(min_altitude)
        self.catalog_filters = list(catalog_filters or [])
        self.object_limit    = int(object_limit)
        self.horizon_points  = list(horizon_points or [])
        self.catalog_file    = self.get_catalog_file_path()
        self.type_filters    = list(type_filters) if type_filters else None
        self.sort_by_score = bool(sort_by_score)

    def get_catalog_file_path(self) -> str:
        app_root = _app_root()
        candidates = [
            os.path.join(app_root, "data", "catalogs", "celestial_catalog.csv"),
            os.path.join(app_root, "..", "data", "catalogs", "celestial_catalog.csv"),
            os.path.join(app_root, "..", "..", "data", "catalogs", "celestial_catalog.csv"),
            os.path.join(app_root, "celestial_catalog.csv"),
            os.path.join(app_root, "..", "..", "..", "data", "catalogs", "celestial_catalog.csv"),
        ]
        seen = set()
        unique_candidates = []
        for c in candidates:
            n = os.path.normpath(c)
            if n not in seen:
                seen.add(n)
                unique_candidates.append(n)

        for bundled in unique_candidates:
            if os.path.exists(bundled):
                return bundled

        self._catalog_search_paths = unique_candidates
        return ""   # caller detects empty string as not found


    def run(self):
        try:
            from astropy.utils import iers
            iers.conf.auto_download = False
            iers.conf.auto_max_age = None

            local_tz = pytz.timezone(self.timezone)
            naive    = datetime.strptime(f"{self.date} {self.time}", "%Y-%m-%d %H:%M")
            local_dt = local_tz.localize(naive)
            t        = Time(local_dt)

            loc = EarthLocation(lat=self.latitude * u.deg,
                                lon=self.longitude * u.deg, height=0 * u.m)
            lst = t.sidereal_time("apparent", self.longitude * u.deg)
            self.lst_calculated.emit(
                f"Local Sidereal Time: {lst.to_string(unit=u.hour, precision=3)}")

            phase_pct, phase_icon, rts = self.calculate_lunar_phase(t, loc, self.timezone)
            self.lunar_phase_calculated.emit(phase_pct, phase_icon, rts)

            catalog_file = self.catalog_file
            if not catalog_file or not os.path.exists(catalog_file):
                searched = getattr(self, "_catalog_search_paths", [])
                lines = ["Catalog file not found.", ""]
                if searched:
                    lines.append("Searched locations:")
                    for p in searched:
                        lines.append(f"  {p}")
                lines += ["", f"app root: {_app_root()}"]
                print(f"[WIMS] {chr(10).join(lines)}")
                self.calculation_complete.emit(
                    pd.DataFrame(),
                    "Catalog file not found — check console for details.")
                return

            df = _load_full_catalog(catalog_file)

            if self.catalog_filters:
                df = df[df["Catalog"].isin(self.catalog_filters)]

            # ── Object type filter ─────────────────────────────────────────
            if self.type_filters is not None and "Type" in df.columns:
                include_blank = "(blank)" in self.type_filters
                real_types    = [t for t in self.type_filters if t != "(blank)"]

                if include_blank and real_types:
                    df = df[df["Type"].isin(real_types) | df["Type"].isna() |
                            (df["Type"].astype(str).str.strip() == "")]
                elif include_blank:
                    df = df[df["Type"].isna() |
                            (df["Type"].astype(str).str.strip() == "")]
                elif real_types:
                    df = df[df["Type"].isin(real_types)]
                else:
                    df = df.iloc[0:0]

            df.dropna(subset=["RA", "Dec"], inplace=True)
            df.reset_index(drop=True, inplace=True)

            sky         = SkyCoord(ra=df["RA"].to_numpy() * u.deg,
                                   dec=df["Dec"].to_numpy() * u.deg, frame="icrs")
            altaz_frame = AltAz(obstime=t, location=loc)
            altaz       = sky.transform_to(altaz_frame)
            df["Altitude"] = np.round(altaz.alt.deg, 1)
            df["Azimuth"]  = np.round(altaz.az.deg,  1)

            moon_altaz = get_body("moon", t, loc).transform_to(altaz_frame)
            df["Degrees from Moon"] = np.round(altaz.separation(moon_altaz).deg, 2)

            # ── Custom horizon filter ──────────────────────────────────────
            if self.horizon_points:
                horizon_mins  = _horizon_min_alts_vectorized(
                    df["Azimuth"].to_numpy(), self.horizon_points)
                effective_min = np.maximum(horizon_mins, self.min_altitude)
                df = df[df["Altitude"].to_numpy() >= effective_min]
            else:
                df = df[df["Altitude"] >= self.min_altitude]

            ra_hours = df["RA"].to_numpy() * (24.0 / 360.0)
            minutes  = ((ra_hours - lst.hour) * u.hour) % (24 * u.hour)
            mins     = minutes.to_value(u.hour) * 60.0
            df["Minutes to Transit"]   = np.round(mins, 1)
            df["Before/After Transit"] = np.where(df["Minutes to Transit"] > 720,
                                                   "After", "Before")
            df["Minutes to Transit"]   = np.where(df["Minutes to Transit"] > 720,
                                                   1440 - df["Minutes to Transit"],
                                                   df["Minutes to Transit"])

            # ── Moon position and phase (shared by both scoring paths) ─────
            moon_body  = get_body("moon", t, loc)
            sun_body   = get_sun(t)
            elong      = moon_body.separation(sun_body).deg
            phase_pct  = int(round((1 - np.cos(np.radians(elong))) / 2 * 100))
            moon_coord = SkyCoord(ra=moon_body.ra.deg * u.deg,
                                  dec=moon_body.dec.deg * u.deg)

            if self.sort_by_score:
                all_obj   = SkyCoord(ra=df["RA"].to_numpy() * u.deg,
                                     dec=df["Dec"].to_numpy() * u.deg)
                moon_seps = all_obj.separation(moon_coord).deg
                df["Score"] = _score_targets_batch(
                    df["RA"].to_numpy(), df["Dec"].to_numpy(),
                    self.latitude, self.longitude,
                    self.date, self.timezone,
                    moon_seps, phase_pct,
                    horizon_points=self.horizon_points,
                )
                df = df.nlargest(self.object_limit, "Score")
            else:
                df = df.nsmallest(self.object_limit, "Minutes to Transit")
                df = df.reset_index(drop=True)
                all_obj_trimmed   = SkyCoord(ra=df["RA"].to_numpy() * u.deg,
                                             dec=df["Dec"].to_numpy() * u.deg)
                moon_seps_trimmed = all_obj_trimmed.separation(moon_coord).deg
                df["Score"] = _score_targets_batch(
                    df["RA"].to_numpy(), df["Dec"].to_numpy(),
                    self.latitude, self.longitude,
                    self.date, self.timezone,
                    moon_seps_trimmed, phase_pct,
                    horizon_points=self.horizon_points,
                )

            self.calculation_complete.emit(df, "Calculation complete.")
        except Exception as e:
            self.calculation_complete.emit(pd.DataFrame(), f"Error: {e!s}")

    def calculate_lunar_phase(self, t, loc, tz_name):
        moon  = get_body("moon", t, loc)
        sun   = get_sun(t)
        elong = moon.separation(sun).deg
        phase_pct = int(round((1 - np.cos(np.radians(elong))) / 2 * 100))
        future    = t + (6 * u.hour)
        is_waxing = (get_body("moon", future, loc)
                     .separation(get_sun(future)).deg > elong)

        name = "new_moon.png"
        if   0   <= elong < 9:    name = "new_moon.png"
        elif 9   <= elong < 18:   name = "waxing_crescent_1.png" if is_waxing else "waning_crescent_5.png"
        elif 18  <= elong < 27:   name = "waxing_crescent_2.png" if is_waxing else "waning_crescent_4.png"
        elif 27  <= elong < 36:   name = "waxing_crescent_3.png" if is_waxing else "waning_crescent_3.png"
        elif 36  <= elong < 45:   name = "waxing_crescent_4.png" if is_waxing else "waning_crescent_2.png"
        elif 45  <= elong < 54:   name = "waxing_crescent_5.png" if is_waxing else "waning_crescent_1.png"
        elif 54  <= elong < 90:   name = "first_quarter.png"
        elif 90  <= elong < 108:  name = "waxing_gibbous_1.png"  if is_waxing else "waning_gibbous_4.png"
        elif 108 <= elong < 126:  name = "waxing_gibbous_2.png"  if is_waxing else "waning_gibbous_3.png"
        elif 126 <= elong < 144:  name = "waxing_gibbous_3.png"  if is_waxing else "waning_gibbous_2.png"
        elif 144 <= elong < 162:  name = "waxing_gibbous_4.png"  if is_waxing else "waning_gibbous_1.png"
        elif 162 <= elong <= 180: name = "full_moon.png"

        if   elong < 9:    phase_emoji = "🌑"
        elif elong < 45:   phase_emoji = "🌒" if is_waxing else "🌘"
        elif elong < 90:   phase_emoji = "🌓" if is_waxing else "🌗"
        elif elong < 135:  phase_emoji = "🌔" if is_waxing else "🌖"
        elif elong <= 180: phase_emoji = "🌕"
        else:              phase_emoji = "🌕"

        rts = self._moon_rise_transit_set(t, loc, tz_name, phase_emoji)
        return phase_pct, name, rts

    def _moon_rise_transit_set(self, t, loc, tz_name, phase_emoji="🌕"):
        try:
            local_tz = pytz.timezone(tz_name)
            t_start  = t - 12 * u.hour
            times    = t_start + np.linspace(0, 24, 1440) * u.hour
            alts     = (get_body("moon", times, loc)
                        .transform_to(AltAz(obstime=times, location=loc)).alt.deg)

            def _to_local(at):
                return (at.to_datetime(timezone=pytz.utc)
                        .astimezone(local_tz).strftime("%H:%M"))

            transit_str = _to_local(times[int(np.argmax(alts))])
            crossings   = np.where(np.diff(np.sign(alts)))[0]
            t_jd        = t.jd
            times_jd    = np.array([tt.jd for tt in times])
            rise_cands, set_cands = [], []

            for ci in crossings:
                rising   = alts[ci + 1] > alts[ci]
                cjd      = 0.5 * (times_jd[ci] + times_jd[ci + 1])
                cands    = rise_cands if rising else set_cands
                cands.append((abs(cjd - t_jd), times[ci]))

            rise_str = _to_local(min(rise_cands)[1]) if rise_cands else "—"
            set_str  = _to_local(min(set_cands)[1])  if set_cands  else "—"
            return f"{phase_emoji} Rise: {rise_str}   Transit: {transit_str}   Set: {set_str}"
        except Exception as e:
            return f"Moon times unavailable ({e})"


# ---------------------------------------------------
#  Object detail worker (runs SIMBAD query off-thread)
# ---------------------------------------------------
class ObjectDetailThread(QThread):
    result_ready = pyqtSignal(dict)

    def __init__(self, name, ra_deg, dec_deg, alt_name: str = ""):
        super().__init__()
        self.name     = name
        self.alt_name = alt_name.strip() if alt_name else ""
        self.ra_deg   = float(ra_deg)
        self.dec_deg  = float(dec_deg)

    def run(self):
        info = {"name": self.name, "ra": self.ra_deg, "dec": self.dec_deg,
                "simbad": None, "error": None}
        try:
            from astroquery.simbad import Simbad
            from astropy.coordinates import SkyCoord
            import astropy.units as u

            s = Simbad()
            s.reset_votable_fields()
            s.add_votable_fields("otype", "flux(V)", "flux(B)", "rvz_redshift",
                                 "rvz_radvel", "sptype", "dim")

            def _variants_for(n: str) -> list:
                n = " ".join(n.split())
                variants = [n, n.replace(" ", "")]

                import re
                # Space-normalize catalog prefix
                spaced = re.sub(
                    r'^(NGC|IC|M|UGC|PGC|ACO|LBN|LDN|SH2|PNG|PN-G)\s*(\d)',
                    r'\1 \2', n, flags=re.IGNORECASE)
                if spaced not in variants:
                    variants.append(spaced)

                # ── PK ↔ PN-G cross-reference ──────────────────────────────
                # If name looks like a PN-G designation, also try PK prefix
                # e.g. "PN-G 063.1+13.9" → try "PK 063.1+13.9", "PK063.1+13.9"
                png_match = re.match(
                    r'^pn-?g\s*([\d.]+[+-][\d.]+)',
                    n.strip().lower()
                )
                if png_match:
                    coords = png_match.group(1)
                    for pk_form in (f"PK {coords}", f"PK{coords}"):
                        if pk_form not in variants:
                            variants.append(pk_form)

                # If name looks like a PK designation, also try PN-G prefix
                pk_match = re.match(r'^pk\s*([\d.]+[+-][\d.]+)', n.strip().lower())
                if pk_match:
                    coords = pk_match.group(1)
                    for png_form in (f"PN G{coords}", f"PNG {coords}",
                                     f"PN-G {coords}", f"PN-G{coords}"):
                        if png_form not in variants:
                            variants.append(png_form)

                return variants

            # Collect all names we have
            all_names = [self.name]
            if self.alt_name and self.alt_name not in ("—", "nan", "None", ""):
                all_names.append(self.alt_name)

            # Sort: NGC/IC/M names first, then everything else
            def _priority(n):
                nu = n.upper().strip()
                if nu.startswith(("NGC", "IC", "M ")):
                    return 0
                return 1

            all_names.sort(key=_priority)

            name_variants = []
            seen = set()
            for n in all_names:
                for v in _variants_for(n):
                    if v not in seen:
                        seen.add(v)
                        name_variants.append(v)

            # Keep the existing Abell expansion logic
            clean_name = " ".join(self.name.split())
            name_lower = clean_name.lower()
            if name_lower.startswith("abell"):
                num = clean_name.split(None, 1)[1].strip() if " " in clean_name else clean_name[5:].strip()
                for prefix in ("ACO", "aco", "Abell"):
                    for v in (f"{prefix} {num}", f"{prefix}{num}"):
                        if v not in seen:
                            seen.add(v)
                            name_variants.append(v)

            seen = set()
            name_variants = [v for v in name_variants if not (v in seen or seen.add(v))]

            tbl = None
            for variant in name_variants:
                try:
                    tbl = s.query_object(variant)
                    if tbl is not None and len(tbl) > 0:
                        break
                    tbl = None
                except Exception:
                    tbl = None

            # TAP ADQL fallback — handles ACO/Abell and other catalogs query_object misses
            if tbl is None or len(tbl) == 0:
                try:
                    from astroquery.utils.tap.core import TapPlus
                    tap = TapPlus(url="https://simbad.cds.unistra.fr/simbad/sim-tap")
                    for variant in name_variants:
                        adql = f"""
                            SELECT b.main_id, b.ra, b.dec, b.otype, b.rvz_radvel,
                                   b.rvz_redshift, b.sp_type,
                                   f1.flux as flux_v, f2.flux as flux_b
                            FROM basic b
                            LEFT JOIN flux f1 ON f1.oidref = b.oid AND f1.filter = 'V'
                            LEFT JOIN flux f2 ON f2.oidref = b.oid AND f2.filter = 'B'
                            JOIN ident i ON i.oidref = b.oid
                            WHERE i.id = '{variant}'
                        """
                        result = tap.launch_job(adql).get_results()
                        if result is not None and len(result) > 0:
                            tbl = result
                            break
                except Exception:
                    pass

            if tbl is not None and len(tbl) > 0:
                row = tbl[0]
                def _val(*cols):
                    for col in cols:
                        if col in tbl.colnames:
                            try:
                                v = row[col]
                                s2 = v.decode() if isinstance(v, bytes) else str(v)
                                if s2 not in ("--", "nan", "", "None", "masked"):
                                    return s2
                            except Exception:
                                pass
                    return "—"
                info["simbad"] = {
                    "main_id":  _val("main_id", "MAIN_ID"),
                    "otype":    _val("otype", "OTYPE"),
                    "vmag":     _val("flux_v", "V", "FLUX_V"),
                    "bmag":     _val("flux_b", "B", "FLUX_B"),
                    "rv":       _val("rvz_radvel", "RVZ_RADVEL"),
                    "redshift": _val("rvz_redshift", "RVZ_REDSHIFT"),
                    "sp_type":  _val("sp_type", "SP_TYPE"),
                    "maj_axis": _val("galdim_majaxis"),
                    "min_axis": _val("galdim_minaxis"),
                }
            else:
                info["simbad"] = {}
        except Exception as e:
            info["error"] = str(e)
        self.result_ready.emit(info)

# ---------------------------------------------------
#  Altitude / visibility dialog
# ---------------------------------------------------
def _compute_alt_curve(ra_deg, dec_deg, lat, lon, date_str, tz_name):
    local_tz = pytz.timezone(tz_name)
    naive    = datetime.strptime(date_str, "%Y-%m-%d")
    # Start at noon on the observing date
    t_start  = Time(local_tz.localize(
        datetime(naive.year, naive.month, naive.day, 12, 0)))
    loc      = EarthLocation(lat=lat * u.deg, lon=lon * u.deg, height=0 * u.m)

    n     = 288  # 5-minute resolution
    times = t_start + np.linspace(0, 24, n) * u.hour
    frame = AltAz(obstime=times, location=loc)

    obj_coord = SkyCoord(ra=ra_deg * u.deg, dec=dec_deg * u.deg)
    obj_alts  = obj_coord.transform_to(frame).alt.deg
    sun_alts  = get_sun(times).transform_to(frame).alt.deg
    moon_alts = get_body("moon", times, loc).transform_to(frame).alt.deg

    # Use cumulative hours from noon (12, 13, ... 24, 25 ... 36)
    # so the plot runs noon→midnight→noon without wrapping
    local_hours = 12.0 + np.linspace(0, 24, n)

    return times, local_hours, obj_alts, sun_alts, moon_alts, loc

def _score_targets_batch(ra_arr, dec_arr, lat, lon, date_str, tz_name,
                          moon_seps, phase_pct, horizon_points=None):
    """
    Score all objects using chunked ThreadPoolExecutor.
    Each thread handles a chunk of objects sequentially, reducing overhead
    and keeping threads busy long enough for real parallelism.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    N = len(ra_arr)
    scores = np.zeros(N, dtype=float)

    max_workers = max(4, min((os.cpu_count() or 8) // 2, N))
    # Chunk size: divide evenly across workers, minimum 10 per chunk
    chunk_size  = max(10, (N + max_workers - 1) // max_workers)
    chunks      = [(i, min(i + chunk_size, N)) for i in range(0, N, chunk_size)]

    def _score_chunk(start, end):
        """Score a slice of objects — builds its own astropy state, no sharing."""
        try:
            import pytz as _pytz
            from astropy import units as _u
            from astropy.coordinates import (SkyCoord as _SC, EarthLocation as _EL,
                                             AltAz as _AltAz, get_sun as _get_sun)
            from astropy.time import Time as _Time
            from datetime import datetime as _dt

            local_tz = _pytz.timezone(tz_name)
            naive    = _dt.strptime(date_str, "%Y-%m-%d")
            t_start  = _Time(local_tz.localize(
                _dt(naive.year, naive.month, naive.day, 12, 0)))
            loc      = _EL(lat=lat * _u.deg, lon=lon * _u.deg, height=0 * _u.m)

            n        = 144
            times    = t_start + np.linspace(0, 24, n) * _u.hour
            frame    = _AltAz(obstime=times, location=loc)
            sun_alts = _get_sun(times).transform_to(frame).alt.deg
            astro_night = sun_alts < -18
            total_astro = float(np.sum(astro_night))

            chunk_scores = np.zeros(end - start, dtype=float)
            for j, i in enumerate(range(start, end)):
                if total_astro == 0:
                    chunk_scores[j] = 0.0
                    continue
                obj_coord = _SC(ra=float(ra_arr[i]) * _u.deg,
                                dec=float(dec_arr[i]) * _u.deg)
                altaz    = obj_coord.transform_to(frame)
                obj_alts = altaz.alt.deg

                if horizon_points:
                    obj_az = altaz.az.deg
                    h_lim  = np.array([
                        _horizon_min_alt(float(az), horizon_points)
                        for az in obj_az], dtype=float)
                    above_quality = obj_alts >= np.maximum(h_lim, 30.0)
                    above_window  = obj_alts >= np.maximum(h_lim, 20.0)
                else:
                    above_quality = obj_alts >= 30.0
                    above_window  = obj_alts >= 20.0

                alt_score    = float(np.sum(astro_night & above_quality)) / total_astro
                window_score = float(np.sum(astro_night & above_window))  / total_astro
                sep_norm     = min(1.0, float(moon_seps[i]) / 90.0)
                phase_norm   = 1.0 - (phase_pct / 100.0)
                moon_score   = sep_norm * (0.5 + 0.5 * phase_norm)
                chunk_scores[j] = round(
                    (alt_score * 0.40 + moon_score * 0.35 + window_score * 0.25) * 100, 1)
        except Exception:
            pass
        return start, chunk_scores

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs = [ex.submit(_score_chunk, s, e) for s, e in chunks]
        for fut in as_completed(futs):
            try:
                start, chunk_scores = fut.result()
                scores[start:start + len(chunk_scores)] = chunk_scores
            except Exception:
                pass

    return scores

def _score_target(ra_deg, dec_deg, lat, lon, date_str, tz_name,
                  moon_sep_deg, phase_pct, horizon_points=None):
    """Returns a 0-100 observability score for the target on the given night."""
    try:
        local_tz = pytz.timezone(tz_name)
        naive    = datetime.strptime(date_str, "%Y-%m-%d")
        t_start  = Time(local_tz.localize(
            datetime(naive.year, naive.month, naive.day, 12, 0)))
        loc      = EarthLocation(lat=lat * u.deg, lon=lon * u.deg, height=0 * u.m)

        n     = 144  # 10-min resolution — fast enough for scoring
        times = t_start + np.linspace(0, 24, n) * u.hour
        frame = AltAz(obstime=times, location=loc)

        obj_coord = SkyCoord(ra=ra_deg * u.deg, dec=dec_deg * u.deg)
        altaz     = obj_coord.transform_to(frame)
        obj_alts  = altaz.alt.deg
        sun_alts  = get_sun(times).transform_to(frame).alt.deg

        # Build per-timestep effective minimum altitude
        # If custom horizon defined, compute azimuth at each timestep and
        # look up the horizon limit — otherwise use flat 30°/20° thresholds
        if horizon_points:
            obj_az = altaz.az.deg
            h_lim  = np.array([
                _horizon_min_alt(float(az), horizon_points)
                for az in obj_az
            ], dtype=float)
            above_quality = obj_alts >= np.maximum(h_lim, 30.0)
            above_window  = obj_alts >= np.maximum(h_lim, 20.0)
        else:
            above_quality = obj_alts >= 30.0
            above_window  = obj_alts >= 20.0

        astro_night = sun_alts < -18
        total_astro = float(np.sum(astro_night))
        if total_astro == 0:
            return 0.0

        alt_score    = float(np.sum(astro_night & above_quality)) / total_astro
        window_score = float(np.sum(astro_night & above_window))  / total_astro

        sep_norm   = min(1.0, moon_sep_deg / 90.0)
        phase_norm = 1.0 - (phase_pct / 100.0)
        moon_score = sep_norm * (0.5 + 0.5 * phase_norm)

        return round((alt_score * 0.40 + moon_score * 0.35 + window_score * 0.25) * 100, 1)
    except Exception:
        return 0.0

def _score_target_for_date(ra_deg, dec_deg, lat, lon, date_str, tz_name,
                            horizon_points=None) -> tuple[float, int]:
    """
    Compute score + lunar phase% for a specific date (self-contained — computes
    moon position internally so it can be called for arbitrary dates).
    Returns (score, phase_pct).
    """
    try:
        local_tz = pytz.timezone(tz_name)
        naive    = datetime.strptime(date_str, "%Y-%m-%d")
        t_mid    = Time(local_tz.localize(
            datetime(naive.year, naive.month, naive.day, 0, 0)))
        loc      = EarthLocation(lat=lat * u.deg, lon=lon * u.deg, height=0 * u.m)

        moon  = get_body("moon", t_mid, loc)
        sun   = get_sun(t_mid)
        elong = moon.separation(sun).deg
        phase_pct = int(round((1 - np.cos(np.radians(elong))) / 2 * 100))

        obj_coord  = SkyCoord(ra=ra_deg * u.deg, dec=dec_deg * u.deg)
        moon_coord = SkyCoord(ra=moon.ra.deg * u.deg, dec=moon.dec.deg * u.deg)
        sep        = float(obj_coord.separation(moon_coord).deg)

        score = _score_target(ra_deg, dec_deg, lat, lon, date_str, tz_name,
                              sep, phase_pct, horizon_points=horizon_points)
        return score, phase_pct
    except Exception:
        return 0.0, 0

def _score_badge(score) -> str:
    """Return an emoji badge + label for an observability score."""
    try:
        s = float(score)
    except (TypeError, ValueError):
        return ""
    if s < 35:
        return "❌ Bad"
    elif s < 55:
        return "🔴 Poor"
    elif s < 75:
        return "🟡 Marginal"
    elif s < 90:
        return "🟢 Good"
    else:
        return "⭐ Excellent"

class ObjectVisibilityDialog(QDialog):
    def __init__(self, item_data: dict, observer: dict, parent=None):
        super().__init__(parent)
        self.item_data = item_data
        self.observer  = observer
        name = item_data.get("name", "Object")
        self.setWindowTitle(f"Visibility — {name}")
        self.resize(980, 640)
        self._detail_thread = None
        self._build_ui()
        self._compute_and_plot()
        self._fetch_simbad()

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 8, 8, 8)
        outer.setSpacing(6)

        self.tabs = QTabWidget()
        outer.addWidget(self.tabs, 1)

        # ── Tab 1: Altitude / Visibility plot ─────────────────────────────
        self.plot_tab = QWidget()
        plot_lay = QVBoxLayout(self.plot_tab)
        plot_lay.setContentsMargins(4, 4, 4, 4)

        if _HAS_PG:
            self.plot_widget = pg.PlotWidget()
            self.plot_widget.setLabel("bottom", "Local Time (h)")
            self.plot_widget.setLabel("left", "Altitude (°)")
            self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
            self.plot_widget.setYRange(-10, 90)
            self.plot_widget.addLine(y=0,  pen=pg.mkPen("w", width=1, style=Qt.PenStyle.DashLine))
            self.plot_widget.addLine(y=30, pen=pg.mkPen("g", width=1, style=Qt.PenStyle.DotLine))
            plot_lay.addWidget(self.plot_widget)
        else:
            plot_lay.addWidget(QLabel("pyqtgraph not installed — plot unavailable."))

        self.summary_lbl = QLabel("")
        self.summary_lbl.setWordWrap(True)
        self.summary_lbl.setStyleSheet("font-size: 12px; padding: 4px;")
        plot_lay.addWidget(self.summary_lbl, 0)

        self.tabs.addTab(self.plot_tab, "Altitude & Visibility")

        # ── Tab 2: Rise / Transit / Set ───────────────────────────────────
        self.rts_tab = QWidget()
        rts_lay = QVBoxLayout(self.rts_tab)
        self.rts_text = QTextEdit()
        self.rts_text.setReadOnly(True)
        self.rts_text.setStyleSheet("font-size: 13px;")
        rts_lay.addWidget(self.rts_text)
        self.tabs.addTab(self.rts_tab, "Rise / Transit / Set")

        # ── Tab 3: SIMBAD Details ─────────────────────────────────────────
        self.simbad_tab = QWidget()
        simbad_lay = QVBoxLayout(self.simbad_tab)
        self.simbad_text = QTextEdit()
        self.simbad_text.setReadOnly(True)
        self.simbad_text.setStyleSheet("font-size: 13px;")
        self.simbad_text.setPlainText("Querying SIMBAD…")
        simbad_lay.addWidget(self.simbad_text)
        self.tabs.addTab(self.simbad_tab, "SIMBAD Details")

        # ── Tab 4: Planet Separations ─────────────────────────────────────
        self.planet_tab = QWidget()
        planet_lay = QVBoxLayout(self.planet_tab)
        self.planet_text = QTextEdit()
        self.planet_text.setReadOnly(True)
        self.planet_text.setStyleSheet("font-size: 13px;")
        planet_lay.addWidget(self.planet_text)
        self.tabs.addTab(self.planet_tab, "Planet Separations")

        # Bottom buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        open_finder = QPushButton("Finder Chart…")
        open_finder.clicked.connect(self._open_finder_chart)
        open_aladin = QPushButton("Open in Aladin")
        open_aladin.clicked.connect(self._open_aladin)
        open_astrobin = QPushButton("Search AstroBin")
        open_astrobin.clicked.connect(self._open_astrobin)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.close)
        for b in (open_finder, open_aladin, open_astrobin, close_btn):
            btn_row.addWidget(b)
        outer.addLayout(btn_row, 0)

    def _open_finder_chart(self):
        try:
            from setiastro.saspro.finder_chart import FinderChartFromCoordDialog
            from PyQt6.QtCore import QSettings
        except ImportError as e:
            QMessageBox.warning(self, "Finder Chart",
                f"Finder chart module not available:\n{e}")
            return

        dlg = FinderChartFromCoordDialog(
            name=self.item_data.get("name", "Object"),
            ra_deg=self.item_data.get("ra", 0.0),
            dec_deg=self.item_data.get("dec", 0.0),
            settings=QSettings(),
            parent=self,
        )
        dlg.show()

    def _compute_and_plot(self):
        ra  = self.item_data["ra"]
        dec = self.item_data["dec"]
        lat = self.observer["lat"]
        lon = self.observer["lon"]
        tz  = self.observer["tz"]
        date_str = self.observer["date"]
        name = self.item_data.get("name", "Object")

        try:
            times, hrs, obj_alts, sun_alts, moon_alts, loc = \
                _compute_alt_curve(ra, dec, lat, lon, date_str, tz)
        except Exception as e:
            self.summary_lbl.setText(f"Could not compute visibility: {e}")
            return

        # ── Plot ──────────────────────────────────────────────────────────
        if _HAS_PG:
            pw = self.plot_widget
            pw.setXRange(12, 36, padding=0)

            # Custom tick labels: 12→23 then 0→12
            ticks = [(h, str(h if h <= 23 else h - 24))
                     for h in range(12, 37, 2)]
            pw.getAxis("bottom").setTicks([ticks])

            pw.setBackground(pg.mkColor(40, 55, 120, 255))

            # Find sun altitude crossing points and draw clean bands
            def _sun_x_at_threshold(threshold):
                """Find all x values where sun_alts crosses threshold."""
                crossings = []
                for i in range(len(sun_alts) - 1):
                    if (sun_alts[i] - threshold) * (sun_alts[i+1] - threshold) < 0:
                        # Linear interpolation
                        t = (threshold - sun_alts[i]) / (sun_alts[i+1] - sun_alts[i])
                        crossings.append(hrs[i] + t * (hrs[i+1] - hrs[i]))
                return crossings

            def _fill_region(x0, x1, color, alpha):
                region = pg.LinearRegionItem(
                    values=(x0, x1),
                    orientation='vertical',
                    brush=pg.mkBrush(*color, alpha),
                    pen=pg.mkPen(None),
                    movable=False,
                )
                pw.addItem(region)

            # Get crossing x positions for each twilight boundary
            civil_x      = _sun_x_at_threshold(-6)
            nautical_x   = _sun_x_at_threshold(-12)
            astro_x      = _sun_x_at_threshold(-18)

            x_min, x_max = float(hrs[0]), float(hrs[-1])

            # Night zone: between astro crossings (middle of plot)
            if len(astro_x) >= 2:
                _fill_region(astro_x[0],    astro_x[1],    (0,   0,  15), 200)
            elif len(astro_x) == 1:
                _fill_region(astro_x[0],    x_max,         (0,   0,  15), 200)

            # Nautical twilight bands
            if len(nautical_x) >= 2 and len(astro_x) >= 2:
                _fill_region(nautical_x[0], astro_x[0],    (10, 20,  60), 160)
                _fill_region(astro_x[1],    nautical_x[1], (10, 20,  60), 160)

            # Civil twilight bands
            if len(civil_x) >= 2 and len(nautical_x) >= 2:
                _fill_region(civil_x[0],    nautical_x[0], (20, 35,  90), 120)
                _fill_region(nautical_x[1], civil_x[1],    (20, 35,  90), 120)
            # Object altitude
            pw.plot(hrs, obj_alts,
                    pen=pg.mkPen("y", width=2.5),
                    name=name)

            # Moon altitude (dashed grey)
            pw.plot(hrs, moon_alts,
                    pen=pg.mkPen((180, 180, 180), width=1.2,
                                 style=Qt.PenStyle.DashLine),
                    name="Moon")

            # Horizon and 30° guide lines already added in _build_ui

            # Mark current observing time
            local_tz  = pytz.timezone(tz)
            naive     = datetime.strptime(
                f"{date_str} {self.observer.get('time','12:00')}",
                "%Y-%m-%d %H:%M")
            obs_local = local_tz.localize(naive)
            obs_hr = obs_local.hour + obs_local.minute / 60.0
            # Shift into noon-to-noon space
            if obs_hr < 12:
                obs_hr += 24
            pw.addLine(x=obs_hr, pen=pg.mkPen("r", width=1.5,
                                               style=Qt.PenStyle.DashLine))


            # ── Custom horizon overlay on altitude plot ────────────────────
            horizon_pts = self.item_data.get("horizon_points", [])
            if horizon_pts and _HAS_PG:
                # Build horizon altitude curve over the same hrs axis
                # hrs = noon-to-noon cumulative hours, times = matching astropy Time array
                # We need azimuth at each time step to look up horizon limit
                try:
                    obj_coord_h = SkyCoord(ra=ra * u.deg, dec=dec * u.deg)
                    frame_h     = AltAz(obstime=times, location=loc)
                    altaz_h     = obj_coord_h.transform_to(frame_h)
                    obj_az      = altaz_h.az.deg

                    # Horizon limit at each time step
                    h_lim = np.array([
                        _horizon_min_alt(float(az), horizon_pts)
                        for az in obj_az
                    ], dtype=float)

                    # Draw as a filled region from 0 up to the horizon limit
                    # Use a FillBetweenItem for the blocked zone
                    h_top  = pg.PlotDataItem(hrs, h_lim)
                    h_bot  = pg.PlotDataItem(hrs, np.zeros_like(h_lim))
                    h_fill = pg.FillBetweenItem(
                        h_bot, h_top,
                        brush=pg.mkBrush(220, 60, 60, 70),
                    )
                    pw.addItem(h_fill)

                    # Draw the horizon limit line itself
                    pw.plot(hrs, h_lim,
                            pen=pg.mkPen((220, 80, 80), width=1.5,
                                         style=Qt.PenStyle.DashLine),
                            name="Horizon limit")
                except Exception:
                    pass   # horizon overlay is best-effort

            # ── Azimuth compass labels along the object track ────────────────────
            try:
                if 'obj_az' not in dir():
                    # compute azimuth if horizon overlay didn't already
                    obj_coord_az = SkyCoord(ra=ra * u.deg, dec=dec * u.deg)
                    frame_az     = AltAz(obstime=times, location=loc)
                    altaz_az     = obj_coord_az.transform_to(frame_az)
                    obj_az       = altaz_az.az.deg

                def _az_to_compass(az: float) -> str:
                    dirs = ["N","NNE","NE","ENE","E","ESE","SE","SSE",
                            "S","SSW","SW","WSW","W","WNW","NW","NNW"]
                    idx = int((az + 11.25) / 22.5) % 16
                    return dirs[idx]

                # Sample every ~2 hours along the track, only where object is above -5°
                step = max(1, len(hrs) // 12)
                labeled_xs = set()
                for i in range(0, len(hrs), step):
                    alt_val = float(obj_alts[i])
                    if alt_val < -5:
                        continue
                    x = float(hrs[i])
                    y = float(alt_val)
                    # Avoid label crowding — skip if another label is within 1.5h
                    too_close = any(abs(x - lx) < 1.5 for lx in labeled_xs)
                    if too_close:
                        continue
                    labeled_xs.add(x)
                    compass = _az_to_compass(float(obj_az[i]))
                    lbl = pg.TextItem(
                        compass,
                        anchor=(0.5, 1.2),
                        color=(220, 180, 80),   # warm gold, distinct from the yellow track
                    )
                    lbl.setFont(__import__('PyQt6.QtGui', fromlist=['QFont']).QFont("", 7))
                    lbl.setPos(x, y)
                    pw.addItem(lbl)
            except Exception:
                pass  # compass labels are best-effort

            pw.addLegend()

        # ── Rise / Transit / Set tab ──────────────────────────────────────
        local_tz = pytz.timezone(tz)

        def _to_local(t):
            return (t.to_datetime(timezone=pytz.utc)
                    .astimezone(local_tz).strftime("%H:%M"))

        # Object crossings
        obj_cross = np.where(np.diff(np.sign(obj_alts)))[0]
        obj_rise = obj_set = "—"
        for ci in obj_cross:
            rising = obj_alts[ci + 1] > obj_alts[ci]
            ts = _to_local(times[ci])
            if rising and obj_rise == "—":
                obj_rise = ts
            elif not rising and obj_set == "—":
                obj_set = ts

        # Handle circumpolar / never-rises cases
        if obj_rise == "—" and obj_set == "—":
            if obj_alts.min() > 0:
                obj_rise = obj_set = "Circumpolar"
            else:
                obj_rise = obj_set = "Below horizon"
        peak_idx    = int(np.argmax(obj_alts))
        obj_transit = _to_local(times[peak_idx])
        peak_alt    = float(obj_alts[peak_idx])

        # Imaging window: above 20° during astronomical night
        imaging_mask = (obj_alts >= 20) & (sun_alts < -18)
        imaging_hrs  = float(np.sum(imaging_mask)) * (24.0 / len(times))

        # Moon interference: moon above horizon during imaging window
        moon_up_during_imaging = (imaging_mask & (moon_alts > 0))
        moon_interference_hrs  = float(np.sum(moon_up_during_imaging)) * (24.0 / len(times))

        rts_lines = [
            f"Object:  {name}",
            f"Date:    {date_str}",
            f"",
            f"Rise:          {obj_rise}",
            f"Transit:       {obj_transit}  (peak alt {peak_alt:.1f}°)",
            f"Set:           {obj_set}",
            f"",
            f"Imaging window (>20°, astro night):  {imaging_hrs:.1f} h",
            f"Moon above horizon during window:    {moon_interference_hrs:.1f} h",
            f"",
        ]

        # Twilight start/end
        astro_night = np.where(sun_alts < -18)[0]
        if len(astro_night):
            rts_lines.append(
                f"Astronomical night: "
                f"{_to_local(times[astro_night[0]])} → "
                f"{_to_local(times[astro_night[-1]])}")
        nautical = np.where(sun_alts < -12)[0]
        if len(nautical):
            rts_lines.append(
                f"Nautical twilight:  "
                f"{_to_local(times[nautical[0]])} → "
                f"{_to_local(times[nautical[-1]])}")

        self.rts_text.setPlainText("\n".join(rts_lines))

        # ── Summary label under plot ──────────────────────────────────────
        self.summary_lbl.setText(
            f"Rise {obj_rise}  •  Transit {obj_transit} ({peak_alt:.0f}°)  •  "
            f"Set {obj_set}  •  Imaging window: {imaging_hrs:.1f} h  •  "
            f"Moon interference: {moon_interference_hrs:.1f} h"
        )

        # ── Planet separations ────────────────────────────────────────────
        self._compute_planet_separations(loc, times, ra, dec)

    def _compute_planet_separations(self, loc, times, ra_deg, dec_deg):
        planets = ["mars", "jupiter", "saturn", "venus", "mercury", "uranus", "neptune"]
        obj_coord = SkyCoord(ra=ra_deg * u.deg, dec=dec_deg * u.deg)
        t_mid = times[len(times) // 2]
        lines = [f"Separations at midnight ({t_mid.iso[:10]}):\n"]
        for planet in planets:
            try:
                pb = get_body(planet, t_mid, loc)
                sep = float(obj_coord.separation(
                    SkyCoord(ra=pb.ra.deg * u.deg, dec=pb.dec.deg * u.deg)).deg)
                warn = "  ⚠ close!" if sep < 5 else ""
                lines.append(f"  {planet.capitalize():10s}  {sep:6.2f}°{warn}")
            except Exception:
                pass
        self.planet_text.setPlainText("\n".join(lines))

    def _fetch_simbad(self):
        ra  = self.item_data["ra"]
        dec = self.item_data["dec"]
        name = self.item_data.get("name", "")
        self._detail_thread = ObjectDetailThread(name, ra, dec)
        self._detail_thread.result_ready.connect(self._on_simbad_ready)
        self._detail_thread.start()

    def _on_simbad_ready(self, info: dict):
        if info.get("error"):
            self.simbad_text.setPlainText(f"SIMBAD error: {info['error']}")
            return
        s = info.get("simbad", {})
        tried = info.get("_debug_tried", [])
        clean = info.get("_debug_clean", "")
        if not s:
            orig = info.get('name', '')
            tried_str = "\n".join(f"  - '{v}'" for v in tried)
            self.simbad_text.setPlainText(
                f"No SIMBAD match found.\n\n"
                f"Original name: '{orig}'\n"
                f"Cleaned name:  '{clean}'\n"
                f"Variants tried:\n{tried_str}"
            )
            return

        # Build angular size string if available
        maj = s.get("maj_axis", "—")
        mn  = s.get("min_axis", "—")
        size_str = f"{maj}′ × {mn}′" if maj != "—" else "—"

        lines = [
            f"Main ID:       {s.get('main_id','—')}",
            f"Object type:   {s.get('otype','—')}",
            f"",
            f"V magnitude:   {s.get('vmag','—')}",
            f"B magnitude:   {s.get('bmag','—')}",
            f"Spectral type: {s.get('sp_type','—')}",
            f"Angular size:  {size_str}",
            f"",
            f"Radial vel.:   {s.get('rv','—')}  km/s",
            f"Redshift z:    {s.get('redshift','—')}",
            f"",
            f"RA:            {info.get('ra', 0):.5f}°",
            f"Dec:           {info.get('dec', 0):.5f}°",
        ]
        self.simbad_text.setPlainText("\n".join(lines))
        self.tabs.setTabText(2, f"SIMBAD — {s.get('main_id','')}")

    def _open_aladin(self):
        ra  = self.item_data["ra"]
        dec = self.item_data["dec"]
        webbrowser.open(
            f"https://aladin.cds.unistra.fr/AladinLite/"
            f"?target={ra:.5f}+{dec:+.5f}&fov=0.5&survey=P/DSS2/color")

    def _open_astrobin(self):
        name = self.item_data.get("name", "").replace(" ", "")
        webbrowser.open(f"https://www.astrobin.com/search/?q={name}")


# ---------------------------------------------------
#  Sortable tree item
# ---------------------------------------------------
class SortableTreeWidgetItem(QTreeWidgetItem):
    def __lt__(self, other):
        col = self.treeWidget().sortColumn()
        if col in [3, 4, 5, 7, 10, 12]:
            def _to_float(txt):
                try:
                    return (0, float(txt))
                except (ValueError, TypeError):
                    return (1, 0.0)

            a = _to_float(self.text(col))
            b = _to_float(other.text(col))
            return a < b

        if col == 11:   # Size column
            def _size_key(txt):
                import re
                txt = txt.strip()
                if not txt:
                    return (1, 0.0)
                # Abell clusters: "Num Galaxies: 51" → sort by galaxy count
                m = re.search(r'Num\s+Galaxies:\s*(\d+)', txt, re.IGNORECASE)
                if m:
                    return (0, float(m.group(1)))
                # Strip any trailing unit text (arc min, arcmin, arc sec, etc.)
                txt = re.sub(r'\s*(arc\s*min|arc\s*sec|arcmin|arcsec|"|\').*$',
                             '', txt, flags=re.IGNORECASE).strip()
                if not txt:
                    return (1, 0.0)
                # Match "N x M" or "NxM" with optional spaces and decimals
                m = re.match(r'([\d.]+)\s*x\s*([\d.]+)', txt, re.IGNORECASE)
                if m:
                    return (0, max(float(m.group(1)), float(m.group(2))))
                # Plain number
                try:
                    return (0, float(txt))
                except ValueError:
                    return (1, 0.0)
            return _size_key(self.text(col)) < _size_key(other.text(col))

        return self.text(col) < other.text(col)


# ---------------------------------------------------
#  Coordinate helpers
# ---------------------------------------------------
def _parse_deg_with_suffix(txt: str, kind: str) -> float:
    if txt is None:
        raise ValueError("empty")
    t = str(txt).strip().replace("°", "")
    if not t:
        raise ValueError("empty")
    suffix = ""
    if t[-1].upper() in ("N", "S", "E", "W"):
        suffix = t[-1].upper()
        t = t[:-1].strip()
    val = float(t)
    if suffix:
        if kind == "lat":
            val = abs(val) if suffix == "N" else -abs(val)
        elif kind == "lon":
            val = abs(val) if suffix == "E" else -abs(val)
    if kind == "lat" and not (-90 <= val <= 90):
        raise ValueError("Latitude must be in [-90, 90]")
    if kind == "lon" and not (-180 <= val <= 180):
        raise ValueError("Longitude must be in [-180, 180]")
    return val


def _format_with_suffix(val: float, kind: str) -> str:
    v = float(val)
    hemi = ("N" if v >= 0 else "S") if kind == "lat" else ("E" if v >= 0 else "W")
    return f"{abs(v):g}{hemi}"


def _tz_vs_longitude_hint(tz_name, date_str, time_str, lon_deg):
    try:
        local_tz = pytz.timezone(tz_name)
        naive    = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
        local_dt = local_tz.localize(naive)
        off_hours = (local_dt.utcoffset() or pd.Timedelta(0)).total_seconds() / 3600.0
    except Exception:
        return (False, "", "", 0.0)
    hours = int(off_hours)
    mins  = int(round(abs(off_hours - hours) * 60))
    sign  = "−" if off_hours < 0 else "+"
    utc_str = f"UTC{sign}{abs(hours)}:{mins:02d}" if mins else f"UTC{sign}{abs(hours)}"
    central = off_hours * 15.0
    sign_ok = (abs(off_hours) < 1e-9) or (lon_deg == 0) or ((lon_deg > 0) == (off_hours > 0))
    far     = abs(abs(lon_deg) - abs(central)) > 45.0
    if (not sign_ok) or far:
        msg = (f"Timezone {tz_name} ({utc_str}) looks inconsistent with longitude "
               f"{abs(lon_deg):g}{'E' if lon_deg>0 else 'W'} "
               f"(central meridian ≈ {abs(central):.0f}°{'E' if central>0 else 'W'}).")
        return (True, msg, utc_str, central)
    return (False, "", utc_str, central)

def _horizon_min_alt(az_deg: float, horizon_points: list) -> float:
    """
    Linear interpolation of custom horizon altitude at a given azimuth.
    horizon_points: list of (az, alt) tuples, az in [0, 360].
    Returns 0.0 if no points defined.
    """
    if not horizon_points:
        return 0.0
    pts = sorted(horizon_points, key=lambda p: p[0])
    azs  = np.array([p[0] for p in pts], dtype=float)
    alts = np.array([p[1] for p in pts], dtype=float)

    # Ensure wrap-around coverage from 0 to 360
    if azs[0] > 0:
        azs  = np.r_[0.0, azs]
        alts = np.r_[alts[0], alts]
    if azs[-1] < 360:
        azs  = np.r_[azs,  360.0]
        alts = np.r_[alts, alts[0]]   # snap north=0 to north=360

    return float(np.clip(np.interp(az_deg % 360, azs, alts), 0.0, 90.0))


def _horizon_min_alts_vectorized(az_array: np.ndarray, horizon_points: list) -> np.ndarray:
    """Vectorized version for filtering a whole DataFrame column."""
    if not horizon_points:
        return np.zeros(len(az_array), dtype=float)
    return np.array([_horizon_min_alt(float(az), horizon_points) for az in az_array])

class HorizonEditorDialog(QDialog):
    """
    Interactive custom horizon editor.
    - Click on empty space to add a point
    - Drag existing points to move them
    - Right-click a point to delete it
    - The 0° and 360° (north) endpoints are always kept in sync
    """
    horizon_changed = pyqtSignal(list)   # emits sorted [(az, alt), ...]

    _POINT_RADIUS = 8      # px, hit-test radius
    _SNAP_AZ_TOL  = 5.0    # degrees: snap to north if within this

    def __init__(self, horizon_points: list, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Custom Horizon Editor")
        self.resize(900, 500)

        # Work on a copy; each point is [az, alt] (mutable)
        self._pts = [[float(az), float(alt)] for az, alt in horizon_points]
        self._drag_idx   = None   # index of point being dragged
        self._hover_idx  = None

        self._build_ui()
        self._refresh()

    # ── UI ────────────────────────────────────────────────────────────────
    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 8, 8, 8)
        outer.setSpacing(6)

        info = QLabel(
            "Left-click empty area to add a point  •  "
            "Drag a point to move it  •  "
            "Right-click a point to delete it  •  "
            "North (0° / 360°) endpoints stay in sync"
        )
        info.setStyleSheet("font-size: 10px; color: palette(window-text);")
        info.setWordWrap(True)
        outer.addWidget(info)

        if not _HAS_PG:
            outer.addWidget(QLabel("pyqtgraph not installed — horizon editor unavailable."))
            self._plot = None
        else:
            self._plot = pg.PlotWidget()
            self._plot.setLabel("bottom", "Azimuth (°)  [0=N  90=E  180=S  270=W]")
            self._plot.setLabel("left",   "Altitude (°)")
            self._plot.setXRange(0, 360, padding=0.01)
            self._plot.setYRange(0, 90,  padding=0.02)
            self._plot.showGrid(x=True, y=True, alpha=0.3)

            # Disable default mouse drag (panning) on the ViewBox —
            # we handle all mouse interaction ourselves
            self._plot.getViewBox().setMouseEnabled(x=False, y=False)
            self._plot.getViewBox().setMouseMode(pg.ViewBox.RectMode)

            # Compass tick labels
            az_ticks = [(0,"N"),(45,"NE"),(90,"E"),(135,"SE"),
                        (180,"S"),(225,"SW"),(270,"W"),(315,"NW"),(360,"N")]
            self._plot.getAxis("bottom").setTicks([az_ticks])

            # Horizon fill
            self._fill_curve_top = pg.PlotDataItem([0, 360], [0, 0])
            self._fill_curve_bot = pg.PlotDataItem([0, 360], [0, 0])
            self._fill_item = pg.FillBetweenItem(
                self._fill_curve_bot,
                self._fill_curve_top,
                brush=pg.mkBrush(255, 80, 80, 60),
            )
            self._plot.addItem(self._fill_item)

            # Polyline
            self._line_item = self._plot.plot([], [], pen=pg.mkPen("r", width=2))

            # Scatter for control points
            self._scatter = pg.ScatterPlotItem(
                size=14, pen=pg.mkPen("w", width=1.5),
                brush=pg.mkBrush(255, 100, 100, 220),
            )
            self._plot.addItem(self._scatter)

            # Install event filter on the viewport for raw mouse events
            self._plot.viewport().installEventFilter(self)

            outer.addWidget(self._plot, 1)

        # Buttons row
        btn_row = QHBoxLayout()

        flat_btn = QPushButton("Reset to Flat")
        flat_btn.clicked.connect(self._reset_flat)
        btn_row.addWidget(flat_btn)

        load_btn = QPushButton("Load from File…")
        load_btn.clicked.connect(self._load_file)
        btn_row.addWidget(load_btn)

        save_btn = QPushButton("Save to File…")
        save_btn.clicked.connect(self._save_file)
        btn_row.addWidget(save_btn)

        btn_row.addStretch()

        clear_btn = QPushButton("Clear All")
        clear_btn.clicked.connect(self._clear_all)
        btn_row.addWidget(clear_btn)

        ok_btn = QPushButton("Apply && Close")
        ok_btn.setDefault(True)
        ok_btn.clicked.connect(self._apply)
        btn_row.addWidget(ok_btn)

        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(cancel_btn)

        outer.addLayout(btn_row)

    # ── Internal helpers ──────────────────────────────────────────────────
    def _sorted_pts(self):
        return sorted(self._pts, key=lambda p: p[0])

    def _plot_xy(self):
        """Build the closed polyline for display (wraps N→N)."""
        pts = self._sorted_pts()
        if not pts:
            return np.array([0, 360], float), np.array([0, 0], float)

        azs  = np.array([p[0] for p in pts], dtype=float)
        alts = np.array([p[1] for p in pts], dtype=float)

        # Prepend az=0 and append az=360, synced to north altitude
        north_alt = alts[0] if azs[0] <= 1e-3 else float(np.interp(0, azs, alts))
        if azs[0] > 1e-3:
            azs  = np.r_[0.0, azs]
            alts = np.r_[north_alt, alts]
        if azs[-1] < 359.999:
            azs  = np.r_[azs,  360.0]
            alts = np.r_[alts, north_alt]

        return azs, alts

    def _refresh(self):
        if self._plot is None:
            return

        xs, ys = self._plot_xy()
        self._line_item.setData(xs, ys)

        # Rebuild fill curves in place
        self._fill_curve_top.setData(xs, ys)
        self._fill_curve_bot.setData(xs, np.zeros_like(ys))

        # Scatter control points
        pts = self._sorted_pts()
        if pts:
            self._scatter.setData(
                x=[p[0] for p in pts],
                y=[p[1] for p in pts],
            )
        else:
            self._scatter.setData(x=[], y=[])

    def _view_to_data(self, scene_pos):
        """Convert a scene QPointF to (az, alt) data coordinates."""
        vb = self._plot.getViewBox()
        dp = vb.mapSceneToView(scene_pos)
        return float(dp.x()), float(dp.y())

    def _nearest_point_idx(self, az, alt):
        """
        Return index of the nearest control point in screen-space,
        or None if none is within _POINT_RADIUS pixels.
        """
        if not self._pts:
            return None
        vb   = self._plot.getViewBox()
        rect = vb.viewRect()
        w    = self._plot.width()
        h    = self._plot.height()
        if rect.width() == 0 or rect.height() == 0:
            return None

        px_per_az  = w / rect.width()
        px_per_alt = h / rect.height()
        daz  = (az  - rect.x()) * px_per_az
        dalt = (alt - rect.y()) * px_per_alt

        best_d, best_i = self._POINT_RADIUS + 1, None
        for i, (paz, palt) in enumerate(self._pts):
            dx = (paz  - rect.x()) * px_per_az  - daz
            dy = (palt - rect.y()) * px_per_alt - dalt
            d  = (dx*dx + dy*dy) ** 0.5
            if d < best_d:
                best_d, best_i = d, i
        return best_i if best_d <= self._POINT_RADIUS else None

    def _snap_north(self, az):
        """If az is within tolerance of 0 or 360, snap to 0."""
        if az < self._SNAP_AZ_TOL or az > 360 - self._SNAP_AZ_TOL:
            return 0.0
        return az

    def _sync_north(self):
        """
        Ensure the 0° and 360° points have the same altitude.
        We keep only the az=0 point internally; az=360 is added
        dynamically in _plot_xy for display only.
        """
        # Remove any stray az=360 entries (we add them in _plot_xy only)
        self._pts = [p for p in self._pts if p[0] < 359.999]

    # ── Mouse events ──────────────────────────────────────────────────────
    def eventFilter(self, source, event):
        """
        Intercept raw mouse events on the plot viewport so we get
        accurate positions without pyqtgraph's pan/zoom consuming them.
        """
        if self._plot is None:
            return super().eventFilter(source, event)

        if source is not self._plot.viewport():
            return super().eventFilter(source, event)

        from PyQt6.QtCore import QEvent
        from PyQt6.QtGui import QMouseEvent

        if event.type() == QEvent.Type.MouseButtonPress:
            az, alt = self._viewport_to_data(event.pos())
            if az is None:
                return False

            az  = float(np.clip(az,  0, 360))
            alt = float(np.clip(alt, 0, 90))
            az  = self._snap_north(az)

            idx = self._nearest_point_idx(az, alt)

            if event.button() == Qt.MouseButton.RightButton:
                if idx is not None:
                    del self._pts[idx]
                    self._sync_north()
                    self._refresh()
                    self.horizon_changed.emit(self.get_points())
                return True  # consume event

            if event.button() == Qt.MouseButton.LeftButton:
                if idx is not None:
                    self._drag_idx = idx   # start drag
                else:
                    self._pts.append([az, alt])
                    self._sync_north()
                    self._refresh()
                    self.horizon_changed.emit(self.get_points())
                return True  # consume event

        elif event.type() == QEvent.Type.MouseMove:
            if self._drag_idx is not None:
                az, alt = self._viewport_to_data(event.pos())
                if az is not None:
                    az  = float(np.clip(az,  0, 360))
                    alt = float(np.clip(alt, 0, 90))
                    az  = self._snap_north(az)
                    self._pts[self._drag_idx][0] = az
                    self._pts[self._drag_idx][1] = alt
                    self._sync_north()
                    self._refresh()
                return True  # consume event so plot doesn't pan

        elif event.type() == QEvent.Type.MouseButtonRelease:
            if self._drag_idx is not None:
                self._drag_idx = None
                self.horizon_changed.emit(self.get_points())
                return True

        return super().eventFilter(source, event)

    def _viewport_to_data(self, viewport_pos):
        """
        Convert a QPoint in viewport coordinates to (az, alt) data coordinates.
        Returns (None, None) if the position is outside the ViewBox.
        """
        vb = self._plot.getViewBox()

        # Map viewport pos → scene pos → view (data) pos
        scene_pos = self._plot.viewport().mapToGlobal(viewport_pos)
        scene_pos = self._plot.mapFromGlobal(scene_pos)
        scene_pos_f = self._plot.mapToScene(
            int(viewport_pos.x()), int(viewport_pos.y())
        )

        if not vb.sceneBoundingRect().contains(scene_pos_f):
            return None, None

        data_pt = vb.mapSceneToView(scene_pos_f)
        return float(data_pt.x()), float(data_pt.y())

    # ── Button handlers ───────────────────────────────────────────────────
    def _reset_flat(self):
        self._pts = []
        self._refresh()
        self.horizon_changed.emit(self.get_points())

    def _clear_all(self):
        self._pts = []
        self._refresh()
        self.horizon_changed.emit(self.get_points())

    def _load_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Load Horizon File", "",
            "CSV files (*.csv);;Text/Horizon files (*.txt *.hrz);;All Files (*)")
        if not path:
            return
        try:
            pts = self._parse_horizon_file(path)
            if not pts:
                QMessageBox.warning(self, "Load Horizon",
                                    "No valid horizon points found in file.")
                return
            self._pts = [[az, alt] for az, alt in pts]
            self._sync_north()
            self._refresh()
            self.horizon_changed.emit(self.get_points())
            self.update_status_hint(f"Loaded {len(self._pts)} points from {os.path.basename(path)}")
        except Exception as e:
            QMessageBox.warning(self, "Load Horizon", f"Could not load file:\n{e}")

    @staticmethod
    def _parse_horizon_file(path: str) -> list:
        """
        Parse horizon points from either:
          1) Stellarium format:  azimuth altitude  (space-separated, # comments)
          2) WIMS CSV format:    azimuth_deg, altitude_deg  (comma-separated)

        Handles duplicate azimuths (vertical chimney/wall edges) by keeping
        the maximum altitude at any given azimuth — we want the blocking height.

        Returns sorted list of (az, alt) tuples.
        """
        raw_pts = []
        is_csv  = path.lower().endswith(".csv")

        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                # Strip inline comments (Stellarium uses # for both full-line
                # and annotation comments like "#roof peak")
                stripped = line.split("#")[0].strip()
                if not stripped:
                    continue

                # Try comma-separated (WIMS CSV) first
                if "," in stripped:
                    parts = stripped.split(",")
                    if len(parts) >= 2:
                        try:
                            az  = float(parts[0].strip())
                            alt = float(parts[1].strip())
                            raw_pts.append((az, alt))
                        except ValueError:
                            pass
                    continue

                # Try space/tab-separated (Stellarium format)
                parts = stripped.split()
                if len(parts) >= 2:
                    try:
                        az  = float(parts[0])
                        alt = float(parts[1])
                        raw_pts.append((az, alt))
                    except ValueError:
                        pass

        if not raw_pts:
            return []

        # Resolve duplicate azimuths — keep the maximum altitude
        # (a chimney edge at az=30 with alt=30 and alt=33 → keep 33,
        #  because that's the blocking height the observer must clear)
        az_to_alt: dict[float, float] = {}
        for az, alt in raw_pts:
            az = float(az) % 360.0   # normalise any 360→0 wrap
            az_to_alt[az] = max(az_to_alt.get(az, -999.0), float(alt))

        # Sort by azimuth
        return sorted(az_to_alt.items(), key=lambda p: p[0])

    def update_status_hint(self, msg: str):
        """Update the info label if present, otherwise no-op."""
        # Find the QLabel info widget (first child label in outer layout)
        try:
            layout = self.layout()
            for i in range(layout.count()):
                w = layout.itemAt(i).widget()
                if isinstance(w, QLabel):
                    w.setText(msg)
                    return
        except Exception:
            pass

    def _save_file(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Horizon File", "",
            "CSV files (*.csv);;Stellarium horizon (*.txt);;All Files (*)")
        if not path:
            return
        try:
            pts = self._sorted_pts()
            ext = os.path.splitext(path)[1].lower()

            with open(path, "w", encoding="utf-8") as f:
                if ext in (".txt", ".hrz"):
                    # Write Stellarium-compatible format
                    f.write("# Horizon description file\n")
                    f.write("# Exported by SASpro What's In My Sky\n")
                    f.write("# Azimuth(degrees) Altitude(degrees)\n")
                    f.write("#\n")
                    for az, alt in pts:
                        f.write(f"{az:.1f} {alt:.1f}\n")
                else:
                    # Default: WIMS CSV format
                    f.write("# azimuth_deg, altitude_deg\n")
                    for az, alt in pts:
                        f.write(f"{az:.2f},{alt:.2f}\n")
        except Exception as e:
            QMessageBox.warning(self, "Save Horizon", f"Could not save file:\n{e}")

    def _apply(self):
        self.horizon_changed.emit(self.get_points())
        self.accept()

    # ── Public API ────────────────────────────────────────────────────────
    def get_points(self) -> list:
        """Return sorted list of (az, alt) tuples."""
        return [(p[0], p[1]) for p in self._sorted_pts()]

def _score_target_precomputed(ra_deg, dec_deg, sun_alts, times, loc,
                               moon_sep_deg, phase_pct, horizon_points=None):
    """
    Score a target using pre-computed sun_alts and times arrays.
    Caller computes sun_alts, times, loc once and reuses across all objects.
    """
    try:
        frame     = AltAz(obstime=times, location=loc)
        obj_coord = SkyCoord(ra=ra_deg * u.deg, dec=dec_deg * u.deg)
        altaz     = obj_coord.transform_to(frame)
        obj_alts  = altaz.alt.deg

        if horizon_points:
            obj_az = altaz.az.deg
            h_lim  = np.array([
                _horizon_min_alt(float(az), horizon_points)
                for az in obj_az
            ], dtype=float)
            above_quality = obj_alts >= np.maximum(h_lim, 30.0)
            above_window  = obj_alts >= np.maximum(h_lim, 20.0)
        else:
            above_quality = obj_alts >= 30.0
            above_window  = obj_alts >= 20.0

        astro_night  = sun_alts < -18
        total_astro  = float(np.sum(astro_night))
        if total_astro == 0:
            return 0.0

        alt_score    = float(np.sum(astro_night & above_quality)) / total_astro
        window_score = float(np.sum(astro_night & above_window))  / total_astro

        sep_norm   = min(1.0, moon_sep_deg / 90.0)
        phase_norm = 1.0 - (phase_pct / 100.0)
        moon_score = sep_norm * (0.5 + 0.5 * phase_norm)

        return round((alt_score * 0.40 + moon_score * 0.35 + window_score * 0.25) * 100, 1)
    except Exception:
        return 0.0

# ---------------------------------------------------
#  Main dialog
# ---------------------------------------------------
class WhatsInMySkyDialog(QDialog):
    def __init__(self, parent=None, wims_path=None, wrench_path=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("What's In My Sky"))
        if wims_path:
            self.setWindowIcon(QIcon(wims_path))

        # One-time migration of user objects from old home catalog copy
        _migrate_user_objects_from_home_catalog()

        self.settings     = QSettings()
        self.object_limit = int(self.settings.value("object_limit", 100, int))
        self._observer    = {}
        self._horizon_points: list = self._load_horizon_from_settings()
        self._atlas_entries: list = []
        self._atlas_thread: AtlasCatalogThread | None = None

        self._build_ui(wrench_path)
        self._load_settings_into_ui()
        self._preload_type_filters()

        self.calc_thread: Optional[CalculationThread] = None
        self.catalog_file: Optional[str] = None
        geom = self.settings.value("wims/geometry")
        if geom:
            self.restoreGeometry(geom)

    # ── UI ────────────────────────────────────────────────────────────────
    def _build_ui(self, wrench_path):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Left panel (unchanged) ────────────────────────────────────────
        left_outer = QFrame()
        left_outer.setFixedWidth(280)
        left_outer.setFrameShape(QFrame.Shape.NoFrame)
        left_vbox = QVBoxLayout(left_outer)
        left_vbox.setContentsMargins(0, 0, 0, 0)
        left_vbox.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        form_widget = QWidget()
        form = QVBoxLayout(form_widget)
        form.setContentsMargins(12, 12, 12, 12)
        form.setSpacing(0)

        def _section(title):
            lbl = QLabel(title.upper())
            lbl.setStyleSheet(
                "font-size: 10px; font-weight: 500; color: palette(window-text);"
                "letter-spacing: 0.05em; margin-top: 10px; margin-bottom: 4px;")
            return lbl

        def _field(label_text, widget):
            col = QVBoxLayout()
            col.setSpacing(2)
            col.setContentsMargins(0, 0, 0, 6)
            lbl = QLabel(label_text)
            lbl.setStyleSheet("font-size: 11px; color: palette(window-text);")
            col.addWidget(lbl)
            col.addWidget(widget)
            return col

        form.addWidget(_section("Location & Time"))
        fixed_w = 240
        self.latitude_entry     = QLineEdit(); self.latitude_entry.setFixedWidth(fixed_w)
        self.longitude_entry    = QLineEdit(); self.longitude_entry.setFixedWidth(fixed_w)
        self.date_entry         = QLineEdit(); self.date_entry.setFixedWidth(fixed_w)
        self.time_entry         = QLineEdit(); self.time_entry.setFixedWidth(fixed_w)
        self.timezone_combo     = QComboBox(); self.timezone_combo.addItems(pytz.all_timezones)
        self.timezone_combo.setFixedWidth(fixed_w)
        self.min_altitude_entry = QLineEdit(); self.min_altitude_entry.setFixedWidth(fixed_w)

        for lbl, w in [("Latitude", self.latitude_entry),
                        ("Longitude (E+, W−)", self.longitude_entry),
                        ("Date (YYYY-MM-DD)", self.date_entry),
                        ("Time (HH:MM)", self.time_entry),
                        ("Time Zone", self.timezone_combo),
                        ("Min Altitude (°)", self.min_altitude_entry)]:
            form.addLayout(_field(lbl, w))

        form.addWidget(_section("Catalogs"))
        cat_grid = QWidget()
        cat_lay  = QGridLayout(cat_grid)
        cat_lay.setContentsMargins(0, 0, 0, 0)
        cat_lay.setHorizontalSpacing(4)
        cat_lay.setVerticalSpacing(2)
        self.catalog_vars: dict[str, QCheckBox] = {}
        catalogs = [
            ("Messier",       "Messier"),
            ("NGC",           "NGC"),
            ("IC",            "IC"),
            ("Caldwell",      "Caldwell"),
            ("Abell",         "Abell"),
            ("Sharpless",     "Sharpless"),
            ("LBN",           "LBN"),
            ("LDN",           "LDN"),
            ("PNG (inc. PK)", "PNG"),
            ("Arp",           "Arp"),
            ("User",          "User"),
        ]
        for i, (label, key) in enumerate(catalogs):
            cb = QCheckBox(label)
            cat_lay.addWidget(cb, i // 2, i % 2)
            self.catalog_vars[key] = cb
        form.addWidget(cat_grid)

        form.addWidget(_section("RA/Dec Format"))
        self.ra_dec_degrees = QRadioButton("Degrees")
        self.ra_dec_hms     = QRadioButton("H:M:S / D:M:S")
        self.ra_dec_degrees.setChecked(True)
        g = QButtonGroup(self)
        g.addButton(self.ra_dec_degrees); g.addButton(self.ra_dec_hms)
        ra_row = QHBoxLayout()
        ra_row.setContentsMargins(0, 2, 0, 6)
        ra_row.addWidget(self.ra_dec_degrees)
        ra_row.addWidget(self.ra_dec_hms)
        ra_row.addStretch()
        form.addLayout(ra_row)
        self.ra_dec_degrees.toggled.connect(self.update_ra_dec_format)
        self.ra_dec_hms.toggled.connect(self.update_ra_dec_format)

        form.addWidget(_section("Sidereal Time"))
        self.lst_label = QLabel("Local Sidereal Time: —")
        self.lst_label.setStyleSheet(
            "font-size: 12px; color: palette(window-text); margin-bottom: 6px;")
        self.lst_label.setWordWrap(True)
        form.addWidget(self.lst_label)
        form.addStretch(1)

        scroll.setWidget(form_widget)
        left_vbox.addWidget(scroll, 1)

        calc_btn = QPushButton("Calculate")
        calc_btn.setFixedHeight(36)
        calc_btn.clicked.connect(self.start_calculation)
        calc_btn.setStyleSheet("margin: 6px 12px;")
        left_vbox.addWidget(calc_btn)

        moon_frame = QFrame()
        moon_frame.setFrameShape(QFrame.Shape.NoFrame)
        moon_frame.setStyleSheet("border-top: 1px solid palette(shadow);")
        moon_hbox = QHBoxLayout(moon_frame)
        moon_hbox.setContentsMargins(12, 8, 12, 10)
        moon_hbox.setSpacing(10)
        self.lunar_phase_image_label = QLabel()
        self.lunar_phase_image_label.setFixedSize(100, 100)
        self.lunar_phase_image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        moon_hbox.addWidget(self.lunar_phase_image_label, 0)
        moon_text = QVBoxLayout()
        moon_text.setSpacing(2)
        self.lunar_phase_label = QLabel("Lunar Phase: N/A")
        self.lunar_phase_label.setStyleSheet("font-size: 12px; font-weight: 500;")
        self.lunar_rts_label = QLabel("")
        self.lunar_rts_label.setWordWrap(True)
        self.lunar_rts_label.setStyleSheet(
            "font-size: 11px; color: palette(window-text);")
        moon_text.addWidget(self.lunar_phase_label)
        moon_text.addWidget(self.lunar_rts_label)
        moon_hbox.addLayout(moon_text, 1)
        left_vbox.addWidget(moon_frame, 0)

        # ── Middle panel — Object Type Filter ────────────────────────────
        mid_outer = QFrame()
        mid_outer.setFixedWidth(180)
        mid_outer.setFrameShape(QFrame.Shape.NoFrame)
        mid_outer.setStyleSheet("border-right: 1px solid palette(shadow);")
        mid_vbox = QVBoxLayout(mid_outer)
        mid_vbox.setContentsMargins(6, 6, 6, 6)
        mid_vbox.setSpacing(4)

        type_hdr = QLabel("OBJECT TYPES")
        type_hdr.setStyleSheet(
            "font-size: 10px; font-weight: 500; color: palette(window-text);"
            "letter-spacing: 0.05em;")
        mid_vbox.addWidget(type_hdr)

        # Toggle buttons row
        tog_row = QHBoxLayout()
        tog_row.setSpacing(4)
        tog_all_btn = QPushButton("All")
        tog_none_btn = QPushButton("None")
        tog_all_btn.setFixedHeight(22)
        tog_none_btn.setFixedHeight(22)
        tog_all_btn.setStyleSheet("font-size: 10px;")
        tog_none_btn.setStyleSheet("font-size: 10px;")
        tog_all_btn.clicked.connect(lambda: self._set_all_type_filters(True))
        tog_none_btn.clicked.connect(lambda: self._set_all_type_filters(False))
        tog_row.addWidget(tog_all_btn)
        tog_row.addWidget(tog_none_btn)
        tog_row.addStretch()
        mid_vbox.addLayout(tog_row)

        # Scrollable checkbox list
        type_scroll = QScrollArea()
        type_scroll.setWidgetResizable(True)
        type_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        type_scroll.setFrameShape(QFrame.Shape.NoFrame)

        self._type_filter_widget = QWidget()
        self._type_filter_layout = QVBoxLayout(self._type_filter_widget)
        self._type_filter_layout.setContentsMargins(2, 2, 2, 2)
        self._type_filter_layout.setSpacing(1)
        self._type_filter_layout.addStretch(1)

        type_scroll.setWidget(self._type_filter_widget)
        mid_vbox.addWidget(type_scroll, 1)

        # dict of type_name → QCheckBox, populated lazily when catalog loads
        self._type_filter_vars: dict[str, QCheckBox] = {}

        # ── Right panel ───────────────────────────────────────────────────
        right_outer = QWidget()
        right_vbox  = QVBoxLayout(right_outer)
        right_vbox.setContentsMargins(0, 0, 0, 0)
        right_vbox.setSpacing(0)

        toolbar = QHBoxLayout()
        toolbar.setContentsMargins(10, 6, 10, 6)
        toolbar.setSpacing(8)
        self.status_label = QLabel("Status: Idle")
        self.status_label.setStyleSheet(
            "font-size: 11px; color: palette(window-text);")
        toolbar.addWidget(self.status_label, 1)
        _TOOLBAR_BTN_STYLE = """
            QPushButton {
                background-color: #2a6496;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 0 10px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #3a7ab6;
            }
            QPushButton:pressed {
                background-color: #1e4f78;
            }
        """

        _WRENCH_BTN_STYLE = """
            QPushButton {
                background-color: #e07b00;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 0 10px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #f59120;
            }
            QPushButton:pressed {
                background-color: #b56200;
            }
        """

        add_btn      = QPushButton("Add Object…"); add_btn.clicked.connect(self.add_custom_object)
        save_btn     = QPushButton("Save CSV…");   save_btn.clicked.connect(self.save_to_csv)
        settings_btn = QPushButton()
        if wrench_path and os.path.exists(wrench_path):
            settings_btn.setIcon(QIcon(wrench_path))
            settings_btn.setToolTip("Settings")
        else:
            settings_btn.setText("⚙ Settings")
        settings_btn.clicked.connect(self.open_settings)

        search_btn = QPushButton("Search Object…")
        search_btn.clicked.connect(self._open_object_search)

        horizon_btn = QPushButton("🏔 Horizon…")
        horizon_btn.clicked.connect(self.open_horizon_editor)

        fieldrot_btn = QPushButton("🔄 Alt/Az Field Rotation…")
        fieldrot_btn.clicked.connect(self._open_field_rotation)

        for b in (add_btn, save_btn, search_btn, horizon_btn, fieldrot_btn):
            b.setFixedHeight(28)
            b.setStyleSheet(_TOOLBAR_BTN_STYLE)
            toolbar.addWidget(b)

        toolbar.addWidget(make_help_button("whats_in_my_sky", self))

        settings_btn.setFixedHeight(28)
        settings_btn.setStyleSheet(_WRENCH_BTN_STYLE)
        toolbar.addWidget(settings_btn)

        toolbar_frame = QFrame()
        toolbar_frame.setFrameShape(QFrame.Shape.NoFrame)
        toolbar_frame.setStyleSheet("border-bottom: 1px solid palette(shadow);")
        toolbar_frame.setLayout(toolbar)
        right_vbox.addWidget(toolbar_frame, 0)

        sort_row = QHBoxLayout()
        sort_row.setContentsMargins(10, 2, 10, 2)
        sort_row.setSpacing(8)
        sort_lbl = QLabel("Generate List By:")
        sort_lbl.setStyleSheet("font-size: 11px;")
        self.sort_transit_rb = QRadioButton("Closest to Transit")
        self.sort_score_rb   = QRadioButton("Best Nightly Score (Tip: Filter catalogs/types recommended — can be slow)")
        self.sort_transit_rb.setChecked(True)
        self.sort_transit_rb.setStyleSheet("font-size: 11px;")
        self.sort_score_rb.setStyleSheet("font-size: 11px;")
        sort_grp = QButtonGroup(self)
        sort_grp.addButton(self.sort_transit_rb)
        sort_grp.addButton(self.sort_score_rb)
        sort_row.addWidget(sort_lbl)
        sort_row.addWidget(self.sort_transit_rb)
        sort_row.addWidget(self.sort_score_rb)
        sort_row.addStretch()
        right_vbox.addLayout(sort_row)

        hint_lbl = QLabel("Tip: right-click any object for visibility plot, SIMBAD details, planet separations and more.")
        hint_lbl.setStyleSheet("font-size: 10px; color: palette(window-text); padding: 2px 10px;")
        hint_lbl.setWordWrap(True)
        right_vbox.addWidget(hint_lbl, 0)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels([
            "Name","RA","Dec","Altitude","Azimuth",
            "Min→Transit","B/A Transit","°from Moon",
            "Alt Name","Type","Magnitude","Size (arcmin)","Score","Community"])
        self.tree.setSortingEnabled(True)
        hdr = self.tree.header()
        hdr.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        hdr.setStretchLastSection(True)
        hdr.setMinimumSectionSize(50)
        self.tree.sortByColumn(5, Qt.SortOrder.AscendingOrder)
        self.tree.setAlternatingRowColors(True)
        self.tree.setUniformRowHeights(True)
        self.tree.setFrameShape(QFrame.Shape.NoFrame)
        for col, w in enumerate([90,65,65,55,55,70,65,70,90,100,50,80,50,50]):
            self.tree.setColumnWidth(col, w)

        self.tree.itemDoubleClicked.connect(self.on_row_double_click)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._show_context_menu)

        right_vbox.addWidget(self.tree, 1)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(left_outer)
        splitter.addWidget(mid_outer)
        splitter.addWidget(right_outer)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 0)
        splitter.setStretchFactor(2, 1)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(1)
        root.addWidget(splitter)
        self.resize(1300, 620)

    def _preload_type_filters(self):
        try:
            t = CalculationThread.__new__(CalculationThread)
            catalog_path = t.get_catalog_file_path()
            if catalog_path and os.path.exists(catalog_path):
                self.catalog_file = catalog_path
                df = _load_full_catalog(catalog_path)
                self._populate_type_filters(df)
        except Exception:
            pass

    def _open_object_search(self):
        catalog = getattr(self, "catalog_file", None) or \
                os.path.join(os.path.expanduser("~"), "celestial_catalog.csv")
        if not catalog or not os.path.exists(catalog):
            t = CalculationThread.__new__(CalculationThread)
            catalog = t.get_catalog_file_path()
        if not catalog or not os.path.exists(catalog):
            QMessageBox.warning(self, "Object Search",
                "Catalog not found. Please run Calculate once first.")
            return
        # Read observer fields directly from the UI — no Calculate needed
        try:
            lat = _parse_deg_with_suffix(self.latitude_entry.text(), "lat")
            lon = _parse_deg_with_suffix(self.longitude_entry.text(), "lon")
        except ValueError as e:
            QMessageBox.warning(self, "Object Search",
                f"Invalid location — please fill in Latitude and Longitude first.\n{e}")
            return

        date_str = self.date_entry.text().strip()
        time_str = self.time_entry.text().strip()
        tz_str   = self.timezone_combo.currentText()

        if not date_str:
            date_str = datetime.now().strftime("%Y-%m-%d")
        if not time_str:
            time_str = "22:00"

        observer = {
            "lat":             lat,
            "lon":             lon,
            "date":            date_str,
            "time":            time_str,
            "tz":              tz_str,
            "horizon_points":  self._horizon_points,  # ← add this
        }

        dlg = ObjectSearchDialog(catalog, observer, parent=self)
        dlg.show()

    def _populate_type_filters(self, df: pd.DataFrame):
        if "Type" not in df.columns:
            return

        types = sorted(df["Type"].dropna().unique().tolist())
        
        # Check if there are any blank/NaN type rows and add a synthetic entry
        has_blank = df["Type"].isna().any() or (df["Type"].astype(str).str.strip() == "").any()
        if has_blank:
            types = ["(blank)"] + types

        if not types:
            return

        saved = self.settings.value("wims/type_filters", None)
        saved_set = set(saved) if isinstance(saved, list) else None

        while self._type_filter_layout.count() > 1:
            item = self._type_filter_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        self._type_filter_vars.clear()

        for typ in types:
            cb = QCheckBox(typ)
            cb.setStyleSheet("font-size: 11px;")
            checked = (saved_set is None) or (typ in saved_set)
            cb.setChecked(checked)
            cb.stateChanged.connect(self._save_type_filters)
            self._type_filter_layout.insertWidget(
                self._type_filter_layout.count() - 1, cb)
            self._type_filter_vars[typ] = cb

    def _get_selected_types(self) -> list[str] | None:
        """
        Return list of checked type strings, or None if all are checked
        (so CalculationThread can skip filtering entirely for speed).
        """
        if not self._type_filter_vars:
            return None
        checked = [t for t, cb in self._type_filter_vars.items() if cb.isChecked()]
        if len(checked) == len(self._type_filter_vars):
            return None  # all selected — no filtering needed
        return checked

    def _set_all_type_filters(self, state: bool):
        for cb in self._type_filter_vars.values():
            cb.blockSignals(True)
            cb.setChecked(state)
            cb.blockSignals(False)
        self._save_type_filters()

    def _save_type_filters(self):
        checked = [t for t, cb in self._type_filter_vars.items() if cb.isChecked()]
        self.settings.setValue("wims/type_filters", checked)

    # ─ Custom horizon handling ─────────────────────────────────────────────
    def _load_horizon_from_settings(self) -> list:
        """Load horizon points from QSettings (stored as JSON string)."""
        import json
        raw = self.settings.value("wims_horizon", "[]", str)
        try:
            pts = json.loads(raw)
            return [(float(p[0]), float(p[1])) for p in pts
                    if len(p) >= 2]
        except Exception:
            return []

    def _save_horizon_to_settings(self):
        import json
        self.settings.setValue(
            "wims_horizon",
            json.dumps([[az, alt] for az, alt in self._horizon_points])
        )

    def _on_horizon_changed(self, pts: list):
        self._horizon_points = pts
        self._save_horizon_to_settings()
        n = len(pts)
        self.update_status(
            f"Custom horizon updated ({n} point{'s' if n != 1 else ''}) — "
            f"recalculate to apply."
        )

    def open_horizon_editor(self):
        dlg = HorizonEditorDialog(self._horizon_points, parent=self)
        dlg.horizon_changed.connect(self._on_horizon_changed)
        dlg.exec()


    def _open_field_rotation(self):
        """
        Open the Alt/Az Field Rotation Calculator.
 
        If a row is selected in the results tree, pre-fills Alt, Az, RA, Dec,
        date, timezone, and target name so the night curve renders immediately.
        """
        try:
            lat = float(self.settings.value("latitude",  0.0))
            lon = float(self.settings.value("longitude", 0.0))
        except (TypeError, ValueError):
            lat, lon = 0.0, 0.0
 
        alt_prefill  = None
        az_prefill   = None
        ra_prefill   = None
        dec_prefill  = None
        name_prefill = None
 
        sel = self.tree.selectedItems()
        if sel:
            item = sel[0]
            try:
                alt_prefill = float(item.text(3))   # column 3 = Altitude
                az_prefill  = float(item.text(4))   # column 4 = Azimuth
            except (ValueError, IndexError):
                pass
            try:
                data = self._item_data(item)
                if data:
                    ra_prefill   = data["ra"]
                    dec_prefill  = data["dec"]
                    name_prefill = data.get("name", "")
            except Exception:
                pass
 
        date_str = (self._observer.get("date")
                    or self.date_entry.text().strip()
                    or None)
        tz_name  = (self._observer.get("tz")
                    or self.timezone_combo.currentText()
                    or None)
 
        from setiastro.saspro.altaz_field_rotation import AltAzFieldRotationDialog
        dlg = AltAzFieldRotationDialog(
            lat=lat,
            lon=lon,
            alt=alt_prefill,
            az=az_prefill,
            ra_deg=ra_prefill,
            dec_deg=dec_prefill,
            date_str=date_str,
            tz_name=tz_name,
            target_name=name_prefill,
            settings=self.settings,
            parent=self,
        )
        dlg.show()
 
    def _open_field_rotation_for(self, item):
        """
        Open the field rotation calculator pre-filled from a specific tree item.
        Called from the context menu.
        """
        try:
            lat = float(self.settings.value("latitude",  0.0))
            lon = float(self.settings.value("longitude", 0.0))
        except (TypeError, ValueError):
            lat, lon = 0.0, 0.0
 
        alt_prefill  = None
        az_prefill   = None
        ra_prefill   = None
        dec_prefill  = None
        name_prefill = None
 
        try:
            alt_prefill = float(item.text(3))
            az_prefill  = float(item.text(4))
        except (ValueError, IndexError):
            pass
        try:
            data = self._item_data(item)
            if data:
                ra_prefill   = data["ra"]
                dec_prefill  = data["dec"]
                name_prefill = data.get("name", "")
        except Exception:
            pass
 
        date_str = (self._observer.get("date")
                    or self.date_entry.text().strip()
                    or None)
        tz_name  = (self._observer.get("tz")
                    or self.timezone_combo.currentText()
                    or None)
 
        from setiastro.saspro.altaz_field_rotation import AltAzFieldRotationDialog
        dlg = AltAzFieldRotationDialog(
            lat=lat,
            lon=lon,
            alt=alt_prefill,
            az=az_prefill,
            ra_deg=ra_prefill,
            dec_deg=dec_prefill,
            date_str=date_str,
            tz_name=tz_name,
            target_name=name_prefill,
            settings=self.settings,
            parent=self,
        )
        dlg.show()

    # ── Context menu ──────────────────────────────────────────────────────
    def _show_context_menu(self, pos):
        item = self.tree.itemAt(pos)
        if not item:
            return

        menu = QMenu(self)

        act_visibility = QAction("📈  Altitude / Visibility Plot…", self)
        act_score      = QAction("⭐  Weekly Observability Score…", self)
        act_simbad     = QAction("🔭  SIMBAD Details…", self)
        act_planets    = QAction("🪐  Planet Separations…", self)
        act_finder     = QAction("🔍  Finder Chart…", self)
        act_aladin     = QAction("🗺   Open in Aladin…", self)
        act_astrobin   = QAction("🖼   Search AstroBin…", self)
        act_yearly     = QAction("📅  Full Year Analysis…", self)

        menu.addAction(act_visibility)
        menu.addAction(act_score)
        menu.addSeparator()
        menu.addAction(act_yearly)
        menu.addSeparator()
        menu.addAction(act_simbad)
        menu.addAction(act_planets)
        menu.addAction(act_finder)

        act_fieldrot = QAction("🔄  Field Rotation…", self)
        menu.addAction(act_fieldrot)
        act_fieldrot.triggered.connect(lambda: self._open_field_rotation_for(item))

        menu.addSeparator()
        menu.addAction(act_aladin)
        menu.addAction(act_astrobin)
        menu.addSeparator()
        act_atlas = QAction("🌌  View in Seti Astro Community Atlas…", self)
        menu.addAction(act_atlas)
        act_atlas.triggered.connect(lambda: self._open_atlas_for(item))
        act_visibility.triggered.connect(lambda: self._open_visibility_dialog(item))
        act_score.triggered.connect(lambda: self._open_score_dialog(item))
        act_simbad.triggered.connect(lambda: self._open_visibility_dialog(item, tab=2))
        act_planets.triggered.connect(lambda: self._open_visibility_dialog(item, tab=3))
        act_finder.triggered.connect(lambda: self._open_finder_chart_for(item))
        act_aladin.triggered.connect(lambda: self._open_aladin_for(item))
        act_astrobin.triggered.connect(lambda: self.on_row_double_click(item, 0))
        act_yearly.triggered.connect(lambda: self._open_yearly_analysis(item))

        menu.exec(self.tree.viewport().mapToGlobal(pos))

    def _open_atlas_for(self, item):
        import webbrowser
        data = self._item_data(item)
        if data:
            # Open atlas and let Aladin navigate to the object's coordinates
            ra  = data["ra"]
            dec = data["dec"]
            webbrowser.open(
                f"https://f005.backblazeb2.com/file/setiastro-atlas/atlas.html"
                f"?ra={ra:.5f}&dec={dec:.5f}"
            )
        else:
            import webbrowser
            webbrowser.open(
                "https://f005.backblazeb2.com/file/setiastro-atlas/atlas.html"
            )

    def _open_finder_chart_for(self, item):
            data = self._item_data(item)
            if data is None:
                QMessageBox.warning(self, "WIMS", "Could not parse RA/Dec for this object.")
                return
            try:
                from setiastro.saspro.finder_chart import FinderChartFromCoordDialog
            except ImportError as e:
                QMessageBox.warning(self, "Finder Chart",
                    f"Finder chart module not available:\n{e}")
                return
            dlg = FinderChartFromCoordDialog(
                name=data["name"],
                ra_deg=data["ra"],
                dec_deg=data["dec"],
                settings=self.settings,
                parent=self,
            )
            dlg.show()

    def _open_yearly_analysis(self, item):
        if not self._observer:
            QMessageBox.information(self, "WIMS",
                "Run Calculate first so the observer location is known.")
            return
        data = self._item_data(item)
        if data is None:
            QMessageBox.warning(self, "WIMS", "Could not parse RA/Dec for this object.")
            return

        # Reuse the same flow as ObjectSearchDialog._on_analyse
        # but launch directly without needing to search first
        from PyQt6.QtWidgets import QProgressDialog

        prog = QProgressDialog(
            f"Computing yearly visibility for {data['name']}…",
            "Cancel", 0, 100, self)
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(0)
        prog.setValue(0)
        prog.show()

        start = self._observer.get("date", datetime.now().strftime("%Y-%m-%d"))
        thread = ObjectSearchThread(
            data["ra"], data["dec"],
            self._observer["lat"], self._observer["lon"],
            self._observer["tz"],
            start,
            horizon_points=self._horizon_points,
        )
        thread.progress.connect(prog.setValue)
        thread.result_ready.connect(prog.close)
        thread.result_ready.connect(
            lambda results, d=data: self._show_yearly_results(d, results))

        # Keep reference so thread isn't garbage collected
        self._yearly_thread = thread
        prog.canceled.connect(thread.terminate)
        thread.start()

    def _show_yearly_results(self, data, results):
        dlg = ObjectSearchResultDialog(data, self._observer, results, parent=self)
        dlg.show()

    def _open_score_dialog(self, item):
        if not self._observer:
            QMessageBox.information(self, "WIMS",
                "Run Calculate first so the observer location is known.")
            return
        data = self._item_data(item)
        if data is None:
            QMessageBox.warning(self, "WIMS", "Could not parse RA/Dec for this object.")
            return
        dlg = ScoreChartDialog(data, self._observer, parent=self)
        dlg.show()

    def _item_data(self, item):
        """Extract name, ra, dec from a tree item."""
        name = item.text(0)
        try:
            ra_txt  = item.text(1)
            dec_txt = item.text(2)
            if ":" in ra_txt:
                sc = SkyCoord(ra=ra_txt, dec=dec_txt, unit=(u.hourangle, u.deg))
            else:
                sc = SkyCoord(ra=float(ra_txt) * u.deg, dec=float(dec_txt) * u.deg)
            return {"name": name, "ra": float(sc.ra.deg), "dec": float(sc.dec.deg)}
        except Exception:
            return None

    def _open_visibility_dialog(self, item, tab=0):
        if not self._observer:
            QMessageBox.information(self, "WIMS",
                "Run Calculate first so the observer location is known.")
            return
        data = self._item_data(item)
        if data is None:
            QMessageBox.warning(self, "WIMS", "Could not parse RA/Dec for this object.")
            return
        data["horizon_points"] = self._horizon_points   # ← inject
        dlg = ObjectVisibilityDialog(data, self._observer, parent=self)
        dlg.tabs.setCurrentIndex(tab)
        dlg.show()

    def _open_aladin_for(self, item):
        data = self._item_data(item)
        if data:
            webbrowser.open(
                f"https://aladin.cds.unistra.fr/AladinLite/"
                f"?target={data['ra']:.5f}+{data['dec']:+.5f}&fov=0.5&survey=P/DSS2/color")

    # ── Settings ──────────────────────────────────────────────────────────
    def _load_settings_into_ui(self):
        def cast(v, typ, default):
            try: return typ(v)
            except Exception: return default
        self.latitude_entry.setText(str(cast(self.settings.value("latitude",  0.0), float, 0.0)))
        self.longitude_entry.setText(str(cast(self.settings.value("longitude", 0.0), float, 0.0)))
        self.date_entry.setText(
            self.settings.value("date", datetime.now().strftime("%Y-%m-%d")))
        self.time_entry.setText(self.settings.value("time", "00:00"))
        self.timezone_combo.setCurrentText(self.settings.value("timezone", "UTC"))
        self.min_altitude_entry.setText(
            str(cast(self.settings.value("min_altitude", 0.0), float, 0.0)))
        self.object_limit = cast(self.settings.value("object_limit", 100), int, 100)
        if self.settings.value("wims/sort_by_score", False, type=bool):
            self.sort_score_rb.setChecked(True)

    def _save_settings(self, lat, lon, date, time, tz, min_alt):
        for k, v in [("latitude", lat), ("longitude", lon), ("date", date),
                     ("time", time), ("timezone", tz), ("min_altitude", min_alt)]:
            self.settings.setValue(k, v)

    # ── Calculation ───────────────────────────────────────────────────────
    def start_calculation(self):
        try:
            orig_lat = self.latitude_entry.text()
            orig_lon = self.longitude_entry.text()
            latitude  = _parse_deg_with_suffix(orig_lat, "lat")
            longitude = _parse_deg_with_suffix(orig_lon, "lon")
            self.latitude_entry.setText(_format_with_suffix(latitude,  "lat"))
            self.longitude_entry.setText(_format_with_suffix(longitude, "lon"))
            date_str = self.date_entry.text().strip()
            time_str = self.time_entry.text().strip()
            tz_str   = self.timezone_combo.currentText()
            min_alt  = float(self.min_altitude_entry.text())
        except ValueError as e:
            self.update_status(f"Invalid input: {e}"); return

        warn, msg, _, central = _tz_vs_longitude_hint(tz_str, date_str, time_str, longitude)
        if warn:
            bare = orig_lon.strip() and orig_lon.strip()[-1].upper() not in ("E","W")
            sign_mismatch = not ((longitude > 0) == (central > 0)
                                 or abs(central) < 1e-6 or longitude == 0)
            if bare and sign_mismatch:
                longitude = -longitude
                self.longitude_entry.setText(_format_with_suffix(longitude, "lon"))
                self.update_status(f"{msg} → Auto-corrected to {_format_with_suffix(longitude,'lon')}.")
            else:
                self.update_status(msg + " Please verify your longitude/timezone.")
        else:
            self.update_status("Inputs look consistent.")

        self.settings.setValue("wims/sort_by_score", self.sort_score_rb.isChecked())
        self._save_settings(latitude, longitude, date_str, time_str, tz_str, min_alt)

        # Store observer context for visibility dialogs
        self._observer = {
            "lat": latitude, "lon": longitude,
            "date": date_str, "time": time_str, "tz": tz_str,
            "min_alt": min_alt,
            "horizon_points": self._horizon_points, 
        }

        catalogs = [n for n, cb in self.catalog_vars.items() if cb.isChecked()]
        type_filters = self._get_selected_types()
        self.calc_thread = CalculationThread(
            latitude, longitude, date_str, time_str, tz_str,
            min_alt, catalogs, self.object_limit,
            horizon_points=self._horizon_points,
            type_filters=type_filters,
            sort_by_score=self.sort_score_rb.isChecked()) 
        self.catalog_file = self.calc_thread.catalog_file
        self.calc_thread.calculation_complete.connect(self.on_calculation_complete)
        self.calc_thread.lunar_phase_calculated.connect(self.update_lunar_phase)
        self.calc_thread.lst_calculated.connect(self.update_lst)
        self.calc_thread.status_update.connect(self.update_status)
        self.update_status("Calculating…")
        self.calc_thread.start()
        self._fetch_atlas_catalog()

    def _fetch_atlas_catalog(self):
        """Kick off a background fetch of the community atlas catalog."""
        if self._atlas_thread is not None:
            try:
                self._atlas_thread.quit()
            except Exception:
                pass
        self._atlas_thread = AtlasCatalogThread()
        self._atlas_thread.finished.connect(self._on_atlas_catalog_ready)
        self._atlas_thread.start()
 
    def _on_atlas_catalog_ready(self, entries: list):
        self._atlas_entries = entries
        # If the tree is already populated, update the Community column
        if self.tree.topLevelItemCount() > 0:
            self._update_community_column()

    def _update_community_column(self):
        """
        Walk the populated tree and tick the Community column for any object
        whose RA/Dec falls inside an atlas footprint.
        """
        if not self._atlas_entries:
            return
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            try:
                ra_txt  = item.text(1)
                dec_txt = item.text(2)
                if ":" in ra_txt:
                    from astropy.coordinates import SkyCoord
                    import astropy.units as u
                    sc = SkyCoord(ra=ra_txt, dec=dec_txt,
                                  unit=(u.hourangle, u.deg))
                    ra  = float(sc.ra.deg)
                    dec = float(sc.dec.deg)
                else:
                    ra  = float(ra_txt)
                    dec = float(dec_txt)
 
                if _ra_in_atlas(ra, dec, self._atlas_entries):
                    item.setText(13, "✓")
                    item.setForeground(13,
                        __import__("PyQt6.QtGui", fromlist=["QBrush"]).QBrush(
                            __import__("PyQt6.QtGui", fromlist=["QColor"]).QColor(
                                80, 200, 120)))
                else:
                    item.setText(13, "")
            except Exception:
                pass


    # ── Slots ─────────────────────────────────────────────────────────────
    def update_lunar_phase(self, phase_percentage, phase_image_name, rts):
        self.lunar_phase_label.setText(f"Lunar Phase: {phase_percentage}% illuminated")
        self.lunar_rts_label.setText(rts)
        pth = get_icon_path(phase_image_name)
        if os.path.exists(pth):
            pm = QPixmap(pth).scaled(100, 100,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation)
            self.lunar_phase_image_label.setPixmap(pm)
        else:
            self.lunar_phase_image_label.clear()

    def on_calculation_complete(self, df, message):
        # DEBUG — remove after confirming fix
        if not df.empty and "Alt Name" in df.columns:
            png_rows = df[df.get("Catalog", pd.Series(dtype=str)).astype(str).str.strip().str.upper() == "PNG"]
            for _, r in png_rows.head(5).iterrows():
                raw = r.get("Alt Name", "")
                print(f"[DEBUG] Name={r['Name']!r}  AltName={raw!r}  type={type(raw)}")        
        if self._type_filter_vars == {} and not df.empty:
            try:
                full_df = _load_full_catalog(self.catalog_file or "")
                self._populate_type_filters(full_df)
            except Exception:
                pass
        self.update_status(message)
        self.tree.clear()
        if df.empty:
            return
        for _, row in df.iterrows():
            ra_disp, dec_disp = row["RA"], row["Dec"]
            if self.ra_dec_hms.isChecked():
                sc = SkyCoord(ra=row["RA"] * u.deg, dec=row["Dec"] * u.deg)
                ra_disp  = sc.ra.to_string(unit=u.hour, sep=":")
                dec_disp = sc.dec.to_string(unit=u.deg, sep=":")
            size_arcmin = str(row.get("Info","")) if pd.notna(row.get("Info","")) else ""
            alt_full = str(row.get("Alt Name","")) if pd.notna(row.get("Alt Name","")) else ""
            vals = [
                str(row.get("Name","") or ""),
                str(ra_disp), str(dec_disp),
                str(row.get("Altitude","")), str(row.get("Azimuth","")),
                str(int(row.get("Minutes to Transit",0)))
                    if pd.notna(row.get("Minutes to Transit", np.nan)) else "",
                str(row.get("Before/After Transit","")),
                str(round(row.get("Degrees from Moon",0.0),2))
                    if pd.notna(row.get("Degrees from Moon", np.nan)) else "",
                alt_full,
                row.get("Type","")     if pd.notna(row.get("Type",""))     else "",
                str(row.get("Magnitude","")) if pd.notna(row.get("Magnitude","")) else "",
                size_arcmin,
                str(row.get("Score", 0.0)),
                ""  # Community column, to be filled in later
            ]
            item = SortableTreeWidgetItem(vals)
            # Full alt name on hover so nothing is ever hidden
            item.setToolTip(8, alt_full)
            self.tree.addTopLevelItem(item)
        if self._atlas_entries:
            self._update_community_column()



    def update_status(self, msg):
        self.status_label.setText(f"Status: {msg}")

    def update_lst(self, msg):
        self.lst_label.setText(msg)

    def open_settings(self):
        n, ok = QInputDialog.getInt(self, "Settings",
            "Enter number of objects to display:",
            value=self.object_limit, min=1, max=1000)
        if ok:
            self.object_limit = n
            self.settings.setValue("object_limit", n)

    def on_row_double_click(self, item, column):
        name = item.text(0).replace(" ", "")
        webbrowser.open(f"https://www.astrobin.com/search/?q={name}")

    def add_custom_object(self):
        name, ok = QInputDialog.getText(self, "Add Custom Object", "Enter object name:")
        if not ok or not name:
            return
        ra, ok = QInputDialog.getDouble(self, "Add Custom Object", "Enter RA (deg):", decimals=3)
        if not ok:
            return
        dec, ok = QInputDialog.getDouble(self, "Add Custom Object", "Enter Dec (deg):", decimals=3)
        if not ok:
            return

        entry = {
            "Name":      name,
            "RA":        ra,
            "Dec":       dec,
            "Alt Name":  "",
            "Type":      "Custom",
            "Magnitude": "",
            "Info":      "",
            "Catalog":   "User",
        }

        try:
            if os.path.exists(USER_OBJECTS_PATH):
                existing = pd.read_csv(USER_OBJECTS_PATH, encoding="utf-8",
                                       quotechar='"', quoting=0)
            else:
                existing = pd.DataFrame(columns=_USER_OBJECTS_COLS)

            updated = pd.concat([existing, pd.DataFrame([entry])], ignore_index=True)
            updated.to_csv(USER_OBJECTS_PATH, index=False, encoding="utf-8")
            self.update_status(f"Added custom object: {name}")
        except Exception as e:
            QMessageBox.warning(self, "Add Custom Object",
                                f"Could not save user object:\n{e}")

    def update_ra_dec_format(self):
        use_deg = self.ra_dec_degrees.isChecked()
        for i in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(i)
            ra_txt, dec_txt = it.text(1), it.text(2)
            try:
                if use_deg and ":" in ra_txt:
                    sc = SkyCoord(ra=ra_txt, dec=dec_txt, unit=(u.hourangle, u.deg))
                    it.setText(1, f"{sc.ra.deg:.3f}")
                    it.setText(2, f"{sc.dec.deg:.3f}")
                elif not use_deg and ":" not in ra_txt:
                    sc = SkyCoord(ra=float(ra_txt) * u.deg, dec=float(dec_txt) * u.deg)
                    it.setText(1, sc.ra.to_string(unit=u.hour, sep=":"))
                    it.setText(2, sc.dec.to_string(unit=u.deg,  sep=":"))
            except Exception:
                pass

    def save_to_csv(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save CSV File", "",
                                               "CSV files (*.csv);;All Files (*)")
        if not path: return
        cols = [self.tree.headerItem().text(i) for i in range(self.tree.columnCount())]
        rows = [[self.tree.topLevelItem(i).text(j)
                 for j in range(self.tree.columnCount())]
                for i in range(self.tree.topLevelItemCount())]
        pd.DataFrame(rows, columns=cols).to_csv(path, index=False)
        self.update_status(f"Data saved to {path}")

    def closeEvent(self, event):
        self.settings.setValue("wims/geometry", self.saveGeometry())
        super().closeEvent(event)
