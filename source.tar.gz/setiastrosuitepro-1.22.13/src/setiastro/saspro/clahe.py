#saspro/clahe.py
from __future__ import annotations
import numpy as np
import cv2

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QImage, QPixmap, QIcon
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGroupBox, QGridLayout,
    QLabel, QPushButton, QSlider, QGraphicsScene,
    QGraphicsPixmapItem, QMessageBox
)

# Import centralized widgets
from setiastro.saspro.widgets.graphics_views import ZoomableGraphicsView
from setiastro.saspro.widgets.image_utils import extract_mask_resized as _get_active_mask_resized
from setiastro.saspro.widgets.themed_buttons import themed_toolbtn
from setiastro.saspro.help_support import make_help_button

# ----------------------- Core -----------------------
def apply_clahe(image: np.ndarray, clip_limit: float = 2.0, tile_grid_size: tuple = (8, 8)) -> np.ndarray:
    # ... (unchanged)
    if image is None:
        raise ValueError("image is None")
    arr = np.asarray(image, dtype=np.float32)
    arr = np.clip(arr, 0.0, 1.0)
    was_hw1 = (arr.ndim == 3 and arr.shape[2] == 1)
    if arr.ndim == 3 and arr.shape[2] == 3:
        lab = cv2.cvtColor((arr * 255.0).astype(np.uint8), cv2.COLOR_RGB2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=float(clip_limit), tileGridSize=tuple(tile_grid_size))
        cl = clahe.apply(l)
        limg = cv2.merge((cl, a, b))
        enhanced = cv2.cvtColor(limg, cv2.COLOR_LAB2RGB).astype(np.float32) / 255.0
        return np.clip(enhanced, 0.0, 1.0)
    mono = arr.squeeze()
    clahe = cv2.createCLAHE(clipLimit=float(clip_limit), tileGridSize=tuple(tile_grid_size))
    cl = clahe.apply((mono * 255.0).astype(np.uint8)).astype(np.float32) / 255.0
    cl = np.clip(cl, 0.0, 1.0)
    if was_hw1:
        cl = cl[..., None]
    return cl

# Note: _get_active_mask_resized imported from setiastro.saspro.widgets.image_utils

def apply_clahe_to_doc(doc, preset: dict | None):
    """
    Apply CLAHE to doc.image using a preset.

    Backward compatible:
      - old presets: {"clip_limit": 2.0, "tile": 8}  # tile count across min dimension
      - new presets: {"clip_limit": 2.0, "tile_px": 128}  # tile size in pixels
      - new: {"blend": 1.0}  # 0..1
    """
    if doc is None or getattr(doc, "image", None) is None:
        raise RuntimeError("Document has no image.")

    img = np.asarray(doc.image)

    # --- preset decode (supports old + new) ---
    p = preset or {}
    clip = float(p.get("clip_limit", 2.0))

    # NEW: blend amount (0..1)
    blend = float(p.get("blend", 1.0))
    # allow percent-style presets too (e.g. 75)
    if blend > 1.0:
        blend = blend / 100.0
    blend = float(np.clip(blend, 0.0, 1.0))

    # Resolve tile_grid_size for OpenCV
    if "tile_px" in p:
        tile_px = int(p.get("tile_px", 128))
        h, w = img.shape[:2]
        s = float(min(h, w))
        tile_px = max(8, tile_px)
        n = int(round(s / float(tile_px)))
        n = max(2, min(n, 128))
        tile_grid = (n, n)
    else:
        tile = int(p.get("tile", 8))
        tile = max(2, min(tile, 128))
        tile_grid = (tile, tile)

    out = apply_clahe(img, clip_limit=clip, tile_grid_size=tile_grid)
    out = np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)

    # Normalize base into [0..1] for blending/masking
    base = np.asarray(doc.image, dtype=np.float32)
    if base.dtype.kind in "ui":
        maxv = float(np.iinfo(base.dtype).max)
        base = base / max(1.0, maxv)
    else:
        base = np.clip(base, 0.0, 1.0)

    # NEW: global blend (before mask)
    if out.ndim == 3:
        if base.ndim == 2:
            base = base[:, :, None].repeat(out.shape[2], axis=2)
        elif base.ndim == 3 and base.shape[2] == 1:
            base = base.repeat(out.shape[2], axis=2)
        out = np.clip(base * (1.0 - blend) + out * blend, 0.0, 1.0)
    else:
        if base.ndim == 3 and base.shape[2] == 1:
            base = base.squeeze(axis=2)
        out = np.clip(base * (1.0 - blend) + out * blend, 0.0, 1.0)

    # Blend with active mask if present
    H, W = out.shape[:2]
    m = _get_active_mask_resized(doc, H, W)
    if m is not None:
        if out.ndim == 3:
            M = np.repeat(m[:, :, None], out.shape[2], axis=2).astype(np.float32)
            out = np.clip(base * (1.0 - M) + out * M, 0.0, 1.0)
        else:
            out = np.clip(base * (1.0 - m) + out * m, 0.0, 1.0)

    # Commit
    out = out.astype(np.float32, copy=False)
    _meta = {
        "step_name": "CLAHE",
        "command_id": "clahe",
        "preset": {
            "clip_limit": float(clip),
            **({"tile_px": int(p.get("tile_px", 128))} if "tile_px" in p
               else {"tile": int(p.get("tile", 8))}),
            "blend": float(blend),
        },
    }
    doc.set_image(out, metadata=_meta, step_name="CLAHE")


# ----------------------- Dialog -----------------------
class CLAHEDialogPro(QDialog):
    def __init__(self, parent, doc, icon: QIcon | None = None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("CLAHE"))
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)
        if icon:
            try: self.setWindowIcon(icon)
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        except Exception:
            pass  # older PyQt6 versions
        self.doc = doc
        self.orig = np.clip(np.asarray(doc.image, dtype=np.float32), 0.0, 1.0)
        disp = self.orig
        if disp.ndim == 2: disp = disp[..., None].repeat(3, axis=2)
        elif disp.ndim == 3 and disp.shape[2] == 1: disp = disp.repeat(3, axis=2)
        self._disp_base = disp

        v = QVBoxLayout(self)

        # ---- Params (unchanged) ----
        grp = QGroupBox(self.tr("CLAHE Parameters")); grid = QGridLayout(grp)
        self.s_clip = QSlider(Qt.Orientation.Horizontal); self.s_clip.setRange(1, 40); self.s_clip.setValue(20)
        self.lbl_clip = QLabel("2.0")
        self.s_clip.valueChanged.connect(lambda val: self.lbl_clip.setText(f"{val/10.0:.1f}"))
        self.s_clip.valueChanged.connect(self._debounce_preview)

        # tile size slider (pixels) — intuitive control
        self.s_tile = QSlider(Qt.Orientation.Horizontal)
        self.s_tile.setRange(8, 512)          # 4 is pointless; you clamp to >=8 anyway
        self.s_tile.setSingleStep(8)
        self.s_tile.setPageStep(64)
        self.s_tile.setValue(128)             # nice default
        self.s_tile.setToolTip("CLAHE tile size in pixels (larger = coarser, smaller = finer).")

        self.lbl_tile = QLabel("128 px")
        self.lbl_tile.setToolTip(self.s_tile.toolTip())

        self.s_tile.valueChanged.connect(lambda v: self.lbl_tile.setText(f"{v} px"))
        self.s_tile.valueChanged.connect(self._debounce_preview)

        grid.addWidget(QLabel(self.tr("Tile Size (px):")), 1, 0)
        grid.addWidget(self.s_tile, 1, 1)
        grid.addWidget(self.lbl_tile, 1, 2)



        grid.addWidget(QLabel(self.tr("Clip Limit:")), 0, 0); grid.addWidget(self.s_clip, 0, 1); grid.addWidget(self.lbl_clip, 0, 2)

        v.addWidget(grp)
        # NEW: blend slider (0..100%)
        self.s_blend = QSlider(Qt.Orientation.Horizontal)
        self.s_blend.setRange(0, 100)
        self.s_blend.setValue(100)
        self.lbl_blend = QLabel("100%")
        self.s_blend.valueChanged.connect(lambda v: self.lbl_blend.setText(f"{v}%"))
        self.s_blend.valueChanged.connect(self._debounce_preview)

        grid.addWidget(QLabel(self.tr("Blend Amount:")), 2, 0)
        grid.addWidget(self.s_blend, 2, 1)
        grid.addWidget(self.lbl_blend, 2, 2)
        # ---- Preview with zoom/pan ----
        self.scene = QGraphicsScene(self)
        self.view  = ZoomableGraphicsView(self.scene)
        self.view.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.pix   = QGraphicsPixmapItem()
        self.scene.addItem(self.pix)
        v.addWidget(self.view, 1)

        # ---- Zoom bar ----
        # ---- Zoom bar (themed) ----
        z = QHBoxLayout()
        z.addStretch(1)

        self.btn_zoom_in  = themed_toolbtn("zoom-in", "Zoom In")
        self.btn_zoom_out = themed_toolbtn("zoom-out", "Zoom Out")
        self.btn_zoom_fit = themed_toolbtn("zoom-fit-best", "Fit to Preview")

        self.btn_zoom_in.clicked.connect(self.view.zoom_in)
        self.btn_zoom_out.clicked.connect(self.view.zoom_out)
        self.btn_zoom_fit.clicked.connect(lambda: self.view.fit_to_item(self.pix))

        z.addWidget(self.btn_zoom_in)
        z.addWidget(self.btn_zoom_out)
        z.addWidget(self.btn_zoom_fit)

        v.addLayout(z)


        # ---- Buttons (unchanged) ----
        row = QHBoxLayout()
        self.btn_apply = QPushButton(self.tr("Apply"));  self.btn_apply.clicked.connect(self._apply)
        self.btn_reset = QPushButton(self.tr("Reset"));  self.btn_reset.clicked.connect(self._reset)
        self.btn_close = QPushButton(self.tr("Cancel")); self.btn_close.clicked.connect(self.reject)
        row.addStretch(1); row.addWidget(self.btn_apply); row.addWidget(self.btn_reset); row.addWidget(self.btn_close)
        v.addLayout(row)

        # --- preset drag handle (grip), pinned lower-left ---
        try:
            from setiastro.saspro.shortcuts import PresetDragHandle
            try:
                from setiastro.saspro.resources import clahe_path
                _grip_icon = QIcon(clahe_path)
            except Exception:
                _grip_icon = QIcon()
            drag_row = QHBoxLayout()
            drag_row.setContentsMargins(0, 0, 0, 0)
            self.preset_drag_handle = PresetDragHandle(
                "clahe", self.get_preset, icon=_grip_icon,
                tooltip=self.tr(
                    "Drag to the canvas to create a CLAHE shortcut "
                    "with these exact settings.\n"
                    "Drop directly on an image to apply them headlessly."
                ),
                parent=self,
            )
            drag_row.addWidget(self.preset_drag_handle)
            drag_row.addStretch(1)
            self.btn_help = make_help_button("clahe", self)
            drag_row.addWidget(self.btn_help)

            v.addLayout(drag_row)
        except Exception:
            pass

        self._timer = QTimer(self); self._timer.setSingleShot(True); self._timer.timeout.connect(self._update_preview)

        self._set_pix(self._disp_base)
        self._update_preview()
        # initial fit
        self.view.fit_to_item(self.pix)

    def _debounce_preview(self): self._timer.start(250)

    def _set_pix(self, rgb):
        arr = (np.clip(rgb, 0, 1) * 255).astype(np.uint8)
        h, w, _ = arr.shape
        q = QImage(arr.data, w, h, 3*w, QImage.Format.Format_RGB888)
        self.pix.setPixmap(QPixmap.fromImage(q))
        self.scene.setSceneRect(self.pix.boundingRect())

    def _update_preview(self):
        clip = self.s_clip.value() / 10.0
        tile_px = int(self.s_tile.value())
        blend = self.s_blend.value() / 100.0

        try:
            tile_grid = self._tile_grid_from_px(tile_px, self._disp_base.shape[:2])

            out = apply_clahe(
                self._disp_base,
                clip_limit=float(clip),
                tile_grid_size=tile_grid
            )

            # Respect active mask (preview works on _disp_base size)
            base = self._disp_base.astype(np.float32, copy=False)
            out = np.clip(base * (1.0 - blend) + out * blend, 0.0, 1.0)

            # Respect active mask (preview works on _disp_base size)
            H, W = out.shape[:2]
            m = _get_active_mask_resized(self.doc, H, W)
            if m is not None:
                if out.ndim == 3:
                    M = np.repeat(m[:, :, None], out.shape[2], axis=2).astype(np.float32)
                else:
                    M = m.astype(np.float32)
                out = np.clip(base * (1.0 - M) + out * M, 0.0, 1.0)
            self._set_pix(out)
            self._preview = out

        except Exception as e:
            QMessageBox.warning(self, "CLAHE", f"Preview failed:\n{e}")


    def _apply(self):
        try:
            clip = float(self.s_clip.value() / 10.0)
            tile_px = int(self.s_tile.value())
            blend = float(self.s_blend.value() / 100.0)

            # --- CLAHE params ---
            tile_grid = self._tile_grid_from_px(tile_px, self.orig.shape[:2])

            # --- Run CLAHE on the original (normalized) image ---
            out = apply_clahe(
                self.orig,
                clip_limit=clip,
                tile_grid_size=tile_grid
            )
            out = np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)

            # --- Build base from CURRENT doc state (normalized to 0..1) ---
            base = np.asarray(self.doc.image, dtype=np.float32)
            if base.dtype.kind in "ui":
                maxv = float(np.iinfo(base.dtype).max)
                base = base / max(1.0, maxv)
            else:
                base = np.clip(base, 0.0, 1.0)

            # --- Align base channels to out channels ---
            if out.ndim == 3:
                if base.ndim == 2:
                    base = base[:, :, None].repeat(out.shape[2], axis=2)
                elif base.ndim == 3 and base.shape[2] == 1:
                    base = base.repeat(out.shape[2], axis=2)
            else:
                if base.ndim == 3 and base.shape[2] == 1:
                    base = base.squeeze(axis=2)

            # --- Global blend ALWAYS (even with no mask) ---
            out = np.clip(base * (1.0 - blend) + out * blend, 0.0, 1.0)

            # --- Apply active mask gating (if present) ---
            H, W = out.shape[:2]
            m = _get_active_mask_resized(self.doc, H, W)
            if m is not None:
                if out.ndim == 3:
                    M = np.repeat(m[:, :, None], out.shape[2], axis=2).astype(np.float32)
                    out = np.clip(base * (1.0 - M) + out * M, 0.0, 1.0)
                else:
                    out = np.clip(base * (1.0 - m) + out * m, 0.0, 1.0)

            out = out.astype(np.float32, copy=False)

            # --- Commit to document ---
            _meta = {"step_name": "CLAHE",
                     "command_id": "clahe",
                     "preset": {"clip_limit": float(clip), "tile_px": int(tile_px)}}
            if hasattr(self.doc, "set_image"):
                self.doc.set_image(out, metadata=_meta, step_name="CLAHE")
            else:
                self.doc.image = out

            # ── Register as last_headless_command for replay ─────────────
            try:
                main = self.parent()
                while main is not None and not hasattr(main, "_remember_last_headless_command"):
                    main = main.parent()
                if main is not None:
                    preset = {
                        "clip_limit": float(clip),
                        "tile_px": int(tile_px),
                        "blend": float(blend),
                    }
                    main._remember_last_headless_command(
                        "clahe", preset,
                        description=f"CLAHE (clip={clip:.1f}, tile={tile_px}px, blend={blend:.2f})"
                    )
            except Exception:
                pass
            # ─────────────────────────────────────────────────────────────

            # Dialog stays open so user can apply to other images
            self._refresh_document_from_active()

        except Exception as e:
            QMessageBox.critical(self, "CLAHE", f"Failed to apply:\n{e}")

    def _refresh_document_from_active(self):
        """
        Refresh the dialog's document reference to the currently active document.
        This allows reusing the same dialog on different images.
        """
        try:
            main = self.parent()
            if main and hasattr(main, "_active_doc"):
                new_doc = main._active_doc()
                if new_doc is not None and new_doc is not self.doc:
                    self.doc = new_doc
                    # Refresh original image and preview for new document
                    self.orig = np.clip(np.asarray(new_doc.image, dtype=np.float32), 0.0, 1.0)
                    disp = self.orig
                    if disp.ndim == 2: disp = disp[..., None].repeat(3, axis=2)
                    elif disp.ndim == 3 and disp.shape[2] == 1: disp = disp.repeat(3, axis=2)
                    self._disp_base = disp
                    self._update_preview()
        except Exception:
            pass

    def _tile_grid_from_px(self, tile_px: int, hw: tuple[int, int]) -> tuple[int, int]:
        """
        Convert desired tile size (pixels) into OpenCV tileGridSize=(n,n)
        where n is number of tiles across the *min dimension*.
        """
        h, w = hw
        s = float(min(h, w))
        tile_px = max(8, int(tile_px))
        n = int(round(s / float(tile_px)))
        n = max(2, min(n, 128))
        return (n, n)

    # -------- preset emit (grip) --------
    def get_preset(self) -> dict:
        """Emit current slider state as the CLAHE preset schema (inverse of seed_from_preset).
        Mirrors exactly what _apply records for Replay Last."""
        return {
            "clip_limit": float(self.s_clip.value()) / 10.0,
            "tile_px": int(self.s_tile.value()),
            "blend": float(self.s_blend.value()) / 100.0,
        }

    # -------- preset seed (double-click open) --------
    def seed_from_preset(self, p: dict | None):
        """Inverse of get_preset. clip is int×10, blend is int×100 (percent),
        tile_px is direct pixels. Supports legacy 'tile' (tile-count) presets.
        Block signals around sets, then set labels + fire one preview by hand."""
        p = dict(p or {})

        # clip_limit -> slider int (×10)
        try:
            ci = int(round(float(p.get("clip_limit", 2.0)) * 10.0))
            ci = max(self.s_clip.minimum(), min(self.s_clip.maximum(), ci))
        except Exception:
            ci = self.s_clip.value()

        # tile: prefer tile_px (direct); fall back to legacy tile-count heuristic.
        try:
            if "tile_px" in p:
                tp = int(p.get("tile_px", 128))
            else:
                legacy = max(2, min(int(p.get("tile", 8)), 128))
                tp = int(round(2048 / float(legacy)))
            tp = max(self.s_tile.minimum(), min(self.s_tile.maximum(), tp))
        except Exception:
            tp = self.s_tile.value()

        # blend -> percent int; accept 0..1 or 0..100.
        try:
            b = float(p.get("blend", 1.0))
            if b <= 1.0:
                b = b * 100.0
            bi = int(round(b))
            bi = max(self.s_blend.minimum(), min(self.s_blend.maximum(), bi))
        except Exception:
            bi = self.s_blend.value()

        for w in (self.s_clip, self.s_tile, self.s_blend):
            try: w.blockSignals(True)
            except Exception: pass
        try:
            self.s_clip.setValue(ci)
            self.s_tile.setValue(tp)
            self.s_blend.setValue(bi)
        finally:
            for w in (self.s_clip, self.s_tile, self.s_blend):
                try: w.blockSignals(False)
                except Exception: pass

        # Labels are driven by the (now-blocked) valueChanged lambdas -> set by hand.
        self.lbl_clip.setText(f"{ci/10.0:.1f}")
        self.lbl_tile.setText(f"{tp} px")
        self.lbl_blend.setText(f"{bi}%")

        # One preview reflecting the seeded state.
        try:
            self._update_preview()
        except Exception:
            pass

    def _reset(self):
        self.s_clip.setValue(20)
        self.s_tile.setValue(128)
        self.s_blend.setValue(100)
        self._set_pix(self._disp_base)
        self.view.fit_to_item(self.pix)


def open_clahe_with_preset(main_window, preset: dict | None = None):
    from PyQt6.QtGui import QIcon

    # Resolve doc: active MDI subwindow first, then docman fallback.
    doc = None
    try:
        sw = main_window.mdi.activeSubWindow()
        if sw is not None:
            doc = getattr(sw.widget(), "document", None)
    except Exception:
        doc = None
    if doc is None:
        dm = getattr(main_window, "doc_manager", getattr(main_window, "docman", None))
        if dm is not None:
            doc = (dm.get_active_document() if hasattr(dm, "get_active_document")
                   else getattr(dm, "active_document", None))
    if doc is None or getattr(doc, "image", None) is None:
        return None

    _icon = QIcon()
    try:
        from setiastro.saspro.resources import clahe_path
        _icon = QIcon(clahe_path)
    except Exception:
        pass

    # Constructor takes a QIcon (not a path).
    dlg = CLAHEDialogPro(main_window, doc, icon=_icon)

    # No on-show reset -> seed directly before show.
    try:
        dlg.seed_from_preset(preset or {})
    except Exception:
        pass

    try:
        main_window._clahe_dialog = dlg   # retain against GC (WA_DeleteOnClose)
    except Exception:
        pass

    dlg.show(); dlg.raise_(); dlg.activateWindow()
    return dlg