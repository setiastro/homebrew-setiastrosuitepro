#saspro/morphology.py
from __future__ import annotations
import numpy as np
import cv2

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QImage, QPixmap, QIcon
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGroupBox, QGridLayout, QFormLayout,
    QLabel, QPushButton, QSlider, QComboBox,
    QGraphicsScene, QGraphicsPixmapItem, QMessageBox, QSpinBox, QDialogButtonBox
)

# Import centralized widgets
from setiastro.saspro.widgets.graphics_views import ZoomableGraphicsView
from setiastro.saspro.widgets.image_utils import (
    extract_mask_resized as _get_active_mask_resized,
    blend_with_mask as _blend_with_mask
)
from setiastro.saspro.widgets.themed_buttons import themed_toolbtn
from setiastro.saspro.help_support import make_help_button

# ---------------- Core (unchanged) ----------------
def apply_morphology(image: np.ndarray, *, operation: str = "erosion",
                     kernel_size: int = 3, iterations: int = 1) -> np.ndarray:
    # ... (existing body unchanged)
    if image is None:
        raise ValueError("image is None")
    img = np.clip(np.asarray(image, dtype=np.float32), 0.0, 1.0)
    was_hw1 = (img.ndim == 3 and img.shape[2] == 1)
    if kernel_size % 2 == 0: kernel_size += 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))

    def _do(u8):
        if operation == "erosion":  return cv2.erode(u8, kernel, iterations=iterations)
        if operation == "dilation": return cv2.dilate(u8, kernel, iterations=iterations)
        if operation == "opening":  return cv2.morphologyEx(u8, cv2.MORPH_OPEN, kernel, iterations=iterations)
        if operation == "closing":  return cv2.morphologyEx(u8, cv2.MORPH_CLOSE, kernel, iterations=iterations)
        raise ValueError(f"Unsupported morphological operation: {operation}")

    if img.ndim == 2 or was_hw1:
        mono = (img.squeeze() * 255.0).astype(np.uint8)
        out = _do(mono).astype(np.float32) / 255.0
        out = np.clip(out, 0.0, 1.0)
        return out[..., None] if was_hw1 else out

    if img.ndim == 3 and img.shape[2] == 3:
        u8 = (img * 255.0).astype(np.uint8)
        # OpenCV morphology functions handle multi-channel images natively (independent channels)
        out_u8 = _do(u8)
        return (out_u8.astype(np.float32) / 255.0).clip(0.0, 1.0)

    raise ValueError("Input image must be mono (H,W)/(H,W,1) or RGB (H,W,3).")

def apply_morphology_to_doc(doc, preset: dict | None):
    if doc is None or getattr(doc, "image", None) is None:
        raise RuntimeError("Document has no image.")

    img = np.asarray(doc.image)
    op   = (preset or {}).get("operation", "erosion")
    ker  = int((preset or {}).get("kernel", 3))
    it   = int((preset or {}).get("iterations", 1))

    out = apply_morphology(img, operation=str(op), kernel_size=ker, iterations=it)
    out = np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)

    # Blend with active mask if present
    H, W = out.shape[:2]
    m = _get_active_mask_resized(doc, H, W)
    if m is not None:
        base = np.asarray(doc.image, dtype=np.float32)
        if base.dtype.kind in "ui":
            maxv = float(np.iinfo(base.dtype).max)
            base = base / max(1.0, maxv)
        else:
            base = np.clip(base, 0.0, 1.0)
        out = _blend_with_mask(base, out, m).astype(np.float32, copy=False)

    _meta = {"step_name": "Morphology", "command_id": "morphology",
             "preset": {"operation": str(op), "kernel": int(ker), "iterations": int(it)}}
    if hasattr(doc, "set_image"): doc.set_image(out, metadata=_meta, step_name="Morphology")
    else: doc.image = out

# Note: _get_active_mask_resized and _blend_with_mask imported from setiastro.saspro.widgets.image_utils


# ---------------- Dialog ----------------
class MorphologyDialogPro(QDialog):
    OPS = ["Erosion", "Dilation", "Opening", "Closing"]
    OP_MAP = {"Erosion":"erosion","Dilation":"dilation","Opening":"opening","Closing":"closing"}

    def __init__(self, parent, doc, icon: QIcon | None = None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Morphological Operations"))
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        except Exception:
            pass  # older PyQt6 versions        
        if icon:
            try: self.setWindowIcon(icon)
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

        self.doc  = doc
        self.orig = np.clip(np.asarray(doc.image, dtype=np.float32), 0.0, 1.0)

        disp = self.orig
        if disp.ndim == 2: disp = disp[..., None].repeat(3, axis=2)
        elif disp.ndim == 3 and disp.shape[2] == 1: disp = disp.repeat(3, axis=2)
        self._disp_base = disp

        v = QVBoxLayout(self)

        # ---- Params (unchanged) ----
        grp = QGroupBox(self.tr("Morphological Parameters"))
        grid = QGridLayout(grp)
        self.cb_op = QComboBox(); self.cb_op.addItems(self.OPS)
        self.sp_kernel = QSpinBox(); self.sp_kernel.setRange(1, 31); self.sp_kernel.setSingleStep(2)
        self.sp_iter   = QSpinBox(); self.sp_iter.setRange(1, 10)

        init = dict(initial or {})
        op_text = {v:k for k,v in self.OP_MAP.items()}.get(str(init.get("operation","erosion")).lower(), "Erosion")
        self.cb_op.setCurrentText(op_text)
        k = int(init.get("kernel", 3)); self.sp_kernel.setValue(k if k % 2 == 1 else k + 1)
        self.sp_iter.setValue(int(init.get("iterations", 1)))

        self.cb_op.currentTextChanged.connect(self._debounce)
        self.sp_kernel.valueChanged.connect(self._debounce)
        self.sp_iter.valueChanged.connect(self._debounce)

        grid.addWidget(QLabel(self.tr("Operation:")), 0, 0); grid.addWidget(self.cb_op, 0, 1, 1, 2)
        grid.addWidget(QLabel(self.tr("Kernel size:")), 1, 0); grid.addWidget(self.sp_kernel, 1, 1)
        grid.addWidget(QLabel(self.tr("Iterations:")), 2, 0); grid.addWidget(self.sp_iter, 2, 1)
        v.addWidget(grp)

        # ---- Preview with zoom/pan ----
        self.scene = QGraphicsScene(self)
        self.view  = ZoomableGraphicsView(self.scene)
        self.view.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.pix   = QGraphicsPixmapItem()
        self.scene.addItem(self.pix)
        v.addWidget(self.view, 1)

        # ---- Zoom bar (themed) ----
        z = QHBoxLayout()
        z.addStretch(1)

        btn_in  = themed_toolbtn("zoom-in", "Zoom In")
        btn_out = themed_toolbtn("zoom-out", "Zoom Out")
        btn_fit = themed_toolbtn("zoom-fit-best", "Fit to Preview")

        btn_in.clicked.connect(self.view.zoom_in)
        btn_out.clicked.connect(self.view.zoom_out)
        btn_fit.clicked.connect(lambda: self.view.fit_to_item(self.pix))

        z.addWidget(btn_in)
        z.addWidget(btn_out)
        z.addWidget(btn_fit)
        v.addLayout(z) 


        # ---- Buttons (unchanged) ----
        row = QHBoxLayout()
        btn_apply = QPushButton(self.tr("Apply"));  btn_apply.clicked.connect(self._apply)
        btn_reset = QPushButton(self.tr("Reset"));  btn_reset.clicked.connect(self._reset)
        btn_cancel= QPushButton(self.tr("Cancel")); btn_cancel.clicked.connect(self.reject)
        row.addStretch(1); row.addWidget(btn_apply); row.addWidget(btn_reset); row.addWidget(btn_cancel)
        v.addLayout(row)

        # --- preset drag handle (grip), pinned lower-left ---
        try:
            from setiastro.saspro.shortcuts import PresetDragHandle
            try:
                from setiastro.saspro.resources import morpho_path
                _grip_icon = QIcon(morpho_path)
            except Exception:
                _grip_icon = QIcon()
            drag_row = QHBoxLayout()
            drag_row.setContentsMargins(0, 0, 0, 0)
            self.preset_drag_handle = PresetDragHandle(
                "morphology", self.get_preset, icon=_grip_icon,
                tooltip=self.tr(
                    "Drag to the canvas to create a Morphology shortcut with these settings.\n"
                    "Drop directly on an image to apply them headlessly."),
                parent=self,
            )
            drag_row.addWidget(self.preset_drag_handle)
            drag_row.addStretch(1)   # push grip hard to the LEFT edge
            self.btn_help = make_help_button("morphology", self)
            drag_row.addWidget(self.btn_help)            
            v.addLayout(drag_row)
        except Exception:
            pass

        self._timer = QTimer(self); self._timer.setSingleShot(True); self._timer.timeout.connect(self._update_preview)

        self._set_pix(self._disp_base)
        self._update_preview()
        # initial fit
        self.view.fit_to_item(self.pix)

    def _debounce(self): self._timer.start(200)

    def _set_pix(self, rgb):
        arr = (np.clip(rgb, 0, 1) * 255).astype(np.uint8)
        h, w, _ = arr.shape
        q = QImage(arr.data, w, h, 3*w, QImage.Format.Format_RGB888)
        self.pix.setPixmap(QPixmap.fromImage(q))
        self.scene.setSceneRect(self.pix.boundingRect())

    def _params(self):
        op = self.OP_MAP[self.cb_op.currentText()]
        k  = int(self.sp_kernel.value())
        it = int(self.sp_iter.value())
        if k % 2 == 0: k += 1
        return op, k, it

    # ── preset emit / seed ─────────────────────────────────────────────
    def get_preset(self) -> dict:
        """Emit side — byte-for-byte what _apply records / the consumer reads."""
        op, k, it = self._params()
        return {"operation": op, "kernel": int(k), "iterations": int(it)}

    def seed_from_preset(self, p: dict | None):
        """Exact inverse of get_preset."""
        p = dict(p or {})

        op = str(p.get("operation", "erosion")).lower()
        op_text = {v: k for k, v in self.OP_MAP.items()}.get(op, "Erosion")

        try:
            k = int(p.get("kernel", 3))
        except (TypeError, ValueError):
            k = 3
        if k % 2 == 0:
            k += 1
        k = max(1, min(31, k))

        try:
            it = int(p.get("iterations", 1))
        except (TypeError, ValueError):
            it = 1
        it = max(1, min(10, it))

        for w in (self.cb_op, self.sp_kernel, self.sp_iter):
            w.blockSignals(True)
        try:
            self.cb_op.setCurrentText(op_text)
            self.sp_kernel.setValue(k)
            self.sp_iter.setValue(it)
        finally:
            for w in (self.cb_op, self.sp_kernel, self.sp_iter):
                w.blockSignals(False)

        self._update_preview()

    def _update_preview(self):
        op, k, it = self._params()
        try:
            out = apply_morphology(self._disp_base, operation=op, kernel_size=k, iterations=it)

            # Blend preview with active mask (preview is on _disp_base size)
            H, W = out.shape[:2]
            m = _get_active_mask_resized(self.doc, H, W)
            if m is not None:
                base = self._disp_base.astype(np.float32)
                out = _blend_with_mask(base, out.astype(np.float32), m)

            self._set_pix(out)
        except Exception as e:
            QMessageBox.warning(self, "Morphology", f"Preview failed:\n{e}")

    def _apply(self):
        op, k, it = self._params()
        try:
            out = apply_morphology(self.orig, operation=op, kernel_size=k, iterations=it)
            out = np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)

            # Blend with active mask at full resolution
            H, W = out.shape[:2]
            m = _get_active_mask_resized(self.doc, H, W)
            if m is not None:
                base = np.asarray(self.doc.image, dtype=np.float32)
                if base.dtype.kind in "ui":
                    maxv = float(np.iinfo(base.dtype).max)
                    base = base / max(1.0, maxv)
                else:
                    base = np.clip(base, 0.0, 1.0)
                out = _blend_with_mask(base, out, m).astype(np.float32, copy=False)

            # Commit to document
            _meta = {"step_name": "Morphology", "command_id": "morphology",
                     "preset": {"operation": op, "kernel": int(k), "iterations": int(it)}}
            if hasattr(self.doc, "set_image"):
                self.doc.set_image(out, metadata=_meta, step_name="Morphology")
            else:
                self.doc.image = out

            # ── Register as last_headless_command for replay ───────────
            try:
                main = self.parent()
                if main is not None:
                    preset = {
                        "operation": op,
                        "kernel": int(k),
                        "iterations": int(it),
                    }
                    payload = {
                        "command_id": "morphology",
                        "preset": dict(preset),
                    }
                    setattr(main, "_last_headless_command", payload)

                    # optional log
                    try:
                        if hasattr(main, "_log"):
                            main._log(
                                f"[Replay] Registered Morphology as last action "
                                f"(op={op}, kernel={k}, iter={it})"
                            )
                    except Exception:
                        pass
            except Exception:
                # never break apply if replay wiring fails
                pass
            # ────────────────────────────────────────────────────────────

            # Dialog stays open so user can apply to other images
            # Refresh document reference for next operation
            self._refresh_document_from_active()
        except Exception as e:
            QMessageBox.critical(self, "Morphology", f"Failed to apply:\n{e}")

    def _refresh_document_from_active(self):
        """
        Refresh the dialog's document reference to the currently active document.
        This allows reusing the same dialog on different images.
        """
        try:
            main = self.parent()
            if main and hasattr(main, "_active_doc"):
                new_doc = main._active_doc()
                if new_doc is not None and new_doc is not self.doc:
                    self.doc = new_doc
                    # Refresh preview for new document
                    self.orig = np.clip(np.asarray(new_doc.image, dtype=np.float32), 0.0, 1.0)
                    disp = self.orig
                    if disp.ndim == 2: disp = disp[..., None].repeat(3, axis=2)
                    elif disp.ndim == 3 and disp.shape[2] == 1: disp = disp.repeat(3, axis=2)
                    self._disp_base = disp
                    self._update_preview()
        except Exception:
            pass



    def _reset(self):
        self.cb_op.setCurrentText("Erosion")
        self.sp_kernel.setValue(3)
        self.sp_iter.setValue(1)
        self._set_pix(self._disp_base)
        self.view.fit_to_item(self.pix)


# ---------------------- Preset editor (Shortcuts) ----------------------

class _MorphologyPresetDialog(QDialog):
    """
    Preset editor for Morphology shortcuts.
    Stores JSON-safe dict:
        { "operation": "erosion|dilation|opening|closing",
          "kernel": int odd,
          "iterations": int }
    """
    OPS = ["erosion", "dilation", "opening", "closing"]

    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Morphology — Preset")
        p = dict(initial or {})
        f = QFormLayout(self)

        self.cb_op = QComboBox()
        self.cb_op.addItems([op.title() for op in self.OPS])
        op0 = str(p.get("operation", "erosion")).lower()
        if op0 not in self.OPS:
            op0 = "erosion"
        self.cb_op.setCurrentText(op0.title())

        self.sp_kernel = QSpinBox()
        self.sp_kernel.setRange(1, 31)
        self.sp_kernel.setSingleStep(2)
        k = int(p.get("kernel", 3))
        if k % 2 == 0:
            k += 1
        self.sp_kernel.setValue(k)

        self.sp_iter = QSpinBox()
        self.sp_iter.setRange(1, 10)
        self.sp_iter.setValue(int(p.get("iterations", 1)))

        f.addRow("Operation:", self.cb_op)
        f.addRow("Kernel size:", self.sp_kernel)
        f.addRow("Iterations:", self.sp_iter)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        f.addRow(btns)

    def result_dict(self) -> dict:
        k = int(self.sp_kernel.value())
        if k % 2 == 0:
            k += 1
        return {
            "operation": self.cb_op.currentText().lower(),
            "kernel": int(k),
            "iterations": int(self.sp_iter.value()),
        }


# ---------------------- Headless runner (Scripts / Presets / Replay) ----------------------

def run_morphology_via_preset(main, preset: dict | None = None, *, target_doc=None):
    """
    Headless Morphology runner.

    preset keys:
      - operation: "erosion" | "dilation" | "opening" | "closing"
      - kernel: odd int (default 3)
      - iterations: int >= 1 (default 1)
    """
    p = dict(preset or {})

    # ---- Remember for Replay ----
    try:
        remember = getattr(main, "_remember_last_headless_command", None) \
                   or getattr(main, "remember_last_headless_command", None)
        if callable(remember):
            remember("morphology", p, description="Morphology")
        else:
            setattr(main, "_last_headless_command", {
                "command_id": "morphology",
                "preset": dict(p),
            })
    except Exception:
        pass
    # ----------------------------

    dm = getattr(main, "doc_manager", None) or getattr(main, "dm", None)

    # Resolve doc
    doc = target_doc
    if doc is None:
        d = getattr(main, "_active_doc", None)
        doc = d() if callable(d) else d

    if doc is None or getattr(doc, "image", None) is None:
        QMessageBox.warning(main, "Morphology", "Load an image first.")
        return

    try:
        apply_morphology_to_doc(doc, p)
        if hasattr(main, "_log"):
            main._log(f"✅ Morphology (headless) preset={p}")
    except Exception as e:
        QMessageBox.critical(main, "Morphology", str(e))
        if hasattr(main, "_log"):
            main._log(f"❌ Morphology failed: {e}")


def open_morphology_with_preset(main_window, preset: dict | None = None):
    doc = None
    try:
        sw = main_window.mdi.activeSubWindow()
        if sw is not None:
            doc = getattr(sw.widget(), "document", None)
    except Exception:
        doc = None
    if doc is None:
        dm = getattr(main_window, "doc_manager", getattr(main_window, "docman", None))
        if dm is not None:
            try:
                doc = (dm.get_active_document() if hasattr(dm, "get_active_document")
                       else getattr(dm, "active_document", None))
            except Exception:
                doc = None
    if doc is None:
        try:
            ad = getattr(main_window, "_active_doc", None)
            if callable(ad):
                doc = ad()
        except Exception:
            doc = None
    if doc is None or getattr(doc, "image", None) is None:
        return None

    _icon = QIcon()
    try:
        from setiastro.saspro.resources import morphology_path
        _icon = QIcon(morphology_path)
    except Exception:
        _icon = QIcon()

    dlg = MorphologyDialogPro(main_window, doc, icon=_icon)   # parent FIRST, doc SECOND
    try:
        dlg.seed_from_preset(preset or {})
    except Exception:
        pass
    try:
        main_window._morphology_dialog = dlg   # retain against GC (WA_DeleteOnClose)
    except Exception:
        pass
    dlg.show(); dlg.raise_(); dlg.activateWindow()
    return dlg
