# src/setiastro/saspro/remove_stars.py
from __future__ import annotations
import os
import sys
import time
import urllib.request
import urllib.error
from pathlib import Path
import platform
import shutil
import stat
import tempfile
import numpy as np

from PyQt6.QtCore import QThread, pyqtSignal, Qt, QSettings, QUrl
from PyQt6.QtWidgets import (
    QInputDialog, QMessageBox, QFileDialog,QGroupBox,
    QDialog, QVBoxLayout, QTextEdit, QPushButton, QProgressBar, QDoubleSpinBox,
    QLabel, QComboBox, QCheckBox, QSpinBox, QFormLayout, QDialogButtonBox, QWidget, QHBoxLayout, QApplication
)
from PyQt6.QtGui import QDesktopServices, QIcon, QPixmap


from setiastro.saspro.cosmicclarity_engines.darkstar_engine import (
    darkstar_starremoval_rgb01,
    DarkStarParams,
)

# use your legacy I/O functions (as requested)
from setiastro.saspro.legacy.image_manager import save_image, load_image
import glob
try:
    import cv2
except Exception:
    cv2 = None

# Shared utilities
from setiastro.saspro.widgets.image_utils import extract_mask_from_document as _active_mask_array_from_doc
from setiastro.saspro.resources import get_resources, starnet_path, get_icons, rcastro_path, syqon_path

_ENABLE_SYQON = True  # flip to True only after you get permission

# --- Star Removal tool registry ---
_STAR_REMOVAL_TOOLS = [
    {"key": "syqon", "label": "SyQon Starless", "runner": "_run_syqon", "icon_path": starnet_path},    
    {"key": "starnet", "label": "StarNet", "runner": "_run_starnet", "icon_path": syqon_path},
    {"key": "darkstar", "label": "CosmicClarity Dark Star", "runner": "_run_darkstar", "icon_path": starnet_path},
    #{"key": "sxt",     "label": "StarXTerminator (RC-Astro)",   "runner": "_run_sxt",     "icon_path": rcastro_path},
]

_MAD_NORM = 1.4826

# --------- deterministic, invertible stretch used for StarNet ----------
# ---------- stretch-like MTF (linked) pre-stretch for StarNet ----------
def _robust_peak_sigma(gray: np.ndarray) -> tuple[float, float]:
    gray = gray.astype(np.float32, copy=False)
    med = float(np.median(gray))
    mad = float(np.median(np.abs(gray - med)))
    sigma = 1.4826 * mad if mad > 0 else float(gray.std())
    try:
        hist, edges = np.histogram(gray, bins=2048, range=(gray.min(), gray.max()))
        peak = float(0.5 * (edges[np.argmax(hist)] + edges[np.argmax(hist)+1]))
    except Exception:
        peak = med
    return peak, max(sigma, 1e-8)

def _mtf_apply(x: np.ndarray, shadows: float, midtones: float, highlights: float) -> np.ndarray:
    s, m, h = float(shadows), float(midtones), float(highlights)
    denom = max(h - s, 1e-8)
    xp = (x - s) / denom
    xp = np.clip(xp, 0.0, 1.0)
    num = (m - 1.0) * xp
    den = ((2.0 * m - 1.0) * xp) - m
    y = np.divide(num, den, out=np.zeros_like(xp, dtype=np.float32), where=np.abs(den) > 1e-12)
    return np.clip(y, 0.0, 1.0).astype(np.float32, copy=False)

def _mtf_inverse(y: np.ndarray, shadows: float, midtones: float, highlights: float) -> np.ndarray:
    s = float(shadows)
    m = float(midtones)
    h = float(highlights)
    yp = np.clip(y.astype(np.float32, copy=False), 0.0, 1.0)
    num = (((s + h) * m - s) * yp - s * m + s)
    den = (2.0 * m - 1.0) * yp - m + 1.0
    x = np.divide(
        num, den,
        out=np.full_like(yp, s, dtype=np.float32),
        where=np.abs(den) > 1e-12
    )
    x = np.clip(x, s, h)
    return np.clip(x, 0.0, 1.0).astype(np.float32, copy=False)

def _mtf_params_linked(img_rgb01: np.ndarray, shadowclip_sigma: float = -2.8, targetbg: float = 0.25):
    x = np.asarray(img_rgb01, dtype=np.float32)
    bp = float(np.clip(x.min(), 0.0, 1.0 - 1e-6))
    denom = max(1.0 - bp, 1e-12)
    med_raw = float(np.median(x))
    med_rescaled = float(np.clip((med_raw - bp) / denom, 1e-6, 1.0 - 1e-6))
    tb = float(np.clip(targetbg, 1e-6, 1.0 - 1e-6))
    denom_m = (2.0 * tb - 1.0) * med_rescaled - tb
    if abs(denom_m) < 1e-12:
        denom_m = 1e-12
    m = med_rescaled * (tb - 1.0) / denom_m
    m = float(np.clip(m, 1e-4, 1.0 - 1e-4))
    return {"s": bp, "m": m, "h": 1.0}

def _apply_mtf_linked_rgb(img_rgb01: np.ndarray, p: dict) -> np.ndarray:
    if img_rgb01.ndim == 2:
        img_rgb01 = np.stack([img_rgb01]*3, axis=-1)
    y = np.empty_like(img_rgb01, dtype=np.float32)
    for c in range(3):
        y[..., c] = _mtf_apply(img_rgb01[..., c], p["s"], p["m"], p["h"])
    return np.clip(y, 0.0, 1.0)

def _invert_mtf_linked_rgb(img_rgb01: np.ndarray, p: dict) -> np.ndarray:
    y = np.empty_like(img_rgb01, dtype=np.float32)
    for c in range(3):
        y[..., c] = _mtf_inverse(img_rgb01[..., c], p["s"], p["m"], p["h"])
    return y

def _mtf_params_unlinked_noclip(img_rgb01: np.ndarray, targetbg: float = 0.25) -> dict:
    x = np.asarray(img_rgb01, dtype=np.float32)
    if x.ndim == 2:
        x_in = x[..., None]
        C_in = 1
    elif x.ndim == 3 and x.shape[2] == 1:
        x_in = x
        C_in = 1
    else:
        x_in = x[..., :3]
        C_in = x_in.shape[2]

    med = np.median(x_in, axis=(0, 1)).astype(np.float32)
    s_in = np.zeros(C_in, dtype=np.float32)
    m_in = np.zeros(C_in, dtype=np.float32)
    h_in = np.ones(C_in, dtype=np.float32)
    tb = float(np.clip(targetbg, 1e-6, 1.0 - 1e-6))
    for c in range(C_in):
        md = float(np.clip(med[c], 1e-6, 1.0 - 1e-6))
        m_in[c] = float(_mtf_scalar(md, tb, 0.0, 1.0))

    if C_in == 1:
        s = np.repeat(s_in, 3)
        m = np.repeat(m_in, 3)
        h = np.repeat(h_in, 3)
    else:
        s = s_in; m = m_in; h = h_in

    return {"s": s, "m": m, "h": h}

def _mtf_params_unlinked(img_rgb01, shadows_clipping=-2.8, targetbg=0.25):
    import numpy as np
 
    x = np.asarray(img_rgb01, dtype=np.float32)
    if x.ndim == 2:
        x_in = x[..., None]; C_in = 1
    elif x.ndim == 3 and x.shape[2] == 1:
        x_in = x; C_in = 1
    else:
        x_in = x; C_in = x.shape[2]
 
    s_in = np.zeros(C_in, dtype=np.float32)
    m_in = np.zeros(C_in, dtype=np.float32)
    h_in = np.ones(C_in, dtype=np.float32)
 
    tb = float(np.clip(targetbg, 1e-6, 1.0 - 1e-6))
 
    for c in range(C_in):
        ch = x_in[..., c]
        bp = float(np.clip(ch.min(), 0.0, 1.0 - 1e-6))
        denom = max(1.0 - bp, 1e-12)
        med_raw = float(np.median(ch))
        med_rescaled = float(np.clip((med_raw - bp) / denom, 1e-6, 1.0 - 1e-6))
        denom_m = (2.0 * tb - 1.0) * med_rescaled - tb
        if abs(denom_m) < 1e-12:
            denom_m = 1e-12
        m = med_rescaled * (tb - 1.0) / denom_m
        m = float(np.clip(m, 1e-4, 1.0 - 1e-4))
        s_in[c] = bp
        m_in[c] = m
        h_in[c] = 1.0
 
    if C_in == 1:
        s = np.repeat(s_in, 3); m_arr = np.repeat(m_in, 3); h = np.repeat(h_in, 3)
    else:
        s = s_in; m_arr = m_in; h = h_in
 
    return {"s": s, "m": m_arr, "h": h}


def _mtf_scalar(x: float, m: float, lo: float = 0.0, hi: float = 1.0) -> float:
    if x <= lo: return 0.0
    if x >= hi: return 1.0
    denom_range = hi - lo
    if abs(denom_range) < 1e-12: return 0.0
    xp = (x - lo) / denom_range
    num = (m - 1.0) * xp
    den = (2.0 * m - 1.0) * xp - m
    if abs(den) < 1e-12: return 0.5
    y = num / den
    return float(np.clip(y, 0.0, 1.0))


def _apply_mtf_unlinked_rgb(img_rgb01: np.ndarray, p: dict) -> np.ndarray:
    x = np.asarray(img_rgb01, dtype=np.float32)
    if x.ndim == 2:
        x = np.stack([x]*3, axis=-1)
    elif x.ndim == 3 and x.shape[2] == 1:
        x = np.repeat(x, 3, axis=2)
    out = np.empty_like(x, dtype=np.float32)
    for c in range(x.shape[2]):
        out[..., c] = _mtf_apply(x[..., c], float(p["s"][c]), float(p["m"][c]), float(p["h"][c]))
    return np.clip(out, 0.0, 1.0)


def _invert_mtf_unlinked_rgb(img_rgb01: np.ndarray, p: dict) -> np.ndarray:
    y = np.asarray(img_rgb01, dtype=np.float32)
    if y.ndim == 2:
        y = np.stack([y]*3, axis=-1)
    elif y.ndim == 3 and y.shape[2] == 1:
        y = np.repeat(y, 3, axis=2)
    out = np.empty_like(y, dtype=np.float32)
    for c in range(y.shape[2]):
        out[..., c] = _mtf_inverse(y[..., c], float(p["s"][c]), float(p["m"][c]), float(p["h"][c]))
    return np.clip(out, 0.0, 1.0)

# ------------------------------------------------------------
# Settings helper
# ------------------------------------------------------------
def _get_setting_any(settings, keys: tuple[str, ...], default: str = "") -> str:
    if not settings:
        return default
    for k in keys:
        try:
            v = settings.value(k, "", type=str)
        except Exception:
            v = settings.value(k, "")
        if isinstance(v, str) and v.strip():
            return v.strip()
    return default

def _bp_min_per_channel(img_rgb01: np.ndarray) -> np.ndarray:
    x = np.asarray(img_rgb01, dtype=np.float32)
    if x.ndim == 2:
        x = np.stack([x] * 3, axis=-1)
    elif x.ndim == 3 and x.shape[2] == 1:
        x = np.repeat(x, 3, axis=2)
    else:
        x = x[..., :3]
    return np.min(x, axis=(0, 1)).astype(np.float32)


def _subtract_bp_per_channel(img_rgb01: np.ndarray, bp3: np.ndarray) -> np.ndarray:
    x = np.asarray(img_rgb01, dtype=np.float32)
    if x.ndim == 2:
        x = np.stack([x] * 3, axis=-1)
    elif x.ndim == 3 and x.shape[2] == 1:
        x = np.repeat(x, 3, axis=2)
    else:
        x = x[..., :3]
    return np.clip(x - bp3.reshape((1, 1, 3)), 0.0, 1.0).astype(np.float32, copy=False)


def _add_bp_per_channel(img_rgb01: np.ndarray, bp3: np.ndarray) -> np.ndarray:
    x = np.asarray(img_rgb01, dtype=np.float32)
    if x.ndim == 2:
        x = np.stack([x] * 3, axis=-1)
    elif x.ndim == 3 and x.shape[2] == 1:
        x = np.repeat(x, 3, axis=2)
    else:
        x = x[..., :3]
    return np.clip(x + bp3.reshape((1, 1, 3)), 0.0, 1.0).astype(np.float32, copy=False)

# ================== HEADLESS, ARRAY-IN → STARLESS-ARRAY-OUT ==================
def starnet_starless_from_array(arr_rgb01: np.ndarray, settings, *, tmp_prefix="comet") -> np.ndarray:
    import os, platform, subprocess, numpy as np

    arr = np.asarray(arr_rgb01, dtype=np.float32)
    was_single = (arr.ndim == 2) or (arr.ndim == 3 and arr.shape[2] == 1)

    exe = _get_setting_any(settings, ("starnet/exe_path", "paths/starnet"), "")
    if not exe or not os.path.exists(exe):
        raise RuntimeError("StarNet executable not configured (settings 'paths/starnet').")

    workdir = os.path.dirname(exe) or os.getcwd()
    in_path  = os.path.join(workdir, f"{tmp_prefix}_in.tif")
    out_path = os.path.join(workdir, f"{tmp_prefix}_out.tif")

    x_in = np.asarray(arr, dtype=np.float32)
    if x_in.ndim == 3 and x_in.shape[2] == 1:
        x_in = x_in[..., 0]
    x_in = np.nan_to_num(x_in, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32, copy=False)

    xmax = float(np.max(x_in)) if x_in.size else 1.0
    scale_factor = xmax if xmax > 1.01 else 1.0
    xin = (x_in / scale_factor) if scale_factor > 1.0 else x_in
    xin = np.clip(xin, 0.0, 1.0)

    if xin.ndim == 2:
        xin_rgb = np.stack([xin] * 3, axis=-1)
    elif xin.ndim == 3 and xin.shape[2] == 1:
        xin_rgb = np.repeat(xin, 3, axis=2)
    else:
        xin_rgb = xin[..., :3]

    bp3 = _bp_min_per_channel(xin_rgb)
    xin_bp = _subtract_bp_per_channel(xin_rgb, bp3)
    mtf_params = _mtf_params_unlinked_noclip(xin_bp, targetbg=0.25)
    x_for_starnet = _apply_mtf_unlinked_rgb(xin_bp, mtf_params).astype(np.float32, copy=False)

    save_image(
        x_for_starnet, in_path,
        original_format="tif", bit_depth="16-bit",
        original_header=None, is_mono=False, image_meta=None, file_meta=None
    )

    exe_name = os.path.basename(exe).lower()
    if platform.system() in ("Windows", "Linux"):
        cmd = [exe, in_path, out_path, "256"]
    else:
        cmd = [exe, "--input", in_path, "--output", out_path] if "starnet2" in exe_name else [exe, in_path, out_path]

    rc = subprocess.call(cmd, cwd=workdir)
    if rc != 0 or not os.path.exists(out_path):
        _safe_rm(in_path); _safe_rm(out_path)
        raise RuntimeError(f"StarNet failed rc={rc}")

    starless_s, _, _, _ = load_image(out_path)
    _safe_rm(in_path); _safe_rm(out_path)

    if starless_s.ndim == 2:
        starless_s = np.stack([starless_s] * 3, axis=-1)
    elif starless_s.ndim == 3 and starless_s.shape[2] == 1:
        starless_s = np.repeat(starless_s, 3, axis=2)
    starless_s = np.clip(starless_s.astype(np.float32, copy=False), 0.0, 1.0)

    starless_bp = _invert_mtf_unlinked_rgb(starless_s, mtf_params)
    starless_lin01 = _add_bp_per_channel(starless_bp, bp3)

    if scale_factor > 1.0:
        starless_lin01 = starless_lin01 * scale_factor

    result = starless_lin01.astype(np.float32, copy=False)
    if was_single and result.ndim == 3:
        result = result.mean(axis=2)
    return result

# ------------------------------------------------------------
# Public entry
# ------------------------------------------------------------
def remove_stars(main, target_doc=None):
    if getattr(main, "_remove_stars_headless_running", False):
        return
    if getattr(main, "_remove_stars_guard", False):
        return

    labels = [t["label"] for t in _STAR_REMOVAL_TOOLS]
    settings = QSettings()
    settings_key = "remove_stars/last_tool_label"
    last_label = str(settings.value(settings_key, labels[0] if labels else "", type=str))

    if last_label in labels:
        current_index = labels.index(last_label)
    else:
        current_index = 0

    label, ok = QInputDialog.getItem(
        main, "Select Star Removal Tool", "Choose a tool:", labels, current_index, False
    )
    if not ok:
        return

    try:
        settings.setValue(settings_key, label)
    except Exception:
        pass

    tool = next((t for t in _STAR_REMOVAL_TOOLS if t["label"] == label), None)
    if not tool:
        return

    doc = target_doc
    if doc is None:
        doc = getattr(main, "_active_doc", None)
        if callable(doc):
            doc = doc()

    if doc is None or getattr(doc, "image", None) is None:
        QMessageBox.warning(main, "No Image", "Please load an image before removing stars.")
        return

    fn = globals().get(tool["runner"])
    if callable(fn):
        fn(main, doc, icon_path=tool.get("icon_path"))


def _first_nonzero_bp_per_channel(img3: np.ndarray) -> np.ndarray:
    bps = np.zeros(3, dtype=np.float32)
    for c in range(3):
        ch = img3[..., c].reshape(-1)
        pos = ch[ch > 0.0]
        bps[c] = float(pos.min()) if pos.size else 0.0
    return bps


def _prepare_statstretch_input_for_starnet(img_rgb01: np.ndarray) -> tuple[np.ndarray, dict]:
    import numpy as np
    from setiastro.saspro.imageops.stretch import stretch_color_image

    x = np.asarray(img_rgb01, dtype=np.float32)
    if x.ndim == 2:
        x = np.stack([x]*3, axis=-1)
    elif x.ndim == 3 and x.shape[2] == 1:
        x = np.repeat(x, 3, axis=2)
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    x = np.clip(x, 0.0, 1.0)

    bp = _first_nonzero_bp_per_channel(x)
    xin_ped = np.clip(x - bp.reshape((1, 1, 3)), 0.0, 1.0)
    m0 = np.array([float(np.median(xin_ped[..., c])) for c in range(3)], dtype=np.float32)

    x_for_starnet = stretch_color_image(
        xin_ped, target_median=0.25, linked=False,
        normalize=False, apply_curves=False, curves_boost=0.0
    ).astype(np.float32, copy=False)

    meta = {"statstretch": True, "bp": bp, "m0": m0}
    return x_for_starnet, meta

# -----------------------------------------------------------------------------
# SyQon Starless integration
# -----------------------------------------------------------------------------

def _syqon_data_dir() -> Path:
    try:
        r = get_resources()
        base = Path(r.MODELS_DIR)
        d = base / "syqon_starless"
    except Exception:
        d = Path.home() / ".saspro" / "models" / "syqon_starless"
    d.mkdir(parents=True, exist_ok=True)
    return d

_SYQON_BUY_URL         = "https://donate.stripe.com/14AdR9fZFbw85Rb4Wq2B204"
_SYQON_BUY_URL_NADIR   = "https://donate.stripe.com/14AdR9fZFbw85Rb4Wq2B204"
_SYQON_BUY_URL_AXIOMV2 = "https://syqon.it/starless/"
_SYQON_BUY_URL_AXIOMV3 = "https://syqon.it/starless/"   # update when SyQon supplies a V3 link

def _syqon_buy_url_for(model_kind: str) -> str:
    mk = _syqon_norm_kind(model_kind)
    if mk in ("axiomv2", "axiomv2.1", "axiomv2.2"):
        return _SYQON_BUY_URL_AXIOMV2
    if mk == "axiomv3":
        return _SYQON_BUY_URL_AXIOMV3
    return _SYQON_BUY_URL_NADIR


def _syqon_model_path(d: Path, model_kind: str) -> Path:
    mk = _syqon_norm_kind(model_kind)
    if mk == "axiomv2":
        return d / "axiomv2.pt"
    if mk == "axiomv2.1":
        return d / "axiomv2.1.pt"
    if mk == "axiomv2.2":
        return d / "axiomv2.2.pt"
    if mk == "axiomv3":
        return d / "axiomv3.pt"
    return d / "nadir"

def _syqon_signal_path(d: Path) -> Path:
    """Path to the Signal 1.0 model file, always signal_v1.pt."""
    return d / "signal_v1.pt"
 
 
def _syqon_have_signal(d: Path) -> bool:
    try:
        p = _syqon_signal_path(d)
        return p.exists() and p.is_file()
    except Exception:
        return False


def _syqon_have_deps(d: Path, model_kind: str) -> tuple[bool, bool]:
    return True, _syqon_model_path(d, model_kind).exists()


def _syqon_download_file(url: str, dst: Path, progress_cb=None) -> bool:
    try:
        with urllib.request.urlopen(url) as resp:
            total = int(resp.headers.get("Content-Length", 0) or 0)
            got = 0
            dst.parent.mkdir(parents=True, exist_ok=True)
            with open(dst, "wb") as f:
                while True:
                    chunk = resp.read(1024 * 64)
                    if not chunk:
                        break
                    f.write(chunk)
                    got += len(chunk)
                    if callable(progress_cb) and total > 0:
                        progress_cb(got, total)
        return True
    except Exception:
        return False


def _syqon_compute_target_bg_from_doc(doc) -> float:
    x = np.asarray(doc.image).astype(np.float32, copy=False)
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)

    if x.ndim == 3 and x.shape[2] >= 3:
        gray = x[..., :3].mean(axis=2)
    elif x.ndim == 3 and x.shape[2] == 1:
        gray = x[..., 0]
    else:
        gray = x

    mx = float(np.max(gray)) if gray.size else 1.0
    if mx > 1.01:
        gray = gray / mx

    gray = np.clip(gray, 0.0, 1.0)
    med = float(np.median(gray)) if gray.size else 0.12
    return float(np.clip(med, 0.01, 0.50))

# --- model labels ---
_SYQON_MODEL_LABELS = {
    "nadir":      "Nadir",
    "axiomv2":    "AxiomV2",
    "axiomv2.1":  "AxiomV2.1",
    "axiomv2.2":  "AxiomV2.2",
    "axiomv3":    "AxiomV3",
}


def _syqon_norm_kind(v: str) -> str:
    v = (v or "").strip().lower()
    if v in ("nadir", "nadir model"):
        return "nadir"
    if v in ("axiomv2", "axiom2", "axiom v2", "axiom-v2"):
        return "axiomv2"
    if v in ("axiomv2.1", "axiom2.1", "axiom v2.1", "axiom-v2.1", "axiomv2_1"):
        return "axiomv2.1"
    if v in ("axiomv2.2", "axiom2.2", "axiom v2.2", "axiom-v2.2", "axiomv2_2"):
        return "axiomv2.2"
    if v in ("axiomv3", "axiom3", "axiom v3", "axiom-v3", "axiomv3.0", "v3"):
        return "axiomv3"
    return "nadir"

def _rgb01_to_qimage(rgb01: np.ndarray):
    from PyQt6.QtGui import QImage
    x = np.clip(rgb01, 0.0, 1.0)
    u8 = (x * 255.0 + 0.5).astype(np.uint8)
    u8 = np.ascontiguousarray(u8)
    h, w = u8.shape[:2]
    q = QImage(u8.data, w, h, 3 * w, QImage.Format.Format_RGB888)
    return q.copy()


class _SyQonProcessThread(QThread):
    progress = pyqtSignal(int, str)
    preview  = pyqtSignal(object)
    finished = pyqtSignal(object, object, dict, str)


    def __init__(
        self,
        x_for_net: np.ndarray,
        ckpt_path: str,
        tile: int,
        overlap: int,
        target_bg: float,
        shadow_clip: float,
        model_kind: str = "nadir",
        use_amp: bool = False,
        amp_dtype: str = "fp16",
        channel_mode: str = "rgb",
        *,
        live_preview: bool = False,
        preview_src_rgb01: np.ndarray | None = None,
        preview_max_dim: int = 900,
        preview_emit_ms: int = 120,
        parent=None,
        signal_ckpt_path: str = "",
        signal_tile: int = 1024,
        signal_overlap: int = 64,
        signal_diff_threshold: float = 0.020,        
    ):
        super().__init__(parent)
        self.x_for_net   = x_for_net
        self.ckpt_path   = str(ckpt_path)
        self.model_kind  = (model_kind or "nadir").lower().strip()
        self.channel_mode = (channel_mode or "rgb").lower().strip()
        self.tile        = int(tile)
        self.overlap     = int(overlap)
        self.target_bg   = float(target_bg)
        self.shadow_clip = float(shadow_clip)
        self.live_preview    = bool(live_preview)
        self.preview_src     = preview_src_rgb01
        self.preview_max_dim = int(preview_max_dim)
        self.preview_emit_ms = int(preview_emit_ms)
        self.use_amp  = bool(use_amp)
        ad = (amp_dtype or "fp16").lower().strip()
        if ad not in ("fp16", "bf16"):
            ad = "fp16"
        self.amp_dtype = ad
        self._cancel = False
        self.signal_ckpt_path      = str(signal_ckpt_path)
        self.signal_tile           = int(signal_tile)
        self.signal_overlap        = int(signal_overlap)
        self.signal_diff_threshold = float(signal_diff_threshold)

    def cancel(self):
        self._cancel = True

    def run(self):
        import time
        info = {
            "engine": "syqon_nafnet",
            "use_amp_requested": bool(self.use_amp),
            "amp_dtype_requested": str(self.amp_dtype),
        }

        try:
            if self._cancel:
                raise RuntimeError("Cancelled")

            try:
                from setiastro.saspro.runtime_torch import import_torch
                import_torch(prefer_cuda=True, prefer_xpu=False, status_cb=lambda s: None)
            except Exception as e:
                info["runtime_torch_import"] = f"{type(e).__name__}: {e}"

            from setiastro.saspro.starless_engines.syqon_nafnet_engine import nafnet_starless_rgb01

            preview_buf = None
            scale_x = scale_y = 1.0
            last_emit = 0.0

            if self.live_preview and (self.preview_src is not None):
                src = np.asarray(self.preview_src, dtype=np.float32)
                if src.ndim == 2:
                    src = np.stack([src]*3, axis=-1)
                elif src.ndim == 3 and src.shape[2] == 1:
                    src = np.repeat(src, 3, axis=2)
                else:
                    src = src[..., :3]

                H, W = src.shape[:2]
                md = max(H, W)
                if md > self.preview_max_dim:
                    s = self.preview_max_dim / float(md)
                    Hd = max(1, int(round(H * s)))
                    Wd = max(1, int(round(W * s)))
                else:
                    Hd, Wd = H, W

                if cv2 is not None and (Hd != H or Wd != W):
                    preview_buf = cv2.resize(src, (Wd, Hd), interpolation=cv2.INTER_AREA).astype(np.float32, copy=False)
                else:
                    preview_buf = src.copy()

                scale_x = float(preview_buf.shape[1]) / float(W)
                scale_y = float(preview_buf.shape[0]) / float(H)
                self.preview.emit(_rgb01_to_qimage(preview_buf))
                last_emit = time.time()

            def _prog(done, total, stage):
                if self._cancel:
                    raise RuntimeError("Cancelled")
                pct = int(100.0 * float(done) / max(float(total), 1.0))
                self.progress.emit(pct, str(stage or ""))

            def _tile_cb(y0, x0, ph, pw, tile_rgb01):
                nonlocal preview_buf, last_emit
                if preview_buf is None:
                    return
                if self._cancel:
                    raise RuntimeError("Cancelled")
                dx0 = int(round(x0 * scale_x)); dy0 = int(round(y0 * scale_y))
                dx1 = int(round((x0 + pw) * scale_x)); dy1 = int(round((y0 + ph) * scale_y))
                dx1 = max(dx0 + 1, dx1); dy1 = max(dy0 + 1, dy1)
                dh = min(preview_buf.shape[0], dy1) - dy0
                dw = min(preview_buf.shape[1], dx1) - dx0
                if dh <= 0 or dw <= 0:
                    return
                if cv2 is not None and (dw != pw or dh != ph):
                    tile_disp = cv2.resize(tile_rgb01, (dw, dh), interpolation=cv2.INTER_AREA)
                else:
                    tile_disp = tile_rgb01[:dh, :dw, :]
                preview_buf[dy0:dy0+dh, dx0:dx0+dw, :] = tile_disp.astype(np.float32, copy=False)
                now = time.time()
                if (now - last_emit) * 1000.0 >= float(self.preview_emit_ms):
                    self.preview.emit(_rgb01_to_qimage(preview_buf))
                    last_emit = now

            starless_s, stars_s, engine_info = nafnet_starless_rgb01(
                self.x_for_net,
                ckpt_path=self.ckpt_path,
                tile=self.tile,
                overlap=self.overlap,
                use_gpu=True,
                prefer_dml=True,
                model_kind=self.model_kind,
                residual_mode=True,
                use_amp=self.use_amp,
                amp_dtype=self.amp_dtype,
                channel_mode=self.channel_mode,
                progress_cb=_prog,
                tile_cb=_tile_cb if (self.live_preview and preview_buf is not None) else None,
                signal_ckpt_path      = self.signal_ckpt_path,
                signal_tile           = self.signal_tile,
                signal_overlap        = self.signal_overlap,
                signal_diff_threshold = self.signal_diff_threshold,
            )

            if self._cancel:
                raise RuntimeError("Cancelled")

            if engine_info:
                try:
                    info.update(dict(engine_info))
                except Exception:
                    info["engine_info"] = engine_info

            self.finished.emit(starless_s, stars_s, info, "")

        except Exception as e:
            import traceback
            info["traceback"] = traceback.format_exc()
            self.finished.emit(None, None, info, str(e))


from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap, QIcon

class SyQonLivePreviewWindow(QDialog):
    def __init__(self, parent=None, *, title="SyQon Live Preview", icon: QIcon | None = None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(False)
        self.setMinimumSize(520, 420)
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
        except Exception:
            pass
        if icon is not None:
            try:
                self.setWindowIcon(icon)
            except Exception:
                pass

        lay = QVBoxLayout(self)
        self.lbl = QLabel(self)
        self.lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl.setStyleSheet("border: 1px solid rgba(255,255,255,0.15);")
        self.lbl.setMinimumSize(480, 360)
        lay.addWidget(self.lbl)
        self._last_qimg = None

    def set_frame(self, qimg):
        self._last_qimg = qimg
        self._render()

    def _render(self):
        if self._last_qimg is None:
            return
        pm = QPixmap.fromImage(self._last_qimg)
        pm = pm.scaled(
            self.lbl.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        self.lbl.setPixmap(pm)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self._render()


class SyQonStarlessDialog(QDialog):
    def __init__(self, main, doc, parent=None, icon: QIcon | None = None):
        super().__init__(parent)
        self.main     = main
        self.doc      = doc
        self.data_dir = _syqon_data_dir()
        self.proc_thr = None
        self.setWindowTitle("SyQon Starless")
        self.setMinimumSize(560, 520)
        self.icons = get_icons()

        if icon is not None:
            try:
                self.setWindowIcon(icon)
            except Exception:
                pass

        lay = QVBoxLayout(self)

        self.lbl_logo = QLabel(self)
        self.lbl_logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        try:
            pm = QPixmap(self.icons.SYQON_AXIOM)
            if not pm.isNull():
                self.lbl_logo.setPixmap(
                    pm.scaledToWidth(260, Qt.TransformationMode.SmoothTransformation)
                )
                lay.addWidget(self.lbl_logo)
        except Exception:
            pass

        self.lbl = QLabel("Checking SyQon model…", self)
        self.lbl.setWordWrap(True)
        lay.addWidget(self.lbl)

        self.pbar = QProgressBar(self)
        self.pbar.setRange(0, 100)
        self.pbar.setValue(0)
        self.pbar.setVisible(False)
        lay.addWidget(self.pbar)

        self.cmb_engine = QComboBox(self)
        self.cmb_engine.addItem("SyQon Model (Integrated)", userData="integrated")
        self.cmb_engine.addItem("Starless Standalone CLI",  userData="standalone_cli")
        self.lbl_cli_path  = QLabel("Standalone executable:", self)
        self.edt_cli_path  = QLineEdit(self)
        self.btn_cli_browse = QPushButton("Browse…", self)
        self.btn_cli_browse.clicked.connect(self._browse_cli_exe)

        eng_box = QGroupBox("Engine", self)
        eng_lay = QFormLayout(eng_box)
        eng_lay.addRow("Processing engine:", self.cmb_engine)
        cli_row = QHBoxLayout()
        cli_row.addWidget(self.edt_cli_path, 1)
        cli_row.addWidget(self.btn_cli_browse)
        eng_lay.addRow(self.lbl_cli_path, cli_row)
        lay.addWidget(eng_box)

        # --- model box ---
        self.model_box = QGroupBox("Model", self)
        model_lay = QVBoxLayout(self.model_box)

        self.lbl_model_path = QLabel("", self)
        self.lbl_model_path.setWordWrap(True)
        model_lay.addWidget(self.lbl_model_path)

        self.cmb_model = QComboBox(self)
        self.cmb_model.clear()
        for key in ("nadir", "axiomv2", "axiomv2.1", "axiomv2.2", "axiomv3"):
            self.cmb_model.addItem(_SYQON_MODEL_LABELS[key], userData=key)
        self.cmb_model.setCurrentIndex(0)

        model_lay.addWidget(QLabel("Model variant:", self))
        model_lay.addWidget(self.cmb_model)

        row = QHBoxLayout()
        self.btn_buy     = QPushButton("Get Starless Model Here…", self)
        self.btn_install = QPushButton("Install Downloaded Model…", self)
        self.btn_remove  = QPushButton("Remove Model", self)

        self.btn_buy.clicked.connect(self._open_buy_page)
        self.btn_install.clicked.connect(self._install_model)
        self.btn_remove.clicked.connect(self._remove_model)

        row.addWidget(self.btn_buy)
        row.addWidget(self.btn_install)
        row.addWidget(self.btn_remove)
        row.addStretch(1)
        model_lay.addLayout(row)
        lay.addWidget(self.model_box)

        # --- params ---
        formw = QWidget(self)
        form  = QFormLayout(formw)

        self.spin_tile    = QSpinBox(self);    self.spin_tile.setRange(128, 2048)
        self.spin_overlap = QSpinBox(self);    self.spin_overlap.setRange(16, 512)
        self.spin_shadow  = QDoubleSpinBox(self)
        self.spin_shadow.setRange(0.5, 5.0);   self.spin_shadow.setSingleStep(0.1)
        self.spin_shadow.setDecimals(1)

        self.chk_mtf = QCheckBox("Apply temporary stretch for model (recommended)", self)
        self.chk_mtf.setChecked(True)

        self.spin_mtf_median = QDoubleSpinBox(self)
        self.spin_mtf_median.setRange(0.01, 0.50)
        self.spin_mtf_median.setSingleStep(0.01)
        self.spin_mtf_median.setDecimals(3)
        self.spin_mtf_median.setValue(0.10)
        self.lbl_mtf_median = QLabel("Temp stretch target median:", self)

        self._auto_bg = _syqon_compute_target_bg_from_doc(doc)
        self.lbl_target_bg = QLabel("Target background:", self)
        self.spin_bg = QDoubleSpinBox(self)
        self.spin_bg.setRange(0.01, 0.50); self.spin_bg.setSingleStep(0.01)
        self.spin_bg.setDecimals(3);       self.spin_bg.setValue(self._auto_bg)

        self.chk_show_bg = QCheckBox("Advanced: show Target Background control", self)
        self.chk_show_bg.setChecked(False)
        self.chk_show_bg.toggled.connect(self._toggle_bg)

        self.chk_make_stars = QCheckBox("Also create stars-only document (_stars)", self)
        self.chk_make_stars.setChecked(True)
        self.chk_pad = QCheckBox("Pad edges (improves edge star removal)", self)
        self.chk_pad.setChecked(True)
        self.chk_amp = QCheckBox("Use AMP (mixed precision) — faster on some GPUs", self)
        self.chk_amp.setChecked(False)
        self.chk_rgb_perchan = QCheckBox(
            "RGB + Per-Channel mode (may improve colour accuracy)", self
        )
        self.chk_rgb_perchan.setChecked(False)
        self.chk_rgb_perchan.setToolTip(
            "Runs the model twice: once on the full RGB image and once per channel independently.\n"
            "The two results are averaged, then Lab chroma correction is applied.\n"
            "Can reduce colour fringing on narrowband or colour-imbalanced images.\n"
            "Takes approximately 4× longer than standard mode.\n"
            "Note: not available for AxiomV3 (model uses internal per-tile normalisation)."
        )
        self.spin_pad = QSpinBox(self)
        self.spin_pad.setRange(0, 1024); self.spin_pad.setSingleStep(16)
        self.spin_pad.setValue(256)

        self.cmb_stars_extract = QComboBox(self)
        self.cmb_stars_extract.addItems(["unscreen", "subtract"])
        self.cmb_stars_extract.setCurrentText("unscreen")

        s = getattr(main, "settings", None)
        if s:
            self.spin_tile.setValue(int(s.value("syqon/tile_size", 512)))
            self.spin_overlap.setValue(int(s.value("syqon/overlap", 128)))
            self.spin_shadow.setValue(float(s.value("syqon/shadow_clip", 2.8)))
            self.chk_make_stars.setChecked(bool(s.value("syqon/make_stars", True, type=bool)))
            self.chk_pad.setChecked(bool(s.value("syqon/pad_edges", True, type=bool)))
            self.spin_pad.setValue(int(s.value("syqon/pad_pixels", 256)))
            self.cmb_stars_extract.setCurrentText(str(s.value("syqon/stars_extract", "unscreen")))
            self.chk_mtf.setChecked(bool(s.value("syqon/use_mtf", True, type=bool)))
            self.spin_mtf_median.setValue(float(s.value("syqon/mtf_target_median", 0.10)))
            self.chk_amp.setChecked(bool(s.value("syqon/use_amp", False, type=bool)))
            self.chk_rgb_perchan.setChecked(bool(s.value("syqon/rgb_perchan_mode", False, type=bool)))
            self.edt_cli_path.setText(str(s.value("syqon/standalone_cli_path", "")))
            saved = _syqon_norm_kind(str(s.value("syqon/model_kind", "nadir")))
            idx = self.cmb_model.findData(saved)
            if idx >= 0:
                self.cmb_model.setCurrentIndex(idx)
            saved_engine = str(s.value("syqon/engine_mode", "integrated")) if s else "integrated"
            idx = self.cmb_engine.findData(saved_engine)
            if idx >= 0:
                self.cmb_engine.setCurrentIndex(idx)
        else:
            self.spin_tile.setValue(512)
            self.spin_overlap.setValue(128)
            self.spin_shadow.setValue(2.8)
            self.chk_pad.setChecked(True)
            self.spin_pad.setValue(256)
            self.cmb_stars_extract.setCurrentText("unscreen")

        form.addRow("Tile size:", self.spin_tile)
        form.addRow("Overlap:",   self.spin_overlap)
        self.spin_shadow.hide()

        self.lbl_bginfo = QLabel(f"Target background (auto): {self._auto_bg:.3f}", self)
        form.addRow(self.lbl_bginfo)
        form.addRow(self.lbl_target_bg, self.spin_bg)
        form.addRow("", self.chk_show_bg)
        form.addRow("", self.chk_mtf)
        form.addRow(self.lbl_mtf_median, self.spin_mtf_median)
        form.addRow("", self.chk_make_stars)
        form.addRow("", self.chk_pad)
        form.addRow("Pad pixels:", self.spin_pad)
        form.addRow("", self.chk_amp)
        form.addRow("", self.chk_rgb_perchan)  
        form.addRow("Stars-only extraction:", self.cmb_stars_extract)

        self.chk_live_preview = QCheckBox("Live tile preview (slower)", self)
        self.chk_live_preview.setChecked(False)
        lay.addWidget(self.chk_live_preview)
        lay.addWidget(formw)

        btns = QHBoxLayout()
        self.btn_process = QPushButton("Process", self)
        self.btn_close   = QPushButton("Close", self)
        self.btn_process.clicked.connect(self._process)
        self.btn_close.clicked.connect(self.close)
        btns.addWidget(self.btn_process)
        btns.addStretch(1)
        btns.addWidget(self.btn_close)
        lay.addLayout(btns)

        # --- preset drag handle (grip) ---
        try:
            from setiastro.saspro.shortcuts import PresetDragHandle
            from setiastro.saspro.help_support import make_help_button
            try:
                _grip_icon = QIcon(syqon_path)
            except Exception:
                _grip_icon = QIcon()
            drag_row = QHBoxLayout()
            drag_row.setContentsMargins(0, 0, 0, 0)
            self.preset_drag_handle = PresetDragHandle(
                "remove_stars", self.get_preset, icon=_grip_icon,
                tooltip=self.tr(
                    "Drag to the canvas to create a Remove Stars (SyQon) shortcut "
                    "with these exact settings.\n"
                    "Drop directly on an image to apply them headlessly."
                ),
                parent=self,
            )
            drag_row.addWidget(self.preset_drag_handle)
            drag_row.addStretch(1)
            self.btn_help = make_help_button("remove_stars", self)
            drag_row.addWidget(self.btn_help)
            lay.addLayout(drag_row)
        except Exception:
            pass

        self.cmb_engine.currentIndexChanged.connect(self._on_engine_changed)
        self.edt_cli_path.textChanged.connect(self._refresh_state)
        self._toggle_bg(self.chk_show_bg.isChecked())
        self.cmb_model.currentTextChanged.connect(self._on_model_changed)
        self.chk_mtf.toggled.connect(lambda on: self.spin_mtf_median.setEnabled(bool(on)))
        self.spin_mtf_median.setEnabled(self.chk_mtf.isChecked())
        self.preview_win = None
        self.chk_live_preview.toggled.connect(self._toggle_live_preview_window)
        self._refresh_engine_ui()
        self._refresh_state()

    # -------- preset emit (grip) --------
    def get_preset(self) -> dict:
        """Mirror RemoveStarsPresetDialog.result_dict() syqon branch (the canonical schema).
        shadow_clip is intentionally omitted (dead in headless); use_amp/rgb_perchan are
        settings-backed and restored on construction, not carried by the shortcut."""
        return {
            "tool": "syqon",
            "engine_mode": self._engine_mode(),
            "cli_path": self.edt_cli_path.text().strip(),
            "model_kind": self._model_kind(),
            "tile_size": int(self.spin_tile.value()),
            "overlap": int(self.spin_overlap.value()),
            "use_mtf": bool(self.chk_mtf.isChecked()),
            "mtf_target_median": float(self.spin_mtf_median.value()),
            "make_stars": bool(self.chk_make_stars.isChecked()),
            "pad_edges": bool(self.chk_pad.isChecked()),
            "pad_pixels": int(self.spin_pad.value()),
            "stars_extract": str(self.cmb_stars_extract.currentText()),
        }

    # -------- preset seed (double-click open) --------
    def seed_from_preset(self, p: dict | None):
        p = dict(p or {})
        widgets = [
            self.cmb_engine, self.edt_cli_path, self.cmb_model,
            self.spin_tile, self.spin_overlap, self.chk_make_stars,
            self.chk_pad, self.spin_pad, self.cmb_stars_extract,
            self.chk_mtf, self.spin_mtf_median,
        ]
        for w in widgets:
            try: w.blockSignals(True)
            except Exception: pass
        try:
            em = str(p.get("engine_mode", "integrated")).strip().lower()
            i = self.cmb_engine.findData(
                "standalone_cli" if em in ("standalone_cli", "cli", "standalone") else "integrated"
            )
            if i >= 0:
                self.cmb_engine.setCurrentIndex(i)

            if p.get("cli_path"):
                self.edt_cli_path.setText(str(p.get("cli_path")))

            j = self.cmb_model.findData(_syqon_norm_kind(str(p.get("model_kind", "nadir"))))
            if j >= 0:
                self.cmb_model.setCurrentIndex(j)

            if "tile_size" in p:   self.spin_tile.setValue(int(p.get("tile_size")))
            if "overlap" in p:     self.spin_overlap.setValue(int(p.get("overlap")))
            if "make_stars" in p:  self.chk_make_stars.setChecked(bool(p.get("make_stars")))
            if "pad_edges" in p:   self.chk_pad.setChecked(bool(p.get("pad_edges")))
            if "pad_pixels" in p:  self.spin_pad.setValue(int(p.get("pad_pixels")))
            if p.get("stars_extract"):
                self.cmb_stars_extract.setCurrentText(str(p.get("stars_extract")))
            if "use_mtf" in p:     self.chk_mtf.setChecked(bool(p.get("use_mtf")))
            if "mtf_target_median" in p:
                self.spin_mtf_median.setValue(float(p.get("mtf_target_median")))
        finally:
            for w in widgets:
                try: w.blockSignals(False)
                except Exception: pass

        # Re-apply dependent enable/visibility the blocked signals skipped.
        for fn in (self._refresh_engine_ui, self._on_model_changed, self._refresh_state):
            try: fn()
            except Exception: pass
        try:
            self.spin_mtf_median.setEnabled(
                self.chk_mtf.isChecked() and self._engine_mode() != "standalone_cli"
            )
        except Exception:
            pass

    def _engine_mode(self) -> str:
        return str(self.cmb_engine.currentData() or "integrated")

    def _browse_cli_exe(self):
        import os
        s = getattr(self.main, "settings", None)
        start = str(s.value("syqon/standalone_cli_path", "")) if s else ""
        if not start:
            start = self.edt_cli_path.text().strip()
        filt = "Executable (*.exe)" if os.name == "nt" else "All Files (*)"
        path, _ = QFileDialog.getOpenFileName(self, "Select Starless Standalone Executable", start, filt)
        if path:
            self.edt_cli_path.setText(path)
            if s:
                s.setValue("syqon/standalone_cli_path", path)

    def _refresh_engine_ui(self):
        standalone = (self._engine_mode() == "standalone_cli")
        self.lbl_cli_path.setVisible(standalone)
        self.edt_cli_path.setVisible(standalone)
        self.btn_cli_browse.setVisible(standalone)
        self.model_box.setVisible(not standalone)
        self.cmb_model.setEnabled(not standalone)
        self.btn_buy.setEnabled(not standalone)
        self.btn_install.setEnabled(not standalone)
        self.btn_remove.setEnabled((not standalone) and self._have_model())
        if standalone:
            self.chk_live_preview.setChecked(False)
            self.chk_amp.setChecked(False)
        self.chk_live_preview.setEnabled(not standalone)
        self.chk_amp.setEnabled(not standalone)

        # Standalone CLI has no MTF/AMP/channel-mode/pad flags -- grey
        # these out so the user isn't shown options that silently do
        # nothing when this engine is selected.
        self.chk_mtf.setEnabled(not standalone)
        self.spin_mtf_median.setEnabled((not standalone) and self.chk_mtf.isChecked())
        self.lbl_mtf_median.setEnabled(not standalone)
        self.chk_rgb_perchan.setEnabled((not standalone) and self._model_kind() != "axiomv3")
        self.chk_pad.setEnabled(not standalone)
        self.spin_pad.setEnabled((not standalone) and self.chk_pad.isChecked())

        try:
            self.adjustSize()
        except Exception:
            pass

    def _on_engine_changed(self, *_):
        s = getattr(self.main, "settings", None)
        if s:
            s.setValue("syqon/engine_mode", self._engine_mode())
        self._refresh_engine_ui()
        self._refresh_state()

    def _toggle_live_preview_window(self, on: bool):
        on = bool(on)
        if not on:
            try:
                if self.preview_win is not None:
                    self.preview_win.hide()
            except Exception:
                pass
            return
        if self.preview_win is None:
            self.preview_win = SyQonLivePreviewWindow(
                parent=self, title="SyQon Live Preview", icon=self.windowIcon()
            )
            self.preview_win.finished.connect(lambda *_: self.chk_live_preview.setChecked(False))
        self.preview_win.show()
        self.preview_win.raise_()
        self.preview_win.activateWindow()

    def _model_kind(self) -> str:
        return _syqon_norm_kind(self.cmb_model.currentData() or "nadir")

    def _on_model_changed(self, *_):
        s = getattr(self.main, "settings", None) or QSettings()
        s.setValue("syqon/model_kind", self._model_kind())
        # AxiomV3 doesn't support per-channel mode — grey it out so users aren't confused
        is_v3 = (self._model_kind() == "axiomv3")
        if is_v3:
            self.chk_rgb_perchan.setChecked(False)
        self.chk_rgb_perchan.setEnabled(not is_v3)
        self._refresh_state()

    def _on_worker_preview(self, qimg):
        try:
            if not self.chk_live_preview.isChecked() or qimg is None:
                return
            if self.preview_win is None:
                self._toggle_live_preview_window(True)
            if self.preview_win is not None and self.preview_win.isVisible():
                self.preview_win.set_frame(qimg)
        except Exception:
            pass

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        try:
            pm = self.lbl_preview.pixmap()
            if pm and not pm.isNull():
                self.lbl_preview.setPixmap(pm.scaled(
                    self.lbl_preview.size(),
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation
                ))
        except Exception:
            pass

    def _set_busy(self, busy: bool):
        self.btn_process.setEnabled(not busy)
        self.btn_close.setEnabled(not busy)
        self.btn_buy.setEnabled(not busy)
        self.btn_install.setEnabled(not busy)
        self.btn_remove.setEnabled((not busy) and self._have_model())
        self.cmb_engine.setEnabled(not busy)
        self.btn_cli_browse.setEnabled(not busy)
        self.pbar.setVisible(busy)
        self.chk_live_preview.setEnabled((not busy) and self._engine_mode() != "standalone_cli")
        if busy:
            self.pbar.setRange(0, 100)
            self.pbar.setValue(0)

    def _on_worker_progress(self, pct: int, stage: str):
        self.pbar.setValue(int(pct))
        if stage:
            self.lbl.setText(stage)

    def _on_worker_finished(self, starless_s, stars_s, info: dict, err: str):
        import json

        try:
            info = info or {}
            safe_info = {}
            for k, v in dict(info).items():
                try:
                    json.dumps(v)
                    safe_info[k] = v
                except Exception:
                    safe_info[k] = repr(v)
            print("\n[SyQon] Engine info:")
            print(json.dumps(safe_info, indent=2, sort_keys=True))
        except Exception as e:
            print(f"[SyQon] Failed to print info: {type(e).__name__}: {e}")

        if err:
            self._set_busy(False)
            QMessageBox.critical(self, "SyQon", err)
            self._refresh_state()
            return

        try:
            if hasattr(self.main, "_log"):
                self.main._log(
                    f"SyQon backend: device={info.get('device')} "
                    f"torch={info.get('torch_version')} file={info.get('torch_file')}"
                )
        except Exception:
            pass

        try:
            if self.preview_win is not None:
                self.preview_win.hide()
        except Exception:
            pass

        pad_edges         = bool(self.chk_pad.isChecked())
        pad_pixels        = int(self.spin_pad.value())
        stars_extract_mode = str(self.cmb_stars_extract.currentText())

        scale_factor  = self._scale_factor
        H0, W0        = self._H0, self._W0
        orig_was_mono = self._orig_was_mono
        target_bg     = self._target_bg

        if starless_s.ndim == 2:
            starless_s = np.stack([starless_s]*3, axis=-1)

        mtf_wrap = self._mtf_params
        do_mtf   = bool(getattr(self, "_do_mtf", True))

        # AxiomV3 has normalisation baked in — MTF inversion still valid if we applied it
        if do_mtf and mtf_wrap is not None:
            bp3        = np.asarray(mtf_wrap["bp3"], dtype=np.float32)
            mtf_params = mtf_wrap["mtf"]
            starless_bp  = _invert_mtf_unlinked_rgb(starless_s, mtf_params)
            starless_lin = _add_bp_per_channel(starless_bp, bp3)
        else:
            starless_lin = starless_s

        if scale_factor > 1.01:
            starless_lin = (starless_lin * scale_factor).astype(np.float32, copy=False)

        if pad_edges and pad_pixels > 0:
            starless_lin = _crop_unpad(starless_lin, pad_pixels, H0, W0)

        orig = np.asarray(self.doc.image).astype(np.float32, copy=False)
        if orig.ndim == 2:
            original_rgb = np.stack([orig]*3, axis=-1)
        elif orig.ndim == 3 and orig.shape[2] == 1:
            original_rgb = np.repeat(orig, 3, axis=2)
        else:
            original_rgb = orig[..., :3] if orig.ndim == 3 else orig

        starless_rgb = starless_lin.astype(np.float32, copy=False)

        if self.chk_make_stars.isChecked():
            stars_only = _extract_stars_only(original_rgb, starless_rgb, mode=stars_extract_mode)
            m3 = _active_mask3_from_doc(self.doc, stars_only.shape[1], stars_only.shape[0])
            if m3 is not None:
                stars_only *= m3
            stars_to_push = stars_only.mean(axis=2).astype(np.float32, copy=False) if orig_was_mono else stars_only
            _push_as_new_doc(self.main, self.doc, stars_to_push, title_suffix="_stars", source="Stars-Only (SyQon)")

        final_starless  = _mask_blend_with_doc_mask(self.doc, starless_rgb, original_rgb)
        final_to_apply  = final_starless.mean(axis=2).astype(np.float32, copy=False) if orig_was_mono else final_starless
        final_to_apply  = np.clip(final_to_apply, 0.0, 1.0).astype(np.float32, copy=False)

        model_kind_used = self._model_kind()
        meta = {
            "step_name": "Stars Removed",
            "bit_depth": "32-bit floating point",
            "is_mono":   bool(orig_was_mono),
            "replay_last": {
                "op": "remove_stars",
                "params": {
                    "engine":      "SyQon",
                    "tile_size":   int(self.spin_tile.value()),
                    "overlap":     int(self.spin_overlap.value()),
                    "shadow_clip": float(self.spin_shadow.value()),
                    "target_bg":   float(target_bg),
                    "make_stars":  bool(self.chk_make_stars.isChecked()),
                    "pad_edges":   bool(pad_edges),
                    "pad_pixels":  int(pad_pixels),
                    "channel_mode": "rgb+perchan" if (bool(self.chk_rgb_perchan.isChecked()) and model_kind_used != "axiomv3") else "rgb",
                    "stars_extract": str(stars_extract_mode),
                    "model_path":  str(self._model_dst_path()),
                    "model_kind":  model_kind_used,
                    "label":       "Remove Stars (SyQon)",
                    "use_mtf":     bool(do_mtf),
                    "use_amp":     bool(self.chk_amp.isChecked()),
                }
            }
        }

        meta["command_id"] = "remove_stars"
        meta["preset"] = self.get_preset()

        self.doc.apply_edit(final_to_apply, metadata=meta, step_name="Stars Removed")
        if hasattr(self.main, "_log"):
            self.main._log("Stars Removed (SyQon)")

        try:
            self.main._last_headless_command = {
                "command_id": "remove_stars",
                "preset": {
                    "tool":        "syqon",
                    "tile_size":   int(self.spin_tile.value()),
                    "overlap":     int(self.spin_overlap.value()),
                    "shadow_clip": float(self.spin_shadow.value()),
                    "target_bg":   float(target_bg),
                    "make_stars":  bool(self.chk_make_stars.isChecked()),
                    "model_path":  str(self._model_dst_path()),
                    "model_kind":  model_kind_used,
                    "pad_edges":   bool(pad_edges),
                    "pad_pixels":  int(pad_pixels),
                    "stars_extract": str(stars_extract_mode),
                    "use_mtf":     bool(do_mtf),
                    "channel_mode": "rgb+perchan" if (bool(self.chk_rgb_perchan.isChecked()) and model_kind_used != "axiomv3") else "rgb",
                },
            }
        except Exception:
            pass

        self._set_busy(False)
        self.lbl.setText("Complete!")
        # Only close if running as a real dialog, not embedded in SyQon Tools hub
        if self.windowFlags() & Qt.WindowType.Dialog:
            self.close()

    def _model_dst_path(self) -> Path:
        return _syqon_model_path(self.data_dir, self._model_kind())

    def _have_model(self) -> bool:
        try:
            p = self._model_dst_path()
            return p.exists() and p.is_file()
        except Exception as e:
            print(f"[SyQon _have_model] exception: {e}")
            return False

    def _toggle_bg(self, on: bool):
        on = bool(on)
        self.lbl_bginfo.setVisible(on)
        self.lbl_target_bg.setVisible(on)
        self.spin_bg.setVisible(on)

    def _refresh_state(self):
        standalone = (self._engine_mode() == "standalone_cli")
    
        if standalone:
            exe_path = self.edt_cli_path.text().strip()
            # On Mac, .app bundles are directories not files -- accept
            # both files (Windows .exe / Linux binary) and directories
            # (.app bundles on macOS).
            exe_exists = bool(exe_path) and (
                os.path.isfile(exe_path) or os.path.isdir(exe_path)
            )
            if exe_exists:
                self.lbl.setText("Ready (Starless Standalone CLI selected).")
                self.btn_process.setEnabled(True)
            else:
                self.lbl.setText(
                    "Starless Standalone CLI mode is selected.\n\n"
                    "Please choose the standalone Starless executable with the Browse button."
                )
                self.btn_process.setEnabled(True)
            return
        self.btn_process.setEnabled(True)
    
        mk    = self._model_kind()
        dst   = self._model_dst_path()
        label = _SYQON_MODEL_LABELS.get(mk, mk)
    
        if self._have_model():
            self.lbl_model_path.setText(f"Installed model path:\n{str(dst)}")
    
            # Show Signal status for AxiomV2.2 only
            if mk == "axiomv2.2":
                sig_ok = _syqon_have_signal(self.data_dir)
                sig_status = "Signal 1.0: installed ✓" if sig_ok else "Signal 1.0: not installed (optional but recommended)"
                self.lbl.setText(f"Ready ({label} model installed).\n{sig_status}")
            else:
                self.lbl.setText(f"Ready ({label} model installed).")
    
            self.btn_process.setEnabled(True)
            self.btn_remove.setEnabled(True)
        else:
            self.lbl_model_path.setText("Model not installed.")
            self.lbl.setText(
                f"{label} model is not installed.\n\n"
                "1) Click \"Get Starless Model Here…\" to purchase/download it.\n"
                "2) Then click \"Install Downloaded Model…\" and select the downloaded file."
            )
            self.btn_process.setEnabled(True)
            self.btn_remove.setEnabled(False)
    
        self.btn_buy.setEnabled(True)
        self.btn_install.setEnabled(True)
        self.btn_process.setEnabled(True)


    def _open_buy_page(self):
        mk  = self._model_kind()
        url = _syqon_buy_url_for(mk)
        if not url:
            QMessageBox.information(
                self, "SyQon",
                "SyQon purchase URL is not configured yet.\n\n"
                "Please obtain the model from SyQon directly, then use:\n"
                "\"Install Downloaded Model…\" and select the appropriate model file."
            )
            return
        QDesktopServices.openUrl(QUrl(url))


    def _install_model(self):
        import shutil
        mk    = self._model_kind()
        label = _SYQON_MODEL_LABELS.get(mk, mk)
    
        src_path, _ = QFileDialog.getOpenFileName(
            self, f"Select SyQon {label} Model File", "",
            "Model Files (*.pt *.pth *.bin);;All Files (*)"
        )
        if not src_path:
            return
    
        src = Path(src_path)
        if not src.exists():
            QMessageBox.warning(self, "SyQon", "Selected file does not exist.")
            return
    
        dst = _syqon_model_path(self.data_dir, mk)
        dst.parent.mkdir(parents=True, exist_ok=True)
    
        self.pbar.setVisible(True)
        self.pbar.setRange(0, 0)
        self.lbl.setText(f"Installing {label} model…")
        QApplication.processEvents()
    
        try:
            shutil.copy2(str(src), str(dst))
        except Exception as e:
            self.pbar.setVisible(False)
            QMessageBox.critical(self, "SyQon", f"Failed to install model:\n{e}")
            self._refresh_state()
            return
    
        self.pbar.setVisible(False)
    
        s = getattr(self.main, "settings", None)
        if s:
            s.setValue("syqon/model_kind", mk)
            s.setValue(f"syqon/model_src_path/{mk}", str(src))
            s.setValue(f"syqon/model_installed_path/{mk}", str(dst))
    
        # AxiomV2.2: offer Signal 1.0 install immediately after Axiom install
        if mk == "axiomv2.2":
            reply = QMessageBox.question(
                self,
                "Install Signal 1.0?",
                "Axiom V2.2 works with Signal 1.0 for star-core inpainting.\n\n"
                "Would you like to install the Signal 1.0 model now?\n"
                "(You can install it later via Install Downloaded Model…)",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes,
            )
            if reply == QMessageBox.StandardButton.Yes:
                sig_src_path, _ = QFileDialog.getOpenFileName(
                    self, "Select Signal 1.0 Model File (signal_v1.pt)", "",
                    "Model Files (*.pt *.pth *.bin);;All Files (*)"
                )
                if sig_src_path:
                    sig_src = Path(sig_src_path)
                    sig_dst = _syqon_signal_path(self.data_dir)
                    self.pbar.setVisible(True)
                    self.pbar.setRange(0, 0)
                    self.lbl.setText("Installing Signal 1.0 model…")
                    QApplication.processEvents()
                    try:
                        shutil.copy2(str(sig_src), str(sig_dst))
                        self.lbl.setText("Signal 1.0 model installed.")
                        if s:
                            s.setValue("syqon/signal_installed_path", str(sig_dst))
                    except Exception as e:
                        QMessageBox.warning(self, "SyQon", f"Signal 1.0 install failed:\n{e}")
                    self.pbar.setVisible(False)
    
        self.lbl.setText(f"{label} model installed.")
        self._refresh_state()


    def _remove_model(self):
        dst = self._model_dst_path()
        if not dst.exists():
            self._refresh_state()
            return

        reply = QMessageBox.question(
            self, "Remove Model", "Remove the installed SyQon model from disk?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        try:
            dst.unlink(missing_ok=True)
        except Exception:
            try:
                if dst.exists():
                    os.remove(str(dst))
            except Exception:
                pass

        self._refresh_state()

    def _process(self):
        import numpy as np

        engine_mode = self._engine_mode()

        s = getattr(self.main, "settings", None) or QSettings()
        s.setValue("syqon/engine_mode",         engine_mode)
        s.setValue("syqon/tile_size",            int(self.spin_tile.value()))
        s.setValue("syqon/overlap",              int(self.spin_overlap.value()))
        s.setValue("syqon/shadow_clip",          float(self.spin_shadow.value()))
        s.setValue("syqon/make_stars",           bool(self.chk_make_stars.isChecked()))
        s.setValue("syqon/pad_edges",            bool(self.chk_pad.isChecked()))
        s.setValue("syqon/pad_pixels",           int(self.spin_pad.value()))
        s.setValue("syqon/stars_extract",        str(self.cmb_stars_extract.currentText()))
        s.setValue("syqon/use_mtf",              bool(self.chk_mtf.isChecked()))
        s.setValue("syqon/mtf_target_median",    float(self.spin_mtf_median.value()))
        s.setValue("syqon/use_amp",              bool(self.chk_amp.isChecked()))
        s.setValue("syqon/rgb_perchan_mode",     bool(self.chk_rgb_perchan.isChecked()))
        s.setValue("syqon/model_kind",           self._model_kind())
        s.setValue("syqon/standalone_cli_path",  self.edt_cli_path.text().strip())

        tile    = int(self.spin_tile.value())
        overlap = int(self.spin_overlap.value())
        if overlap >= tile:
            QMessageBox.warning(self, "SyQon", "Overlap must be smaller than tile size.")
            return

        pad_edges  = bool(self.chk_pad.isChecked())
        pad_pixels = int(self.spin_pad.value())
        target_bg  = float(self._auto_bg)
        if self.chk_show_bg.isChecked():
            target_bg = float(self.spin_bg.value())

        src = np.asarray(self.doc.image).astype(np.float32, copy=False)
        orig_was_mono = (src.ndim == 2) or (src.ndim == 3 and src.shape[2] == 1)
        x = np.nan_to_num(src, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32, copy=False)

        scale_factor = float(np.max(x)) if x.size else 1.0
        if scale_factor > 1.01:
            x01 = np.clip(x / scale_factor, 0.0, 1.0)
        else:
            x01 = np.clip(x, 0.0, 1.0)

        if x01.ndim == 2:
            xrgb = np.stack([x01] * 3, axis=-1)
        elif x01.ndim == 3 and x01.shape[2] == 1:
            xrgb = np.repeat(x01, 3, axis=2)
        else:
            xrgb = x01[..., :3]

        H0, W0 = xrgb.shape[:2]
        if pad_edges and pad_pixels > 0:
            xrgb = _pad_reflect(xrgb, pad_pixels)

        self._scale_factor = scale_factor
        self._H0, self._W0 = H0, W0
        self._orig_was_mono = orig_was_mono
        self._target_bg     = target_bg

        try:
            if self.proc_thr is not None and self.proc_thr.isRunning():
                self.proc_thr.cancel()
                self.proc_thr.wait(250)
        except Exception:
            pass

        self._set_busy(True)
        self.lbl.setText("Processing…")

        # --- Standalone CLI (SyQonStarless.exe / .app -- real C++ build) ---
        if engine_mode == "standalone_cli":
            exe_path = self.edt_cli_path.text().strip()
            # Resolve macOS .app bundles to the actual binary inside them
            if exe_path.endswith(".app") and os.path.isdir(exe_path):
                app_name = os.path.splitext(os.path.basename(exe_path))[0]
                exe_path = os.path.join(exe_path, "Contents", "MacOS", app_name)
            if not exe_path or not (os.path.isfile(exe_path) or os.path.isdir(exe_path)):
                self._set_busy(False)
                QMessageBox.warning(self, "SyQon", "Please select a valid Starless Standalone executable.")
                return
 
            # The real C++ CLI has no MTF/AMP/channel-mode/pad flags --
            # those only existed in the old Python starless_cli. Whatever
            # stretch/processing choices apply now happen either inside
            # the model itself or via the GUI window the user interacts
            # with (we always launch with --gui per Siril-parity), so
            # SASpro's own MTF pre/post-processing is bypassed for this
            # engine path.
            self._do_mtf      = False
            self._mtf_params  = None
 
            # Device string: map SASpro's "use CPU" checkbox (if present)
            # to the C++ exe's -d flag; default to Auto like Siril's
            # sequence-mode call does.
            device = "Auto"
 
            self.proc_thr = _SyQonStandaloneCLIThread(
                input_rgb01=xrgb,
                exe_path=exe_path,
                tile=tile,
                overlap=overlap,
                device=device,
                parent=None,   # not parented into the widget tree: a dialog
                               # teardown must never reach a running QThread
                               # (deleteChildren -> 'destroyed while running' -> abort)
            )
            self.proc_thr.progress.connect(self._on_worker_progress)
            self.proc_thr.finished.connect(self._on_worker_finished)
            # delete the thread only AFTER run() has fully unwound
            self.proc_thr.finished.connect(self.proc_thr.deleteLater)
            self.proc_thr.start()
            return


        # --- Integrated model ---
        if not self._have_model():
            self._set_busy(False)
            QMessageBox.warning(self, "SyQon", "SyQon model is not installed. Install it first.")
            return

        ckpt_path  = str(self._model_dst_path())
        model_kind = self._model_kind()
        do_mtf     = bool(self.chk_mtf.isChecked())
        self._do_mtf = do_mtf

        if do_mtf:
            mtf_target = float(self.spin_mtf_median.value())
            bp3        = _bp_min_per_channel(xrgb)
            xrgb_bp    = _subtract_bp_per_channel(xrgb, bp3)
            mtf_params = _mtf_params_unlinked_noclip(xrgb_bp, targetbg=mtf_target)
            x_for_net  = _apply_mtf_unlinked_rgb(xrgb_bp, mtf_params)
            self._mtf_params = {"bp3": bp3, "mtf": mtf_params}
        else:
            x_for_net        = xrgb
            self._mtf_params = None

        live_preview = bool(self.chk_live_preview.isChecked())
        preview_src  = x_for_net if do_mtf else xrgb

        # AxiomV3: per-channel mode not supported; force rgb
        is_v3 = (model_kind == "axiomv3")
        channel_mode = "rgb"
        if not is_v3 and self.chk_rgb_perchan.isChecked():
            channel_mode = "rgb+perchan"

        # Signal 1.0 path — only used for AxiomV2.2
        signal_ckpt_path = ""
        if model_kind == "axiomv2.2":
            sig_path = _syqon_signal_path(self.data_dir)
            if sig_path.exists():
                signal_ckpt_path = str(sig_path)

        self.proc_thr = _SyQonProcessThread(
            x_for_net=x_for_net,
            ckpt_path=ckpt_path,
            tile=tile,
            overlap=overlap,
            target_bg=float(target_bg),
            shadow_clip=float(self.spin_shadow.value()),
            model_kind=model_kind,
            use_amp=bool(self.chk_amp.isChecked()),
            amp_dtype="fp16",
            channel_mode=channel_mode,
            signal_ckpt_path=signal_ckpt_path,
            signal_tile=1024,
            signal_overlap=64,
            signal_diff_threshold=0.020,
            live_preview=live_preview,
            preview_src_rgb01=(preview_src if live_preview else None),
            preview_max_dim=900,
            preview_emit_ms=120,
            parent=None,   # see standalone: keep the worker out of the widget tree
        )
        self.proc_thr.progress.connect(self._on_worker_progress)
        self.proc_thr.preview.connect(self._on_worker_preview)
        self.proc_thr.finished.connect(self._on_worker_finished)
        # delete the thread only AFTER run() has fully unwound
        self.proc_thr.finished.connect(self.proc_thr.deleteLater)
        self.proc_thr.start()

    def closeEvent(self, ev):
        try:
            if self.proc_thr is not None and self.proc_thr.isRunning():
                self.proc_thr.cancel()
                self.proc_thr.wait(500)
        except Exception:
            pass
        try:
            if self.preview_win is not None:
                self.preview_win.hide()
        except Exception:
            pass
        super().closeEvent(ev)


def open_syqon_starless_with_preset(main, doc, preset: dict | None = None):
    if not _ENABLE_SYQON:
        QMessageBox.information(
            main, "SyQon",
            "SyQon is disabled until permission/licensing is confirmed."
        )
        return None
    dlg = SyQonStarlessDialog(main, doc, parent=main, icon=QIcon(starnet_path))
    dlg.setModal(False)
    # No on-show reset in this dialog; __init__ populates from settings, seed overrides.
    if preset:
        try:
            dlg.seed_from_preset(preset)
        except Exception:
            pass
    try:
        main._syqon_starless_dialog = dlg   # retain against GC (non-modal .show())
    except Exception:
        pass
    dlg.show(); dlg.raise_(); dlg.activateWindow()
    return dlg


def _run_syqon(main, doc, icon_path=starnet_path):
    open_syqon_starless_with_preset(main, doc, preset=None)
    
import os, time, tempfile, subprocess
from pathlib import Path
import numpy as np
from astropy.io import fits


class _SyQonStandaloneCLIThread(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(object, object, dict, str)

    def __init__(
        self,
        input_rgb01: np.ndarray,
        exe_path: str,
        tile: int,
        overlap: int,
        device: str = "Auto",
        parent=None,
    ):
        super().__init__(parent)
        self.input_rgb01 = np.asarray(input_rgb01, dtype=np.float32)
        self.exe_path    = str(exe_path)
        self.tile        = int(tile)
        self.overlap     = int(overlap)
        self.device      = str(device or "Auto")
        self._cancel     = False
        self._tmp_in     = None
        self._tmp_out    = None
        self._tmp_mask   = None
        self._p          = None

    def cancel(self):
        self._cancel = True
        try:
            if self._p is not None and self._p.poll() is None:
                self._p.terminate()
        except Exception:
            pass

    def _emit(self, pct: int, stage: str):
        self.progress.emit(int(np.clip(pct, 0, 100)), str(stage or ""))

    def run(self):
        import threading, re

        info = {
            "engine":   "syqon_standalone_cli",
            "exe_path": self.exe_path,
            "tile":     self.tile,
            "overlap":  self.overlap,
            "device":   self.device,
        }

        stdout_lines = []
        stderr_lines = []

        # Parse the same progress lines the C++ CLI emits to stdout.
        # In --gui mode the CLI also emits these since the underlying
        # InferenceEngine still writes to stdout even when the Qt window
        # is open -- so we get real-time updates for free.
        re_pct   = re.compile(r'\[CLI\]\s+Progress:\s+(\d+)%', re.IGNORECASE)
        re_stage = re.compile(r'\[(?:CLI|InferenceEngine|ONNX)\]\s+(?:Status:\s*)?(.+)', re.IGNORECASE)

        def _reader(pipe, label, sink):
            try:
                for raw_line in pipe:
                    line = raw_line.rstrip("\r\n")
                    sink.append(line)
                    print(f"[Starless {label}] {line}", flush=True)
                    if label != "stdout":
                        continue
                    # Parse percentage
                    m = re_pct.search(line)
                    if m:
                        pct = int(m.group(1))
                        # Don't emit 100 yet -- wait until file exists
                        self._emit(min(pct, 99), "SyQon Starless processing…")
                        continue
                    # Parse stage label for status text
                    m = re_stage.search(line)
                    if m:
                        stage = m.group(1).strip()
                        # Filter out noisy low-level lines
                        if not any(x in stage for x in (
                            "Channel", "Stretch loop", "Auto-configured",
                            "Model loaded", "Loaded embedded", "DirectML",
                            "Reading TIFF", "bits:", "samples:"
                        )):
                            self._emit(0, stage)
            except Exception as e:
                print(f"[Starless {label} reader] {type(e).__name__}: {e}", flush=True)

        try:
            if self._cancel:
                raise RuntimeError("Cancelled")

            exe = Path(self.exe_path)
            if not exe.exists():
                raise RuntimeError(f"Starless executable not found:\n{self.exe_path}")

            tag    = f"syqon_{os.getpid()}_{int(time.time()*1000)}"
            tmpdir = Path(tempfile.gettempdir()) / "SASpro_SyQon_StarlessCLI"
            tmpdir.mkdir(parents=True, exist_ok=True)

            in_base        = f"{tag}_in"
            self._tmp_in   = str(tmpdir / f"{in_base}.tif")
            self._tmp_out  = str(tmpdir / f"starless_{in_base}.tif")
            self._tmp_mask = str(tmpdir / f"starmask_{in_base}.tif")

            self._emit(2, "Writing temp image for Starless…")
            save_image(
                self.input_rgb01,
                self._tmp_in,
                original_format="tif",
                bit_depth="32-bit floating point",
                original_header=None,
                is_mono=False,
                image_meta=None,
                file_meta=None,
            )

            if self._cancel:
                raise RuntimeError("Cancelled")

            cmd = [
                str(exe),
                "-i", self._tmp_in,
                "-o", self._tmp_out,
                "-d", self.device,
                "-t", "512",    # model is static [1,3,512,512]
                "-v", str(self.overlap),
                "-c", "seti",
                "--gui",        # open the SyQonStarless window so the
                                # user can adjust stretch/device settings
            ]
            info["command"] = cmd

            print("\n[Starless CLI launch]", flush=True)
            print("CMD:", " ".join(cmd), flush=True)

            self._emit(5, "Opening SyQon Starless…")

            self._p = subprocess.Popen(
                cmd,
                cwd=str(exe.parent),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.DEVNULL,
                text=True,
                bufsize=1,
                universal_newlines=True,
            )

            # Reader threads drain stdout/stderr in real-time so the pipe
            # buffer never fills up and deadlocks (the communicate() 
            # approach blocked until exit, causing the earlier hang).
            t_out = threading.Thread(
                target=_reader,
                args=(self._p.stdout, "stdout", stdout_lines),
                daemon=True
            )
            t_err = threading.Thread(
                target=_reader,
                args=(self._p.stderr, "stderr", stderr_lines),
                daemon=True
            )
            t_out.start()
            t_err.start()

            # Block until the user closes the SyQonStarless window.
            self._p.wait()
            t_out.join(timeout=2.0)
            t_err.join(timeout=2.0)

            if self._cancel:
                raise RuntimeError("Cancelled")

            info["stdout_tail"] = "\n".join(stdout_lines[-200:])
            info["stderr_tail"] = "\n".join(stderr_lines[-200:])
            info["returncode"]  = self._p.returncode

            if self._p.returncode != 0 or not os.path.exists(self._tmp_out):
                raise RuntimeError(
                    "SyQon Starless closed without producing output "
                    "(cancelled, or processing was not completed)."
                )

            self._emit(95, "Loading Starless output…")
            starless_rgb01, _, _, _ = load_image(self._tmp_out)
            if starless_rgb01 is None:
                raise RuntimeError("Standalone CLI output could not be loaded.")

            starless_rgb01 = np.asarray(starless_rgb01, dtype=np.float32)
            if starless_rgb01.ndim == 2:
                starless_rgb01 = np.stack([starless_rgb01] * 3, axis=-1)
            elif starless_rgb01.ndim == 3 and starless_rgb01.shape[2] == 1:
                starless_rgb01 = np.repeat(starless_rgb01, 3, axis=2)
            else:
                starless_rgb01 = starless_rgb01[..., :3]
            starless_rgb01 = np.clip(starless_rgb01, 0.0, 1.0).astype(np.float32, copy=False)

            # Starmask written automatically by the app next to the output.
            stars_rgb01 = None
            try:
                if os.path.exists(self._tmp_mask):
                    s_img, _, _, _ = load_image(self._tmp_mask)
                    if s_img is not None:
                        s_img = np.asarray(s_img, dtype=np.float32)
                        if s_img.ndim == 2:
                            s_img = np.stack([s_img] * 3, axis=-1)
                        elif s_img.ndim == 3 and s_img.shape[2] == 1:
                            s_img = np.repeat(s_img, 3, axis=2)
                        stars_rgb01 = np.clip(
                            s_img[..., :3], 0.0, 1.0
                        ).astype(np.float32, copy=False)
            except Exception:
                pass

            self._emit(100, "Standalone CLI: complete")
            self.finished.emit(starless_rgb01, stars_rgb01, info, "")

        except Exception as e:
            import traceback
            info["traceback"] = traceback.format_exc()
            self.finished.emit(None, None, info, str(e))

        finally:
            try:
                if self._p is not None and self._p.poll() is None:
                    self._p.terminate()
            except Exception:
                pass
            for p in (self._tmp_in, self._tmp_out, self._tmp_mask):
                try:
                    if p and os.path.exists(p):
                        os.remove(p)
                except Exception:
                    pass

def _detect_starnet_version(exe: str) -> str:
    """
    Returns 'v25' for StarNet2 2.5+ (new CLI), 'v2' for classic StarNet++ v2.
    Detection is based on executable name first, then --version output as fallback.
    """
    import subprocess
    import os

    exe_name = os.path.basename(exe).lower()

    # New 2.5+ CLI uses 'starnet2' as the binary name
    if "starnet2" in exe_name and "++" not in exe_name:
        return "v25"

    # Classic v2 uses 'starnet++' or 'starnetv2' etc.
    if "++" in exe_name or "starnetv2" in exe_name:
        return "v2"

    # Ambiguous name — probe --version output
    try:
        r = subprocess.run(
            [exe, "--version"],
            capture_output=True, text=True, timeout=8
        )
        out = (r.stdout or "") + (r.stderr or "")
        # New version reports "StarNet2 v2.5.x"
        if "2.5" in out or "onnx" in out.lower() or "-i " in out or "--input" in out:
            return "v25"
    except Exception:
        pass

    return "v2"

def _run_starnet(main, doc, icon_path=None):
    import os
    import platform
    import numpy as np
    import re
    from PyQt6.QtWidgets import QFileDialog, QMessageBox

    # --- Resolve StarNet exe, persist in settings
    exe = _get_setting_any(getattr(main, "settings", None),
                           ("starnet/exe_path", "paths/starnet"), "")
    if not exe or not os.path.exists(exe):
        exe_path, _ = QFileDialog.getOpenFileName(
            main, "Select StarNet Executable", "", "Executable Files (*)"
        )
        if not exe_path:
            return
        exe = exe_path
        s = getattr(main, "settings", None)
        if s:
            s.setValue("starnet/exe_path", exe)
            s.setValue("paths/starnet", exe)

    if platform.system() in ("Darwin", "Linux"):
        _ensure_exec_bit(exe)

    sysname = platform.system()
    if sysname not in ("Windows", "Darwin", "Linux"):
        QMessageBox.critical(
            main, "Unsupported OS",
            f"The current operating system '{sysname}' is not supported."
        )
        return

    # --- Ask linearity (SASv2 behavior)
    reply = QMessageBox.question(
        main, "Image Linearity", "Is the current image linear?",
        QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        QMessageBox.StandardButton.No
    )
    is_linear = (reply == QMessageBox.StandardButton.Yes)
    did_stretch = is_linear

    # stash params for replay-last
    try:
        main._last_remove_stars_params = {
            "engine": "StarNet",
            "is_linear": bool(is_linear),
            "did_stretch": bool(did_stretch),
            "label": "Remove Stars (StarNet)",
        }
    except Exception:
        pass

    # 🔁 Record headless command for Replay Last
    try:
        main._last_headless_command = {
            "command_id": "remove_stars",
            "preset": {
                "tool": "starnet",
                "linear": bool(is_linear),
            },
        }
        if hasattr(main, "_log"):
            main._log(
                f"[Replay] Recorded remove_stars (StarNet, linear="
                f"{'yes' if is_linear else 'no'})"
            )
    except Exception:
        pass

    # --- Ensure float32 and sane values (no forced RGB expansion yet)
    src = np.asarray(doc.image)
    if src.ndim == 3 and src.shape[2] == 1:
        processing_image = src[..., 0]
    else:
        processing_image = src

    processing_image = np.nan_to_num(
        processing_image.astype(np.float32, copy=False),
        nan=0.0, posinf=0.0, neginf=0.0
    )

    # --- Scale normalization if >1.0
    scale_factor = float(np.max(processing_image)) if processing_image.size else 1.0
    if scale_factor > 1.0:
        processing_norm = processing_image / scale_factor
    else:
        processing_norm = processing_image

    # --- Build input/output paths in a real temp directory (not the StarNet folder,
    #     which may be read-only on some installs, especially StarNet2 2.5+)
    starnet_dir = os.path.dirname(exe) or os.getcwd()
    _starnet_tmp_dir = tempfile.mkdtemp(prefix="SASpro_StarNet_")
    input_image_path = os.path.join(_starnet_tmp_dir, "imagetoremovestars.tif")
    output_image_path = os.path.join(_starnet_tmp_dir, "starless.tif")

    # --- Prepare input for StarNet 
    img_for_starnet = processing_norm
    if is_linear:
        mtf_params = _mtf_params_unlinked(processing_norm, shadows_clipping=-2.8, targetbg=0.25)
        img_for_starnet = _apply_mtf_unlinked_rgb(processing_norm, mtf_params)

        # 🔐 Stash EXACT params for inverse step later
        try:
            setattr(main, "_starnet_stat_meta", {
                "scheme": "stretch_mtf",
                "s": np.asarray(mtf_params["s"], dtype=np.float32),
                "m": np.asarray(mtf_params["m"], dtype=np.float32),
                "h": np.asarray(mtf_params["h"], dtype=np.float32),
                "scale": float(scale_factor),
            })
        except Exception:
            pass
    else:
        # non-linear: do not try to invert any pre-stretch later
        try:
            if hasattr(main, "_starnet_stat_meta"):
                delattr(main, "_starnet_stat_meta")
        except Exception:
            pass

    # --- Write TIFF for StarNet (16-bit)
    try:
        save_image(
            img_for_starnet, input_image_path,
            original_format="tif", bit_depth="16-bit",
            original_header=None, is_mono=False, image_meta=None, file_meta=None
        )
    except Exception as e:
        QMessageBox.critical(main, "StarNet", f"Failed to write input TIFF:\n{e}")
        return

    # --- Build command
    exe_name = os.path.basename(exe).lower()
    # --- Detect version and build command ---
    starnet_version = _detect_starnet_version(exe)

    if sysname == "Windows":
        if starnet_version == "v25":
            command = [exe, "-i", input_image_path, "-o", output_image_path, "-s", "256"]
        else:
            command = [exe, input_image_path, output_image_path, "256"]

    elif sysname == "Linux":
        if starnet_version == "v25":
            command = [exe, "-i", input_image_path, "-o", output_image_path, "-s", "256"]
        else:
            command = [exe, input_image_path, output_image_path, "256"]

    else:  # macOS
        if starnet_version == "v25":
            command = [exe, "-i", input_image_path, "-o", output_image_path, "-s", "256"]
        elif "starnet2" in exe_name:
            # old macOS starnet2 variant used --input/--output
            command = [exe, "--input", input_image_path, "--output", output_image_path]
        else:
            command = [exe, input_image_path, output_image_path]

    # --- Progress dialog + worker
    dlg = _ProcDialog(main, title="StarNet Progress")
    dlg.reset_progress("Starting StarNet…")
    dlg.pbar.setRange(0, 100)
    dlg.pbar.setValue(0)
    dlg.pbar.setFormat("0%")
    dlg.append_text("Launching StarNet...\n")

    thr = _ProcThread(command, cwd=starnet_dir)

    # ---- Output parsing (stages + percent finished + tile count) ----
    _re_pct = re.compile(r"^\s*(\d{1,3})%\s+finished\s*$")
    _re_tiles = re.compile(r"Total number of tiles:\s*(\d+)\s*$")

    tile_total = {"n": 0}
    last_pct = {"v": -1}

    def _stage_from_line(low: str) -> str | None:
        if "reading input image" in low:
            return "Reading input image…"
        if ("bits per sample" in low) or ("samples per pixel" in low) or ("height:" in low) or ("width:" in low):
            return "Inspecting input…"
        if "restoring neural network checkpoint" in low:
            return "Loading model checkpoint…"
        if "created device" in low and "gpu" in low:
            return "Initializing GPU…"
        if "loaded cudnn version" in low:
            return "Initializing cuDNN…"
        if "total number of tiles" in low:
            return "Tiling image…"
        if "% finished" in low:
            return "Processing tiles…"
        if "writing" in low or "saving" in low:
            return "Writing output…"
        return None

    def _is_noise(low: str) -> bool:
        # Keep progress + stage parsing, but optionally suppress spam in the log box.
        # You can loosen/tighten this anytime.
        return (
            (low.startswith("202") and "tensorflow/" in low) or
            ("cpu_feature_guard" in low) or
            ("mlir" in low) or
            ("ptxas" in low) or
            ("bfc_allocator" in low) or
            ("garbage collection" in low)
        )

    def _on_out(line: str):
        low = line.lower()

        # stage updates
        st = _stage_from_line(low)
        if st:
            try:
                dlg.lbl_stage.setText(st)
            except Exception:
                pass

        # tile total
        m = _re_tiles.search(line)
        if m:
            try:
                tile_total["n"] = int(m.group(1))
            except Exception:
                tile_total["n"] = 0

        # percent updates (throttled)
        m = _re_pct.match(line)
        if m:
            try:
                pct = int(m.group(1))
                pct = max(0, min(100, pct))
                if pct != last_pct["v"]:
                    last_pct["v"] = pct
                    if tile_total["n"] > 0:
                        done = int(round(tile_total["n"] * (pct / 100.0)))
                        dlg.set_progress(done, tile_total["n"], "Processing tiles…")
                    else:
                        dlg.set_progress(pct, 100, "Processing…")
            except Exception:
                pass

        # append (optionally suppress TF spam)
        if not _is_noise(low):
            dlg.append_text(line)

    thr.output_signal.connect(_on_out)

    # finished -> apply + cleanup
    def _on_finish(rc: int):
        try:
            # snap to 100% for UX (even if StarNet ended abruptly, it will be overwritten by error handling)
            dlg.set_progress(100, 100, "StarNet finished. Loading output…")
        except Exception:
            pass
        _on_starnet_finished(main, doc, rc, dlg, input_image_path, output_image_path, did_stretch)

    thr.finished_signal.connect(_on_finish)

    # cancel kills subprocess
    dlg.cancel_button.clicked.connect(thr.cancel)

    thr.start()
    dlg.exec()

def _on_starnet_finished(main, doc, return_code, dialog, input_path, output_path, did_stretch):
    import os
    import numpy as np
    from PyQt6.QtWidgets import QMessageBox
    from setiastro.saspro.imageops.stretch import stretch_mono_image  # used for statistical inverse
    try:
        dialog.pbar.setRange(0, 100)
        dialog.set_progress(100, 100, "StarNet finished. Loading output…")
    except Exception:
        pass
    def _first_nonzero_bp_per_channel(img3: np.ndarray) -> np.ndarray:
        bps = np.zeros(3, dtype=np.float32)
        for c in range(3):
            ch = img3[..., c].reshape(-1)
            pos = ch[ch > 0.0]
            bps[c] = float(pos.min()) if pos.size else 0.0
        return bps

    dialog.append_text(f"\nProcess finished with return code {return_code}.\n")
    _tmp_dir = os.path.dirname(input_path)
    if return_code != 0:
        QMessageBox.critical(main, "StarNet Error", f"StarNet failed with return code {return_code}.")
        _safe_rm(input_path); _safe_rm(output_path)
        _safe_rmdir(_tmp_dir)
        dialog.close()
        return
    if not os.path.exists(output_path):
        QMessageBox.critical(main, "StarNet Error", "Starless image was not created.")
        _safe_rm(input_path)
        _safe_rmdir(_tmp_dir)
        dialog.close()
        return
    dialog.append_text(f"Starless image found at {output_path}. Loading image...\n")
    starless_rgb, _, _, _ = load_image(output_path)
    _safe_rm(input_path); _safe_rm(output_path)
    _safe_rmdir(_tmp_dir)
    if starless_rgb is None:
        QMessageBox.critical(main, "StarNet Error", "Failed to load starless image.")
        dialog.close()
        return

    # ensure 3ch float32 in [0..1]
    if starless_rgb.ndim == 2:
        starless_rgb = np.stack([starless_rgb] * 3, axis=-1)
    elif starless_rgb.ndim == 3 and starless_rgb.shape[2] == 1:
        starless_rgb = np.repeat(starless_rgb, 3, axis=2)
    starless_rgb = np.clip(starless_rgb.astype(np.float32, copy=False), 0.0, 1.0)

    # original image (from the doc) as 3ch float32, track if it was mono
    orig = np.asarray(doc.image)
    if orig.ndim == 2:
        original_rgb = np.stack([orig] * 3, axis=-1)
        orig_was_mono = True
    elif orig.ndim == 3 and orig.shape[2] == 1:
        original_rgb = np.repeat(orig, 3, axis=2)
        orig_was_mono = True
    else:
        original_rgb = orig
        orig_was_mono = False
    original_rgb = original_rgb.astype(np.float32, copy=False)


    # ---- Inversion back to the document’s domain ----
    if did_stretch:
        # Prefer the new MTF meta if present
        meta = getattr(main, "_starnet_stat_meta", None)
        mtf_params_legacy = getattr(main, "_starnet_last_mtf_params", None)

        if isinstance(meta, dict) and meta.get("scheme") == "stretch_mtf":
            dialog.append_text("Unstretching (stretch-style MTF pseudoinverse)...\n")
            try:
                s_vec = np.asarray(meta.get("s"), dtype=np.float32)
                m_vec = np.asarray(meta.get("m"), dtype=np.float32)
                h_vec = np.asarray(meta.get("h"), dtype=np.float32)
                scale_factor = float(meta.get("scale", 1.0))

                p = {"s": s_vec, "m": m_vec, "h": h_vec}
                inv = _invert_mtf_unlinked_rgb(starless_rgb, p)

                if scale_factor > 1.0:
                    inv = inv * scale_factor

                starless_rgb = np.clip(inv, 0.0, 1.0)
            except Exception as e:
                dialog.append_text(f"⚠️ stretch-style MTF inverse failed: {e}\n")

        elif isinstance(meta, dict) and meta.get("scheme") == "statstretch":
            # Back-compat: statistical round-trip with bp/m0
            dialog.append_text("Unstretching (statistical inverse w/ original BP/M0)...\n")

            bp_vec = np.asarray(meta.get("bp"), dtype=np.float32)
            m0_vec = np.asarray(meta.get("m0"), dtype=np.float32)
            scale_factor = float(meta.get("scale", 1.0))

            inv = np.empty_like(starless_rgb, dtype=np.float32)
            for c in range(3):
                inv[..., c] = stretch_mono_image(
                    starless_rgb[..., c],
                    target_median=float(m0_vec[c]),
                    normalize=False, apply_curves=False, curves_boost=0.0
                )

            inv += bp_vec.reshape((1, 1, 3))
            inv = np.clip(inv, 0.0, 1.0)
            if scale_factor > 1.0:
                inv *= scale_factor
            starless_rgb = np.clip(inv, 0.0, 1.0)

        elif mtf_params_legacy:
            # Very old MTF path (linked, single triple) – keep for safety
            dialog.append_text("Unstretching (legacy MTF inverse)...\n")
            try:
                starless_rgb = _invert_mtf_linked_rgb(starless_rgb, mtf_params_legacy)
                sc = float(mtf_params_legacy.get("scale", 1.0))
                if sc > 1.0:
                    starless_rgb = starless_rgb * sc
            except Exception as e:
                dialog.append_text(f"⚠️ Legacy MTF inverse failed: {e}\n")
            starless_rgb = np.clip(starless_rgb, 0.0, 1.0)

        # Clean up stashed meta so it can't leak to future ops
        try:
            if hasattr(main, "_starnet_stat_meta"):
                delattr(main, "_starnet_stat_meta")
        except Exception:
            pass



    # ---- Stars-Only = original − starless (linear-domain diff) ----
    dialog.append_text("Generating stars-only image...\n")
    stars_only = np.clip(original_rgb - starless_rgb, 0.0, 1.0)

    # apply active mask (doc-based)
    m3 = _active_mask3_from_doc(doc, stars_only.shape[1], stars_only.shape[0])
    if m3 is not None:
        stars_only *= m3
        dialog.append_text("✅ Applied active mask to the stars-only image.\n")
    else:
        dialog.append_text("ℹ️ No active mask for stars-only; skipping.\n")

    # If the original doc was mono, return a mono stars-only image
    if orig_was_mono:
        stars_to_push = stars_only.mean(axis=2).astype(np.float32, copy=False)
    else:
        stars_to_push = stars_only

    # push Stars-Only as new document with suffix _stars
    _push_as_new_doc(main, doc, stars_to_push, title_suffix="_stars", source="Stars-Only (StarNet)")
    dialog.append_text("Stars-only image pushed.\n")

    # mask-blend starless with original using active mask, then overwrite current view
    dialog.append_text("Preparing to update current view with starless (mask-blend)...\n")
    final_starless = _mask_blend_with_doc_mask(doc, starless_rgb, original_rgb)

    # If the original doc was mono, collapse back to single-channel
    if orig_was_mono:
        final_to_apply = final_starless.mean(axis=2).astype(np.float32, copy=False)
    else:
        final_to_apply = final_starless.astype(np.float32, copy=False)

    try:
        meta = {
            "step_name": "Stars Removed",
            "bit_depth": "32-bit floating point",
            "is_mono": bool(orig_was_mono),
        }

        # 🔹 Attach replay-last metadata
        rp = getattr(main, "_last_remove_stars_params", None)
        if isinstance(rp, dict):
            replay_params = dict(rp)  # shallow copy so we don't mutate the stored one
        else:
            replay_params = {
                "engine": "StarNet",
                "is_linear": bool(did_stretch),
                "did_stretch": bool(did_stretch),
                "label": "Remove Stars (StarNet)",
            }

        replay_params.setdefault("engine", "StarNet")
        replay_params.setdefault("label", "Remove Stars (StarNet)")

        meta["replay_last"] = {
            "op": "remove_stars",
            "params": replay_params,
        }

        # Clean up the stash so it can't leak to the next unrelated op
        try:
            if hasattr(main, "_last_remove_stars_params"):
                delattr(main, "_last_remove_stars_params")
        except Exception:
            pass

        _last = getattr(main, "_last_headless_command", None)
        if isinstance(_last, dict) and _last.get("command_id") == "remove_stars" \
                and isinstance(_last.get("preset"), dict):
            meta["command_id"] = "remove_stars"
            meta["preset"] = dict(_last["preset"])
        else:
            meta["command_id"] = "remove_stars"
            meta["preset"] = {"tool": "starnet", "linear": bool(did_stretch)}

        doc.apply_edit(
            final_to_apply,
            metadata=meta,
            step_name="Stars Removed"
        )
        if hasattr(main, "_log"):
            main._log("Stars Removed (StarNet)")
    except Exception as e:
        QMessageBox.critical(main, "StarNet Error", f"Failed to apply starless result:\n{e}")

    dialog.append_text("Temporary files cleaned up.\n")
    dialog.close()



# ------------------------------------------------------------
# CosmicClarityDarkStar
# ------------------------------------------------------------
def _open_darkstar_config(main, doc, icon_path=None, preset=None):
    from PyQt6.QtWidgets import QMessageBox
    if not _ensure_darkstar_model_available(main):
        return None
    cfg = DarkStarConfigDialog(main)
    try:
        cfg.setWindowIcon(QIcon(starnet_path))
    except Exception:
        pass
    cfg.setModal(False)
    if preset:
        try:
            cfg.seed_from_preset(preset)
        except Exception:
            pass
    try:
        main._darkstar_cfg_dialog = cfg   # retain against GC (non-modal .show())
    except Exception:
        pass
    # Non-blocking .show(): nobody reads .result(), so fire the run on `accepted`.
    cfg.accepted.connect(lambda: _darkstar_run_from_dialog(main, doc, cfg))
    cfg.show(); cfg.raise_(); cfg.activateWindow()
    return cfg


def _run_darkstar(main, doc, icon_path=None):
    _open_darkstar_config(main, doc, icon_path=icon_path, preset=None)


def open_darkstar_with_preset(main, doc, preset=None):
    return _open_darkstar_config(main, doc, icon_path=None, preset=preset)


def _darkstar_run_from_dialog(main, doc, cfg):
    import numpy as np
    from PyQt6.QtWidgets import QMessageBox
    try:
        main._darkstar_cfg_dialog = None
    except Exception:
        pass
    v = cfg.get_values()

    disable_gpu = bool(v["disable_gpu"])
    use_gpu = not disable_gpu
    compatibility_mode = bool(v.get("compatibility_mode", False))
    mode = str(v["mode"])                         # "unscreen" | "additive"
    processing_path = str(v["processing_path"])   # "mono_per_channel" | "hybrid_luma_color" | "color_only"
    show_extracted_stars = bool(v["show_extracted_stars"])

    chunk_size = int(v.get("chunk_size", v.get("stride", 512)))
    overlap_frac = float(v.get("overlap_frac", 0.125))
    edge_padding = int(v.get("edge_padding", 64))
    output_stars_only = bool(show_extracted_stars)

    # 🔹 Stash parameters for replay-last (same structure as you had)
    try:
        main._last_headless_command = {
            "command_id": "remove_stars",
            "preset": {
                "tool": "darkstar",
                "disable_gpu": bool(disable_gpu),
                "compatibility_mode": bool(compatibility_mode),
                "mode": str(mode),
                "processing_path": str(processing_path),
                "show_extracted_stars": bool(show_extracted_stars),
                "chunk_size": int(chunk_size),
                "stride": int(chunk_size),  # legacy compatibility
                "edge_padding": int(edge_padding),
                "overlap_frac": float(overlap_frac),
            },
        }
        if hasattr(main, "_log"):
            main._log(
                "[Replay] Recorded remove_stars (DarkStar, "
                f"mode={mode}, path={processing_path}, chunk_size={int(chunk_size)}, "
                f"gpu={'off' if disable_gpu else 'on'}, "
                f"compat={'on' if compatibility_mode else 'off'}, "
                f"stars={'on' if show_extracted_stars else 'off'})"
            )
    except Exception:
        pass


    # --- Build input image for engine: float32 [0..1], HxWx3/1/mono ok ---
    src = np.asarray(doc.image)
    orig_was_mono = (src.ndim == 2) or (src.ndim == 3 and src.shape[2] == 1)

    x = np.nan_to_num(src.astype(np.float32, copy=False), nan=0.0, posinf=0.0, neginf=0.0)

    orig_h, orig_w = x.shape[:2]

    scale_factor = float(np.max(x)) if x.size else 1.0
    if scale_factor > 1.0:
        x = x / scale_factor
    x = np.clip(x, 0.0, 1.0).astype(np.float32, copy=False)

    # Reflect-pad whole image before sending to Dark Star to reduce edge artifacts
    if edge_padding > 0:
        x = _pad_reflect(x, edge_padding)

    params = DarkStarParams(
        use_gpu=bool(use_gpu),
        chunk_size=int(chunk_size),
        overlap_frac=float(overlap_frac),
        mode=str(mode),
        output_stars_only=bool(output_stars_only),
        processing_path=str(processing_path),
        edge_padding=int(edge_padding),
        compatibility_mode=bool(compatibility_mode),
    )
    
    dlg = _ProcDialog(main, title="Dark Star Progress")
    dlg.append_text("Starting Dark Star (engine)…\n")

    thr = _DarkStarThread(x, params, parent=dlg)

    def _on_prog(done, total, stage):
        dlg.set_progress(done, total, stage)

    def _on_done(starless, stars_only, was_mono, err):
        if err:
            QMessageBox.critical(main, "Dark Star Error", f"Dark Star failed:\n{err}")
            dlg.close()
            return
        # Remove UI-level reflect padding
        if edge_padding > 0:
            try:
                starless = _crop_unpad(starless, edge_padding, orig_h, orig_w)
                if stars_only is not None:
                    stars_only = _crop_unpad(stars_only, edge_padding, orig_h, orig_w)
            except Exception as e:
                QMessageBox.critical(main, "Dark Star Error", f"Failed to crop padded result:\n{e}")
                dlg.close()
                return
        # Engine returns float32 [0..1]; if we normalized >1, restore scale if you want.
        # BUT you later clip to [0..1] for doc anyway, so this is mostly for consistency.
        if scale_factor > 1.0:
            try:
                starless = starless * scale_factor
                if stars_only is not None:
                    stars_only = stars_only * scale_factor
            except Exception:
                pass

        # Original as RGB for blending math
        orig = np.asarray(doc.image).astype(np.float32, copy=False)
        if orig.ndim == 2:
            original_rgb = np.stack([orig]*3, axis=-1)
        elif orig.ndim == 3 and orig.shape[2] == 1:
            original_rgb = np.repeat(orig, 3, axis=2)
        else:
            original_rgb = orig

        # Starless as RGB for blending math
        if starless.ndim == 2:
            starless_rgb = np.stack([starless]*3, axis=-1)
        elif starless.ndim == 3 and starless.shape[2] == 1:
            starless_rgb = np.repeat(starless, 3, axis=2)
        else:
            starless_rgb = starless

        starless_rgb = starless_rgb.astype(np.float32, copy=False)

        # ---- Optional stars-only push ----
        if show_extracted_stars:
            if stars_only is None:
                # Safety fallback if someone changes engine params later
                stars_only_rgb = np.clip(original_rgb - starless_rgb, 0.0, 1.0).astype(np.float32, copy=False)
            else:
                if stars_only.ndim == 2:
                    stars_only_rgb = np.stack([stars_only]*3, axis=-1)
                elif stars_only.ndim == 3 and stars_only.shape[2] == 1:
                    stars_only_rgb = np.repeat(stars_only, 3, axis=2)
                else:
                    stars_only_rgb = stars_only.astype(np.float32, copy=False)

            m3 = _active_mask3_from_doc(doc, stars_only_rgb.shape[1], stars_only_rgb.shape[0])
            if m3 is not None:
                stars_only_rgb *= m3
                dlg.append_text("✅ Applied active mask to stars-only image.\n")

            if orig_was_mono:
                stars_to_push = stars_only_rgb.mean(axis=2).astype(np.float32, copy=False)
            else:
                stars_to_push = stars_only_rgb

            _push_as_new_doc(main, doc, stars_to_push, title_suffix="_stars", source="Stars-Only (DarkStar)")
            dlg.append_text("Stars-only image pushed.\n")

        # ---- Mask-blend starless into current doc ----
        final_starless = _mask_blend_with_doc_mask(doc, starless_rgb, original_rgb)

        if orig_was_mono:
            final_to_apply = final_starless.mean(axis=2).astype(np.float32, copy=False)
        else:
            final_to_apply = final_starless.astype(np.float32, copy=False)

        # Clip to [0..1] because that’s what your pipeline expects almost everywhere
        final_to_apply = np.clip(final_to_apply, 0.0, 1.0).astype(np.float32, copy=False)

        try:
            meta = {
                "step_name": "Stars Removed",
                "bit_depth": "32-bit floating point",
                "is_mono": bool(orig_was_mono),
            }

            rp = getattr(main, "_last_remove_stars_params", None)
            replay_params = dict(rp) if isinstance(rp, dict) else {"engine": "DarkStar", "label": "Remove Stars (DarkStar)"}
            replay_params.setdefault("engine", "DarkStar")
            replay_params.setdefault("label", "Remove Stars (DarkStar)")

            meta["replay_last"] = {"op": "remove_stars", "params": replay_params}

            try:
                if hasattr(main, "_last_remove_stars_params"):
                    delattr(main, "_last_remove_stars_params")
            except Exception:
                pass

            _last = getattr(main, "_last_headless_command", None)
            if isinstance(_last, dict) and _last.get("command_id") == "remove_stars" \
                    and isinstance(_last.get("preset"), dict):
                meta["command_id"] = "remove_stars"
                meta["preset"] = dict(_last["preset"])
            else:
                meta["command_id"] = "remove_stars"
                meta["preset"] = {"tool": "darkstar"}

            doc.apply_edit(final_to_apply, metadata=meta, step_name="Stars Removed")
            if hasattr(main, "_log"):
                main._log("Stars Removed (DarkStar)")
        except Exception as e:
            QMessageBox.critical(main, "Dark Star Error", f"Failed to apply result:\n{e}")

        dlg.append_text("Done.\n")
        dlg.close()

    thr.progress_signal.connect(_on_prog)
    thr.finished_signal.connect(_on_done)

    dlg.cancel_button.clicked.connect(lambda: dlg.append_text("Cancel not supported for in-process engine.\n"))
    dlg.show()
    thr.start()
    dlg.exec()

# ------------------------------------------------------------
# Mask helpers (doc-centric)
# ------------------------------------------------------------
# _active_mask_array_from_doc is now imported from setiastro.saspro.widgets.image_utils


def _active_mask3_from_doc(doc, w, h) -> np.ndarray | None:
    """Return 3-channel mask resized to (h,w) if a doc-level mask exists; else None."""
    m = _active_mask_array_from_doc(doc)
    if m is None:
        return None
    if m.shape != (h, w):
        if cv2 is not None:
            m = cv2.resize(m, (w, h), interpolation=cv2.INTER_NEAREST)
        else:
            yi = (np.linspace(0, m.shape[0] - 1, h)).astype(np.int32)
            xi = (np.linspace(0, m.shape[1] - 1, w)).astype(np.int32)
            m = m[yi][:, xi]
    return np.repeat(m[:, :, None], 3, axis=2).astype(np.float32, copy=False)


def _mask_blend_with_doc_mask(doc, starless_rgb: np.ndarray, original_rgb: np.ndarray) -> np.ndarray:
    """Blend using mask from doc if present: result = starless*m + original*(1-m)."""
    m = _active_mask_array_from_doc(doc)
    if m is None:
        return starless_rgb
    h, w = starless_rgb.shape[:2]
    if m.shape != (h, w):
        if cv2 is not None:
            m = cv2.resize(m, (w, h), interpolation=cv2.INTER_NEAREST)
        else:
            yi = (np.linspace(0, m.shape[0] - 1, h)).astype(np.int32)
            xi = (np.linspace(0, m.shape[1] - 1, w)).astype(np.int32)
            m = m[yi][:, xi]
    m3 = np.repeat(m[:, :, None], 3, axis=2)
    return np.clip(starless_rgb * m3 + original_rgb * (1.0 - m3), 0.0, 1.0).astype(np.float32, copy=False)


def _derive_view_base_title(main, doc) -> str:
    """
    Prefer the active view's title (respecting per-view rename/override),
    fallback to the document display name, then to doc.name, and finally 'Image'.
    Also strips any decorations (mask glyph, 'Active View:' prefix) if available.
    """
    # 1) Ask main for a subwindow for this document, if it exposes a helper
    try:
        if hasattr(main, "_subwindow_for_document"):
            sw = main._subwindow_for_document(doc)
            if sw:
                w = sw.widget() if hasattr(sw, "widget") else sw
                # Preferred: view's effective title (includes per-view override)
                if hasattr(w, "_effective_title"):
                    t = w._effective_title() or ""
                else:
                    t = sw.windowTitle() if hasattr(sw, "windowTitle") else ""
                if hasattr(w, "_strip_decorations"):
                    t, _ = w._strip_decorations(t)
                if t.strip():
                    return t.strip()
    except Exception:
        pass

    # 2) Try scanning MDI for a subwindow whose widget holds this document
    try:
        mdi = (getattr(main, "mdi_area", None)
               or getattr(main, "mdiArea", None)
               or getattr(main, "mdi", None))
        if mdi and hasattr(mdi, "subWindowList"):
            for sw in mdi.subWindowList():
                w = sw.widget()
                if getattr(w, "document", None) is doc:
                    t = sw.windowTitle() if hasattr(sw, "windowTitle") else ""
                    if hasattr(w, "_strip_decorations"):
                        t, _ = w._strip_decorations(t)
                    if t.strip():
                        return t.strip()
    except Exception:
        pass

    # 3) Fallback to document's display name (then name, then generic)
    try:
        if hasattr(doc, "display_name"):
            t = doc.display_name()
            if t and t.strip():
                return t.strip()
    except Exception:
        pass
    return (getattr(doc, "name", "") or "Image").strip()


# ------------------------------------------------------------
# New document helper
# ------------------------------------------------------------
def _push_as_new_doc(main, doc, arr: np.ndarray, title_suffix="_stars", source="Stars-Only"):
    dm = getattr(main, "docman", None)
    if not dm or not hasattr(dm, "open_array"):
        return
    try:
        # Use the current view's title if available (respects per-view rename)
        base = _derive_view_base_title(main, doc)

        # avoid double-suffix if user already named it with the suffix
        if title_suffix and base.endswith(title_suffix):
            title = base
        else:
            title = f"{base}{title_suffix}"

        meta = {
            "bit_depth": "32-bit floating point",
            "is_mono": (arr.ndim == 2),
            "source": source,
        }
        newdoc = dm.open_array(arr.astype(np.float32, copy=False), metadata=meta, title=title)
        if hasattr(main, "_spawn_subwindow_for"):
            main._spawn_subwindow_for(newdoc)
    except Exception:
        pass



# ------------------------------------------------------------
# Utilities
# ------------------------------------------------------------
def _ensure_exec_bit(path: str):
    if platform.system() == "Windows":
        return
    try:
        st = os.stat(path)
        os.chmod(path, st.st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    except Exception:
        pass


def _safe_rm(p):
    try:
        if p and os.path.exists(p):
            os.remove(p)
    except Exception:
        pass

def _safe_rmdir(p):
    try:
        if p and os.path.isdir(p):
            shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass

def _pad_reflect(img: np.ndarray, pad: int) -> np.ndarray:
    """
    Reflect-pad HxW or HxWxC image by `pad` pixels on all sides.
    """
    pad = int(max(0, pad))
    if pad <= 0:
        return img
    if img.ndim == 2:
        return np.pad(img, ((pad, pad), (pad, pad)), mode="reflect")
    if img.ndim == 3:
        return np.pad(img, ((pad, pad), (pad, pad), (0, 0)), mode="reflect")
    return img


def _crop_unpad(img: np.ndarray, pad: int, h: int, w: int) -> np.ndarray:
    """
    Crop back to original (h,w) after padding by `pad`.
    """
    pad = int(max(0, pad))
    if pad <= 0:
        return img
    if img.ndim == 2:
        return img[pad:pad + h, pad:pad + w]
    if img.ndim == 3:
        return img[pad:pad + h, pad:pad + w, :]
    return img


def _extract_stars_only(original_rgb: np.ndarray,
                        starless_rgb: np.ndarray,
                        mode: str = "subtract",
                        eps: float = 1e-6) -> np.ndarray:
    """
    Compute stars-only from (original, starless).

    mode="subtract":
        stars = clip(original - starless)

    mode="unscreen":
        assumes: original = screen(starless, stars)
        screen(A,B) = 1 - (1-A)*(1-B)
        => stars = 1 - (1-original)/(1-starless)

    Both inputs are expected float32 in [0..1] (RGB).
    """
    o = np.asarray(original_rgb, dtype=np.float32)
    s = np.asarray(starless_rgb, dtype=np.float32)

    if mode.lower() != "unscreen":
        return np.clip(o - s, 0.0, 1.0).astype(np.float32, copy=False)

    denom = np.clip(1.0 - s, eps, 1.0)               # avoid divide by 0 near white cores
    stars = 1.0 - (1.0 - o) / denom
    return np.clip(stars, 0.0, 1.0).astype(np.float32, copy=False)


# ------------------------------------------------------------
#sasproc runner & dialog (merged stdout/stderr)
# ------------------------------------------------------------
class _ProcThread(QThread):
    output_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(int)

    def __init__(self, command: list[str], cwd: str | None = None, parent=None):
        super().__init__(parent)
        self.command = command
        self.cwd = cwd
        self.process = None

    def cancel(self):
        """Request the subprocess to stop."""
        if self.process:
            try:
                self.process.kill()
            except Exception:
                pass


    def run(self):
        import subprocess
        import os
        env = os.environ.copy()
        for k in ("PYTHONHOME","PYTHONPATH","DYLD_LIBRARY_PATH","DYLD_FALLBACK_LIBRARY_PATH","PYTHONEXECUTABLE"):
            env.pop(k, None)
        rc = -1
        try:
            self.process = subprocess.Popen(
                self.command, cwd=self.cwd,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                universal_newlines=True, text=True, start_new_session=True, env=env
            )
            for line in iter(self.process.stdout.readline, ""):
                if not line: break
                self.output_signal.emit(line.rstrip())
            try:
                self.process.stdout.close()
            except Exception:
                pass
            rc = self.process.wait()
        except Exception as e:
            self.output_signal.emit(str(e))
            rc = -1
        finally:
            self.process = None
        self.finished_signal.emit(rc)

class _ProcDialog(QDialog):
    def __init__(self, parent, title="Process"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumSize(600, 460)

        self._last_pct = -1  # for throttling UI updates

        lay = QVBoxLayout(self)

        # --- status line + progress bar ---
        self.lbl_stage = QLabel("", self)
        self.lbl_stage.setWordWrap(True)
        self.lbl_stage.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        lay.addWidget(self.lbl_stage)

        self.pbar = QProgressBar(self)
        self.pbar.setRange(0, 100)
        self.pbar.setValue(0)
        self.pbar.setTextVisible(True)
        lay.addWidget(self.pbar)

        # --- log output ---
        self.text = QTextEdit(self)
        self.text.setReadOnly(True)
        lay.addWidget(self.text, 1)

        # --- cancel ---
        self.cancel_button = QPushButton("Cancel", self)
        lay.addWidget(self.cancel_button)

    def append_text(self, s: str):
        try:
            self.text.append(s)
        except Exception:
            pass

    def set_progress(self, done: int, total: int, stage: str = ""):
        """
        Update stage label + progress bar.
        `total<=0` puts the bar into an indeterminate-ish state (0%).
        Throttles updates when percent hasn't changed.
        """
        try:
            if stage:
                self.lbl_stage.setText(stage)

            if total and total > 0:
                pct = int(round(100.0 * float(done) / float(total)))
                pct = max(0, min(100, pct))
            else:
                pct = 0

            # throttle: only repaint if percent changed or we're at end
            if pct != self._last_pct or done == total:
                self._last_pct = pct
                self.pbar.setValue(pct)

                # keep the text helpful
                if total and total > 0:
                    self.pbar.setFormat(f"{pct}%  ({done}/{total})")
                else:
                    self.pbar.setFormat(f"{pct}%")
        except Exception:
            pass

    def reset_progress(self, stage: str = ""):
        self._last_pct = -1
        if stage:
            try:
                self.lbl_stage.setText(stage)
            except Exception:
                pass
        try:
            self.pbar.setValue(0)
            self.pbar.setFormat("0%")
        except Exception:
            pass

class _DarkStarThread(QThread):
    progress_signal = pyqtSignal(int, int, str)   # done, total, stage
    finished_signal = pyqtSignal(object, object, bool, str)  # starless, stars_only, was_mono, errstr

    def __init__(self, img_rgb01: np.ndarray, params: DarkStarParams, parent=None):
        super().__init__(parent)
        self._img = img_rgb01
        self._params = params

    def run(self):
        try:
            def prog(done, total, stage):
                self.progress_signal.emit(int(done), int(total), str(stage))

            # status_cb is optional; keep quiet or route to progress text if you want
            starless, stars_only, was_mono = darkstar_starremoval_rgb01(
                self._img,
                params=self._params,
                progress_cb=prog,
                status_cb=print,
            )
            self.finished_signal.emit(starless, stars_only, bool(was_mono), "")
        except Exception as e:
            self.finished_signal.emit(None, None, False, str(e))

class DarkStarConfigDialog(QDialog):
    """
    SASv2-style config UI:
      - Disable GPU: Yes/No (default No)
      - Star Removal Mode: unscreen | additive (default unscreen)
      - Processing Path:
            mono_per_channel
            hybrid_luma_color
            color_only
      - Show Extracted Stars: Yes/No (default Yes)
      - Stride (powers of 2): 64,128,256,512,1024 (default 512)
      - Overlap (%): overlap between chunks
      - Edge Padding: reflected full-image border to reduce edge artifacts
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("CosmicClarity Dark Star Settings")

        settings = QSettings()
        self.icons = get_icons()

        self.chk_disable_gpu = QCheckBox("Disable GPU")
        self.chk_disable_gpu.setChecked(False)

        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["unscreen", "additive"])
        self.cmb_mode.setCurrentText(str(settings.value("darkstar/mode", "unscreen")))

        self.cmb_processing = QComboBox()
        self.cmb_processing.addItem("Mono AI per channel", "mono_per_channel")
        self.cmb_processing.addItem("Hybrid Luma + Color (best balance)", "hybrid_luma_color")
        self.cmb_processing.addItem("Color AI only", "color_only")
        saved_processing = str(settings.value("darkstar/processing_path", "hybrid_luma_color"))
        idx = max(0, self.cmb_processing.findData(saved_processing))
        self.cmb_processing.setCurrentIndex(idx)

        self.chk_show_stars = QCheckBox("Show Extracted Stars")
        self.chk_show_stars.setChecked(bool(settings.value("darkstar/show_extracted_stars", True, type=bool)))

        self.cmb_chunk_size = QComboBox()
        for v in (64, 128, 256, 512, 1024):
            self.cmb_chunk_size.addItem(str(v), v)

        # Backward-compatible read: prefer chunk_size, fall back to old stride
        saved_chunk_size = int(settings.value(
            "darkstar/chunk_size",
            settings.value("darkstar/stride", 512, type=int),
            type=int
        ))
        idx = max(0, self.cmb_chunk_size.findData(saved_chunk_size))
        self.cmb_chunk_size.setCurrentIndex(idx)

        self.cmb_overlap = QComboBox()
        for pct in (0.05, 0.075, 0.10, 0.125, 0.15, 0.20, 0.25, 0.35, 0.50):
            label = f"{pct * 100:.1f}%"
            self.cmb_overlap.addItem(label, pct)
        saved_overlap = float(settings.value("darkstar/overlap_frac", 0.125, type=float))
        # match by closest value
        best_idx = 0
        best_err = 1e9
        for i in range(self.cmb_overlap.count()):
            v = float(self.cmb_overlap.itemData(i))
            err = abs(v - saved_overlap)
            if err < best_err:
                best_err = err
                best_idx = i
        self.cmb_overlap.setCurrentIndex(best_idx)

        self.cmb_padding = QComboBox()
        for v in (0, 16, 32, 64, 128, 256):
            self.cmb_padding.addItem(str(v), v)
        saved_padding = int(settings.value("darkstar/edge_padding", 64, type=int))
        idx = max(0, self.cmb_padding.findData(saved_padding))
        self.cmb_padding.setCurrentIndex(idx)

        self.chk_compatibility = QCheckBox("GPU Compatibility Mode")
        self.chk_compatibility.setChecked(bool(settings.value("darkstar/compatibility_mode", False, type=bool)))

        form = QFormLayout()
        form.addRow("Star Removal Mode:", self.cmb_mode)
        form.addRow("Processing Path:", self.cmb_processing)
        form.addRow("Chunk Size (power of two):", self.cmb_chunk_size)
        form.addRow("Overlap (%):", self.cmb_overlap)
        form.addRow("Edge Padding:", self.cmb_padding)
        form.addRow("", self.chk_compatibility)
        form.addRow("", self.chk_disable_gpu)
        form.addRow("", self.chk_show_stars)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        self.lbl_logo = QLabel(self)
        self.lbl_logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        try:
            pm = QPixmap(self.icons.COSMICCLARITYDARK)
            if not pm.isNull():
                self.lbl_logo.setPixmap(
                    pm.scaledToWidth(280, Qt.TransformationMode.SmoothTransformation)
                )
                layout.addWidget(self.lbl_logo)
        except Exception:
            pass

        layout.addLayout(form)
        layout.addWidget(btns)

        # --- preset drag handle (grip) ---
        try:
            from setiastro.saspro.shortcuts import PresetDragHandle
            from setiastro.saspro.help_support import make_help_button
            try:
                _grip_icon = QIcon(starnet_path)
            except Exception:
                _grip_icon = QIcon()
            drag_row = QHBoxLayout()
            drag_row.setContentsMargins(0, 0, 0, 0)
            self.preset_drag_handle = PresetDragHandle(
                "remove_stars", self.get_preset, icon=_grip_icon,
                tooltip=self.tr(
                    "Drag to the canvas to create a Remove Stars (DarkStar) shortcut "
                    "with these exact settings.\n"
                    "Drop directly on an image to apply them headlessly."
                ),
                parent=self,
            )
            drag_row.addWidget(self.preset_drag_handle)
            drag_row.addStretch(1)
            self.btn_help = make_help_button("remove_stars", self)
            drag_row.addWidget(self.btn_help)
            layout.addLayout(drag_row)
        except Exception:
            pass

    def get_preset(self) -> dict:
        """Limited schema by design (matches RemoveStarsPresetDialog.result_dict darkstar
        branch and the headless consumer). Advanced params follow QSettings, not the shortcut."""
        return {
            "tool": "darkstar",
            "disable_gpu": bool(self.chk_disable_gpu.isChecked()),
            "mode": self.cmb_mode.currentText(),
            "show_extracted_stars": bool(self.chk_show_stars.isChecked()),
            "stride": int(self.cmb_chunk_size.currentData()),
        }

    def seed_from_preset(self, p: dict | None):
        p = dict(p or {})
        widgets = [self.chk_disable_gpu, self.cmb_mode, self.chk_show_stars, self.cmb_chunk_size]
        for w in widgets:
            try: w.blockSignals(True)
            except Exception: pass
        try:
            if "disable_gpu" in p:
                self.chk_disable_gpu.setChecked(bool(p.get("disable_gpu")))
            if p.get("mode"):
                self.cmb_mode.setCurrentText(str(p.get("mode")))
            if "show_extracted_stars" in p:
                self.chk_show_stars.setChecked(bool(p.get("show_extracted_stars")))
            stride = p.get("stride", p.get("chunk_size"))
            if stride is not None:
                idx = self.cmb_chunk_size.findData(int(stride))
                if idx >= 0:
                    self.cmb_chunk_size.setCurrentIndex(idx)
        finally:
            for w in widgets:
                try: w.blockSignals(False)
                except Exception: pass

    def get_values(self):
        vals = {
            "disable_gpu": self.chk_disable_gpu.isChecked(),
            "mode": self.cmb_mode.currentText(),
            "processing_path": str(self.cmb_processing.currentData()),
            "show_extracted_stars": self.chk_show_stars.isChecked(),
            "chunk_size": int(self.cmb_chunk_size.currentData()),
            "overlap_frac": float(self.cmb_overlap.currentData()),
            "edge_padding": int(self.cmb_padding.currentData()),
            "compatibility_mode": self.chk_compatibility.isChecked(),            
        }

        try:
            settings = QSettings()
            settings.setValue("darkstar/mode", vals["mode"])
            settings.setValue("darkstar/processing_path", vals["processing_path"])
            settings.setValue("darkstar/show_extracted_stars", vals["show_extracted_stars"])
            settings.setValue("darkstar/chunk_size", vals["chunk_size"])
            settings.setValue("darkstar/stride", vals["chunk_size"])  # legacy compatibility
            settings.setValue("darkstar/overlap_frac", vals["overlap_frac"])
            settings.setValue("darkstar/edge_padding", vals["edge_padding"])
            settings.setValue("darkstar/compatibility_mode", vals["compatibility_mode"])            
        except Exception:
            pass

        return vals

def _ensure_darkstar_model_available(parent=None) -> bool:
    """
    Dark Star always requires the mono AI4 model.
    Return True if present, otherwise show a warning and return False.
    """
    from PyQt6.QtWidgets import QMessageBox
    from setiastro.saspro.resources import get_resources
    import os

    try:
        R = get_resources()
        mono_pth = str(R.CC_DARKSTAR_MONO_PTH)
    except Exception as e:
        QMessageBox.warning(
            parent,
            "Dark Star Model Missing",
            f"Could not resolve Dark Star model paths.\n\n{e}",
        )
        return False

    if not mono_pth or not os.path.exists(mono_pth):
        QMessageBox.warning(
            parent,
            "Dark Star Model Missing",
            "The required Dark Star mono model is not installed yet:\n\n"
            f"{mono_pth}\n\n"
            "Please install or download the Dark Star models, then try again.",
        )
        return False

    return True

def darkstar_starless_from_array(
    arr_rgb01: np.ndarray,
    *,
    use_gpu: bool = True,
    chunk_size: int = 512,
    overlap_frac: float = 0.125,
    mode: str = "unscreen",
    processing_path: str = "hybrid_luma_color",
    output_stars_only: bool = False,
    edge_padding: int = 64,
    compatibility_mode: bool = False,
    progress_cb=None,
    status_cb=None
) -> tuple[np.ndarray, np.ndarray | None, bool]:
    """
    Headless DarkStar:
      input: float32 [0..1], mono or RGB
      output: (starless, stars_only_or_None, was_mono)
    """
    x = np.asarray(arr_rgb01, dtype=np.float32)
    was_mono = (x.ndim == 2) or (x.ndim == 3 and x.shape[2] == 1)

    if x.ndim == 3 and x.shape[2] == 1:
        x = x[..., 0]

    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32, copy=False)
    x = np.clip(x, 0.0, 1.0)

    orig_h, orig_w = x.shape[:2]

    if edge_padding > 0:
        x = _pad_reflect(x, edge_padding)

    params = DarkStarParams(
        use_gpu=bool(use_gpu),
        chunk_size=int(chunk_size),
        overlap_frac=float(overlap_frac),
        mode=str(mode),
        output_stars_only=bool(output_stars_only),
        processing_path=str(processing_path),
        edge_padding=int(edge_padding),
        compatibility_mode=bool(compatibility_mode),
    )

    def _prog(done, total, stage):
        if callable(progress_cb):
            try:
                progress_cb(int(done), int(total), str(stage))
            except Exception:
                pass

    def _status(msg: str):
        if callable(status_cb):
            try:
                status_cb(str(msg))
            except Exception:
                pass

    starless, stars_only, engine_was_mono = darkstar_starremoval_rgb01(
        x,
        params=params,
        progress_cb=_prog if callable(progress_cb) else None,
        status_cb=_status if callable(status_cb) else None,
    )

    if edge_padding > 0:
        if starless is not None:
            starless = _crop_unpad(starless, edge_padding, orig_h, orig_w)
        if stars_only is not None:
            stars_only = _crop_unpad(stars_only, edge_padding, orig_h, orig_w)

    if starless is not None:
        starless = np.clip(np.asarray(starless, dtype=np.float32), 0.0, 1.0)

    if stars_only is not None:
        stars_only = np.clip(np.asarray(stars_only, dtype=np.float32), 0.0, 1.0)

    if was_mono and starless is not None and starless.ndim == 3:
        starless = starless.mean(axis=2).astype(np.float32, copy=False)

    if was_mono and stars_only is not None and stars_only.ndim == 3:
        stars_only = stars_only.mean(axis=2).astype(np.float32, copy=False)

    return starless, (stars_only if output_stars_only else None), bool(was_mono)

def _run_sxt(main, doc, icon_path=None):
    """Open the RC-Astro dialog with the StarXTerminator tab pre-selected."""
    from setiastro.saspro.rcastro import open_rcastro_dialog
    from PyQt6.QtGui import QIcon

    # Check exe is configured first
    s = QSettings()
    exe = str(s.value("rcastro/exe_path", ""))
    if not exe or not os.path.exists(exe):
        QMessageBox.warning(
            main, "StarXTerminator",
            "RC-Astro executable not set.\n\n"
            "Open RC-Astro Tools from the toolbar and browse for the\n"
            "rc-astro executable first, then try again."
        )
        return

    icon = QIcon(icon_path) if icon_path else None

    # Open the dialog (or raise it if already open)
    if hasattr(main, "_rcastro_dlg") and main._rcastro_dlg is not None:
        try:
            dlg = main._rcastro_dlg
            # Switch to the SXT tab (index 1)
            dlg.tabs.setCurrentIndex(1)
            dlg.raise_()
            dlg.activateWindow()
            return
        except RuntimeError:
            main._rcastro_dlg = None

    dlg = open_rcastro_dialog(main, doc=doc, rcastro_icon=icon)
    # Switch to SXT tab (index 1: BXT=0, SXT=1, NXT=2)
    dlg.tabs.setCurrentIndex(1)
    main._rcastro_dlg = dlg
    dlg.destroyed.connect(lambda: setattr(main, "_rcastro_dlg", None))