from __future__ import annotations
import numpy as np

try:
    import cv2
except Exception:
    cv2 = None

from PyQt6.QtCore import Qt, QTimer, QSettings, QByteArray
from PyQt6.QtGui import QImage, QPixmap, QIcon, QGuiApplication
from PyQt6.QtWidgets import (
    QDialog, QWidget, QLabel, QPushButton, QComboBox, QCheckBox, QSlider, QGroupBox,
    QVBoxLayout, QHBoxLayout, QGridLayout, QMessageBox, QSpinBox, QDoubleSpinBox,
    QFileDialog, QScrollArea, QFrame, QTabWidget, QSplitter
)
from PyQt6.QtWidgets import QSizePolicy
from setiastro.saspro.widgets.themed_buttons import themed_toolbtn
from setiastro.saspro.help_support import make_help_button

# ---------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------

def _to_uint8_rgb(img01: np.ndarray) -> np.ndarray:
    a = np.clip(img01, 0.0, 1.0)
    if a.ndim == 2:
        a = np.repeat(a[..., None], 3, axis=2)
    return (a * 255.0 + 0.5).astype(np.uint8)

def _to_pixmap(img01: np.ndarray) -> QPixmap:
    a = _to_uint8_rgb(img01)
    h, w, _ = a.shape
    qimg = QImage(a.data, w, h, a.strides[0], QImage.Format.Format_RGB888)
    return QPixmap.fromImage(qimg)

def _rgb_to_hsv01(img01: np.ndarray) -> np.ndarray:
    if cv2 is None:
        raise RuntimeError("OpenCV (cv2) is required for Selective Color.")
    # expects 8-bit for best speed
    u8 = _to_uint8_rgb(img01)
    hsv = cv2.cvtColor(u8, cv2.COLOR_RGB2HSV)  # H in [0,180], S,V in [0,255]
    out = np.empty_like(hsv, dtype=np.float32)
    out[...,0] = hsv[...,0].astype(np.float32) / 180.0  # 0..1
    out[...,1] = hsv[...,1].astype(np.float32) / 255.0
    out[...,2] = hsv[...,2].astype(np.float32) / 255.0
    return out

def _luminance01(img01: np.ndarray) -> np.ndarray:
    if img01.ndim == 2:
        return np.clip(img01, 0.0, 1.0).astype(np.float32)
    r, g, b = img01[...,0], img01[...,1], img01[...,2]
    return (0.2989*r + 0.5870*g + 0.1140*b).astype(np.float32)

def _softstep(x, edge0, edge1):
    # smoothstep
    t = np.clip((x - edge0) / max(edge1 - edge0, 1e-6), 0.0, 1.0)
    return t * t * (3 - 2*t)

# ---------------------------------------------------------------------
# Mask generation
# ---------------------------------------------------------------------

_PRESETS = {
    "Red":     [(340, 360), (0, 15)],
    "Orange":  [(15, 40)],
    "Yellow":  [(40, 70)],
    "Green":   [(70, 170)],
    "Cyan":    [(170, 200)],
    "Blue":    [(200, 270)],
    "Magenta": [(270, 340)],
}

def _hue_band(Hdeg: np.ndarray, lo: float, hi: float, smooth_deg: float) -> np.ndarray:
    """
    Soft band on the hue circle (degrees 0..360), but with *local* feathering:
    - core band is the forward arc lo → hi
    - smooth_deg only adds a ramp *right after hi* and *right before lo*
    - never balloons into the whole hue wheel
    """
    H = Hdeg.astype(np.float32)

    lo = float(lo) % 360.0
    hi = float(hi) % 360.0

    # length of the forward arc
    L = (hi - lo) % 360.0
    if L <= 1e-6:
        return np.zeros_like(H, dtype=np.float32)

    s = float(max(smooth_deg, 0.0))

    # forward distance from lo → hue (always 0..360)
    fwd = (H - lo) % 360.0
    # backward distance from hue → lo (always 0..360)
    bwd = (lo - H) % 360.0

    # start with zeros
    band = np.zeros_like(H, dtype=np.float32)

    # 1) core: strictly inside the band
    inside = (fwd <= L)
    band[inside] = 1.0

    if s > 1e-6:
        # 2) upper feather: just after hi
        upper = (fwd > L) & (fwd < L + s)
        band[upper] = np.maximum(
            band[upper],
            1.0 - (fwd[upper] - L) / s
        )

        # 3) lower feather: just before lo (going backwards)
        lower = (bwd > 0) & (bwd < s)
        band[lower] = np.maximum(
            band[lower],
            1.0 - bwd[lower] / s
        )

    return np.clip(band, 0.0, 1.0).astype(np.float32)



def _hue_mask(img01: np.ndarray,
              ranges_deg: list[tuple[float,float]],
              min_chroma: float,
              min_light: float,
              max_light: float,
              smooth_deg: float,
              invert_range: bool = False,
              soft: bool = False) -> np.ndarray:
    """
    Return mask in 0..1 for the UNION of hue bands in ranges_deg (degrees).
    Handles wrap-around without recursion. If invert_range=True, selects the
    COMPLEMENT of the union on the hue circle (before chroma/light gating).
    """
    hsv  = _rgb_to_hsv01(img01)                 # H in [0..1)
    Hdeg = (np.mod(hsv[..., 0] * 360.0, 360.0)).astype(np.float32)
    S    = hsv[..., 1].astype(np.float32)
    V    = hsv[..., 2].astype(np.float32)

    m = np.zeros_like(Hdeg, dtype=np.float32)
    for lo, hi in ranges_deg:
        m = np.maximum(m, _hue_band(Hdeg, lo, hi, smooth_deg))

    # Invert selection on the hue circle if requested
    if invert_range:
        m = 1.0 - m

    # chroma/light gating
    if soft:
        #sasproportional selection: weight by how strongly the pixel is colored
        # (chroma) and feather the lightness limits, so the mask fades in/out
        # continuously instead of snapping. Edge pixels of a colored region are
        # naturally less saturated, so this softens hard, blobby boundaries.
        chroma = (S * V).astype(np.float32)
        c_lo = max(0.0, float(min_chroma))
        c_hi = min(1.0, c_lo + 0.35)   # only vivid color reaches full strength
        m *= _softstep(chroma, c_lo, c_hi)

        feather_l = 0.10
        if min_light > 0:
            m *= _softstep(V, max(0.0, float(min_light) - feather_l), float(min_light))
        if max_light < 1:
            m *= (1.0 - _softstep(V, float(max_light), min(1.0, float(max_light) + feather_l)))
    else:
        if min_chroma > 0:
            chroma = (S * V).astype(np.float32)
            m *= _softstep(chroma, float(min_chroma)*0.7, float(min_chroma))
        if min_light > 0:
            m *= (V >= float(min_light)).astype(np.float32)
        if max_light < 1:
            m *= (V <= float(max_light)).astype(np.float32)

    return np.clip(m, 0.0, 1.0)




def _weight_shadows_highlights(mask: np.ndarray,
                               img01: np.ndarray,
                               shadows: float,
                               highlights: float,
                               balance: float) -> np.ndarray:
    """
    New behavior:
    - `shadows` in [0..1]: pixels BELOW this luminance get faded OUT.
    - `highlights` in [0..1]: pixels ABOVE this luminance get faded OUT.
    - `balance` just tweaks feather width (optional).
    """
    L = _luminance01(img01).astype(np.float32)
    w = np.ones_like(L, dtype=np.float32)

    # feather size ~ 8% of range, you can tune this
    feather = 0.08 + 0.12 * balance  # 0.08..0.2

    # 1) shadow gate: fade OUT below `shadows`
    if shadows > 1e-3:
        s0 = max(0.0, shadows - feather)
        s1 = min(1.0, shadows + 1e-6)
        # below s0 → 0, above s1 → 1
        w *= _softstep(L, s0, s1)

    # 2) highlight gate: fade OUT above `highlights`
    if highlights < 0.999:
        h0 = max(0.0, highlights - 1e-6)
        h1 = min(1.0, highlights + feather)
        # below h0 → 1, above h1 → 0
        w *= (1.0 - _softstep(L, h0, h1))

    # apply to mask
    return np.clip(mask * w, 0.0, 1.0)


# ---------------------------------------------------------------------
# Color adjustments
# ---------------------------------------------------------------------

def _apply_selective_adjustments(img01: np.ndarray,
                                 mask01: np.ndarray,
                                 cyan: float, magenta: float, yellow: float,
                                 r: float, g: float, b: float,
                                 lum: float, chroma: float, sat: float, con: float,
                                 intensity: float,
                                 use_chroma_mode: bool) -> np.ndarray:

    """
    CMY/RGB sliders in [-1..+1] range (we’ll clamp).
    L/S/C also in [-1..+1].
    """
    a = img01.astype(np.float32, copy=True)
    m = np.clip(mask01.astype(np.float32) * float(intensity), 0.0, 1.0)

    # RGB base
    if a.ndim == 2:
        a = np.repeat(a[..., None], 3, axis=2)

    R = a[...,0]; G = a[...,1]; B = a[...,2]

    # CMY = reduce the complementary primary
    # Positive Cyan -> reduce Red; negative Cyan -> increase Red.
    R = np.clip(R + (-cyan) * m, 0.0, 1.0)
    G = np.clip(G + (-magenta) * m, 0.0, 1.0)
    B = np.clip(B + (-yellow) * m, 0.0, 1.0)

    # Primary boosts
    R = np.clip(R + r * m, 0.0, 1.0)
    G = np.clip(G + g * m, 0.0, 1.0)
    B = np.clip(B + b * m, 0.0, 1.0)

    out = np.stack([R,G,B], axis=-1)

    # L / Chroma-or-Sat / Contrast
    if any(abs(x) > 1e-6 for x in (lum, chroma, sat, con)):
        if abs(lum) > 0:
            out = np.clip(out + lum * m[..., None], 0.0, 1.0)

        if abs(con) > 0:
            out = np.clip((out - 0.5) * (1.0 + con * m[..., None]) + 0.5, 0.0, 1.0)

        if use_chroma_mode:
            if abs(chroma) > 0:
                out = _apply_chroma_boost(out, m, chroma)
        else:
            if abs(sat) > 0:
                hsv = _rgb_to_hsv01(out)
                hsv[..., 1] = np.clip(hsv[..., 1] * (1.0 + sat * m), 0.0, 1.0)
                # HSV->RGB using cv2 (expects 8-bit)
                hv = (hsv[..., 0] * 180.0).astype(np.uint8)
                sv = (hsv[..., 1] * 255.0).astype(np.uint8)
                vv = (hsv[..., 2] * 255.0).astype(np.uint8)
                hsv8 = np.stack([hv, sv, vv], axis=-1)
                rgb8 = cv2.cvtColor(hsv8, cv2.COLOR_HSV2RGB)
                out = rgb8.astype(np.float32) / 255.0

    return np.clip(out, 0.0, 1.0)

def _apply_chroma_boost(rgb01: np.ndarray, m01: np.ndarray, chroma: float) -> np.ndarray:
    """
    L-preserving chroma change:
      rgb' = Y + (rgb - Y) * (1 + chroma * m)
    where Y is luminance and m is the 0..1 mask (with intensity applied upstream).
    Positive chroma -> more colorfulness; negative -> less.
    """
    rgb = _ensure_rgb01(rgb01).astype(np.float32)
    m   = np.clip(m01.astype(np.float32), 0.0, 1.0)[..., None]
    Y   = _luminance01(rgb)[..., None]                 # HxWx1
    d   = rgb - Y                                      # chroma direction
    k   = (1.0 + float(chroma) * m)                    # scale per-pixel with mask
    out = Y + d * k
    return np.clip(out, 0.0, 1.0)


def _ensure_rgb01(img: np.ndarray) -> np.ndarray:
    """Return an RGB float image in [0,1]."""
    a = np.clip(img.astype(np.float32), 0.0, 1.0)
    if a.ndim == 2:
        a = np.repeat(a[..., None], 3, axis=2)
    return a

class HueWheel(QWidget):
    """
    A compact HSV hue wheel with two draggable handles for start/end (degrees 0..360).
    Emits rangeChanged(start_deg, end_deg) when either handle moves.
    """
    from PyQt6.QtCore import pyqtSignal
    rangeChanged = pyqtSignal(int, int)

    def __init__(self, start_deg=65, end_deg=158, parent=None):
        super().__init__(parent)
        self.setMinimumSize(160, 160)
        self._start = int(start_deg) % 360
        self._end   = int(end_deg)   % 360
        self._dragging = None  # "start" | "end" | None
        self._ring_img = None
        self._picked = None  # degrees or None

    # --- public API
    def setRange(self, start_deg: int, end_deg: int, notify=True):
        s = int(start_deg) % 360
        e = int(end_deg)   % 360
        if s == self._start and e == self._end:
            return
        self._start, self._end = s, e
        self.update()
        if notify:
            self.rangeChanged.emit(self._start, self._end)

    def range(self):
        return self._start, self._end

    def setPickedHue(self, deg: float | int | None):
        """Show a small marker on the wheel at the sampled hue (degrees)."""
        if deg is None:
            self._picked = None
        else:
            self._picked = int(deg) % 360
        self.update()

    # --- util
    @staticmethod
    def _ang_from_pos(cx, cy, x, y):
        import math
        a = math.degrees(math.atan2(y - cy, x - cx))
        a = (a + 360.0) % 360.0
        return a

    def _ensure_ring(self, side):
        # cache a color wheel image to paint fast
        if self._ring_img is not None and self._ring_img.width() == side and self._ring_img.height() == side:
            return
        import math
        side = int(side)
        img = np.zeros((side, side, 3), np.uint8)
        cx = cy = side // 2
        r  = int(side*0.48)
        rr2 = r*r
        for y in range(side):
            dy = y - cy
            for x in range(side):
                dx = x - cx
                d2 = dx*dx + dy*dy
                if rr2 - r*12 <= d2 <= rr2:  # thin ring
                    ang = self._ang_from_pos(cx, cy, x, y)
                    hsv = np.array([ang/2, 255, 255], np.uint8)   # H 0..180 in OpenCV
                    rgb = cv2.cvtColor(hsv[None,None,:], cv2.COLOR_HSV2RGB)[0,0]
                    img[y, x] = rgb
        h, w, _ = img.shape
        self._ring_img = QImage(img.data, w, h, img.strides[0], QImage.Format.Format_RGB888).copy()

    # --- events
    def paintEvent(self, ev):
        from PyQt6.QtGui import QPainter, QPen, QBrush, QColor
        p = QPainter(self)
        side = min(self.width(), self.height())
        self._ensure_ring(side)

        # center ring
        x0 = (self.width() - side)//2
        y0 = (self.height() - side)//2
        p.drawImage(x0, y0, self._ring_img)

        # draw handles & arc
        cx = x0 + side//2
        cy = y0 + side//2
        r  = int(side*0.48)

        def pt(ang_deg):
            import math
            th = math.radians(ang_deg)
            return int(cx + r*math.cos(th)), int(cy + r*math.sin(th))

        # --- RANGE ARC (match mask logic) ---
        # Mask defines band as positive arc from start -> end with L = (end - start) % 360.
        s, e = int(self._start) % 360, int(self._end) % 360
        L = (e - s) % 360  # arc length in degrees (0..359)
        steps = 60
        if L > 0:
            p.setPen(QPen(QColor(255, 255, 255, 140), 4))
            px, py = pt(s)
            for k in range(1, steps + 1):
                a = (s + (L * k) / steps) % 360  # move forward along the positive arc
                qx, qy = pt(a)
                p.drawLine(px, py, qx, qy)
                px, py = qx, qy

        # handles
        p.setBrush(QBrush(QColor(255,255,255)))
        p.setPen(QPen(QColor(0,0,0), 1))
        for ang in (self._start, self._end):
            xh, yh = pt(ang)
            p.drawEllipse(xh-5, yh-5, 10, 10)

        # sampled hue marker
        if self._picked is not None:
            import math
            th = math.radians(self._picked)
            px = int(cx + r*math.cos(th)); py = int(cy + r*math.sin(th))
            p.setBrush(QBrush(QColor(0, 0, 0)))
            p.setPen(QPen(QColor(255, 255, 255), 2))
            p.drawEllipse(px-6, py-6, 12, 12)


    def mousePressEvent(self, ev):
        x, y = ev.position().x(), ev.position().y()
        side = min(self.width(), self.height())
        x0 = (self.width() - side)//2
        y0 = (self.height() - side)//2
        cx = x0 + side//2
        cy = y0 + side//2
        a = self._ang_from_pos(cx, cy, x, y)
        # pick the nearest handle
        def d(a0, a1):
            dd = abs((a0 - a1 + 180) % 360 - 180)
            return dd
        if d(a, self._start) <= d(a, self._end):
            self._dragging = "start"
            self._start = int(a)
        else:
            self._dragging = "end"
            self._end = int(a)
        self.update()
        self.rangeChanged.emit(self._start, self._end)

    def mouseMoveEvent(self, ev):
        if not self._dragging:
            return
        x, y = ev.position().x(), ev.position().y()
        side = min(self.width(), self.height())
        x0 = (self.width() - side)//2
        y0 = (self.height() - side)//2
        cx = x0 + side//2
        cy = y0 + side//2
        a = int(self._ang_from_pos(cx, cy, x, y)) % 360
        if self._dragging == "start":
            self._start = a
        else:
            self._end = a
        self.update()
        self.rangeChanged.emit(self._start, self._end)

    def mouseReleaseEvent(self, ev):
        self._dragging = None


# ---------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------

class SelectiveColorCorrection(QDialog):
    """
    v1.0 — live preview, mask overlay, presets + custom hue range,
    CMY/RGB + L/S/C sliders. Loads active document's image.
    """
    def __init__(self, doc_manager=None, document=None, parent=None, window_icon: QIcon | None = None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Selective Color Correction"))
        if window_icon:
            self.setWindowIcon(window_icon)
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        except Exception:
            pass  # older PyQt6 versions
        self.docman = doc_manager
        self.document = document
        if self.document is None or getattr(self.document, "image", None) is None:
            QMessageBox.information(self, "No image", "Open an image first.")
            self.close(); return

        self.img = np.clip(self.document.image.astype(np.float32), 0.0, 1.0)
        self.preview_img = self.img.copy()
        self._syncing_hue = False
        self._imported_mask_full = None     # full-res mask (H x W) float32 0..1
        self._imported_mask_name = None     # nice label to show in UI
        self._use_imported_mask = False     # checkbox state mirror
        self._mask_delay_ms = 200
        self._adj_delay_ms  = 200
        self._region_mask_full = None    # full-res binary region mask (H x W) float32
        self._lasso_points = []          # list of (x,y) in label coords while drawing
        self._lasso_drawing = False
        self._lasso_overlay = None       # QPixmap overlay for live lasso feedback        
        self._build_ui()
        self._mask_delay_ms = 200  # 0.2s idle before recomputing mask
        self._mask_timer = QTimer(self)
        self._mask_timer.setSingleShot(True)
        self._mask_timer.timeout.connect(self._recompute_mask_and_preview)   
        self._adj_delay_ms = 200
        self._adj_timer = QTimer(self)
        self._adj_timer.setSingleShot(True)
        self._adj_timer.timeout.connect(self._update_preview_pixmap)    
        self.dd_preset.setCurrentText("Red")
        self._setting_preset = False
        self._recompute_mask_and_preview()
        self._panning = False
        self._pan_start_pos = None       # QPointF in label coords
        self._pan_start_scroll = (0, 0)  # (hval, vval)    
        self._pan_deadzone = 1   
        self._pan_start_pos_vp = None 

    # ------------- UI -------------
    def _build_ui(self):
        # --- Root layout -------------------------------------------------------
        root = QHBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(10)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(6)
        root.addWidget(self.splitter)

        # ======================================================================
        # LEFT PANE  (header → "small preview" toggle → scroller → live toggle → buttons)
        # ======================================================================
        left_widget = QWidget()
        left_widget.setMinimumWidth(360)
        left_widget.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        self.splitter.addWidget(left_widget)

        left_outer = QVBoxLayout(left_widget)
        left_outer.setContentsMargins(0, 0, 0, 0)
        left_outer.setSpacing(8)

        # Header (target view label)
        try:
            disp = getattr(self.document, "display_name", lambda: "Image")()
        except Exception:
            disp = "Image"
        self.lbl_target = QLabel(f"Target View:  <b>{disp}</b>")
        left_outer.addWidget(self.lbl_target)

        # Small/fast preview toggle
        self.cb_small_preview = QCheckBox("Small-sized Preview (fast)")
        self.cb_small_preview.setChecked(True)
        self.cb_small_preview.toggled.connect(self._recompute_mask_and_preview)
        left_outer.addWidget(self.cb_small_preview)

        # ---------- SCROLLABLE CONTROLS (placed inside a QScrollArea) ----------
        controls_container = QWidget()
        left = QVBoxLayout(controls_container)
        left.setContentsMargins(0, 0, 0, 0)
        left.setSpacing(8)

        # ===== Mask group
        gb_mask = QGroupBox(self.tr("Mask"))
        gl = QGridLayout(gb_mask)
        gl.setContentsMargins(8, 8, 8, 8)
        gl.setHorizontalSpacing(10)
        gl.setVerticalSpacing(8)

        # Row 0: Preset
        gl.addWidget(QLabel("Preset:"), 0, 0)
        self.dd_preset = QComboBox()
        self.dd_preset.addItems(["Custom"] + list(_PRESETS.keys()))
        self.dd_preset.currentTextChanged.connect(self._on_preset_change)
        gl.addWidget(self.dd_preset, 0, 1, 1, 4)

        # Hue wheel
        self.hue_wheel = HueWheel(start_deg=65, end_deg=158)
        self.hue_wheel.setMinimumSize(130, 130)
        self.hue_wheel.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
        gl.addWidget(self.hue_wheel, 1, 0, 7, 2)

        # Wheel -> sliders/spins (so dragging wheel updates UI and mask)
        def _wheel_to_sliders(s: int, e: int):
            # If user is dragging the wheel, we’re now custom
            if not self._setting_preset and self.dd_preset.currentText() != "Custom":
                self.dd_preset.blockSignals(True)
                self.dd_preset.setCurrentText("Custom")
                self.dd_preset.blockSignals(False)

            # Update BOTH sliders and spins, without ping-pong
            self._syncing_hue = True
            try:
                s = int(s) % 360
                e = int(e) % 360

                for w, val in (
                    (self.sl_h1, s), (self.sp_h1, s),
                    (self.sl_h2, e), (self.sp_h2, e),
                ):
                    w.blockSignals(True)
                    w.setValue(val)
                    w.blockSignals(False)
            finally:
                self._syncing_hue = False

            self._schedule_mask()

        self.hue_wheel.rangeChanged.connect(_wheel_to_sliders)



        # Helper: integer slider + spin (0..360)
        def _deg_pair(grid: QGridLayout, label: str, row: int):
            grid.addWidget(QLabel(label), row, 2)
            sld = QSlider(Qt.Orientation.Horizontal)
            sld.setRange(0, 360); sld.setSingleStep(1); sld.setPageStep(10)
            spn = QSpinBox(); spn.setRange(0, 360)
            sld.valueChanged.connect(spn.setValue)
            spn.valueChanged.connect(sld.setValue)
            grid.addWidget(sld, row, 3, 1, 3)
            grid.addWidget(spn, row, 6, 1, 1)
            return sld, spn

        # Rows 1–2: Hue Start/End
        self.sl_h1, self.sp_h1 = _deg_pair(gl, "Hue start (°):", 1)
        self.sl_h2, self.sp_h2 = _deg_pair(gl, "Hue end (°):",   2)
        self.sp_h1.setValue(65); self.sp_h2.setValue(158)

        # Row 3: chroma + lightness
        gl.addWidget(QLabel("Min chroma:"), 3, 2)
        self.ds_minC = QDoubleSpinBox(); self.ds_minC.setRange(0,1); self.ds_minC.setSingleStep(0.05); self.ds_minC.setValue(0.05)

        self.ds_minC.valueChanged.connect(self._recompute_mask_and_preview)
        gl.addWidget(self.ds_minC, 3, 3)

        gl.addWidget(QLabel("Lightness min/max:"), 3, 4)
        self.ds_minL = QDoubleSpinBox(); self.ds_minL.setRange(0,1); self.ds_minL.setSingleStep(0.05); self.ds_minL.setValue(0.0)
        self.ds_maxL = QDoubleSpinBox(); self.ds_maxL.setRange(0,1); self.ds_maxL.setSingleStep(0.05); self.ds_maxL.setValue(1.0)
        self.ds_minL.valueChanged.connect(self._recompute_mask_and_preview)
        self.ds_maxL.valueChanged.connect(self._recompute_mask_and_preview)
        gl.addWidget(self.ds_minL, 3, 5)
        gl.addWidget(QLabel("to"), 3, 6)
        gl.addWidget(self.ds_maxL, 3, 7)

        # Row 4: smoothness + invert
        gl.addWidget(QLabel("Smoothness (deg):"), 4, 2)
        self.ds_smooth = QDoubleSpinBox(); self.ds_smooth.setRange(0,60); self.ds_smooth.setSingleStep(1.0); self.ds_smooth.setValue(10.0)
        self.ds_smooth.valueChanged.connect(self._recompute_mask_and_preview)
        gl.addWidget(self.ds_smooth, 4, 3)

        self.cb_invert = QCheckBox("Invert hue range")
        self.cb_invert.setChecked(False)
        self.cb_invert.toggled.connect(self._recompute_mask_and_preview)
        gl.addWidget(self.cb_invert, 4, 4, 1, 3)

        # Row 5: shadows/highlights + intensity
        gl.addWidget(QLabel("Shadows:"), 5, 2)
        self.ds_sh = QDoubleSpinBox(); self.ds_sh.setRange(0,1); self.ds_sh.setSingleStep(0.05); self.ds_sh.setValue(0.0)
        self.ds_sh.valueChanged.connect(self._recompute_mask_and_preview)
        gl.addWidget(self.ds_sh, 5, 3)

        gl.addWidget(QLabel("Highlights:"), 5, 4)
        self.ds_hi = QDoubleSpinBox(); self.ds_hi.setRange(0,1); self.ds_hi.setSingleStep(0.05); self.ds_hi.setValue(1.0)
        self.ds_hi.valueChanged.connect(self._recompute_mask_and_preview)
        gl.addWidget(self.ds_hi, 5, 5)

        self.ds_bal = QDoubleSpinBox(); self.ds_bal.setRange(0,1); self.ds_bal.setSingleStep(0.05); self.ds_bal.setValue(0.5)
        self.ds_bal.valueChanged.connect(self._recompute_mask_and_preview)
        self.ds_bal.setVisible(False)  # used in math, hidden in UI

        gl.addWidget(QLabel("Intensity:"), 5, 6)
        self.ds_int = QDoubleSpinBox(); self.ds_int.setRange(0, 2.0); self.ds_int.setSingleStep(0.05); self.ds_int.setValue(1.0)
        self.ds_int.valueChanged.connect(self._recompute_mask_and_preview)
        gl.addWidget(self.ds_int, 5, 7)

        # Row 6: blur + overlay
        gl.addWidget(QLabel("Edge blur (px):"), 6, 2)
        self.sb_blur = QSpinBox(); self.sb_blur.setRange(0, 150); self.sb_blur.setValue(0)
        self.sb_blur.valueChanged.connect(self._recompute_mask_and_preview)
        gl.addWidget(self.sb_blur, 6, 3)

        self.cb_show_mask = QCheckBox("Show mask overlay")
        self.cb_show_mask.setChecked(False)
        self.cb_show_mask.toggled.connect(self._update_preview_pixmap)
        gl.addWidget(self.cb_show_mask, 6, 4, 1, 2)

        # Soft (proportional) mask: weight by how strongly each pixel matches the
        # selected color instead of a hard in/out selection -> fewer blobby edges.
        self.cb_soft_mask = QCheckBox("Soft (proportional)")
        self.cb_soft_mask.setChecked(False)
        self.cb_soft_mask.setToolTip(
            "Weight the mask by how strongly each pixel matches the color "
            "(chroma), and feather the lightness limits, instead of a hard "
            "in/out selection. Softens blobby, hard-edged corrections."
        )
        self.cb_soft_mask.toggled.connect(self._recompute_mask_and_preview)
        gl.addWidget(self.cb_soft_mask, 6, 6, 1, 2)

        # Row 7: imported mask
        self.cb_use_imported = QCheckBox("Use imported mask")
        self.cb_use_imported.setChecked(False)
        self.cb_use_imported.toggled.connect(self._on_use_imported_mask_toggled)
        gl.addWidget(self.cb_use_imported, 7, 2, 1, 2)

        self.btn_import_mask = QPushButton("Pick mask from view…")
        self.btn_import_mask.clicked.connect(self._import_mask_from_view)
        gl.addWidget(self.btn_import_mask, 7, 4, 1, 2)

        self.lbl_imported_mask = QLabel("No imported mask")
        gl.addWidget(self.lbl_imported_mask, 7, 6, 1, 2)

        # Column sizing
        gl.setColumnStretch(0, 0)
        gl.setColumnStretch(1, 0)
        for c in (2,3,4,5,6,7):
            gl.setColumnStretch(c, 1)

        left.addWidget(gb_mask)

        # ===== Adjustments
        # CMY
        gb_cmy = QGroupBox(self.tr("Complementary colors (CMY)"))
        glc = QGridLayout(gb_cmy)
        self.sl_c, self.ds_c = self._slider_pair(glc, "Cyan:",    0)
        self.sl_m, self.ds_m = self._slider_pair(glc, "Magenta:", 1)
        self.sl_y, self.ds_y = self._slider_pair(glc, "Yellow:",  2)
        left.addWidget(gb_cmy)

        # RGB
        gb_rgb = QGroupBox(self.tr("RGB Colors"))
        glr = QGridLayout(gb_rgb)
        self.sl_r, self.ds_r = self._slider_pair(glr, "Red:",   0)
        self.sl_g, self.ds_g = self._slider_pair(glr, "Green:", 1)
        self.sl_b, self.ds_b = self._slider_pair(glr, "Blue:",  2)
        left.addWidget(gb_rgb)

        # LSC
        gb_lsc = QGroupBox(self.tr("Luminance, Chroma/Saturation, Contrast"))
        gll = QGridLayout(gb_lsc)
        self.sl_l, self.ds_l           = self._slider_pair(gll, "Luminance:",  0)
        self.sl_chroma, self.ds_chroma = self._slider_pair(gll, "Chroma (L-preserving):", 1)
        self.sl_s, self.ds_s           = self._slider_pair(gll, "Saturation (HSV S):", 2)
        self.sl_c2, self.ds_c2         = self._slider_pair(gll, "Contrast:",  3)
        gll.addWidget(QLabel("Color boost mode:"), 4, 0)
        self.dd_color_mode = QComboBox()
        self.dd_color_mode.addItems(["Chroma (L-preserving)", "Saturation (HSV S)"])
        self.dd_color_mode.setCurrentIndex(0)
        self.dd_color_mode.currentIndexChanged.connect(self._update_color_mode_enabled)
        gll.addWidget(self.dd_color_mode, 4, 1, 1, 2)
        left.addWidget(gb_lsc)

        # Wrap controls in a scroller (horizontal scroll allowed if needed)
        left_scroll = QScrollArea()
        left_scroll.setWidget(controls_container)
        left_scroll.setWidgetResizable(False)
        left_scroll.setFrameShape(QFrame.Shape.NoFrame)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        left_scroll.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        left_outer.addWidget(left_scroll, 1)

        # Live toggle (non-scroll)
        self.cb_live = QCheckBox("Preview changed image")
        self.cb_live.setChecked(True)
        self.cb_live.toggled.connect(self._update_preview_pixmap)
        left_outer.addWidget(self.cb_live)

        # Buttons row (non-scroll)
        row = QHBoxLayout()
        self.btn_apply = QPushButton("Apply")
        self.btn_apply.clicked.connect(self._apply_to_document)
        self.btn_push = QPushButton("Apply as New Document")
        self.btn_push.clicked.connect(self._apply_as_new_doc)
        self.btn_export_mask = QPushButton("Export Mask")
        self.btn_export_mask.clicked.connect(self._export_mask_doc)
        self.btn_reset = QPushButton("↺ Reset")
        self.btn_reset.clicked.connect(self._reset_controls)
        self.btn_clear_region = QPushButton("✕ Clear Region Mask")
        self.btn_clear_region.setToolTip("Remove the freehand region constraint")
        self.btn_clear_region.clicked.connect(self._clear_region_mask)
        self.btn_clear_region.setEnabled(False)        
        row.addWidget(self.btn_apply)
        row.addWidget(self.btn_push)
        row.addWidget(self.btn_export_mask)
        row.addWidget(self.btn_reset)
        row.addWidget(self.btn_clear_region)
        left_outer.addLayout(row)

        # ======================================================================
        # RIGHT PANE  (zoom toolbar + preview scroller + picked hue readout)
        # ======================================================================
        right_widget = QWidget()
        right_widget.setMinimumWidth(420)
        right_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.splitter.addWidget(right_widget)

        right = QVBoxLayout(right_widget)
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(8)

        # Zoom toolbar (themed)
        zoom_row = QHBoxLayout()

        self.btn_zoom_out = themed_toolbtn("zoom-out", "Zoom Out")
        self.btn_zoom_in  = themed_toolbtn("zoom-in", "Zoom In")
        self.btn_zoom_1   = themed_toolbtn("zoom-original", "1:1")
        self.btn_fit      = themed_toolbtn("zoom-fit-best", "Fit")

        zoom_row.addWidget(self.btn_zoom_out)
        zoom_row.addWidget(self.btn_zoom_in)
        zoom_row.addWidget(self.btn_zoom_1)
        zoom_row.addWidget(self.btn_fit)
        zoom_row.addStretch(1)
        self.btn_doc_help = make_help_button("selective_color", self)
        zoom_row.addWidget(self.btn_doc_help)
        right.addLayout(zoom_row)

        self.lbl_help = QLabel(
            "🖱️ <b>Click</b>: show hue  &nbsp;•&nbsp; "
            "<b>Shift+Click</b>: select that color  &nbsp;•&nbsp; "
            "<b>Ctrl+Drag</b>: pan  &nbsp;•&nbsp; "
            "<b>Alt+Drag</b>: draw region mask  &nbsp;•&nbsp; "
            "<b>Wheel</b>: zoom"
        )

        self.lbl_help.setWordWrap(True)
        self.lbl_help.setTextFormat(Qt.TextFormat.RichText)
        self.lbl_help.setStyleSheet("color: #888; font-size: 11px;")
        right.addWidget(self.lbl_help)

        # Preview scroller
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(False)
        self.lbl_preview = QLabel()
        self.lbl_preview.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self.lbl_preview.setMinimumSize(10, 10)
        self.scroll.setWidget(self.lbl_preview)
        right.addWidget(self.scroll, 1)

        vp = self.scroll.viewport()
        vp.setMouseTracking(True)
        vp.installEventFilter(self)

        self.lbl_preview.setToolTip(
            "Click to sample hue.\n"
            "Ctrl + Click & Drag to pan.\n"
            "Mouse Wheel to zoom."
        )
        self.btn_zoom_in.setToolTip("Zoom in (centers view)")
        self.btn_zoom_out.setToolTip("Zoom out (centers view)")
        self.btn_zoom_1.setToolTip("Reset zoom to 1:1")

        # Hue readout
        self.lbl_hue_readout = QLabel("Picked hue: —")
        right.addWidget(self.lbl_hue_readout)
        self.lbl_region_readout = QLabel("Region mask: none  (Alt+Drag to draw)")
        self.lbl_region_readout.setStyleSheet("color: #888; font-size: 11px;")
        right.addWidget(self.lbl_region_readout)
        # Splitter stretch: make preview greedy
        self.splitter.setStretchFactor(0, 0)  # left
        self.splitter.setStretchFactor(1, 1)  # right
        self.splitter.setSizes([420, 900])

        # Clamp dialog height and add size grip
        self.setSizeGripEnabled(True)
        try:
            g = QGuiApplication.primaryScreen().availableGeometry()
            max_h = int(g.height() * 0.9)
            self.resize(1080, min(680, max_h))
            self.setMaximumHeight(max_h)
        except Exception:
            self.resize(1080, 680)

        # ---- Wiring that depends on built widgets ----------------------------
        self._update_color_mode_enabled()
        for w in (self.ds_c, self.ds_m, self.ds_y, self.ds_r, self.ds_g, self.ds_b, self.ds_l, self.ds_s, self.ds_c2, self.ds_int):
            w.valueChanged.connect(self._schedule_adjustments)

        def _sliders_to_wheel(_=None):
            if getattr(self, "_syncing_hue", False):
                return

            if not self._setting_preset and self.dd_preset.currentText() != "Custom":
                self.dd_preset.blockSignals(True)
                self.dd_preset.setCurrentText("Custom")
                self.dd_preset.blockSignals(False)

            s = int(self.sp_h1.value())
            e = int(self.sp_h2.value())
            self.hue_wheel.setRange(s, e, notify=False)
            self._schedule_mask()


        self.sp_h1.valueChanged.connect(_sliders_to_wheel)
        self.sp_h2.valueChanged.connect(_sliders_to_wheel)
        self.sl_h1.valueChanged.connect(_sliders_to_wheel)
        self.sl_h2.valueChanged.connect(_sliders_to_wheel)

        # Zoom behavior
        self._zoom = 1.0


        self.btn_zoom_in.clicked.connect(lambda: self._apply_zoom(self._zoom * 1.25, None))
        self.btn_zoom_out.clicked.connect(lambda: self._apply_zoom(self._zoom / 1.25, None))
        self.btn_zoom_1.clicked.connect(lambda: self._apply_zoom(1.0, None))

        # Preview interactions
        self.lbl_preview.setMouseTracking(True)
        self.lbl_preview.installEventFilter(self)
        try:
            self.splitter.splitterMoved.connect(lambda *_: self._save_window_state())
        except Exception:
            pass
        # First paint
        self._update_preview_pixmap()

    # --- Lasso helpers ---------------------------------------------------
    def _clear_region_mask(self):
        self._region_mask_full = None
        self._lasso_points = []
        self._lasso_overlay = None
        self.lbl_region_readout.setText("Region mask: none  (Alt+Drag to draw)")
        self.btn_clear_region.setEnabled(False)
        self._recompute_mask_and_preview()

    def _lasso_to_region_mask(self, points_label: list, base_shape: tuple) -> np.ndarray:
        """
        Convert lasso points (in label/zoomed coords) to a full-res binary mask.
        points_label: list of (x, y) in label pixel coords
        base_shape: (H, W) of the base image
        """
        if len(points_label) < 3:
            return None

        bh, bw = base_shape[:2]

        # Convert label coords → base image coords
        z = max(self._zoom, 1e-6)
        pts_img = [(x / z, y / z) for x, y in points_label]

        # Build polygon mask using cv2 fillPoly
        if cv2 is not None:
            pts_arr = np.array(pts_img, dtype=np.int32)
            mask = np.zeros((bh, bw), dtype=np.uint8)
            cv2.fillPoly(mask, [pts_arr], 255)
            return mask.astype(np.float32) / 255.0
        else:
            # Pure numpy fallback — scanline fill
            from matplotlib.path import Path
            path = Path(pts_img)
            yy, xx = np.mgrid[0:bh, 0:bw]
            coords = np.column_stack([xx.ravel(), yy.ravel()])
            inside = path.contains_points(coords)
            return inside.reshape(bh, bw).astype(np.float32)

    def _draw_lasso_overlay(self):
        """Draw the current lasso as a dashed orange outline with transparent fill."""
        if not self._lasso_points:
            return

        # Get the current pixmap — regenerate it clean first so we don't stack overlays
        base = getattr(self, "_last_base", None)
        if base is None:
            return

        # Re-render base preview without triggering full recompute
        mask = getattr(self, "_mask", np.zeros(base.shape[:2], np.float32))
        if self.cb_live.isChecked():
            out = _apply_selective_adjustments(
                base, mask,
                cyan=float(self.ds_c.value()),
                magenta=float(self.ds_m.value()),
                yellow=float(self.ds_y.value()),
                r=float(self.ds_r.value()),
                g=float(self.ds_g.value()),
                b=float(self.ds_b.value()),
                lum=float(self.ds_l.value()),
                chroma=float(self.ds_chroma.value()),
                sat=float(self.ds_s.value()),
                con=float(self.ds_c2.value()),
                intensity=float(self.ds_int.value()),
                use_chroma_mode=(self.dd_color_mode.currentIndex() == 0),
            )
            out = _ensure_rgb01(out)
        else:
            out = _ensure_rgb01(base)

        if self.cb_show_mask.isChecked():
            out = self._overlay_mask(out, mask * float(self.ds_int.value()))

        pm = _to_pixmap(out)
        h, w = out.shape[:2]
        zw = max(1, int(round(w * self._zoom)))
        zh = max(1, int(round(h * self._zoom)))
        pm_scaled = pm.scaled(zw, zh, Qt.AspectRatioMode.IgnoreAspectRatio,
                              Qt.TransformationMode.SmoothTransformation)

        # Now paint the lasso on top
        from PyQt6.QtGui import QPainter, QPen, QColor, QPainterPath
        overlay = pm_scaled.copy()
        painter = QPainter(overlay)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        if len(self._lasso_points) > 2:
            path = QPainterPath()
            path.moveTo(*self._lasso_points[0])
            for px, py in self._lasso_points[1:]:
                path.lineTo(px, py)
            path.closeSubpath()
            # Transparent orange fill
            painter.fillPath(path, QColor(255, 165, 0, 35))

        # Dashed orange outline
        pen = QPen(QColor(255, 165, 0), 1)
        pen.setStyle(Qt.PenStyle.DashLine)
        painter.setPen(pen)
        for i in range(1, len(self._lasso_points)):
            x0, y0 = self._lasso_points[i-1]
            x1, y1 = self._lasso_points[i]
            painter.drawLine(int(x0), int(y0), int(x1), int(y1))

        # Closing line back to start
        if len(self._lasso_points) > 2:
            x0, y0 = self._lasso_points[-1]
            x1, y1 = self._lasso_points[0]
            painter.setPen(QPen(QColor(255, 165, 0, 120), 1, Qt.PenStyle.DotLine))
            painter.drawLine(int(x0), int(y0), int(x1), int(y1))

        painter.end()
        self.lbl_preview.setPixmap(overlay)
        self.lbl_preview.resize(zw, zh)
    # --- Zoom helpers ----------------------------------------------------
    def _current_scroll(self):
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()
        return hbar.value(), vbar.value(), hbar.maximum(), vbar.maximum()

    def _set_scroll(self, x, y):
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()
        hbar.setValue(int(max(0, min(x, hbar.maximum()))))
        vbar.setValue(int(max(0, min(y, vbar.maximum()))))

    def _apply_zoom(self, new_zoom: float, anchor_label_pos=None):
        """
        new_zoom: float
        anchor_label_pos: QPointF in *label (content)* coords to keep fixed on screen.
                        If None, use viewport center.
        """
        old_zoom = getattr(self, "_zoom", 1.0)
        new_zoom = max(0.05, min(16.0, float(new_zoom)))
        if abs(new_zoom - old_zoom) < 1e-6:
            return

        # Figure out the anchor (content coords)
        if anchor_label_pos is None:
            # viewport center → content coords
            sx, sy, _, _ = self._current_scroll()
            vp = self.scroll.viewport().rect()
            cx = (sx + vp.width()  / 2.0) / max(old_zoom, 1e-9)
            cy = (sy + vp.height() / 2.0) / max(old_zoom, 1e-9)
        else:
            cx = float(anchor_label_pos.x()) / max(1.0, 1.0)  # label coords already in content space
            cy = float(anchor_label_pos.y()) / max(1.0, 1.0)

        # Where is that content point on the viewport *before* zoom?
        sx, sy, _, _ = self._current_scroll()
        vp = self.scroll.viewport().rect()
        pvx = cx * old_zoom - sx   # pixel pos in viewport
        pvy = cy * old_zoom - sy

        # Apply zoom and repaint
        self._zoom = new_zoom
        self._update_preview_pixmap()

        # Set scroll so that the same content point stays at the same viewport pixel
        nx = cx * new_zoom - pvx
        ny = cy * new_zoom - pvy
        self._set_scroll(nx, ny)

    def _fit_to_preview(self):
        if not hasattr(self, "_base_pm") or self._base_pm is None:
            return
        vp = self.scroll.viewport().size()
        pm = self._base_pm.size()
        if pm.width() <= 0 or pm.height() <= 0:
            return
        k = min(vp.width() / pm.width(), vp.height() / pm.height())
        self._apply_zoom(k, anchor_label_pos=None)

    # --- Pan helpers -----------------------------------------------------
    def _begin_pan(self, pos_label):
        self._panning = True
        self._pan_start_pos = pos_label
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()
        self._pan_start_scroll = (hbar.value(), vbar.value())
        try:
            self.lbl_preview.setCursor(Qt.CursorShape.ClosedHandCursor)
        except Exception:
            pass

    def _update_pan(self, pos_label):
        if not self._panning or self._pan_start_pos is None:
            return
        dx = pos_label.x() - self._pan_start_pos.x()  # label pixels
        dy = pos_label.y() - self._pan_start_pos.y()
        sx0, sy0 = self._pan_start_scroll
        # invert to move content with the mouse
        self._set_scroll(sx0 - dx, sy0 - dy)

    def _end_pan(self):
        self._panning = False
        self._pan_start_pos = None
        try:
            self.lbl_preview.setCursor(Qt.CursorShape.ArrowCursor)
        except Exception:
            pass


    def _update_color_mode_enabled(self):
        use_chroma = (self.dd_color_mode.currentIndex() == 0)
        # enable Chroma controls when chroma mode; disable Sat controls, and vice versa
        self.ds_chroma.setEnabled(use_chroma); self.sl_chroma.setEnabled(use_chroma)
        self.ds_s.setEnabled(not use_chroma);  self.sl_s.setEnabled(not use_chroma)
        # refresh preview
        self._schedule_adjustments()


    def _set_pair(self, sld: QSlider, box: QDoubleSpinBox, value: float):
        # block both sides to avoid ping-pong and callbacks
        sld.blockSignals(True); box.blockSignals(True)
        sld.setValue(int(round(value * 1000)))  # because slider units are *1000
        box.setValue(float(value))
        sld.blockSignals(False); box.blockSignals(False)


    def _reset_controls(self):
        """Reset all UI controls to defaults and rebuild mask/preview on current self.img."""
        # pause timers while resetting
        self._mask_timer.stop()
        self._adj_timer.stop()

        # --- Preset: make 'Red' the default and let _on_preset_change drive the wheel/sliders ---
        # IMPORTANT: do NOT overwrite with 'Custom' afterwards.
        self._setting_preset = True
        try:
            # This emits currentTextChanged -> _on_preset_change(), which:
            #  - sets the hue_wheel to the preset range (notify=False)
            #  - sets sp_h1/sp_h2 to the preset lo/hi
            #  - calls _recompute_mask_and_preview()
            self.dd_preset.setCurrentText("Red")
        finally:
            self._setting_preset = False

        # --- Mask gating defaults (won't change the preset/wheel) ---
        def setv(w, val):
            w.blockSignals(True)
            if isinstance(w, (QDoubleSpinBox, QSpinBox)):
                w.setValue(val)
            elif isinstance(w, QCheckBox):
                w.setChecked(bool(val))
            elif isinstance(w, QComboBox):
                idx = w.findText(val)
                if idx >= 0:
                    w.setCurrentIndex(idx)
            elif isinstance(w, QSlider):
                w.setValue(int(val))
            w.blockSignals(False)

        setv(self.ds_minC, 0.05)
        setv(self.ds_minL, 0.0)
        setv(self.ds_maxL, 1.0)
        setv(self.ds_smooth, 10.0)
        setv(self.cb_invert, False)
        setv(self.cb_soft_mask, False)

        # Shadows/Highlights/Balance
        setv(self.ds_sh, 0.0)
        setv(self.ds_hi, 1.0)
        setv(self.ds_bal, 0.5)

        # Blur / overlays / preview
        setv(self.sb_blur, 0)
        setv(self.cb_show_mask, False)
        # keep user’s small/large preview choice & zoom as-is

        # CMY/RGB/LSC back to 0, intensity to 1.0
        self._set_pair(self.sl_c,  self.ds_c,  0.0)
        self._set_pair(self.sl_m,  self.ds_m,  0.0)
        self._set_pair(self.sl_y,  self.ds_y,  0.0)
        self._set_pair(self.sl_r,  self.ds_r,  0.0)
        self._set_pair(self.sl_g,  self.ds_g,  0.0)
        self._set_pair(self.sl_b,  self.ds_b,  0.0)
        self._set_pair(self.sl_l,  self.ds_l,  0.0)
        self._set_pair(self.sl_s,  self.ds_s,  0.0)
        self._set_pair(self.sl_c2, self.ds_c2, 0.0)

        self._set_pair(self.sl_chroma, self.ds_chroma, 0.0)
        # default to Chroma mode
        self.dd_color_mode.blockSignals(True)
        self.dd_color_mode.setCurrentIndex(0)
        self.dd_color_mode.blockSignals(False)
        self._update_color_mode_enabled()

        self.ds_int.blockSignals(True)
        self.ds_int.setValue(1.0)
        self.ds_int.blockSignals(False)

        # Clear any sampled hue marker on the wheel
        self.hue_wheel.setPickedHue(None)

        # Rebuild preview (preset handler already recomputed the mask, but this is safe)
        self._recompute_mask_and_preview()


    def _schedule_adjustments(self, *_, delay_ms: int | None = None):
        if delay_ms is None:
            delay_ms = getattr(self, "_adj_delay_ms", 200)

        if not hasattr(self, "_adj_timer"):
            return

        ms = max(1, int(delay_ms))  # never allow 0/negative
        self._adj_timer.stop()
        self._adj_timer.start(ms)

    def _schedule_mask(self, *_, delay_ms: int | None = None):
        if delay_ms is None:
            delay_ms = getattr(self, "_mask_delay_ms", 200)

        if not hasattr(self, "_mask_timer"):
            return

        ms = max(1, int(delay_ms))
        self._mask_timer.stop()
        self._mask_timer.start(ms)


    def _sample_hue_deg_from_base(self, x: int, y: int) -> float | None:
        """Return hue in degrees at (x,y) in _last_base (float RGB in [0,1])."""
        base = getattr(self, "_last_base", None)
        if base is None:
            return None
        h, w = base.shape[:2]
        if not (0 <= x < w and 0 <= y < h):
            return None
        pix = base[y:y+1, x:x+1, :] if base.ndim == 3 else np.repeat(base[y:y+1, x:x+1][...,None], 3, axis=2)
        hsv = _rgb_to_hsv01(pix)  # 1x1x3, H in [0,1]
        return float(hsv[0,0,0] * 360.0)

    def _map_label_point_to_image_xy(self, ev_pos):
        """Map a click on the *label* to base image (x,y), accounting for zoom."""
        base = getattr(self, "_last_base", None)
        if base is None:
            return None
        bh, bw = base.shape[:2]
        # ev_pos is in the label's local coordinates
        x = int(round(ev_pos.x() / max(self._zoom, 1e-6)))
        y = int(round(ev_pos.y() / max(self._zoom, 1e-6)))
        if x < 0 or y < 0 or x >= bw or y >= bh:
            return None
        return (x, y)

    def _draw_region_outline_on_pixmap(self, pm: QPixmap) -> QPixmap:
        """
        If a region mask is active, draw its outline as a dashed orange border
        on the given pixmap. Returns a new pixmap with the outline painted on it.
        """
        if self._region_mask_full is None:
            return pm

        # Get the contour of the region mask at preview resolution
        if cv2 is None:
            return pm

        bh, bw = self._region_mask_full.shape[:2]
        # Scale region mask to current zoom/preview size
        pw = pm.width()
        ph = pm.height()

        try:
            rm_preview = cv2.resize(
                self._region_mask_full, (pw, ph),
                interpolation=cv2.INTER_NEAREST)
            rm_u8 = (rm_preview * 255).astype(np.uint8)
            contours, _ = cv2.findContours(
                rm_u8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        except Exception:
            return pm

        from PyQt6.QtGui import QPainter, QPen, QColor
        result = pm.copy()
        painter = QPainter(result)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Outer glow — thicker semi-transparent line
        pen_glow = QPen(QColor(255, 165, 0, 80), 4)
        pen_glow.setStyle(Qt.PenStyle.SolidLine)
        painter.setPen(pen_glow)
        for contour in contours:
            pts = contour.reshape(-1, 2)
            for i in range(len(pts)):
                x0, y0 = int(pts[i][0]),   int(pts[i][1])
                x1, y1 = int(pts[(i+1) % len(pts)][0]), int(pts[(i+1) % len(pts)][1])
                painter.drawLine(x0, y0, x1, y1)

        # Dashed orange outline on top
        pen_dash = QPen(QColor(255, 165, 0), 2)
        pen_dash.setStyle(Qt.PenStyle.DashLine)
        pen_dash.setDashPattern([6, 4])
        painter.setPen(pen_dash)
        for contour in contours:
            pts = contour.reshape(-1, 2)
            for i in range(len(pts)):
                x0, y0 = int(pts[i][0]),   int(pts[i][1])
                x1, y1 = int(pts[(i+1) % len(pts)][0]), int(pts[(i+1) % len(pts)][1])
                painter.drawLine(x0, y0, x1, y1)

        painter.end()
        return result

    def eventFilter(self, obj, ev):
        from PyQt6.QtCore import QEvent, Qt

        # Helper: get event position in *viewport* coords regardless of target
        def _pos_in_viewport(o, e):
            if o is self.scroll.viewport():
                return e.position()  # already viewport coords (QPointF)
            # map label-local → viewport
            return self.lbl_preview.mapTo(self.scroll.viewport(), e.position().toPoint())

        # --- Wheel zoom on viewport or label (plain wheel + Ctrl+wheel) ---
        if obj in (self.scroll.viewport(), self.lbl_preview) and ev.type() == QEvent.Type.Wheel:
            # Anchor in label/content coords, because _apply_zoom expects label-space coords.
            if obj is self.lbl_preview:
                anchor_label_pos = ev.position()
            else:
                anchor_label_pos = self.lbl_preview.mapFrom(
                    self.scroll.viewport(), ev.position().toPoint()
                )

            dy = ev.pixelDelta().y()

            if dy != 0:
                abs_dy = abs(dy)
                ctrl_down = bool(ev.modifiers() & Qt.KeyboardModifier.ControlModifier)

                if abs_dy <= 3:
                    base_factor = 1.012 if ctrl_down else 1.010
                elif abs_dy <= 10:
                    base_factor = 1.025 if ctrl_down else 1.020
                else:
                    base_factor = 1.040 if ctrl_down else 1.030

                factor = base_factor if dy > 0 else 1.0 / base_factor
            else:
                dy = ev.angleDelta().y()
                if dy == 0:
                    ev.accept()
                    return True

                ctrl_down = bool(ev.modifiers() & Qt.KeyboardModifier.ControlModifier)
                step = 1.25 if ctrl_down else 1.15
                factor = step if dy > 0 else 1.0 / step

            self._apply_zoom(self._zoom * factor, anchor_label_pos=anchor_label_pos)
            ev.accept()
            return True

        # --- LASSO REGION MASK (Alt + LMB drag) on viewport or label ---
        if obj in (self.scroll.viewport(), self.lbl_preview):
            if ev.type() == QEvent.Type.MouseButtonPress:
                if (ev.button() == Qt.MouseButton.LeftButton and
                        ev.modifiers() & Qt.KeyboardModifier.AltModifier and
                        not ev.modifiers() & Qt.KeyboardModifier.ControlModifier):
                    # start lasso — get position in label coords
                    if obj is self.lbl_preview:
                        lpos = ev.position()
                    else:
                        lpos = self.lbl_preview.mapFrom(
                            self.scroll.viewport(), ev.position().toPoint())
                    self._lasso_drawing = True
                    self._lasso_points = [(float(lpos.x()), float(lpos.y()))]
                    self.scroll.viewport().setCursor(Qt.CursorShape.CrossCursor)
                    return True

            elif ev.type() == QEvent.Type.MouseMove and self._lasso_drawing:
                if obj is self.lbl_preview:
                    lpos = ev.position()
                else:
                    lpos = self.lbl_preview.mapFrom(
                        self.scroll.viewport(), ev.position().toPoint())
                self._lasso_points.append((float(lpos.x()), float(lpos.y())))
                # Thin the points — only keep every 8th to reduce memory
                if len(self._lasso_points) % 8 == 0:
                    self._draw_lasso_overlay()
                return True

            elif ev.type() == QEvent.Type.MouseButtonRelease and self._lasso_drawing:
                self._lasso_drawing = False
                self.scroll.viewport().setCursor(Qt.CursorShape.ArrowCursor)

                if len(self._lasso_points) >= 3 and hasattr(self, '_last_base'):
                    base = self._last_base
                    region = self._lasso_to_region_mask(
                        self._lasso_points, base.shape)

                    if region is not None:
                        # Scale back up to full-res image coords
                        fh, fw = self.img.shape[:2]
                        bh, bw = base.shape[:2]
                        if (bh, bw) != (fh, fw) and cv2 is not None:
                            region_full = cv2.resize(
                                region, (fw, fh),
                                interpolation=cv2.INTER_LINEAR)
                        else:
                            region_full = region

                        self._region_mask_full = np.clip(
                            region_full.astype(np.float32), 0.0, 1.0)
                        n_pts = len(self._lasso_points)
                        self.lbl_region_readout.setText(
                            f"Region mask: active ({n_pts} points)  "
                            f"— click '✕ Clear Region Mask' to remove")
                        self.btn_clear_region.setEnabled(True)

                self._lasso_points = []
                self._recompute_mask_and_preview()
                return True

        # --- PANNING (Ctrl + LMB) on viewport *or* label ---
        if obj in (self.scroll.viewport(), self.lbl_preview):
            if ev.type() == QEvent.Type.MouseButtonPress:
                if (ev.button() == Qt.MouseButton.LeftButton and
                    ev.modifiers() & Qt.KeyboardModifier.ControlModifier):
                    self._panning = True
                    self._pan_start_pos_vp = _pos_in_viewport(obj, ev)
                    hbar = self.scroll.horizontalScrollBar()
                    vbar = self.scroll.verticalScrollBar()
                    self._pan_start_scroll = (hbar.value(), vbar.value())
                    self.scroll.viewport().setCursor(Qt.CursorShape.ClosedHandCursor)
                    return True

            elif ev.type() == QEvent.Type.MouseMove and self._panning:
                cur = _pos_in_viewport(obj, ev)
                dx = cur.x() - self._pan_start_pos_vp.x()
                dy = cur.y() - self._pan_start_pos_vp.y()
                if abs(dx) > self._pan_deadzone or abs(dy) > self._pan_deadzone:
                    hbar = self.scroll.horizontalScrollBar()
                    vbar = self.scroll.verticalScrollBar()
                    hbar.setValue(int(self._pan_start_scroll[0] - dx))
                    vbar.setValue(int(self._pan_start_scroll[1] - dy))
                return True

            elif ev.type() in (QEvent.Type.MouseButtonRelease, QEvent.Type.Leave):
                if self._panning:
                    self._panning = False
                    self.scroll.viewport().setCursor(Qt.CursorShape.ArrowCursor)
                    return True

        # --- Hue pick (plain click) on the label only ---
        if obj is self.lbl_preview and ev.type() == QEvent.Type.MouseButtonPress:
            if ev.modifiers() & Qt.KeyboardModifier.ControlModifier:
                return True  # Ctrl is for panning; let pan branch handle it
            pt = self._map_label_point_to_image_xy(ev.position())
            if pt is not None:
                x, y = pt
                hue = self._sample_hue_deg_from_base(x, y)
                if hue is not None:
                    self.hue_wheel.setPickedHue(hue)
                    self.lbl_hue_readout.setText(f"Picked hue: {hue:.1f}°")
                    if ev.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                        half = 15
                        self.hue_wheel.setRange(int((hue-half) % 360), int((hue+half) % 360))
            return True

        return super().eventFilter(obj, ev)

    def _slider_row(self, grid: QGridLayout, name: str, row: int) -> QDoubleSpinBox:
        grid.addWidget(QLabel(name), row, 0)
        s = QDoubleSpinBox()
        s.setRange(-1.0, 1.0); s.setSingleStep(0.05); s.setDecimals(2); s.setValue(0.0)
        s.valueChanged.connect(self._recompute_mask_and_preview)
        grid.addWidget(s, row, 1)
        return s

    def _slider_pair(self, grid: QGridLayout, name: str, row: int, minv=-0.2, maxv=0.2, step=0.005):
        import math

        def _to_slider(v: float) -> int:
            # Symmetric rounding away from zero at half-steps; no banker’s rounding.
            s = abs(v) * 1000.0
            s = math.floor(s + 0.5)
            return int(-s if v < 0 else s)

        def _to_spin(v_int: int) -> float:
            return float(v_int) / 1000.0

        grid.addWidget(QLabel(name), row, 0)

        sld = QSlider(Qt.Orientation.Horizontal)
        sld.setRange(int(minv*1000), int(maxv*1000))   # e.g., -100..100
        sld.setSingleStep(int(step*1000))             # e.g., 5
        sld.setPageStep(int(5*step*1000))             # e.g., 25
        sld.setValue(0)

        box = QDoubleSpinBox()
        box.setRange(minv, maxv)
        box.setSingleStep(step)
        box.setDecimals(3)
        box.setValue(0.0)
        box.setKeyboardTracking(False)  # only fire on committed changes

        # Two-way binding without ping-pong
        def _sld_to_box(v_int: int):
            box.blockSignals(True)
            box.setValue(_to_spin(v_int))
            box.blockSignals(False)

        def _box_to_sld(v_float: float):
            sld.blockSignals(True)
            sld.setValue(_to_slider(v_float))
            sld.blockSignals(False)

        sld.valueChanged.connect(_sld_to_box)
        box.valueChanged.connect(_box_to_sld)

        # Debounced preview updates (adjustments don’t rebuild mask)
        sld.valueChanged.connect(self._schedule_adjustments)
        box.valueChanged.connect(self._schedule_adjustments)
        # Nice UX: force one final refresh on release
        sld.sliderReleased.connect(self._update_preview_pixmap)
        box.editingFinished.connect(self._update_preview_pixmap)

        grid.addWidget(sld, row, 1)
        grid.addWidget(box, row, 2)
        return sld, box


    # ------------- Logic -------------
    def _on_preset_change(self, txt: str):
        self._setting_preset = True
        try:
            if txt != "Custom":
                intervals = _PRESETS.get(txt, [])
                if intervals:
                    lo, hi = (intervals[0][0], intervals[-1][1]) if len(intervals) > 1 else intervals[0]

                    # --- NEW: keep wheel + sliders + spins all in sync ---
                    self._syncing_hue = True
                    try:
                        # update wheel silently
                        self.hue_wheel.setRange(int(lo), int(hi), notify=False)

                        # update both sliders and spins (no ping-pong)
                        for w, val in (
                            (self.sl_h1, int(lo)), (self.sp_h1, int(lo)),
                            (self.sl_h2, int(hi)), (self.sp_h2, int(hi)),
                        ):
                            w.blockSignals(True)
                            w.setValue(val)
                            w.blockSignals(False)

                        self.hue_wheel.update()  # ensure repaint
                    finally:
                        self._syncing_hue = False

            self._recompute_mask_and_preview()
        finally:
            self._setting_preset = False

    def _downsample(self, img, max_dim=1024):
        h, w = img.shape[:2]
        s = max(h, w)
        if s <= max_dim: return img
        k = max_dim / float(s)
        if cv2 is None:
            return cv2.resize(img, (int(w*k), int(h*k))) if False else img[::int(1/k), ::int(1/k)]
        return cv2.resize(img, (int(w*k), int(h*k)), interpolation=cv2.INTER_AREA)

    def _recompute_mask_and_preview(self):
        if self.img is None:
            return

        base = self._downsample(self.img, 1200) if self.cb_small_preview.isChecked() else self.img
        self._last_base = base

        if self._use_imported_mask and self._imported_mask_full is not None:
            imp = self._imported_mask_full
            bh, bw = base.shape[:2]
            mh, mw = imp.shape[:2]
            if (mh, mw) != (bh, bw):
                if cv2 is not None:
                    mask = cv2.resize(imp, (bw, bh), interpolation=cv2.INTER_LINEAR)
                else:
                    yy = (np.linspace(0, mh - 1, bh)).astype(int)
                    xx = (np.linspace(0, mw - 1, bw)).astype(int)
                    mask = imp[yy[:, None], xx[None, :]]
            else:
                mask = imp
            mask = np.clip(mask.astype(np.float32), 0.0, 1.0)
        else:
            preset = self.dd_preset.currentText()
            if preset == "Custom":
                ranges = [(float(self.sp_h1.value()), float(self.sp_h2.value()))]
            else:
                ranges = _PRESETS[preset]

            mask = _hue_mask(
                base,
                ranges_deg=ranges,
                min_chroma=float(self.ds_minC.value()),
                min_light=float(self.ds_minL.value()),
                max_light=float(self.ds_maxL.value()),
                smooth_deg=float(self.ds_smooth.value()),
                invert_range=self.cb_invert.isChecked(),
                soft=self.cb_soft_mask.isChecked(),
            )

            mask = _weight_shadows_highlights(
                mask, base,
                shadows=float(self.ds_sh.value()),
                highlights=float(self.ds_hi.value()),
                balance=float(self.ds_bal.value()),
            )

            k = int(self.sb_blur.value())
            if k > 0 and cv2 is not None:
                mask = cv2.GaussianBlur(mask.astype(np.float32), (0, 0), float(k))

        # ── AND with region mask for preview too ───────────────────────────
        if self._region_mask_full is not None:
            bh, bw = base.shape[:2]
            rm = self._region_mask_full
            mh, mw = rm.shape[:2]
            if (mh, mw) != (bh, bw):
                if cv2 is not None:
                    rm = cv2.resize(rm, (bw, bh), interpolation=cv2.INTER_LINEAR)
                else:
                    yy = np.linspace(0, mh-1, bh).astype(int)
                    xx = np.linspace(0, mw-1, bw).astype(int)
                    rm = rm[yy[:, None], xx[None, :]]
            mask = mask * np.clip(rm.astype(np.float32), 0.0, 1.0)

        self._mask = np.clip(mask, 0.0, 1.0)
        self._update_preview_pixmap()

    def _on_use_imported_mask_toggled(self, on: bool):
        self._use_imported_mask = bool(on)
        # if we don't have an imported mask yet, turn it off again
        if self._use_imported_mask and self._imported_mask_full is None:
            self._use_imported_mask = False
            self.cb_use_imported.setChecked(False)
            QMessageBox.information(self, "No imported mask", "Pick a mask view first.")
            return

        # just rebuild preview with the external mask
        self._recompute_mask_and_preview()

    def _import_mask_from_view(self):
        if self.docman is None:
            QMessageBox.information(self, "No document manager", "Cannot import without a document manager.")
            return

        # get ALL docs user currently has open (renamed, FITS layers, XISF layers, duplicates, etc.)
        docs = self.docman.all_documents() or []
        # only image docs
        img_docs = [d for d in docs if hasattr(d, "image") and d.image is not None]

        if not img_docs:
            QMessageBox.information(self, "No views", "There are no image views to import a mask from.")
            return

        # build names as the user sees them
        items = []
        for d in img_docs:
            try:
                nm = d.display_name()
            except Exception:
                nm = "Untitled"
            items.append(nm)

        from PyQt6.QtWidgets import QInputDialog
        choice, ok = QInputDialog.getItem(
            self,
            "Pick mask view",
            "Open image views:",
            items,
            0,
            False
        )
        if not ok:
            return

        # find selected document
        sel_doc = None
        for d, nm in zip(img_docs, items):
            if nm == choice:
                sel_doc = d
                break

        if sel_doc is None or getattr(sel_doc, "image", None) is None:
            QMessageBox.warning(self, "Import failed", "Selected view has no image.")
            return

        mask_img = np.clip(sel_doc.image.astype(np.float32), 0.0, 1.0)

        # if it's RGB, take channel 0 — that’s how your exported mask would look (3 equal channels)
        if mask_img.ndim == 3:
            mask_img = mask_img[..., 0]

        # resize to current image size if needed
        dst_h, dst_w = self.img.shape[:2]
        src_h, src_w = mask_img.shape[:2]
        if (src_h, src_w) != (dst_h, dst_w):
            if cv2 is not None:
                mask_full = cv2.resize(mask_img, (dst_w, dst_h), interpolation=cv2.INTER_LINEAR)
            else:
                yy = (np.linspace(0, src_h - 1, dst_h)).astype(int)
                xx = (np.linspace(0, src_w - 1, dst_w)).astype(int)
                mask_full = mask_img[yy[:, None], xx[None, :]]
        else:
            mask_full = mask_img

        mask_full = np.clip(mask_full.astype(np.float32), 0.0, 1.0)

        # store
        self._imported_mask_full = mask_full
        self._imported_mask_name = choice
        self.lbl_imported_mask.setText(f"Imported: {choice}")

        # auto-enable
        self.cb_use_imported.setChecked(True)
        self._use_imported_mask = True

        # refresh preview
        self._recompute_mask_and_preview()


    def _overlay_mask(self, base: np.ndarray, mask: np.ndarray) -> np.ndarray:
        base = _ensure_rgb01(base)
        # mask is HxW -> expand to HxWx1 for broadcasting
        alpha = np.clip(mask.astype(np.float32), 0.0, 1.0)[..., None] * 0.6
        # red overlay
        overlay = base.copy()
        overlay[..., 0] = np.clip(base[..., 0]*(1 - alpha[..., 0]) + 1.0*alpha[..., 0], 0.0, 1.0)
        overlay[..., 1] = np.clip(base[..., 1]*(1 - alpha[..., 0]) + 0.0*alpha[..., 0], 0.0, 1.0)
        overlay[..., 2] = np.clip(base[..., 2]*(1 - alpha[..., 0]) + 0.0*alpha[..., 0], 0.0, 1.0)
        return overlay

    def _update_preview_pixmap(self):
        if not hasattr(self, "_last_base"):
            self._recompute_mask_and_preview(); return

        base = self._last_base
        mask = getattr(self, "_mask", np.zeros(base.shape[:2], np.float32))

        if self.cb_live.isChecked():
            out = _apply_selective_adjustments(
                base, mask,
                cyan=float(self.ds_c.value()),
                magenta=float(self.ds_m.value()),
                yellow=float(self.ds_y.value()),
                r=float(self.ds_r.value()),
                g=float(self.ds_g.value()),
                b=float(self.ds_b.value()),
                lum=float(self.ds_l.value()),
                chroma=float(self.ds_chroma.value()),
                sat=float(self.ds_s.value()),
                con=float(self.ds_c2.value()),
                intensity=float(self.ds_int.value()),
                use_chroma_mode=(self.dd_color_mode.currentIndex() == 0),
            )

            out = _ensure_rgb01(out)
        else:
            out = _ensure_rgb01(base)

        if self.cb_show_mask.isChecked():
            # fade overlay by intensity too
            mask_vis = mask * float(self.ds_int.value())
            show = self._overlay_mask(out, mask_vis)
        else:
            show = out

        pm = _to_pixmap(show)
        h, w = show.shape[:2]
        zw, zh = max(1, int(round(w * self._zoom))), max(1, int(round(h * self._zoom)))
        pm_scaled = pm.scaled(zw, zh, Qt.AspectRatioMode.IgnoreAspectRatio,
                            Qt.TransformationMode.SmoothTransformation)
        pm_scaled = self._draw_region_outline_on_pixmap(pm_scaled)
        self.lbl_preview.setPixmap(pm_scaled)
        self.lbl_preview.resize(zw, zh)


    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        QTimer.singleShot(0, self._update_preview_pixmap)

    # ------------- Apply -------------
    def _apply_fullres(self) -> np.ndarray:
        base = self.img

        if self._use_imported_mask and self._imported_mask_full is not None:
            mask = np.clip(self._imported_mask_full.astype(np.float32), 0.0, 1.0)
        else:
            mask = self._build_mask(base)

        out = _apply_selective_adjustments(
            base, mask,
            cyan=float(self.ds_c.value()),
            magenta=float(self.ds_m.value()),
            yellow=float(self.ds_y.value()),
            r=float(self.ds_r.value()),
            g=float(self.ds_g.value()),
            b=float(self.ds_b.value()),
            lum=float(self.ds_l.value()),
            chroma=float(self.ds_chroma.value()),
            sat=float(self.ds_s.value()),
            con=float(self.ds_c2.value()),
            intensity=float(self.ds_int.value()),
            use_chroma_mode=(self.dd_color_mode.currentIndex() == 0),
        )

        return out

    def _export_mask_doc(self):
        if self.docman is None:
            QMessageBox.information(self, "No document manager", "Cannot export mask without a document manager.")
            return

        base = self.img
        if base is None:
            QMessageBox.information(self, "No image", "Open an image first.")
            return

        mask = self._build_mask(base)          # H x W, float32, 0..1
        mask_rgb = np.repeat(mask[..., None], 3, axis=2).astype(np.float32)

        name = getattr(self.document, "display_name", lambda: "Image")()
        title = f"{name} [SelectiveColor MASK]"
        try:
            self.docman.open_array(mask_rgb, title=title)
        except Exception as e:
            QMessageBox.warning(self, "Export failed", str(e))


    def _build_mask(self, base: np.ndarray) -> np.ndarray:
        preset = self.dd_preset.currentText()
        ranges = (
            [(float(self.sp_h1.value()), float(self.sp_h2.value()))]
            if preset == "Custom"
            else _PRESETS[preset]
        )

        mask = _hue_mask(
            base,
            ranges_deg=ranges,
            min_chroma=float(self.ds_minC.value()),
            min_light=float(self.ds_minL.value()),
            max_light=float(self.ds_maxL.value()),
            smooth_deg=float(self.ds_smooth.value()),
            invert_range=self.cb_invert.isChecked(),
            soft=self.cb_soft_mask.isChecked(),
        )

        mask = _weight_shadows_highlights(
            mask, base,
            shadows=float(self.ds_sh.value()),
            highlights=float(self.ds_hi.value()),
            balance=float(self.ds_bal.value()),
        )

        k = int(self.sb_blur.value())
        if k > 0 and cv2 is not None:
            mask = cv2.GaussianBlur(mask.astype(np.float32), (0, 0), float(k))

        # ── AND with region mask if one exists ─────────────────────────────
        if self._region_mask_full is not None:
            bh, bw = base.shape[:2]
            rm = self._region_mask_full
            mh, mw = rm.shape[:2]
            if (mh, mw) != (bh, bw):
                if cv2 is not None:
                    rm = cv2.resize(rm, (bw, bh), interpolation=cv2.INTER_LINEAR)
                else:
                    yy = np.linspace(0, mh-1, bh).astype(int)
                    xx = np.linspace(0, mw-1, bw).astype(int)
                    rm = rm[yy[:, None], xx[None, :]]
            mask = mask * np.clip(rm.astype(np.float32), 0.0, 1.0)

        return np.clip(mask, 0.0, 1.0).astype(np.float32)



    def _apply_to_document(self):
        try:
            result = self._apply_fullres()
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e)); return
        try:
            self._save_window_state()
        except Exception:
            pass
        # write back to the same document (preferred)
        try:
            if hasattr(self.document, "set_image"):
                self.document.set_image(result)
        except Exception:
            # fallback: if set_image fails, at least open it as a new view (but keep dialog open)
            name = getattr(self.document, "display_name", lambda: "Image")()
            if hasattr(self.docman, "open_array"):
                self.docman.open_array(result, title=f"{name} [SelectiveColor]")

        # make the processed image the new working base for further tweaks
        self.img = np.clip(result.astype(np.float32), 0.0, 1.0)
        self._last_base = None   # force rebuild from current self.img
        self._reset_controls()   # reset knobs; dialog remains open


    def _apply_as_new_doc(self):
        try:
            result = self._apply_fullres()
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e)); return
        try:
            self._save_window_state()
        except Exception:
            pass
        name = getattr(self.document, "display_name", lambda: "Image")()
        new_doc = None
        if hasattr(self.docman, "open_array"):
            new_doc = self.docman.open_array(result, title=f"{name} [SelectiveColor]")

        # continue editing the new doc if we got a handle; otherwise just keep editing current
        if new_doc is not None:
            self.document = new_doc
            # refresh label
            try:
                disp = getattr(self.document, "display_name", lambda: "Image")()
            except Exception:
                disp = "Image"
            self.lbl_target.setText(f"Target View:  <b>{disp}</b>")

        # new working base is the processed pixels either way
        self.img = np.clip(result.astype(np.float32), 0.0, 1.0)
        self._last_base = None
        self._reset_controls()

    def _restore_window_state(self):
        try:
            s = QSettings()
            g = s.value("selcolor/window_geometry", None)
            if g is not None:
                self.restoreGeometry(g)

            sp = s.value("selcolor/splitter_state", None)
            if sp is not None and hasattr(self, "splitter"):
                self.splitter.restoreState(sp)

            # Optional UX state
            self.cb_small_preview.setChecked(bool(s.value("selcolor/small_preview", True, type=bool)))
            self.cb_live.setChecked(bool(s.value("selcolor/live_preview", True, type=bool)))
            self.cb_show_mask.setChecked(bool(s.value("selcolor/show_mask", False, type=bool)))

            z = float(s.value("selcolor/zoom", 1.0))
            self._zoom = max(0.05, min(16.0, z))

        except Exception:
            pass


    def _save_window_state(self):
        try:
            s = QSettings()
            s.setValue("selcolor/window_geometry", self.saveGeometry())
            if hasattr(self, "splitter"):
                s.setValue("selcolor/splitter_state", self.splitter.saveState())

            # Optional UX state
            s.setValue("selcolor/small_preview", bool(self.cb_small_preview.isChecked()))
            s.setValue("selcolor/live_preview", bool(self.cb_live.isChecked()))
            s.setValue("selcolor/show_mask", bool(self.cb_show_mask.isChecked()))
            s.setValue("selcolor/zoom", float(getattr(self, "_zoom", 1.0)))

            try:
                s.sync()
            except Exception:
                pass
        except Exception:
            pass

    def showEvent(self, ev):
        super().showEvent(ev)
        if getattr(self, "_geom_restored", False):
            return
        self._geom_restored = True

        def _after():
            self._restore_window_state()
            # If user had previously chosen a zoom other than 1, re-render with it
            self._last_base = None
            self._recompute_mask_and_preview()
            # If you want a default fit when first-ever run, do it only when no saved geometry existed.
        QTimer.singleShot(0, _after)

    def closeEvent(self, ev):
        try:
            self._save_window_state()
        except Exception:
            pass
        super().closeEvent(ev)