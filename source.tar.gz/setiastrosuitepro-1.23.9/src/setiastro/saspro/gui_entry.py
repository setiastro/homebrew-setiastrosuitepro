# src/setiastro/saspro/gui_entry.py
from __future__ import annotations

"""
GUI entry point for Seti Astro Suite Pro.

This module contains the heavy GUI startup path (splash, runtime bootstrap,
PyQt6 imports, main window creation). It must NOT be imported from the CLI path
unless the user is launching the GUI.
"""
import platform
import sys
import os
from pathlib import Path

# ── Windows: check for Microsoft Visual C++ Redistributable ─────────────────
# MUST run before ANY C-extension imports (PyQt6, numpy, torch, numba, ...).
# Python 3.13 / 3.14 do NOT bundle msvcp140.dll or vcruntime140_1.dll with
# their Windows installer (3.12 bundled some of it), so a clean install of
# those Pythons on a machine without the VC++ 2015-2022 x64 Redistributable
# fails to load torch_python.dll (WinError 126) and can access-violate on
# numba's first compile. Detecting this ourselves lets us tell the user
# exactly what to install instead of surfacing a WinError 126 wall of text
# from mid-app or crashing to the faulthandler log. Uses a native MessageBox
# via ctypes so it works even if PyQt6 can't import for the same reason.
if sys.platform.startswith("win"):
    import ctypes
    _missing_vcrt = []
    for _dll in ("msvcp140.dll", "vcruntime140.dll", "vcruntime140_1.dll"):
        try:
            ctypes.WinDLL(_dll)   # bare name -> normal OS DLL search path
        except OSError:
            _missing_vcrt.append(_dll)
    if _missing_vcrt:
        _msg = (
            "Seti Astro Suite Pro requires the Microsoft Visual C++ "
            "2015-2022 Redistributable (x64).\r\n\r\n"
            "Missing on this system: " + ", ".join(_missing_vcrt) + "\r\n\r\n"
            "Download and install the redistributable from Microsoft:\r\n"
            "https://aka.ms/vs/17/release/vc_redist.x64.exe\r\n\r\n"
            "Then relaunch Seti Astro Suite Pro."
        )
        # MB_ICONERROR (0x10) | MB_SETFOREGROUND (0x10000) | MB_TOPMOST (0x40000)
        try:
            ctypes.windll.user32.MessageBoxW(
                0, _msg, "Seti Astro Suite Pro - Missing Prerequisite", 0x50010
            )
        except Exception:
            print(_msg)
        sys.exit(1)

# ── Frozen build: verify a matching system Python exists ─────────────────────
# The installer build embeds a FIXED Python (3.12 today) and imports torch into
# that very interpreter, so its AI runtime venv has to be built by a system
# Python of the same minor. Install only 3.13/3.14 and the app is in a state
# that cannot work -- but every symptom shows up somewhere else and somewhere
# later: a WinError 126, a torch import failure, or (before this landed) a
# "'NoneType' object is not subscriptable" from runtime path discovery. None of
# those name the actual cause, which is why this was a recurring support thread.
#
# Say it plainly, once, at startup. Non-fatal: SAS Pro runs without the AI
# runtime, just without the GPU/AI features, so the user chooses.
# Set SASPRO_SKIP_PYTHON_PREFLIGHT=1 to silence it.
if getattr(sys, "frozen", False) and not os.environ.get("SASPRO_SKIP_PYTHON_PREFLIGHT"):
    try:
        from setiastro.saspro.runtime_torch import runtime_python_preflight

        _pyprob = runtime_python_preflight()
        if _pyprob:
            _need = _pyprob["required"]                       # e.g. "3.12"
            _have = _pyprob.get("detected") or []
            # Pinned full versions for the direct python.org installer link.
            _PY_FULL = {"3.12": "3.12.10", "3.13": "3.13.9", "3.14": "3.14.2"}
            _full = _PY_FULL.get(_need)
            _url = (f"https://www.python.org/ftp/python/{_full}/python-{_full}-amd64.exe"
                    if _full and sys.platform.startswith("win")
                    else "https://www.python.org/downloads/")

            _have_txt = (", ".join(_have) if _have
                         else "none that SAS Pro could detect")
            _msg = (
                f"This installer build of Seti Astro Suite Pro runs on Python {_need} "
                f"and needs Python {_need} installed on your system to set up its "
                f"GPU/AI runtime.\r\n\r\n"
                f"Python versions found on this PC: {_have_txt}\r\n\r\n"
                f"Python {_need} was not found. Without it, denoise, sharpening, "
                f"star removal and the other AI/GPU features will not be available.\r\n\r\n"
                f"To fix it:\r\n"
                f"  1. Install Python {_need} from:\r\n     {_url}\r\n"
                f"  2. During setup, tick \"Add python.exe to PATH\".\r\n"
                f"  3. Relaunch Seti Astro Suite Pro - it rebuilds its runtime "
                f"automatically.\r\n\r\n"
                f"(Other Python versions can stay installed; they do not conflict. "
                f"Running SAS Pro from pip or source works on 3.12, 3.13 and 3.14 - "
                f"this requirement applies to the installer build only.)\r\n\r\n"
                f"Open the Python {_need} download page now and exit?\r\n"
                f"  Yes = open the download and close SAS Pro\r\n"
                f"  No  = continue without the AI/GPU features"
            )

            if sys.platform.startswith("win"):
                # MB_YESNO(0x4) | MB_ICONWARNING(0x30) | SETFOREGROUND | TOPMOST
                _IDYES = 6
                try:
                    import ctypes  # bound above on Windows; re-import is free
                    _choice = ctypes.windll.user32.MessageBoxW(
                        0, _msg,
                        f"Seti Astro Suite Pro - Python {_need} Required",
                        0x50034,
                    )
                except Exception:
                    print(_msg)
                    _choice = 0
                if _choice == _IDYES:
                    try:
                        import webbrowser
                        webbrowser.open(_url)
                    except Exception:
                        pass
                    sys.exit(1)
            else:
                print(_msg, file=sys.stderr)
    except SystemExit:
        raise
    except Exception:
        # A preflight must never be the reason the app fails to start.
        pass

# ── Numba threading-layer bootstrap ──────────────────────────────────────────
# MUST run before ANY `import numba` in this process. astroalign and
# numba_warmup both import numba, and numba locks its threading layer at first
# import — so this side-effect import has to come first. On Windows + CPython
# 3.14 the TBB layer aborts with an UNCATCHABLE native access violation during
# the first parallel JIT compile (the warmup_jit crash); this demotes TBB so
# numba resolves to omp/workqueue instead. No-op on unaffected Python/OS combos.
from setiastro.saspro import numba_bootstrap  # noqa: E402,F401  (import for side effect)
# -*- coding: utf-8 -*-
"""
Seti Astro Suite Pro - Main Entry Point Module

This module contains the main application entry point logic.
It can be executed directly via `python -m setiastro.saspro` or
called via the `main()` function when invoked as an entry point.
"""

# Show splash screen IMMEDIATELY before any heavy imports

_STARTUP_PROFILE = os.environ.get("SASPRO_STARTUP_PROFILE", "").strip().lower() in ("1","true","yes","on")
_app_icon_obj = None
_app_icon_path = ""

def _is_wayland_session() -> bool:
    # Best-effort detection that does NOT require a QApplication instance
    xdg = (os.environ.get("XDG_SESSION_TYPE") or "").lower()
    if xdg == "wayland":
        return True
    # QT can still run wayland even if XDG_SESSION_TYPE isn't set
    if os.environ.get("WAYLAND_DISPLAY"):
        return True
    return False

def _allow_window_opacity_effects() -> bool:
    # User override: allow opacity effects even on Wayland if they want
    if os.environ.get("SASPRO_ALLOW_OPACITY", "").strip().lower() in ("1","true","yes","on"):
        return True
    # Default: disable opacity effects on Wayland
    return not _is_wayland_session()


from pathlib import Path

if sys.platform.startswith("win"):
    exe_dir = Path(sys.executable).resolve().parent
    internal = exe_dir / "_internal"
    if internal.is_dir():
        try:
            os.add_dll_directory(str(internal))
        except Exception:
            pass
        os.environ["PATH"] = str(internal) + os.pathsep + os.environ.get("PATH", "")
        


# ---- Linux Qt stability guard (must run BEFORE any PyQt6 import) ----
# Default behavior: DO NOT override Wayland.
# If a user needs the "safe" path, they can opt-in by setting:
#   SASPRO_QT_SAFE=1
#
# This avoids punishing all Wayland users for one bad driver/Qt stack.
if sys.platform.startswith("linux"):
    if os.environ.get("SASPRO_QT_SAFE", "").strip() in ("1", "true", "yes", "on"):
        # Prefer X11/xcb unless user explicitly set a platform plugin
        os.environ.setdefault("QT_QPA_PLATFORM", "xcb")

        # Prefer software GL unless user explicitly set something else
        os.environ.setdefault("QT_OPENGL", "software")
        os.environ.setdefault("LIBGL_ALWAYS_SOFTWARE", "1")

from PyQt6.QtCore import QCoreApplication

# Global variables for splash screen and app
_splash = None
_app = None

# Flag to track if splash was initialized
_splash_initialized = False

# Flag to ensure heavy imports/bootstrap happens only once
_imports_bootstrapped = False

def _set_windows_appusermodelid(app_id: str) -> None:
    if not sys.platform.startswith("win"):
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        pass

from setiastro.saspro.versioning import get_app_version
_EARLY_VERSION = get_app_version("setiastrosuitepro")

VERSION = _EARLY_VERSION

def _collect_open_paths(argv: list[str] | None) -> list[str]:
    if not argv:
        return []
    out: list[str] = []
    for a in argv:
        if not a or a.startswith("-"):
            continue
        # strip surrounding quotes if any
        s = a.strip().strip('"').strip("'")
        try:
            p = Path(s)
        except Exception:
            continue
        if p.exists() and p.is_file():
            out.append(str(p))
        else:
            print(f"[startup] ignoring arg (not a file): {p}  exists={p.exists()} is_file={p.is_file()}")

    return out

def _init_splash():
    """Initialize the splash screen. Safe to call multiple times."""
    global _splash, _app, _splash_initialized

    if _splash_initialized:
        return

    # --- Windows: set AppUserModelID as early as possible ---
    if sys.platform.startswith("win"):
        _set_windows_appusermodelid("SetiAstro.SetiAstroSuitePro")

    # Minimal imports for splash screen
    from PyQt6.QtWidgets import QApplication, QWidget
    from PyQt6.QtCore import Qt, QCoreApplication, QRect, QPropertyAnimation, QEasingCurve, QEvent
    from PyQt6.QtGui import (
        QGuiApplication, QIcon, QPixmap, QColor, QPainter, QFont, QLinearGradient
    )
    import time

    # If we're forcing software OpenGL, do it *before* QApplication is created.
    if sys.platform.startswith("linux"):
        if os.environ.get("SASPRO_QT_SAFE", "").strip().lower() in ("1", "true", "yes", "on"):
            if os.environ.get("QT_OPENGL", "").lower() == "software":
                try:
                    QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_UseSoftwareOpenGL, True)
                except Exception:
                    pass

    # Set application attributes before creating QApplication
    try:
        QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
            Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
        )
    except Exception:
        pass

    # Keep these exactly (QSettings/defaults depend on org/app names)
    QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_DontShowIconsInMenus, False)
    QCoreApplication.setOrganizationName("SetiAstro")
    QCoreApplication.setOrganizationDomain("setiastrosuite.pro")
    QCoreApplication.setApplicationName("Seti Astro Suite Pro")
    class _SASProApplication(QApplication):
        def event(self, e):
            # macOS: Finder "Open With" / dock-dropped files arrive as
            # QFileOpenEvent. These can fire BEFORE the main window exists
            # (right-click a .fits before SASpro is open -> the OS launches
            # us and immediately sends the FileOpen event, often before our
            # splash's event loop has ticked the main window into existence).
            # We buffer paths on the QApplication instance; after the main
            # window is built, main() installs _file_open_cb and drains the
            # buffer. Any subsequent FileOpen events route through the cb
            # directly.
            if e.type() == QEvent.Type.FileOpen:
                try:
                    path = e.file()
                    if path:
                        pending = getattr(self, "_pending_open_paths", None)
                        if pending is None:
                            pending = []
                            self._pending_open_paths = pending
                        pending.append(path)

                        cb = getattr(self, "_file_open_cb", None)
                        if callable(cb):
                            try:
                                cb(path)
                            except Exception:
                                pass
                except Exception:
                    pass
                return True

            if (
                e.type() == QEvent.Type.ApplicationActivate
                and platform.system() == "Darwin"
            ):
                for window in self.topLevelWidgets():
                    if (
                        hasattr(window, '__class__')
                        and window.__class__.__name__ != '_EarlySplash'
                        and window.isVisible()
                        and not window.isMinimized()
                    ):
                        window.raise_()
                        window.activateWindow()
            return super().event(e)

    # ---------------------------------------------------------------------
    # Path resolution helpers (NO QIcon/QPixmap usage before QApplication)
    # ---------------------------------------------------------------------
    def _find_resource_paths_legacy() -> tuple[str, str, str | None]:
        """
        Returns (app_icon_path, splash_logo_path, startup_bg_path) using filesystem only.
        app_icon_path prefers ICO on Windows.
        splash_logo_path prefers PNG for large splash rendering.
        """
        if hasattr(sys, "_MEIPASS"):
            base = sys._MEIPASS
        else:
            try:
                import setiastro
                package_dir = os.path.dirname(os.path.abspath(setiastro.__file__))
                package_parent = os.path.dirname(package_dir)
                images_dir_installed = os.path.join(package_parent, "images")
                if os.path.exists(images_dir_installed):
                    base = package_parent
                else:
                    base = os.path.dirname(
                        os.path.dirname(
                            os.path.dirname(
                                os.path.dirname(os.path.abspath(__file__))
                            )
                        )
                    )
            except Exception:
                base = os.path.dirname(
                    os.path.dirname(
                        os.path.dirname(
                            os.path.dirname(os.path.abspath(__file__))
                        )
                    )
                )

        images_dir = os.path.join(base, "images")

        # App icon (taskbar/tray/window icon): prefer ICO on Windows
        if sys.platform.startswith("win"):
            app_icon_candidates = [
                os.path.join(images_dir, "astrosuitepro.ico"),
                os.path.join(images_dir, "astrosuite.ico"),
                os.path.join(images_dir, "astrosuitepro.png"),
                os.path.join(images_dir, "astrosuite.png"),
            ]
        else:
            app_icon_candidates = [
                os.path.join(images_dir, "astrosuitepro.png"),
                os.path.join(images_dir, "astrosuitepro.ico"),
                os.path.join(images_dir, "astrosuite.png"),
                os.path.join(images_dir, "astrosuite.ico"),
            ]

        # Splash logo (large display): prefer PNG always
        splash_logo_candidates = [
            os.path.join(images_dir, "astrosuitepro.png"),
            os.path.join(images_dir, "astrosuite.png"),
            os.path.join(images_dir, "astrosuitepro.ico"),
            os.path.join(images_dir, "astrosuite.ico"),
        ]

        # Startup background (optional)
        startup_bg_candidates = [
            os.path.join(images_dir, "startup_background.png"),
            os.path.join(images_dir, "startup_bg.png"),
            os.path.join(images_dir, "splash_background.png"),
        ]

        app_icon_path = ""
        for p in app_icon_candidates:
            if os.path.exists(p):
                app_icon_path = p
                break

        splash_logo_path = ""
        for p in splash_logo_candidates:
            if os.path.exists(p):
                splash_logo_path = p
                break

        startup_bg_path = None
        for p in startup_bg_candidates:
            if os.path.exists(p):
                startup_bg_path = p
                break

        return app_icon_path, splash_logo_path, startup_bg_path

    def _resolve_early_paths() -> tuple[str, str, str | None]:
        """
        Returns (app_icon_path, splash_logo_path, startup_bg_path)
        using path existence only (NO Qt image/icon creation yet).
        """
        app_icon_path = ""
        splash_logo_path = ""
        startup_bg_path = None

        # Prefer centralized resources resolver if available
        try:
            from setiastro.saspro.resources import icon_path as res_icon_path, background_startup_path

            # app icon path from resources
            if res_icon_path and os.path.exists(res_icon_path):
                app_icon_path = res_icon_path

            # splash logo should prefer PNG for rendering
            # If resources.icon_path is ICO on Windows, try same stem .png first.
            if app_icon_path:
                root, ext = os.path.splitext(app_icon_path)
                png_try = root + ".png"
                if os.path.exists(png_try):
                    splash_logo_path = png_try
                else:
                    splash_logo_path = app_icon_path

            # startup background
            if background_startup_path and os.path.exists(background_startup_path):
                startup_bg_path = background_startup_path

        except Exception:
            pass

        # Legacy fallbacks
        legacy_app_icon, legacy_splash_logo, legacy_bg = _find_resource_paths_legacy()

        if not app_icon_path:
            app_icon_path = legacy_app_icon

        if not splash_logo_path:
            splash_logo_path = legacy_splash_logo or app_icon_path

        if not startup_bg_path:
            startup_bg_path = legacy_bg

        # Windows: for app icon only, prefer .ico sibling if current app icon is .png
        if sys.platform.startswith("win") and app_icon_path:
            root, ext = os.path.splitext(app_icon_path)
            if ext.lower() == ".png":
                ico_try = root + ".ico"
                if os.path.exists(ico_try):
                    app_icon_path = ico_try

        return app_icon_path, splash_logo_path, startup_bg_path

    # Resolve paths BEFORE QApplication and BEFORE any widgets (filesystem only)
    _early_app_icon_path, _early_splash_logo_path, _startup_bg_path = _resolve_early_paths()

    # ---------------------------
    # Create QApplication (Qt image/icon creation allowed after this)
    # ---------------------------

    _app = _SASProApplication(sys.argv)

    try:
        _app.setQuitOnLastWindowClosed(True)
    except Exception:
        pass

    # Linux startup diagnostics (kept from your original working flow)
    if sys.platform.startswith("linux"):
        try:
            print("Qt platform:", _app.platformName())
            print("QuitOnLastWindowClosed:", _app.quitOnLastWindowClosed())
            print("XDG_SESSION_TYPE:", os.environ.get("XDG_SESSION_TYPE"))
            print("QT_QPA_PLATFORM:", os.environ.get("QT_QPA_PLATFORM"))
            print("QT_OPENGL:", os.environ.get("QT_OPENGL"))
        except Exception:
            pass


    # ------------------------------------------------------------------
    # IMPORTANT: Use the SAME SIMPLE APP ICON INIT FLOW as the version
    # that worked for the Windows taskbar icon.
    # ------------------------------------------------------------------
    global _app_icon_obj, _app_icon_path
    _app_icon_path = _early_app_icon_path
    _app_icon_obj = QIcon()
    try:
        if _early_app_icon_path and os.path.exists(_early_app_icon_path):
            _app_icon_obj = QIcon(_early_app_icon_path)
            if _app_icon_obj.isNull() and sys.platform.startswith("win"):
                # fallback to png sibling if ico failed
                root, _ext = os.path.splitext(_early_app_icon_path)
                png_try = root + ".png"
                if os.path.exists(png_try):
                    _app_icon_obj = QIcon(png_try)

            if not _app_icon_obj.isNull():
                _app.setWindowIcon(_app_icon_obj)
            else:
                print(f"[startup] WARNING: Qt failed to load app icon '{_early_app_icon_path}'")
    except Exception as e:
        print(f"[startup] WARNING: setWindowIcon failed: {e!r}")

    # =========================================================================
    # PhotoshopStyleSplash - Custom splash screen widget
    # =========================================================================
    class _EarlySplash(QWidget):
        """
        A modern, Photoshop-style splash screen shown immediately on startup.
        """
        def __init__(self, logo_path: str):
            super().__init__()
            self._version = _EARLY_VERSION
            self._build = ""
            self.current_message = QCoreApplication.translate("Splash", "Starting...")
            self.technical_message = ""
            self.progress_value = 0

            self.setWindowFlags(
                Qt.WindowType.SplashScreen |
                Qt.WindowType.FramelessWindowHint |
                Qt.WindowType.WindowStaysOnTopHint
            )
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

            self.splash_width = 600
            self.splash_height = 400
            self.setFixedSize(self.splash_width, self.splash_height)

            screen = QGuiApplication.primaryScreen()
            if screen:
                screen_geo = screen.availableGeometry()
                x = (screen_geo.width() - self.splash_width) // 2 + screen_geo.x()
                y = (screen_geo.height() - self.splash_height) // 2 + screen_geo.y()
                self.move(x, y)

            self.logo_pixmap = self._load_logo(logo_path)

            self.bg_image_pixmap = QPixmap()
            if _startup_bg_path:
                bg_pm = QPixmap(_startup_bg_path)
                if not bg_pm.isNull():
                    self.bg_image_pixmap = bg_pm
                else:
                    print(f"[startup] WARNING: splash background failed to load: {_startup_bg_path}")

            self.title_font = QFont("Segoe UI", 28, QFont.Weight.Bold)
            self.subtitle_font = QFont("Segoe UI", 11)
            self.message_font = QFont("Segoe UI", 9)
            self.copyright_font = QFont("Segoe UI", 8)
            self.supporter_font = QFont("Segoe UI", 9)

            # Opt-in supporter credit (recognition only). Read straight from
            # QSettings so the splash carries no dependency on the heavy
            # common_utilities import, which hasn't happened this early.
            self._supporter_line = self._compute_supporter_line()

        def _load_logo(self, path: str) -> QPixmap:
            """Load splash logo. Prefer PNG path passed in; fallback robustly."""
            if not path or not os.path.exists(path):
                return QPixmap()

            ext = os.path.splitext(path)[1].lower()

            # For splash logo, PNG is preferred. ICO can work, but some ICOs look wrong when enlarged.
            if ext == ".ico":
                ic = QIcon(path)
                pm = ic.pixmap(256, 256)
                if pm.isNull():
                    pm = ic.pixmap(128, 128)
                if pm.isNull():
                    pm = QPixmap(path)
            else:
                pm = QPixmap(path)
                if pm.isNull():
                    pm = QIcon(path).pixmap(256, 256)

            if not pm.isNull():
                pm = pm.scaled(
                    180, 180,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation
                )
            else:
                print(f"[startup] WARNING: splash logo failed to load: {path}")

            return pm

        def setMessage(self, message: str):
            self.current_message = message
            self.repaint()
            if _app:
                _app.processEvents()

        def setTechnicalMessage(self, message: str):
            self.technical_message = message
            self.repaint()
            if _app:
                _app.processEvents()

        def setProgress(self, value: int):
            target = max(0, min(100, int(value)))
            start = float(self.progress_value)

            if target <= start or (target - start) < 1:
                self.progress_value = target
                self.repaint()
                if _app:
                    _app.processEvents()
                return

            steps = 15
            dt = 0.005
            for i in range(1, steps + 1):
                t = i / steps
                factor = -t * (t - 2)  # quadratic ease-out
                cur = start + (target - start) * factor
                self.progress_value = cur
                self.repaint()
                if _app:
                    _app.processEvents()
                time.sleep(dt)

            self.progress_value = target
            self.repaint()
            if _app:
                _app.processEvents()

        def _compute_supporter_line(self) -> str:
            """Supporter credit for the splash subtitle, or '' if none/hidden.

            Keys mirror common_utilities.get_supporter(); read via QSettings
            directly because common_utilities isn't imported at splash time.
            """
            try:
                from PyQt6.QtCore import QSettings
                s = QSettings()
                name = str(s.value("supporter/name", "") or "").strip()
                if not name:
                    return ""
                if bool(s.value("supporter/hidden", False, type=bool)):
                    return ""
                return QCoreApplication.translate(
                    "Splash", "\u2665 Supported by {0}").format(name)
            except Exception:
                return ""

        def setBuildInfo(self, version: str, build: str):
            self._version = version or _EARLY_VERSION
            self._build = build
            # Recompute in case the credit was entered/changed this session.
            self._supporter_line = self._compute_supporter_line()
            self.repaint()

        def paintEvent(self, event):
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.setRenderHint(QPainter.RenderHint.TextAntialiasing)

            w, h = self.splash_width, self.splash_height

            gradient = QLinearGradient(0, 0, 0, h)
            gradient.setColorAt(0.0, QColor(15, 15, 25))
            gradient.setColorAt(0.5, QColor(25, 25, 45))
            gradient.setColorAt(1.0, QColor(10, 10, 20))
            painter.fillRect(0, 0, w, h, gradient)

            if not self.bg_image_pixmap.isNull():
                temp = QPixmap(w, h)
                temp.fill(Qt.GlobalColor.transparent)

                ptmp = QPainter(temp)
                ptmp.setRenderHint(QPainter.RenderHint.Antialiasing)
                ptmp.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)

                scaled = self.bg_image_pixmap.scaled(
                    w, h,
                    Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                    Qt.TransformationMode.SmoothTransformation
                )

                sx = (w - scaled.width()) // 2
                sy = (h - scaled.height()) // 2
                ptmp.drawPixmap(sx, sy, scaled)

                ptmp.setCompositionMode(QPainter.CompositionMode.CompositionMode_DestinationIn)
                fade_gradient = QLinearGradient(0, 0, 0, h)
                fade_gradient.setColorAt(0.0, QColor(0, 0, 0, 255))
                fade_gradient.setColorAt(0.5, QColor(0, 0, 0, 255))
                fade_gradient.setColorAt(1.0, QColor(0, 0, 0, 0))
                ptmp.fillRect(0, 0, w, h, fade_gradient)
                ptmp.end()

                painter.save()
                painter.setOpacity(0.25)
                painter.drawPixmap(0, 0, temp)
                painter.restore()

            painter.setPen(QColor(60, 60, 80))
            painter.drawRect(0, 0, w - 1, h - 1)

            if not self.logo_pixmap.isNull():
                logo_x = (w - self.logo_pixmap.width()) // 2
                logo_y = 40
                painter.drawPixmap(logo_x, logo_y, self.logo_pixmap)

            # ─── SASPRO ASCII title ────────────────────────────────────────
            # Four rows, each a different color — top-down gradient
            # dim → magenta → bright magenta → white. All rows are exactly
            # 66 characters wide so columns line up in a monospace font.
            ascii_lines = [
                ("┌┐ ┌┐ ┌┬┐ ∙      ┌┐ ┌┐ ┌┬┐ ┌┐ ┌┐      ┌┐ ┐┐ ∙ ┌┬┐ ┌┐      ┌┐ ┌┐ ┌┐", QColor( 85,  85, 100)),
                ("││ ├   │  │      ├│ ││  │  ││ ││      ││ ││ │  │  ├       ││ ││ ││", QColor(170,  85, 170)),
                ("└┐ ││  │  │      ││ └┐  │  │┘ ││      └┐ ││ │  │  ││      │┘ │┘ ││", QColor(230, 110, 240)),
                ("└┘ └┘  ┘  ┘      ┘┘ └┘  ┘  ┘┘ └┘      └┘ └┘ ┘  ┘  └┘      ┘  ┘┘ └┘", QColor(255, 255, 255)),
            ]

            ascii_font = QFont("Consolas", 10)
            ascii_font.setStyleHint(QFont.StyleHint.Monospace)
            # Fallback chain so macOS / Linux builds still land on a mono
            # font that has the Unicode box-drawing glyphs.
            ascii_font.setFamilies(["Consolas", "Cascadia Mono", "Menlo",
                                    "DejaVu Sans Mono", "Courier New"])
            painter.setFont(ascii_font)

            fm = painter.fontMetrics()
            line_h = fm.height()
            block_top = 215  # was y=230 for the one-liner; nudged up because art is 4 rows
            for i, (line, color) in enumerate(ascii_lines):
                painter.setPen(color)
                text_w = fm.horizontalAdvance(line)
                x = (w - text_w) // 2
                y = block_top + i * line_h + fm.ascent()
                painter.drawText(x, y, line)

            # Compute subtitle y dynamically so it clears the taller title
            # block regardless of font metrics on this platform.
            subtitle_top = block_top + line_h * len(ascii_lines) + 8
            # ───────────────────────────────────────────────────────────────

            painter.setFont(self.subtitle_font)
            painter.setPen(QColor(180, 180, 200))
            subtitle_text = QCoreApplication.translate("Splash", "Version {0}").format(self._version)
            if self._build:
                if self._build == "dev":
                    subtitle_text += QCoreApplication.translate("Splash", "  •  Running locally from source code")
                else:
                    subtitle_text += QCoreApplication.translate("Splash", "  •  Build {0}").format(self._build)
            painter.drawText(QRect(0, subtitle_top, w, 25), Qt.AlignmentFlag.AlignCenter, subtitle_text)

            if self._supporter_line:
                painter.setFont(self.supporter_font)
                painter.setPen(QColor(212, 175, 55))   # gold, matches the About heart
                painter.drawText(QRect(0, subtitle_top + 26, w, 18),
                                 Qt.AlignmentFlag.AlignCenter, self._supporter_line)

            bar_margin = 50
            bar_height = 4
            bar_y = h - 70
            bar_width = w - (bar_margin * 2)

            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(40, 40, 60))
            painter.drawRoundedRect(bar_margin, bar_y, bar_width, bar_height, 2, 2)

            if self.progress_value > 0:
                fill_width = int(bar_width * float(self.progress_value) / 100.0)
                fill_width = max(0, min(bar_width, fill_width))
                if fill_width > 0:
                    bar_gradient = QLinearGradient(bar_margin, 0, bar_margin + bar_width, 0)
                    bar_gradient.setColorAt(0.0, QColor(80, 140, 220))
                    bar_gradient.setColorAt(1.0, QColor(140, 180, 255))
                    painter.setBrush(bar_gradient)
                    painter.drawRoundedRect(bar_margin, bar_y, fill_width, bar_height, 2, 2)

            painter.setFont(self.message_font)
            painter.setPen(QColor(150, 150, 180))
            painter.drawText(
                QRect(bar_margin, bar_y + 10, bar_width, 20),
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                self.current_message
            )

            if self.technical_message:
                technical_font = QFont("Segoe UI", 7)
                painter.setFont(technical_font)
                painter.setPen(QColor(80, 80, 110))
                painter.drawText(
                    QRect(bar_margin, bar_y + 28, bar_width, 16),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    self.technical_message
                )

            painter.setFont(self.copyright_font)
            painter.setPen(QColor(100, 100, 130))
            painter.drawText(
                QRect(0, h - 30, w, 20),
                Qt.AlignmentFlag.AlignCenter,
                "© 2024-2026 Franklin Marek (Seti Astro)  •  All Rights Reserved"
            )

            painter.end()

        def finish(self):
            self.hide()
            self.close()
            self.deleteLater()

        def start_fade_out(self, on_finished=None):
            if not _allow_window_opacity_effects():
                self.finish()
                if callable(on_finished):
                    on_finished()
                return

            self._anim = QPropertyAnimation(self, b"windowOpacity")
            self._anim.setDuration(1000)
            self._anim.setStartValue(1.0)
            self._anim.setEndValue(0.0)
            self._anim.setEasingCurve(QEasingCurve.Type.OutQuad)

            def _done():
                self.finish()
                if callable(on_finished):
                    on_finished()

            self._anim.finished.connect(_done)
            self._anim.start()

        def start_fade_in(self):
            if not _allow_window_opacity_effects():
                self.setWindowOpacity(1.0)
                return
            self.setWindowOpacity(0.0)
            self._anim = QPropertyAnimation(self, b"windowOpacity")
            self._anim.setDuration(800)
            self._anim.setStartValue(0.0)
            self._anim.setEndValue(1.0)
            self._anim.setEasingCurve(QEasingCurve.Type.InQuad)
            self._anim.start()

    # Create splash AFTER app icon is set (and use splash-logo path, not app icon path)
    _splash = _EarlySplash(_early_splash_logo_path)

    # Set splash window icon too (shell/task switcher help)
    try:
        if not _app_icon_obj.isNull():
            _splash.setWindowIcon(_app_icon_obj)
    except Exception:
        pass

    _splash.start_fade_in()
    _splash.show()

    # Allow fade-in to progress before heavy imports start
    t_start = time.time()
    while time.time() - t_start < 0.85:
        _app.processEvents()
        try:
            if _allow_window_opacity_effects() and _splash.windowOpacity() >= 0.99:
                break
        except Exception:
            break
        time.sleep(0.01)

    _splash.setMessage(QCoreApplication.translate("Splash", "Initializing Python runtime..."))
    _splash.setProgress(2)
    _app.processEvents()

    # Load translation BEFORE any other widgets are created
    try:
        from setiastro.saspro.i18n import load_language, get_translations_dir  # keep same import shape as original
        _ = get_translations_dir  # avoid lint complaints if unused
        ok = load_language(app=_app)
    except Exception as e:
        print("i18n load failed:", repr(e))

    _splash_initialized = True

# =============================================================================
# Now proceed with all the heavy imports (splash is visible)
# =============================================================================

# Helper to update splash during imports
def _update_splash(msg: str, progress: int):
    global _splash
    if _splash is not None:
        _splash.setMessage(msg)
        _splash.setProgress(progress)

def _update_splash_technical(msg: str):
    global _splash
    if _splash is not None:
        _splash.setTechnicalMessage(msg)

def _bootstrap_imports():
    """
    Heavy imports + runtime bootstrap.
    This must NOT run at module import time, only when main() is called.
    """
    global _imports_bootstrapped
    if _imports_bootstrapped:
        return
    _imports_bootstrapped = True
 
    if not _splash_initialized:
        _init_splash()
    # ── Gravitas field messages ───────────────────────────────────────
    import random

    _GRAVITAS_MESSAGES = [
        "Preserving diffuse gravitas fields...",
        "Initializing volumetric coherence engine...",
        "Calibrating transitional density gradients...",
        "Mapping low-frequency spatial continuity...",
        "Harmonizing environmental structure tensors...",
        "Synchronizing large-scale field topology...",
        "Resolving photometric flux coherence vectors...",
        "Warming up statistical homogenization suppressor...",
        "Aligning nebular gravitas preservers...",
        "Configuring spatially believable rendering pipeline...",
        "Bootstrapping coherent emission field integrator...",
        "Loading diffuse structure continuity module...",
        "Preparing quantum-adjacent star alignment kernels...",
        "Engaging probabilistic pixel gravity synthesizer...",
        "Normalizing interstellar density transition buffers...",
        "Convincing hot pixels they are not stars...", 
        "Checking whether Pluto is a planet today...",
        "Debating optimal sigma-clipping thresholds internally...",
    ]
    random.shuffle(_GRAVITAS_MESSAGES)
    _grav_idx = [0]

    def _update_splash_gravitas(progress: int):
        msg = _GRAVITAS_MESSAGES[_grav_idx[0] % len(_GRAVITAS_MESSAGES)]
        _grav_idx[0] += 1
        _update_splash(msg, progress)
    # ─────────────────────────────────────────────────────────────────
    import sys as _sys 
    if getattr(_sys, "frozen", False):
        try:
            import os as _os
            from pathlib import Path as _Path
            _os.chdir(_Path.home())
        except Exception:
            pass
    _update_splash_gravitas(5)
    _update_splash_technical("Loading PyTorch runtime...")
 
    from setiastro.saspro.runtime_torch import (
        add_runtime_to_sys_path,
        _ban_shadow_torch_paths,
        _purge_bad_torch_from_sysmodules,
    )
 
    # Inject runtime site-packages IMMEDIATELY so bare `import torch` calls
    # in any subsequently-imported module can resolve against the wheel.

    _ban_shadow_torch_paths(status_cb=lambda *_: None)
    _purge_bad_torch_from_sysmodules(status_cb=lambda *_: None)
    add_runtime_to_sys_path(status_cb=lambda *_: None)
 
    # ── Probe whether torch is actually importable right now ──────────────────
    _torch_actually_available = False
    try:
        import importlib.util as _ilu
        if _ilu.find_spec("torch") is not None:
            import torch as _torch_probe  # noqa
            _torch_actually_available = True
 
            # ── Pre-warm torch._C._InferenceMode in the main thread ──────────
            # torch 2.6+ on Windows has a pybind11 thread-affinity quirk where
            # torch._C._InferenceMode is absent when torch is first accessed
            # inside a QThread (CUDA context not yet initialized on that thread).
            # Touching it here in the main thread — where the CUDA context IS
            # fully initialized — ensures the attribute is registered in the
            # shared C extension state before any worker thread runs.
            # This prevents 'module torch._C has no attribute _InferenceMode'
            # errors in QThreads that use spandrel or call model().
            try:
                if hasattr(_torch_probe, "_C") and not hasattr(_torch_probe._C, "_InferenceMode"):
                    # Force CUDA context init on the main thread so pybind11
                    # registers the C++ class bindings that back _InferenceMode.
                    if hasattr(_torch_probe, "cuda") and _torch_probe.cuda.is_available():
                        _ = _torch_probe.zeros(1, device="cuda")
                    # Verify the attribute appeared after the CUDA touch.
                    # If it still doesn't exist, install a Python-level shim so
                    # all threads (which share torch._C) have a working fallback.
                    if not hasattr(_torch_probe._C, "_InferenceMode"):
                        class _InferenceModeShim:
                            """
                            Pure-Python fallback for torch._C._InferenceMode.
                            Used when the pybind11 C++ binding fails to register
                            in the current process (torch 2.6+ / Windows quirk).
                            Disables gradient computation exactly like the real class.
                            """
                            def __init__(self, enabled=True):
                                self._enabled = bool(enabled)
                                self._prev = False
                            def __enter__(self):
                                self._prev = _torch_probe.is_grad_enabled()
                                if self._enabled:
                                    _torch_probe.set_grad_enabled(False)
                                return self
                            def __exit__(self, *args):
                                _torch_probe.set_grad_enabled(self._prev)
                        _torch_probe._C._InferenceMode = _InferenceModeShim
                        print("[SASpro] torch._C._InferenceMode shim installed (torch 2.6+ thread quirk)")
                    else:
                        print("[SASpro] torch._C._InferenceMode pre-warmed ok")
            except Exception as _e:
                print(f"[SASpro] torch._C._InferenceMode pre-warm warning (non-fatal): {_e}")
 
    except Exception:
        _torch_actually_available = False

 
    # ── If torch is absent, inject a stub so the GUI can still open ───────────
    if not _torch_actually_available:
        import types
        import sys as _sys
 
        _TORCH_NOT_INSTALLED_MSG = (
            "PyTorch is not installed in the SASpro runtime venv.\n"
            "Go to Settings -> Preferences -> Install/Repair Hardware Acceleration."
        )
 
        class _TorchUnavailableStub(types.ModuleType):
            """
            Injected into sys.modules when the runtime venv has no torch.
            Attribute access returns child stubs so module-level imports like
            `import torch.nn as nn` don't crash.  Any real usage (calling,
            subclassing nn.Module, tensor ops) raises RuntimeError with a
            clear install prompt.
            """
            def __init__(self, name: str = "torch"):
                super().__init__(name)
                self.__path__ = []    # makes Python treat it as a package
                self.__spec__ = None
                self.__version__ = "0.0.0+unavailable"
                # NOTE: torch.cuda / torch.version are deliberately NOT set
                # here any more. They used to be built with __new__ (skipping
                # __init__), which left them without a __name__ -- so the very
                # first __getattr__ on one would blow up inside the f-string
                # below. They now resolve lazily through __getattr__ to the
                # fully-constructed stubs that the _torch_submods loop installs
                # into sys.modules immediately after this class is defined.

            def __getattr__(self, name: str):
                # CRITICAL: never fabricate a child stub for a dunder.
                #
                # inspect.getmodule() walks every entry in sys.modules probing
                # __file__ (and friends). If __file__ hands back a module
                # object, inspect.getfile() falls through to its
                # `raise TypeError('{!r} is a built-in module'.format(object))`
                # branch -- and that repr goes through importlib's
                # _module_repr, which formats self.__file__ with !r, whose
                # __file__ is another stub, whose __file__ is another stub...
                # 950 frames later: RecursionError, during the astropy.nddata
                # import triggered by the reproject guard below.
                #
                # Real built-in modules raise AttributeError for __file__.
                # So do we. That terminates the walk cleanly.
                if name.startswith("__") and name.endswith("__"):
                    raise AttributeError(name)

                child_key = f"{self.__name__}.{name}"
                child = _sys.modules.get(child_key)
                if child is None:
                    child = _TorchUnavailableStub(child_key)
                    _sys.modules[child_key] = child
                return child

            # Belt and braces: give repr() a terminating implementation of its
            # own, so no future introspection path can re-enter the cycle above
            # even if it reaches us by some other route.
            def __repr__(self) -> str:
                return f"<module {self.__name__!r} (SASpro torch-unavailable stub)>"

            def __call__(self, *a, **kw):
                raise RuntimeError(_TORCH_NOT_INSTALLED_MSG)

            def __bool__(self):
                return False

            # Keep isinstance(x, torch.nn.Module) from crashing -- just False.
            # Works because the second isinstance argument is a stub INSTANCE,
            # so Python looks __instancecheck__ up on _TorchUnavailableStub.
            def __instancecheck__(self, instance):
                return False

            # Make `torch.cuda.is_available()` return False instead of crashing
            def is_available(self):
                return False

        # Only inject if torch is genuinely absent
        if "torch" not in _sys.modules:
            _stub_root = _TorchUnavailableStub("torch")
            _sys.modules["torch"] = _stub_root
 
            # Pre-populate the sub-modules most commonly imported at module level
            _torch_submods = [
                "torch.nn",
                "torch.nn.functional",
                "torch.nn.modules",
                "torch.cuda",
                "torch.backends",
                "torch.backends.mps",
                "torch.backends.cudnn",
                "torch.utils",
                "torch.utils.data",
                "torch.amp",
                "torch.version",
                "torch.jit",
                "torch.onnx",
            ]
            for _sm in _torch_submods:
                if _sm not in _sys.modules:
                    _sys.modules[_sm] = _TorchUnavailableStub(_sm)
 
            print(
                "[SASpro] torch not available in runtime venv -> stub injected. "
                "GPU tools will be unavailable until Hardware Acceleration is installed "
                "via Settings -> Preferences."
            )

    # ── reproject.spherical_intersect SAC guard ──────────────────────────────
    # reproject's __init__.py eagerly imports its C-extension submodule
    # `spherical_intersect` (which backs reproject_exact) at package load.
    # SASpro only ever calls reproject_interp — pure Python — but the eager
    # import means ANY failure loading the compiled _overlap.pyd takes the
    # whole reproject package down with it, and star_alignment/mosaic_master
    # can't even import.
    #
    # Windows 11 24H2's Smart App Control has started quarantining the
    # _overlap.pyd shipped in the reproject wheel on some installs (first
    # reported Oct 2026, after KB5127647 / KB5127648). The quarantine fires
    # at DLL-load time with:
    #   ImportError: DLL load failed while importing _overlap:
    #                An Application Control policy has blocked this file.
    # We can't sign every third-party wheel, so the practical defence is:
    # try the real import once, and if it fails for ANY reason (SAC block,
    # missing DLL, broken wheel), replace reproject.spherical_intersect in
    # sys.modules with a stub whose reproject_exact raises a clear
    # RuntimeError at call time. Downstream `from reproject import
    # reproject_interp` then succeeds, star_alignment loads, Stacking
    # Suite launches, and nothing in SASpro that we actually use is lost.
    # Must run BEFORE the main_window import below, which pulls
    # star_alignment -> reproject. Same ordering requirement as the torch
    # stub above.
    try:
        import reproject.spherical_intersect  # noqa: F401
    except (ImportError, OSError) as _reproject_err:
        import types as _types2
        _stub = _types2.ModuleType("reproject.spherical_intersect")
        _reproject_err_captured = _reproject_err
        def _reproject_exact_unavailable(*_a, **_kw):
            raise RuntimeError(
                "reproject_exact is unavailable on this system "
                f"({_reproject_err_captured}). SASpro only uses "
                "reproject_interp, so stacking and WCS alignment still "
                "work; if you need reproject_exact specifically, see "
                "https://aka.ms/smartappcontrol about Smart App Control."
            )
        _stub.reproject_exact = _reproject_exact_unavailable
        _sys.modules["reproject.spherical_intersect"] = _stub
        print(
            f"[SASpro] reproject.spherical_intersect unavailable "
            f"({_reproject_err}); stub injected. "
            "reproject_interp (what SASpro actually uses) still works."
        )

    _update_splash_gravitas(7)
    _update_splash_technical("Preparing AI runtime cache...")
    try:
        from setiastro.saspro.runtime_torch import prewarm_torch_cache
        prewarm_torch_cache(
            status_cb=lambda *_: None,
            require_torchaudio=False,
            ensure_venv=True,
            ensure_numpy=False,
            validate_marker=True,
        )
    except Exception:
        pass
 
    _update_splash_gravitas(10)
    _update_splash_technical("Loading standard libraries...")
 
    import importlib
    import json
    import logging
    import math
    import multiprocessing
    import os
    import re
    import sys
    import threading
    import time
    import traceback
    import warnings
    import webbrowser
 
    from collections import defaultdict
    from datetime import datetime
    from decimal import getcontext
    from io import BytesIO
    from itertools import combinations
    from math import isnan
    from pathlib import Path
    from typing import Dict, List, Optional, Set, Tuple
    from urllib.parse import quote, quote_plus
 
    _update_splash_gravitas(15)
    _update_splash_technical("Loading NumPy...")
 
    _update_splash_gravitas(25)
    _update_splash_technical("Configuring matplotlib...")
    from setiastro.saspro.config_bootstrap import ensure_mpl_config_dir
    _MPL_CFG_DIR = ensure_mpl_config_dir()
 
    from setiastro.saspro.metadata_patcher import apply_metadata_patches
    apply_metadata_patches()
 
    warnings.filterwarnings(
        "ignore",
        message=r"Call to deprecated function \(or staticmethod\) _destroy\.",
        category=DeprecationWarning,
    )
 
    os.environ["LIGHTKURVE_STYLE"] = "default"
 
    # ── Linux: FreeType symbol clash with Qt ─────────────────────────────────
    # matplotlib's wheel links its own FreeType into the ft2font extension, but
    # Python dlopens extensions RTLD_LOCAL, so ft2font's FT_* lookups search the
    # GLOBAL symbol scope first — where libQt6Gui has already published the
    # system libfreetype.so.6. An older system FreeType then services calls
    # compiled against a newer one, the glyph metrics come out garbage, and the
    # first text render dies with:
    #     RuntimeError: FT_Render_Glyph (ft2font_wrapper.cpp line 1943)
    #                   failed with error 0x62: raster overflow
    # In practice that surfaces as a tool window refusing to open at all
    # ("Could not open Dither Analysis: ..."), since the exception comes out of
    # the first Qt paint of the canvas.
    #
    # RTLD_DEEPBIND makes ft2font prefer its own bundled FreeType. Qt keeps
    # using the system one; neither interferes with the other.
    #
    # This has to be the FIRST matplotlib import in the process — the extension
    # module is cached after it, so a later rebind is impossible. Hence here and
    # not at module scope: ensure_mpl_config_dir() above must set MPLCONFIGDIR
    # before matplotlib reads it, and the splash is already up by this point.
    # Upstream: https://github.com/matplotlib/matplotlib/issues/32208
    # SASPRO_FT2FONT_DEEPBIND
    if hasattr(os, "RTLD_DEEPBIND"):   # glibc Linux only; absent on Win/mac/musl
        if "matplotlib" in sys.modules:
            print("[ft2font] matplotlib already imported - deepbind preload "
                  "skipped; Linux text rendering may fail", file=sys.stderr)
        else:
            _dl_flags = sys.getdlopenflags()
            try:
                sys.setdlopenflags(_dl_flags | os.RTLD_DEEPBIND)
                from matplotlib import ft2font as _ft2font  # noqa: F401
            except Exception as _ft_exc:
                print(f"[ft2font] deepbind preload failed: {_ft_exc}",
                      file=sys.stderr)
            finally:
                sys.setdlopenflags(_dl_flags)

    import matplotlib
    try:
        matplotlib.use("QtAgg", force=True)
    except TypeError:
        matplotlib.use("QtAgg")
 
    try:
        matplotlib.rcParams["text.usetex"] = False
        matplotlib.rcParams["mathtext.fontset"] = "dejavusans"
        matplotlib.rcParams["font.family"] = "DejaVu Sans"
    except Exception:
        pass
 
    def _force_mpl_no_tex():
        try:
            matplotlib.rcParams["text.usetex"] = False
            matplotlib.rcParams["mathtext.fontset"] = "dejavusans"
            matplotlib.rcParams["font.family"] = "DejaVu Sans"
        except Exception:
            pass
 
    _force_mpl_no_tex()
 
    if (sys.stdout is not None) and (hasattr(sys.stdout, "reconfigure")):
        sys.stdout.reconfigure(encoding='utf-8')
 
    global _photutils_isophote
    _photutils_isophote = None
 
    def _get_photutils_isophote():
        global _photutils_isophote
        if _photutils_isophote is None:
            try:
                from photutils import isophote as _isophote_module
                _photutils_isophote = _isophote_module
            except Exception:
                _photutils_isophote = False
        return _photutils_isophote if _photutils_isophote else None
 
    def get_Ellipse():
        mod = _get_photutils_isophote()
        return mod.Ellipse if mod else None
 
    def get_EllipseGeometry():
        mod = _get_photutils_isophote()
        return mod.EllipseGeometry if mod else None
 
    def get_build_ellipse_model():
        mod = _get_photutils_isophote()
        return mod.build_ellipse_model if mod else None
 
    global _lightkurve_module
    _lightkurve_module = None
 
    def get_lightkurve():
        global _lightkurve_module
        if _lightkurve_module is None:
            try:
                import lightkurve as _lk
                _lk.MPLSTYLE = None
                _lightkurve_module = _lk
            except Exception:
                _lightkurve_module = False
            _force_mpl_no_tex()
        return _lightkurve_module if _lightkurve_module else None
 
    _update_splash_gravitas(30)
    _update_splash_technical("Loading UI utilities...")
 
    from setiastro.saspro.widgets.common_utilities import (
        AboutDialog,
        ProjectSaveWorker as _ProjectSaveWorker,
        DECOR_GLYPHS,
        _strip_ui_decorations,
        install_crash_handlers,
    )
 
    _update_splash_gravitas(45)
    _update_splash_technical("Loading PyQt6 components...")
 
    from PyQt6 import sip
 
    from PyQt6.QtWidgets import (QDialog, QApplication, QMainWindow, QWidget, QHBoxLayout, QFileDialog, QMessageBox, QSizePolicy, QToolBar, QPushButton, QAbstractItemDelegate,
        QLineEdit, QMenu, QListWidget, QListWidgetItem, QSplashScreen, QDockWidget, QListView, QCompleter, QMdiArea, QMdiSubWindow, QWidgetAction, QAbstractItemView,
        QInputDialog, QVBoxLayout, QLabel, QCheckBox, QProgressBar, QProgressDialog, QGraphicsItem, QTabWidget, QTableWidget, QHeaderView, QTableWidgetItem, QToolButton, QPlainTextEdit
    )
    from PyQt6.QtGui import (QPixmap, QColor, QIcon, QKeySequence, QShortcut, QGuiApplication, QStandardItemModel, QStandardItem, QAction, QPalette, QBrush, QActionGroup, QDesktopServices, QFont, QTextCursor
    )
    from PyQt6.QtCore import (Qt, pyqtSignal, QTimer, QSize, QSignalBlocker, QModelIndex, QThread, QUrl, QSettings, QEvent, QByteArray, QObject,
        QPropertyAnimation, QEasingCurve
    )
    from PyQt6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply
 
    global BUILD_TIMESTAMP
    try:
        from setiastro.saspro._generated.build_info import BUILD_TIMESTAMP
    except Exception:
        BUILD_TIMESTAMP = "dev"
 
    _update_splash_gravitas(50)
    _update_splash_technical("Loading resources...")
 
    from setiastro.saspro.resources import (
        icon_path, windowslogo_path,
    )
 
    _update_splash_gravitas(55)
    _update_splash_technical("Configuring Qt message handler...")
 
    from PyQt6.QtCore import qInstallMessageHandler, QtMsgType
 
    def _qt_msg_handler(mode, ctx, msg):
        lvl = {
            QtMsgType.QtDebugMsg:    logging.DEBUG,
            QtMsgType.QtInfoMsg:     logging.INFO,
            QtMsgType.QtWarningMsg:  logging.WARNING,
            QtMsgType.QtCriticalMsg: logging.ERROR,
            QtMsgType.QtFatalMsg:    logging.CRITICAL,
        }.get(mode, logging.ERROR)
        logging.log(lvl, "Qt: %s (%s:%s)", msg, getattr(ctx, "file", "?"), getattr(ctx, "line", -1))
 
    qInstallMessageHandler(_qt_msg_handler)
 
    _update_splash_gravitas(60)
    _update_splash_technical("Loading MDI widgets...")
 
    from setiastro.saspro.mdi_widgets import (
        MdiArea, ViewLinkController, ConsoleListWidget, QtLogStream, _DocProxy,
        ROLE_ACTION as _ROLE_ACTION,
    )
 
    from setiastro.saspro.main_helpers import (
        safe_join_dir_and_name as _safe_join_dir_and_name,
        normalize_save_path_chosen_filter as _normalize_save_path_chosen_filter,
        display_name as _display_name,
        best_doc_name as _best_doc_name,
        doc_looks_like_table as _doc_looks_like_table,
        is_alive as _is_alive,
        safe_widget as _safe_widget,
    )
 
    from setiastro.saspro.file_utils import (
        _normalize_ext,
        _sanitize_filename,
        _exts_from_filter,
        REPLACE_SPACES_WITH_UNDERSCORES as _REPLACE_SPACES_WITH_UNDERSCORES,
        WIN_RESERVED_NAMES as _WIN_RESERVED,
    )
 
    _update_splash_gravitas(65)
    _update_splash_technical("Loading main window module...")
 
    # Wrap the main_window import to catch sys.exit() / ImportError from any
    # remaining bare `import torch` that slipped through the stub net.
    try:
        from setiastro.saspro.gui.main_window import AstroSuiteProMainWindow
    except SystemExit as e:
        raise RuntimeError(
            "A module called sys.exit() during import.\n\n"
            "This usually means a module still has a bare `import torch` at "
            "module level that is not covered by the torch stub.\n\n"
            "Open Settings -> Preferences -> Install/Repair Hardware Acceleration "
            "to install PyTorch, then restart.\n\n"
            f"Original exit code: {e.code}"
        ) from e
    except ImportError as e:
        msg = str(e)
        if "torch" in msg.lower() or "pytorch" in msg.lower():
            raise RuntimeError(
                "A module failed to import because PyTorch is not available.\n\n"
                "Open Settings -> Preferences -> Install/Repair Hardware Acceleration.\n\n"
                f"Original error: {e}"
            ) from e
        raise
 
    _update_splash_gravitas(70)
    _update_splash_technical("Modules loaded, finalizing...")
 
    globals().update({
        "logging": logging,
        "multiprocessing": multiprocessing,
        "warnings": warnings,
        "QIcon": QIcon,
        "QMessageBox": QMessageBox,
        "QPropertyAnimation": QPropertyAnimation,
        "QEasingCurve": QEasingCurve,
        "windowslogo_path": windowslogo_path,
        "icon_path": icon_path,
        "install_crash_handlers": install_crash_handlers,
        "AstroSuiteProMainWindow": AstroSuiteProMainWindow,
        "BUILD_TIMESTAMP": BUILD_TIMESTAMP,
        "_force_mpl_no_tex": _force_mpl_no_tex,
        "_torch_actually_available": _torch_actually_available,
    })




def _init_opengl_before_qapp():
    """
    MUST run before QApplication is constructed.

    Creating the first QOpenGLWidget after the app is up makes Qt destroy and
    recreate the top-level native window — which wipes the dock layout. Setting
    AA_ShareOpenGLContexts up front lets the later GL widget (the Gaia
    Neighborhood Explorer) share the existing context instead of forcing a
    window rebuild.

    pyqtgraph's GLViewWidget still issues fixed-function calls (glMatrixMode,
    glLoadMatrixf), so it needs a compatibility profile, not core.
    """    
    import sys
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QSurfaceFormat
    from PyQt6.QtWidgets import QApplication    

    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts, True)

    fmt = QSurfaceFormat()
    fmt.setDepthBufferSize(24)
    fmt.setStencilBufferSize(8)
    fmt.setProfile(QSurfaceFormat.OpenGLContextProfile.CompatibilityProfile)
    fmt.setSwapBehavior(QSurfaceFormat.SwapBehavior.DoubleBuffer)
    QSurfaceFormat.setDefaultFormat(fmt)


def main(argv: list[str] | None = None, *, _skip_handoff: bool = False) -> int:
    """
    Main entry point for Seti Astro Suite Pro.
    
    This function can be called from:
    - The package entry point (setiastrosuitepro command)
    - Direct import and call
    - When running as a module: python -m setiastro.saspro
    """
    # Catch multiprocessing spawn children FIRST — before the splash, OpenGL
    # init, or any heavy work. In a frozen build every process-pool worker
    # re-execs this EXE and runs main(); freeze_support() takes the child over
    # here and never returns, so it can no longer flash the splash on its way
    # to being a worker. (The later multiprocessing block is now a no-op.)
    import multiprocessing as _mp
    _mp.freeze_support()
    try:
        _mp.set_start_method("spawn", force=True)
    except RuntimeError:
        pass

    # ── Single-instance handoff ──────────────────────────────────────────────
    # If another SASpro is already running (in the same bucket — frozen builds
    # share one bucket, source checkouts share another; see single_instance.py
    # for the policy) and the user did NOT pass --new-instance / set
    # SASPRO_NEW_INSTANCE=1, hand our argv off to it and exit — BEFORE the
    # splash paints, before OpenGL init, before heavy imports — so the user
    # sees nothing but the existing window popping to the front with their
    # file open in it.
    #
    # _skip_handoff=True means __main__.entry() already ran this probe against
    # the RAW argv (including any --new-instance flag) and either handed off or
    # decided we're the primary. Running it again here would re-probe with the
    # already-stripped argv — losing the --new-instance signal — and silently
    # hand the "new instance" launch back to the running primary. The direct
    # cli._launch_gui() path leaves this False so single-instance still works
    # for `python -m setiastro.saspro.cli file.fits`.
    if not _skip_handoff:
        try:
            from setiastro.saspro.single_instance import maybe_handoff_and_exit
            _effective_argv = argv if argv is not None else sys.argv[1:]
            _cleaned = maybe_handoff_and_exit(_effective_argv)
            if _cleaned is None:
                # Primary accepted our handoff. We're done; secondary exits silently.
                return 0
            # Strip --new-instance / --single-instance from argv for the rest of main().
            argv = _cleaned
        except Exception:
            # Single-instance failure must never block launch. Fall through and
            # start a normal full instance.
            import traceback as _tb
            print("[single-instance] probe failed, launching normally:")
            _tb.print_exc()
    else:
        # Caller already handled handoff with the raw argv; just normalize
        # our view of argv so downstream code (_collect_open_paths etc.)
        # sees the cleaned list.
        try:
            from setiastro.saspro.single_instance import parse_instance_flags
            argv = parse_instance_flags(argv).remaining
        except Exception:
            # If flag parsing somehow blows up, use argv as-is. Downstream
            # tolerates stray flags via _collect_open_paths' startswith("-")
            # filter, so there's no crash risk here.
            pass

    _init_opengl_before_qapp()
    global _splash, _app, _splash_initialized
    from PyQt6.QtCore import QTimer
    import logging
    logging.getLogger("OpenGL.acceleratesupport").setLevel(logging.WARNING)
    open_paths = _collect_open_paths(argv)
    
    # Initialize splash if not already done
    if not _splash_initialized:
        _init_splash()

    _bootstrap_imports()
    # Update splash with build info now that we have VERSION and BUILD_TIMESTAMP
    if _splash:
        _splash.setBuildInfo(VERSION, BUILD_TIMESTAMP)
        _splash.setMessage(QCoreApplication.translate("Splash", "Setting up logging..."))
        _splash.setProgress(72)
    
    # --- Logging (catch unhandled exceptions to a file) ---
    import tempfile
    from pathlib import Path
 
    # Cross-platform log file location
    def get_log_file_path():
        """Get appropriate log file path for the current platform."""
        
        if hasattr(sys, '_MEIPASS'):
            # Running in PyInstaller bundle - use platform-appropriate user directory
            if sys.platform.startswith('win'):
                # Windows: %APPDATA%\SetiAstroSuitePro\logs\
                log_dir = Path(os.path.expandvars('%APPDATA%')) / 'SetiAstroSuitePro' / 'logs'
            elif sys.platform.startswith('darwin'):
                # macOS: ~/Library/Logs/SetiAstroSuitePro/
                log_dir = Path.home() / 'Library' / 'Logs' / 'SetiAstroSuitePro'
            else:
                # Linux: ~/.local/share/SetiAstroSuitePro/logs/
                log_dir = Path.home() / '.local' / 'share' / 'SetiAstroSuitePro' / 'logs'
            
            # Create directory if it doesn't exist
            try:
                log_dir.mkdir(parents=True, exist_ok=True)
                log_file = log_dir / 'saspro.log'
            except (OSError, PermissionError):
                # Fallback to temp directory if user directory fails
                log_file = Path(tempfile.gettempdir()) / 'saspro.log'
        else:
            # Development mode - use logs folder in project
            log_dir = Path('logs')
            try:
                log_dir.mkdir(parents=True, exist_ok=True)
                log_file = log_dir / 'saspro.log'
            except (OSError, PermissionError):
                log_file = Path('saspro.log')
        
        return str(log_file)
    
    # Configure logging with cross-platform path
    log_file_path = get_log_file_path()

    try:
        _root = logging.getLogger()
        _root.setLevel(logging.INFO)
        # A library called basicConfig() during import and left a StreamHandler
        # at WARNING, which made our basicConfig(filename=...) a silent no-op.
        # Tear down whatever's there and own the root logger explicitly.
        for _h in list(_root.handlers):
            _root.removeHandler(_h)
            try:
                _h.close()
            except Exception:
                pass
        _fmt = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        from logging.handlers import RotatingFileHandler
        _fh = RotatingFileHandler(
            log_file_path, mode="a", maxBytes=1_000_000, backupCount=3, encoding="utf-8"
        )
        _fh.setFormatter(_fmt)
        _root.addHandler(_fh)
        logging.info("=" * 60)
        logging.info("SASpro %s starting — %s", VERSION, log_file_path)        
        # Optional: also keep console output while running from source
        _sh = logging.StreamHandler(sys.stdout)
        _sh.setFormatter(_fmt)
        _root.addHandler(_sh)
        logging.info("Logging initialized -> %s", log_file_path)
        logging.info("Platform: %s", sys.platform)
        logging.info("PyInstaller bundle: %s", hasattr(sys, "_MEIPASS"))
    except Exception as e:
        print(f"Warning: could not initialize file logging at {log_file_path}: {e}")
        

    # Setup crash handlers and app icon
    if _splash:
        _splash.setMessage(QCoreApplication.translate("Splash", "Installing crash handlers..."))
        _splash.setProgress(75)
    install_crash_handlers(_app) 
    try:
        if _app_icon_obj is not None and not _app_icon_obj.isNull():
            _app.setWindowIcon(_app_icon_obj)
    except Exception:
        pass


    # --- Windows exe / multiprocessing friendly ---
    if _splash:
        _splash.setMessage(QCoreApplication.translate("Splash", "Configuring multiprocessing..."))
        _splash.setProgress(78)
    try:
        multiprocessing.freeze_support()
        try:
            multiprocessing.set_start_method("spawn", force=True)
        except RuntimeError:
            # Already set in this interpreter
            pass
    except Exception:
        logging.exception("Multiprocessing init failed (continuing).")

    try:
        if _splash:
            _splash.setMessage(QCoreApplication.translate("Splash", "Loading image manager..."))
            _splash.setProgress(80)
        from setiastro.saspro.legacy.image_manager import ImageManager
        
        if _splash:
            _splash.setMessage(QCoreApplication.translate("Splash", "Suppressing warnings..."))
            _splash.setProgress(82)
        from matplotlib import MatplotlibDeprecationWarning
        warnings.filterwarnings("ignore", category=MatplotlibDeprecationWarning)

        if _splash:
            _splash.setMessage(QCoreApplication.translate("Splash", "Creating image manager..."))
            _splash.setProgress(85)
        imgr = ImageManager(max_slots=100)
        
        if _splash:
            _splash.setMessage(QCoreApplication.translate("Splash", "Building main window..."))
            _splash.setProgress(90)
        win = AstroSuiteProMainWindow(
            image_manager=imgr,
            version=VERSION,
            build_timestamp=BUILD_TIMESTAMP,
        )
        try:
            if _app_icon_obj is not None and not _app_icon_obj.isNull():
                win.setWindowIcon(_app_icon_obj)
        except Exception:
            pass

        # ── Install single-instance primary listener ─────────────────────────
        # From now on, any secondary SASpro launch in our bucket will hand its
        # argv to us instead of starting fresh. The handler runs on the Qt
        # main thread, raises our window, and routes paths through the doc
        # manager's open_path() — the same sink used by the CLI path and by
        # macOS QFileOpenEvents, so there's one code path for "a file arrived
        # from the outside world".
        try:
            from setiastro.saspro.single_instance import (
                install_primary_listener, raise_window_to_front,
            )

            def _on_handoff(payload: dict):
                try:
                    handoff_argv = payload.get("argv") or []
                    paths = _collect_open_paths(handoff_argv)
                    logging.info(
                        "[single-instance] handoff received: %d path(s) from pid=%s",
                        len(paths), payload.get("pid"),
                    )

                    raise_window_to_front(win)

                    if paths:
                        dm = getattr(win, "docman", None) or getattr(win, "doc_manager", None)
                        if dm is None:
                            logging.warning("[single-instance] no doc manager, can't open paths")
                            return
                        for p in paths:
                            try:
                                dm.open_path(p)
                            except Exception:
                                logging.exception("[single-instance] open_path failed: %s", p)
                except Exception:
                    logging.exception("[single-instance] handoff handler crashed")

            # Hang the server off the main window so GC doesn't eat it.
            win._single_instance_server = install_primary_listener(
                _app, _on_handoff, status_cb=lambda m: logging.info(m)
            )
        except Exception:
            logging.exception("[single-instance] failed to install primary listener (continuing)")

        # ── macOS QFileOpenEvent plumbing ───────────────────────────────────
        # On macOS, Finder's "Open With -> SetiAstroSuitePro" and dock-dropped
        # files fire QFileOpenEvent on the QApplication. _SASProApplication
        # buffers any that arrive before the main window exists. Now that it
        # does, install the live callback and drain whatever's queued.
        if sys.platform == "darwin":
            def _open_one_from_event(path: str):
                try:
                    raise_window_to_front(win)
                    dm = getattr(win, "docman", None) or getattr(win, "doc_manager", None)
                    if dm is not None:
                        dm.open_path(path)
                except Exception:
                    logging.exception("[file-open-event] failed: %s", path)

            try:
                _app._file_open_cb = _open_one_from_event
                for _p in list(getattr(_app, "_pending_open_paths", []) or []):
                    QTimer.singleShot(0, lambda p=_p: _open_one_from_event(p))
                _app._pending_open_paths = []
            except Exception:
                logging.exception("[file-open-event] failed to drain pending paths")

        def _kick_updates_after_splash():
            try:
                win.raise_()
                win.activateWindow()
                from setiastro.saspro.first_run_dialog import _is_first_run
                if win.settings.value("updates/check_on_startup", True, type=bool) and not _is_first_run():
                    QTimer.singleShot(1000, win.check_for_updates_startup)
            except Exception:
                pass
            try:
                from setiastro.saspro.first_run_dialog import maybe_show_first_run_dialog, maybe_show_tip_of_day
                QTimer.singleShot(200, lambda: maybe_show_first_run_dialog(win))
                QTimer.singleShot(2000, lambda: maybe_show_tip_of_day(win))
            except Exception:
                pass

        if _splash:
            _splash.setMessage(QCoreApplication.translate("Splash", "Showing main window..."))
            _splash.setProgress(95)
        
        # --- Smooth Transition: App Fade In + Splash Fade Out ---
        # MITIGATION: Prevent "White Flash" on startup
        # 1. Force a dark background immediately so if opacity lags, it's dark not white
        win.setStyleSheet("QMainWindow { background-color: #0F0F19; }")
        win.winId()

        if _allow_window_opacity_effects():
            win.setWindowOpacity(0.0)

        win.show()
        QTimer.singleShot(0, lambda: win.setWindowIcon(_app.windowIcon()))

        # ── Non-fatal environment sanity check (source runs only) ──────
        # Frozen/installer builds are isolated + correct, so skip them. For
        # users running from GitHub, a NumPy/SciPy mismatch or two mixed Python
        # environments makes the multi-process workers die (BrokenProcessPool
        # -> 'no frames to stack'). The fallbacks keep SASpro working
        # single-process; this just tells the user how to fix it. Warn and keep
        # running — never touch their environment.
        def _saspro_env_warn():
            try:
                import sys as _sys2
                if getattr(_sys2, "frozen", False):
                    return
                from setiastro.saspro.worker_env import diagnose_local_env
                _ok, _msg = diagnose_local_env()
                if _ok:
                    return
                from PyQt6.QtWidgets import QMessageBox as _QMB, QApplication as _QApp
                _box = _QMB(win)
                _box.setIcon(_QMB.Icon.Warning)
                _box.setWindowTitle("Python environment problem")
                _box.setText(
                    "SASpro detected an inconsistent scientific-library setup.\n\n"
                    "It will still run, but multi-core stacking is disabled until "
                    "this is fixed (stacking will be slower).")
                _box.setInformativeText(_msg)
                _copy = _box.addButton("Copy fix command", _QMB.ButtonRole.ActionRole)
                _box.addButton(_QMB.StandardButton.Ok)
                _box.setDefaultButton(_QMB.StandardButton.Ok)
                _box.exec()
                if _box.clickedButton() is _copy:
                    try:
                        _QApp.clipboard().setText(
                            f'"{_sys2.executable}" -m pip install -r requirements.txt')
                    except Exception:
                        pass
            except Exception:
                pass
        QTimer.singleShot(1500, _saspro_env_warn)
        
        if open_paths:
            def _open_cli_paths():
                dm = getattr(win, "docman", None) or getattr(win, "doc_manager", None)
                if dm is None:
                    print("[startup open] No doc manager on main window")
                    return
                for p in open_paths:
                    try:
                        dm.open_path(p)
                    except Exception as e:
                        print("[startup open] failed:", p, e)

            QTimer.singleShot(0, _open_cli_paths)

        if _allow_window_opacity_effects():
            anim_app = QPropertyAnimation(win, b"windowOpacity")
            anim_app.setDuration(1200)
            anim_app.setStartValue(0.0)
            anim_app.setEndValue(1.0)
            anim_app.setEasingCurve(QEasingCurve.Type.OutQuad)

            def _on_fade_in_finished():
                win.setStyleSheet("")
                if hasattr(win, "on_fade_in_complete"):
                    win.on_fade_in_complete()

            anim_app.finished.connect(_on_fade_in_finished)
            anim_app.start()
        else:
            # No opacity animation on Wayland: just show immediately and clear the temp stylesheet
            win.setStyleSheet("")
            if hasattr(win, "on_fade_in_complete"):
                win.on_fade_in_complete()
        

        # Start background Numba warmup after UI is visible
        try:
            from setiastro.saspro.numba_warmup import start_background_warmup
            start_background_warmup()
        except Exception:
            pass  # Non-critical if warmup fails
        # (astroalign warmup now runs sequentially inside start_background_warmup)
        if _splash:
            _splash.setMessage(QCoreApplication.translate("Splash", "Ready!"))
            _splash.setProgress(100)
            _app.processEvents()
            
            # Small delay to ensure "Ready!" is seen briefly before fade starts
            import time
            time.sleep(0.1)
            
            # 2. Animate Splash Fade Out
            # Note: We do NOT use finish() directly here. The animation calls it when done.
            _splash.start_fade_out(on_finished=_kick_updates_after_splash)
            
            # NOTE: We keep a reference to _splash (global) so it doesn't get GC'd during animation.
            # It will deleteLater() itself.
        
        if BUILD_TIMESTAMP == "dev":
            build_label = "running from local source code"
        else:
            build_label = f"build {BUILD_TIMESTAMP}"

        import textwrap
        try:
            print("\033[38;2;255;140;0m" + textwrap.dedent(r"""
[0;90m┌┐[0;37m [0;90m┌┐[0;37m [0;90m┌┬┐[0;37m [0;90m∙[0;37m      [0;90m┌┐[0;37m [0;90m┌┐[0;37m [0;90m┌┬┐[0;37m [0;90m┌┐[0;37m [0;90m┌┐[0;37m      [0;90m┌┐[0;37m [0;90m┐┐[0;37m [0;90m∙[0;37m [0;90m┌┬┐[0;37m [0;90m┌┐[0;37m      [0;90m┌┐[0;37m [0;90m┌┐[0;37m [0;90m┌┐[0m
[0;35m││[0;37m [0;35m├[0;37m  [0;35m │[0;37m  [0;35m│[0;37m      [0;35m├│[0;37m [0;35m││[0;37m [0;35m │[0;37m  [0;35m││[0;37m [0;35m││[0;37m      [0;35m││[0;37m [0;35m││[0;37m [0;35m│[0;37m [0;35m │[0;37m  [0;35m├[0;37m       [0;35m││[0;37m [0;35m││[0;37m [0;35m││[0m
[0;95m└┐[0;37m [0;95m││[0;37m [0;97m [0;95m│[0;37m  [0;95m│[0;37m      [0;95m││[0;37m [0;95m└┐[0;37m [0;97m [0;95m│[0;37m  [0;95m│┘[0;37m [0;95m││[0;37m      [0;95m└┐[0;37m [0;95m││[0;37m [0;95m│[0;37m [0;97m [0;95m│[0;37m  [0;95m││[0;37m      [0;95m│┘[0;37m [0;95m│┘[0;37m [0;95m││[0m
[0;97m└┘[0;37m [0;97m└┘[0;37m [0;97m ┘[0;37m  [0;97m┘[0;37m      [0;97m┘┘[0;37m [0;97m└┘[0;37m [0;97m ┘[0;37m  [0;97m┘┘[0;37m [0;97m└┘[0;37m      [0;97m└┘[0;37m [0;97m└┘[0;37m [0;97m┘[0;37m [0;97m ┘[0;37m  [0;97m└┘[0;37m      [0;97m┘[0;37m  [0;97m┘┘[0;37m [0;97m└┘[0m                                                                         
            """) + "\033[0m")
        except Exception:
            print(textwrap.dedent(r"""
[0;90m┌┐[0;37m [0;90m┌┐[0;37m [0;90m┌┬┐[0;37m [0;90m∙[0;37m      [0;90m┌┐[0;37m [0;90m┌┐[0;37m [0;90m┌┬┐[0;37m [0;90m┌┐[0;37m [0;90m┌┐[0;37m      [0;90m┌┐[0;37m [0;90m┐┐[0;37m [0;90m∙[0;37m [0;90m┌┬┐[0;37m [0;90m┌┐[0;37m      [0;90m┌┐[0;37m [0;90m┌┐[0;37m [0;90m┌┐[0m
[0;35m││[0;37m [0;35m├[0;37m  [0;35m │[0;37m  [0;35m│[0;37m      [0;35m├│[0;37m [0;35m││[0;37m [0;35m │[0;37m  [0;35m││[0;37m [0;35m││[0;37m      [0;35m││[0;37m [0;35m││[0;37m [0;35m│[0;37m [0;35m │[0;37m  [0;35m├[0;37m       [0;35m││[0;37m [0;35m││[0;37m [0;35m││[0m
[0;95m└┐[0;37m [0;95m││[0;37m [0;97m [0;95m│[0;37m  [0;95m│[0;37m      [0;95m││[0;37m [0;95m└┐[0;37m [0;97m [0;95m│[0;37m  [0;95m│┘[0;37m [0;95m││[0;37m      [0;95m└┐[0;37m [0;95m││[0;37m [0;95m│[0;37m [0;97m [0;95m│[0;37m  [0;95m││[0;37m      [0;95m│┘[0;37m [0;95m│┘[0;37m [0;95m││[0m
[0;97m└┘[0;37m [0;97m└┘[0;37m [0;97m ┘[0;37m  [0;97m┘[0;37m      [0;97m┘┘[0;37m [0;97m└┘[0;37m [0;97m ┘[0;37m  [0;97m┘┘[0;37m [0;97m└┘[0;37m      [0;97m└┘[0;37m [0;97m└┘[0;37m [0;97m┘[0;37m [0;97m ┘[0;37m  [0;97m└┘[0;37m      [0;97m┘[0;37m  [0;97m┘┘[0;37m [0;97m└┘[0m 
            """))
        print(f"Seti Astro Suite Pro v{VERSION} ({build_label}) up and running!")
        sys.exit(_app.exec())

    except Exception:
        import traceback
        if _splash:
            try:
                _splash.hide()
                _splash.close()
                _splash.deleteLater()
            except Exception:
                pass
        tb = traceback.format_exc()
        logging.error("Unhandled exception occurred\n%s", tb)
        msg = QMessageBox(None)
        msg.setIcon(QMessageBox.Icon.Critical)
        msg.setWindowTitle(QCoreApplication.translate("Main", "Application Error"))
        msg.setText(QCoreApplication.translate("Main", "An unexpected error occurred."))
        msg.setInformativeText(tb.splitlines()[-1] if tb else "See details.")
        msg.setDetailedText(tb)
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg.exec()
        sys.exit(1)


# When run as a module, execute main()
if __name__ == "__main__":
    main()