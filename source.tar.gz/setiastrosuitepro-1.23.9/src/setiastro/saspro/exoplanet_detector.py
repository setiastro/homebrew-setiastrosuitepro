# ExoPlanet Detector (SASpro) — standalone plate solving, no WIMI

from __future__ import annotations

from setiastro.saspro.main_helpers import non_blocking_sleep

import os
import shutil
import tempfile
import time
from typing import List, Tuple, Set
import webbrowser
import multiprocessing
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional
from urllib.parse import quote
from types import SimpleNamespace
import math
import numpy as np
import pandas as pd
import sep
import pyqtgraph as pg
import matplotlib.pyplot as plt
from types import SimpleNamespace
from astropy.io import fits
from astropy.time import Time
from astropy.stats import sigma_clipped_stats
from astropy.coordinates import SkyCoord
import astropy.units as u
from astropy.wcs import WCS
from astropy.timeseries import LombScargle, BoxLeastSquares
import re

from astroquery.simbad import Simbad
from astroquery.vizier import Vizier

from astroquery.mast import Tesscut

from lightkurve import TessTargetPixelFile

import lightkurve as lk

# ---- project-local imports (adjust paths if needed) --------------------
from setiastro.saspro.legacy.numba_utils import bin2x2_numba, apply_flat_division_numba
from setiastro.saspro.imageops.stretch import stretch_mono_image, stretch_color_image
from setiastro.saspro.help_support import make_help_button
from setiastro.saspro.plate_solver import plate_solve_doc_inplace
from setiastro.saspro.star_alignment import (
    StarRegistrationWorker,
    StarRegistrationThread,
    IDENTITY_2x3,
)
from setiastro.saspro.legacy.image_manager import load_image, save_image, get_valid_header  # adjust if different
from setiastro.saspro import photometry_aavso as aav
from setiastro.saspro import cds_health
from setiastro.saspro.widgets.themed_buttons import themed_toolbtn

# ------------------------------------------------------------------------
from setiastro.saspro.legacy.xisf import XISF
from PyQt6.QtCore import Qt, QTimer, QSettings, QRectF, QPoint, QPointF
from PyQt6.QtGui import QIcon, QColor, QBrush, QPen, QPainter, QImage, QPixmap
from PyQt6.QtWidgets import (
    QAbstractItemView, QButtonGroup, QComboBox, QDialog, QDialogButtonBox, QApplication, QGraphicsView, QGraphicsPixmapItem,
    QFileDialog, QFormLayout, QGroupBox, QHBoxLayout, QLabel, QListWidget, QGraphicsView, QGraphicsScene, QGraphicsEllipseItem,
    QListWidgetItem, QMessageBox, QPushButton, QProgressBar, QRadioButton, QSpinBox, QDoubleSpinBox,
    QSlider, QToolButton, QVBoxLayout, QInputDialog, QLineEdit, QCheckBox
)
import pyqtgraph as pg

import warnings
from astropy.utils.exceptions import AstropyWarning
warnings.filterwarnings("ignore", category=AstropyWarning, message=".*more axes.*")


# ───────────────────────── CDS / SIMBAD hardening ─────────────────────────
#
# Everything in this module that touches SIMBAD or VizieR runs on the GUI
# thread, and until now none of it bounded its timeouts. astroquery with no
# timeout set falls back to the OS TCP connect timeout -- roughly 130 s on
# Linux -- and the lookup helpers below each retried five times. A CDS
# outage therefore froze the window for ~11 minutes per lookup with no
# cancel and no progress.
#
# Three things fix that:
#   1. A bounded timeout, set on BOTH spellings (`TIMEOUT` was renamed to
#      `timeout` in astroquery 0.4.8; setting only the old name on a new
#      astroquery silently does nothing, which is how an unbounded call
#      sneaks through).
#   2. A cds_health preflight, so we learn CDS is down in ~4 s instead of
#      ~130 s, and the session-wide breaker makes every later lookup return
#      instantly.
#   3. No retrying of connection-class failures. If the host is not
#      answering, a second attempt just buys the same timeout again.
#
# NOTE ON VizieR / VSX: the VSX lookups in this module are not an
# independent fallback for a SIMBAD outage. B/vsx is a VizieR catalog, and
# VizieR is CDS. It runs on separate hosts from the SIMBAD TAP endpoint, so
# it survives a SIMBAD-only fault and is worth trying -- but a Strasbourg-
# wide outage takes both down, so these calls need the same bounding.

_SIMBAD_TIMEOUT_S = 20      # per-call ceiling for interactive lookups
_VIZIER_TIMEOUT_S = 20


def _configure_simbad_endpoint():
    """
    Point astroquery at whichever mirror cds_health last found healthy and
    bound its timeout. Returns the hostname in use.

    Safe to call repeatedly; every assignment is individually guarded so a
    version that lacks one of these attributes doesn't break the others.
    """
    host = cds_health.current_server()
    applied = cds_health.apply_server(host)
    for setter in (
        lambda: setattr(Simbad, "timeout", int(_SIMBAD_TIMEOUT_S)),
        lambda: setattr(Simbad, "TIMEOUT", int(_SIMBAD_TIMEOUT_S)),
    ):
        try:
            setter()
        except Exception:
            pass
    if not applied:
        print(f"[DEBUG] astroquery refused SIMBAD server {host!r} — "
              f"queries would go to the default host instead.")
    return host, applied


def _new_simbad():
    """
    Build a fresh, bounded Simbad object for a one-off lookup.

    Why this exists rather than just setting Simbad.TIMEOUT once:
    astroquery exports `Simbad` as a module-level *instance* of
    SimbadClass, and the lookups in this module each build their own with
    `Simbad()`. An attribute set on the module-level object does not
    propagate to a newly constructed one -- the new object reads its
    default from `conf`. So a bound set only on the module-level object
    silently fails to apply to exactly the calls we are trying to bound.

    Belt and braces: `_configure_simbad_endpoint()` sets `conf.timeout`
    (which new instances inherit) AND this sets the attribute directly on
    the instance we are about to use, under both spellings.
    """
    host, applied = _configure_simbad_endpoint()
    s = Simbad()
    if applied:
        try:
            s.server = host
        except Exception:
            pass
    for setter in (
        lambda: setattr(s, "timeout", int(_SIMBAD_TIMEOUT_S)),
        lambda: setattr(s, "TIMEOUT", int(_SIMBAD_TIMEOUT_S)),
    ):
        try:
            setter()
        except Exception:
            pass
    try:
        s.reset_votable_fields()
    except Exception:
        pass
    return s


def _new_vizier(**kwargs):
    """
    Build a bounded Vizier client pointed at the chosen VizieR mirror.

    VizieR runs on different hosts from the SIMBAD TAP endpoint, so it
    survives a SIMBAD-only fault -- but vizier.cds.unistra.fr is still a
    Strasbourg host, so a CDS-wide outage takes it down too. Hence a
    mirror here as well, and the same bounded timeout either way.
    """
    kwargs.setdefault("timeout", int(_VIZIER_TIMEOUT_S))
    v = Vizier(**kwargs)
    try:
        v.VIZIER_SERVER = cds_health.vizier_server()
    except Exception:
        pass
    return v


def _configure_vizier_timeout():
    """Bound the module-level Vizier object and point it at the mirror."""
    host = cds_health.vizier_server()
    try:
        import astroquery.vizier as _aqv
        try:
            _aqv.conf.server = host
        except Exception:
            pass
    except Exception:
        pass
    for setter in (
        lambda: setattr(Vizier, "TIMEOUT", int(_VIZIER_TIMEOUT_S)),
        lambda: setattr(Vizier, "timeout", int(_VIZIER_TIMEOUT_S)),
        lambda: setattr(Vizier, "VIZIER_SERVER", host),
    ):
        try:
            setter()
        except Exception:
            pass


def _extract_ra_dec_from_header(h: fits.Header):
    """Return (ra_deg, dec_deg) if found, else (None, None)."""
    if not isinstance(h, fits.Header):
        return None, None

    # 1) If WCS is already present, use its center
    try:
        w = WCS(h)
        if w.has_celestial:
            # center of the current pixel grid
            nx = h.get("NAXIS1"); ny = h.get("NAXIS2")
            if nx and ny:
                sky = w.pixel_to_world(nx/2, ny/2)
                return float(sky.ra.deg), float(sky.dec.deg)
    except Exception:
        pass

    # 2) Common RA/DEC keyword pairs
    pairs = [
        ("OBJCTRA", "OBJCTDEC"),  # PixInsight/ASCOM style (strings)
        ("RA",      "DEC"),
        ("TELRA",   "TELDEC"),
        ("RA_OBJ",  "DEC_OBJ"),
        ("CAT-RA",  "CAT-DEC"),
        ("RA_DEG",  "DEC_DEG"),   # degrees already
    ]

    for rak, deck in pairs:
        if rak in h and deck in h:
            ra_raw, dec_raw = h[rak], h[deck]

            # Try a few parse paths
            for parser in (
                lambda r,d: SkyCoord(r, d, unit=(u.hourangle, u.deg)),
                lambda r,d: SkyCoord(float(r)*u.deg, float(d)*u.deg),
                lambda r,d: SkyCoord(r, d, unit=(u.deg, u.deg)),
            ):
                try:
                    c = parser(ra_raw, dec_raw)
                    return float(c.ra.deg), float(c.dec.deg)
                except Exception:
                    pass

    return None, None


def _estimate_scale_arcsec_per_pix(h: fits.Header):
    """Return pixel scale (arcsec/pix) if derivable, else None."""
    if not isinstance(h, fits.Header):
        return None

    # Direct scale keywords (various conventions)
    for k in ("PIXSCALE", "PIXSCL", "SECPIX", "SECPIX1"):
        if k in h:
            try:
                val = float(h[k])
                if val > 0:
                    return val
            except Exception:
                pass

    # Derive from pixel size & focal length:
    # scale["/pix] ≈ 206.265 * pixel_size_μm / focal_length_mm
    px_um = None
    for k in ("XPIXSZ", "PIXSIZE1", "PIXSIZE"):  # μm
        if k in h:
            try:
                px_um = float(h[k])
                break
            except Exception:
                pass

    foc_mm = None
    for k in ("FOCALLEN", "FOCLEN", "FOCALLENGTH"):
        if k in h:
            try:
                foc_mm = float(h[k])
                break
            except Exception:
                pass

    if px_um and foc_mm and foc_mm > 0:
        return 206.265 * px_um / foc_mm

    return None

_TZ_RE = re.compile(r'([+-])(\d{2})(\d{2})$')  # -0700 -> -07:00

def _fix_iso_tz(s: str) -> str:
    s = s.strip()
    m = _TZ_RE.search(s)
    if m:
        s = s[:m.start()] + f"{m.group(1)}{m.group(2)}:{m.group(3)}"
    return s

def _parse_obs_time_from_header(hdr) -> Time | None:
    # hdr can be fits.Header or your dict-ish header
    def _get(key):
        try:
            return hdr.get(key)
        except Exception:
            return None

    # 1) Prefer UT-OBS if present (already “UTC-ish”)
    for key in ("UT-OBS", "DATE-OBS", "DATE-END"):
        v = _get(key)
        if isinstance(v, str) and v.strip():
            try:
                return Time(_fix_iso_tz(v), format="isot", scale="utc")
            except Exception:
                pass

    # 2) MJD-OBS is super reliable
    v = _get("MJD-OBS")
    if v is not None:
        try:
            return Time(float(v), format="mjd", scale="utc")
        except Exception:
            pass

    return None

def _estimate_fov_deg(img_shape, scale_arcsec):
    """Rough FOV (deg) from image size and scale (max of X/Y)."""
    try:
        h, w = img_shape[:2]
        if scale_arcsec and h and w:
            fov_x = (w * scale_arcsec) / 3600.0
            fov_y = (h * scale_arcsec) / 3600.0
            return float(max(fov_x, fov_y))
    except Exception:
        pass
    return None


def _build_astrometry_hints(hdr: fits.Header, plane: np.ndarray):
    """Compose a hints dict for the solver."""
    ra_deg, dec_deg = _extract_ra_dec_from_header(hdr)
    scale = _estimate_scale_arcsec_per_pix(hdr)
    fov   = _estimate_fov_deg(plane.shape, scale)

    # A generous search radius: ≥1°, or 3×FOV if we have it
    radius = None
    if fov is not None:
        radius = max(1.0, 3.0 * fov)

    hints = {}
    if ra_deg is not None and dec_deg is not None:
        hints["ra_deg"]  = ra_deg
        hints["dec_deg"] = dec_deg
    if scale is not None:
        hints["pixel_scale_arcsec"] = scale
    if fov is not None:
        hints["fov_deg"] = fov
    if radius is not None:
        hints["search_radius_deg"] = radius

    # Optional: parity if you know you’re mirrored or not (None = let solver decide)
    # hints["parity"] = +1  # or -1

    return hints

# ── Photometric gain ─────────────────────────────────────────────────────
#
# sep's `gain` converts DATA UNITS to Poisson counts: it adds flux/gain to
# the variance. load_image divides by the source bit depth, so one data
# unit is 65535 ADU for 16-bit input, not one electron. The old gain=1.0
# therefore claimed a star with ~0.1 units of total aperture flux carried
# ~0.1 electrons -- sqrt(0.1)/0.1 = 3.2, i.e. a 3.5 mag error on every
# measurement. That is what pushed MERR past AAVSO's 1.0 ceiling and wrote
# "na" on every row while the magnitudes themselves stayed correct.
#
#     gain_eff = EGAIN[e-/ADU] * ADU_per_unit * 4
#
# The 4 is because bin2x2_numba AVERAGES: a binned pixel of value v holds
# the electrons of four unbinned pixels averaging v, so four times as many
# electrons sit behind each unit of the binned array.
#
# Note the noise model this completes: err=rmsmap already carries sky and
# read noise (sep's background rms measures exactly that), and because `ds`
# is background-subtracted the gain term adds only the star's own shot
# noise. The two are complementary, which is why the annulus call needs the
# same gain rather than none.

_ADU_PER_UNIT = {
    "8-bit":           255.0,
    "16-bit":          65535.0,
    "16-bit signed":   65535.0,
    "32-bit unsigned": 4294967295.0,
    "32-bit signed":   4294967295.0,
}

# ASCOM/INDI report true e-/ADU as EGAIN. A bare GAIN keyword is usually
# the CMOS gain *setting* (0-500 on ZWO/QHY), not e-/ADU, so it is left out
# on purpose -- using it here would be wrong by roughly 100x.
_EGAIN_KEYS = ("EGAIN", "GAINE", "E_GAIN", "ELECGAIN")


def _header_scalar(hdr, keys):
    """First of `keys` present in a fits.Header or XISF-style dict, as float."""
    if hdr is None:
        return None
    if isinstance(hdr, fits.Header):
        for k in keys:
            if k in hdr:
                try:
                    return float(hdr[k])
                except (TypeError, ValueError):
                    pass
        return None
    if isinstance(hdr, dict):
        kw = None
        im = hdr.get("image_meta")
        if isinstance(im, dict):
            kw = im.get("FITSKeywords")
        if kw is None:
            kw = hdr.get("FITSKeywords")
        for k in keys:
            v = None
            if isinstance(kw, dict) and k in kw:
                ent = kw[k]
                v = ent[0].get("value") if isinstance(ent, list) and ent else ent
            elif k in hdr:
                v = hdr[k]
            if v is not None:
                try:
                    return float(v)
                except (TypeError, ValueError):
                    pass
        for sub in ("fits_header", "original_header", "header"):
            h = hdr.get(sub)
            if isinstance(h, fits.Header):
                r = _header_scalar(h, keys)
                if r is not None:
                    return r
    return None


def _rescale_header_for_binning(hdr, bin_factor: int = 2):
    """
    Return a copy of `hdr` describing the same sky on a `bin_factor`-binned
    pixel grid.

    _solve_reference hands the plate solver a 2x2 binned plane, but a header
    straight off the file describes the unbinned frame. plate_solver reads
    it for the pixel-scale hint it cannot solve without
    (_estimate_scale_arcsec_from_header: WCS/CD, then CDELT, then
    PIXSCALE-style keys, then XPIXSZ * XBINNING / FOCALLEN), so uncorrected
    it is told the scale is half what it really is.

    What changes, and why:

      CRPIX        (p - 0.5)/b + 0.5
                   FITS numbers pixel CENTRES from 1, so the outer edge of
                   pixel 1 sits at 0.5. Binning maps edges, not centres;
                   dividing the centre directly is off by half a binned
                   pixel.
      CD, CDELT    x b   one binned pixel spans b unbinned ones.
      PIXSCALE,
      SECPIX, ...  x b   the same statement, made directly in arcsec/px.
      XBINNING,
      YBINNING     x b   this is where the solver expects a binning factor
                         to live: it computes XPIXSZ * XBINNING / FOCALLEN.
                         Scaling XPIXSZ as well would square the correction.

    SIP is dropped rather than rescaled. Those coefficients carry units of
    unbinned pixels to the (p+q)th power, so a correct rescale is
    A_pq * b**(p + q - 1) -- easy to get subtly wrong, and the solver refits
    SIP from scratch regardless. A seed with no distortion model is fine; a
    seed with a wrong one is not.
    """
    if not isinstance(hdr, fits.Header):
        return hdr
    b = float(max(1, int(bin_factor)))
    out = hdr.copy()
    if b == 1.0:
        return out

    for k in ("CRPIX1", "CRPIX2"):
        if k in out:
            try:
                out[k] = (float(out[k]) - 0.5) / b + 0.5
            except (TypeError, ValueError):
                pass

    for k in ("CD1_1", "CD1_2", "CD2_1", "CD2_2", "CDELT1", "CDELT2",
              "PIXSCALE", "SECPIX", "SECPIX1", "SECPIX2",
              "SCALE", "PLATESCL", "PLTSCALE"):
        if k in out:
            try:
                out[k] = float(out[k]) * b
            except (TypeError, ValueError):
                pass

    _had_bin = False
    for k in ("XBINNING", "YBINNING", "XBIN", "YBIN"):
        if k in out:
            try:
                out[k] = int(round(float(out[k]) * b))
                _had_bin = True
            except (TypeError, ValueError):
                pass
    if not _had_bin and any(k in out for k in ("XPIXSZ", "YPIXSZ",
                                               "PIXSIZE1", "PIXSIZE2")):
        out["XBINNING"] = int(b)
        out["YBINNING"] = int(b)

    for k in [k for k in list(out.keys())
              if str(k).upper().startswith(("A_", "B_", "AP_", "BP_"))]:
        try:
            del out[k]
        except Exception:
            pass
    for k in ("CTYPE1", "CTYPE2"):
        if k in out:
            try:
                out[k] = str(out[k]).replace("-SIP", "")
            except Exception:
                pass

    try:
        out.add_history(f"Rescaled for {int(b)}x{int(b)} software binning "
                        f"(SASpro exoplanet tool)")
    except Exception:
        pass
    return out


# ============================================================
# Transit search helpers — ported from exoplanet_ground_telescope_script - Kyle Lynch
# ============================================================

def _robust_sigma(x: np.ndarray) -> float:
    """Median-absolute-deviation based sigma (1.4826 * MAD)."""
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if x.size < 3:
        return np.nan
    med = np.nanmedian(x)
    mad = np.nanmedian(np.abs(x - med))
    return float(1.4826 * mad) if np.isfinite(mad) else np.nan


def _sort_lightcurve(time_jd: np.ndarray, flux: np.ndarray,
                     positive_only: bool = True):
    t = np.asarray(time_jd, float)
    y = np.asarray(flux, float)
    good = np.isfinite(t) & np.isfinite(y)
    if positive_only:
        good &= (y > 0)
    if not np.any(good):
        return np.array([], float), np.array([], float)
    s = np.argsort(t[good])
    return t[good][s], y[good][s]


def _segment_slices(time: np.ndarray, gap_days: float):
    t = np.asarray(time, float)
    if t.size == 0:
        return []
    cuts = np.where(np.diff(t) > gap_days)[0]
    starts = np.r_[0, cuts + 1]
    ends   = np.r_[cuts + 1, t.size]
    return [slice(int(a), int(b)) for a, b in zip(starts, ends)]


def _upper_outlier_mask(y: np.ndarray, sigma_mult: float = 6.0) -> np.ndarray:
    arr = np.asarray(y, float)
    mask = np.zeros(arr.shape, dtype=bool)
    good = np.isfinite(arr) & (arr > 0)
    if np.sum(good) < 6:
        return mask
    med = float(np.nanmedian(arr[good]))
    sig = _robust_sigma(arr[good] - med)
    if not (np.isfinite(sig) and sig > 0):
        return mask
    return np.isfinite(arr) & (arr > med + sigma_mult * sig)


def _prepare_search_lightcurve(time_jd: np.ndarray, flux: np.ndarray):
    """Clean, sort, median-normalise, and clip upper outliers."""
    t, y = _sort_lightcurve(time_jd, flux, positive_only=True)
    if t.size == 0:
        return t, y
    med = np.nanmedian(y[np.isfinite(y) & (y > 0)])
    if np.isfinite(med) and med != 0:
        y = y / med
    bad = _upper_outlier_mask(y, sigma_mult=6.0)
    if np.any(bad):
        keep = np.isfinite(y) & (~bad)
        t, y = t[keep], y[keep]
        if y.size > 0:
            med2 = np.nanmedian(y)
            if np.isfinite(med2) and med2 != 0:
                y = y / med2
    return t, y


def _phase_centered(time: np.ndarray, period: float, t0: float) -> np.ndarray:
    """Fold to [-0.5, 0.5]."""
    ph = ((np.asarray(time, float) - t0) / period) % 1.0
    return ((ph + 0.5) % 1.0) - 0.5


def _whiten_periodogram(power: np.ndarray):
    """Subtract running-median background from BLS power spectrum."""
    from scipy.ndimage import median_filter as _mf
    power = np.asarray(power, float)
    if power.size == 0:
        return np.array([], float), np.array([], float)
    finite = np.isfinite(power)
    fill = float(np.nanmedian(power[finite])) if np.any(finite) else 0.0
    arr = np.where(finite, power, fill)
    max_window = power.size if power.size % 2 == 1 else power.size - 1
    if max_window < 3:
        bg = np.full_like(arr, fill, dtype=float)
    else:
        window = max(31, int(power.size // 150))
        if window % 2 == 0:
            window += 1
        window = max(3, min(window, max_window))
        bg = _mf(arr, size=window, mode="nearest")
    whitened = arr - bg
    whitened -= np.nanmedian(whitened[finite])
    whitened[~finite] = np.nan
    bg[~finite] = np.nan
    return bg, whitened


def _top_peak_indices(periods: np.ndarray, power: np.ndarray,
                      max_peaks: int = 12, merge_frac: float = 0.01):
    periods = np.asarray(periods, float)
    power   = np.asarray(power, float)
    if periods.size == 0:
        return []
    cand = []
    for i in range(power.size):
        if not np.isfinite(power[i]):
            continue
        left  = power[i-1] if i > 0 else -np.inf
        right = power[i+1] if i+1 < power.size else -np.inf
        if power[i] >= left and power[i] >= right:
            cand.append(i)
    if not cand:
        cand = list(np.where(np.isfinite(power))[0])
    cand = np.asarray(cand, int)
    order = cand[np.argsort(power[cand])[::-1]]
    keep = []
    for idx in order:
        p = periods[idx]
        if not (np.isfinite(p) and p > 0):
            continue
        if any(abs(p / periods[j] - 1.0) <= merge_frac for j in keep
               if np.isfinite(periods[j]) and periods[j] > 0):
            continue
        keep.append(int(idx))
        if len(keep) >= max_peaks:
            break
    return keep


def _make_binned_curve(x: np.ndarray, y: np.ndarray, bin_width: float):
    """Robust-sigma-clipped binning; returns (bx, by, be)."""
    x = np.asarray(x, float); y = np.asarray(y, float)
    good = np.isfinite(x) & np.isfinite(y)
    x, y = x[good], y[good]
    if x.size < 10:
        return np.array([], float), np.array([], float), np.array([], float)
    edges = np.arange(np.nanmin(x), np.nanmax(x) + bin_width, bin_width)
    bx, by, be = [], [], []
    for i in range(len(edges) - 1):
        m = (x >= edges[i]) & (x < edges[i+1])
        if np.sum(m) < 4:
            continue
        yy = y[m]; xx = x[m]
        med = np.nanmedian(yy)
        sig = _robust_sigma(yy)
        if np.isfinite(sig) and sig > 0:
            keep = np.abs(yy - med) < 4.0 * sig
            xx, yy = xx[keep], yy[keep]
        if yy.size < 4:
            continue
        sig2 = _robust_sigma(yy)
        bx.append(float(np.nanmedian(xx)))
        by.append(float(np.nanmedian(yy)))
        be.append(float(sig2 / np.sqrt(yy.size)) if np.isfinite(sig2) and sig2 > 0
                  else float(np.nanstd(yy) / np.sqrt(max(1, yy.size))))
    return np.asarray(bx, float), np.asarray(by, float), np.asarray(be, float)


def _estimate_night_dip_events(time_jd: np.ndarray, flux: np.ndarray,
                                gap_days: float = 0.20):
    """
    Per-night dip detection: returns list of dicts with
    t_center, depth_frac, snr, duration_d.
    """
    from scipy.ndimage import median_filter as _mf
    t, y = _sort_lightcurve(time_jd, flux, positive_only=True)
    if t.size < 12:
        return []
    events = []
    for sl in _segment_slices(t, gap_days):
        tn, yn = t[sl], y[sl]
        good = np.isfinite(tn) & np.isfinite(yn) & (yn > 0)
        tn, yn = tn[good], yn[good]
        if tn.size < 8:
            continue
        med = float(np.nanmedian(yn))
        if med <= 0 or not np.isfinite(med):
            continue
        seg = yn / med
        scatter = _robust_sigma(seg)
        if not np.isfinite(scatter) or scatter <= 0:
            scatter = float(np.nanstd(seg))
        scatter = max(scatter, 1e-5)

        filled = seg.copy()
        filled[~np.isfinite(filled)] = 1.0
        w = min(11, max(5, (tn.size // 12) * 2 + 1))
        if w % 2 == 0:
            w += 1
        if w >= tn.size:
            w = tn.size if tn.size % 2 == 1 else max(5, tn.size - 1)
        smooth = _mf(filled, size=max(5, w), mode="nearest").astype(float)

        oot = float(np.nanmedian(smooth))
        min_idx = int(np.nanargmin(smooth))
        depth = max(0.0, oot - float(smooth[min_idx]))
        if not np.isfinite(depth) or depth < max(2.0 * scatter, 8e-4):
            continue

        thresh = oot - max(1.2 * scatter, 0.45 * depth)
        low = smooth <= thresh
        left = right = min_idx
        while left > 0 and low[left-1]:
            left -= 1
        while right + 1 < low.size and low[right+1]:
            right += 1

        # cadence estimate
        dts = np.diff(np.sort(tn))
        dts = dts[dts > 1e-6]
        cad = float(np.nanmedian(dts)) if dts.size > 0 else 5.0/1440.0
        dur = float((tn[right] - tn[left]) + max(cad, 5.0/1440.0))
        events.append({
            "t_center": float(np.nanmedian(tn[left:right+1])),
            "depth_frac": float(depth),
            "snr": float(depth / scatter),
            "duration_d": dur,
        })
    return events


def _alias_penalty(period_d: float, tol: float = 0.02) -> float:
    if not (np.isfinite(period_d) and period_d > 0):
        return 0.0
    penalty = 0.0
    for alias in (0.5, 1.0, 2.0, 3.0):
        frac = abs(period_d / alias - 1.0)
        if frac <= tol:
            penalty = max(penalty, 1.0 - frac / tol)
    return float(penalty)


class OverlayView(QGraphicsView):
    def __init__(self, parent=None):
        super().__init__(parent)
        # disable built-in hand drag
        self.setDragMode(QGraphicsView.DragMode.NoDrag)
        # always arrow cursor
        self.viewport().setCursor(Qt.CursorShape.ArrowCursor)
        self._panning = False
        self._last_pos = QPoint()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            scene_pt = self.mapToScene(event.pos())
            # if we clicked an ellipse, let it handle the event
            for it in self.scene().items(scene_pt):
                if isinstance(it, ClickableEllipseItem):
                    super().mousePressEvent(event)
                    return
            # else: start panning
            self._panning = True
            self._last_pos = event.pos()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._panning:
            delta = event.pos() - self._last_pos
            self._last_pos = event.pos()
            self.horizontalScrollBar().setValue(self.horizontalScrollBar().value() - delta.x())
            self.verticalScrollBar().setValue(self.verticalScrollBar().value() - delta.y())
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and self._panning:
            self._panning = False
            event.accept()
            return
        super().mouseReleaseEvent(event)

class ClickableEllipseItem(QGraphicsEllipseItem):
    def __init__(self, rect: QRectF, index: int, callback):
        super().__init__(rect)
        self.index = index
        self.callback = callback
        self.setAcceptedMouseButtons(Qt.MouseButton.LeftButton)
        self.setAcceptHoverEvents(True)

    def mousePressEvent(self, ev):
        if ev.button() == Qt.MouseButton.LeftButton:
            shift = bool(ev.modifiers() & Qt.KeyboardModifier.ShiftModifier)
            self.callback(self.index, shift)
        super().mousePressEvent(ev)


class ReferenceOverlayDialog(QDialog):
    def __init__(self, plane: np.ndarray, positions: List[Tuple], target_median: float, parent=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Reference Frame: Stars Overlay"))
        self.plane = np.asarray(plane, dtype=np.float32)
        self.positions = positions
        self.target_median = target_median
        self.autostretch = True

        self._normal_pen   = QPen(QColor('lightblue'), 3)
        self._dip_pen      = QPen(QColor('yellow'), 3)
        self._selected_pen = QPen(QColor('red'), 4)

        self.ellipse_items: dict[int, ClickableEllipseItem] = {}
        self.flagged_stars: Set[int] = set()

        self._build_ui()
        self._init_graphics()

        if parent and hasattr(parent, 'star_list'):
            parent.star_list.itemSelectionChanged.connect(self._update_highlights)

        QTimer.singleShot(0, self._fit_to_100pct)

    def _build_ui(self):
        self.view = OverlayView(self)
        self.view.setRenderHints(
            QPainter.RenderHint.Antialiasing |
            QPainter.RenderHint.SmoothPixmapTransform
        )
        self.scene = QGraphicsScene(self)
        self.view.setScene(self.scene)

        btns = QHBoxLayout()

        self.zoom_in_btn = QPushButton("Zoom In")
        self.zoom_in_btn.clicked.connect(lambda: self.view.scale(1.2, 1.2))
        btns.addWidget(self.zoom_in_btn)

        self.zoom_out_btn = QPushButton("Zoom Out")
        self.zoom_out_btn.clicked.connect(lambda: self.view.scale(1/1.2, 1/1.2))
        btns.addWidget(self.zoom_out_btn)

        self.reset_btn = QPushButton("Reset Zoom")
        self.reset_btn.clicked.connect(self._fit_to_100pct)
        btns.addWidget(self.reset_btn)

        self.fit_btn = QPushButton("Fit to Window")
        self.fit_btn.clicked.connect(self._fit_to_window)
        btns.addWidget(self.fit_btn)

        self.stretch_btn = QPushButton()
        self.stretch_btn.clicked.connect(self._toggle_autostretch)
        btns.addWidget(self.stretch_btn)

        self._update_stretch_button_text()
        btns.addStretch()

        lay = QVBoxLayout(self)
        lay.addWidget(self.view)
        lay.addLayout(btns)
        self.resize(800, 600)

    def _update_stretch_button_text(self):
        self.stretch_btn.setText(f"Stretch: {'ON' if self.autostretch else 'OFF'}")

    def _normalize_to_u8_linear(self, img: np.ndarray) -> np.ndarray:
        """
        Linear preview:
        - if already in [0,1], keep it linear
        - otherwise percentile-compress to 8-bit
        """
        arr = np.asarray(img, dtype=np.float32)
        arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)

        finite = np.isfinite(arr)
        if not np.any(finite):
            return np.zeros(arr.shape, dtype=np.uint8)

        amin = float(np.min(arr[finite]))
        amax = float(np.max(arr[finite]))

        # Common SASpro case: float image already normalized to [0,1]
        if amin >= 0.0 and amax <= 1.0:
            out = np.clip(arr, 0.0, 1.0)
            return (out * 255.0).astype(np.uint8)

        # Otherwise make a robust linear preview
        lo, hi = np.percentile(arr[finite], [0.5, 99.5])
        if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
            lo = amin
            hi = amax if amax > amin else (amin + 1.0)

        out = (arr - lo) / max(hi - lo, 1e-8)
        out = np.clip(out, 0.0, 1.0)
        return (out * 255.0).astype(np.uint8)

    def _to_preview_u8(self, img: np.ndarray) -> np.ndarray:
        arr = np.asarray(img, dtype=np.float32)
        arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
        arr = np.clip(arr, 0.0, 1.0)
        return (arr * 255.0).astype(np.uint8)


    def _normalize_preview_source(self, img: np.ndarray) -> np.ndarray:
        arr = np.asarray(img)

        # keep original values, just move into a sane preview/stretch domain
        if arr.dtype.kind in "iu":
            arr = arr.astype(np.float32)

        else:
            arr = np.asarray(arr, dtype=np.float32)

        arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)

        finite = np.isfinite(arr)
        if not np.any(finite):
            return np.zeros(arr.shape, dtype=np.float32)

        amin = float(np.min(arr[finite]))
        amax = float(np.max(arr[finite]))

        # already normalized
        if amin >= 0.0 and amax <= 1.0:
            return np.clip(arr, 0.0, 1.0)

        # signed / weird-range data -> normalize to 0..1 first
        if amax <= amin:
            return np.zeros(arr.shape, dtype=np.float32)

        arr01 = (arr - amin) / (amax - amin)
        return np.clip(arr01, 0.0, 1.0).astype(np.float32)

    def _init_graphics(self):
        base = self._normalize_preview_source(self.plane)
        img = base

        if self.autostretch:
            try:
                stretched = stretch_mono_image(base, target_median=0.3)
                stretched = np.asarray(stretched, dtype=np.float32)

                if np.isfinite(stretched).any() and np.nanstd(stretched) > 1e-4:
                    img = np.clip(stretched, 0.0, 1.0)
            except Exception as e:
                print(f"[Exoplanet preview] stretch_mono_image failed: {e}")
                img = base

        arr8 = (np.clip(img, 0.0, 1.0) * 255.0).astype(np.uint8)
        h, w = arr8.shape
        qimg = QImage(arr8.data, w, h, w, QImage.Format.Format_Grayscale8).copy()
        pix = QPixmap.fromImage(qimg)

        self.scene.clear()
        self.ellipse_items.clear()
        self.scene.addItem(QGraphicsPixmapItem(pix))

        radius = max(2, int(math.ceil(1.2 * self.target_median)))
        for idx, (x, y) in enumerate(self.positions):
            r = QRectF(x - radius, y - radius, 2 * radius, 2 * radius)
            ell = ClickableEllipseItem(r, idx, self._on_star_clicked)
            ell.setPen(self._normal_pen)
            ell.setBrush(QBrush(Qt.BrushStyle.NoBrush))
            self.scene.addItem(ell)
            self.ellipse_items[idx] = ell


    def _fit_to_100pct(self):
        self.view.resetTransform()
        rect = self.scene.itemsBoundingRect()
        self.view.setSceneRect(rect)
        self.view.centerOn(rect.center())

    def _fit_to_window(self):
        rect = self.scene.itemsBoundingRect()
        self.view.fitInView(rect, Qt.AspectRatioMode.KeepAspectRatio)

    def _toggle_autostretch(self):
        self.autostretch = not self.autostretch
        self._update_stretch_button_text()
        self._init_graphics()

    def _on_star_clicked(self, index: int, shift: bool):
        parent = self.parent()
        if not parent or not hasattr(parent, 'star_list'):
            return

        lst = parent.star_list
        item = lst.item(index)
        if not item:
            return

        if shift:
            item.setSelected(not item.isSelected())
        else:
            lst.clearSelection()
            item.setSelected(True)

        lst.scrollToItem(item)
        self._update_highlights()

    def _update_highlights(self):
        parent = self.parent()
        if not parent or not hasattr(parent, 'star_list'):
            return

        sel = {item.data(Qt.ItemDataRole.UserRole)
               for item in parent.star_list.selectedItems()}

        for idx, ell in self.ellipse_items.items():
            if idx in sel:
                ell.setPen(self._selected_pen)
            elif idx in self.flagged_stars:
                ell.setPen(self._dip_pen)
            else:
                ell.setPen(self._normal_pen)

    def update_dip_flags(self, flagged_indices: Set[int]):
        self.flagged_stars = flagged_indices
        self._update_highlights()


# ---------------------------------------------------------------------------
# SIMBAD/VSX name-resolution helpers.  Used by ExoPlanetWindow to pick the
# best display / export name near a (RA, Dec) — biasing toward variable-star
# designations and named catalogs over incidental Gaia DR3 entries.
# ---------------------------------------------------------------------------

# SIMBAD otype prefixes considered "variable star".
_VARIABLE_OTYPE_PREFIXES = (
    "V*",   "Mi*",  "EB*", "EA*", "EW*", "RR*", "Ce*", "dS*", "SX*",
    "Sr*",  "SR*",  "LP*", "LPV", "Ir*", "IR*", "Pu*", "Ro*", "RS*",
    "BY*",  "Er*",  "FU*", "GC*", "Ta*", "TT*", "Y*O",
)

# Catalog prefixes we prefer as an exported #NAME over a generic Gaia id.
_PREFERRED_NAME_PREFIXES = (
    "V*",   "V ",   "NSV",
    "HD ",  "HR ",  "HIP ", "TYC ", "BD",  "CD",
    "ASAS ", "ASASSN-", "ASASSN ", "ZTF ", "OGLE",
    "GSC ", "PPM ",  "SAO ", "WDS ", "WISE ",
)

# Deprioritise plain Gaia identifiers.
_DEPRIORITIZED_NAME_PREFIXES = (
    "Gaia DR3 ", "Gaia DR2 ", "Gaia DR1 ", "Gaia EDR3 ",
)


def _is_variable_otype(otype: str) -> bool:
    if not otype:
        return False
    ot = otype.strip()
    return any(ot.startswith(p) for p in _VARIABLE_OTYPE_PREFIXES)


def _name_score(name: str) -> int:
    n = (name or "").strip()
    for p in _DEPRIORITIZED_NAME_PREFIXES:
        if n.startswith(p):
            return -30
    for p in _PREFERRED_NAME_PREFIXES:
        if n.startswith(p):
            return 30
    return 0


# AAVSO's STARID and KNAME fields want the designation alone -- "V336 Aps",
# not SIMBAD's "V* V336 Aps". That leading token is SIMBAD's object-type
# tag (V*, **, Cl*, EM*, SV*, ...) or the literal "NAME" marker, and WebObs
# rejects a submission that still carries it.
#
# The same tag is why the old VSX fallback never fired: query_object() on a
# tagged SIMBAD id resolves nothing, so the name it was meant to replace
# was handed straight through to the file. Resolve VSX by coordinate and
# sanitise whatever comes back.
def _strip_simbad_type_prefix(name: str) -> str:
    n = " ".join(str(name or "").split())
    if not n:
        return ""
    if n.upper().startswith("NAME "):
        n = n[5:].strip()
    head, _sep, rest = n.partition(" ")
    if rest and head.endswith("*"):
        n = rest.strip()
    return " ".join(n.split())


def _aavso_starid(name: str) -> str:
    """SIMBAD/VSX identifier -> a form AAVSO WebObs will accept."""
    return _strip_simbad_type_prefix(name)


class ExoPlanetWindow(QDialog):
    def __init__(self, parent=None, wrench_path=None, settings=None):
        super().__init__(parent)
        self.settings = settings
        self.main_win = parent
        self.setWindowTitle(self.tr("Exoplanet Transit Detector"))

        self.resize(900, 600)
        self.wrench_path = wrench_path
        # State
        self.image_paths      = []
        self._cached_images   = []
        self._cached_headers  = []   # parallel to _cached_images
        self.times            = None  # astropy Time array
        self.star_positions   = []
        self.fluxes           = None  # stars × frames
        self.flags            = None
        self.raw_flux_rgb     = None  # (3, n_stars, n_frames) for color inputs; None for mono
        self.raw_flux_err_rgb = None
        self.median_fwhm      = None
        self.master_dark      = None
        self.master_flat      = None
        self.exposure_time    = None
        self._last_ensemble   = []
        self.ensemble_map     = {}

        # --- new settings ---
        self.sep_threshold     = 5.0   # SEP σ
        self.border_fraction   = 0.10  # ignore border fraction
        self.ensemble_k        = 10    # ensemble companions
        # e-/ADU override for the photometric gain. 0 = take EGAIN from the
        # header, and fall back to no Poisson term if it isn't there.
        self.camera_egain      = 0.0

        # Analysis
        self.ls_min_frequency     = 0.01
        self.ls_max_frequency     = 10.0
        self.ls_samples_per_peak  = 10
        self.bls_min_period       = 0.05
        self.bls_max_period       = 2.0
        self.bls_n_periods        = 1000
        self.bls_duration_min_frac= 0.01
        self.bls_duration_max_frac= 0.5
        self.bls_n_durations      = 20

        # WCS (standalone; no WIMI)
        self._wcs   = None
        self.wcs_ra = None
        self.wcs_dec= None

        # — Mode selector —
        mode_layout = QHBoxLayout()
        mode_layout.addWidget(QLabel(self.tr("Mode:")))
        self.aligned_mode_rb = QRadioButton(self.tr("Aligned Subs"))
        self.raw_mode_rb     = QRadioButton(self.tr("Raw Subs"))
        self.aligned_mode_rb.setChecked(True)
        mg = QButtonGroup(self)
        mg.addButton(self.aligned_mode_rb); mg.addButton(self.raw_mode_rb)
        mg.buttonToggled.connect(self.on_mode_changed)
        mode_layout.addWidget(self.aligned_mode_rb)
        mode_layout.addWidget(self.raw_mode_rb)
        mode_layout.addStretch()
        self.force_solve_cb = QCheckBox(self.tr("Force blind plate solve"))
        self.force_solve_cb.setChecked(False)
        self.force_solve_cb.setToolTip(
            "Always run the plate solver, even if a valid WCS already exists in the file header.\n"
            "Use this when the embedded WCS is inaccurate or from an unreliable source."
        )
        mode_layout.addWidget(self.force_solve_cb)
        mode_layout.addStretch()   # move this addStretch() to after the checkbox        
        self.wrench_button = QToolButton()
        self.wrench_button.setIcon(QIcon(self.wrench_path))
        self.wrench_button.setToolTip("Settings…")
        self.wrench_button.setStyleSheet("""
            QToolButton {
                background-color: #FF4500;
                color: white;
                padding: 4px;
                border-radius: 4px;
            }
            QToolButton:hover {
                background-color: #FF6347;
            }
        """)
        self.wrench_button.clicked.connect(self.open_settings)
        mode_layout.addWidget(self.wrench_button)
        mode_layout.addWidget(make_help_button("exoplanet", self))

        # — Calibration controls (hidden in Aligned) —
        cal_layout = QHBoxLayout()
        self.load_darks_btn = QPushButton(self.tr("Load Master Dark…"))
        self.load_flats_btn = QPushButton(self.tr("Load Master Flat…"))
        for w in (self.load_darks_btn, self.load_flats_btn):
            w.clicked.connect(self.load_masters)
            w.hide()
            cal_layout.addWidget(w)
        self.dark_status_label = QLabel("Dark: ❌");  self.dark_status_label.hide()
        self.flat_status_label = QLabel("Flat: ❌");  self.flat_status_label.hide()
        cal_layout.addWidget(self.dark_status_label)
        cal_layout.addWidget(self.flat_status_label)
        cal_layout.addStretch()

        # — Status & Progress —
        self.status_label = QLabel("Ready")
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)

        # — Top controls —
        top_layout = QHBoxLayout()
        self.load_raw_btn     = QPushButton(self.tr("1: Load Raw Subs…"))
        self.load_aligned_btn = QPushButton(self.tr("Load, Measure && Photometry…"))
        self.calibrate_btn    = QPushButton(self.tr("1a: Calibrate && Align Subs"))
        self.measure_btn      = QPushButton(self.tr("2: Measure && Photometry"))
        self.load_raw_btn.    clicked.connect(self.load_raw_subs)
        self.load_aligned_btn.clicked.connect(self.load_and_measure_subs)
        self.calibrate_btn.clicked.connect(self.calibrate_and_align)
        self.measure_btn.     clicked.connect(self.detect_stars)
        self.detrend_combo = QComboBox()
        self.detrend_combo.addItems(["No Detrend", "Linear", "Quadratic"])
        self.save_aligned_btn = QPushButton("Save Aligned Frames…")
        self.save_aligned_btn.clicked.connect(self.save_aligned_frames)

        top_layout.addWidget(self.load_raw_btn)
        top_layout.addWidget(self.load_aligned_btn)
        top_layout.addWidget(self.calibrate_btn)
        top_layout.addWidget(self.measure_btn)
        top_layout.addStretch()
        top_layout.addWidget(QLabel("Detrend:"))
        top_layout.addWidget(self.detrend_combo)
        top_layout.addWidget(self.save_aligned_btn)

        # — Star list & Plot —
        middle = QHBoxLayout()
        self.star_list  = QListWidget()
        self.star_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.star_list.itemSelectionChanged.connect(self.update_plot_for_selection)
        self.star_list.setStyleSheet("""
            QListWidget::item:selected {
                background: #3399ff; 
                color: white;
            }
        """)
        middle.addWidget(self.star_list, 2)
        self.plot_widget = pg.PlotWidget(title="Light Curves")
        self.plot_widget.addLegend()
        middle.addWidget(self.plot_widget, 5)

        # — Bottom rows —
        row1 = QHBoxLayout()
        row1.addWidget(QLabel("Dip threshold (ppt):"))
        self.threshold_slider = QSlider(Qt.Orientation.Horizontal)
        self.threshold_slider.setRange(0, 100)
        self.threshold_slider.setValue(20)
        row1.addWidget(self.threshold_slider)
        self.threshold_value_label = QLabel(f"{self.threshold_slider.value()} ppt")
        row1.addWidget(self.threshold_value_label)

        row1.addSpacing(16)
        row1.addWidget(QLabel("Temporal SNR min:"))
        self.temporal_snr_spin = QDoubleSpinBox()
        self.temporal_snr_spin.setRange(0.0, 10.0)
        self.temporal_snr_spin.setSingleStep(0.1)
        self.temporal_snr_spin.setValue(2.0)
        self.temporal_snr_spin.setDecimals(1)
        self.temporal_snr_spin.setToolTip(
            "Minimum ratio of the MA's peak deviation from 1.0\n"
            "to the MAD of residuals (raw points minus MA).\n\n"
            "This is the temporal signal-to-noise of the light curve\n"
            "variation — NOT the photometric SNR of the star itself.\n\n"
            "Higher values reject more noisy/scattered stars.\n"
            "1.5 = MA must move 1.5× further than the typical scatter.\n"
            "Set to 0.0 to disable the coherence check entirely."
        )
        self.temporal_snr_spin.valueChanged.connect(
            lambda _: self.apply_threshold(self.threshold_slider.value())
        )
        row1.addWidget(self.temporal_snr_spin)

        row1.addStretch()
        self.identify_btn = QPushButton("Identify Star…")
        self.identify_btn.clicked.connect(self.on_identify_star)
        row1.addWidget(self.identify_btn)
        self.find_star_btn = QPushButton("Find Star…")
        self.find_star_btn.setToolTip(
            "Look up a star by name (SIMBAD-resolvable — e.g. V336 Aps,\n"
            "HD 12345, TYC 9256-617-1, Gaia DR3 …). Selects the closest\n"
            "detected star in the list."
        )
        self.find_star_btn.clicked.connect(self.on_find_star_by_name)
        row1.addWidget(self.find_star_btn)
        self.show_ensemble_btn = QPushButton("Show Ensemble Members")
        self.show_ensemble_btn.clicked.connect(self.show_ensemble_members)
        row1.addWidget(self.show_ensemble_btn)
        self.analyze_btn = QPushButton("Analyze Star…")
        self.analyze_btn.clicked.connect(self.on_analyze)
        row1.addWidget(self.analyze_btn)

        row2 = QHBoxLayout()
        self.fetch_tesscut_btn = QPushButton("Query TESScut Light Curve")
        self.fetch_tesscut_btn.setEnabled(False)
        self.fetch_tesscut_btn.clicked.connect(self.query_tesscut)
        row2.addWidget(self.fetch_tesscut_btn)
        self.export_btn = QPushButton("Export CSV/FITS")
        self.export_btn.clicked.connect(self.export_data)
        row2.addWidget(self.export_btn)
        self.export_aavso_btn = QPushButton("Export → AAVSO")
        self.export_aavso_btn.clicked.connect(self.export_to_aavso)
        row2.addWidget(self.export_aavso_btn)

        # — Assemble —
        main = QVBoxLayout(self)
        main.addLayout(mode_layout)
        main.addLayout(cal_layout)
        main.addLayout(top_layout)
        main.addLayout(middle)
        main.addLayout(row1)
        main.addLayout(row2)
        statlay = QHBoxLayout()
        statlay.addWidget(self.status_label)
        statlay.addWidget(self.progress_bar)
        main.addLayout(statlay)

        # init
        self.on_mode_changed(self.aligned_mode_rb, True)
        self.detrend_combo.setCurrentIndex(2)
        self.on_detrend_changed(2)
        self.threshold_slider.valueChanged.connect(self._on_threshold_changed)
        self.analyze_btn.setEnabled(False)
        self.calibrate_btn.hide()

    # ---------------- UI wiring ----------------

    def _on_threshold_changed(self, v: int):
        self.threshold_value_label.setText(f"{v} ppt")
        self.apply_threshold(v)
        if hasattr(self, '_ref_overlay'):
            self._ref_overlay._update_highlights()

    def open_settings(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Photometry & Analysis Settings")
        layout = QVBoxLayout(dlg)

        photo_box = QGroupBox("Photometry")
        fb = QFormLayout(photo_box)
        self.sep_spin = QDoubleSpinBox(); self.sep_spin.setRange(1.0, 20.0); self.sep_spin.setSingleStep(0.5); self.sep_spin.setValue(self.sep_threshold)
        fb.addRow("SEP detection σ:", self.sep_spin)
        self.border_spin = QDoubleSpinBox(); self.border_spin.setRange(0.0, 0.5); self.border_spin.setSingleStep(0.01); self.border_spin.setValue(self.border_fraction)
        fb.addRow("Border fraction:", self.border_spin)
        self.egain_spin = QDoubleSpinBox()
        self.egain_spin.setRange(0.0, 100.0)
        self.egain_spin.setSingleStep(0.05)
        self.egain_spin.setDecimals(3)
        self.egain_spin.setValue(float(getattr(self, "camera_egain", 0.0) or 0.0))
        self.egain_spin.setSpecialValueText("Auto (from EGAIN header)")
        self.egain_spin.setToolTip(
            "Camera gain in electrons per ADU, used for the shot-noise term "
            "in MERR.\n\n"
            "0 = read EGAIN from the frame headers. If neither is available "
            "the shot-noise term is dropped, which understates MERR for "
            "bright stars.\n\n"
            "This is NOT the CMOS gain setting (0-500 on ZWO/QHY) — it is "
            "e-/ADU, typically 0.1-10."
        )
        fb.addRow("Camera gain (e-/ADU):", self.egain_spin)
        layout.addWidget(photo_box)

        ens_box = QGroupBox("Ensemble Normalization")
        ef = QFormLayout(ens_box)
        self.ensemble_spin = QSpinBox(); self.ensemble_spin.setRange(1, 50); self.ensemble_spin.setValue(self.ensemble_k)
        ef.addRow("Comparison stars (k):", self.ensemble_spin)
        layout.addWidget(ens_box)

        cds_box = QGroupBox("CDS / SIMBAD")
        cds_form = QFormLayout(cds_box)

        _pref, _pinned = cds_health.server_preference()
        self.cds_server_combo = QComboBox()
        self.cds_server_combo.addItem("Automatic (Strasbourg, then Harvard)", "")
        for _host in cds_health.MIRRORS:
            self.cds_server_combo.addItem(_host, _host)
        _i = self.cds_server_combo.findData(_pref)
        self.cds_server_combo.setCurrentIndex(_i if _i >= 0 else 0)
        self.cds_server_combo.setToolTip(
            "Which SIMBAD mirror to try first.\n\n"
            "Harvard (simbad.harvard.edu) is the US mirror \u2014 the same "
            "machine the web UI calls simbad.cfa.harvard.edu, but that alias "
            "is not a name astroquery accepts, so pick it from this list "
            "rather than typing it."
        )
        cds_form.addRow("SIMBAD mirror:", self.cds_server_combo)

        self.cds_pin_cb = QCheckBox("Don't fall back to the other mirror")
        self.cds_pin_cb.setChecked(_pinned)
        self.cds_pin_cb.setToolTip(
            "If your network reaches one mirror and not the other, failing "
            "over just costs a timeout on every lookup."
        )
        cds_form.addRow("", self.cds_pin_cb)

        self.cds_vizier_combo = QComboBox()
        self.cds_vizier_combo.addItem("Automatic (Strasbourg)", "")
        for _host in cds_health.VIZIER_MIRRORS:
            self.cds_vizier_combo.addItem(_host, _host)
        _vi = self.cds_vizier_combo.findData(cds_health.vizier_server())
        self.cds_vizier_combo.setCurrentIndex(_vi if _vi > 0 else 0)
        cds_form.addRow("VizieR mirror (VSX, APASS):", self.cds_vizier_combo)

        self.cds_status_label = QLabel(cds_health.status_text())
        self.cds_status_label.setWordWrap(True)
        cds_form.addRow("Status:", self.cds_status_label)

        _test_btn = QPushButton("Test now")

        def _test_cds():
            cds_health.set_server_preference(
                self.cds_server_combo.currentData() or "",
                pin=self.cds_pin_cb.isChecked(),
                vizier=self.cds_vizier_combo.currentData() or "",
            )
            self.cds_status_label.setText("Probing\u2026")
            QApplication.processEvents()
            cds_health.probe(force=True)
            self.cds_status_label.setText(
                cds_health.status_text() + "\n" + cds_health.status_detail())

        _test_btn.clicked.connect(_test_cds)
        cds_form.addRow("", _test_btn)

        layout.addWidget(cds_box)

        ana_box = QGroupBox("Analysis (period search)")
        form = QFormLayout(ana_box)
        self.ls_samp_spin = QSpinBox(); self.ls_samp_spin.setRange(1, 100); self.ls_samp_spin.setValue(self.ls_samples_per_peak)
        form.addRow("LS samples / peak:", self.ls_samp_spin)
        self.bls_min_spin = QDoubleSpinBox(); self.bls_min_spin.setRange(0.01, 10.0); self.bls_min_spin.setValue(self.bls_min_period)
        form.addRow("BLS min period [d]:", self.bls_min_spin)
        self.bls_max_spin = QDoubleSpinBox(); self.bls_max_spin.setRange(0.01, 10.0); self.bls_max_spin.setValue(self.bls_max_period)
        form.addRow("BLS max period [d]:", self.bls_max_spin)
        self.bls_nper_spin = QSpinBox(); self.bls_nper_spin.setRange(10, 20000); self.bls_nper_spin.setValue(self.bls_n_periods)
        form.addRow("BLS # periods:", self.bls_nper_spin)
        self.bls_min_frac_spin = QDoubleSpinBox(); self.bls_min_frac_spin.setRange(0.0001, 1.0); self.bls_min_frac_spin.setSingleStep(0.001); self.bls_min_frac_spin.setValue(self.bls_duration_min_frac)
        form.addRow("BLS min dur frac:", self.bls_min_frac_spin)
        self.bls_max_frac_spin = QDoubleSpinBox(); self.bls_max_frac_spin.setRange(0.01, 1.0); self.bls_max_frac_spin.setSingleStep(0.01); self.bls_max_frac_spin.setValue(self.bls_duration_max_frac)
        form.addRow("BLS max dur frac:", self.bls_max_frac_spin)
        self.bls_ndur_spin = QSpinBox(); self.bls_ndur_spin.setRange(1, 200); self.bls_ndur_spin.setValue(self.bls_n_durations)
        form.addRow("BLS # durations:", self.bls_ndur_spin)
        layout.addWidget(ana_box)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        layout.addWidget(btns)

        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.sep_threshold   = self.sep_spin.value()
            self.border_fraction = self.border_spin.value()
            self.camera_egain    = self.egain_spin.value()
            self.ensemble_k      = self.ensemble_spin.value()
            cds_health.set_server_preference(
                self.cds_server_combo.currentData() or "",
                pin=self.cds_pin_cb.isChecked(),
                vizier=self.cds_vizier_combo.currentData() or "",
            )
            self.ls_samples_per_peak = self.ls_samp_spin.value()
            self.bls_min_period        = self.bls_min_spin.value()
            self.bls_max_period        = self.bls_max_spin.value()
            self.bls_n_periods         = self.bls_nper_spin.value()
            self.bls_duration_min_frac = self.bls_min_frac_spin.value()
            self.bls_duration_max_frac = self.bls_max_frac_spin.value()
            self.bls_n_durations       = self.bls_ndur_spin.value()

    def on_mode_changed(self, button, checked):
        is_raw = checked and (button is self.raw_mode_rb)
        for w in (
            self.load_raw_btn,
            self.load_darks_btn,
            self.load_flats_btn,
            self.dark_status_label,
            self.flat_status_label,
            self.calibrate_btn,
        ):
            w.setVisible(is_raw)
        self.load_aligned_btn.setVisible(not is_raw)
        self.measure_btn.setVisible(is_raw)

    def load_and_measure_subs(self):
        before = len(getattr(self, "image_paths", []))
        self.load_aligned_subs()
        after = len(getattr(self, "image_paths", []))
        if after == 0 or after == before and not self._cached_images:
            return
        self.detect_stars()
    # --------------- I/O + Calibration ----------------

    def load_raw_subs(self):
        settings = QSettings()
        start_dir = settings.value("ExoPlanet/lastRawFolder", os.path.expanduser("~"), type=str)
        paths, _ = QFileDialog.getOpenFileNames(self, "Select Raw Frames", start_dir, "FITS, TIFF or XISF (*.fit *.fits *.tif *.tiff *.xisf)")
        if not paths: return
        settings.setValue("ExoPlanet/lastRawFolder", os.path.dirname(paths[0]))

        self.status_label.setText("Reading headers…")
        self.progress_bar.setVisible(True)
        self.progress_bar.setMaximum(len(paths))
        self.progress_bar.setValue(0)
        QApplication.processEvents()

        datelist = []
        for i, p in enumerate(paths, start=1):
            ext = os.path.splitext(p)[1].lower()
            ds = None
            if ext == '.xisf':
                try:
                    xisf     = XISF(p)
                    img_meta = xisf.get_images_metadata()[0].get('FITSKeywords', {})
                    if 'DATE-OBS' in img_meta:
                        ds = img_meta['DATE-OBS'][0]['value']
                except Exception:
                    ds = None
            elif ext in ('.fit', '.fits', '.fz'):
                try:
                    hdr0, _ = get_valid_header(p)
                    ds      = hdr0.get('DATE-OBS')
                except Exception:
                    ds = None

            # Use robust header time parsing (UT-OBS -> DATE-OBS -> MJD-OBS fallback)
            t = None
            try:
                if ext == ".xisf":
                    # Build a tiny dict-like header for the helper
                    hdr_like = {}
                    try:
                        xisf     = XISF(p)
                        img_meta = xisf.get_images_metadata()[0]
                        kw       = img_meta.get("FITSKeywords", {}) or {}
                        # XISF FITSKeywords layout: key -> [ {value: ...}, ... ]
                        for k in ("UT-OBS", "DATE-OBS", "DATE-END", "MJD-OBS"):
                            if k in kw and kw[k]:
                                hdr_like[k] = kw[k][0].get("value")
                    except Exception:
                        hdr_like = {}
                    t = _parse_obs_time_from_header(hdr_like)

                elif ext in (".fit", ".fits", ".fz"):
                    hdr0, _ = get_valid_header(p)
                    t = _parse_obs_time_from_header(hdr0)

                else:
                    # TIFF etc. may not have FITS-like time headers; leave None
                    t = None

            except Exception as e:
                print(f"[DEBUG] Failed to parse obs time for {p}: {e}")

            datelist.append((p, t))

            self.progress_bar.setValue(i)
            QApplication.processEvents()

        datelist.sort(key=lambda x: (x[1] is None, x[1] or x[0]))
        sorted_paths = [p for p, _ in datelist]

        self.image_paths     = sorted_paths
        self._cached_images  = []
        self._cached_headers = []
        self._cached_bitdepths = []
        self.airmasses       = []
        self.star_list.clear()
        self.plot_widget.clear()

        self.status_label.setText("Loading raw frames…")
        self.progress_bar.setMaximum(len(sorted_paths))
        self.progress_bar.setValue(0)
        QApplication.processEvents()

        for i, p in enumerate(sorted_paths, start=1):
            self.status_label.setText(f"Loading raw frame {i}/{len(sorted_paths)}…")
            QApplication.processEvents()
            img, hdr, bit_depth, is_mono = load_image(p)
            if img is None:
                QMessageBox.warning(self, "Load Error", f"Failed to load raw frame:\n{os.path.basename(p)}")
                self._cached_images.append(None)
                self._cached_headers.append(None)
                self._cached_bitdepths.append(None)
                am = 1.0
            else:
                img_binned = bin2x2_numba(img)
                self._cached_images.append(img_binned)
                self._cached_headers.append(hdr)
                self._cached_bitdepths.append(bit_depth)

                if self.exposure_time is None:
                    if isinstance(hdr, fits.Header):
                        self.exposure_time = hdr.get('EXPOSURE', hdr.get('EXPTIME', None))
                    elif isinstance(hdr, dict):
                        img_meta = hdr.get('image_meta', {}) or {}
                        fits_kw  = img_meta.get('FITSKeywords', {})
                        val = None
                        if 'EXPOSURE' in fits_kw: val = fits_kw['EXPOSURE'][0].get('value')
                        elif 'EXPTIME' in fits_kw: val = fits_kw['EXPTIME'][0].get('value')
                        try:
                            self.exposure_time = float(val)
                        except (ValueError, TypeError):
                            print(f"[DEBUG] Could not parse exposure_time={val!r}")

                am = None
                if isinstance(hdr, fits.Header):
                    if 'AIRMASS' in hdr:
                        try: am = float(hdr['AIRMASS'])
                        except ValueError: am = None
                    if am is None:
                        alt = (hdr.get('OBJCTALT') or hdr.get('ALT') or hdr.get('ALTITUDE') or hdr.get('EL'))
                        try: am = self.estimate_airmass_from_altitude(float(alt))
                        except (ValueError, TypeError): am = 1.0
                elif isinstance(hdr, dict):
                    img_meta = hdr.get('image_meta', {}) or {}
                    fits_kw  = img_meta.get('FITSKeywords', {})
                    if 'AIRMASS' in fits_kw:
                        try: am = float(fits_kw['AIRMASS'][0]['value'])
                        except (ValueError, TypeError): am = None
                    if am is None:
                        for key in ('OBJCTALT','ALT','ALTITUDE','EL'):
                            ent = fits_kw.get(key)
                            if ent:
                                try:
                                    am = self.estimate_airmass_from_altitude(float(ent[0]['value']))
                                    break
                                except Exception:
                                    pass  # Ignore airmass estimation errors
                        else:
                            am = 1.0
                if am is None:
                    am = 1.0

            self.airmasses.append(am)
            self.progress_bar.setValue(i)
            QApplication.processEvents()

        # Keep full timestamps (DO NOT truncate to date-only)
        tlist = [t for _, t in datelist if t is not None]
        if tlist:
            self.times = Time(tlist)   # already utc scale from helper
        else:
            self.times = None

        self.progress_bar.setVisible(False)
        loaded = sum(1 for im in self._cached_images if im is not None)
        self.status_label.setText(f"Loaded {loaded}/{len(sorted_paths)} raw frames")

    def load_aligned_subs(self) -> bool:
        settings = QSettings()
        start_dir = settings.value("ExoPlanet/lastAlignedFolder", os.path.expanduser("~"), type=str)
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Select Aligned Frames", start_dir,
            "FITS or TIFF (*.fit *.fits *.tif *.tiff *.xisf)"
        )
        if not paths:
            self.status_label.setText("Load canceled.")
            return False

        settings.setValue("ExoPlanet/lastAlignedFolder", os.path.dirname(paths[0]))

        self.status_label.setText("Reading metadata from aligned frames…")
        self.progress_bar.setVisible(True)
        self.progress_bar.setMaximum(len(paths))
        self.progress_bar.setValue(0)
        QApplication.processEvents()

        datelist = []
        for i, p in enumerate(paths, start=1):
            ext = os.path.splitext(p)[1].lower(); ds = None
            if ext == '.xisf':
                try:
                    xisf     = XISF(p)
                    img_meta = xisf.get_images_metadata()[0]
                    kw       = img_meta.get('FITSKeywords', {})
                    if 'DATE-OBS' in kw: ds = kw['DATE-OBS'][0]['value']
                except Exception: ds = None
            elif ext in ('.fit', '.fits', '.fz'):
                try:
                    hdr0, _ = get_valid_header(p)
                    ds      = hdr0.get('DATE-OBS')
                except Exception: ds = None
            # Use robust header time parsing (UT-OBS -> DATE-OBS -> MJD-OBS fallback)
            t = None
            try:
                if ext == ".xisf":
                    # Build a tiny dict-like header for the helper
                    hdr_like = {}
                    try:
                        xisf     = XISF(p)
                        img_meta = xisf.get_images_metadata()[0]
                        kw       = img_meta.get("FITSKeywords", {}) or {}
                        # XISF FITSKeywords layout: key -> [ {value: ...}, ... ]
                        for k in ("UT-OBS", "DATE-OBS", "DATE-END", "MJD-OBS"):
                            if k in kw and kw[k]:
                                hdr_like[k] = kw[k][0].get("value")
                    except Exception:
                        hdr_like = {}
                    t = _parse_obs_time_from_header(hdr_like)

                elif ext in (".fit", ".fits", ".fz"):
                    hdr0, _ = get_valid_header(p)
                    t = _parse_obs_time_from_header(hdr0)

                else:
                    # TIFF etc. may not have FITS-like time headers; leave None
                    t = None

            except Exception as e:
                print(f"[DEBUG] Failed to parse obs time for {p}: {e}")

            datelist.append((p, t))
            self.progress_bar.setValue(i)
            QApplication.processEvents()

        datelist.sort(key=lambda x: (x[1] is None, x[1] or x[0]))
        sorted_paths = [p for p, _ in datelist]

        self.image_paths     = sorted_paths
        self._cached_images  = []
        self._cached_headers = []
        self._cached_bitdepths = []
        self.airmasses       = []

        self.status_label.setText("Loading aligned frames…")
        self.progress_bar.setMaximum(len(sorted_paths))
        self.progress_bar.setValue(0)
        QApplication.processEvents()

        for i, p in enumerate(sorted_paths, start=1):
            self.status_label.setText(f"Loading frame {i}/{len(sorted_paths)}…")
            QApplication.processEvents()
            img, hdr, bit_depth, is_mono = load_image(p)
            if img is None:
                QMessageBox.warning(self, "Load Error", f"Failed to load aligned frame:\n{os.path.basename(p)}")
                self._cached_images.append(None)
                self._cached_headers.append(None)
                self._cached_bitdepths.append(None)
                am = 1.0
            else:
                img_binned = bin2x2_numba(img)
                self._cached_images.append(img_binned)
                self._cached_headers.append(hdr)
                self._cached_bitdepths.append(bit_depth)

                if self.exposure_time is None:
                    if isinstance(hdr, fits.Header):
                        self.exposure_time = hdr.get('EXPOSURE', hdr.get('EXPTIME', None))
                    elif isinstance(hdr, dict):
                        img_meta = hdr.get('image_meta', {}) or {}
                        fits_kw  = img_meta.get('FITSKeywords', {})
                        val = None
                        if 'EXPOSURE' in fits_kw: val = fits_kw['EXPOSURE'][0].get('value')
                        elif 'EXPTIME' in fits_kw: val = fits_kw['EXPTIME'][0].get('value')
                        try: self.exposure_time = float(val)
                        except (ValueError, TypeError): print(f"[DEBUG] Could not parse exposure_time={val!r}")

                am = None
                if isinstance(hdr, fits.Header):
                    if 'AIRMASS' in hdr:
                        try: am = float(hdr['AIRMASS'])
                        except ValueError: am = None
                    if am is None:
                        alt = (hdr.get('OBJCTALT') or hdr.get('ALT') or hdr.get('ALTITUDE') or hdr.get('EL'))
                        try: am = self.estimate_airmass_from_altitude(float(alt))
                        except (ValueError, TypeError): am = 1.0
                elif isinstance(hdr, dict):
                    img_meta = hdr.get('image_meta', {}) or {}
                    fits_kw  = img_meta.get('FITSKeywords', {})
                    if 'AIRMASS' in fits_kw:
                        try: am = float(fits_kw['AIRMASS'][0]['value'])
                        except (ValueError, TypeError): am = None
                    if am is None:
                        for key in ('OBJCTALT','ALT','ALTITUDE','EL'):
                            ent = fits_kw.get(key)
                            if ent:
                                try:
                                    am = self.estimate_airmass_from_altitude(float(ent[0]['value']))
                                    break
                                except Exception:
                                    pass  # Ignore airmass estimation errors
                        else:
                            am = 1.0
                else:
                    am = 1.0

            self.airmasses.append(am)
            self.progress_bar.setValue(i)
            QApplication.processEvents()

        # Keep full timestamps (DO NOT truncate to date-only)
        tlist = [t for _, t in datelist if t is not None]
        if tlist:
            self.times = Time(tlist)   # already utc scale from helper
        else:
            self.times = None

        self.progress_bar.setVisible(False)
        loaded = sum(1 for im in self._cached_images if im is not None)
        self.status_label.setText(f"Loaded {loaded}/{len(sorted_paths)} aligned frames")
        return loaded > 0

    def load_masters(self):
        settings = QSettings()
        last_master_dir = settings.value("ExoPlanet/lastMasterFolder", os.path.expanduser("~"), type=str)
        sender = self.sender()
        dlg = QFileDialog(self, "Select Master File", last_master_dir, "FITS, TIFF or XISF (*.fit *.fits *.tif *.tiff *.xisf)")
        dlg.setFileMode(QFileDialog.FileMode.ExistingFile)
        if not dlg.exec(): return
        path = dlg.selectedFiles()[0]
        settings.setValue("ExoPlanet/lastMasterFolder", os.path.dirname(path))

        img, hdr, bit_depth, is_mono = load_image(path)
        if img is None:
            QMessageBox.warning(self, "Load Error", f"Failed to load master file:\n{path}")
            return

        img = img.astype(np.float32)
        binned = bin2x2_numba(img)

        if "Dark" in sender.text():
            if self.master_flat is not None and not self._shapes_compatible(binned, self.master_flat):
                QMessageBox.warning(self, "Shape Mismatch", "This master dark (binned) doesn’t match your existing flat.")
                return
            self.master_dark = binned
            self.dark_status_label.setText("Dark: ✅")
            self.dark_status_label.setStyleSheet("color: #00cc66; font-weight: bold;")
        else:
            if self.master_dark is not None and not self._shapes_compatible(self.master_dark, binned):
                QMessageBox.warning(self, "Shape Mismatch", "This master flat (binned) doesn’t match your existing dark.")
                return
            self.master_flat = binned
            self.flat_status_label.setText("Flat: ✅")
            self.flat_status_label.setStyleSheet("color: #00cc66; font-weight: bold;")

    def _try_wcs_from_header(self, hdr, plane):
        H = self._get_best_header_for_wcs(hdr)
        if H is None:
            return None

        try:
            w = WCS(H, naxis=2, relax=True)
            if not w.has_celestial:
                return None

            # sanity check by transforming image center
            h, wimg = plane.shape[:2]
            sky = w.pixel_to_world(wimg / 2, h / 2)
            _ = float(sky.ra.deg), float(sky.dec.deg)
            return w
        except Exception:
            return None

    def _shapes_compatible(self, master: np.ndarray, other: np.ndarray) -> bool:
        if master.shape == other.shape:
            return True
        if master.ndim == 2 and other.ndim == 3 and other.shape[:2] == master.shape:
            return True
        if other.ndim == 2 and master.ndim == 3 and master.shape[:2] == other.shape:
            return True
        return False

    def calibrate_and_align(self):
        if not self._cached_images:
            QMessageBox.warning(self, "Calibrate", "Load raw subs first.")
            return
        self.status_label.setText("Calibrating & aligning frames…")
        self.progress_bar.setVisible(True)
        n = len(self._cached_images)
        self.progress_bar.setMaximum(n)

        reference_image_2d = None
        for i, (img, hdr) in enumerate(zip(self._cached_images, self._cached_headers), start=1):
            if self.master_dark is not None:
                img = img.astype(np.float32) - self.master_dark
            if self.master_flat is not None:
                img = apply_flat_division_numba(img, self.master_flat)
            if img.ndim == 2:
                img = np.stack([img, img, img], axis=2)

            plane = img if img.ndim == 2 else img.mean(axis=2)

            if reference_image_2d is None:
                reference_image_2d = plane.copy()

            delta = StarRegistrationWorker.compute_affine_transform_astroalign(plane, reference_image_2d)
            if delta is None:
                delta = IDENTITY_2x3

            img_aligned = StarRegistrationThread.apply_affine_transform_static(img, delta)
            self._cached_images[i-1] = img_aligned
            self.progress_bar.setValue(i)
            QApplication.processEvents()

        self.progress_bar.setVisible(False)
        self.status_label.setText("Calibration & alignment complete")

    def save_aligned_frames(self):
        if not self._cached_images:
            QMessageBox.warning(self, "Save Aligned Frames", "No images to save. Run Calibrate & Align first.")
            return
        out_dir = QFileDialog.getExistingDirectory(self, "Choose Output Folder")
        if not out_dir:
            return
        for i, orig_path in enumerate(self.image_paths):
            img = self._cached_images[i]
            ext = os.path.splitext(orig_path)[1].lstrip(".").lower()
            fmt = ext if ext in ("fits","fit","tiff","tif","xisf","png","jpg","jpeg") else "fits"
            hdr = self._cached_headers[i] if hasattr(self, "_cached_headers") and i < len(self._cached_headers) else None
            base = os.path.splitext(os.path.basename(orig_path))[0]
            out_name = f"{base}_aligned.{fmt}"
            out_path = os.path.join(out_dir, out_name)
            save_image(
                img_array=img, filename=out_path, original_format=fmt, bit_depth=None,
                original_header=hdr, is_mono=(img.ndim==2), image_meta=None, file_meta=None
            )
        QMessageBox.information(self, "Save Complete", f"Saved {len(self._cached_images)} aligned frames to:\n{out_dir}")

    # --------------- Detection + Photometry ----------------
    def _seed_header_for_astap(self, ref_idx: int) -> fits.Header | None:
        """
        Build a *real* FITS header to seed ASTAP, harvested from the reference
        frame's original header. We preserve RA/Dec (OBJCTRA/OBJCTDEC or CRVAL1/2),
        size (NAXIS*), basic camera hints (PIXSZ, BINNING, FOCALLEN) if present.
        """
        if not (0 <= ref_idx < len(self._cached_headers)):
            return None

        src = self._cached_headers[ref_idx]
        H = fits.Header()

        # try to copy directly if it's already a FITS Header
        if isinstance(src, fits.Header):
            H = src.copy()
        elif isinstance(src, dict):
            # Could be a nested XISF-like dict. Look for FITSKeywords first.
            kw = None
            if "image_meta" in src and isinstance(src["image_meta"], dict):
                kw = src["image_meta"].get("FITSKeywords", None)
            if kw is None:
                kw = src.get("FITSKeywords", None)
            if isinstance(kw, dict):
                for k, v in kw.items():
                    try:
                        # XISF stores [{'value':...}], FITS-like dicts store raw
                        if isinstance(v, list):
                            vv = v[0].get("value", None)
                        else:
                            vv = v
                        if vv is not None:
                            H[k] = vv
                    except Exception:
                        pass
            else:
                # best-effort: flat dict of scalars
                for k, v in src.items():
                    try:
                        H[k] = v
                    except Exception:
                        pass

        # be sure image size is present (ASTAP likes NAXIS1/2)
        if self._cached_images and self._cached_images[ref_idx] is not None:
            img = self._cached_images[ref_idx]
            h, w = (img.shape if img.ndim == 2 else img.shape[:2])
            H.setdefault("NAXIS", 2)
            H["NAXIS1"] = w
            H["NAXIS2"] = h

        # If we only have OBJCTRA/OBJCTDEC strings, just leave them — your
        # _build_astap_seed() handles these. If we *also* have CRVAL*, keep them.
        # Do NOT inject WCS—we want ASTAP to solve, not be constrained by stale WCS.
        # (_solve_numpy_with_astap will strip WCS keys before writing temp FITS)

        # optional: exposure time
        if self.exposure_time is not None:
            H.setdefault("EXPTIME", float(self.exposure_time))

        return H if len(H) else None

    def _coerce_seed_header(self, hdr_in, plane) -> fits.Header:
        """
        Make a real fits.Header usable by _build_astap_seed():
        - copy fields from FITS, XISF-like dicts, or flat dicts
        - ensure NAXIS/NAXIS1/NAXIS2
        - try to expose RA/Dec in a form the seeder can use
            (OBJCTRA/OBJCTDEC strings and/or CRVAL1/CRVAL2 degrees).
        """
        H = fits.Header()

        # 1) copy what we can
        if isinstance(hdr_in, fits.Header):
            H = hdr_in.copy()
        elif isinstance(hdr_in, dict):
            # XISF-style nested?
            kw = None
            if "image_meta" in hdr_in and isinstance(hdr_in["image_meta"], dict):
                kw = hdr_in["image_meta"].get("FITSKeywords")
            if kw is None:
                kw = hdr_in.get("FITSKeywords")
            if isinstance(kw, dict):
                for k, v in kw.items():
                    try:
                        vv = v[0]["value"] if isinstance(v, list) else v
                        if vv is not None:
                            H[k] = vv
                    except Exception:
                        pass
            else:
                # flat dict of scalars
                for k, v in hdr_in.items():
                    try:
                        H[k] = v
                    except Exception:
                        pass

        # 2) ensure image size
        h, w = (plane.shape if plane.ndim == 2 else plane.shape[:2])
        H.setdefault("NAXIS", 2)
        H["NAXIS1"] = int(w)
        H["NAXIS2"] = int(h)

        # 3) try to normalize RA/Dec
        # If OBJCTRA/OBJCTDEC are present as strings, keep them.
        # Otherwise, if we find numeric RA/DEC/CRVAL*, ensure CRVAL1/2 are set.
        def _try_deg(val):
            try:
                return float(val)
            except Exception:
                return None

        ra_deg = None
        dec_deg = None

        # prefer CRVAL1/2 if they seem finite
        ra_deg = _try_deg(H.get("CRVAL1"))
        dec_deg = _try_deg(H.get("CRVAL2"))

        if ra_deg is None or dec_deg is None:
            # common alternates
            for rakey in ("RA", "OBJCTRA", "OBJRA"):
                if rakey in H:
                    try:
                        # could be sexagesimal string
                        ra_deg = SkyCoord(H[rakey], H.get("OBJCTDEC", None) or H.get("DEC", None), unit=(u.hourangle, u.deg)).ra.deg
                        dec_deg = SkyCoord(H[rakey], H.get("OBJCTDEC", None) or H.get("DEC", None), unit=(u.hourangle, u.deg)).dec.deg
                        break
                    except Exception:
                        pass
            if ra_deg is None and "RA" in H and "DEC" in H:
                ra_deg = _try_deg(H["RA"])
                dec_deg = _try_deg(H["DEC"])

        # Set CRVAL* if we have clean degrees
        if ra_deg is not None and dec_deg is not None:
            H["CRVAL1"] = float(ra_deg)
            H["CRVAL2"] = float(dec_deg)

            # Also supply OBJCTRA/OBJCTDEC sexagesimal (helps some ASTAP setups)
            try:
                c = SkyCoord(ra_deg*u.deg, dec_deg*u.deg, frame="icrs")
                H.setdefault("OBJCTRA",  c.ra.to_string(unit=u.hour, sep=":", precision=2, pad=True))
                H.setdefault("OBJCTDEC", c.dec.to_string(unit=u.deg, sep=":", precision=1, pad=True, alwayssign=True))
            except Exception:
                pass

        # Optional: if you have pixel size / focal length / binning in the original
        # header, leaving them in place is good; _build_astap_seed will use them.

        return H

    def _get_best_header_for_wcs(self, hdr):
        if isinstance(hdr, fits.Header):
            return hdr

        if isinstance(hdr, dict):
            # first try canonical SASpro metadata keys
            for k in ("wcs_header", "original_header", "header", "fits_header"):
                h = hdr.get(k)
                if isinstance(h, fits.Header):
                    return h

            # XISF-style FITSKeywords fallback
            kw = None
            if "image_meta" in hdr and isinstance(hdr["image_meta"], dict):
                kw = hdr["image_meta"].get("FITSKeywords")
            if kw is None:
                kw = hdr.get("FITSKeywords")

            if isinstance(kw, dict):
                H = fits.Header()
                for k, v in kw.items():
                    try:
                        vv = v[0]["value"] if isinstance(v, list) else v
                        if vv is not None:
                            H[k] = vv
                    except Exception:
                        pass
                return H if len(H) else None

        return None

    def _try_existing_wcs(self, hdr):
        H = self._get_best_header_for_wcs(hdr)
        if H is None:
            return None
        try:
            w = WCS(H, naxis=2, relax=True)
            if not w.has_celestial:
                return None
            return w
        except Exception:
            return None


    def _photometry_gain(self):
        """
        Electrons per data unit, for sep's `gain`, or None when unknown.

        Order: explicit user setting, then EGAIN from the frame headers.
        Returns None if neither is available or the bit depth doesn't pin
        down the ADU scale -- a 32-bit float stack carries no units we can
        infer, and guessing one is worse than dropping the Poisson term.
        """
        egain = float(getattr(self, "camera_egain", 0.0) or 0.0)
        if egain <= 0.0:
            egain = 0.0
            for hdr in (getattr(self, "_cached_headers", None) or []):
                v = _header_scalar(hdr, _EGAIN_KEYS)
                # Sanity band: real e-/ADU sits around 0.1-10. A value of
                # 100+ is almost certainly a CMOS gain setting written to
                # the wrong keyword, and using it would under-weight the
                # shot noise by the same factor.
                if v is not None and 0.01 <= v <= 100.0:
                    egain = float(v)
                    break
        if egain <= 0.0:
            return None

        scale = None
        for bd in (getattr(self, "_cached_bitdepths", None) or []):
            if bd:
                scale = _ADU_PER_UNIT.get(str(bd).strip())
                break
        if not scale:
            return None

        # bin2x2_numba averages, so each binned unit stands for 4 pixels'
        # worth of electrons.
        return float(egain) * float(scale) * 4.0

    def detect_stars(self):
        self.status_label.setText("Measuring frames…")
        self.progress_bar.setVisible(True)
        self.progress_bar.setMaximum(len(self.image_paths))
        self.progress_bar.setValue(0)

        # 0) ensure frames are cached
        if not hasattr(self, "_cached_images") or len(self._cached_images) != len(self.image_paths):
            _loaded = [load_image(p) for p in self.image_paths]
            self._cached_images    = [r[0] for r in _loaded]
            self._cached_bitdepths = [r[2] for r in _loaded]

        n_frames = len(self._cached_images)
        self.progress_bar.setMaximum(n_frames)
        self.progress_bar.setValue(0)

        # --- PASS 1: per-frame background & SEP stats (parallel) ---
        def _process_frame(idx, img):
            plane = img.mean(axis=2) if img.ndim == 3 else img
            mean, med, std = sigma_clipped_stats(plane)
            zeroed = plane - med
            bkg    = sep.Background(zeroed)
            bkgmap = bkg.back()
            rmsmap = bkg.rms()
            data_sub = zeroed - bkgmap

            # keep arrays tight for SEP
            data_sub = np.ascontiguousarray(data_sub.astype(np.float32, copy=False))
            rmsmap   = np.ascontiguousarray(rmsmap.astype(np.float32, copy=False))

            try:
                objs = sep.extract(
                    data_sub, thresh=self.sep_threshold, err=rmsmap,
                    minarea=16, deblend_nthresh=32, clean=True
                )
            except Exception:
                objs = None

            if objs is None or len(objs) == 0:
                sc = 0; avg_fwhm = 0.0; avg_ecc = 0.0
            else:
                sc = len(objs)
                a = np.clip(objs['a'], 1e-3, None)
                b = np.clip(objs['b'], 1e-3, None)
                fwhm_vals = 2.3548 * np.sqrt(a * b)
                ecc_vals  = np.sqrt(1.0 - np.clip(b / a, 0, 1)**2)
                avg_fwhm  = float(np.nanmean(fwhm_vals))
                avg_ecc   = float(np.nanmean(ecc_vals))

            stats = {"star_count": sc, "eccentricity": avg_ecc,
                    "mean": float(np.mean(plane)), "fwhm": avg_fwhm}
            return idx, data_sub, objs, rmsmap, stats

        cpu_cnt   = multiprocessing.cpu_count()
        n_workers = max(1, int(cpu_cnt * 0.8))

        frame_data = {}
        stats_map  = {}
        with ThreadPoolExecutor(max_workers=n_workers) as exe:
            futures = [exe.submit(_process_frame, idx, img)
                    for idx, img in enumerate(self._cached_images)]
            done = 0
            for fut in as_completed(futures):
                idx, data_sub, objs, rmsmap, stats = fut.result()
                frame_data[idx] = (data_sub, objs, rmsmap)
                stats_map[idx]  = stats
                done += 1
                self.progress_bar.setValue(done)
                self.status_label.setText(f"Measured frame {done}/{n_frames}")

        # pick best reference
        def quality(i):
            s = stats_map[i]
            return s["star_count"] / (s["fwhm"] * s["mean"] + 1e-8)
        ref_idx   = max(stats_map.keys(), key=quality)
        ref_stats = stats_map[ref_idx]

        # --- Solve WCS on reference (unchanged) ---
        self.ref_idx = ref_idx
        ref_img = self._cached_images[ref_idx]
        plane = ref_img.mean(axis=2) if ref_img.ndim == 3 else ref_img
        hdr = self._cached_headers[ref_idx]
        self._solve_reference(plane, hdr)


        # --- SEP catalog on reference ---
        data_ref, objs_ref, rms_ref = frame_data[ref_idx]
        if objs_ref is None or len(objs_ref) == 0:
            QMessageBox.warning(self, "No Stars", "No stars found in reference frame.")
            self.progress_bar.setVisible(False)
            return

        xs = objs_ref['x']; ys = objs_ref['y']
        h, w = data_ref.shape
        bf = self.border_fraction
        keep_border = ((xs > w*bf) & (xs < w*(1-bf)) & (ys > h*bf) & (ys < h*(1-bf)))
        xs = np.ascontiguousarray(xs[keep_border].astype(np.float32, copy=False))
        ys = np.ascontiguousarray(ys[keep_border].astype(np.float32, copy=False))

        self.median_fwhm = ref_stats["fwhm"]
        aper_r = float(max(2.5, 1.5 * self.median_fwhm))

        # --- PASS 2: aperture + annulus sky subtraction on all frames --------
        n_stars  = len(xs)
        n_frames = len(self._cached_images)
        raw_flux     = np.empty((n_stars, n_frames), dtype=np.float32)
        raw_flux_err = np.empty((n_stars, n_frames), dtype=np.float32)
        flags        = np.zeros((n_stars, n_frames), dtype=np.int16)

        # Per-star FWHM from reference frame for adaptive aperture
        # Fall back to median_fwhm if per-star values aren't available
        if objs_ref is not None and len(objs_ref) > 0:
            a_ref = np.clip(objs_ref['a'][keep_border], 1e-3, None)
            b_ref = np.clip(objs_ref['b'][keep_border], 1e-3, None)
            per_star_fwhm = 2.3548 * np.sqrt(a_ref * b_ref)
        else:
            per_star_fwhm = np.full(n_stars, self.median_fwhm, dtype=np.float32)

        # Clamp per-star FWHM to a sane range around the median
        fwhm_med = float(np.nanmedian(per_star_fwhm))
        fwhm_med = max(fwhm_med, 1.5)
        per_star_fwhm = np.clip(per_star_fwhm, 0.5 * fwhm_med, 3.0 * fwhm_med)

        # Aperture and annulus radii based on per-star FWHM
        # aperture  : 1.5 × FWHM  (captures ~95% of flux for Gaussian PSF)
        # annulus in: 3.0 × FWHM  (clear of any PSF wings)
        # annulus out: 5.0 × FWHM (enough sky pixels for good median estimate)
        aper_r   = np.maximum(2.5, 1.5 * per_star_fwhm).astype(np.float64)
        ann_r_in  = np.maximum(aper_r + 1.0, 3.0 * per_star_fwhm).astype(np.float64)
        ann_r_out = np.maximum(ann_r_in + 2.0, 5.0 * per_star_fwhm).astype(np.float64)

        self.status_label.setText("Computing aperture photometry with annulus sky subtraction…")
        self.progress_bar.setMaximum(n_frames)
        self.progress_bar.setValue(0)

        _gain = self._photometry_gain()
        self._photometry_gain_used = _gain
        if _gain:
            print(f"[DEBUG] photometric gain: {_gain:.4g} e-/data-unit")
        else:
            print("[DEBUG] photometric gain unknown — Poisson term omitted; "
                  "MERR will reflect sky/read noise and the systematic floor "
                  "only. Set the camera gain in Settings for a complete "
                  "error budget.")

        def _sum_frame(t: int):
            data_sub, _objs, rmsmap = frame_data[t]
            ds = np.maximum(data_sub, -1.0 * rmsmap)

            fl   = np.zeros(n_stars, dtype=np.float64)
            ferr = np.zeros(n_stars, dtype=np.float64)
            flg  = np.zeros(n_stars, dtype=np.int16)

            for si in range(n_stars):
                xsi = float(xs[si])
                ysi = float(ys[si])
                r   = float(aper_r[si])
                rin  = float(ann_r_in[si])
                rout = float(ann_r_out[si])

                # --- aperture sum ---
                try:
                    f_ap, f_err, f_flag = sep.sum_circle(
                        ds, [xsi], [ysi], r, err=rmsmap,
                        gain=_gain,
                    )
                    f_ap   = float(f_ap[0])
                    f_err  = float(f_err[0])
                    f_flag = int(f_flag[0])
                except Exception:
                    fl[si] = np.nan; ferr[si] = np.nan; flg[si] = 1
                    continue

                # --- annulus sky estimate (robust median × aperture area) ---
                try:
                    ann_flux, ann_err, ann_flag = sep.sum_circann(
                        ds, [xsi], [ysi], rin, rout, err=rmsmap, gain=_gain,
                    )
                    ann_area = sep.circann_area(rin, rout)
                    ap_area  = np.pi * r * r

                    # sky per pixel from annulus (median is more robust than mean)
                    sky_per_pix = float(ann_flux[0]) / max(ann_area, 1.0)

                    # subtract local sky from aperture
                    sky_total = sky_per_pix * ap_area
                    f_sky_sub = f_ap - sky_total

                    #saspropagate sky subtraction error
                    # var(sky_total) = (ap_area/ann_area)^2 * var(ann)
                    sky_err_contrib = float(ann_err[0]) * (ap_area / max(ann_area, 1.0))
                    f_err_total = float(np.sqrt(max(f_err**2 + sky_err_contrib**2, 0.0)))

                    fl[si]   = f_sky_sub
                    ferr[si] = f_err_total
                    flg[si]  = f_flag | int(ann_flag[0])

                except Exception:
                    # annulus failed — fall back to global-background-subtracted value
                    fl[si]   = f_ap
                    ferr[si] = f_err
                    flg[si]  = f_flag

            return t, fl.astype(np.float32), ferr.astype(np.float32), flg.astype(np.int16)

        done = 0
        with ThreadPoolExecutor(max_workers=n_workers) as exe:
            for t, fl, ferr, flg in exe.map(_sum_frame, range(n_frames)):
                raw_flux[:, t]     = fl
                raw_flux_err[:, t] = ferr
                flags[:, t]        = flg
                done += 1
                if (done % 4) == 0 or done == n_frames:
                    self.progress_bar.setValue(done)

        # --- ENSEMBLE NORMALIZATION (safe masks + unit-median renorm) ---
        n_stars, n_frames = raw_flux.shape
        star_refs = np.nanmedian(raw_flux, axis=1)
        rel_flux = np.full_like(raw_flux, np.nan, dtype=np.float32)
        rel_err  = np.full_like(raw_flux_err, np.nan, dtype=np.float32)

        k = int(self.ensemble_k)
        k = max(1, min(k, max(1, n_stars - 1)))  # keep in range
        self.ensemble_map = {}

        for i in range(n_stars):
            diffs = np.abs(star_refs - star_refs[i])
            diffs[i] = np.inf
            neigh = np.argpartition(diffs, k)[:k]
            self.ensemble_map[i] = list(np.asarray(neigh, dtype=int))

            ens_flux = np.nanmedian(raw_flux[neigh, :], axis=0)
            ens_err  = np.sqrt(np.nansum(raw_flux_err[neigh, :]**2, axis=0)) / np.sqrt(len(neigh))

            mask = (raw_flux[i] > 0) & (ens_flux > 0) & np.isfinite(raw_flux[i]) & np.isfinite(ens_flux)
            if not np.any(mask):
                continue

            rel_flux[i, mask] = raw_flux[i, mask] / ens_flux[mask]
            with np.errstate(divide='ignore', invalid='ignore'):
                term1 = raw_flux_err[i, mask] / raw_flux[i, mask]
                term2 = ens_err[mask]         / ens_flux[mask]
                rel_err[i, mask] = rel_flux[i, mask] * np.sqrt(term1**2 + term2**2)

        # unit-median renorm so curves are centered ~1.0
        meds = np.nanmedian(rel_flux, axis=1)
        good = (meds > 0) & np.isfinite(meds)
        rel_flux[good] /= meds[good, None]
        rel_err[good]  /= meds[good, None]

        self.fluxes      = rel_flux
        self.flux_errors = rel_err
        self.flags       = flags

        # --- detrend (then re-center) ---
        if self.detrend_degree is not None:
            n_stars = rel_flux.shape[0]
            self.status_label.setText("Detrending curves…")
            self.progress_bar.setVisible(True)
            self.progress_bar.setMaximum(n_stars)
            self.progress_bar.setValue(0)
            for i in range(n_stars):
                curve = rel_flux[i].copy()
                goodm = np.isfinite(curve) & (curve > 0)
                rel_flux[i] = self._detrend_curve(curve, self.detrend_degree, mask=goodm)
                self.progress_bar.setValue(i+1)
            self.progress_bar.setVisible(False)
            self.status_label.setText("Detrending complete")

            meds = np.nanmedian(rel_flux, axis=1)
            good = (meds > 0) & np.isfinite(meds)
            rel_flux[good] /= meds[good, None]

        # --- robust per-star outlier flagging ---
        for i in range(n_stars):
            curve = rel_flux[i, :]
            med_i = np.nanmedian(curve)
            mad_i = np.nanmedian(np.abs(curve - med_i))
            sigma_i = 1.4826 * mad_i if mad_i > 0 else np.nanstd(curve)
            if sigma_i > 0:
                outlier_mask = np.abs(curve - med_i) > 2 * sigma_i
                flags[i, outlier_mask] = 1

        # --- drop stars with too many flagged frames ---
        good_counts = np.sum(flags == 0, axis=1)
        keep        = good_counts >= (0.75 * n_frames)

        # Remap ensemble_map from OLD (pre-filter) star indices to NEW
        # (post-filter) indices, dropping any member that was itself filtered
        # out. Without this, everything keyed by star index after a drop -- the
        # auto-selected check star, its catalog mag, and the per-frame errors --
        # points at the wrong row.
        old_to_new = -np.ones(n_stars, dtype=int)
        old_to_new[np.where(keep)[0]] = np.arange(int(np.count_nonzero(keep)))
        remapped = {}
        for old_i in range(n_stars):
            new_i = int(old_to_new[old_i])
            if new_i < 0:
                continue
            remapped[new_i] = [int(old_to_new[j])
                               for j in self.ensemble_map.get(old_i, [])
                               if 0 <= j < n_stars and old_to_new[j] >= 0]
        self.ensemble_map = remapped

        xs, ys       = xs[keep], ys[keep]
        rel_flux     = rel_flux[keep, :]
        rel_err      = rel_err[keep, :]
        raw_flux     = raw_flux[keep, :]
        raw_flux_err = raw_flux_err[keep, :]
        flags        = flags[keep, :]

        self.star_positions = list(zip(xs, ys))
        self.fluxes         = rel_flux.copy()
        self.flux_errors    = rel_err.copy()
        self.raw_flux       = raw_flux.copy()       # background-subtracted instrumental flux
        self.raw_flux_err   = raw_flux_err.copy()   # its 1-sigma error -- needed for calibrated mags
        self.flags          = flags

        # Supplementary per-channel R/G/B pass for color inputs. Populates
        # self.raw_flux_rgb / self.raw_flux_err_rgb, or leaves them None
        # for mono. Enables multi-band (TB/TG/TR) AAVSO export.
        self._run_multiband_photometry(xs, ys, keep_mask=None)

        # list uses median rel flux, not the first frame
        self.star_list.clear()
        for i, (x, y) in enumerate(self.star_positions):
            fmed = np.nanmedian(rel_flux[i])
            ftxt = f"{fmed:.3f}" if np.isfinite(fmed) else "na"
            item = QListWidgetItem(
                f"#{i}: x={x:.1f}, y={y:.1f}   RelFlux≈{ftxt}   FWHM={self.median_fwhm:.2f}"
            )
            item.setData(Qt.ItemDataRole.UserRole, i)
            self.star_list.addItem(item)

        # overlay & finish: use the real reference plane, not SEP background-subtracted data
        self._show_reference_with_circles(plane, self.star_positions)
        self.status_label.setText("Ready")
        self.progress_bar.setVisible(False)
        self.analyze_btn.setEnabled(True)

        # refresh dip-highlights using MA-based thresholding
        self._on_threshold_changed(self.threshold_slider.value())

    def _solve_reference(self, plane, hdr):
        plane2d = plane.mean(axis=2) if getattr(plane, "ndim", 2) == 3 else plane

        # Images were 2x2 binned during load — track this so pixel→sky
        # conversions apply the correct scale factor.
        self._wcs_bin_factor = 2  # always set; plate solver works on binned plane
                                   # so solved WCS is already in binned coords.
                                   # Header WCS from original file is NOT — see below.

        def _is_xisf_source(h) -> bool:
            if h is None:
                return False
            # XISF loaded via legacy loader stores format in metadata dict
            if isinstance(h, dict):
                fmt = str(h.get("original_format", "")).lower()
                if fmt == "xisf":
                    return True
                # Any key starting with XISF: is a tell-tale from xisf_fits_header_from_meta
                for k in h.keys():
                    if isinstance(k, str) and k.upper().startswith("XISF:"):
                        return True
                # Check nested fits_header / original_header
                for sub_key in ("fits_header", "original_header", "header"):
                    sub = h.get(sub_key)
                    if isinstance(sub, fits.Header):
                        for k in sub.keys():
                            if isinstance(k, str) and k.upper().startswith("XISF:"):
                                return True
            if isinstance(h, fits.Header):
                for k in h.keys():
                    if isinstance(k, str) and k.upper().startswith("XISF:"):
                        return True
            return False

        source_is_xisf = _is_xisf_source(hdr)

        # Also check the file extension of the first loaded path as a fallback
        if not source_is_xisf and self.image_paths:
            ref_path = self.image_paths[self.ref_idx] if hasattr(self, "ref_idx") else self.image_paths[0]
            if str(ref_path).lower().endswith(".xisf"):
                source_is_xisf = True

        # ── Step 1: trust existing WCS only if NOT from XISF and not forcing ─
        force_solve = self.force_solve_cb.isChecked()
 
        if not source_is_xisf and not force_solve:
            existing_wcs = self._try_wcs_from_header(hdr, plane2d)
            if existing_wcs is not None:
                # Ask the user whether to reuse the existing WCS or re-solve
                ans = QMessageBox.question(
                    self,
                    "WCS Found",
                    "A valid WCS solution was found in the image header.\n\n"
                    "Use the existing WCS?\n\n"
                    "• Yes — use the header WCS as-is (fast)\n"
                    "• No  — run the plate solver to get a fresh solution",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes,
                )
                if ans == QMessageBox.StandardButton.Yes:
                    self._wcs = existing_wcs
                    self._wcs_bin_factor = 2  # header WCS is full-res; star coords are binned
                    H, W = plane2d.shape[:2]
                    try:
                        # This WCS is in FULL-RES pixels while plane2d is
                        # binned, so the frame centre sits at
                        # (W, H) * bin_factor / 2 in its coordinates. At
                        # bin_factor 2 that is exactly (W, H) -- which is
                        # what the old line passed, correct by coincidence
                        # rather than by construction. Spelled out so it
                        # survives the factor ever changing.
                        _bf = float(getattr(self, "_wcs_bin_factor", 2) or 2)
                        center = self._wcs.pixel_to_world(W * _bf / 2.0,
                                                          H * _bf / 2.0)
                        self.wcs_ra  = float(center.ra.deg)
                        self.wcs_dec = float(center.dec.deg)
                    except Exception:
                        self.wcs_ra = self.wcs_dec = None
 
                    ra_str  = "nan" if self.wcs_ra  is None else f"{self.wcs_ra:.5f}"
                    dec_str = "nan" if self.wcs_dec is None else f"{self.wcs_dec:.5f}"
                    self.status_label.setText(f"WCS from header: RA={ra_str}, Dec={dec_str}")
                    self.fetch_tesscut_btn.setEnabled(True)
                    return
                # else: fall through to plate solve below
        else:
            if force_solve:
                self.status_label.setText("Force blind solve enabled — ignoring any existing WCS…")
            else:
                self.status_label.setText(
                    "XISF source detected — skipping approximate WCS, running plate solve…")
            QApplication.processEvents()



        # ── Step 2: plate-solve ───────────────────────────────────────────
        #
        # plane2d is 2x2 binned; the header is not. plate_solver takes its
        # pixel-scale hint straight out of this header, so handing it an
        # unbinned one tells it the scale is half what it is.
        #
        # The blind path does not merely degrade on that: solve_blind_core
        # discards any candidate outside +/-30% of the hint, and the truth
        # is 2.0x it, so every candidate is thrown away and the solve
        # reports "no match" on a field it had already located. The same
        # number also sets the |AB| baseline window and picks the index
        # layer, so it is wrong three ways before the filter even runs.
        _BIN = 2
        seed_hdr = _rescale_header_for_binning(
            self._coerce_seed_header(hdr if hdr is not None else {}, plane2d),
            _BIN)
        meta = {}
        if isinstance(hdr, fits.Header):
            meta["original_header"] = _rescale_header_for_binning(hdr, _BIN)
        elif isinstance(hdr, dict):
            meta.update(hdr)
            # _seed_header_from_meta lets meta["wcs"] / meta["wcs_header"]
            # OVERRIDE original_header. Both describe the unbinned grid, so
            # leaving them in means the corrected header is quietly
            # overwritten by the very WCS it was correcting.
            for _k in ("wcs", "wcs_header", "fits_header"):
                meta.pop(_k, None)
            H = self._get_best_header_for_wcs(hdr)
            meta["original_header"] = (_rescale_header_for_binning(H, _BIN)
                                       if H is not None else seed_hdr)
        else:
            meta["original_header"] = seed_hdr

        # For XISF, the seed header still has useful RA/Dec/scale hints
        # even though we don't trust its distortion model — keep them.
        if source_is_xisf and "original_header" in meta:
            existing_h = meta["original_header"]
            if isinstance(existing_h, fits.Header):
                # Strip SIP and CD/CDELT so the solver starts clean,
                # but keep CRVAL*/OBJCTRA/OBJCTDEC/FOCALLEN/XPIXSZ for hints
                strip_keys = [k for k in existing_h.keys()
                              if k.startswith(("A_", "B_", "AP_", "BP_",
                                               "CD1_", "CD2_", "CDELT",
                                               "CTYPE", "CRPIX", "NAXIS"))]
                clean_hdr = existing_h.copy()
                for k in strip_keys:
                    try:
                        del clean_hdr[k]
                    except Exception:
                        pass
                meta["original_header"] = clean_hdr

        doc = SimpleNamespace(
            image=plane2d,
            metadata=meta,
        )

        settings = getattr(self, "settings", None)
        if settings is None and hasattr(self, "main_win"):
            settings = getattr(self.main_win, "settings", None)
        if settings is None and self.parent() is not None:
            settings = getattr(self.parent(), "settings", None)

        ok, res = plate_solve_doc_inplace(self, doc, settings)
        if not ok:
            if source_is_xisf:
                # For XISF, offer to fall back to the approximate WCS rather
                # than leaving the user with nothing at all
                ans = QMessageBox.question(
                    self,
                    "Plate Solve Failed",
                    f"Plate solving failed:\n{res}\n\n"
                    "The loaded files are XISF — the embedded WCS is an approximation "
                    "of PixInsight's TPS solution and may be off by 10–30 arcsec in the "
                    "frame corners.\n\n"
                    "Use the approximate XISF WCS anyway? Star matching may fail for "
                    "some targets near the edges.",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No,
                )
                if ans == QMessageBox.StandardButton.Yes:
                    fallback_wcs = self._try_wcs_from_header(hdr, plane2d)
                    if fallback_wcs is not None:
                        self._wcs = fallback_wcs
                        H2, W2 = plane2d.shape[:2]
                        try:
                            # Same correction as the reuse path above, and
                            # here it was genuinely wrong: this WCS is
                            # full-res, so (W2/2, H2/2) is a QUARTER of the
                            # way into the frame, not the centre.
                            _bf2 = float(getattr(self, "_wcs_bin_factor", 2) or 2)
                            center = self._wcs.pixel_to_world(W2 * _bf2 / 2.0,
                                                              H2 * _bf2 / 2.0)
                            self.wcs_ra  = float(center.ra.deg)
                            self.wcs_dec = float(center.dec.deg)
                        except Exception:
                            self.wcs_ra = self.wcs_dec = None
                        self.status_label.setText(
                            "⚠️ Using approximate XISF WCS (star matching may be imprecise)"
                        )
                        self.fetch_tesscut_btn.setEnabled(True)
                        return
            QMessageBox.critical(self, "Plate Solve", f"Plate solving failed:\n{res}")
            self._wcs = None
            self.fetch_tesscut_btn.setEnabled(False)
            return

        # ── Step 3: grab solved WCS ───────────────────────────────────────
        self._wcs = doc.metadata.get("wcs", None)
        self._wcs_bin_factor = 1  # solver worked on binned plane → WCS is in binned coords        
        if self._wcs is None or not getattr(self._wcs, "has_celestial", False):
            QMessageBox.warning(self, "Plate Solve", "Solver finished but no usable WCS was found.")
            self.fetch_tesscut_btn.setEnabled(False)
            self._wcs = None
            return

        H, W = plane2d.shape[:2]
        try:
            center = self._wcs.pixel_to_world(W / 2, H / 2)
            self.wcs_ra  = float(center.ra.deg)
            self.wcs_dec = float(center.dec.deg)
        except Exception:
            self.wcs_ra = self.wcs_dec = None

        ra_str  = "nan" if self.wcs_ra  is None else f"{self.wcs_ra:.5f}"
        dec_str = "nan" if self.wcs_dec is None else f"{self.wcs_dec:.5f}"
        self.status_label.setText(f"WCS solved: RA={ra_str}, Dec={dec_str}")
        self.fetch_tesscut_btn.setEnabled(True)

    # ---------------- Plotting & helpers ----------------

    def show_ensemble_members(self):
        sels = self.star_list.selectedItems()
        if len(sels) != 1: return
        target = sels[0].data(Qt.ItemDataRole.UserRole)
        members = self.ensemble_map.get(target, [])
        for idx in self._last_ensemble:
            item = self.star_list.item(idx)
            if item:
                color = item.background().color()
                if color == QColor('lightblue'):
                    item.setBackground(QBrush())
        for idx in members:
            item = self.star_list.item(idx)
            if item and item.background().color() != QColor('yellow'):
                item.setBackground(QBrush(QColor('lightblue')))
        self._last_ensemble = members

    def on_detrend_changed(self, idx: int):
        # idx==0 → No Detrend, 1 → Linear, 2 → Quadratic
        mapping = {0: None, 1: 1, 2: 2}
        self.detrend_degree = mapping[idx]
        if getattr(self, 'fluxes', None) is not None:
            self.update_plot_for_selection()

    @staticmethod
    def _detrend_curve(curve: np.ndarray, deg: int, mask: Optional[np.ndarray] = None) -> np.ndarray:
        x = np.arange(curve.size)
        if mask is None:
            mask = np.isfinite(curve) & (curve > 0)
        n_good = int(mask.sum())
        if n_good < 2:
            return curve
        fit_deg = min(deg, n_good - 1)
        if fit_deg < 1:
            return curve
        try:
            coeffs = np.polyfit(x[mask], curve[mask], fit_deg)
        except Exception:
            return curve
        trend = np.polyval(coeffs, x)
        trend[trend == 0] = 1.0
        return curve / trend

    def _show_reference_with_circles(self, plane, positions):
        dlg = ReferenceOverlayDialog(
            plane=plane,
            positions=positions,
            target_median=self.median_fwhm,
            parent=self
        )
        self._ref_overlay = dlg
        dlg.show()

    def update_plot_for_selection(self):
        """Redraw light curves for the selected stars."""
        # 1) sanity
        if self.fluxes is None:
            QMessageBox.warning(self, "No Photometry", "Please run photometry before selecting a star.")
            return

        # 2) X axis: hours since start if we have times, else frame index
        try:
            import astropy.units as u
            x_all = (self.times - self.times[0]).to(u.hour).value
            bottom_label = "Hours since start"
        except Exception:
            x_all = np.arange(self.fluxes.shape[1])
            bottom_label = "Frame"

        # 3) prep plot
        self.plot_widget.clear()
        self.plot_widget.addLegend()
        self.plot_widget.setLabel('bottom', bottom_label)
        self.plot_widget.setLabel('left',   'Relative Flux')

        # 4) what to draw?
        inds = [it.data(Qt.ItemDataRole.UserRole) for it in self.star_list.selectedItems()]
        if not inds:
            return

        n_stars = self.fluxes.shape[0]
        medians = np.nanmedian(self.fluxes, axis=1)
        max_gap = 1.0  # hours (or frames if no time axis)

        for idx in inds:
            f = self.fluxes[idx]
            flags_star = self.flags[idx] if (self.flags is not None and idx < self.flags.shape[0]) else np.zeros_like(f, int)

            mask = np.isfinite(f) & (f > 0) & (flags_star == 0)
            if mask.sum() < 2:
                continue

            rel = f[mask] / medians[idx]
            x   = x_all[mask]

            # moving average (window=5)
            ma = self.moving_average(rel, window=5) if hasattr(self, "moving_average") else np.convolve(np.pad(rel, 2, mode="edge"), np.ones(5)/5, mode="valid")

            # split segments across large gaps
            dt = np.diff(x)
            breaks = np.where(dt > max_gap)[0]
            segments = np.split(np.arange(len(x)), breaks+1)

            color = pg.intColor(idx, hues=n_stars)
            dull  = QColor(color); dull.setAlpha(60)
            dull_pen   = pg.mkPen(color=dull, width=1)
            dull_brush = pg.mkBrush(color=dull)
            dash_pen   = pg.mkPen(color=color, width=2, style=Qt.PenStyle.DashLine)

            for seg in segments:
                xs, ys, mas = x[seg], rel[seg], ma[seg]
                # raw points
                self.plot_widget.plot(xs, ys, pen=dull_pen, symbol='o', symbolBrush=dull_brush, name=f"Star #{idx}")
                # moving average
                self.plot_widget.plot(xs, mas, pen=dash_pen, name="MA (w=5)")

    def apply_threshold(self, ppt_threshold: int, sigma_upper: float = 3.0):
        if not hasattr(self, 'fluxes') or self.fluxes is None:
            return

        rel = self.fluxes
        n_stars, n_frames = rel.shape

        flagged = set()
        for i in range(n_stars):
            f = rel[i]
            flags_star = self.flags[i] if self.flags is not None else np.zeros(n_frames, dtype=np.int16)

            mask = np.isfinite(f) & (f > 0) & (flags_star == 0)
            if mask.sum() < 5:
                continue

            med_i = float(np.nanmedian(f[mask]))
            if not (np.isfinite(med_i) and med_i > 0):
                continue

            f_norm = f[mask] / med_i
            ma = self.moving_average(f_norm, window=5)

            # Peak deviation of the MA from 1.0
            ma_dev_ppt = np.abs(1.0 - ma) * 1000.0
            finite = np.isfinite(ma_dev_ppt)
            if not finite.any():
                continue
            peak_ppt = float(np.nanmax(ma_dev_ppt[finite]))

            if peak_ppt < ppt_threshold:
                continue

            # ── Coherence check ───────────────────────────────────────────
            # Compute scatter of raw points around the MA (residuals).
            # If scatter is large relative to the MA excursion, the MA is
            # being driven by noise rather than a coherent signal.
            residuals = f_norm - ma
            mad_residuals = float(1.4826 * np.nanmedian(
                np.abs(residuals - np.nanmedian(residuals))
            )) * 1000.0  # in ppt

            if np.isfinite(mad_residuals) and mad_residuals > 0:
                min_snr = self.temporal_snr_spin.value()
                if min_snr > 0.0 and (peak_ppt / mad_residuals) < min_snr:
                    continue
            flagged.add(i)

        for dlg in self.findChildren(ReferenceOverlayDialog):
            dlg.update_dip_flags(flagged)

        for row in range(self.star_list.count()):
            self.star_list.item(row).setBackground(QBrush())
        for idx in flagged:
            item = self.star_list.item(idx)
            if item:
                item.setBackground(QBrush(QColor('yellow')))

        self.status_label.setText(f"{len(flagged)} star(s) deviate ≥ {ppt_threshold} ppt")

    def moving_average(self, curve, window=5):
        pad = window//2
        ext = np.pad(curve, pad, mode="edge")
        kernel = np.ones(window)/window
        ma = np.convolve(ext, kernel, mode="valid")
        return ma

    # ---------------- Analysis + Identify ----------------

    def on_analyze(self):
        sels = self.star_list.selectedItems()
        if len(sels) != 1:
            QMessageBox.information(self, "Analyze", "Please select exactly one star.")
            return
        idx = sels[0].data(Qt.ItemDataRole.UserRole)

        # ── 1. Build raw time/flux arrays ────────────────────────────────────
        t_jd  = self.times.utc.jd                  # full JD
        f_all = self.fluxes[idx]
        good  = np.isfinite(f_all) & (self.flags[idx] == 0)
        t_jd_good = t_jd[good]
        f_good    = f_all[good]

        if len(t_jd_good) < 10:
            QMessageBox.warning(self, "Analyze", "Not enough good points to analyze.")
            return

        # ── 2. Lomb-Scargle on relative MJD (unit-median flux) ───────────────
        t_rel = t_jd_good - t_jd_good[0]          # days from first obs
        f_norm = f_good / np.nanmedian(f_good[np.isfinite(f_good) & (f_good > 0)])

        ls = LombScargle(t_rel, f_norm)
        Tspan = float(np.ptp(t_rel))
        dt    = float(np.nanmedian(np.diff(np.sort(t_rel))))
        min_f = max(1.0 / Tspan, 1e-6)
        max_f = 0.5 / max(dt, 1e-9)
        freq, power_ls = ls.autopower(
            minimum_frequency=min_f,
            maximum_frequency=max_f,
            samples_per_peak=getattr(self, "ls_samples_per_peak", 10),
        )
        mask = (freq > 0) & np.isfinite(power_ls)
        freq, power_ls = freq[mask], power_ls[mask]
        periods_ls = 1.0 / freq
        order = np.argsort(periods_ls)
        periods_ls, power_ls = periods_ls[order], power_ls[order]
        best_ls_period = float(periods_ls[np.argmax(power_ls)])

        # ── 3. Prepare cleaned light curve for BLS ───────────────────────────
        t_clean, y_clean = _prepare_search_lightcurve(t_jd_good, f_good)
        if t_clean.size < 20:
            QMessageBox.warning(self, "Analyze", "Too few clean points for BLS.")
            return

        baseline_days = float(np.ptp(t_clean))
        bls_min_p = float(getattr(self, "bls_min_period", 0.5))
        bls_max_p = min(
            float(getattr(self, "bls_max_period", 30.0)),
            0.95 * baseline_days,
        )
        if bls_max_p <= bls_min_p:
            bls_max_p = max(bls_min_p * 2.0, 0.95 * baseline_days)

        # Duration grid
        min_p_for_dur = bls_min_p
        dur_min_frac  = float(getattr(self, "bls_duration_min_frac", 0.01))
        dur_max_frac  = float(getattr(self, "bls_duration_max_frac", 0.10))
        n_durations   = int(getattr(self, "bls_n_durations", 8))
        dur_grid = np.linspace(
            dur_min_frac * min_p_for_dur,
            dur_max_frac * min_p_for_dur,
            n_durations,
        )  # days

        # ── 4. BLS with whitened power + multi-peak scanning ─────────────────
        dy_scalar = _robust_sigma(y_clean)
        if not (np.isfinite(dy_scalar) and dy_scalar > 0):
            dy_scalar = float(np.nanstd(y_clean - np.nanmedian(y_clean)))
        if not (np.isfinite(dy_scalar) and dy_scalar > 0):
            dy_scalar = 1e-4

        bls_model = BoxLeastSquares(
            t_clean * u.day,
            y_clean,
            dy=np.full_like(y_clean, dy_scalar),
        )
        result = bls_model.autopower(
            dur_grid * u.day,
            objective="snr",
            oversample=10,
            minimum_n_transit=2,
            minimum_period=bls_min_p * u.day,
            maximum_period=bls_max_p * u.day,
        )

        power_raw = np.asarray(result.power, float).ravel()
        periods_bls = np.asarray(result.period.value
                                if hasattr(result.period, "value")
                                else result.period, float).ravel()

        if power_raw.size == 0 or not np.any(np.isfinite(power_raw)):
            QMessageBox.warning(self, "Analyze", "BLS returned no usable power spectrum.")
            return

        _, power_white = _whiten_periodogram(power_raw)
        power_metric = power_white if np.any(np.isfinite(power_white)) else power_raw

        # Compute SDE from whitened power
        fin_m = np.isfinite(power_metric)
        power_med = float(np.nanmedian(power_metric[fin_m]))
        power_std = float(max(
            _robust_sigma(power_metric[fin_m]),
            float(np.nanstd(power_metric[fin_m])),
            1e-12,
        ))

        # Scan top peaks, pick best by SNR after local refinement
        peak_idxs = _top_peak_indices(periods_bls, power_metric, max_peaks=12, merge_frac=0.01)
        if not peak_idxs:
            peak_idxs = [int(np.nanargmax(power_metric))]

        best_period_d  = np.nan
        best_duration_d = np.nan
        best_t0_jd     = np.nan
        best_depth_frac = np.nan
        best_sde       = -np.inf
        best_metric    = -np.inf

        for pi in peak_idxs:
            cand_period = float(periods_bls[pi])
            if not (np.isfinite(cand_period) and bls_min_p <= cand_period <= bls_max_p):
                continue

            # Local refinement around this peak
            half_w  = max(0.01, 0.20 * cand_period)
            p_lo    = max(bls_min_p, cand_period - half_w)
            p_hi    = min(bls_max_p, cand_period + half_w)
            n_steps = 101
            p_grid  = np.linspace(p_lo, p_hi, n_steps) * u.day

            try:
                ref = bls_model.power(
                    p_grid, dur_grid * u.day,
                    objective="snr", oversample=5,
                )
                ref_power = np.asarray(ref.power, float).ravel()
                ref_periods = np.asarray(ref.period.value
                                        if hasattr(ref.period, "value")
                                        else ref.period, float).ravel()
                _, ref_white = _whiten_periodogram(ref_power)
                ref_metric = ref_white if np.any(np.isfinite(ref_white)) else ref_power
                k = int(np.nanargmax(ref_metric))

                cand_p  = float(ref_periods[k])
                cand_d  = float(ref.duration[k].value
                                if hasattr(ref.duration[k], "value")
                                else ref.duration[k])
                cand_t0 = float(ref.transit_time[k].value
                                if hasattr(ref.transit_time[k], "value")
                                else ref.transit_time[k])
                cand_depth = abs(float(ref.depth[k].value
                                    if hasattr(ref.depth[k], "value")
                                    else ref.depth[k])) if hasattr(ref, "depth") else np.nan
                cand_metric = float(ref_metric[k]) if np.isfinite(ref_metric[k]) else float(ref_power[k])
            except Exception:
                cand_p  = cand_period
                cand_d  = float(result.duration[pi].value
                                if hasattr(result.duration[pi], "value")
                                else result.duration[pi])
                cand_t0 = float(result.transit_time[pi].value
                                if hasattr(result.transit_time[pi], "value")
                                else result.transit_time[pi])
                cand_depth = abs(float(result.depth[pi].value
                                    if hasattr(result.depth[pi], "value")
                                    else result.depth[pi])) if hasattr(result, "depth") else np.nan
                cand_metric = float(power_metric[pi]) if np.isfinite(power_metric[pi]) else 0.0

            sde = (cand_metric - power_med) / power_std if power_std > 0 else 0.0

            # Apply alias penalty
            alias_pen = _alias_penalty(cand_p)
            sde_adj = sde - 1.5 * alias_pen

            if sde_adj > best_sde:
                best_sde        = sde_adj
                best_period_d   = cand_p
                best_duration_d = cand_d
                best_t0_jd      = cand_t0
                best_depth_frac = cand_depth
                best_metric     = cand_metric

        if not np.isfinite(best_period_d):
            # Fall back to raw argmax
            k = int(np.nanargmax(power_metric))
            best_period_d   = float(periods_bls[k])
            best_duration_d = float(result.duration[k].value
                                    if hasattr(result.duration[k], "value")
                                    else result.duration[k])
            best_t0_jd      = float(result.transit_time[k].value
                                    if hasattr(result.transit_time[k], "value")
                                    else result.transit_time[k])
            best_depth_frac = abs(float(result.depth[k].value
                                        if hasattr(result.depth[k], "value")
                                        else result.depth[k])) if hasattr(result, "depth") else np.nan
            best_sde        = (float(power_metric[k]) - power_med) / power_std if power_std > 0 else 0.0

        # ── 5. Phase fold [-0.5, 0.5] ────────────────────────────────────────
        phase = _phase_centered(t_clean, best_period_d, best_t0_jd)

        # BLS box model on sorted phase
        ord_ph = np.argsort(phase)
        phase_s = phase[ord_ph]
        flux_s  = y_clean[ord_ph]

        transit_half = min(0.45, max(0.01, 0.5 * best_duration_d / best_period_d))
        depth_plot   = float(best_depth_frac) if np.isfinite(best_depth_frac) else 0.0
        model_phase = np.linspace(-0.5, 0.5, 500)
        model_flux  = np.where(np.abs(model_phase) <= transit_half,
                            1.0 - depth_plot, 1.0)

        # Binned phase curve
        bin_width = max(0.005, transit_half / 3.0)
        bx, by, be = _make_binned_curve(phase, y_clean, bin_width)

        # Dip event detection for the summary
        dip_events = _estimate_night_dip_events(t_jd_good, f_good)

        # ── 6. Build dialog ───────────────────────────────────────────────────
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Analysis: Star #{idx}  |  P = {best_period_d:.4f} d  |  SDE = {best_sde:.1f}")
        layout = QVBoxLayout(dlg)

        # Summary label
        dur_hr   = best_duration_d * 24.0
        depth_ppt = depth_plot * 1000.0
        n_dips   = len(dip_events)
        alias_pen = _alias_penalty(best_period_d)
        summary = (
            f"Period: {best_period_d:.5f} d   "
            f"Duration: {dur_hr:.2f} h   "
            f"Depth: {depth_ppt:.2f} ppt   "
            f"SDE: {best_sde:.1f}   "
            f"Alias penalty: {alias_pen:.2f}   "
            f"Night dips detected: {n_dips}"
        )
        lbl = QLabel(summary)
        lbl.setStyleSheet("font-size: 11px; color: #aaddff; padding: 4px;")
        layout.addWidget(lbl)

        tabs = __import__("PyQt6.QtWidgets", fromlist=["QTabWidget"]).QTabWidget()
        layout.addWidget(tabs)

        # ── Tab 1: Lomb-Scargle ───────────────────────────────────────────────
        pg_ls = pg.PlotWidget(title="Lomb–Scargle Periodogram")
        pg_ls.plot(periods_ls, power_ls, pen=pg.mkPen("w", width=1))
        pg_ls.addLine(x=best_ls_period,
                    pen=pg.mkPen("y", style=Qt.PenStyle.DashLine, width=2))
        pg_ls.setLabel("bottom", "Period [d]")
        pg_ls.setLabel("left", "LS Power")
        pg_ls.showGrid(True, True, alpha=0.3)
        tabs.addTab(pg_ls, "Lomb-Scargle")

        # ── Tab 2: BLS Periodogram (whitened) ────────────────────────────────
        pg_bls = pg.PlotWidget(title="BLS Periodogram (whitened SNR)")
        pg_bls.plot(periods_bls, power_metric, pen=pg.mkPen("c", width=1))
        pg_bls.addLine(x=best_period_d,
                    pen=pg.mkPen("r", style=Qt.PenStyle.DashLine, width=2))
        pg_bls.setLabel("bottom", "Period [d]")
        pg_bls.setLabel("left", "Whitened Power")
        pg_bls.showGrid(True, True, alpha=0.3)
        tabs.addTab(pg_bls, "BLS Periodogram")

        # ── Tab 3: Phase fold ─────────────────────────────────────────────────
        pg_fold = pg.PlotWidget(title=f"Phase-Folded  P = {best_period_d:.4f} d")

        # Raw points (grey, small)
        pg_fold.plot(
            phase, y_clean,
            pen=None, symbol="o",
            symbolBrush=pg.mkBrush(180, 180, 180, 80),
            symbolSize=4,
            name="Raw",
        )

        # Binned points with error bars (blue)
        if bx.size > 0:
            err = pg.ErrorBarItem(
                x=bx, y=by, height=2 * be,
                pen=pg.mkPen("b", width=1.5),
            )
            pg_fold.addItem(err)
            pg_fold.plot(
                bx, by,
                pen=None, symbol="o",
                symbolBrush=pg.mkBrush(80, 160, 255, 220),
                symbolSize=7,
                name="Binned",
            )

        # Box model (red)
        pg_fold.plot(
            model_phase, model_flux,
            pen=pg.mkPen("r", width=2),
            name="Box model",
        )
        pg_fold.addLine(y=1.0, pen=pg.mkPen("w", style=Qt.PenStyle.DashLine, width=1))
        pg_fold.setLabel("bottom", "Phase")
        pg_fold.setLabel("left", "Relative Flux")
        pg_fold.showGrid(True, True, alpha=0.3)
        tabs.addTab(pg_fold, "Phase Fold")

        # ── Tab 4: Raw light curve ────────────────────────────────────────────
        pg_lc = pg.PlotWidget(title="Raw Light Curve")
        # t_jd_good and f_good are already filtered (finite + flag==0)
        # so t_plot and f_norm are the same size — no secondary mask needed
        t_plot = t_jd_good - t_jd_good[0]
        f_norm_plot = f_good / np.nanmedian(f_good[np.isfinite(f_good) & (f_good > 0)])
        pg_lc.plot(
            t_plot, f_norm_plot,
            pen=None, symbol="o",
            symbolBrush=pg.mkBrush(180, 200, 255, 160),
            symbolSize=4,
        )
        # Mark predicted transit centers
        if np.isfinite(best_t0_jd) and np.isfinite(best_period_d):
            t0_rel = best_t0_jd - t_jd_good[0]
            span   = float(np.ptp(t_plot))
            epoch  = math.floor((0.0 - t0_rel) / best_period_d)
            while True:
                tc = t0_rel + epoch * best_period_d
                if tc > span + best_period_d:
                    break
                if tc >= -best_period_d:
                    pg_lc.addLine(
                        x=tc,
                        pen=pg.mkPen("r", style=Qt.PenStyle.DashLine, width=1),
                    )
                epoch += 1
        pg_lc.setLabel("bottom", "Days from first obs")
        pg_lc.setLabel("left", "Relative Flux")
        pg_lc.showGrid(True, True, alpha=0.3)
        tabs.addTab(pg_lc, "Light Curve")

        dlg.resize(1000, 640)
        dlg.exec()

    # ---- shared SIMBAD/VSX name resolver ------------------------------
    #
    # Query SIMBAD around (ra, dec) at a moderately wide radius, then score
    # every returned row so that variable-star otypes and named catalog IDs
    # rank above generic Gaia DR3 entries.  Ties break on angular offset.
    # If the winning row still isn't obviously a variable, ask VSX (by
    # coordinate, NOT by the main_id we just got — VSX has no reverse
    # index on Gaia identifiers) whether anything in the region carries a
    # variable-star designation, and upgrade the name if so.
    #
    # This fixes the exported #NAME landing on "Gaia DR3 5790…" when the
    # user clicked V336 Aps: with a 5″ SIMBAD radius and a distance-only
    # sort, a Gaia catalog entry sitting 2–3″ from the click could beat the
    # actual Mira in row 0, and the old VSX fallback (query_object on that
    # Gaia string) then returned nothing.

    def _resolve_target_name_row(self, ra_deg, dec_deg, radius_arcsec=15.0):
        """Return dict {main_id, otype, vmag, offset_arcsec, is_variable,
        used_vsx} for the best-scoring match near (ra_deg, dec_deg), or
        None on failure / no match.  Never raises."""
        coord = SkyCoord(ra=ra_deg*u.deg, dec=dec_deg*u.deg, frame="icrs")
        table = None

        # Preflight: ~4 s to learn CDS is down, versus 5 unbounded attempts
        # at the OS connect timeout. Once the breaker is tripped this costs
        # nothing on later lookups in the same session.
        if not cds_health.simbad_available():
            print(f"[DEBUG] SIMBAD skipped — {cds_health.status_text()}")
            return self._vsx_only_lookup(coord, radius_arcsec)

        # Two attempts, not five, and a connection failure breaks out
        # immediately instead of buying the same timeout four more times.
        for attempt in range(1, 3):
            try:
                custom = _new_simbad()
                custom.add_votable_fields("otype")
                custom.add_votable_fields("flux(V)")
                table = custom.query_region(coord, radius=radius_arcsec*u.arcsec)
                cds_health.note_success()
                break
            except Exception as e:
                print(f"[DEBUG] SIMBAD attempt {attempt} failed: {e}")
                if cds_health.note_failure(e, context="exoplanet/resolve_target"):
                    print("[DEBUG] SIMBAD unreachable — falling back to VSX.")
                    return self._vsx_only_lookup(coord, radius_arcsec)
                if attempt == 2:
                    return None
                non_blocking_sleep(1)

        if table is None or len(table) == 0:
            # SIMBAD blank — try VSX directly as a last resort.
            return self._vsx_only_lookup(coord, radius_arcsec)

        try:
            id_col    = next(c for c in table.colnames if c.lower() == "main_id")
            ra_col    = next(c for c in table.colnames if c.lower() == "ra")
            dec_col   = next(c for c in table.colnames if c.lower() == "dec")
        except StopIteration:
            return None
        otype_col = next((c for c in table.colnames if c.lower() == "otype"), None)
        flux_col  = next((c for c in table.colnames if c.upper() in ("FLUX_V", "V")), None)

        best = None
        best_score = None
        for row in table:
            name = row[id_col]
            if isinstance(name, bytes):
                name = name.decode("utf-8")
            name = str(name).strip()

            try:
                rra  = float(row[ra_col])
                rdec = float(row[dec_col])
            except Exception:
                continue
            match  = SkyCoord(ra=rra*u.deg, dec=rdec*u.deg, frame="icrs")
            offset = float(coord.separation(match).arcsec)

            otype = ""
            if otype_col is not None:
                ov = row[otype_col]
                if isinstance(ov, bytes):
                    ov = ov.decode("utf-8")
                otype = str(ov).strip()

            vmag = None
            if flux_col is not None:
                try:
                    fv = float(row[flux_col])
                    if np.isfinite(fv):
                        vmag = fv
                except Exception:
                    vmag = None

            score = 0.0
            if _is_variable_otype(otype):
                score += 100.0
            score += _name_score(name)
            score -= offset  # closer wins ties

            if (best_score is None) or (score > best_score):
                best_score = score
                best = {
                    "main_id":       name,
                    "otype":         otype,
                    "vmag":          vmag,
                    "offset_arcsec": offset,
                    "is_variable":   _is_variable_otype(otype),
                    "used_vsx":      False,
                }

        if best is None:
            return None

        # If the winner still isn't a variable, see if VSX has something
        # nearby that we should upgrade to.
        if not best["is_variable"]:
            vsx_name = self._vsx_name_near(coord, radius_arcsec)
            if vsx_name:
                best["main_id"]     = vsx_name
                best["used_vsx"]    = True
                best["is_variable"] = True

        return best

    def _vsx_name_near(self, coord, radius_arcsec):
        """Return the closest VSX 'Name' within `radius_arcsec`, or None."""
        try:
            # Deliberately NOT gated on cds_health: VizieR runs on separate
            # hosts from the SIMBAD TAP endpoint, so this is a genuine
            # fallback when SIMBAD alone is broken. It is only bounded, so a
            # Strasbourg-wide outage costs one timeout instead of hanging.
            v = _new_vizier(columns=["Name", "RAJ2000", "DEJ2000"],
                            catalog="B/vsx")
            v.ROW_LIMIT = 25
            tbls = v.query_region(coord, radius=radius_arcsec*u.arcsec)
        except Exception as e:
            print(f"[DEBUG] VSX region lookup failed: {e}")
            return None
        if not tbls or len(tbls) == 0 or len(tbls[0]) == 0:
            return None
        t = tbls[0]
        try:
            ras  = np.asarray(t["RAJ2000"], dtype=float)
            decs = np.asarray(t["DEJ2000"], dtype=float)
        except Exception:
            return None
        cands = SkyCoord(ra=ras*u.deg, dec=decs*u.deg, frame="icrs")
        seps  = coord.separation(cands).arcsec
        i     = int(np.argmin(seps))
        name  = t["Name"][i]
        if isinstance(name, bytes):
            name = name.decode("utf-8")
        return str(name).strip() or None

    def _vsx_only_lookup(self, coord, radius_arcsec):
        """SIMBAD returned nothing — try VSX alone.  Same dict shape."""
        name = self._vsx_name_near(coord, radius_arcsec)
        if not name:
            return None
        return {
            "main_id":       name,
            "otype":         "V*",
            "vmag":          None,
            "offset_arcsec": float("nan"),
            "is_variable":   True,
            "used_vsx":      True,
        }

    # ---- UI: Identify Star (uses the shared resolver) -----------------
    def on_identify_star(self):
        radec = self.get_selected_star_radec()
        if radec is None:
            QMessageBox.warning(self, "Identify Star", "Please select exactly one star first.")
            return
        ra, dec = radec

        hit = self._resolve_target_name_row(ra, dec, radius_arcsec=15.0)
        if hit is None:
            QMessageBox.information(
                self, "No SIMBAD/VSX Matches",
                f"No objects found within 15″ of {ra:.6f}, {dec:.6f}\n"
                f"(or SIMBAD/VSX unreachable — see console for details)."
            )
            return

        main_id  = hit["main_id"]
        obj_type = hit["otype"] or "n/a"
        vmag     = hit["vmag"]
        offset   = hit["offset_arcsec"]
        vmag_str = f"{vmag:.3f}" if vmag is not None else "n/a"
        off_str  = f"{offset:.2f}″" if np.isfinite(offset) else "n/a"
        tag      = " (VSX)" if hit["used_vsx"] else ""

        simbad_url = "https://simbad.cds.unistra.fr/simbad/sim-id" f"?Ident={quote(main_id)}"
        msg = QMessageBox(self)
        msg.setWindowTitle("SIMBAD/VSX Lookup")
        msg.setText(
            f"Best match{tag}:\n"
            f"  ID:     {main_id}\n"
            f"  Type:   {obj_type}\n"
            f"  V mag:  {vmag_str}\n"
            f"  Offset: {off_str}"
        )
        open_btn = msg.addButton("Open in SIMBAD", QMessageBox.ButtonRole.ActionRole)
        ok_btn   = msg.addButton(QMessageBox.StandardButton.Ok)
        msg.exec()
        if msg.clickedButton() == open_btn:
            webbrowser.open(simbad_url)

    # ---- UI: Find Star by name ----------------------------------------
    #
    # David's request #1: instead of star-hopping from WIMI to locate a
    # named target, let the user type the name.  We resolve via SIMBAD,
    #sasproject through the WCS, and single-select the closest detected
    # star in the list (which triggers the existing overlay highlight and
    # light-curve redraw).  Tolerance is generous — max(2·median FWHM,
    # 10″) — to cover slight WCS residuals; if nothing detected is close
    # enough we report the resolved pixel so the user can see whether SEP
    # dropped it (faint, on the border, saturated).

    def on_find_star_by_name(self):
        if not self.star_positions:
            QMessageBox.warning(
                self, "Find Star",
                "Run photometry first so there are detected stars to search among."
            )
            return
        if self._wcs is None:
            QMessageBox.warning(
                self, "Find Star",
                "No WCS available — plate-solve during photometry first."
            )
            return

        name, ok = QInputDialog.getText(
            self, "Find Star by Name",
            "Enter a SIMBAD-resolvable name\n"
            "(e.g. V336 Aps, HD 12345, TYC 9256-617-1, Gaia DR3 …):",
            QLineEdit.EchoMode.Normal, ""
        )
        if not ok or not name.strip():
            return
        name = name.strip()

        # 1) resolve name -> RA/Dec via SIMBAD
        #
        # Name resolution has no offline substitute: there is no local
        # catalogue here to turn "V336 Aps" into coordinates. So unlike the
        # region lookups this one genuinely cannot proceed without CDS, and
        # the right behaviour is to say so in ~4 s rather than freeze.
        if not cds_health.simbad_available():
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Icon.Warning)
            box.setWindowTitle("SIMBAD Unavailable")
            box.setText("Name resolution needs SIMBAD, and no CDS mirror "
                        "is reachable right now.")
            box.setInformativeText(
                "Resolving a name to coordinates has no offline equivalent, "
                "so this lookup can't run. You can still select the star "
                "directly in the image, or paste its RA/Dec if you have "
                "them.\n\n"
                "If one mirror works for you and the other doesn't, pick it "
                "under the wrench \u2192 CDS / SIMBAD.\n\n"
                "CDS status: https://cds.unistra.fr"
            )
            box.setDetailedText(
                f"{cds_health.status_text()}\n\nMirrors tried:\n"
                f"{cds_health.status_detail()}"
            )
            retry = box.addButton("Re-test mirrors",
                                  QMessageBox.ButtonRole.ActionRole)
            box.addButton(QMessageBox.StandardButton.Ok)
            box.exec()
            if box.clickedButton() is retry:
                cds_health.reset()
                ok_probe, srv, _d = cds_health.probe(force=True)
                if ok_probe:
                    QMessageBox.information(
                        self, "SIMBAD",
                        f"SIMBAD is reachable via {srv}. Try the lookup again.")
            return

        tbl = None
        for attempt in range(1, 3):
            try:
                custom = _new_simbad()
                tbl = custom.query_object(name)
                cds_health.note_success()
                break
            except Exception as e:
                print(f"[DEBUG] SIMBAD name resolve attempt {attempt} failed: {e}")
                if cds_health.note_failure(e, context="exoplanet/query_object"):
                    QMessageBox.critical(
                        self, "SIMBAD Unreachable",
                        "SIMBAD stopped answering while resolving that "
                        f"name.\n\n{type(e).__name__}: {e}\n\n"
                        "Further retries would only wait out the same "
                        "timeout, so this lookup was abandoned."
                    )
                    return
                if attempt == 2:
                    QMessageBox.critical(
                        self, "SIMBAD Error",
                        f"Could not resolve that name:\n{e}"
                    )
                    return
                non_blocking_sleep(1)
        if tbl is None or len(tbl) == 0:
            QMessageBox.information(
                self, "Not Found",
                f"SIMBAD didn't resolve “{name}”.\n"
                "Try a fuller catalog form (e.g. “V* V336 Aps”, “TYC 9256-617-1”)."
            )
            return

        try:
            ra_col  = next(c for c in tbl.colnames if c.lower() == "ra")
            dec_col = next(c for c in tbl.colnames if c.lower() == "dec")
        except StopIteration:
            QMessageBox.warning(self, "Find Star", "SIMBAD response missing RA/Dec columns.")
            return
        try:
            ra_deg  = float(tbl[0][ra_col])
            dec_deg = float(tbl[0][dec_col])
        except (TypeError, ValueError):
            # Older astroquery returns sexagesimal strings
            try:
                sc = SkyCoord(str(tbl[0][ra_col]), str(tbl[0][dec_col]),
                              unit=(u.hourangle, u.deg), frame="icrs")
                ra_deg  = float(sc.ra.deg)
                dec_deg = float(sc.dec.deg)
            except Exception as e:
                QMessageBox.warning(self, "Find Star",
                                    f"Couldn't parse RA/Dec from SIMBAD response:\n{e}")
                return

        # 2) sky -> detector pixel coordinates
        sky = SkyCoord(ra=ra_deg*u.deg, dec=dec_deg*u.deg, frame="icrs")
        try:
            xw, yw = self._wcs.world_to_pixel(sky)
            xw = float(xw); yw = float(yw)
        except Exception as e:
            QMessageBox.warning(self, "Find Star", f"WCS reverse projection failed:\n{e}")
            return

        bin_factor = getattr(self, "_wcs_bin_factor", 1) or 1
        xd = xw / bin_factor
        yd = yw / bin_factor

        # 3) find nearest detected star
        xs = np.array([p[0] for p in self.star_positions], dtype=float)
        ys = np.array([p[1] for p in self.star_positions], dtype=float)
        d = np.hypot(xs - xd, ys - yd)
        i_near = int(np.argmin(d))
        d_near = float(d[i_near])

        # tolerance: max(2·median FWHM in detector px, 10″/px converted, 6px floor)
        tol_px = max(2.0 * float(self.median_fwhm or 3.0), 6.0)
        try:
            from astropy.wcs.utils import proj_plane_pixel_scales
            scales = proj_plane_pixel_scales(self._wcs) * 3600.0  # deg -> arcsec
            px_scale = float(np.mean(scales)) / float(bin_factor)
            if px_scale > 0:
                tol_px = max(tol_px, 10.0 / px_scale)
        except Exception:
            pass

        if d_near > tol_px:
            QMessageBox.information(
                self, "Find Star",
                f"“{name}” resolves to RA/Dec ({ra_deg:.6f}, {dec_deg:.6f})\n"
                f"= detector pixel ({xd:.1f}, {yd:.1f}), but the closest\n"
                f"detected star (#{i_near}) is {d_near:.1f} px away — beyond\n"
                f"the {tol_px:.1f} px tolerance.\n\n"
                "The star may have been rejected by SEP (too faint / near\n"
                "the border) or the frame doesn't cover it."
            )
            return

        # 4) single-select the matching list item and scroll into view
        for row in range(self.star_list.count()):
            it = self.star_list.item(row)
            if int(it.data(Qt.ItemDataRole.UserRole)) == i_near:
                self.star_list.clearSelection()
                self.star_list.setCurrentItem(it)
                self.star_list.scrollToItem(
                    it, QAbstractItemView.ScrollHint.PositionAtCenter
                )
                break

    def _query_simbad_main_id(self):
        """Kept for API compatibility (called by export_to_aavso).  Now
        thin — the real work is in _resolve_target_name_row."""
        radec = self.get_selected_star_radec()
        if radec is None:
            return None
        hit = self._resolve_target_name_row(radec[0], radec[1], radius_arcsec=15.0)
        if hit is None:
            return None
        return hit["main_id"]

    def _query_simbad_name_and_vmag(self, ra_deg, dec_deg, radius=5*u.arcsec):
        coord = SkyCoord(ra=ra_deg*u.deg, dec=dec_deg*u.deg, frame="icrs")
        table = None

        # Called from the AAVSO export path, where SIMBAD only supplies a
        # suggested STARID and V magnitude -- both of which the user can
        # type. Returning (None, None) quickly leaves the export usable;
        # freezing for minutes does not. So no modal error dialog here on
        # an outage: the caller already prompts for the name.
        if not cds_health.simbad_available():
            print(f"[DEBUG] SIMBAD skipped for name/vmag — {cds_health.status_text()}")
            return None, None

        for attempt in range(1, 3):
            try:
                custom = _new_simbad()
                custom.add_votable_fields("otype","flux(V)")
                table = custom.query_region(coord, radius=radius)
                cds_health.note_success()
                break
            except Exception as e:
                if cds_health.note_failure(e, context="exoplanet/name_and_vmag"):
                    print(f"[DEBUG] SIMBAD unreachable during name/vmag: {e}")
                    return None, None
                if attempt == 2:
                    print(f"[DEBUG] SIMBAD name/vmag failed: {e}")
                    return None, None
                non_blocking_sleep(1)


        if table is None or len(table)==0:
            return None, None
        try:
            id_col = next(c for c in table.colnames if c.lower()=="main_id")
        except StopIteration:
            return None, None
        raw_id = table[0][id_col]
        if isinstance(raw_id, bytes):
            raw_id = raw_id.decode()
        v_col = next((c for c in table.colnames if c.upper() in ("FLUX_V","V")), None)
        vmag = None
        if v_col:
            try:
                v = float(table[0][v_col])
                if np.isfinite(v): vmag = v
            except Exception:
                vmag = None
        return raw_id, vmag

    # ---------------- Export ----------------

    def export_data(self):
        if self.fluxes is None or self.times is None:
            QMessageBox.warning(self, "Export", "No photometry to export. Run Measure & Photometry first.")
            return
        wcs = self._wcs
        if wcs is None:
            QMessageBox.warning(self, "Export", "No WCS available. Run plate solve during photometry first.")
            return

        dlg = QFileDialog(self, "Export Light Curves")
        dlg.setAcceptMode(QFileDialog.AcceptMode.AcceptSave)
        dlg.setNameFilters(["CSV files (*.csv)", "FITS files (*.fits)"])
        if not dlg.exec():
            return
        path = dlg.selectedFiles()[0]
        fmt  = dlg.selectedNameFilter()

        times_mjd = self.times.mjd
        n_stars   = self.fluxes.shape[0]

        xs = np.array([xy[0] for xy in self.star_positions])
        ys = np.array([xy[1] for xy in self.star_positions])
        bin_factor = getattr(self, "_wcs_bin_factor", 1)
        sky = wcs.pixel_to_world(xs * bin_factor, ys * bin_factor)

        ras = sky.ra.deg
        decs = sky.dec.deg

        if fmt.startswith("CSV") or path.lower().endswith(".csv"):
            df = pd.DataFrame({"MJD": times_mjd})
            for i in range(n_stars):
                df[f"STAR_{i}"]     = self.fluxes[i]
                df[f"FLAG_{i}"]     = self.flags[i]
                df[f"STAR_{i}_RA"]  = ras[i]
                df[f"STAR_{i}_DEC"] = decs[i]
            df.to_csv(path, index=False)
            QMessageBox.information(self, "Export CSV", f"Wrote CSV →\n{path}")
            return

        hdr_out = fits.Header()
        orig_hdr = None
        if hasattr(self, "_cached_headers") and 0 <= self.ref_idx < len(self._cached_headers):
            orig_hdr = self._cached_headers[self.ref_idx]
        if isinstance(orig_hdr, fits.Header):
            for key in ("OBJECT","TELESCOP","INSTRUME","OBSERVER",
                        "DATE-OBS","EXPTIME","FILTER",
                        "CRVAL1","CRVAL2","CRPIX1","CRPIX2",
                        "CDELT1","CDELT2","CTYPE1","CTYPE2"):
                if key in orig_hdr:
                    hdr_out[key] = orig_hdr[key]
        elif isinstance(orig_hdr, dict):
            for key in ("OBJECT","TELESCOP","INSTRUME","DATE-OBS","EXPTIME","FILTER"):
                val = orig_hdr.get(key, [{}])[0].get("value")
                if val is not None:
                    hdr_out[key] = val

        hdr_out["SEPTHR"]  = (self.sep_threshold,   "SEP detection threshold (sigma)")
        hdr_out["BFRAC"]   = (self.border_fraction, "Border ignore fraction")
        hdr_out["REFIDX"]  = (self.ref_idx,         "Reference frame index")
        hdr_out["MEDFWHM"] = (self.median_fwhm,     "Median FWHM of reference")
        hdr_out.add_history("Exported by Seti Astro Suite")

        cols = [fits.Column(name="MJD", format="D", array=times_mjd)]
        for i in range(n_stars):
            cols.append(fits.Column(name=f"STAR_{i}", format="E", array=self.fluxes[i]))
            cols.append(fits.Column(name=f"FLAG_{i}", format="I", array=self.flags[i]))
        lc_hdu = fits.BinTableHDU.from_columns(cols, header=hdr_out, name="LIGHTCURVE")

        star_idx = np.arange(n_stars, dtype=int)
        cols2 = [
            fits.Column(name="INDEX", format="I", array=star_idx),
            fits.Column(name="X",     format="E", array=xs),
            fits.Column(name="Y",     format="E", array=ys),
            fits.Column(name="RA",    format="D", array=ras),
            fits.Column(name="DEC",   format="D", array=decs),
        ]
        stars_hdu = fits.BinTableHDU.from_columns(cols2, name="STARS")

        primary = fits.PrimaryHDU(header=hdr_out)
        hdul    = fits.HDUList([primary, lc_hdu, stars_hdu])
        hdul.writeto(path, overwrite=True)
        QMessageBox.information(self, "Export FITS", f"Wrote FITS →\n{path}")

    def estimate_airmass_from_altitude(self, alt_deg):
        alt_rad = np.deg2rad(np.clip(alt_deg, 0.1, 90.0))
        return 1.0 / np.sin(alt_rad)

    # ------------------------------------------------------------------
    # Per-channel (R/G/B) supplementary aperture photometry for OSC inputs
    # ------------------------------------------------------------------
    def _run_multiband_photometry(self, xs, ys, keep_mask=None):
        """Second-pass aperture photometry, done per channel on color inputs.

        Uses the SAME star positions and a single global aperture derived
        from self.median_fwhm (per-star aperture variation is small and
        multi-band photometry is about capturing color, not aperture
        optimization).  Sets self.raw_flux_rgb / self.raw_flux_err_rgb
        shaped (3, n_stars, n_frames).  For mono inputs, or if anything
        fails, both attributes are set to None and the exporter falls
        through to the existing single-band path.
        """
        import sep
        from astropy.stats import sigma_clipped_stats

        self.raw_flux_rgb     = None
        self.raw_flux_err_rgb = None

        images = getattr(self, "_cached_images", None) or []
        if not images:
            return
        # Any frame with three planes counts as color for this dataset.
        is_color = any(getattr(im, "ndim", 2) == 3 and im.shape[2] >= 3 for im in images)
        if not is_color:
            return

        n_frames = len(images)
        # Use the SAME post-filter positions as self.star_positions.
        try:
            xs_a = np.asarray(xs, dtype=np.float64)
            ys_a = np.asarray(ys, dtype=np.float64)
        except Exception:
            return
        n_stars = int(xs_a.size)
        if n_stars <= 0:
            return

        fwhm = float(self.median_fwhm) if self.median_fwhm else 3.0
        fwhm = max(1.5, fwhm)
        r_ap  = float(max(2.5, 1.5 * fwhm))
        r_in  = float(max(r_ap + 1.0, 3.0 * fwhm))
        r_out = float(max(r_in + 2.0, 5.0 * fwhm))
        ap_area  = math.pi * r_ap * r_ap
        ann_area = math.pi * (r_out * r_out - r_in * r_in)

        raw_flux_rgb     = np.full((3, n_stars, n_frames), np.nan, dtype=np.float32)
        raw_flux_err_rgb = np.full((3, n_stars, n_frames), np.nan, dtype=np.float32)

        prev_status = self.status_label.text() if hasattr(self, "status_label") else ""
        try:
            if hasattr(self, "status_label"):
                self.status_label.setText("Per-channel photometry (R/G/B)…")
            if hasattr(self, "progress_bar"):
                self.progress_bar.setMaximum(n_frames)
                self.progress_bar.setValue(0)

            xs_c = np.ascontiguousarray(xs_a.astype(np.float64, copy=False))
            ys_c = np.ascontiguousarray(ys_a.astype(np.float64, copy=False))
            _mb_gain = self._photometry_gain()

            for t, img in enumerate(images):
                if img is None or getattr(img, "ndim", 2) != 3 or img.shape[2] < 3:
                    continue  # frame is mono in an otherwise-color set; leave NaN
                for c in range(3):
                    plane = np.ascontiguousarray(
                        np.asarray(img[..., c], dtype=np.float32, order="C")
                    )
                    try:
                        _, med, _ = sigma_clipped_stats(plane)
                        zeroed = plane - float(med)
                        bkg    = sep.Background(zeroed)
                        rmsmap = np.ascontiguousarray(bkg.rms().astype(np.float32, copy=False))
                        ds     = np.ascontiguousarray((zeroed - bkg.back()).astype(np.float32, copy=False))
                    except Exception:
                        continue

                    try:
                        f_ap, f_err, _ = sep.sum_circle(ds, xs_c, ys_c, r_ap,
                                                        err=rmsmap, gain=_mb_gain)
                        ann_flux, ann_err, _ = sep.sum_circann(ds, xs_c, ys_c, r_in, r_out,
                                                               err=rmsmap, gain=_mb_gain)
                    except Exception:
                        continue

                    sky_per_pix = ann_flux / max(ann_area, 1.0)
                    net = f_ap - sky_per_pix * ap_area
                    # variance = aperture_err^2 + sky_subtraction_err^2
                    sky_err_contrib = ann_err * (ap_area / max(ann_area, 1.0))
                    with np.errstate(invalid="ignore"):
                        err = np.sqrt(np.maximum(f_err ** 2 + sky_err_contrib ** 2, 0.0))

                    raw_flux_rgb[c, :, t]     = net.astype(np.float32, copy=False)
                    raw_flux_err_rgb[c, :, t] = err.astype(np.float32, copy=False)

                if hasattr(self, "progress_bar") and (t % 4 == 0 or t == n_frames - 1):
                    self.progress_bar.setValue(t + 1)
        finally:
            if hasattr(self, "status_label"):
                self.status_label.setText(prev_status or "Ready")

        # Only publish if at least ONE channel got a finite measurement
        # somewhere (guards against a broken color pass yielding all-NaN).
        if np.any(np.isfinite(raw_flux_rgb)):
            self.raw_flux_rgb     = raw_flux_rgb
            self.raw_flux_err_rgb = raw_flux_err_rgb

    # ------------------------------------------------------------------
    # Per-channel comparison-star catalog mags (extends the V-only helper).
    # Returns {member_index: {"V": float|None, "B": float|None, "R": float|None,
    #                         "R_is_sloan": bool, "source": str}}
    # ------------------------------------------------------------------
    def _catalog_bvr_mags_for_members(self, members, wcs):
        """Fetch Johnson B, V and an R-band anchor (Cousins Rc if available,
        else Sloan r') for as many ensemble members as possible.  Same
        3-tier resolution as _catalog_vmags_for_members: MagTool cache →
        APASS DR9 → UCAC4.  R_is_sloan flags when the R value is really
        Sloan r' (for AAVSO NOTES honesty)."""
        import numpy as _np
        out = {}
        members = [int(m) for m in members if 0 <= int(m) < len(self.star_positions)]
        if not members:
            return out
        try:
            from astropy.coordinates import SkyCoord
            import astropy.units as u
        except Exception:
            return out

        bf = getattr(self, "_wcs_bin_factor", 1)
        mras, mdecs, mkeys = [], [], []
        for m in members:
            try:
                x, y = self.star_positions[m]
                sky = wcs.pixel_to_world(x * bf, y * bf)
                mras.append(float(sky.ra.deg))
                mdecs.append(float(sky.dec.deg))
                mkeys.append(m)
            except Exception:
                continue
        if not mkeys:
            return out
        member_sc = SkyCoord(_np.asarray(mras) * u.deg, _np.asarray(mdecs) * u.deg)
        TOL = 3.0 * u.arcsec

        def _to_float_nan(arr):
            try:
                mm = _np.ma.masked_invalid(_np.ma.asarray(arr, dtype=float))
                return _np.ma.filled(mm, _np.nan)
            except Exception:
                return _np.array([_np.nan if v is None else float(v) for v in arr],
                                 dtype=float)

        def _apply_catalog(cat_ra, cat_dec, cat_v, cat_b, cat_r, r_is_sloan, source):
            cra = _to_float_nan(cat_ra); cde = _to_float_nan(cat_dec)
            cv  = _to_float_nan(cat_v);  cb  = _to_float_nan(cat_b); cr = _to_float_nan(cat_r)
            good = _np.isfinite(cra) & _np.isfinite(cde) & (
                _np.isfinite(cv) | _np.isfinite(cb) | _np.isfinite(cr)
            )
            if not _np.any(good):
                return
            cat_sc = SkyCoord(cra[good] * u.deg, cde[good] * u.deg)
            cv, cb, cr = cv[good], cb[good], cr[good]
            todo = [i for i, m in enumerate(mkeys) if m not in out]
            if not todo:
                return
            try:
                idx_cat, sep2d, _ = member_sc[todo].match_to_catalog_sky(cat_sc)
            except Exception:
                return
            for t, ic, sp in zip(todo, _np.atleast_1d(idx_cat), _np.atleast_1d(sep2d)):
                if sp <= TOL:
                    i = int(ic)
                    entry = {
                        "V": (float(cv[i]) if _np.isfinite(cv[i]) else None),
                        "B": (float(cb[i]) if _np.isfinite(cb[i]) else None),
                        "R": (float(cr[i]) if _np.isfinite(cr[i]) else None),
                        "R_is_sloan": bool(r_is_sloan),
                        "source": source,
                    }
                    # Only accept if at least one of V/B/R survived
                    if entry["V"] is not None or entry["B"] is not None or entry["R"] is not None:
                        out[mkeys[t]] = entry

        # 1) Magnitude tool's cached catalog (no network) — expect V (± B/R)
        try:
            from setiastro.saspro.plate_solver import _active_doc_from_parent
            doc = _active_doc_from_parent(self.parent())
            meta = getattr(doc, "metadata", {}) or {}
            cat = meta.get("SFCC_star_list") or []
            if cat:
                _apply_catalog(
                    [c.get("ra") for c in cat],
                    [c.get("dec") for c in cat],
                    [c.get("Vmag") for c in cat],
                    [c.get("Bmag") for c in cat],
                    [c.get("Rmag") for c in cat],
                    r_is_sloan=False, source="MagTool",
                )
        except Exception:
            pass

        def _cone():
            c0 = SkyCoord(_np.mean(mras) * u.deg, _np.mean(mdecs) * u.deg)
            rad = c0.separation(member_sc).max() * 1.15 + 30 * u.arcsec
            return c0, rad

        # 2) APASS DR9 — Vmag, Bmag, r'mag (Sloan) → R proxy
        if any(m not in out for m in mkeys):
            try:
                from astroquery.vizier import Vizier
                c0, rad = _cone()
                vz = _new_vizier(columns=["RAJ2000", "DEJ2000", "Vmag", "Bmag", "r_mag", "r\'mag"],
                                 row_limit=50000)
                res = vz.query_region(c0, radius=rad, catalog="II/336/apass9")
                if res:
                    tbl = res[0]
                    # APASS r'-band column is spelled differently across astroquery
                    # versions ("r_mag", "r'mag", or "rmag") — try each.
                    r_col = None
                    for cand in ("r_mag", "r'mag", "rmag", "rpmag"):
                        if cand in tbl.colnames:
                            r_col = cand; break
                    rvals = tbl[r_col] if r_col else [None] * len(tbl)
                    _apply_catalog(
                        tbl["RAJ2000"], tbl["DEJ2000"],
                        tbl["Vmag"], tbl["Bmag"], rvals,
                        r_is_sloan=True, source="APASS9",
                    )
            except Exception:
                pass

        # 3) UCAC4 — Vmag (APASS-derived), Bmag, rmag (Sloan) → R proxy
        if any(m not in out for m in mkeys):
            try:
                from astroquery.vizier import Vizier
                c0, rad = _cone()
                vz = _new_vizier(columns=["RAJ2000", "DEJ2000", "Vmag", "Bmag", "rmag"],
                                 row_limit=50000)
                res = vz.query_region(c0, radius=rad, catalog="I/322A/out")
                if res:
                    tbl = res[0]
                    r_col = "rmag" if "rmag" in tbl.colnames else None
                    rvals = tbl[r_col] if r_col else [None] * len(tbl)
                    _apply_catalog(
                        tbl["RAJ2000"], tbl["DEJ2000"],
                        tbl["Vmag"], tbl["Bmag"], rvals,
                        r_is_sloan=True, source="UCAC4",
                    )
            except Exception:
                pass

        return out

    # ------------------------------------------------------------------
    # Multi-band AAVSO export path (TB + TG + TR interleaved in one file).
    # ------------------------------------------------------------------
    def _export_aavso_multiband(self, idx):
        """AAVSO Extended export using per-channel raw fluxes.  Reuses
        photometry_aavso.build_rgb_rows + format_aavso_extended for the
        row/file plumbing so both tools stay in sync.  Falls back to
        single-comparison calibration on a per-channel basis when the
        catalog can't cover that band."""
        wcs = self._wcs
        if wcs is None:
            QMessageBox.warning(self, "Export AAVSO", "No WCS available.")
            return
        if self.raw_flux_rgb is None or self.raw_flux_err_rgb is None:
            QMessageBox.warning(self, "Export AAVSO",
                                "No per-channel photometry available.")
            return

        # -- STARID ---------------------------------------------------------
        star_id = self._query_simbad_main_id()
        # Resolve the VSX designation by COORDINATE, not by name. VSX has
        # no reverse index on a tagged SIMBAD id ("V* V336 Aps") or on a
        # Gaia DR3 number, which between them cover most targets -- so the
        # old query_object() call returned nothing and the unusable SIMBAD
        # spelling went into the file. Whatever we settle on is stripped of
        # its object-type tag, because AAVSO rejects a STARID carrying one.
        _radec_for_id = self.get_selected_star_radec()
        _vsx_id = None
        if _radec_for_id is not None:
            try:
                _c_for_id = SkyCoord(ra=_radec_for_id[0] * u.deg,
                                     dec=_radec_for_id[1] * u.deg,
                                     frame="icrs")
                _vsx_id = self._vsx_name_near(_c_for_id, 15.0)
            except Exception as e:
                print(f"[DEBUG] VSX coordinate lookup failed: {e}")
        star_id = _aavso_starid(_vsx_id or star_id or "")
        star_id, ok = QInputDialog.getText(
            self, "Target Star Name",
            "AAVSO STARID for this target:",
            QLineEdit.EchoMode.Normal, star_id or ""
        )
        if not ok or not star_id.strip():
            return
        star_id = star_id.strip()

        # -- Observer code + systematic floor -------------------------------
        settings = QSettings()
        prev_code = settings.value("AAVSO/observer_code", "", type=str)
        code, ok = QInputDialog.getText(
            self, "Observer Code", "Enter your AAVSO observer code:",
            QLineEdit.EchoMode.Normal, prev_code
        )
        if not ok:
            return
        code = code.strip().upper()
        settings.setValue("AAVSO/observer_code", code)

        prev_floor = float(settings.value("AAVSO/sys_floor_mag", 0.10, type=float))
        sys_floor, ok = QInputDialog.getDouble(
            self, "Systematic Floor",
            "Systematic error floor (mag) added in quadrature to MERR.\n"
            "  0.10 = defensive default;  0.05 ≈ PixInsight;  0.00 disables.",
            value=prev_floor, min=0.00, max=0.30, decimals=3
        )
        if not ok:
            return
        settings.setValue("AAVSO/sys_floor_mag", sys_floor)

        # -- Ensemble members & check star ---------------------------------
        raw_members = self.ensemble_map.get(idx, [])
        members     = [m for m in raw_members if 0 <= m < len(self.star_positions)]

        # Check star: auto-identify from the ensemble (first with SIMBAD V).
        kname = None; k_idx = None; kstar_catalog = None
        for m in members:
            x, y = self.star_positions[m]
            bf = getattr(self, "_wcs_bin_factor", 1)
            sky = wcs.pixel_to_world(x * bf, y * bf)
            name, v = self._query_simbad_name_and_vmag(sky.ra.deg, sky.dec.deg)
            if name and (v is not None) and np.isfinite(v):
                kname, k_idx = _aavso_starid(name), m
                kstar_catalog = {"Vmag": float(v), "Bmag": None, "Rmag": None}
                break
        if kname is None:
            kname, ok = QInputDialog.getText(
                self, "Check Star Name",
                "Could not auto-identify a check star. Enter check-star ID:"
            )
            if not ok or not kname.strip():
                return
            kname = kname.strip()
            k_idx, ok = QInputDialog.getInt(
                self, "Check Star",
                "Enter the list index (#) of the check star used for calibration:",
                0, 0, max(0, len(self.star_positions) - 1)
            )
            if not ok:
                return
            kstar_catalog = {"Vmag": None, "Bmag": None, "Rmag": None}

        # Per-channel KMAGs: use catalog for check star, then fill missing.
        kmags = aav.check_star_kmags(kstar_catalog)   # {"R":..,"G":..,"B":..}
        #sasprompt default = V-mag when we have it. Better than 0 (which
        # gives MAG=0-ish outputs if the user hits OK without editing —
        # David saw exactly this on TB/TR for V336 Aps). For most stars
        # V is within a magnitude or so of B and R, so if the user
        # doesn't know the exact value, V is a defensible fallback.
        for ch, prompt_label in (("B", "B"), ("G", "V (green anchor)"), ("R", "R")):
            if kmags.get(ch) is None:
                _v_default = float(kmags.get("G") or 0.0)
                _has_v_hint = kmags.get("G") is not None
                _hint = (
                    f"\n\nDefaulted to V-mag ({_v_default:.3f}) as a plausible"
                    f"\nfallback. Edit for accuracy or Cancel to skip this band."
                    if _has_v_hint else
                    "\n\nCancel to skip this band."
                )
                val, ok = QInputDialog.getDouble(
                    self, f"Check-Star {prompt_label} Magnitude",
                    f"Catalog {prompt_label} magnitude for {kname}\n"
                    f"(needed to calibrate the {aav.RGB_FILTER_MAP[ch][0]} channel)."
                    f"{_hint}",
                    value=(kmags.get("G") if kmags.get("G") is not None else 0.0),
                    min=-5.0, max=30.0, decimals=3
                )
                if ok:
                    kmags[ch] = float(val)
                else:
                    kmags[ch] = None

        # -- File path -----------------------------------------------------
        path, _ = QFileDialog.getSaveFileName(
            self, "Save AAVSO File (multi-band)", "",
            "Text files (*.txt *.dat *.csv)"
        )
        if not path:
            return

        # -- Per-channel ensemble ZP or single-comparison fallback ---------
        # Broadened comp pool: every detected star EXCEPT the target,
        # the check star, and anything flagged as variable / dip. This
        # is David0944's msg-6 suggestion — the tight ensemble_map[idx]
        # (nearest-flux neighbors, K≈8) is too small to reliably clear
        # the ≥3-catalog-mag bar for the ensemble tier. A bigger pool
        # gets us more comps with catalog mags; MAD clipping downstream
        # still removes outliers.
        _all_indices = list(range(len(self.star_positions)))
        _flagged     = getattr(self, "flagged_stars", None) or set()
        comp_members = [m for m in _all_indices
                        if m != idx and m != k_idx and m not in _flagged]
        cmap = self._catalog_bvr_mags_for_members(comp_members, wcs)

        LOGC = 2.5 / np.log(10.0)
        floor = float(sys_floor or 0.0)
        n_frames = int(self.raw_flux_rgb.shape[2])
        jd = self.times.utc.jd

        # For each channel produce (mags[n_frames], merr[n_frames], notes).
        # RGB_FILTER_MAP: R→("TR","R"), G→("TG","V"), B→("TB","B")
        per_ch = {}
        used_comps = set()   # comp indices that actually formed the ensemble/comparison
        r_note_extra = ""
        # Detect if any comp's R is Sloan-derived; a single flag on the note
        # is honest enough for AAVSO's NOTES field.
        if any(v.get("R") is not None and v.get("R_is_sloan") for v in cmap.values()):
            r_note_extra = "; R anchor = Sloan r' (APASS/UCAC)"

        for ch in ("B", "G", "R"):
            filt, band_key = aav.RGB_FILTER_MAP[ch]
            ci = {"R": 0, "G": 1, "B": 2}[ch]     # numpy channel index
            F_T    = self.raw_flux_rgb[ci, idx, :].astype(np.float64)
            Ferr_T = self.raw_flux_err_rgb[ci, idx, :].astype(np.float64)

            comp_idx_all = np.array(
                [m for m in comp_members if m in cmap and cmap[m].get(band_key) is not None],
                dtype=int
            )
            comp_mag = np.array(
                [cmap[m][band_key] for m in comp_idx_all], dtype=float
            )

            if comp_idx_all.size >= 3:
                Fi  = self.raw_flux_rgb[ci, comp_idx_all, :].astype(np.float64)
                okF = np.isfinite(Fi) & (Fi > 0)
                zi  = np.where(okF,
                               comp_mag[:, None] + 2.5 * np.log10(np.where(okF, Fi, 1.0)),
                               np.nan)
                # robust MAD-based sigma-clip stars on run-median ZP.
                # std is inflated by the outliers we're trying to catch;
                # MAD isn't, so a comp star with a wrong catalog mag now
                # actually gets clipped instead of masquerading as normal
                # scatter. Floor sigma at 0.05 mag so tight ensembles
                # don't over-clip themselves down to one star.
                z_star = np.nanmedian(zi, axis=1)
                keepC  = np.isfinite(z_star)
                for _ in range(3):
                    if not np.any(keepC):
                        break
                    med  = np.nanmedian(z_star[keepC])
                    mad  = np.nanmedian(np.abs(z_star[keepC] - med))
                    sd_r = max(1.4826 * float(mad), 0.05)
                    if not np.isfinite(sd_r) or sd_r == 0:
                        break
                    prev_keep = keepC.copy()
                    keepC &= np.abs(z_star - med) <= 3.0 * sd_r
                    if np.array_equal(keepC, prev_keep):
                        break  # converged; no point re-computing MAD
                zi = zi[keepC, :]
                ZP_t  = np.nanmedian(zi, axis=0)
                n_t   = np.sum(np.isfinite(zi), axis=0)
                madz  = np.nanmedian(np.abs(zi - ZP_t[None, :]), axis=0)
                SEM_t = np.where(n_t > 1, 1.4826 * madz / np.sqrt(np.maximum(n_t, 1)), np.nan)
                with np.errstate(divide="ignore", invalid="ignore"):
                    mags = -2.5 * np.log10(F_T) + ZP_t
                    merr = np.sqrt((LOGC * Ferr_T / F_T) ** 2
                                   + np.nan_to_num(SEM_t) ** 2 + floor ** 2)
                bad = ~np.isfinite(mags) | (F_T <= 0) | (n_t < 1)
                n_ens = int(np.count_nonzero(keepC))
                note = (f"{filt}: ensemble ZP N={n_ens} vs catalog {band_key}"
                        f"; err incl SEM+{floor:.2f}floor")
                if ch == "R" and r_note_extra:
                    note += r_note_extra
                # AAVSO ENSEMBLE requires a check star, and for ensemble the
                # KMAG field is that star's magnitude standardised through the
                # SAME ensemble ZP (not its catalog value, not a raw
                # instrumental mag). Compute K exactly like the target so a data
                # user can diff it against the catalog value as a quality check.
                used_comps.update(int(m) for m in comp_idx_all[keepC])
                F_K = self.raw_flux_rgb[ci, k_idx, :].astype(np.float64)
                with np.errstate(divide="ignore", invalid="ignore"):
                    _K = -2.5 * np.log10(F_K) + ZP_t
                _K = _K[np.isfinite(_K)]
                cname_ch = "ENSEMBLE"
                cmag_ch  = "na"
                kname_ch = kname
                kmag_ch  = float(np.median(_K)) if _K.size else "na"
            elif comp_idx_all.size >= 1:
                # tier 2: single-comparison vs a comp-member with catalog mag
                # in this band. Prefer the brightest (highest median flux) —
                # best SNR, most stable ZP anchor. This tier exists because
                # the previous code fell straight through to the check star,
                # which is the wrong role for photometric anchoring AND is
                # empty in the ensemble=1 case where the sole ensemble
                # member is also the check star.
                _c_meds = np.array(
                    [np.nanmedian(self.raw_flux_rgb[ci, int(mm), :])
                     for mm in comp_idx_all], dtype=float
                )
                _c_local = int(np.argmax(np.nan_to_num(_c_meds, nan=-np.inf)))
                c_idx = int(comp_idx_all[_c_local])
                c_mag = float(comp_mag[_c_local])
                F_C    = self.raw_flux_rgb[ci, c_idx, :].astype(np.float64)
                Ferr_C = self.raw_flux_err_rgb[ci, c_idx, :].astype(np.float64)
                with np.errstate(divide="ignore", invalid="ignore"):
                    mags  = c_mag - 2.5 * np.log10(F_T / F_C)
                    frac2 = (Ferr_T / F_T) ** 2 + (Ferr_C / F_C) ** 2
                    merr  = np.sqrt((LOGC ** 2) * frac2 + floor ** 2)
                bad = ~np.isfinite(mags) | (F_T <= 0) | (F_C <= 0)
                note = (f"{filt}: single-comparison vs member #{c_idx} "
                        f"({band_key}={c_mag:.3f}); err incl {floor:.2f}floor"
                        f"; ensemble not used: {comp_idx_all.size} of "
                        f"{len(comp_members)} field stars had a catalog "
                        f"{band_key} (need 3)")
                if ch == "R" and r_note_extra:
                    note += r_note_extra
                # NOT an ensemble: classic differential photometry, so CNAME is
                # the comparison and CMAG/KMAG are raw INSTRUMENTAL mags (target
                # standardised to the comp's catalog mag). Keep the independent
                # check star in KNAME/KMAG.
                used_comps.add(int(c_idx))
                F_K = self.raw_flux_rgb[ci, k_idx, :].astype(np.float64)
                _fc = float(np.nanmedian(F_C[F_C > 0])) if np.any(F_C > 0) else np.nan
                _fk = float(np.nanmedian(F_K[F_K > 0])) if np.any(F_K > 0) else np.nan
                cname_ch = f"C{int(c_idx)}"
                cmag_ch  = float(-2.5 * np.log10(_fc)) if np.isfinite(_fc) else "na"
                kname_ch = kname
                kmag_ch  = float(-2.5 * np.log10(_fk)) if np.isfinite(_fk) else "na"
            elif kmags.get(ch) is not None:
                # tier 3 (last resort): calibrate against the CHECK STAR
                # itself. Only lands here when zero comp-members have a
                # catalog mag in this band. Not ideal (the check star is
                # meant for verification, not anchoring) but better than
                # skipping the band entirely.
                F_C    = self.raw_flux_rgb[ci, k_idx, :].astype(np.float64)
                Ferr_C = self.raw_flux_err_rgb[ci, k_idx, :].astype(np.float64)
                with np.errstate(divide="ignore", invalid="ignore"):
                    mags  = kmags[ch] - 2.5 * np.log10(F_T / F_C)
                    frac2 = (Ferr_T / F_T) ** 2 + (Ferr_C / F_C) ** 2
                    merr  = np.sqrt((LOGC ** 2) * frac2 + floor ** 2)
                bad = ~np.isfinite(mags) | (F_T <= 0) | (F_C <= 0)
                note = (f"{filt}: check-star fallback vs {kname}"
                        f"; err incl {floor:.2f}floor"
                        f"; no field star had a catalog {band_key} "
                        f"({len(comp_members)} tried)")
                # The check star is doing double duty as the comparison
                # here, so it belongs in the comps[RA/Dec] provenance --
                # otherwise that line comes out empty and the submission
                # records nothing about what set the zero point.
                used_comps.add(int(k_idx))
                # Degenerate: the check star is doubling as the comparison, so
                # it can't also be an independent check — CNAME=check with its
                # instrumental CMAG, and KNAME/KMAG left as na.
                _fc = float(np.nanmedian(F_C[F_C > 0])) if np.any(F_C > 0) else np.nan
                cname_ch = str(kname)
                cmag_ch  = float(-2.5 * np.log10(_fc)) if np.isfinite(_fc) else "na"
                kname_ch = "na"
                kmag_ch  = "na"
            else:
                # Nothing to calibrate this channel — skip it.
                per_ch[ch] = None
                continue

            mags = np.where(bad, np.nan, mags)
            merr = np.where(bad | ~np.isfinite(merr), np.nan, merr)
            per_ch[ch] = (mags, merr, note, cname_ch, cmag_ch, kname_ch, kmag_ch)

        if not any(v is not None for v in per_ch.values()):
            QMessageBox.warning(
                self, "Export AAVSO",
                "None of the R/G/B channels could be calibrated — no catalog\n"
                "comparison stars and no check-star magnitude for any band."
            )
            return

        # AAVSO asks that the comps forming an ensemble be identified in NOTES.
        # We have no AUIDs for arbitrary field stars, so list their RA/Dec (ICRS
        # deg) — enough for a data user to recover which stars set the zero
        # point. Capped so a large ensemble doesn't blow past NOTES length.
        def _radec_label(mi):
            try:
                x, y = self.star_positions[int(mi)]
                bf = getattr(self, "_wcs_bin_factor", 1)
                sky = wcs.pixel_to_world(x * bf, y * bf)
                return f"{sky.ra.deg:.4f}{sky.dec.deg:+.4f}"
            except Exception:
                return None
        _ids = [s for s in (_radec_label(m) for m in sorted(used_comps)) if s]
        _MAX_IDS = 10
        if not _ids:
            comps_note = ""
        elif len(_ids) > _MAX_IDS:
            comps_note = ("comps[RA/Dec]: " + ", ".join(_ids[:_MAX_IDS])
                          + f", +{len(_ids) - _MAX_IDS} more")
        else:
            comps_note = "comps[RA/Dec]: " + ", ".join(_ids)

        # -- Assemble AavsoRow list frame-by-frame -------------------------
        # Track per-band skip reasons so the summary popup can tell the
        # user *why* certain bands didn't make it into the file. AAVSO
        # Extended Format requires MERR ≤ 1.0 — a single over-limit row
        # gets the whole file rejected at upload, so we drop them here.
        rows = []
        _skipped_by_filt = {}
        _na_by_filt      = {}
        _skip_reasons = set()
        _MERR_MAX = 1.0
        for j, t in enumerate(jd):
            frame_mags = {}; frame_merrs = {}
            frame_cnames = {}; frame_cmags = {}
            frame_knames = {}; frame_kmags = {}
            for ch in ("B", "G", "R"):
                pc = per_ch.get(ch)
                if pc is None:
                    continue
                filt_lbl = aav.RGB_FILTER_MAP[ch][0]
                m = float(pc[0][j]); e = float(pc[1][j])
                if not np.isfinite(m):
                    # No MAG to report — drop the row entirely.
                    _skipped_by_filt[filt_lbl] = _skipped_by_filt.get(filt_lbl, 0) + 1
                    _skip_reasons.add("non-finite MAG")
                    continue
                # Per-band comparison identity (tier-dependent: ENSEMBLE vs single).
                frame_cnames[ch] = pc[3]
                frame_cmags[ch]  = pc[4]
                frame_knames[ch] = pc[5]
                frame_kmags[ch]  = pc[6]
                if not np.isfinite(e) or e > _MERR_MAX:
                    # MAG is real but MERR is out of AAVSO range; emit
                    # the row with MERR=na (David msg-6 request) rather
                    # than dropping the observation.
                    _na_by_filt[filt_lbl] = _na_by_filt.get(filt_lbl, 0) + 1
                    frame_mags[ch]  = m
                    frame_merrs[ch] = None
                    continue
                frame_mags[ch]  = m
                frame_merrs[ch] = e
            if not frame_mags:
                continue
            am = float(np.clip(self.airmasses[j] if j < len(self.airmasses) else 1.0, 1.0, 40.0))
            # Per-frame notes: combine per-channel notes for the bands that
            # actually landed this frame, then append the comp identifiers once.
            note_bits = [per_ch[ch][2] for ch in ("B", "G", "R")
                         if per_ch.get(ch) is not None and ch in frame_mags]
            frame_note = " | ".join(note_bits)
            if comps_note:
                frame_note = f"{frame_note} || {comps_note}" if frame_note else comps_note
            new_rows = aav.build_rgb_rows(
                name=star_id, date_jd=float(t),
                mags=frame_mags, merrs=frame_merrs, amass=am,
                cnames=frame_cnames, cmags=frame_cmags,
                knames=frame_knames, kmags=frame_kmags,
                notes=frame_note,
            )
            rows.extend(new_rows)

        if not rows:
            QMessageBox.warning(
                self, "Export AAVSO",
                "No frames produced a finite calibrated magnitude in any band."
            )
            return

        # -- #RA / #DEC come from the selected star's WCS position ---------
        radec = self.get_selected_star_radec()
        if radec is None:
            QMessageBox.warning(self, "Export AAVSO",
                                "Could not determine RA/Dec of selected star.")
            return

        try:
            body = aav.format_aavso_extended(rows, obscode=code,
                                             ra_deg=radec[0], dec_deg=radec[1])
            with open(path, "w") as f:
                f.write(body)
        except Exception as e:
            QMessageBox.critical(self, "Export AAVSO", f"Failed to write file:\n{e}")
            return

        n_by_filt = {}
        for r in rows:
            n_by_filt[r.filt] = n_by_filt.get(r.filt, 0) + 1
        breakdown = ", ".join(f"{k}:{v}" for k, v in sorted(n_by_filt.items()))

        # summary of skipped-per-band (row dropped entirely — non-finite MAG)
        # and emitted-with-MERR=na (per David msg 6 — MAG kept, error unknown)
        _skip_lines = []
        if _skipped_by_filt:
            _skip_breakdown = ", ".join(
                f"{k}:{v}" for k, v in sorted(_skipped_by_filt.items())
            )
            _reason_txt = "; ".join(sorted(_skip_reasons)) if _skip_reasons else "invalid"
            _skip_lines.append(f"Skipped: {_skip_breakdown}  ({_reason_txt})")

        # summary of emitted-with-MERR=na (per David msg 6)
        if _na_by_filt:
            _na_breakdown = ", ".join(
                f"{k}:{v}" for k, v in sorted(_na_by_filt.items())
            )
            _skip_lines.append(
                f"MERR=na: {_na_breakdown}  (row kept but MERR exceeded {_MERR_MAX:.1f})"
            )

        _body = f"Wrote {len(rows)} row(s) → {path}\n\nBy filter: {breakdown}"
        for _ln in _skip_lines:
            _body += f"\n{_ln}"
        _body += "\n\nOpen AAVSO WebObs upload page now?"

        msg = QMessageBox(self)
        msg.setWindowTitle("Export AAVSO")
        msg.setText(_body)
        yes = msg.addButton("Yes", QMessageBox.ButtonRole.AcceptRole)
        msg.addButton("No", QMessageBox.ButtonRole.RejectRole)
        msg.exec()
        if msg.clickedButton() == yes:
            webbrowser.open("https://www.aavso.org/webobs/file")

    def _catalog_vmags_for_members(self, members, wcs):
        """Return {member_index: (Vmag, source)} for as many ensemble members as
        we can attach a Johnson V catalog magnitude to. Tries, in order:
          1) the Magnitude tool's cached catalog on the active doc
             (metadata["SFCC_star_list"]) -- real/anchored Johnson V
             (APASS / SIMBAD / Gaia-XP), so no network call when it's present;
          2) APASS DR9 (VizieR II/336/apass9) -- Johnson V directly;
          3) UCAC4 (VizieR I/322A/out) -- APASS-derived Johnson V.
        Matching is done in SKY coordinates, so it is valid even though the two
        tools may sit on different pixel grids. Never raises: on any failure a
        member is simply left unresolved and the caller falls back to the
        single check-star calibration.
        """
        import numpy as _np
        out = {}
        members = [int(m) for m in members if 0 <= int(m) < len(self.star_positions)]
        if not members:
            return out

        try:
            from astropy.coordinates import SkyCoord
            import astropy.units as u
        except Exception:
            return out

        # member sky coords (respect the detection bin factor, as elsewhere)
        bf = getattr(self, "_wcs_bin_factor", 1)
        mras, mdecs, mkeys = [], [], []
        for m in members:
            try:
                x, y = self.star_positions[m]
                sky = wcs.pixel_to_world(x * bf, y * bf)
                mras.append(float(sky.ra.deg)); mdecs.append(float(sky.dec.deg)); mkeys.append(m)
            except Exception:
                continue
        if not mkeys:
            return out
        member_sc = SkyCoord(_np.asarray(mras) * u.deg, _np.asarray(mdecs) * u.deg)
        TOL = 3.0 * u.arcsec

        def _to_float_nan(arr):
            try:
                mm = _np.ma.masked_invalid(_np.ma.asarray(arr, dtype=float))
                return _np.ma.filled(mm, _np.nan)
            except Exception:
                return _np.array([_np.nan if v is None else float(v) for v in arr], dtype=float)

        def _apply_catalog(cat_ra, cat_dec, cat_v, source):
            cra = _to_float_nan(cat_ra); cde = _to_float_nan(cat_dec); cvm = _to_float_nan(cat_v)
            good = _np.isfinite(cra) & _np.isfinite(cde) & _np.isfinite(cvm)
            if not _np.any(good):
                return
            cat_sc = SkyCoord(cra[good] * u.deg, cde[good] * u.deg)
            cvm = cvm[good]
            todo = [i for i, m in enumerate(mkeys) if m not in out]
            if not todo:
                return
            try:
                idx_cat, sep2d, _ = member_sc[todo].match_to_catalog_sky(cat_sc)
            except Exception:
                return
            for t, ic, sp in zip(todo, _np.atleast_1d(idx_cat), _np.atleast_1d(sep2d)):
                if sp <= TOL:
                    out[mkeys[t]] = (float(cvm[int(ic)]), source)

        # 1) Magnitude tool's cached catalog (no network)
        try:
            from setiastro.saspro.plate_solver import _active_doc_from_parent
            doc = _active_doc_from_parent(self.parent())
            meta = getattr(doc, "metadata", {}) or {}
            cat = meta.get("SFCC_star_list") or []
            if cat:
                _apply_catalog([c.get("ra") for c in cat],
                               [c.get("dec") for c in cat],
                               [c.get("Vmag") for c in cat], "MagTool")
        except Exception:
            pass

        def _cone():
            c0 = SkyCoord(_np.mean(mras) * u.deg, _np.mean(mdecs) * u.deg)
            rad = c0.separation(member_sc).max() * 1.15 + 30 * u.arcsec
            return c0, rad

        # 2) APASS DR9  then  3) UCAC4  -- only for members still unresolved
        for cat_id, source in (("II/336/apass9", "APASS9"), ("I/322A/out", "UCAC4")):
            if not any(m not in out for m in mkeys):
                break
            try:
                from astroquery.vizier import Vizier
                c0, rad = _cone()
                vz = _new_vizier(columns=["RAJ2000", "DEJ2000", "Vmag"],
                                 row_limit=50000)
                res = vz.query_region(c0, radius=rad, catalog=cat_id)
                if res:
                    tbl = res[0]
                    _apply_catalog(tbl["RAJ2000"], tbl["DEJ2000"], tbl["Vmag"], source)
            except Exception:
                pass

        return out

    def export_to_aavso(self):
        if getattr(self, "fluxes", None) is None or getattr(self, "times", None) is None:
            QMessageBox.warning(self, "Export AAVSO", "No photometry available. Run Measure & Photometry first.")
            return
        wcs = self._wcs
        if wcs is None:
            QMessageBox.warning(self, "Export AAVSO", "No WCS available. Plate-solve first.")
            return

        sels = self.star_list.selectedItems()
        if len(sels) != 1:
            QMessageBox.warning(self, "Export AAVSO", "Please select exactly one star before exporting.")
            return
        idx = sels[0].data(Qt.ItemDataRole.UserRole)

        # Offer a multi-band (TB+TG+TR) export when color photometry is on hand.
        if getattr(self, "raw_flux_rgb", None) is not None:
            reply = QMessageBox.question(
                self, "Multi-Band Export",
                "Color (R/G/B) photometry is available for this dataset.\n\n"
                "Export as multi-band AAVSO (TB + TG + TR)?\n"
                "  Yes  → one file with interleaved TB/TG/TR rows\n"
                "  No   → single-band export (choose one filter code)",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes
            )
            if reply == QMessageBox.StandardButton.Yes:
                return self._export_aavso_multiband(idx)

        star_id = self._query_simbad_main_id()
        # Resolve the VSX designation by COORDINATE, not by name. VSX has
        # no reverse index on a tagged SIMBAD id ("V* V336 Aps") or on a
        # Gaia DR3 number, which between them cover most targets -- so the
        # old query_object() call returned nothing and the unusable SIMBAD
        # spelling went into the file. Whatever we settle on is stripped of
        # its object-type tag, because AAVSO rejects a STARID carrying one.
        _radec_for_id = self.get_selected_star_radec()
        _vsx_id = None
        if _radec_for_id is not None:
            try:
                _c_for_id = SkyCoord(ra=_radec_for_id[0] * u.deg,
                                     dec=_radec_for_id[1] * u.deg,
                                     frame="icrs")
                _vsx_id = self._vsx_name_near(_c_for_id, 15.0)
            except Exception as e:
                print(f"[DEBUG] VSX coordinate lookup failed: {e}")
        star_id = _aavso_starid(_vsx_id or star_id or "")
        if not star_id:
            star_id, ok = QInputDialog.getText(self, "Target Star Name", "Could not auto-identify.  Enter target star name for STARID:", QLineEdit.EchoMode.Normal, "")
            if not ok or not star_id.strip():
                return
            star_id = star_id.strip()

        if not hasattr(self, "exposure_time") or self.exposure_time is None:
            exp, ok = QInputDialog.getDouble(self, "Exposure Time", "No EXPOSURE found in headers. Please enter exposure time (s):", decimals=1)
            if not ok: return
            self.exposure_time = exp

        settings = QSettings()
        prev_code = settings.value("AAVSO/observer_code", "", type=str)
        code, ok = QInputDialog.getText(self, "Observer Code", "Enter your AAVSO observer code:", QLineEdit.EchoMode.Normal, prev_code)
        if not ok: return
        code = code.strip().upper()
        settings.setValue("AAVSO/observer_code", code)

        fmt, ok = QInputDialog.getItem(self, "AAVSO Format", "Choose submission format:", ["Variable-Star Photometry", "Exoplanet Report"], 0, False)
        if not ok: return

        raw_members = self.ensemble_map.get(idx, [])
        members     = [m for m in raw_members if 0 <= m < len(self.star_positions)]
        kname = None; kmag = None; k_idx = None
        for m in members:
            x, y = self.star_positions[m]
            bin_factor = getattr(self, "_wcs_bin_factor", 1)
            sky = wcs.pixel_to_world(x * bin_factor, y * bin_factor)

            name, v = self._query_simbad_name_and_vmag(sky.ra.deg, sky.dec.deg)
            if name and (v is not None) and np.isfinite(v):
                kname, kmag, k_idx = _aavso_starid(name), v, m
                break
        if kname is None:
            kname, ok = QInputDialog.getText(self, "Check Star Name", "Could not auto-identify a check star. Enter check-star ID:")
            if not ok or not kname.strip(): return
            kname = kname.strip()
            kmag, ok = QInputDialog.getDouble(self, "Check Star Magnitude", f"Enter catalog magnitude for {kname}:", decimals=3)
            if not ok: return

        # Calibration needs the check star's MEASURED flux row. If it wasn't
        # auto-identified above, ask which list entry it is.
        if k_idx is None:
            k_idx, ok = QInputDialog.getInt(
                self, "Check Star",
                "Enter the list index (#) of the check star used for calibration:",
                0, 0, max(0, len(self.star_positions) - 1))
            if not ok:
                return

        # Full AAVSO Extended Format band table, grouped for readability.
        # Persist the last-used code so common workflows don't have to
        # re-scroll every export.
        filt_choices = [
            # Johnson–Cousins
            "V", "B", "U", "R", "I", "RC", "IC",
            # DSLR / OSC tri-color
            "TG", "TB", "TR", "TI",
            # Unfiltered CCD (reduced to a Johnson band)
            "CV", "CR", "CBB", "CM",
            # Sloan
            "SU", "SG", "SR", "SI", "SZ",
            # Near-IR / other
            "J", "H", "K", "Y", "ZS",
            # Narrowband / misc
            "HA", "HAC", "MA", "MI", "MB", "O",
        ]
        prev_filt   = settings.value("AAVSO/last_filter", "V", type=str)
        default_idx = filt_choices.index(prev_filt) if prev_filt in filt_choices else 0
        filt, ok = QInputDialog.getItem(
            self, "Filter",
            "Select AAVSO filter code for this dataset:\n"
            "  V/B/U/R/I — Johnson–Cousins\n"
            "  TG/TB/TR/TI — DSLR / OSC tri-color channels\n"
            "  CV/CR/CBB/CM — unfiltered CCD reduced to V/R\n"
            "  SU..SZ — Sloan; HA/HAC — H-alpha; J/H/K — near-IR",
            filt_choices, default_idx, False
        )
        if not ok: return
        settings.setValue("AAVSO/last_filter", filt)

        path, _ = QFileDialog.getSaveFileName(self, "Save AAVSO File", "", "Text files (*.txt *.dat *.csv)")
        if not path: return

        header_lines = [
            "#TYPE=EXTENDED",
            f"#OBSCODE={code}",
            f"#SOFTWARE=Seti Astro Suite Pro",
            "#DELIM=,",
            "#DATE=JD",
            "#OBSTYPE=CCD",
        ]
        radec = self.get_selected_star_radec()
        if radec is None:
            QMessageBox.warning(self, "Export AAVSO", "Could not determine RA/Dec of selected star.")
            return
        c = SkyCoord(ra=radec[0]*u.deg, dec=radec[1]*u.deg, frame="icrs")
        header_lines += [
            "#RA="  + c.ra.to_string(unit=u.hour, sep=":", pad=True, precision=2),
            "#DEC=" + c.dec.to_string(unit=u.degree, sep=":", pad=True, alwayssign=True, precision=1),
        ]
        header_lines.append("#NAME,DATE,MAG,MERR,FILT,TRANS,MTYPE,CNAME,CMAG,KNAME,KMAG,AMASS,GROUP,CHART,NOTES")

        jd = self.times.utc.jd

        # -- Calibrated magnitudes --------------------------------------------
        # Build a real PER-FRAME photometric zero point from the target's
        # ensemble comparison stars that carry catalog V magnitudes, exactly
        # like the Magnitude/Surface-Brightness tool:
        #     ZP(t)  = median_i( Vcat_i + 2.5*log10 F_i(t) )
        #     m_T(t) = -2.5*log10 F_T(t) + ZP(t)
        # Computing ZP per frame keeps it differential (transparency/airmass
        # cancel frame-to-frame), anchors it to Johnson V, and yields an honest
        # per-frame SEM. If too few comparison stars have catalog mags, fall
        # back to a single-comparison calibration against the check star.
        #
        # NOTE: untransformed V (no color term) -- each comp's ZP absorbs its
        # own color, so the star-to-star scatter (hence SEM) reflects real
        # calibration spread, which is why we sigma-clip the comp set and keep a
        # systematic floor in quadrature rather than trusting SEM alone.
        # Broadened comp pool (single-band): every detected star EXCEPT
        # the target, the check star, and anything flagged as variable.
        # See exo_v336_features.py for rationale — bigger pool → more
        # catalog-mag comps → higher chance of clearing the ≥3 bar for
        # ensemble ZP.
        _all_indices = list(range(len(self.star_positions)))
        _flagged     = getattr(self, "flagged_stars", None) or set()
        comp_members = [m for m in _all_indices
                        if m != idx and m != k_idx and m not in _flagged]
        vmap = self._catalog_vmags_for_members(comp_members, wcs)   # {idx: (V, source)}
        comp_idx = np.array([m for m in comp_members if m in vmap], dtype=int)
        comp_mag = np.array([vmap[m][0] for m in comp_idx], dtype=float)

        LOGC   = 2.5 / np.log(10.0)
        floor  = float(getattr(self, "sys_floor_mag", 0.10) or 0.0)
        F_T    = np.asarray(self.raw_flux[idx, :],     dtype=np.float64)
        Ferr_T = np.asarray(self.raw_flux_err[idx, :], dtype=np.float64)

        def _comp_radec_labels(members, maxn=10):
            """RA/Dec (ICRS deg) labels for the comps that set the ZP, for NOTES."""
            w = self._wcs
            bf = getattr(self, "_wcs_bin_factor", 1)
            out = []
            for mi in members:
                try:
                    x, y = self.star_positions[int(mi)]
                    sky = w.pixel_to_world(x * bf, y * bf)
                    out.append(f"{sky.ra.deg:.4f}{sky.dec.deg:+.4f}")
                except Exception:
                    pass
            if not out:
                return ""
            if len(out) > maxn:
                return ", ".join(out[:maxn]) + f", +{len(out) - maxn} more"
            return ", ".join(out)

        if comp_idx.size >= 3:
            Fi  = np.asarray(self.raw_flux[comp_idx, :], dtype=np.float64)   # (Ncomp, Nframe)
            okF = np.isfinite(Fi) & (Fi > 0)
            zi  = np.where(okF, comp_mag[:, None] + 2.5 * np.log10(np.where(okF, Fi, 1.0)), np.nan)

            # choose a stable comparison set ONCE — robust MAD-based
            # sigma-clip on each star's run-median ZP. std is inflated by
            # the outliers we're trying to catch; MAD isn't, so a comp
            # star with a wrong catalog mag now actually gets clipped
            # instead of masquerading as normal scatter. Floor sigma at
            # 0.05 mag so tight ensembles don't over-clip themselves down
            # to one star.
            z_star = np.nanmedian(zi, axis=1)
            keepC  = np.isfinite(z_star)
            for _ in range(3):
                if not np.any(keepC):
                    break
                med  = np.nanmedian(z_star[keepC])
                mad  = np.nanmedian(np.abs(z_star[keepC] - med))
                sd_r = max(1.4826 * float(mad), 0.05)
                if not np.isfinite(sd_r) or sd_r == 0:
                    break
                prev_keep = keepC.copy()
                keepC &= np.abs(z_star - med) <= 3.0 * sd_r
                if np.array_equal(keepC, prev_keep):
                    break  # converged; no point re-computing MAD
            zi = zi[keepC, :]

            ZP_t  = np.nanmedian(zi, axis=0)
            n_t   = np.sum(np.isfinite(zi), axis=0)
            madz  = np.nanmedian(np.abs(zi - ZP_t[None, :]), axis=0)
            SEM_t = np.where(n_t > 1, 1.4826 * madz / np.sqrt(np.maximum(n_t, 1)), np.nan)

            with np.errstate(divide="ignore", invalid="ignore"):
                mags = -2.5 * np.log10(F_T) + ZP_t
                merr = np.sqrt((LOGC * Ferr_T / F_T) ** 2
                               + np.nan_to_num(SEM_t) ** 2 + floor ** 2)
            bad = ~np.isfinite(mags) | (F_T <= 0) | (n_t < 1)

            n_ens       = int(np.count_nonzero(keepC))
            # AAVSO ENSEMBLE: KMAG is the check star standardised through the
            # SAME ensemble ZP (not its catalog mag), so (K - catalog) is a real
            # quality check. Compute K exactly like the target.
            F_K = np.asarray(self.raw_flux[k_idx, :], dtype=np.float64)
            with np.errstate(divide="ignore", invalid="ignore"):
                _K = -2.5 * np.log10(F_K) + ZP_t
            _K = _K[np.isfinite(_K)]
            _used = [int(m) for m in comp_idx[keepC]]
            cname_field = "ENSEMBLE"
            cmag_field  = "na"
            kname_field = kname
            kmag_field  = f"{float(np.median(_K)):.3f}" if _K.size else "na"
            note_field  = (f"ensemble ZP=median(Vcat+2.5log10 F) N={n_ens}; "
                           f"err incl SEM+{floor:.2f}floor")
            _cn = _comp_radec_labels(_used)
            if _cn:
                note_field += f"; comps[RA/Dec]: {_cn}"
        else:
            # Fallback: single-comparison vs the check star, raw-flux ratio.
            F_C    = np.asarray(self.raw_flux[k_idx, :],     dtype=np.float64)
            Ferr_C = np.asarray(self.raw_flux_err[k_idx, :], dtype=np.float64)
            with np.errstate(divide="ignore", invalid="ignore"):
                mags  = kmag - 2.5 * np.log10(F_T / F_C)
                frac2 = (Ferr_T / F_T) ** 2 + (Ferr_C / F_C) ** 2
                merr  = np.sqrt((LOGC ** 2) * frac2 + floor ** 2)
            bad = ~np.isfinite(mags) | (F_T <= 0) | (F_C <= 0)

            # Check star doubling as the comparison → CMAG is its INSTRUMENTAL
            # mag (classic differential); no independent check remains.
            with np.errstate(divide="ignore", invalid="ignore"):
                _fc = float(np.nanmedian(F_C[F_C > 0])) if np.any(F_C > 0) else np.nan
            cname_field = str(kname)
            cmag_field  = f"{-2.5 * np.log10(_fc):.3f}" if np.isfinite(_fc) else "na"
            kname_field = "na"
            kmag_field  = "na"
            # Say WHY there is no ensemble, and keep the comparison's
            # position. Previously the comps[RA/Dec] provenance existed
            # only in the ensemble branch, so a run that fell back here
            # lost it with no explanation -- the file then looks as though
            # an ensemble was never attempted, when in fact the catalog
            # lookup came up short (commonly because VizieR was
            # unreachable, so APASS DR9 and UCAC4 returned nothing).
            note_field  = (f"single-comparison vs {kname}; "
                           f"err incl {floor:.2f} floor; "
                           f"ensemble not used: {comp_idx.size} of "
                           f"{len(comp_members)} field stars had a catalog V "
                           f"(need 3)")
            _cn_fb = _comp_radec_labels([k_idx])
            if _cn_fb:
                note_field += f"; comp[RA/Dec]: {_cn_fb}"

        mags = np.where(bad, np.nan, mags)
        merr = np.where(bad | ~np.isfinite(merr), np.nan, merr)

        _MERR_MAX = 1.0
        _rows_written = 0
        _na_count     = 0
        try:
            with open(path, "w") as f:
                for L in header_lines:
                    f.write(L + "\n")
                for j, t in enumerate(jd):
                    m = mags[j]; me = merr[j]
                    if not np.isfinite(m):
                        continue  # no valid calibrated magnitude for this frame
                    # AAVSO Extended requires MERR ≤ 1.0 or the literal
                    # "na". Downgrade out-of-range values to "na" (David
                    # msg-6 request) rather than let WebObs reject the
                    # whole file at upload.
                    if np.isfinite(me) and me <= _MERR_MAX:
                        me_str = f"{me:.3f}"
                    else:
                        me_str = "na"
                        _na_count += 1  # single-band MERR-out-of-range → emit na
                    am = float(np.clip(self.airmasses[j] if j < len(self.airmasses) else 1.0, 1.0, 40.0))
                    fields = [
                        star_id,
                        f"{t:.5f}",
                        f"{m:.3f}",
                        me_str,
                        filt,
                        "NO",
                        "STD",
                        cname_field,
                        cmag_field,
                        kname_field,
                        kmag_field,
                        f"{am:.1f}",
                        "na",
                        "na",
                        note_field.replace(",", ";"),
                    ]
                    f.write(",".join(fields) + "\n")
                    _rows_written += 1
        except Exception as e:
            QMessageBox.critical(self, "Export AAVSO", f"Failed to write file:\n{e}")
            return

        _body = f"Wrote {fmt} ({_rows_written} row(s)) →\n{path}"
        if _na_count > 0:
            _body += (f"\n\nMERR=na for {_na_count} row(s) "
                      f"(computed error > {_MERR_MAX:.1f}).")
        _body += "\n\nOpen AAVSO WebObs upload page now?"

        msg = QMessageBox(self)
        msg.setWindowTitle("Export AAVSO")
        msg.setText(_body)
        yes = msg.addButton("Yes", QMessageBox.ButtonRole.AcceptRole)
        msg.addButton("No", QMessageBox.ButtonRole.RejectRole)
        msg.exec()
        if msg.clickedButton() == yes:
            webbrowser.open("https://www.aavso.org/webobs/file")

    # ---------------- TESScut ----------------

    def query_tesscut(self):
        radec = self.get_selected_star_radec()
        if radec is None:
            QMessageBox.warning(self, "No Star Selected", "Please select a star from the list to fetch TESScut data.")
            return
        ra, dec = radec
        print(f"[DEBUG] TESScut Query Requested for RA={ra:.6f}, Dec={dec:.6f}")
        coord = SkyCoord(ra=ra, dec=dec, unit="deg")

        size = 10
        MAX_RETRIES = 5

        manifest = None
        for mtry in range(1, MAX_RETRIES+1):
            try:
                print(f"[DEBUG] Manifest attempt {mtry}/{MAX_RETRIES}…")
                manifest = Tesscut.get_cutouts(coordinates=coord, size=size)
                if manifest:
                    print(f"[DEBUG] Manifest OK: {len(manifest)} sector(s).")
                    break
                else:
                    raise RuntimeError("Empty manifest")
            except Exception as me:
                print(f"[DEBUG] Manifest attempt {mtry} failed: {me}")
                if mtry == MAX_RETRIES:
                    QMessageBox.information(self, "No TESS Data", "There are no TESS cutouts available at that position.")
                    self.status_label.setText("No TESScut data found.")
                    return
                non_blocking_sleep(2)

        self.status_label.setText("Querying TESScut…")
        QApplication.processEvents()

        cache_dir = os.path.join(os.path.expanduser("~"), ".setiastro", "tesscut_cache")
        os.makedirs(cache_dir, exist_ok=True)

        for dtry in range(1, MAX_RETRIES+1):
            try:
                print(f"[DEBUG] Download attempt {dtry}/{MAX_RETRIES}…")
                cutouts = Tesscut.download_cutouts(coordinates=coord, size=size, path=cache_dir)
                if not cutouts:
                    raise RuntimeError("No cutouts downloaded")
                print(f"[DEBUG] Downloaded {len(cutouts)} cutout(s).")

                for cutout in cutouts:
                    original_path = cutout['Local Path']
                    print(f"[DEBUG] Processing: {original_path}")
                    with fits.open(original_path, mode='readonly') as hdul:
                        sector = hdul[1].header.get('SECTOR', 'unknown')
                    ext = os.path.splitext(original_path)[1]
                    cache_key = f"tess_sector{sector}_ra{int(round(ra*10000))}_dec{int(round(dec*10000))}{ext}"
                    cached_path = os.path.join(cache_dir, cache_key)

                    if not os.path.exists(cached_path):
                        print(f"[DEBUG] Caching as: {cached_path}")
                        shutil.move(original_path, cached_path)
                    else:
                        print(f"[DEBUG] Already cached: {cached_path}")
                        os.remove(original_path)

                    tpf = TessTargetPixelFile(cached_path)
                    xpix, ypix = tpf.wcs.world_to_pixel(coord)
                    ny, nx = tpf.flux.shape[1], tpf.flux.shape[2]
                    Y, X = np.mgrid[:ny, :nx]
                    r_pix = 2.5
                    aper_mask = ((X - xpix)**2 + (Y - ypix)**2) <= r_pix**2

                    lc = (tpf.to_lightcurve(aperture_mask=aper_mask).remove_nans().normalize())
                    upper, lower = 5.0, -1.0
                    mask = (lc.flux < upper) & (lc.flux > lower)
                    n_clipped = np.sum(~mask)
                    print(f"[DEBUG] Clipping {n_clipped} points outside [{lower}, {upper}]×")
                    lc = lc[mask]

                    lc.plot(label=f"Sector {tpf.sector} (clipped)")
                    plt.title(f"TESS Light Curve - Sector {tpf.sector}")
                    plt.tight_layout()
                    plt.show()

                self.status_label.setText("TESScut fetch complete.")
                return

            except Exception as de:
                print(f"[ERROR] Download attempt {dtry} failed: {de}")
                self.status_label.setText(f"TESScut attempt {dtry}/{MAX_RETRIES} failed.")
                QApplication.processEvents()
                if dtry == MAX_RETRIES:
                    QMessageBox.critical(self, "TESScut Error", f"TESScut failed after {MAX_RETRIES} attempts.\n\n{de}")
                    self.status_label.setText("TESScut fetch failed.")
                else:
                    non_blocking_sleep(2)

    # ---------------- Pixel → Sky helper ----------------
    def get_selected_star_radec(self):
        selected_items = self.star_list.selectedItems()
        if not selected_items:
            return None

        selected_index = selected_items[0].data(Qt.ItemDataRole.UserRole)
        x, y = self.star_positions[selected_index]

        if self._wcs is None:
            return None

        bin_factor = getattr(self, "_wcs_bin_factor", 1)
        xw = x * bin_factor
        yw = y * bin_factor

        sky = self._wcs.pixel_to_world(xw, yw)
        return sky.ra.degree, sky.dec.degree