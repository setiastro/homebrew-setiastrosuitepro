# src/setiastro/saspro/ser_stacker_dialog.py
from __future__ import annotations
import os
import traceback
import numpy as np

from typing import Optional, Union, Sequence

SourceSpec = Union[str, Sequence[str]]

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QRectF, QEvent, QTimer
# === SASpro flat calibration dialog wiring (v1) ===
from PyQt6.QtWidgets import (
    QWidget, QSpinBox, QMessageBox,
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QGroupBox,
    QFormLayout, QComboBox, QDoubleSpinBox, QCheckBox, QTextEdit, QProgressBar,
    QScrollArea, QSlider, QToolButton, QSizePolicy, QFrame,
    QLineEdit, QFileDialog
)

from PyQt6.QtGui import QPainter, QPen, QColor, QImage, QPixmap

from setiastro.saspro.ser_stack_config import SERStackConfig

from setiastro.saspro.ser_stacker import stack_ser, analyze_ser, AnalyzeResult
from setiastro.saspro.ser_stacker import _shift_image
# ── Platform-aware anchor gesture text (mirrors serviewer.py) ───────
import platform as _platform
_IS_MAC = (_platform.system() == "Darwin")
ANCHOR_GESTURE_SHORT = "⌃⇧-drag" if _IS_MAC else "Ctrl+Shift+drag"

# ---------------------------------------------------------------------------
# CollapsibleGroup
# ---------------------------------------------------------------------------

class CollapsibleGroup(QWidget):
    """
    A collapsible section widget that mimics QGroupBox but with a clickable
    header showing ▶ (collapsed) / ▼ (expanded) toggle arrows.

    Usage:
        grp = CollapsibleGroup("Drizzle", parent, collapsed=True)
        layout = grp.content_layout()   # QFormLayout pre-installed
        layout.addRow(...)
        # or: grp.set_content_widget(my_widget)
    """

    def __init__(self, title: str, parent=None, *, collapsed: bool = True):
        super().__init__(parent)
        self._collapsed = bool(collapsed)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # --- header ---
        self._header = QPushButton(self)
        self._header.setFlat(True)
        self._header.setCheckable(False)
        self._header.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._header.setStyleSheet("""
            QPushButton {
                text-align: left;
                padding: 4px 6px;
                font-weight: bold;
                background: #2a2a2a;
                border: 1px solid #3a3a3a;
                border-radius: 3px;
                color: #ccc;
            }
            QPushButton:hover {
                background: #333;
            }
        """)
        self._title = title
        self._update_header_text()
        self._header.clicked.connect(self.toggle)
        outer.addWidget(self._header)

        # --- content container ---
        self._container = QWidget(self)
        self._container.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)

        # border/indent styling
        self._container.setStyleSheet("""
            QWidget {
                border: 1px solid #3a3a3a;
                border-top: none;
                border-radius: 0 0 3px 3px;
            }
        """)

        self._form = QFormLayout(self._container)
        self._form.setContentsMargins(8, 6, 8, 6)
        self._form.setSpacing(4)

        outer.addWidget(self._container)

        self._container.setVisible(not self._collapsed)

    # ------------------------------------------------------------------
    def _update_header_text(self):
        arrow = "▶" if self._collapsed else "▼"
        self._header.setText(f"  {arrow}  {self._title}")

    def toggle(self):
        self._collapsed = not self._collapsed
        self._container.setVisible(not self._collapsed)
        self._update_header_text()
        # Walk up to find a QDialog/QWidget and ask it to adjust size
        p = self.parent()
        while p is not None:
            if hasattr(p, "adjustSize"):
                p.adjustSize()
                break
            p = p.parent() if hasattr(p, "parent") else None

    def set_collapsed(self, collapsed: bool):
        if self._collapsed != bool(collapsed):
            self.toggle()

    def is_collapsed(self) -> bool:
        return self._collapsed

    def content_layout(self) -> QFormLayout:
        """Return the QFormLayout inside the content area."""
        return self._form

    def content_widget(self) -> QWidget:
        return self._container

    def set_content_widget(self, widget: QWidget):
        """Replace the default form layout container with a custom widget."""
        old = self._container
        layout = self.layout()
        layout.replaceWidget(old, widget)
        old.deleteLater()
        self._container = widget
        self._container.setVisible(not self._collapsed)


# ---------------------------------------------------------------------------

def _deg_per_min_from_period(*, days: float | None = None, hours: float | None = None) -> float:
    if days is not None:
        minutes = float(days) * 24.0 * 60.0
    elif hours is not None:
        minutes = float(hours) * 60.0
    else:
        raise ValueError("Provide days or hours.")
    return 360.0 / max(1e-9, minutes)

# Sidereal rotation periods (common reference values)
# - Jupiter: ~9.925 h (System III ~9h55m29s)
# - Saturn:  ~10.656 h
# - Mars:    ~24.623 h
# - Venus:   ~243.025 d (retrograde)
# - Mercury: ~58.646 d
# - Moon:    ~27.321661 d
# - Uranus:  ~17.24 h (retrograde)
# - Neptune: ~16.11 h
_PLANET_ROT_PRESETS_DEG_PER_MIN: dict[str, float] = {
    "Custom…": 0.0,
    "Jupiter (System III)": _deg_per_min_from_period(hours=9.925),
    "Saturn": _deg_per_min_from_period(hours=10.656),
    "Mars": _deg_per_min_from_period(hours=24.623),
    "Venus (retrograde)": -_deg_per_min_from_period(days=243.025),
    "Mercury": _deg_per_min_from_period(days=58.646),
    "Moon": _deg_per_min_from_period(days=27.321661),
    "Uranus (retrograde)": -_deg_per_min_from_period(hours=17.24),
    "Neptune": _deg_per_min_from_period(hours=16.11),
}


def _source_basename_from_source(source: SourceSpec | None) -> str:
    try:
        if isinstance(source, str) and source.strip():
            p = source.strip()
            base = os.path.basename(p)
            stem, _ = os.path.splitext(base)
            return stem.strip()
        if isinstance(source, (list, tuple)) and len(source) > 0:
            first = source[0]
            if isinstance(first, str) and first.strip():
                base = os.path.basename(first.strip())
                stem, _ = os.path.splitext(base)
                return stem.strip()
    except Exception:
        pass
    return ""


def _derive_view_base_title(main, doc) -> str:
    try:
        if hasattr(main, "_subwindow_for_document"):
            sw = main._subwindow_for_document(doc)
            if sw:
                w = sw.widget() if hasattr(sw, "widget") else sw
                if hasattr(w, "_effective_title"):
                    t = w._effective_title() or ""
                else:
                    t = sw.windowTitle() if hasattr(sw, "windowTitle") else ""
                if hasattr(w, "_strip_decorations"):
                    t, _ = w._strip_decorations(t)
                if t.strip():
                    return t.strip()
    except Exception:
        pass

    try:
        mdi = (getattr(main, "mdi_area", None)
               or getattr(main, "mdiArea", None)
               or getattr(main, "mdi", None))
        if mdi and hasattr(mdi, "subWindowList"):
            for sw in mdi.subWindowList():
                w = sw.widget()
                if getattr(w, "document", None) is doc:
                    t = sw.windowTitle() if hasattr(sw, "windowTitle") else ""
                    if hasattr(w, "_strip_decorations"):
                        t, _ = w._strip_decorations(t)
                    if t.strip():
                        return t.strip()
    except Exception:
        pass

    try:
        if hasattr(doc, "display_name"):
            t = doc.display_name()
            if t and t.strip():
                return t.strip()
    except Exception:
        pass

    return (getattr(doc, "name", "") or "Image").strip()


def _push_as_new_doc(
    main,
    source_doc,
    arr: np.ndarray,
    *,
    title_suffix: str = "_stack",
    source: str = "Planetary Stacker",
    source_path: SourceSpec | None = None,
):
    dm = getattr(main, "docman", None)
    if not dm or not hasattr(dm, "open_array"):
        return None

    try:
        base = ""
        if source_doc is not None:
            base = _derive_view_base_title(main, source_doc) or ""
        if not base:
            base = _source_basename_from_source(source_path) or ""
        if not base:
            base = "Stack"

        suf = title_suffix or ""
        if suf and base.lower().endswith(suf.lower()):
            title = base
        else:
            title = f"{base}{suf}"

        x = np.asarray(arr)
        if x.ndim == 3 and x.shape[2] == 1:
            x = x[..., 0]
        x = x.astype(np.float32, copy=False)

        meta = {
            "bit_depth": "32-bit floating point",
            "is_mono": bool(x.ndim == 2),
            "source": source,
        }

        newdoc = dm.open_array(x, metadata=meta, title=title)

        if hasattr(main, "_spawn_subwindow_for"):
            main._spawn_subwindow_for(newdoc)

        return newdoc
    except Exception:
        return None


class APEditorDialog(QDialog):
    """
    AP editor (AutoStakkert-ish):
    - Scrollable preview (fits to window by default)
    - Zoom controls (+/-/slider, Fit, 1:1)
    - Constant on-screen AP box thickness (draw boxes after scaling)
    - Left click: add AP
    - Right click: delete nearest AP
    """
    def __init__(
        self,
        parent=None,
        *,
        ref_img01: np.ndarray,
        ap_size: int,
        ap_spacing: int,
        ap_min_mean: float,
        initial_centers: np.ndarray | None = None
    ):
        super().__init__(parent)
        self.setWindowTitle("Edit Alignment Points (APs)")
        self.setModal(True)
        self.resize(1000, 750)

        self._ref = np.asarray(ref_img01, dtype=np.float32)
        self._H, self._W = self._ref.shape[:2]

        self._ap_size = int(ap_size)
        self._ap_spacing = int(ap_spacing)
        self._ap_min_mean = float(ap_min_mean)

        self._centers = None if initial_centers is None else np.asarray(initial_centers, dtype=np.int32).copy()

        # zoom state
        self._zoom = 1.0
        self._fit_pending = True

        # ---- Build UI ---------------------------------------------------------
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)
        outer.setSpacing(8)

        self._pix = QLabel(self)
        self._pix.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._pix.setMouseTracking(True)
        self._pix.setStyleSheet("background:#111;")

        self._scroll = QScrollArea(self)
        self._scroll.setWidgetResizable(False)
        self._scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._scroll.setWidget(self._pix)

        outer.addWidget(self._scroll, 1)

        zoom_row = QHBoxLayout()
        self.btn_zoom_out = QPushButton("–", self)
        self.btn_zoom_in = QPushButton("+", self)
        self.btn_fit = QPushButton("Fit", self)
        self.btn_100 = QPushButton("1:1", self)

        self.sld_zoom = QSlider(Qt.Orientation.Horizontal, self)
        self.sld_zoom.setRange(10, 400)
        self.sld_zoom.setValue(100)
        self.lbl_zoom = QLabel("100%", self)
        self.lbl_zoom.setStyleSheet("color:#aaa; min-width:60px;")

        self.btn_zoom_out.setFixedWidth(34)
        self.btn_zoom_in.setFixedWidth(34)

        zoom_row.addWidget(QLabel("Zoom:", self))
        zoom_row.addWidget(self.btn_zoom_out)
        zoom_row.addWidget(self.sld_zoom, 1)
        zoom_row.addWidget(self.btn_zoom_in)
        zoom_row.addWidget(self.lbl_zoom)
        zoom_row.addSpacing(10)
        zoom_row.addWidget(self.btn_fit)
        zoom_row.addWidget(self.btn_100)

        outer.addLayout(zoom_row)

        self._lbl_hint = QLabel("Left click: add AP   |   Right click: delete nearest AP   |   Ctrl+Wheel: zoom", self)
        self._lbl_hint.setStyleSheet("color:#aaa;")
        outer.addWidget(self._lbl_hint, 0)

        ap_row = QHBoxLayout()

        self.lbl_ap = QLabel("AP:", self)
        self.lbl_ap.setStyleSheet("color:#aaa;")

        self.spin_ap_size = QSpinBox(self)
        self.spin_ap_size.setRange(16, 256)
        self.spin_ap_size.setSingleStep(8)
        self.spin_ap_size.setValue(int(self._ap_size))

        self.spin_ap_spacing = QSpinBox(self)
        self.spin_ap_spacing.setRange(8, 256)
        self.spin_ap_spacing.setSingleStep(8)
        self.spin_ap_spacing.setValue(int(self._ap_spacing))
        self.spin_ap_min_mean = QDoubleSpinBox(self)
        self.spin_ap_min_mean.setRange(0.0, 1.0)
        self.spin_ap_min_mean.setDecimals(3)
        self.spin_ap_min_mean.setSingleStep(0.005)
        self.spin_ap_min_mean.setValue(float(self._ap_min_mean))
        self.spin_ap_min_mean.setToolTip("Minimum mean intensity (0..1) required for an AP tile to be placed.")

        ap_row.addWidget(self.lbl_ap)
        ap_row.addSpacing(6)
        ap_row.addWidget(QLabel("Size", self))
        ap_row.addWidget(self.spin_ap_size)
        ap_row.addSpacing(10)
        ap_row.addWidget(QLabel("Spacing", self))
        ap_row.addWidget(self.spin_ap_spacing)
        ap_row.addSpacing(10)
        ap_row.addWidget(QLabel("Min mean", self))
        ap_row.addWidget(self.spin_ap_min_mean)        
        ap_row.addStretch(1)

        outer.addLayout(ap_row, 0)

        btn_row = QHBoxLayout()
        self.btn_auto = QPushButton("Auto-place", self)
        self.btn_clear = QPushButton("Clear", self)
        self.btn_ok = QPushButton("OK", self)
        self.btn_cancel = QPushButton("Cancel", self)
        btn_row.addWidget(self.btn_auto)
        btn_row.addWidget(self.btn_clear)
        btn_row.addStretch(1)
        btn_row.addWidget(self.btn_ok)
        btn_row.addWidget(self.btn_cancel)
        outer.addLayout(btn_row)

        self.btn_cancel.clicked.connect(self.reject)
        self.btn_ok.clicked.connect(self.accept)
        self.btn_auto.clicked.connect(self._do_autoplace)
        self.btn_clear.clicked.connect(self._do_clear)

        self.btn_fit.clicked.connect(self._fit_to_window)
        self.btn_100.clicked.connect(lambda: self._set_zoom(1.0))
        self.btn_zoom_in.clicked.connect(lambda: self._set_zoom(self._zoom * 1.25))
        self.btn_zoom_out.clicked.connect(lambda: self._set_zoom(self._zoom / 1.25))
        self.sld_zoom.valueChanged.connect(self._on_zoom_slider)

        self._pix.mousePressEvent = self._on_mouse_press  # type: ignore

        self._ap_debounce = QTimer(self)
        self._ap_debounce.setSingleShot(True)
        self._ap_debounce.setInterval(250)
        self._ap_debounce.timeout.connect(self._apply_ap_params_and_relayout)
        self.spin_ap_min_mean.valueChanged.connect(self._schedule_ap_relayout)

        self.spin_ap_size.valueChanged.connect(self._schedule_ap_relayout)
        self.spin_ap_spacing.valueChanged.connect(self._schedule_ap_relayout)

        self._scroll.viewport().installEventFilter(self)

        self._base_u8 = self._make_display_u8(self._ref)

        if self._centers is None:
            self._do_autoplace()

        self._render()

    def ap_size(self) -> int:
        return int(self._ap_size)

    def ap_spacing(self) -> int:
        return int(self._ap_spacing)

    def ap_min_mean(self) -> float:
        return float(self._ap_min_mean)

    def _schedule_ap_relayout(self):
        try:
            self._ap_debounce.start()
        except Exception:
            self._apply_ap_params_and_relayout()

    def _apply_ap_params_and_relayout(self):
        self._ap_size = int(self.spin_ap_size.value())
        self._ap_spacing = int(self.spin_ap_spacing.value())
        self._ap_min_mean = float(self.spin_ap_min_mean.value())
        self._do_autoplace()

    def showEvent(self, e):
        super().showEvent(e)
        if self._fit_pending:
            self._fit_pending = False
            self._fit_to_window()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._render()

    def eventFilter(self, obj, event):
        try:
            if obj is self._scroll.viewport():
                if event.type() == QEvent.Type.Wheel:
                    if bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier):
                        delta = event.angleDelta().y()
                        if delta > 0:
                            self._set_zoom(self._zoom * 1.15)
                        elif delta < 0:
                            self._set_zoom(self._zoom / 1.15)
                        return True
        except Exception:
            pass
        return super().eventFilter(obj, event)

    def ap_centers(self) -> np.ndarray:
        if self._centers is None:
            return np.zeros((0, 2), dtype=np.int32)
        return self._centers

    @staticmethod
    def _make_display_u8(img01: np.ndarray) -> np.ndarray:
        mono = img01 if img01.ndim == 2 else img01[..., 0]
        mono = np.clip(mono, 0.0, 1.0)

        lo = float(np.percentile(mono, 1.0))
        hi = float(np.percentile(mono, 99.5))
        if hi <= lo + 1e-8:
            hi = lo + 1e-3

        v = (mono - lo) / (hi - lo)
        v = np.clip(v, 0.0, 1.0)
        return (v * 255.0 + 0.5).astype(np.uint8)

    def _on_zoom_slider(self, value: int):
        z = float(value) / 100.0
        self._set_zoom(z)

    def _set_zoom(self, z: float):
        z = float(z)
        z = max(0.10, min(4.00, z))
        self._zoom = z

        block = self.sld_zoom.blockSignals(True)
        try:
            self.sld_zoom.setValue(int(round(z * 100.0)))
        finally:
            self.sld_zoom.blockSignals(block)

        self.lbl_zoom.setText(f"{int(round(z * 100.0))}%")
        self._render()

    def _fit_to_window(self):
        vw = max(1, self._scroll.viewport().width() - 10)
        vh = max(1, self._scroll.viewport().height() - 10)
        if self._W <= 0 or self._H <= 0:
            return
        z = min(vw / float(self._W), vh / float(self._H))
        self._set_zoom(z)

    def _on_ap_params_changed(self):
        self._ap_size = int(self.spin_ap_size.value())
        self._ap_spacing = int(self.spin_ap_spacing.value())
        self._render()

    def _render(self):
        u8 = self._base_u8
        if not u8.flags["C_CONTIGUOUS"]:
            u8 = np.ascontiguousarray(u8)

        h, w = u8.shape[:2]

        qimg = QImage(u8.data, w, h, w, QImage.Format.Format_Grayscale8).copy()
        base_pm = QPixmap.fromImage(qimg)

        zw = max(1, int(round(w * self._zoom)))
        zh = max(1, int(round(h * self._zoom)))
        pm = base_pm.scaled(
            zw, zh,
            Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )

        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        s_img = int(max(8, self._ap_size))
        s_disp = max(2, int(round(s_img * self._zoom)))
        half_disp = s_disp // 2

        pen = QPen(QColor(0, 255, 0), 2)
        p.setPen(pen)

        if self._centers is not None and self._centers.size > 0:
            for cx, cy in self._centers.tolist():
                x = int(round(cx * self._zoom))
                y = int(round(cy * self._zoom))
                p.drawRect(int(x - half_disp), int(y - half_disp), int(s_disp), int(s_disp))

        p.end()

        self._pix.setPixmap(pm)
        self._pix.setFixedSize(pm.size())

    def _do_autoplace(self):
        from setiastro.saspro.ser_stacker import _autoplace_aps
        self._centers = _autoplace_aps(self._ref, self._ap_size, self._ap_spacing, self._ap_min_mean)
        self._render()

    def _do_clear(self):
        self._centers = np.zeros((0, 2), dtype=np.int32)
        self._render()

    def _on_mouse_press(self, ev):
        pm = self._pix.pixmap()
        if pm is None:
            return

        dx = float(ev.position().x())
        dy = float(ev.position().y())

        ix = int(round(dx / max(1e-6, self._zoom)))
        iy = int(round(dy / max(1e-6, self._zoom)))

        ix = max(0, min(self._W - 1, ix))
        iy = max(0, min(self._H - 1, iy))

        if ev.button() == Qt.MouseButton.LeftButton:
            self._add_point(ix, iy)
        elif ev.button() == Qt.MouseButton.RightButton:
            self._delete_nearest(ix, iy)

    def _add_point(self, x: int, y: int):
        s = int(max(8, self._ap_size))
        half = s // 2

        x = max(half, min(self._W - 1 - half, x))
        y = max(half, min(self._H - 1 - half, y))

        if self._centers is None or self._centers.size == 0:
            self._centers = np.asarray([[x, y]], dtype=np.int32)
        else:
            self._centers = np.vstack([self._centers, np.asarray([[x, y]], dtype=np.int32)])
        self._render()

    def _delete_nearest(self, x: int, y: int):
        if self._centers is None or self._centers.size == 0:
            return

        pts = self._centers.astype(np.float32)
        d2 = (pts[:, 0] - float(x)) ** 2 + (pts[:, 1] - float(y)) ** 2
        j = int(np.argmin(d2))

        radius = max(10.0, float(self._ap_size) * 0.6)
        if float(d2[j]) <= radius * radius:
            self._centers = np.delete(self._centers, j, axis=0)
            self._render()

class QualityGraph(QWidget):
    """
    AS-style quality plot (sorted curve expected):
    - Curve: q[0] best ... q[N-1] worst
    - Vertical cutoff line at keep_k
    - Midrange horizontal line (min/max midpoint)
    - True median horizontal line labeled 'Med'
    - Click / drag adjusts keep line and emits keepChanged(k, N)
    """
    keepChanged = pyqtSignal(int, int)  # keep_k, total_N

    def __init__(self, parent=None):
        super().__init__(parent)
        self._q: np.ndarray | None = None
        self._keep_k: int | None = None
        self.setMinimumHeight(160)
        self._dragging = False

    def set_data(self, q: np.ndarray | None, keep_k: int | None = None):
        self._q = None if q is None else np.asarray(q, dtype=np.float32)
        self._keep_k = keep_k
        self.update()

    def _plot_rect(self):
        return self.rect().adjusted(34, 10, -10, -22)

    def _x_to_keep_k(self, x: float) -> int | None:
        if self._q is None or self._q.size < 2:
            return None
        r = self._plot_rect()
        if r.width() <= 1:
            return None
        N = int(self._q.size)

        xx = max(float(r.left()), min(float(r.right()), float(x)))

        t = (xx - float(r.left())) / float(max(1, r.width()))
        i = int(round(t * float(N - 1)))
        i = max(0, min(N - 1, i))

        return int(i + 1)

    def mousePressEvent(self, ev):
        if ev.button() != Qt.MouseButton.LeftButton:
            return super().mousePressEvent(ev)
        self._dragging = True
        k = self._x_to_keep_k(ev.position().x())
        if k is not None:
            self._keep_k = int(k)
            self.update()
            self.keepChanged.emit(int(k), int(self._q.size))  # type: ignore
        ev.accept()

    def mouseMoveEvent(self, ev):
        if not self._dragging:
            return super().mouseMoveEvent(ev)
        k = self._x_to_keep_k(ev.position().x())
        if k is not None:
            if self._keep_k != int(k):
                self._keep_k = int(k)
                self.update()
                self.keepChanged.emit(int(k), int(self._q.size))  # type: ignore
        ev.accept()

    def mouseReleaseEvent(self, ev):
        if ev.button() == Qt.MouseButton.LeftButton:
            self._dragging = False
            ev.accept()
            return
        return super().mouseReleaseEvent(ev)

    def paintEvent(self, e):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(20, 20, 20))
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        r = self._plot_rect()

        p.setPen(QPen(QColor(80, 80, 80), 1))
        p.drawRect(r)

        if self._q is None or self._q.size < 2:
            p.setPen(QPen(QColor(160, 160, 160), 1))
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, "Analyze to see quality graph")
            p.end()
            return

        q = self._q
        N = int(q.size)

        qmin = float(np.min(q))
        qmax = float(np.max(q))
        if qmax <= qmin + 1e-12:
            qmax = qmin + 1e-6

        def y_for(val: float) -> float:
            return r.bottom() - ((val - qmin) / (qmax - qmin)) * r.height()

        qmid = qmin + 0.5 * (qmax - qmin)
        ymid = y_for(qmid)
        pen_mid = QPen(QColor(120, 120, 120), 1)
        pen_mid.setStyle(Qt.PenStyle.DashLine)
        p.setPen(pen_mid)
        p.drawLine(int(r.left()), int(ymid), int(r.right()), int(ymid))

        qmed = float(np.median(q))
        ymed = y_for(qmed)
        pen_med = QPen(QColor(160, 160, 160), 1)
        pen_med.setStyle(Qt.PenStyle.DotLine)
        p.setPen(pen_med)
        p.drawLine(int(r.left()), int(ymed), int(r.right()), int(ymed))

        p.setPen(QPen(QColor(180, 180, 180), 1))
        p.drawText(int(r.right()) - 34, int(ymed) - 2, "Med")

        p.setPen(QPen(QColor(0, 220, 0), 2))
        lastx = lasty = None
        for i in range(N):
            x = r.left() + (i / (N - 1)) * r.width()
            y = y_for(float(q[i]))
            if lastx is not None:
                p.drawLine(int(lastx), int(lasty), int(x), int(y))
            lastx, lasty = x, y

        if self._keep_k is not None and N > 1:
            k = int(max(1, min(N, int(self._keep_k))))
            xcut = r.left() + ((k - 1) / (N - 1)) * r.width()
            p.setPen(QPen(QColor(255, 220, 0), 2))
            p.drawLine(int(xcut), int(r.top()), int(xcut), int(r.bottom()))

        p.setPen(QPen(QColor(180, 180, 180), 1))
        p.drawText(
            self.rect().adjusted(6, 0, 0, 0),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom,
            "Best",
        )
        p.drawText(
            self.rect().adjusted(0, 0, -6, 0),
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignBottom,
            "Worst",
        )

        p.drawText(4, int(r.top()) + 10, f"{qmax:.3g}")
        p.drawText(4, int(ymid) + 4,    f"{qmid:.3g}")
        p.drawText(4, int(ymed) + 4,    f"{qmed:.3g}")
        p.drawText(4, int(r.bottom()),  f"{qmin:.3g}")

        p.end()

class _AnalyzeWorker(QThread):
    progress = pyqtSignal(int, int, str)   # done, total, phase
    finished_ok = pyqtSignal(object)
    failed = pyqtSignal(str)
    log_msg = pyqtSignal(str) 

    def __init__(self, cfg: SERStackConfig, *, debayer: bool, to_rgb: bool, ref_mode: str, ref_count: int):
        super().__init__()
        self.cfg = cfg
        self.debayer = bool(debayer)
        self.to_rgb = bool(to_rgb)
        self.ref_mode = ref_mode
        self.ref_count = int(ref_count)
        self._cancel = False
        self._worker_realign: _ReAlignWorker | None = None

    def run(self):
        try:
            def cb(done: int, total: int, phase: str):
                self.progress.emit(int(done), int(total), str(phase))

            def log(msg: str):
                self.log_msg.emit(str(msg))

            ar = analyze_ser(
                self.cfg,
                debayer=self.debayer,
                to_rgb=self.to_rgb,
                bayer_pattern=getattr(self.cfg, "bayer_pattern", None),
                ref_mode=self.ref_mode,
                ref_count=self.ref_count,
                progress_cb=cb,
                log_cb=log,
            )
            self.finished_ok.emit(ar)
        except Exception as e:
            msg = f"{e}\n\n{traceback.format_exc()}"
            self.failed.emit(msg)

class _StackWorker(QThread):
    progress = pyqtSignal(int, int, str)
    finished_ok = pyqtSignal(object, object)    # out(np.ndarray), diag(dict)
    failed = pyqtSignal(str)

    def __init__(self, cfg: SERStackConfig, analysis: AnalyzeResult | None, *, debayer: bool, to_rgb: bool):
        super().__init__()
        self.cfg = cfg
        self.analysis = analysis
        self.debayer = bool(debayer)
        self.to_rgb = bool(to_rgb)

    def run(self):
        try:
            print(f"tracking mode = {getattr(self.cfg, 'track_mode', 'planetary')}")
            def cb(done: int, total: int, phase: str):
                self.progress.emit(int(done), int(total), str(phase))

            out, diag = stack_ser(
                self.cfg.source,
                roi=self.cfg.roi,
                debayer=self.debayer,
                to_rgb=self.to_rgb,
                bayer_pattern=getattr(self.cfg, "bayer_pattern", None),
                keep_percent=float(getattr(self.cfg, "keep_percent", 20.0)),
                track_mode=str(getattr(self.cfg, "track_mode", "planetary")),
                surface_anchor=getattr(self.cfg, "surface_anchor", None),
                analysis=self.analysis,
                progress_cb=cb,
                drizzle_scale=float(getattr(self.cfg, "drizzle_scale", 1.0)),
                drizzle_pixfrac=float(getattr(self.cfg, "drizzle_pixfrac", 0.80)),
                drizzle_kernel=str(getattr(self.cfg, "drizzle_kernel", "gaussian")),
                drizzle_sigma=float(getattr(self.cfg, "drizzle_sigma", 0.0)),
                keep_mask=getattr(self.cfg, "keep_mask", None),
                center_planet=bool(getattr(self.cfg, "center_on_planet", False)),
            )

            self.finished_ok.emit(out, diag)
        except Exception as e:
            msg = f"{e}\n\n{traceback.format_exc()}"
            self.failed.emit(msg)


class _ReAlignWorker(QThread):
    progress = pyqtSignal(int, int, str)   # done, total, phase
    finished_ok = pyqtSignal(object)       # updated AnalyzeResult
    failed = pyqtSignal(str)

    def __init__(self, cfg: SERStackConfig, analysis: AnalyzeResult, *, debayer: bool, to_rgb: bool):
        super().__init__()
        self.cfg = cfg
        self.analysis = analysis
        self.debayer = bool(debayer)
        self.to_rgb = bool(to_rgb)

    def run(self):
        try:
            def cb(done: int, total: int, phase: str):
                self.progress.emit(int(done), int(total), str(phase))

            from setiastro.saspro.ser_stacker import realign_ser
            out_analysis = realign_ser(
                self.cfg,
                self.analysis,
                debayer=self.debayer,
                to_rgb=self.to_rgb,
                bayer_pattern=getattr(self.cfg, "bayer_pattern", None),
                progress_cb=cb,
            )
            self.finished_ok.emit(out_analysis)
        except Exception as e:
            self.failed.emit(f"{e}\n\n{traceback.format_exc()}")

class _ExportAlignedWorker(QThread):
    progress = pyqtSignal(int, int, str)
    finished_ok = pyqtSignal(str)       # out_path
    failed = pyqtSignal(str)

    def __init__(self, cfg: SERStackConfig, analysis: AnalyzeResult, out_path: str, *,
                 debayer: bool, frame_indices=None,
                 apply_field_rotation: bool = True,
                 apply_planet_derotation: bool = True,
                 apply_local_warp: bool = True):
        super().__init__()
        self.cfg = cfg
        self.analysis = analysis
        self.out_path = out_path
        self.debayer = bool(debayer)
        self.frame_indices = frame_indices
        self.apply_field_rotation = apply_field_rotation
        self.apply_planet_derotation = apply_planet_derotation
        self.apply_local_warp = apply_local_warp

    def run(self):
        try:
            from setiastro.saspro.ser_stacker import export_aligned_ser

            def cb(done: int, total: int, phase: str):
                self.progress.emit(int(done), int(total), str(phase))

            export_aligned_ser(
                self.cfg.source,
                self.out_path,
                self.analysis,
                roi=self.cfg.roi,
                debayer=self.debayer,
                to_rgb=False,
                bayer_pattern=getattr(self.cfg, "bayer_pattern", None),
                frame_indices=self.frame_indices,
                apply_field_rotation=self.apply_field_rotation,
                apply_planet_derotation=self.apply_planet_derotation,
                apply_local_warp=self.apply_local_warp,
                progress_cb=cb,
            )
            self.finished_ok.emit(self.out_path)
        except Exception as e:
            self.failed.emit(f"{e}\n\n{traceback.format_exc()}")

class SERStackerDialog(QDialog):
    """
    Dedicated stacking UI (AutoStakkert-like direction):
    - Keeps viewer separate from stacking.
    - V1: track mode, keep %, uses ROI + optional surface anchor from viewer.
    - Later: alignment points (manual/auto), quality graph, drizzle, etc.
    """

    stackProduced = pyqtSignal(object, object)  # out(np.ndarray), diag(dict)

    def __init__(
            self,
            parent=None,
            *,
            main,
            source_doc=None,
            ser_path: Optional[str] = None,
            source: Optional[SourceSpec] = None,
            roi=None,
            track_mode: str = "planetary",
            surface_anchor=None,
            debayer: bool = True,
            keep_percent: float = 20.0,
            bayer_pattern: Optional[str] = None,
            planet_simple_thresh: float = 0.5,
            planet_use_norm: bool = False,
            planet_smooth_sigma: float = 1.5,
            **kwargs
        ):
        super().__init__(parent)
        self.setWindowTitle("Planetary Stacker")
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)
        self._bayer_pattern = bayer_pattern
        self._keep_mask = None

        self._planet_simple_thresh = float(planet_simple_thresh)
        self._planet_use_norm = bool(planet_use_norm)

        self._derot = None

        if source is None:
            source = ser_path

        if ser_path is None and isinstance(source, str) and source:
            ser_path = source

        if source is None:
            raise ValueError("SERStackerDialog requires source (path or list of paths).")

        self._main = main
        self._source = source
        self._source_doc = source_doc
        self.setMinimumWidth(980)
        self.resize(1040, 720)
        self._ser_path = ser_path

        self._track_mode = track_mode
        self._roi = roi
        self._surface_anchor = surface_anchor
        self._debayer = bool(debayer)
        self._keep_percent = float(keep_percent)

        self._analysis = None
        self._worker_analyze = None
        self._worker = None
        self._last_out = None
        self._last_diag = None
        try:
            if isinstance(self._source, (list, tuple)):
                self._append_log(f"Source: sequence ({len(self._source)} frames)  first={self._source[0]}")
            else:
                self._append_log(f"Source: {self._source}")
        except Exception:
            pass

        self._build_ui()

        self.cmb_track.setCurrentText(
            "Planetary" if track_mode == "planetary" else ("Surface" if track_mode == "surface" else "Off")
        )
        self.spin_keep.setValue(float(keep_percent))
        self.chk_debayer.setChecked(bool(debayer))
        self._update_anchor_warning()
        try:
            if isinstance(self._source, (list, tuple)):
                self._append_log(f"Source: sequence ({len(self._source)} frames)")
            else:
                self._append_log(f"Source: {self._source}")
        except Exception:
            self._append_log("Source: (unknown)")
        self._append_log(f"ROI: {roi if roi is not None else '(full frame)'}")
        if track_mode == "surface":
            self._append_log(f"Surface anchor (ROI-space): {surface_anchor}")



    # ---------------- UI ----------------
    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)
        outer.setSpacing(8)

        cols = QHBoxLayout()
        cols.setSpacing(10)
        outer.addLayout(cols, 1)

        left = QVBoxLayout()
        left.setSpacing(4)
        right = QVBoxLayout()
        right.setSpacing(8)

        cols.addLayout(left, 0)
        cols.addLayout(right, 1)

        # =========================
        # LEFT COLUMN
        # =========================

        # --- Stack Settings ---
        gb = QGroupBox("Stack Settings", self)
        form = QFormLayout(gb)

        self.cmb_track = QComboBox(self)
        self.cmb_track.addItems(["Planetary", "Surface", "Off"])

        self.spin_keep = QDoubleSpinBox(self)
        self.spin_keep.setRange(0.1, 100.0)
        self.spin_keep.setDecimals(1)
        self.spin_keep.setSingleStep(1.0)
        self.spin_keep.setValue(20.0)

        self.chk_debayer = QCheckBox("Debayer (Bayer SER)", self)
        self.chk_debayer.setChecked(True)

        self.lbl_anchor = QLabel("", self)
        self.lbl_anchor.setWordWrap(True)
        self.lbl_anchor.setToolTip(
            "Set the anchor in the Planetary Stacker Viewer, then re-run Analyze.\n"
            f"Gesture: {ANCHOR_GESTURE_SHORT} inside the preview."
        )

        form.addRow("Tracking", self.cmb_track)
        form.addRow("Keep %", self.spin_keep)
        form.addRow("", self.chk_debayer)
        self.chk_center_planet = QCheckBox("Center planet in output", self)
        self.chk_center_planet.setChecked(False)
        self.chk_center_planet.setToolTip(
            "Shift every frame so the planet's centroid lands at the exact\n"
            "center of the output image, rather than aligned to the reference\n"
            "frame position. Only available in Planetary tracking mode."
        )
        form.addRow("", self.chk_center_planet)
        self.chk_atm_dispersion = QCheckBox("Correct atmospheric dispersion", self)
        self.chk_atm_dispersion.setChecked(False)
        self.chk_atm_dispersion.setToolTip(
            "Align R, G, and B channel centroids independently so atmospheric\n"
            "prismatic dispersion (colour fringing) is removed before stacking.\n"
            "Only effective for debayered colour frames in Planetary mode."
        )
        form.addRow("", self.chk_atm_dispersion)

        form.addRow("Surface anchor", self.lbl_anchor)

        left.addWidget(gb, 0)

        # --- Drizzle (collapsible, default collapsed) ---
        gbD = CollapsibleGroup("Drizzle", self, collapsed=True)
        fD = gbD.content_layout()

        self.spin_pixfrac = QDoubleSpinBox(self)
        self.spin_pixfrac.setRange(0.30, 1.00)
        self.spin_pixfrac.setDecimals(2)
        self.spin_pixfrac.setSingleStep(0.05)
        self.spin_pixfrac.setValue(0.80)

        self.cmb_kernel = QComboBox(self)
        self.cmb_kernel.addItems(["Gaussian", "Circle", "Square"])
        self.cmb_kernel.setCurrentText("Gaussian")

        self.spin_sigma = QDoubleSpinBox(self)
        self.spin_sigma.setRange(0.00, 10.00)
        self.spin_sigma.setDecimals(2)
        self.spin_sigma.setSingleStep(0.05)
        self.spin_sigma.setValue(0.00)
        self.spin_sigma.setToolTip("Gaussian sigma in output pixels (0 = auto from pixfrac)")

        scale_row = QHBoxLayout()
        scale_row.setContentsMargins(0, 0, 0, 0)

        self.cmb_drizzle = QComboBox(self)
        self.cmb_drizzle.addItems(["Off (1x)", "1.5x", "2x", "3x", "4x"])

        self.btn_drizzle_info = QToolButton(self)
        self.btn_drizzle_info.setText("?")
        self.btn_drizzle_info.setToolTip("Drizzle info")
        self.btn_drizzle_info.setFixedSize(22, 22)

        scale_row.addWidget(self.cmb_drizzle, 1)
        scale_row.addWidget(self.btn_drizzle_info, 0)

        scale_row_w = QWidget(self)
        scale_row_w.setLayout(scale_row)

        fD.addRow("Scale", scale_row_w)
        fD.addRow("Pixfrac", self.spin_pixfrac)
        self.cmb_kernel.hide()
        lbl = fD.labelForField(self.cmb_kernel)
        if lbl:
            lbl.hide()

        self.lbl_kernel_info = QLabel("Advanced Gaussian Kernel Drizzling", self)
        self.lbl_kernel_info.setStyleSheet("color:#6a9fd8; font-style:italic; font-size:11px;")
        fD.addRow("Kernel", self.lbl_kernel_info)
        fD.addRow("Sigma", self.spin_sigma)

        def _sync_drizzle_ui():
            t = self.cmb_drizzle.currentText()
            off = "Off" in t
            self.spin_pixfrac.setEnabled(not off)
            self.cmb_kernel.setEnabled(not off)

            k = self.cmb_kernel.currentText().lower()
            is_gauss = ("gaussian" in k)
            self.spin_sigma.setEnabled((not off) and is_gauss)

            if off:
                return
            if "1.5" in t:
                if abs(self.spin_pixfrac.value() - 0.80) < 1e-6 or self.spin_pixfrac.value() in (0.70,):
                    self.spin_pixfrac.setValue(0.80)
            elif "2" in t:
                if abs(self.spin_pixfrac.value() - 0.70) < 1e-6 or self.spin_pixfrac.value() in (0.80,):
                    self.spin_pixfrac.setValue(0.70)

        self.cmb_drizzle.currentIndexChanged.connect(lambda _=None: _sync_drizzle_ui())
        self.cmb_kernel.currentIndexChanged.connect(lambda _=None: _sync_drizzle_ui())
        _sync_drizzle_ui()

        def _show_drizzle_info():
            QMessageBox.information(
                self,
                "Drizzle Info",
                "Drizzle increases output resolution by resampling and re-depositing pixels.\n\n"
                "Compute cost:\n"
                "• 1.5× drizzle ≈ 225% compute (2.25×)\n"
                "• 2× drizzle ≈ 400% compute (4×)\n\n"
                "• 3× drizzle ≈ 900% compute (9×)\n"
                "• 4× drizzle ≈ 1600% compute (16×)\n\n"
                "Pixfrac (drop shrink):\n"
                "• Controls how large each input pixel's 'drop' is in the output grid.\n"
                "• Lower pixfrac = tighter drops (sharper, but can create gaps/noise).\n"
                "• Higher pixfrac = smoother coverage (less noise, slightly softer).\n\n"
                "When drizzle helps:\n"
                "• Best when you are under-sampled and you have good alignment / many frames.\n"
                "• Helps most with stable seeing and lots of usable frames.\n\n"
                "When drizzle may NOT help:\n"
                "• If you're already well-sampled (common around f/10–f/20 depending on pixel size),\n"
                "  gains can be minimal.\n"
                "• If seeing is very poor, drizzle often just magnifies blur/noise.\n\n"
                "Tip: Start with 1.5× and pixfrac ~0.8. If coverage looks sparse/noisy, increase pixfrac."
            )

        self.btn_drizzle_info.clicked.connect(_show_drizzle_info)

        left.addWidget(gbD, 0)

        # --- Planet Axial Rotation (collapsible, default collapsed) ---
        gbR = CollapsibleGroup("Planet Axial Rotation", self, collapsed=True)
        fR = gbR.content_layout()

        self.chk_derotate = QCheckBox("Enable derotation", self)
        self.chk_derotate.setChecked(False)
        self.btn_set_disk = QPushButton("Set disk…", self)
        self.btn_set_disk.setEnabled(False)
        self.btn_set_disk.setFlat(False)
        self.btn_set_disk.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_set_disk.setStyleSheet(
            "QPushButton {"
            "  border: 1px solid palette(mid);"
            "  border-radius: 4px;"
            "  padding: 4px 14px;"
            "  background-color: palette(button);"
            "  color: palette(button-text);"
            "}"
            "QPushButton:hover:enabled { background-color: palette(light); }"
            "QPushButton:pressed:enabled { background-color: palette(dark); }"
            "QPushButton:disabled { border: 1px solid palette(mid); color: palette(mid); }"
        )

        self.lbl_derot_disk = QLabel("(not set)", self)
        self.lbl_derot_disk.setWordWrap(True)
        self.lbl_derot_disk.setStyleSheet("color:#888;")

        fR.addRow("", self.chk_derotate)
        self.cmb_derot_planet = QComboBox(self)
        self.cmb_derot_planet.addItems(list(_PLANET_ROT_PRESETS_DEG_PER_MIN.keys()))
        self.cmb_derot_planet.setCurrentText("Custom…")

        self.chk_derot_reverse = QCheckBox("Reverse sign", self)
        self.chk_derot_reverse.setToolTip(
            "Flip direction if your camera orientation makes smearing worse with the default sign.")

        self.spin_derot_rate = QDoubleSpinBox(self)
        self.spin_derot_rate.setRange(-10.0, 10.0)
        self.spin_derot_rate.setDecimals(6)
        self.spin_derot_rate.setSingleStep(0.001)
        self.spin_derot_rate.setValue(0.0)
        self.spin_derot_rate.setToolTip(
            "Rotation rate in degrees per minute.\n"
            "Use a preset or enter a custom value.\n"
            "Tip: if derotation makes smearing worse, try 'Reverse sign'."
        )
        fR.addRow("Preset", self.cmb_derot_planet)
        fR.addRow("", self.chk_derot_reverse)
        fR.addRow("Rate (deg/min)", self.spin_derot_rate)
        fR.addRow("", self.btn_set_disk)
        fR.addRow("Disk", self.lbl_derot_disk)

        left.addWidget(gbR, 0)

        # --- Field Rotation (collapsible, default collapsed) ---
        gbFR = CollapsibleGroup("Field Rotation", self, collapsed=True)
        fFR = gbFR.content_layout()

        self.chk_field_rotation = QCheckBox("Correct field rotation", self)
        self.chk_field_rotation.setChecked(False)
        self.chk_field_rotation.setToolTip(
            "After translation alignment, search for a small rotation that further\n"
            "reduces residual error. Useful for alt-az mounts without a field rotator.\n"
            "Rotation center: planet centroid (planetary) or surface anchor (surface).\n"
            "Searches up to the max rotation set below, with a hysteresis quality check."
        )
        fFR.addRow("", self.chk_field_rotation)

        self.spin_field_rot_max = QDoubleSpinBox(self)
        self.spin_field_rot_max.setRange(1.0, 45.0)
        self.spin_field_rot_max.setDecimals(1)
        self.spin_field_rot_max.setSingleStep(1.0)
        self.spin_field_rot_max.setValue(10.0)
        self.spin_field_rot_max.setToolTip(
            "Maximum field rotation to search for (degrees).\n"
            "Increase for longer clips or faster alt-az mounts."
        )
        self.spin_field_rot_max.setEnabled(False)
        fFR.addRow("Max rotation (°)", self.spin_field_rot_max)

        left.addWidget(gbFR, 0)

        # --- Calibration (collapsible, default collapsed) ---
        gbC = CollapsibleGroup("Calibration", self, collapsed=True)
        fC = gbC.content_layout()

        self.chk_flat_enabled = QCheckBox("Apply master flat", self)
        self.chk_flat_enabled.setChecked(False)
        self.chk_flat_enabled.setToolTip(
            "Divide every raw frame by a normalised master flat to remove\n"
            "vignetting, dust motes, and Newton's rings before stacking.\n"
            "Analogous to AutoStakkert's flat-frame slot."
        )

        # File row: label + line-edit + browse button
        self.ln_flat_path = QLineEdit(self)
        self.ln_flat_path.setReadOnly(True)
        self.ln_flat_path.setPlaceholderText("(no flat selected)")
        self.ln_flat_path.setToolTip(
            "Path to a flat file. Accepted formats:\n"
            "  .ser  — flat video, will be median/mean-stacked\n"
            "  .tif / .tiff — single averaged flat\n"
            "  .fit / .fits / .fits.gz / .fz — single averaged flat"
        )
        self.btn_flat_browse = QPushButton("Browse…", self)
        self.btn_flat_browse.setFlat(False)
        self.btn_flat_browse.setCursor(Qt.CursorShape.PointingHandCursor)

        flat_row = QHBoxLayout()
        flat_row.setContentsMargins(0, 0, 0, 0)
        flat_row.addWidget(self.ln_flat_path, 1)
        flat_row.addWidget(self.btn_flat_browse, 0)
        flat_row_w = QWidget(self)
        flat_row_w.setLayout(flat_row)

        # Combine method (for .ser flats)
        self.cmb_flat_method = QComboBox(self)
        self.cmb_flat_method.addItems(["Median", "Mean"])
        self.cmb_flat_method.setCurrentText("Median")
        self.cmb_flat_method.setToolTip(
            "How to combine frames when the flat is a .ser video.\n"
            "Median rejects outliers (cosmic rays, satellite streaks) and is\n"
            "safe to leave as default. Mean is marginally smoother for very\n"
            "clean flat runs. Ignored for single-frame .tif/.fits inputs."
        )

        # Info + status row
        self.btn_flat_info = QToolButton(self)
        self.btn_flat_info.setText("?")
        self.btn_flat_info.setFixedSize(22, 22)
        self.btn_flat_info.setToolTip("What is a flat, and when do I need one?")

        self.lbl_flat_status = QLabel("(disabled)", self)
        self.lbl_flat_status.setWordWrap(True)
        self.lbl_flat_status.setStyleSheet("color:#888;")

        info_row = QHBoxLayout()
        info_row.setContentsMargins(0, 0, 0, 0)
        info_row.addWidget(self.lbl_flat_status, 1)
        info_row.addWidget(self.btn_flat_info, 0)
        info_row_w = QWidget(self)
        info_row_w.setLayout(info_row)

        fC.addRow("", self.chk_flat_enabled)
        fC.addRow("Flat file", flat_row_w)
        fC.addRow("Combine (SER only)", self.cmb_flat_method)
        fC.addRow("Status", info_row_w)

        left.addWidget(gbC, 0)

        # Dialog-scoped state
        self._flat_path = None
        self._flat_enabled = False
        self._flat_method = "median"

        # --- Wire calibration handlers ---
        def _sync_flat_ui():
            en = bool(self.chk_flat_enabled.isChecked())
            self._flat_enabled = en
            self.ln_flat_path.setEnabled(en)
            self.btn_flat_browse.setEnabled(en)
            self.cmb_flat_method.setEnabled(en)
            if not en:
                self.lbl_flat_status.setText("(disabled)")
                self.lbl_flat_status.setStyleSheet("color:#888;")
                return
            if not self._flat_path:
                self.lbl_flat_status.setText("⚠️  No flat selected — pick a .ser / .tif / .fit file")
                self.lbl_flat_status.setStyleSheet("color:#c66;")
            else:
                base = os.path.basename(self._flat_path)
                try:
                    sz = os.path.getsize(self._flat_path)
                except OSError:
                    sz = 0
                mb = sz / (1024.0 * 1024.0)
                self.lbl_flat_status.setText(f"✅ {base}  ({mb:.1f} MB)")
                self.lbl_flat_status.setStyleSheet("color:#4a4;")

        def _on_flat_browse():
            start_dir = ""
            if self._flat_path and os.path.isfile(self._flat_path):
                start_dir = os.path.dirname(self._flat_path)
            path, _ = QFileDialog.getOpenFileName(
                self,
                "Select master flat",
                start_dir,
                "Flat files (*.ser *.tif *.tiff *.fit *.fits *.fits.gz *.fz);;"
                "SER videos (*.ser);;"
                "TIFF images (*.tif *.tiff);;"
                "FITS images (*.fit *.fits *.fits.gz *.fz);;"
                "All files (*)",
            )
            if not path:
                return
            self._flat_path = path
            self.ln_flat_path.setText(path)
            # Auto-enable when a file is chosen, so the user doesn't have
            # to remember to tick the box
            if not self.chk_flat_enabled.isChecked():
                self.chk_flat_enabled.setChecked(True)
            _sync_flat_ui()

        def _on_flat_method_changed(_txt=None):
            self._flat_method = self.cmb_flat_method.currentText().lower()

        def _show_flat_info():
            QMessageBox.information(
                self, "Master flat calibration",
                "A master flat is an image of a uniformly-lit field (twilight sky,\n"
                "T-shirt over the scope, or ASI/LED flat panel) captured with the\n"
                "same optical train as your lights. Dividing every raw frame by\n"
                "the normalised flat removes:\n"
                "\n"
                "  • vignetting (dim corners)\n"
                "  • dust motes and doughnuts\n"
                "  • Newton's rings from IR/UV filters\n"
                "  • per-pixel gain / sensor QE non-uniformity\n"
                "\n"
                "This is the same slot AutoStakkert offers for flats. Whether\n"
                "you supply a .ser flat video (multiple frames, median-stacked\n"
                "here) or a pre-averaged single .tif / .fit doesn't matter —\n"
                "both go through the same normalisation.\n"
                "\n"
                "The flat must be captured at the SAME sensor resolution,\n"
                "binning, and ROI setting as your lights. The dialog will\n"
                "abort with a clear error otherwise."
            )

        self.chk_flat_enabled.stateChanged.connect(lambda _=None: _sync_flat_ui())
        self.btn_flat_browse.clicked.connect(_on_flat_browse)
        self.cmb_flat_method.currentIndexChanged.connect(_on_flat_method_changed)
        self.btn_flat_info.clicked.connect(_show_flat_info)
        _sync_flat_ui()


        # --- Analyze ---
        gbA = QGroupBox("Analyze", self)
        fA = QFormLayout(gbA)

        self.cmb_ref = QComboBox(self)
        self.cmb_ref.addItems(["Best frame", "Best stack (N)"])

        self.spin_refN = QSpinBox(self)
        self.spin_refN.setRange(2, 200)
        self.spin_refN.setValue(10)

        self.spin_ap_min = QDoubleSpinBox(self)
        self.spin_ap_min.setRange(0.0, 1.0)
        self.spin_ap_min.setDecimals(3)
        self.spin_ap_min.setSingleStep(0.005)
        self.spin_ap_min.setValue(0.03)
        fA.addRow("AP min mean (0..1)", self.spin_ap_min)

        self.btn_edit_aps = QPushButton("(2) Edit APs…", self)
        self.btn_edit_aps.setEnabled(False)
        fA.addRow("", self.btn_edit_aps)

        self.spin_ap_size = QSpinBox(self)
        self.spin_ap_size.setRange(16, 256)
        self.spin_ap_size.setSingleStep(8)
        self.spin_ap_size.setValue(64)

        self.spin_ap_spacing = QSpinBox(self)
        self.spin_ap_spacing.setRange(8, 256)
        self.spin_ap_spacing.setSingleStep(8)
        self.spin_ap_spacing.setValue(48)

        fA.addRow("Reference", self.cmb_ref)
        fA.addRow("Ref stack N", self.spin_refN)

        self.cmb_ap_scale = QComboBox(self)
        self.cmb_ap_scale.addItems(["Single", "Multi-scale (2× / 1× / ½×)"])
        fA.addRow("AP scale", self.cmb_ap_scale)

        self.chk_ssd_bruteforce = QCheckBox(
            "SSD refine: brute force (slower, can rescue tough data)", self)
        self.chk_ssd_bruteforce.setChecked(False)
        fA.addRow("", self.chk_ssd_bruteforce)

        fA.addRow("AP size (px)", self.spin_ap_size)
        fA.addRow("AP spacing (px)", self.spin_ap_spacing)

        left.addWidget(gbA, 0)

        # --- Action buttons ---
        row = QHBoxLayout()
        self.btn_analyze = QPushButton("(1) Analyze", self)
        self.btn_analyze.setEnabled(True)
        self.btn_blink = QPushButton("(3) Blink Keepers", self)
        self.btn_blink.setEnabled(False)
        self.btn_export_aligned = QPushButton("(4) Export Aligned SER…", self)
        self.btn_export_aligned.setEnabled(False)
        self.btn_stack = QPushButton("(5) Stack Now", self)
        self.btn_stack.setEnabled(False)
        self.btn_close = QPushButton("Close", self)

        row.addWidget(self.btn_analyze)
        row.addStretch(1)
        row.addWidget(self.btn_blink)
        row.addStretch(1)
        row.addWidget(self.btn_export_aligned)
        row.addStretch(1)
        row.addWidget(self.btn_stack)
        row.addWidget(self.btn_close)

        # Help button
        from setiastro.saspro.help_support import make_help_button
        row.addWidget(make_help_button("planetary_stacker", self))

        left.addLayout(row, 0)

        # --- Progress ---
        self.prog = QProgressBar(self)
        self.prog.setRange(0, 0)
        self.prog.setVisible(False)
        left.addWidget(self.prog, 0)

        self.lbl_prog = QLabel("", self)
        self.lbl_prog.setStyleSheet("color:#aaa;")
        self.lbl_prog.setVisible(False)
        left.addWidget(self.lbl_prog, 0)

        left.addStretch(1)

        # =========================
        # RIGHT COLUMN
        # =========================

        gbQ = QGroupBox("Quality", self)
        vQ = QVBoxLayout(gbQ)
        vQ.setContentsMargins(8, 8, 8, 8)
        vQ.setSpacing(6)

        self.graph = QualityGraph(self)
        self.graph.setMinimumHeight(180)
        self.graph.setMinimumWidth(480)

        self.lbl_graph_hint = QLabel("Tip: click the graph to set Keep cutoff.", self)
        self.lbl_graph_hint.setStyleSheet("color:#888; font-size:11px;")
        self.lbl_graph_hint.setWordWrap(True)

        vQ.addWidget(self.graph, 1)
        vQ.addWidget(self.lbl_graph_hint, 0)

        right.addWidget(gbQ, 1)

        gbL = QGroupBox("Log", self)
        vL = QVBoxLayout(gbL)
        vL.setContentsMargins(8, 8, 8, 8)

        self.log = QTextEdit(self)
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(140)
        self.log.setPlaceholderText("Log…")

        vL.addWidget(self.log, 1)
        right.addWidget(gbL, 1)

        # =========================
        # Signals / wiring
        # =========================

        self.btn_close.clicked.connect(self.close)
        self.btn_stack.clicked.connect(self._start_stack)
        self.btn_blink.clicked.connect(self._blink_keepers)
        self.cmb_track.currentIndexChanged.connect(self._update_anchor_warning)
        self.cmb_track.currentIndexChanged.connect(self._update_center_planet_ui)
        self.chk_debayer.toggled.connect(lambda _: self._update_center_planet_ui())
        self.btn_analyze.clicked.connect(self._start_analyze)
        self.btn_edit_aps.clicked.connect(self._edit_aps)
        self.spin_keep.valueChanged.connect(self._on_keep_changed)
        self.btn_set_disk.clicked.connect(self._set_derotation_disk)
        self.chk_derotate.toggled.connect(lambda _: self._update_derot_ui())
        self.spin_derot_rate.valueChanged.connect(lambda _: self._update_derot_ui())
        self.chk_field_rotation.toggled.connect(
            lambda checked: self.spin_field_rot_max.setEnabled(checked)
        )
        self.spin_keep.valueChanged.connect(self._update_graph_cutoff)

        def _apply_derot_preset():
            key = self.cmb_derot_planet.currentText().strip()
            base = float(_PLANET_ROT_PRESETS_DEG_PER_MIN.get(key, 0.0))

            is_custom = (key.lower().startswith("custom"))
            self.spin_derot_rate.setEnabled(bool(self.chk_derotate.isChecked()) and is_custom)

            if not is_custom:
                rate = -base if self.chk_derot_reverse.isChecked() else base
                block = self.spin_derot_rate.blockSignals(True)
                try:
                    self.spin_derot_rate.setValue(float(rate))
                finally:
                    self.spin_derot_rate.blockSignals(block)

            self._update_derot_ui()

        self.cmb_derot_planet.currentIndexChanged.connect(lambda _=None: _apply_derot_preset())
        self.chk_derot_reverse.toggled.connect(lambda _=None: _apply_derot_preset())
        self.btn_export_aligned.clicked.connect(self._export_aligned_clicked)

        def _on_graph_keep_changed(k: int, total: int):
            total = max(1, int(total))
            k = max(1, min(total, int(k)))
            pct = 100.0 * float(k) / float(total)

            block = self.spin_keep.blockSignals(True)
            try:
                self.spin_keep.setValue(float(pct))
            finally:
                self.spin_keep.blockSignals(block)

            self._update_graph_cutoff()
            self._append_log(f"Keep set from graph: {pct:.1f}% ({k}/{total})")

        self.graph.keepChanged.connect(_on_graph_keep_changed)
        self._update_center_planet_ui()

    # ---------------- helpers ----------------
    def _update_center_planet_ui(self):
        is_planetary = self._track_mode_value() == "planetary"
        self.chk_center_planet.setEnabled(is_planetary)
        if not is_planetary:
            self.chk_center_planet.setChecked(False)
        self.chk_atm_dispersion.setEnabled(
            is_planetary and bool(self.chk_debayer.isChecked()))
        if not is_planetary:
            self.chk_atm_dispersion.setChecked(False)

    def _edit_aps(self):
        if self._analysis is None:
            return

        try:
            dlg = APEditorDialog(
                self,
                ref_img01=self._analysis.ref_image,
                ap_size=int(self.spin_ap_size.value()),
                ap_spacing=int(self.spin_ap_spacing.value()),
                ap_min_mean=float(self.spin_ap_min.value()),
                initial_centers=getattr(self._analysis, "ap_centers", None),
            )
            if dlg.exec() == QDialog.DialogCode.Accepted:
                centers = dlg.ap_centers()
                self._analysis.ap_centers = centers

                try:
                    self.spin_ap_size.setValue(int(dlg.ap_size()))
                    self.spin_ap_spacing.setValue(int(dlg.ap_spacing()))
                    self.spin_ap_min.setValue(float(dlg.ap_min_mean()))
                except Exception:
                    pass

                self._append_log(
                    f"APs set: {int(centers.shape[0])} points   "
                    f"(size={int(self.spin_ap_size.value())}, spacing={int(self.spin_ap_spacing.value())})"
                )

                cfg = self._make_cfg()

                self.lbl_prog.setVisible(True)
                self.prog.setVisible(True)
                self.prog.setRange(0, 100)
                self.prog.setValue(0)
                self.lbl_prog.setText("Re-aligning with APs…")
                self.btn_stack.setEnabled(False)
                self.btn_analyze.setEnabled(False)
                self.btn_edit_aps.setEnabled(False)
                self.btn_blink.setEnabled(False)
                self.btn_export_aligned.setEnabled(False)

                self._worker_realign = _ReAlignWorker(cfg, self._analysis, debayer=bool(self.chk_debayer.isChecked()), to_rgb=False)
                self._worker_realign.progress.connect(self._on_analyze_progress)
                self._worker_realign.finished_ok.connect(self._on_realign_ok)
                self._worker_realign.failed.connect(self._on_analyze_fail)
                self._worker_realign.start()
            else:
                self._append_log("AP edit cancelled.")
        except Exception as e:
            tb = traceback.format_exc()
            QMessageBox.critical(self, "AP Editor Error", f"{e}\n\n{tb}")
            self._append_log(f"AP editor failed: {e}")
            self._append_log(tb)

    def _on_realign_ok(self, ar: AnalyzeResult):
        self._analysis = ar

        self.prog.setVisible(False)
        self.lbl_prog.setVisible(False)

        self.btn_stack.setEnabled(True)
        self.btn_analyze.setEnabled(True)
        self.btn_edit_aps.setEnabled(True)
        self.btn_blink.setEnabled(True)
        self.btn_close.setEnabled(True)
        self.btn_export_aligned.setEnabled(True)

        self._append_log("Re-align done (dx/dy/conf updated from APs).")

    def _export_aligned_clicked(self):
        if self._analysis is None:
            return

        cfg = self._make_cfg()
        N = int(self._analysis.frames_total)

        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QRadioButton, QDialogButtonBox, QFileDialog
        sel_dlg = QDialog(self)
        sel_dlg.setWindowTitle("Export Aligned SER")
        vl = QVBoxLayout(sel_dlg)
        rb_all = QRadioButton(f"All frames ({N})", sel_dlg)
        keep_k = max(1, min(N, int(round(N * float(self.spin_keep.value()) / 100.0))))
        rb_keep = QRadioButton(f"Keep % only ({keep_k} frames)", sel_dlg)
        rb_all.setChecked(True)
        from PyQt6.QtWidgets import QCheckBox as _QCB
        chk_field_rot = _QCB("Apply field rotation correction", sel_dlg)
        chk_field_rot.setChecked(bool(getattr(self, "chk_field_rotation", None) and self.chk_field_rotation.isChecked()))
        chk_planet_derot = _QCB("Apply planet axial derotation", sel_dlg)
        chk_planet_derot.setChecked(bool(getattr(self._analysis, "planet_derotate", False)))
        chk_local_warp = _QCB("Apply local AP warp", sel_dlg)
        chk_local_warp.setChecked(True)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, sel_dlg)
        bb.accepted.connect(sel_dlg.accept)
        bb.rejected.connect(sel_dlg.reject)
        for w in (rb_all, rb_keep, chk_field_rot, chk_planet_derot, chk_local_warp, bb):
            vl.addWidget(w)
        if sel_dlg.exec() != QDialog.DialogCode.Accepted:
            return

        frame_indices = None
        if rb_keep.isChecked():
            order = np.asarray(self._analysis.order, np.int32)
            frame_indices = order[:keep_k].tolist()

        src = self._source
        if isinstance(src, str) and src:
            default_dir = os.path.dirname(src)
            default_name = os.path.splitext(os.path.basename(src))[0] + "_aligned.ser"
        else:
            default_dir = ""
            default_name = "aligned.ser"

        out_path, _ = QFileDialog.getSaveFileName(
            self, "Save Aligned SER",
            os.path.join(default_dir, default_name),
            "SER Videos (*.ser)"
        )
        if not out_path:
            return
        if not out_path.lower().endswith(".ser"):
            out_path += ".ser"

        self.btn_export_aligned.setEnabled(False)
        self.btn_analyze.setEnabled(False)
        self.btn_stack.setEnabled(False)
        self.btn_close.setEnabled(False)
        self.lbl_prog.setVisible(True)
        self.prog.setVisible(True)
        self.prog.setRange(0, 100)
        self.prog.setValue(0)
        self.lbl_prog.setText("Exporting aligned SER…")
        self._append_log(f"Exporting aligned SER → {os.path.basename(out_path)}")

        self._worker_export = _ExportAlignedWorker(
            cfg, self._analysis, out_path,
            debayer=bool(self.chk_debayer.isChecked()),
            frame_indices=frame_indices,
            apply_field_rotation=bool(chk_field_rot.isChecked()),
            apply_planet_derotation=bool(chk_planet_derot.isChecked()),
            apply_local_warp=bool(chk_local_warp.isChecked()),
        )
        self._worker_export.progress.connect(self._on_analyze_progress)
        self._worker_export.finished_ok.connect(self._on_export_aligned_ok)
        self._worker_export.failed.connect(self._on_export_aligned_fail)
        self._worker_export.start()

    def _on_export_aligned_ok(self, out_path: str):
        self.prog.setVisible(False)
        self.lbl_prog.setVisible(False)
        self.btn_export_aligned.setEnabled(True)
        self.btn_analyze.setEnabled(True)
        self.btn_stack.setEnabled(True)
        self.btn_close.setEnabled(True)
        self._append_log(f"Export done: {os.path.basename(out_path)}")
        self._append_log("Tip: load this SER with Tracking=Off for fast restacking.")
        QMessageBox.information(self, "Export Aligned SER",
            f"Saved aligned SER:\n{out_path}\n\n"
            "To restack this file quickly:\n"
            "  1. Open it in the Planetary Stacker\n"
            "  2. Set Tracking = Off\n"
            "  3. Run Analyze (fast — no shift computation)\n"
            "  4. Stack Now\n\n"
            "Alignment is already baked in — Analyze just scores quality\n"
            "and places AP points for the local warp.")
        
    def _on_export_aligned_fail(self, msg: str):
        self.prog.setVisible(False)
        self.lbl_prog.setVisible(False)
        self.btn_export_aligned.setEnabled(True)
        self.btn_analyze.setEnabled(True)
        self.btn_stack.setEnabled(True)
        self.btn_close.setEnabled(True)
        self._append_log("EXPORT FAILED:")
        self._append_log(msg)

    def _append_log(self, s: str):
        try:
            self.log.append(s)
        except Exception:
            pass

    def _track_mode_value(self) -> str:
        t = self.cmb_track.currentText().strip().lower()
        if t.startswith("planet"):
            return "planetary"
        if t.startswith("surface"):
            return "surface"
        return "off"

    def _sync_from_viewer(self):
            """Re-pull ROI / surface anchor from the parent viewer (non-modal: they can change)."""
            v = self.parent()
            if v is None:
                return
            try:
                if hasattr(v, "get_surface_anchor"):
                    a = v.get_surface_anchor()
                    a = tuple(int(t) for t in a) if a is not None else None
                    if a != self._surface_anchor:
                        self._surface_anchor = a
                        self._analysis = None
                        self._keep_mask = None
                        self._append_log(f"Surface anchor synced from viewer: {a}")
                if hasattr(v, "get_roi"):
                    r = v.get_roi()
                    r = tuple(int(t) for t in r) if r is not None else None
                    if r != self._roi:
                        self._roi = r
                        self._analysis = None
                        self._keep_mask = None
                        self._append_log(f"ROI synced from viewer: {r if r is not None else '(full frame)'}")
            except Exception:
                pass
            self._update_anchor_warning()

    def _update_anchor_warning(self):
        mode = self._track_mode_value()
        if mode != "surface":
            self.lbl_anchor.setText("(not used)")
            self.lbl_anchor.setStyleSheet("color:#888;")
            return

        if self._surface_anchor is None:
            self.lbl_anchor.setText(f"REQUIRED (set in SER Viewer with {ANCHOR_GESTURE_SHORT})")
            self.lbl_anchor.setStyleSheet("color:#c66;")
            return

        x, y, w, h = [int(v) for v in self._surface_anchor]

        txt = f"✅ ROI-space: x={x}, y={y}, w={w}, h={h}"

        if self._roi is not None:
            rx, ry, rw, rh = [int(v) for v in self._roi]
            fx = rx + x
            fy = ry + y
            txt += f"   |   Full-frame: x={fx}, y={fy}, w={w}, h={h}"

        self.lbl_anchor.setText(txt)
        self.lbl_anchor.setStyleSheet("color:#4a4;")


    # ---------------- actions ----------------
    def _start_analyze(self):
        self._sync_from_viewer()
        mode = self._track_mode_value()
        if mode == "surface" and self._surface_anchor is None:
            self._append_log(f"Surface mode requires an anchor. Set it in the viewer ({ANCHOR_GESTURE_SHORT}).")
            return

        ref_mode = "best_stack" if self.cmb_ref.currentText().lower().startswith("best stack") else "best_frame"
        refN = int(self.spin_refN.value()) if ref_mode == "best_stack" else 1

        cfg = self._make_cfg()

        self.btn_analyze.setEnabled(False)
        self.btn_stack.setEnabled(False)
        self.btn_close.setEnabled(False)
        self.btn_blink.setEnabled(False)
        self.btn_export_aligned.setEnabled(False)
        self.lbl_prog.setVisible(True)
        self.lbl_prog.setText("Analyzing…")
        self.prog.setVisible(True)
        self.prog.setRange(0, 100)
        self.prog.setValue(0)

        self._worker_analyze = _AnalyzeWorker(
            cfg,
            debayer=bool(self.chk_debayer.isChecked()),
            to_rgb=False,
            ref_mode=ref_mode,
            ref_count=refN,
        )
        self._worker_analyze.finished_ok.connect(self._on_analyze_ok)
        self._worker_analyze.failed.connect(self._on_analyze_fail)
        self._worker_analyze.progress.connect(self._on_analyze_progress)
        self._worker_analyze.log_msg.connect(self._append_log) 
        self._worker_analyze.start()


    def _on_analyze_progress(self, done: int, total: int, phase: str):
        total = max(1, int(total))
        done = max(0, min(total, int(done)))
        pct = int(round(100.0 * done / total))
        self.prog.setRange(0, 100)
        self.prog.setValue(pct)
        self.lbl_prog.setText(f"{phase}: {done}/{total} ({pct}%)")


    def _on_analyze_ok(self, ar: AnalyzeResult):
        self._analysis = ar

        self.prog.setVisible(False)
        self.lbl_prog.setVisible(False)
        self.btn_set_disk.setEnabled(True)

        self.btn_analyze.setEnabled(True)
        self.btn_stack.setEnabled(True)
        self.btn_blink.setEnabled(True)
        self.btn_close.setEnabled(True)
        self.btn_export_aligned.setEnabled(True)     

        self._append_log(f"Analyze done. frames={ar.frames_total}  track={ar.track_mode}")
        self._append_log(f"Ref: {ar.ref_mode} (N={ar.ref_count})")

        k = int(round(ar.frames_total * (float(self.spin_keep.value()) / 100.0)))
        k = max(1, min(ar.frames_total, k))
        q_sorted = ar.quality[ar.order]
        self.graph.set_data(q_sorted, keep_k=k)
        self.btn_edit_aps.setEnabled(True)

    def _on_analyze_fail(self, msg: str):
        self.prog.setVisible(False)
        self.lbl_prog.setVisible(False)

        self.btn_analyze.setEnabled(True)
        had_analysis = self._analysis is not None and getattr(self._analysis, "ref_image", None) is not None
        self.btn_stack.setEnabled(bool(had_analysis))
        self.btn_edit_aps.setEnabled(bool(had_analysis))
        self.btn_close.setEnabled(True)

        self._append_log("ANALYZE FAILED:")
        self._append_log(msg)

    def _update_graph_cutoff(self):
        if self._analysis is None:
            return
        n = int(self._analysis.frames_total)
        k = int(round(n * (float(self.spin_keep.value()) / 100.0)))
        k = max(1, min(n, k))
        q_sorted = self._analysis.quality[self._analysis.order]
        self.graph.set_data(q_sorted, keep_k=k)

    def _blink_keepers(self):
        if self._analysis is None:
            return

        N = int(self._analysis.frames_total)
        keep_k = int(round(N * (float(self.spin_keep.value()) / 100.0)))
        keep_k = max(1, min(N, keep_k))

        cfg = self._make_cfg()
        cfg.keep_mask = getattr(cfg, "keep_mask", None)

        try:
            dlg = BlinkKeepersDialog(
                self,
                cfg=cfg,
                analysis=self._analysis,
                debayer=bool(self.chk_debayer.isChecked()),
                to_rgb=False,
                keep_k=keep_k,
            )
            if dlg.exec() == QDialog.DialogCode.Accepted:
                km = dlg.keep_mask_all_frames()
                self._keep_mask = km

                kept = int(np.count_nonzero(km))
                self._append_log(f"Blink Keepers: kept {kept}/{N} after manual rejects.")
            else:
                self._append_log("Blink Keepers cancelled (no changes).")
        except Exception as e:
            tb = traceback.format_exc()
            QMessageBox.critical(self, "Blink Keepers Error", f"{e}\n\n{tb}")
            self._append_log(f"Blink Keepers failed: {e}")
            self._append_log(tb)

    def _make_cfg(self) -> SERStackConfig:
        scale_text = self.cmb_drizzle.currentText()
        if "1.5" in scale_text:
            drizzle_scale = 1.5
        elif "4" in scale_text:
            drizzle_scale = 4.0
        elif "3" in scale_text:
            drizzle_scale = 3.0
        elif "2" in scale_text:
            drizzle_scale = 2.0
        else:
            drizzle_scale = 1.0

        drizzle_kernel = "gaussian"

        cfg = SERStackConfig(
            source=self._source,
            roi=self._roi,
            track_mode=self._track_mode_value(),
            surface_anchor=self._surface_anchor,
            keep_percent=float(self.spin_keep.value()),
            bayer_pattern=self._bayer_pattern,
            keep_mask=getattr(self, "_keep_mask", None),

            ap_size=int(self.spin_ap_size.value()),
            ap_spacing=int(self.spin_ap_spacing.value()),
            ap_min_mean=float(self.spin_ap_min.value()),
            ap_multiscale=(self.cmb_ap_scale.currentIndex() == 1),
            ssd_refine_bruteforce=bool(
                getattr(self, "chk_ssd_bruteforce", None)
                and self.chk_ssd_bruteforce.isChecked()
            ),
            correct_field_rotation=bool(
                getattr(self, "chk_field_rotation", None)
                and self.chk_field_rotation.isChecked()
            ),
            correct_atm_dispersion=bool(
                getattr(self, "chk_atm_dispersion", None)
                and self.chk_atm_dispersion.isChecked()
            ),

            field_rotation_max_deg=float(
                getattr(self, "spin_field_rot_max", None).value()
                if getattr(self, "spin_field_rot_max", None) else 10.0
            ),
            field_rotation_step_deg=0.5,

            planet_smooth_sigma=1.5,
            planet_simple_thresh=self._planet_simple_thresh,
            planet_use_norm=self._planet_use_norm,
            center_on_planet=bool(
                getattr(self, "chk_center_planet", None)
                and self.chk_center_planet.isChecked()
            ),
            derotate_enabled=bool(
                getattr(self, "chk_derotate", None) and self.chk_derotate.isChecked()
            ),
            derotate_deg_per_min=float(
                getattr(self, "spin_derot_rate", None).value()
            ) if getattr(self, "spin_derot_rate", None) else 0.0,
            derotate_center=(float(self._derot["cx"]), float(self._derot["cy"])) if self._derot else None,
            derotate_radius=float(self._derot["r"]) if self._derot else None,
            derotate_overlay_mode=str(self._derot.get("overlay_mode", "none")) if self._derot else "none",
            derotate_rings=(
                float(self._derot.get("ring_pa", 0.0)),
                float(self._derot.get("ring_tilt", 0.35)),
                float(self._derot.get("ring_outer", 2.2)),
                float(self._derot.get("ring_inner", 1.25)),
            ) if self._derot else None,

            drizzle_scale=float(drizzle_scale),
            drizzle_pixfrac=float(self.spin_pixfrac.value()),
            drizzle_kernel=str(drizzle_kernel),
            drizzle_sigma=float(self.spin_sigma.value()),
        )
        # ---- Flat calibration: attach via attribute so old SERStackConfig
        # dataclasses (without these fields) still work ------------------
        try:
            cfg.flat_enabled = bool(getattr(self, "_flat_enabled", False))
            cfg.flat_path = getattr(self, "_flat_path", None)
            cfg.flat_stack_method = str(getattr(self, "_flat_method", "median")).lower()
        except Exception:
            pass
        return cfg

    def _on_keep_changed(self, _v):
        self._keep_mask = None

    def _update_derot_ui(self):
        en = bool(self.chk_derotate.isChecked())
        self.spin_derot_rate.setEnabled(en)
        self.btn_set_disk.setEnabled(en and (self._analysis is not None))
        if not en:
            self.lbl_derot_disk.setText("(disabled)")
            self.lbl_derot_disk.setStyleSheet("color:#888;")
        else:
            if self._derot is None:
                self.lbl_derot_disk.setText("⚠️ Set disk center/radius (uses Analyze ref image)")
                self.lbl_derot_disk.setStyleSheet("color:#c66;")
            else:
                cx, cy, r = self._derot["cx"], self._derot["cy"], self._derot["r"]
                self.lbl_derot_disk.setText(f"✅ cx={cx:.1f}, cy={cy:.1f}, r={r:.1f} (ROI-space)")
                self.lbl_derot_disk.setStyleSheet("color:#4a4;")

    def _set_derotation_disk(self):
        if self._analysis is None:
            return
        try:
            from setiastro.saspro.planetprojection import pick_planet_disk_params

            ref = np.asarray(self._analysis.ref_image)
            if ref.ndim == 2:
                ref_rgb = np.dstack([ref, ref, ref])
            elif ref.ndim == 3 and ref.shape[2] == 1:
                ref_rgb = np.dstack([ref[...,0]]*3)
            else:
                ref_rgb = ref[..., :3]

            seed = self._derot or {}
            res = pick_planet_disk_params(
                self,
                ref_rgb,
                cx=seed.get("cx"),
                cy=seed.get("cy"),
                r=seed.get("r"),
                overlay_mode="planet",
                ring_pa=seed.get("ring_pa", 0.0),
                ring_tilt=seed.get("ring_tilt", 0.35),
                ring_outer=seed.get("ring_outer", 2.2),
                ring_inner=seed.get("ring_inner", 1.25),
            )
            if res is None:
                return
            self._derot = res
            self._update_derot_ui()
            self._append_log("Derotation disk set.")
        except Exception as e:
            tb = traceback.format_exc()
            QMessageBox.critical(self, "Derotation Disk Error", f"{e}\n\n{tb}")


    def _start_stack(self):
        self._sync_from_viewer()
        mode = self._track_mode_value()
        if mode == "surface" and self._surface_anchor is None:
            self._append_log(f"Surface mode requires an anchor. Set it in the viewer ({ANCHOR_GESTURE_SHORT}).")
            return
        if self._analysis is None:
            QMessageBox.warning(
                self, "Analyze Required",
                "Please run Analyze first.\n\n"
                "Even with Tracking=Off, Analyze is needed to score frame quality\n"
                "and place alignment points for the local warp.")
            return
        cfg = self._make_cfg()
        cfg.keep_mask = self._keep_mask
        debayer = bool(self.chk_debayer.isChecked())
        if cfg.derotate_enabled and (cfg.derotate_center is None or cfg.derotate_radius is None):
            self._append_log("Derotation enabled but disk is not set. Click 'Set disk…'")
            return
        self.btn_stack.setEnabled(False)
        self.btn_close.setEnabled(False)
        self.btn_analyze.setEnabled(False)
        self.btn_blink.setEnabled(False)
        self.btn_edit_aps.setEnabled(False)
        self.btn_export_aligned.setEnabled(False)
        scale_text = self.cmb_drizzle.currentText()
        if "1.5" in scale_text:
            drizzle_scale = 1.5
        elif "2" in scale_text:
            drizzle_scale = 2.0
        else:
            drizzle_scale = 1.0

        drizzle_kernel = "gaussian"
        drizzle_pixfrac = float(self.spin_pixfrac.value())
        drizzle_sigma = float(self.spin_sigma.value())
        self.lbl_prog.setVisible(True)
        self.prog.setVisible(True)
        self.prog.setRange(0, 100)
        self.prog.setValue(0)
        self.lbl_prog.setText("Stack: 0%")

        self._append_log("Stacking...")

        self._worker = _StackWorker(cfg, analysis=self._analysis, debayer=debayer, to_rgb=False)
        self._worker.progress.connect(self._on_analyze_progress)
        self._worker.finished_ok.connect(self._on_stack_ok)
        self._worker.failed.connect(self._on_stack_fail)
        self._worker.start()

    def _on_stack_ok(self, out, diag):
        self._last_out = out
        self._last_diag = diag

        self.prog.setVisible(False)
        self.lbl_prog.setVisible(False)

        self.btn_stack.setEnabled(True)
        self.btn_close.setEnabled(True)
        self.btn_analyze.setEnabled(True)
        self.btn_edit_aps.setEnabled(True)

        self._append_log(f"Done. Kept {diag.get('frames_kept')} / {diag.get('frames_total')}")
        self._append_log(f"Track: {diag.get('track_mode')}  ROI: {diag.get('roi_used')}")

        newdoc = _push_as_new_doc(
            self._main,
            self._source_doc,
            out,
            title_suffix="_stack",
            source="Planetary Stacker",
            source_path=self._source,
        )

        if newdoc is not None:
            try:
                md = getattr(newdoc, "metadata", None)
                if md is None:
                    md = {}
                    setattr(newdoc, "metadata", md)
                md["ser_stack_diag"] = diag
            except Exception:
                pass

        self.stackProduced.emit(out, diag)

    def _on_stack_fail(self, msg: str):
        self.prog.setVisible(False)
        self.btn_stack.setEnabled(True)
        self.btn_close.setEnabled(True)
        self.btn_analyze.setEnabled(True)
        self._append_log("FAILED:")
        self._append_log(msg)

    def showEvent(self, e):
        super().showEvent(e)
        self._sync_from_viewer()

    def event(self, e):
        if e.type() == QEvent.Type.WindowActivate:
            self._sync_from_viewer()
        return super().event(e)

class BlinkKeepersDialog(QDialog):
    """
    Blink through the frames currently selected to keep, allow user to reject any.
    Returns a keep_mask (bool) for ALL frames, True=keep.
    """
    def __init__(self, parent=None, *, cfg: SERStackConfig, analysis: AnalyzeResult,
                 debayer: bool, to_rgb: bool, keep_k: int):
        super().__init__(parent)
        self.setWindowTitle("Blink Keepers")
        self.resize(1000, 750)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setFocus()
        self.cfg = cfg
        self.analysis = analysis
        self.debayer = bool(debayer)
        self.to_rgb = bool(to_rgb)

        self.N = int(analysis.frames_total)
        keep_k = max(1, min(self.N, int(keep_k)))

        self.keepers = np.asarray(analysis.order[:keep_k], dtype=np.int32)
        self.rejected = np.zeros((self.keepers.size,), dtype=bool)

        # ---- UI ----
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)
        outer.setSpacing(8)

        self.lbl = QLabel(self)
        self.lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl.setStyleSheet("background:#111;")
        self.lbl.setMinimumHeight(480)
        outer.addWidget(self.lbl, 1)
        self.lbl_help = QLabel(self)
        self.lbl_help.setWordWrap(True)
        self.lbl_help.setStyleSheet(
            "color:#9aa; background:#151515; border:1px solid #2a2a2a;"
            "border-radius:6px; padding:6px; font-size:11px;"
        )
        self.lbl_help.setText(
            "Shortcuts: "
            "←/→ (or ↑/↓) = Prev/Next   |   PgUp/PgDn = Prev/Next\n"
            "R or Space = Toggle Reject + Next   |   Backspace = Toggle Reject + Prev\n"
            "Esc = Cancel   |   Enter = OK"
        )
        outer.addWidget(self.lbl_help, 0)
        info_row = QHBoxLayout()
        self.lbl_info = QLabel("", self)
        self.lbl_info.setStyleSheet("color:#bbb;")
        self.lbl_info.setWordWrap(True)
        info_row.addWidget(self.lbl_info, 1)

        self.btn_toggle = QPushButton("Reject", self)
        self.btn_toggle.setCheckable(True)
        info_row.addWidget(self.btn_toggle, 0)

        outer.addLayout(info_row)

        nav = QHBoxLayout()
        self.btn_prev = QPushButton("◀ Prev", self)
        self.btn_next = QPushButton("Next ▶", self)

        self.sld = QSlider(Qt.Orientation.Horizontal, self)
        self.sld.setRange(0, max(0, self.keepers.size - 1))
        self.sld.setValue(0)

        self.lbl_pos = QLabel("", self)
        self.lbl_pos.setStyleSheet("color:#aaa; min-width:90px;")

        nav.addWidget(self.btn_prev)
        nav.addWidget(self.sld, 1)
        nav.addWidget(self.btn_next)
        nav.addWidget(self.lbl_pos)
        outer.addLayout(nav)

        btns = QHBoxLayout()
        self.btn_ok = QPushButton("OK", self)
        self.btn_cancel = QPushButton("Cancel", self)
        btns.addStretch(1)
        btns.addWidget(self.btn_ok)
        btns.addWidget(self.btn_cancel)
        outer.addLayout(btns)
        disp_row = QHBoxLayout()

        self.sld_bright = QSlider(Qt.Orientation.Horizontal, self)
        self.sld_bright.setRange(-100, 100)
        self.sld_bright.setValue(0)
        self.sld_bright.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.sld_bright.setToolTip("Brightness (preview only)")

        self.lbl_bright = QLabel("Bright: 0", self)
        self.lbl_bright.setStyleSheet("color:#aaa; min-width:90px;")

        disp_row.addWidget(QLabel("Preview", self))
        disp_row.addSpacing(6)
        disp_row.addWidget(self.sld_bright, 1)
        disp_row.addWidget(self.lbl_bright, 0)

        outer.addLayout(disp_row)

        # ---- signals ----
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_ok.clicked.connect(self.accept)
        self.btn_prev.clicked.connect(lambda: self._step(-1))
        self.btn_next.clicked.connect(lambda: self._step(+1))
        self.sld.valueChanged.connect(self._show_index)
        self.btn_toggle.clicked.connect(lambda: self._toggle_reject_and_advance(+1))
        self.sld_bright.valueChanged.connect(self._on_brightness_changed)

        # ---- load source ----
        from setiastro.saspro.imageops.serloader import open_planetary_source
        self.src = open_planetary_source(
            self.cfg.source,
            cache_items=20,
        )
        self._debayer = bool(debayer)
        self._bayer_pattern = getattr(self.cfg, "bayer_pattern", None)
        self._force_rgb = True
        self.lbl.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.sld.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_prev.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_next.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn_toggle.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._preview_brightness = 0.0

        self._show_index(0)

    def _on_brightness_changed(self, v: int):
        self._preview_brightness = float(int(v)) / 100.0
        self.lbl_bright.setText(f"Bright: {int(v)}")
        self._show_index(self.sld.value())

    def _toggle_reject_at(self, idx: int):
        if 0 <= idx < self.rejected.size:
            self.rejected[idx] = ~self.rejected[idx]
            self._update_labels()

    def _toggle_reject_and_advance(self, step: int = +1):
        i = int(self.sld.value())
        if self.keepers.size <= 0:
            return

        self._toggle_reject_at(i)

        j = i + int(step)
        j = max(0, min(int(self.keepers.size) - 1, j))
        self.sld.setValue(j)

    def keyPressEvent(self, e):
        k = e.key()
        mods = e.modifiers()

        if mods & (Qt.KeyboardModifier.ControlModifier |
                Qt.KeyboardModifier.AltModifier |
                Qt.KeyboardModifier.MetaModifier):
            super().keyPressEvent(e)
            return

        if k in (Qt.Key.Key_Right, Qt.Key.Key_Down, Qt.Key.Key_PageDown):
            self._step(+1)
            e.accept()
            return

        if k in (Qt.Key.Key_Left, Qt.Key.Key_Up, Qt.Key.Key_PageUp):
            self._step(-1)
            e.accept()
            return

        if k == Qt.Key.Key_R:
            self._toggle_reject_and_advance(+1)
            e.accept()
            return

        if k == Qt.Key.Key_Space:
            self._toggle_reject_and_advance(+1)
            e.accept()
            return

        if k == Qt.Key.Key_Backspace:
            self._toggle_reject_and_advance(-1)
            e.accept()
            return
        if k == Qt.Key.Key_Escape:
            self.reject()
            e.accept()
            return
        if k in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.accept()
            e.accept()
            return
        super().keyPressEvent(e)

    def _step(self, d: int):
        i = int(self.sld.value()) + int(d)
        i = max(0, min(int(self.keepers.size) - 1, i))
        self.sld.setValue(i)

    def _toggle_reject_current(self, checked: bool):
        i = int(self.sld.value())
        if 0 <= i < self.rejected.size:
            self.rejected[i] = bool(checked)
            self._update_labels()

    def _update_labels(self):
        i = int(self.sld.value())
        fi = int(self.keepers[i]) if self.keepers.size else 0
        q = float(self.analysis.quality[fi]) if self.analysis.quality is not None else 0.0

        is_rej = bool(self.rejected[i]) if self.rejected.size else False

        self.lbl_pos.setText(f"{i+1}/{int(self.keepers.size)}")
        self.lbl_info.setText(
            f"Keeper #{i+1}  |  Frame index: {fi}  |  Quality: {q:.6g}  |  "
            f"{'REJECTED' if is_rej else 'KEEP'}"
        )

        if is_rej:
            self.lbl_info.setStyleSheet("color:#f66; font-weight:600;")
            self.lbl_pos.setStyleSheet("color:#f66; min-width:90px;")
            self.btn_toggle.setStyleSheet("background:#3a1111; color:#f66;")
        else:
            self.lbl_info.setStyleSheet("color:#bbb;")
            self.lbl_pos.setStyleSheet("color:#aaa; min-width:90px;")
            self.btn_toggle.setStyleSheet("")

        block = self.btn_toggle.blockSignals(True)
        try:
            self.btn_toggle.setChecked(is_rej)
            self.btn_toggle.setText("Un-reject" if is_rej else "Reject")
        finally:
            self.btn_toggle.blockSignals(block)

    @staticmethod
    def _disp_u8(mono01: np.ndarray, *, brightness: float = 0.0) -> np.ndarray:
        mono = np.asarray(mono01, dtype=np.float32)
        mono = np.clip(mono, 0.0, 1.0)

        lo = float(np.percentile(mono, 1.0))
        hi = float(np.percentile(mono, 99.5))
        if hi <= lo + 1e-8:
            hi = lo + 1e-3

        b = float(np.clip(brightness, -1.0, 1.0))
        span = (hi - lo)

        shift = -b * 0.50 * span
        lo2 = lo + shift
        hi2 = hi + shift

        lo2 = float(np.clip(lo2, 0.0, 1.0))
        hi2 = float(np.clip(hi2, lo2 + 1e-6, 1.0))

        v = (mono - lo2) / (hi2 - lo2)
        v = np.clip(v, 0.0, 1.0)

        return (v * 255.0 + 0.5).astype(np.uint8)

    def _show_index(self, i: int):
        if self.keepers.size == 0:
            return
        i = int(max(0, min(int(self.keepers.size) - 1, int(i))))
        fi = int(self.keepers[i])

        roi = getattr(self.cfg, "roi", None)
        img = self.src.get_frame(
            fi,
            roi=roi,
            debayer=bool(self._debayer),
            to_float01=True,
            force_rgb=bool(self._force_rgb),
            bayer_pattern=getattr(self, "_bayer_pattern", None),
        ).astype(np.float32, copy=False)
        ref_shape = getattr(self.analysis, "ref_image", None)
        if ref_shape is not None:
            from setiastro.saspro.ser_stacker import _conform_to_ref_shape
            img = _conform_to_ref_shape(img, self.analysis.ref_image.shape)

        gdx = float(self.analysis.dx[int(fi)]) if (getattr(self.analysis, "dx", None) is not None) else 0.0
        gdy = float(self.analysis.dy[int(fi)]) if (getattr(self.analysis, "dy", None) is not None) else 0.0
        img = _shift_image(img, gdx, gdy)

        ang_i = 0.0
        if getattr(self.analysis, "ang", None) is not None and self.analysis.ang is not None:
            ang_i = float(self.analysis.ang[int(fi)])

        if abs(ang_i) > 1e-6:
            track_mode = getattr(self.analysis, "track_mode", "planetary")
            ref_img = getattr(self.analysis, "ref_image", None)

            if track_mode == "planetary":
                rot_cx = float(getattr(self.analysis, "ref_cx", img.shape[1] * 0.5))
                rot_cy = float(getattr(self.analysis, "ref_cy", img.shape[0] * 0.5))
            else:
                rot_cx = float(getattr(self.analysis, "surface_anchor_rot_cx", None) or img.shape[1] * 0.5)
                rot_cy = float(getattr(self.analysis, "surface_anchor_rot_cy", None) or img.shape[0] * 0.5)

            import cv2 as _cv2
            H, W = img.shape[:2]
            M = _cv2.getRotationMatrix2D((float(rot_cx), float(rot_cy)), float(ang_i), 1.0)
            img = _cv2.warpAffine(img, M, (W, H),
                                  flags=_cv2.INTER_LINEAR,
                                  borderMode=_cv2.BORDER_CONSTANT,
                                  borderValue=0)

        if img.ndim == 3:
            img = img[..., 0]

        u8 = self._disp_u8(img, brightness=getattr(self, "_preview_brightness", 0.0))

        if not u8.flags["C_CONTIGUOUS"]:
            u8 = np.ascontiguousarray(u8)

        from PyQt6.QtGui import QImage, QPixmap
        from PyQt6.QtCore import Qt
        h, w = u8.shape
        qimg = QImage(u8.data, w, h, w, QImage.Format.Format_Grayscale8).copy()
        pm = QPixmap.fromImage(qimg)

        self.lbl.setPixmap(pm.scaled(
            self.lbl.size(),
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        ))
        self._update_labels()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._show_index(self.sld.value())

    def keep_mask_all_frames(self) -> np.ndarray:
        km = np.zeros((self.N,), dtype=bool)
        km[self.keepers] = True
        if self.keepers.size:
            km[self.keepers[self.rejected]] = False
        return km