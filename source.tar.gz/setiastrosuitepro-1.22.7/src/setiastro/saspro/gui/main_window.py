#pro.gui.main_window.py
from setiastro.saspro.runtime_torch import add_runtime_to_sys_path, _ban_shadow_torch_paths, _purge_bad_torch_from_sysmodules
add_runtime_to_sys_path(status_cb=lambda *_: None)
_ban_shadow_torch_paths(status_cb=lambda *_: None)
_purge_bad_torch_from_sysmodules(status_cb=lambda *_: None)

# ============================================================================
# Standard Library Imports
# ============================================================================
import importlib
import json
import logging
import math
import os
import re
import sys
import platform
import threading
import time
import traceback
import warnings
import webbrowser
from datetime import datetime
from decimal import getcontext
from io import BytesIO
from itertools import combinations
from math import isnan
from pathlib import Path
from typing import List, Tuple, Dict, Set, Optional
from urllib.parse import quote, quote_plus

# ============================================================================
# Third-Party Imports
# ============================================================================
import numpy as np
import matplotlib
# tifffile and XISF imports removed (unused in this file)


# ============================================================================
# Bootstrap Configuration (must run early)
# ============================================================================
from setiastro.saspro.config_bootstrap import ensure_mpl_config_dir
from setiastro.saspro.metadata_patcher import apply_metadata_patches

# Apply matplotlib configuration
_MPL_CFG_DIR = ensure_mpl_config_dir()

# Apply metadata patches for frozen builds
apply_metadata_patches()

# Configure matplotlib backend
matplotlib.use("QtAgg")

# Configure warnings
warnings.filterwarnings(
    "ignore",
    message=r"Call to deprecated function \(or staticmethod\) _destroy\.",
    category=DeprecationWarning
)

# Configure lightkurve style
os.environ['LIGHTKURVE_STYLE'] = 'default'

# Configure stdout encoding if available
if (sys.stdout is not None) and (hasattr(sys.stdout, "reconfigure")):
    sys.stdout.reconfigure(encoding='utf-8')

# ============================================================================
# Lazy Imports for Heavy Dependencies
# ============================================================================
from setiastro.saspro.lazy_imports import (
    get_photutils_isophote,
    get_Ellipse,
    get_EllipseGeometry,
    get_build_ellipse_model,
    get_lightkurve,
    get_reproject_interp,
    lazy_cv2,
)

# scipy.ndimage imports removed - not used in main module
# gaussian_filter, laplace, zoom loaded on demand in specific modules

# ============================================================================
# Shared UI Utilities
# ============================================================================
from setiastro.saspro.widgets.common_utilities import (
    AboutDialog,
    ProjectSaveWorker as _ProjectSaveWorker,
    DECOR_GLYPHS,
    _strip_ui_decorations,
    install_crash_handlers,
)
from setiastro.saspro.gui.diagnostics_dialog import DiagnosticsReportDialog


# Reproject and OpenCV imports removed (unused or available via lazy_imports)




#################################
# PyQt6 Imports
#################################
from collections import defaultdict

from PyQt6 import sip

# ----- QtWidgets -----
from PyQt6.QtWidgets import (QDialog, QApplication, QMainWindow, QWidget, QHBoxLayout, QFileDialog, QMessageBox, QSizePolicy, QToolBar, 
    QLineEdit, QMenu, QDockWidget, QListView, QCompleter, QMdiArea, QMdiArea, QMdiSubWindow, 
    QInputDialog, QCheckBox, QProgressDialog, 
)

# ----- QtGui -----
from PyQt6.QtGui import (QPixmap, QColor, QIcon, QKeySequence, QShortcut,
     QGuiApplication, QStandardItemModel, QStandardItem, QAction, QPalette,
     QBrush, QDesktopServices, QPainter, QImage
)

# ----- QtCore -----
from PyQt6.QtCore import (Qt, pyqtSignal, QTimer, QSize, QModelIndex, QUrl, QSettings, QEvent, QByteArray, QObject,
    QPropertyAnimation, QEasingCurve, QPoint, QCoreApplication
)



# Math functions

import math


#from setiastro.saspro.subwindow import ImageSubWindow, TableSubWindow
#from setiastro.saspro.legacy.image_manager import ImageManager


from setiastro.saspro.autostretch import autostretch
from setiastro.saspro.autostretch import autostretch as _autostretch
from setiastro.saspro.rgb_extract import extract_rgb_channels
from setiastro.saspro.help_support import make_help_button


from setiastro.saspro.legacy.numba_utils import (
    rescale_image_numba,
    flip_horizontal_numba,
    flip_vertical_numba,
    rotate_90_clockwise_numba,
    rotate_90_counterclockwise_numba,
    invert_image_numba,
    rotate_180_numba,
)

try:
    from setiastro.saspro._generated.build_info import BUILD_TIMESTAMP
except Exception:
    BUILD_TIMESTAMP = "dev"




_DEBUG_DND_DUP = False



# Icon paths are now centralized in pro.resources module
from setiastro.saspro.resources import (
    icon_path, windowslogo_path, green_path, neutral_path, whitebalance_path,
    morpho_path, clahe_path, starnet_path, staradd_path, LExtract_path,
    LInsert_path, slot0_path, slot1_path, slot2_path, slot3_path, slot4_path,
    rgbcombo_path, rgbextract_path, copyslot_path, graxperticon_path,
    cropicon_path, openfile_path, abeicon_path, undoicon_path, redoicon_path,
    blastericon_path, hdr_path, invert_path, fliphorizontal_path,
    flipvertical_path, rotateclockwise_path, rotatecounterclockwise_path,
    rotate180_path, maskcreate_path, maskapply_path, maskremove_path,
    slot5_path, slot6_path, slot7_path, slot8_path, slot9_path, pixelmath_path,resizecanvas_path,
    histogram_path, mosaic_path, rescale_path, staralign_path, mask_path,
    platesolve_path, psf_path, supernova_path, starregistration_path,
    stacking_path, pedestal_icon_path, starspike_path, aperture_path, histogram_transform_path,
    jwstpupil_path, signature_icon_path, livestacking_path, hrdiagram_path,
    convoicon_path, spcc_icon_path, sasp_data_path, exoicon_path, peeker_icon,rotatearbitrary_path,
    dse_icon_path, astrobin_filters_csv_path, isophote_path, statstretch_path,
    starstretch_path, curves_path, disk_path, uhs_path, blink_path, ppp_path,gaia_path, unwarp_path,
    nbtorgb_path, freqsep_path, contsub_path, halo_path, cosmic_path,dithericon_path,flythrough_path,
    satellite_path, imagecombine_path, wrench_path, eye_icon_path,multiscale_decomp_path, nbi_path,surfacemosaic_path,
    disk_icon_path, nuke_path, hubble_path, collage_path, annotated_path, atlas_path, slap_path, satchroma_path, fx_path,
    colorwheel_path, font_path, csv_icon_path, spinner_path, wims_path, narrowbandnormalization_path,
    wimi_path, linearfit_path, debayer_path, aberration_path, acv_icon_path, snr_path,nbextract_icon,sssc_path,
    functionbundles_path, viewbundles_path, selectivecolor_path, selectivelum_path, rgbalign_path, planetarystacker_path,syqon_path,rcastro_path,
    background_path, script_icon_path, planetprojection_path,clonestampicon_path, finderchart_path,magnitude_path, cosmeticcorrection_path,
)

import faulthandler

def _install_crash_logging():
    # Ensure logging is configured before we try to use it
    if not logging.getLogger().hasHandlers():
        logging.basicConfig(
            level=logging.WARNING,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[logging.StreamHandler(sys.stderr)]
        )
    
    try:
        faulthandler.enable(all_threads=True)
    except (PermissionError, OSError) as e:
        # On macOS, faulthandler.enable() might fail due to security restrictions
        # We can still continue without it as it's primarily for debugging
        try:
            logging.warning(f"Could not enable faulthandler: {e}")
        except Exception:
            # Fallback if logging isn't configured yet
            print(f"WARNING: Could not enable faulthandler: {e}")
    
    def _excepthook(t, v, tb):
        try:
            logging.critical("Uncaught exception", exc_info=(t, v, tb))
        except Exception:
            # Fallback if logging fails
            print(f"CRITICAL: Uncaught exception: {t.__name__}: {v}")
            traceback.print_tb(tb)
        try:
            faulthandler.dump_traceback(file=sys.stderr)
        except Exception:
            pass
    sys.excepthook = _excepthook

_install_crash_logging()


from PyQt6.QtCore import qInstallMessageHandler, QtMsgType

def _qt_msg_handler(mode, ctx, msg):
    lvl = {
        QtMsgType.QtDebugMsg:    logging.DEBUG,
        QtMsgType.QtInfoMsg:     logging.INFO,
        QtMsgType.QtWarningMsg:  logging.WARNING,
        QtMsgType.QtCriticalMsg: logging.ERROR,
        QtMsgType.QtFatalMsg:    logging.CRITICAL,
    }.get(mode, logging.ERROR)
    logging.log(lvl, "Qt: %s (%s:%s)", msg, getattr(ctx, "file", "?"), getattr(ctx, "line", -1))

qInstallMessageHandler(_qt_msg_handler)

# MDI widgets imported from setiastro.saspro.mdi_widgets
from setiastro.saspro.mdi_widgets import (
    MdiArea, ViewLinkController, ConsoleListWidget, QtLogStream, _DocProxy,
    ROLE_ACTION as _ROLE_ACTION,
)

# Helper functions imported from setiastro.saspro.main_helpers
from setiastro.saspro.main_helpers import (
    safe_join_dir_and_name as _safe_join_dir_and_name,
    normalize_save_path_chosen_filter as _normalize_save_path_chosen_filter,
    display_name as _display_name,
    best_doc_name as _best_doc_name,
    doc_looks_like_table as _doc_looks_like_table,
    is_alive as _is_alive,
    safe_widget as _safe_widget,
)

# AboutDialog, DECOR_GLYPHS, _strip_ui_decorations imported from setiastro.saspro.widgets.common_utilities

# File utilities imported from setiastro.saspro.file_utils
from setiastro.saspro.file_utils import (
    _normalize_ext,
    _sanitize_filename,
    _exts_from_filter,
    REPLACE_SPACES_WITH_UNDERSCORES as _REPLACE_SPACES_WITH_UNDERSCORES,
    WIN_RESERVED_NAMES as _WIN_RESERVED,
)

# GUI Mixins for modular code organization
from setiastro.saspro.gui.mixins import (
    DockMixin, MenuMixin, ToolbarMixin, FileMixin,
    ThemeMixin, GeometryMixin, ViewMixin, HeaderMixin, MaskMixin, UpdateMixin, DockRailMixin
)

import sys
import time
import threading
import traceback
from PyQt6.QtCore import QObject, QTimer
import time
from PyQt6.QtWidgets import QApplication, QMessageBox

def qimage_to_float01_rgb(qimg: QImage) -> np.ndarray:
    """
    Convert a QImage to float32 RGB in [0,1], shape (H,W,3).
    Drops alpha if present.
    """
    if qimg.isNull():
        raise ValueError("Clipboard image is null")

    # Force to RGBA8888 so memory layout is predictable
    img = qimg.convertToFormat(QImage.Format.Format_RGBA8888)
    w = img.width()
    h = img.height()

    ptr = img.bits()
    ptr.setsize(h * w * 4)
    arr = np.frombuffer(ptr, dtype=np.uint8).reshape((h, w, 4))

    rgb = arr[..., :3].astype(np.float32) / 255.0
    return np.ascontiguousarray(rgb)

def float01_to_qimage(img: np.ndarray) -> QImage:
    """
    Convert float32 [0,1] mono or RGB numpy to QImage (8-bit).
    Intended for clipboard, not archival.
    """
    a = np.asarray(img)
    if a.ndim == 2:
        # mono -> RGB for clipboard
        a = np.repeat(a[..., None], 3, axis=2)
    elif a.ndim == 3 and a.shape[2] == 1:
        a = np.repeat(a, 3, axis=2)
    elif a.ndim != 3 or a.shape[2] < 3:
        raise ValueError(f"Unsupported image shape for clipboard: {a.shape}")

    rgb = a[..., :3]
    rgb8 = np.clip(rgb * 255.0 + 0.5, 0, 255).astype(np.uint8)

    h, w = rgb8.shape[:2]
    # QImage needs bytesPerLine
    bytes_per_line = 3 * w
    qimg = QImage(rgb8.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
    # Important: detach from numpy buffer (copy) so clipboard stays valid
    qimg = qimg.copy()
    try:
        from setiastro.saspro.color_space_manager import tag_qimage_with_working_color_space
        qimg = tag_qimage_with_working_color_space(qimg)
    except Exception:
        pass
    return qimg


class UiStallDetector(QObject):
    """
    Detects UI stalls by watching QTimer tick drift.
    On stall, prints stack traces for all threads using print().
    (No faulthandler / no fileno() required.)
    """

    def __init__(self, parent=None, interval_ms: int = 50, threshold_ms: int = 300):
        super().__init__(parent)
        self.interval_ms = int(interval_ms)
        self.threshold_ms = int(threshold_ms)
        self._last = time.perf_counter()
        self._stall_seq = 0

        # cooldown state (instance-level)
        self._last_dump_t = 0.0

        self._timer = QTimer(self)
        self._timer.setInterval(self.interval_ms)
        self._timer.timeout.connect(self._tick)

    def start(self):
        self._last = time.perf_counter()
        self._timer.start()

    def stop(self):
        self._timer.stop()

    def _dump_all_threads_print(self):
        now = time.perf_counter()
        if now - self._last_dump_t < 2.0:  # 2s cooldown
            print("[UI STALL] dump skipped (cooldown)", flush=True)
            return
        self._last_dump_t = now

        frames = sys._current_frames()
        main_ident = threading.main_thread().ident

        print("[UI STALL] ===== lightweight dump (all threads) =====", flush=True)

        # Main thread: full stack
        if main_ident in frames:
            print("\n--- MainThread (full) ---", flush=True)
            print("".join(traceback.format_stack(frames[main_ident])), flush=True)

        # Other threads: only top-frame summary
        for t in threading.enumerate():
            if t.ident is None or t.ident == main_ident:
                continue
            f = frames.get(t.ident)
            if not f:
                continue
            code = f.f_code
            print(
                f"--- Thread {t.ident} ({t.name}) top --- {code.co_filename}:{f.f_lineno} in {code.co_name}",
                flush=True,
            )

        print("[UI STALL] ===== end lightweight dump =====", flush=True)

    def _tick(self):
        now = time.perf_counter()
        elapsed_ms = (now - self._last) * 1000.0
        self._last = now

        late_ms = elapsed_ms - self.interval_ms
        if late_ms >= self.threshold_ms:
            print(f"[UI STALL] tick late by {late_ms:.0f} ms (elapsed={elapsed_ms:.0f} ms)", flush=True)
            self._dump_all_threads_print()

def _strip_filename_ext(title: str) -> str:
    t = (title or "").strip()
    if not t:
        return t
    base, ext = os.path.splitext(t)
    # treat as extension only if it looks like one: .fit .fits .tif .tiff .xisf etc
    if ext and 1 <= len(ext) <= 10 and all(ch.isalnum() for ch in ext[1:]):
        return base
    return t



_DECOR_GLYPHS = "■●◆▲▪▫•◼◻◾◽🔗"

def normalize_doc_title(s: str) -> str:
    s = (s or "").strip()

    # remove our textual prefix too
    if s.startswith("[LINK] "):
        s = s[len("[LINK] "):].strip()

    # strip common UI decorations if you already have this helper
    try:
        s = _strip_ui_decorations(s)
    except Exception:
        pass

    # remove any leading decorator glyphs repeatedly: "🔗 ", "■ ", etc.
    while len(s) >= 2 and s[0] in _DECOR_GLYPHS and s[1] == " ":
        s = s[2:].lstrip()

    # also remove any stray decorator glyphs that got embedded (rare but happens)
    s = re.sub(rf"[{re.escape(_DECOR_GLYPHS)}]", "", s).strip()

    return s

_VIEW_SUFFIX_RE = re.compile(r"\s+\[View\s+\d+\]\s*$")

def _normalize_title_for_compare(t: str) -> str:
    t = (t or "").strip()
    if not t:
        return ""

    # strip UI decorations (🔗, ■, etc)
    try:
        t = _strip_ui_decorations(t)
    except Exception:
        pass

    # strip trailing "[View N]" if present
    t = _VIEW_SUFFIX_RE.sub("", t).strip()

    # strip filename-like extension
    try:
        t = _strip_filename_ext(t)
    except Exception:
        # fallback: only strip if it looks like an ext
        base, ext = os.path.splitext(t)
        if ext and len(ext) <= 10:
            t = base

    return t.strip()

class AstroSuiteProMainWindow(
    DockMixin, DockRailMixin, MenuMixin, ToolbarMixin, FileMixin,
    ThemeMixin, GeometryMixin, ViewMixin, HeaderMixin, MaskMixin, UpdateMixin,
    QMainWindow
):
    currentDocumentChanged = pyqtSignal(object)  # ImageDocument | None

    def __init__(self, image_manager=None, parent=None,
                 version: str = "dev", build_timestamp: str = "dev"):
        super().__init__(parent)
        # Prevent white flash: start strictly transparent and force dark bg
        from PyQt6.QtGui import QGuiApplication

        def _is_wayland() -> bool:
            try:
                plat = (QGuiApplication.platformName() or "").lower()
                if "wayland" in plat:
                    return True
            except Exception:
                pass
            # fallback env checks
            return bool(os.environ.get("WAYLAND_DISPLAY")) and not bool(os.environ.get("DISPLAY"))

        # Prevent white flash: start strictly transparent and force dark bg
        if not _is_wayland():
            self.setWindowOpacity(0.0)
        self.setStyleSheet("QMainWindow { background-color: #0F0F19; }")

        self.setStyleSheet("QMainWindow { background-color: #0F0F19; }")
        #self._stall = UiStallDetector(self, interval_ms=50, threshold_ms=250)
        #self._stall.start()
        # --- Usage Stats ---
        self._session_start_time = time.time()
        self._stats_timer = QTimer(self)
        self._stats_timer.timeout.connect(self._update_usage_stats)
        self._stats_timer.start(60000)  # Update every minute
        self._shutting_down = False
        self._icon_table = None
        self.dock_host = None
        
        from setiastro.saspro.doc_manager import DocManager
        from setiastro.saspro.window_shelf import WindowShelf, MinimizeInterceptor
        from setiastro.saspro.imageops.mdi_snap import MdiSnapController
        from setiastro.saspro.ops.scripts import ScriptManager
        self._version = version
        self._build_timestamp = build_timestamp
        try:
            from setiastro.saspro.widgets.common_utilities import supporter_title_suffix
            _sup_suffix = supporter_title_suffix()
        except Exception:
            _sup_suffix = ""
        self.setWindowTitle(f"Seti Astro Suite Pro v{self._version}{_sup_suffix}")
        self.resize(1400, 900)
        self._ensure_network_manager()
        app = QApplication.instance()
        if app is not None and not app.windowIcon().isNull():
            self.app_icon = app.windowIcon()
        else:
            self.app_icon = QIcon(icon_path)  # fallback only
        self.setWindowIcon(self.app_icon)
        self._doc = None
        self._force_close_all = False
        self._is_restarting = False  # Flag to bypass exit confirmation on restart
        self.settings = QSettings()
        
        # Optimization: Cache the settings dialog for instant opening
        self._settings_dlg_cache = None
        # Pre-load settings dialog after 2.5 seconds (background)
        QTimer.singleShot(1000, self._preload_settings)
        self._last_active_view = None
        self._current_active_sw = None
        self._last_active_sw = None
        self._suspend_dock_sync = False        # pause action<->dock syncing while minimized
        self._dock_visibility_snapshot = {}     # objectName -> bool
        self._pre_minimize_state = None
        self._dock_vis_intended: dict[str, bool] = {}   # last known intended visibility per dock
        self._last_good_state: QByteArray | None = None
        auto_on = self.settings.value("view/auto_fit_on_resize", False, type=bool)
        self._auto_fit_on_resize = bool(auto_on)
        self._last_headless_command: dict | None = None
        self._headless_history: list[dict] = []  # newest at the end
        self._headless_history_max = 150

        # -- Recent files / projects ---------------------------------------
        self._recent_max = 20
        self._recent_image_paths: list[str] = []
        self._recent_project_paths: list[str] = []
        self._load_recent_lists()

        # Debounce timer for auto-fit on resize
        self._auto_fit_timer = QTimer(self)
        self._auto_fit_timer.setSingleShot(True)
        self._auto_fit_timer.setInterval(200)  # ms: tweak if you want snappier/slower
        self._auto_fit_timer.timeout.connect(self._apply_auto_fit_resize)
        # Core
        self.doc_manager = DocManager(image_manager=image_manager, parent=self)
        self.docman = self.doc_manager  # legacy alias for older code
        self.docman.imageRegionUpdated.connect(self._on_doc_region_updated)

        # MDI workspace
        self.mdi = MdiArea()
        self.mdi.setViewMode(QMdiArea.ViewMode.SubWindowView)
        # --- Custom background support: load saved path and apply after init
        self._custom_bg_path = self.settings.value("ui/custom_background", "", type=str) or ""
        if self._custom_bg_path:
            # If the file exists, apply it silently after init. If it doesn't exist,
            # remove the stale setting so the app doesn't try to load it and hang.
            try:
                if os.path.exists(self._custom_bg_path):
                    QTimer.singleShot(0, lambda: self._apply_custom_background(self._custom_bg_path, silent=True))
                else:
                    try:
                        self.settings.remove("ui/custom_background")
                        self.settings.sync()
                    except Exception:
                        pass
                    self._custom_bg_path = ""
            except Exception:
                # In case of any odd error, just skip applying the custom background
                self._custom_bg_path = ""

        # Absolute path to the default background image and placeholders for custom bg
        bg_path = background_path
        self._bg_pixmap = QPixmap(bg_path)
        self._custom_bg_path = getattr(self, "_custom_bg_path", "") or ""
        self._custom_bg_pixmap = QPixmap()  # original loaded custom pixmap (unscaled)

        def _draw_transparent_bg(event):
            painter = QPainter(self.mdi.viewport())

            # Base fill (same as default app background color)
            painter.fillRect(self.mdi.rect(), QColor("#1e1e1e"))

            # Choose which pixmap to draw: custom if available, else default
            pix = None
            if not self._custom_bg_pixmap.isNull():
                pix = self._custom_bg_pixmap
            elif not self._bg_pixmap.isNull():
                pix = self._bg_pixmap

            if pix is not None and not pix.isNull():
                # scale to cover MDI area while preserving aspect ratio
                target = self.mdi.size()
                if target.width() > 0 and target.height() > 0:
                    scaled = pix.scaled(target, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
                else:
                    scaled = pix

                opacity_percent = self.settings.value("display/bg_opacity", 50, type=int)
                opacity_float = max(0.0, min(1.0, float(opacity_percent) / 100.0))
                painter.setOpacity(opacity_float)

                x = (self.mdi.width() - scaled.width()) // 2
                y = (self.mdi.height() - scaled.height()) // 2
                painter.drawPixmap(x, y, scaled)

        self.mdi.paintEvent = _draw_transparent_bg

        self.mdi.subWindowActivated.connect(self._remember_active_pair)
        self.mdi.backgroundDoubleClicked.connect(self.open_files)   # <- new
        QShortcut(QKeySequence("Ctrl+PgDown"), self, activated=self._toggle_last_active_view)
        QShortcut(QKeySequence("Ctrl+PgUp"), self, activated=self._toggle_last_active_view)
        self.setCentralWidget(self.mdi)
        self._snap = MdiSnapController(self.mdi, threshold_px=8)

        self.window_shelf = WindowShelf(self)
        self.window_shelf.setObjectName("WindowShelfDock") 
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.window_shelf)
        self.window_shelf.hide()

        self._minimize_interceptor = MinimizeInterceptor(self.window_shelf, self)
        self.currentDocumentChanged.connect(self._sync_docman_active)
        self.currentDocumentChanged.connect(self._sync_explorer_to_active_doc)
        self.scriptman = ScriptManager(self)
        self.scriptman.load_registry()
        # Docks
        self._init_explorer_dock()
        self._init_console_dock()
        self._init_header_viewer_dock()
        self._init_layers_dock()
        self._init_resource_monitor_dock()
        self._shutting_down = False
        self._init_status_log_dock()
        self._init_log_dock()
        self._hook_stdout_stderr()

        # Toolbar / actions
        self._create_actions()
        self._init_menubar()
        self._init_toolbar()
        self._install_command_search()
        self._init_dock_rails() 

        # Keep explorer in sync
        self.docman.documentAdded.connect(self._add_doc_to_explorer)
        self.docman.documentRemoved.connect(self._remove_doc_from_explorer)
        #self.mdi.viewStateDropped.connect(self._handle_viewstate_drop)
        self.docman.documentAdded.connect(self._on_doc_added_for_header_sync)
        self.docman.documentRemoved.connect(self._on_doc_removed_for_header_sync)
        self.mdi.subWindowActivated.connect(lambda _sw: self._hdr_refresh_timer.start(0))
        self.mdi.subWindowActivated.connect(self._on_subwindow_activated)
        self.mdi.commandDropped.connect(self._handle_command_drop)
        self.docman.documentAdded.connect(self._open_subwindow_for_added_doc)
        self.mdi.maskDropped.connect(self._handle_mask_drop)
        self.mdi.astrometryDropped.connect(self._on_astrometry_drop)
        self.docman.documentAdded.connect(lambda _d: self._refresh_mask_action_states())
        self.docman.documentRemoved.connect(lambda _d: self._refresh_mask_action_states())
        self.docman.documentAdded.connect(self._on_document_added)
        self.mdi.viewStateDropped.connect(self._on_mdi_viewstate_drop)
        self.mdi.linkViewDropped.connect(self._on_linkview_drop)
        self._mdi_open_batch = 0
        self._mdi_place_mode = "cascade"   # or "tile"
        self._mdi_next_pos = None          # QPoint in MDI coords
        self._mdi_cascade_step = 28
        self.doc_manager.set_mdi_area(self.mdi)
        # Coalesce undo/redo label refreshes
        self._undo_redo_refresh_pending = False
        self._undo_redo_refresh_timer = QTimer(self)
        self._undo_redo_refresh_timer.setSingleShot(True)
        self._undo_redo_refresh_timer.timeout.connect(self._do_undo_redo_label_refresh)
        # Keep the toolbar in sync whenever anything relevant changes
        self.doc_manager.documentAdded.connect(lambda *_: self._schedule_undo_redo_label_refresh())
        self.doc_manager.documentRemoved.connect(lambda *_: self._schedule_undo_redo_label_refresh())
        self.doc_manager.imageRegionUpdated.connect(lambda *_: self._schedule_undo_redo_label_refresh())
        self.doc_manager.previewRepaintRequested.connect(lambda *_: self._schedule_undo_redo_label_refresh())
        self.mdi.subWindowActivated.connect(lambda *_: self._schedule_undo_redo_label_refresh())

        # optional: keep, but schedule (or remove entirely)
        #try:
        #    QApplication.instance().focusChanged.connect(lambda *_: self._schedule_undo_redo_label_refresh())
        #except Exception:
        #    pass
        self.shortcuts.load_shortcuts()
        self._ensure_persistent_names() 
        self._restore_window_placement()
        app = QApplication.instance()
        if app is not None:
            self.setWindowIcon(app.windowIcon())        
        try:
            from setiastro.saspro.function_bundle import restore_function_bundle_chips
            restore_function_bundle_chips(self)
        except Exception:
            pass

        try:
            from setiastro.saspro.view_bundle import restore_view_bundle_chips
            restore_view_bundle_chips(self)
        except Exception:
            pass
        self._updates_url = self.settings.value(
            "updates/url",
            "https://raw.githubusercontent.com/setiastro/setiastrosuitepro/main/updates.json",
            type=str
        )

        app = QApplication.instance()

        # Re-entrancy guard + debounce
        self._theme_guard = False
        self._theme_debounce = QTimer(self)
        self._theme_debounce.setSingleShot(True)
        self._theme_debounce.timeout.connect(self._apply_theme_safely)

        # Build a safe list of theme-relevant event types for this Qt build
        _names = [
            "ApplicationPaletteChange",  # present on all Qt6
            "PaletteChange",             # older / extra signal from widgets
            "ColorSchemeChange",         # newer Qt (6.5+)
            # "ThemeChange",             # NOT reliable--do NOT include
            # "StyleChange",             # optional; usually noisy, so we skip
        ]
        _types = []
        for n in _names:
            t = getattr(QEvent.Type, n, None)
            if t is not None:
                _types.append(t)
        self._theme_events = tuple(_types)

        # Listen only on the app object
        app.installEventFilter(self)

        self.apply_theme_from_settings()
        self._populate_view_panels_menu()
        # Startup check (no lambdas)
        #if self.settings.value("updates/check_on_startup", True, type=bool):
        #    QTimer.singleShot(1500, self.check_for_updates_startup)

        self._hdr_refresh_timer = QTimer(self)
        self._hdr_refresh_timer.setSingleShot(True)
        self._hdr_refresh_timer.timeout.connect(lambda: self._refresh_header_viewer(self._active_doc()))

        try:
            self.docman.imageRegionUpdated.connect(self._on_image_region_updated_global)
        except Exception:
            pass

        try:
            self._last_good_state = self.saveState()
        except Exception:
            pass

        self.linker = ViewLinkController(self.mdi)

        # attach any already-open subwindows
        for sw in self.mdi.subWindowList():
            try:
                self.linker.attach_view(sw.widget())
            except Exception:
                pass

        self.mdi.subWindowActivated.connect(self._on_sw_activated)
        self.mdi.subWindowActivated.connect(lambda _=None: self._sync_link_action_state())  
        self._link_views_enabled = QSettings().value("view/link_scroll_zoom", True, type=bool)

        self.status_log_dock.hide()
        self.restore_main_window_state()
        # If docks were previously sent to secondary host, restore that now
        # Done here at end of __init__ so all docks are guaranteed constructed
        s = self.settings
        k = self._mw_key()
        if s.value(f"{k}/dock_host/active", False, type=bool):
            self.restore_dock_host_state()
            self._send_default_docks_to_host()

    def _mw_key(self) -> str:
        return "main_window"

    def _schedule_undo_redo_label_refresh(self):
        # Coalesce many triggers into one UI update
        if getattr(self, "_undo_redo_refresh_pending", False):
            return
        self._undo_redo_refresh_pending = True
        # 0ms is fine *if* it’s a real attribute timer (not a local)
        self._undo_redo_refresh_timer.start(0)

    def _do_undo_redo_label_refresh(self):
        self._undo_redo_refresh_pending = False
        try:
            self.update_undo_redo_action_labels()
        except Exception:
            pass


    def _rebuild_menus_for_language(self):
        """Rebuild menus after language change to apply new translations."""
        try:
            # Clear the menubar and rebuild it
            mb = self.menuBar()
            mb.clear()
            self._init_menubar()
        except Exception:
            pass

    def createPopupMenu(self):
        """Override to add System Monitor to the toolbar/dock context menu."""
        # Get the default popup menu from QMainWindow
        menu = super().createPopupMenu()
        if menu is None:
            menu = QMenu(self)
        
        # Add System Monitor toggle if available
        if hasattr(self, "act_toggle_monitor") and self.act_toggle_monitor is not None:
            menu.addSeparator()
            menu.addAction(self.act_toggle_monitor)
        
        return menu

    def _on_sw_activated(self, sw):
        if not sw:
            return
        view = sw.widget()
        try:
            self.linker.attach_view(view)
        except Exception:
            pass

    def _on_document_opened(self, doc):
        try:
            doc.changed.connect(self.update_undo_redo_action_labels)
        except Exception:
            pass
        self._schedule_undo_redo_label_refresh()

    def _promote_roi_preview_to_real_doc(self, st: dict, preview_doc) -> None:
        dm = self.doc_manager

        # ---- 1) Get pixels — crop from base doc using ROI coords ----
        roi = st.get("roi")
        if not roi or len(roi) != 4:
            return

        x, y, w, h = map(int, roi)

        # preview_doc may be the base ImageDocument or a _RoiViewDocument.
        # Get the full image either way and crop it ourselves.
        base_img = getattr(preview_doc, "image", None)
        if base_img is None:
            return

        arr = np.asarray(base_img)

        # If it's already the right size (e.g. already a _RoiViewDocument),
        # use it directly; otherwise crop from the full image.
        if arr.shape[0] == h and arr.shape[1] == w:
            crop = arr.copy()
        else:
            # Clamp to image bounds
            img_h, img_w = arr.shape[:2]
            x = max(0, min(x, img_w - 1))
            y = max(0, min(y, img_h - 1))
            w = max(1, min(w, img_w - x))
            h = max(1, min(h, img_h - y))
            crop = arr[y:y+h, x:x+w].copy()

        H, W = crop.shape[:2]


        # ---- 2) Build metadata from the preview, stripping preview/ROI flags ----
        pmeta = getattr(preview_doc, "metadata", {}) or {}


        meta = {
            k: v
            for k, v in pmeta.items()
            if k not in (
                "is_preview", "roi", "preview_name",
                "roi_wcs", "roi_header",
                "base_doc_uid",
                "wcs", "original_wcs", "sip_wcs",
                "__header_snapshot__",
            )
        }


        # Mark that this document is a *promoted ROI* doc so later DnD
        # knows it's already a standalone image and should just duplicate it.
        meta["is_roi_doc"] = True


        # Mono / bit-depth flags
        meta["is_mono"] = bool(
            crop.ndim == 2 or (crop.ndim == 3 and crop.shape[2] == 1)
        )
        meta["bit_depth"] = meta.get("bit_depth", "32-bit floating point")


        # ---- 3) Build a nice display name without "(Preview)" chained on ----
        # e.g. "andromedasolved.fit (Preview) [ROI 1793,1067,1132Ã--954]"
        disp = preview_doc.display_name() if hasattr(preview_doc, "display_name") else ""


        # Strip any existing "[ROI ...]" suffix
        if "[ROI" in disp:
            disp = disp.split("[ROI", 1)[0].rstrip()

        # Strip " (Preview)" if present
        if " (Preview)" in disp:
            disp = disp.split(" (Preview)", 1)[0].rstrip()

        if not disp:
            disp = pmeta.get("display_name") or "Untitled"


        meta["display_name"] = f"{disp} [ROI {x},{y},{w}Ã--{h}]"


        # ---- 4) Use the preview's ROI header as the *primary* header ----
        from astropy.wcs import WCS

        roi_hdr = pmeta.get("roi_header")
        base_hdr = (
            pmeta.get("original_header")
            or pmeta.get("fits_header")
            or pmeta.get("header")
        )


        if roi_hdr is not None:

            # We have a true ROI header created by the preview machinery.
            # Work on a copy so we don't mutate the original in-place.
            hdr = roi_hdr.copy()
            hdr["NAXIS1"] = int(W)
            hdr["NAXIS2"] = int(H)

            meta["original_header"] = hdr
            meta["fits_header"] = hdr
            meta["header"] = hdr  # HeaderViewer sees this


            # Build WCS directly from this already-cropped header
            try:
                meta["wcs"] = WCS(hdr)

            except Exception as e:

                # Fallback: reuse any existing WCS object if one was stored
                w_existing = (
                    pmeta.get("roi_wcs")
                    or pmeta.get("wcs")
                    or pmeta.get("original_wcs")
                )

                if w_existing is not None:
                    meta["wcs"] = w_existing


            # Optional: snapshot for project I/O / header viewer
            try:
                from setiastro.saspro.doc_manager import _dm_json_sanitize
                meta["__header_snapshot__"] = {
                    "format": "dict",
                    "items": {str(k): _dm_json_sanitize(v) for k, v in hdr.items()},
                }

            except Exception as e:

                meta.pop("__header_snapshot__", None)

        else:

            # No dedicated roi_header: this is either a "plain" doc or a
            # promoted ROI doc. Do NOT try to re-derive WCS from the header,
            # since it may contain non-WCS strings like:
            #   "Calibrated: bias/dark sub, flat division."
            #
            # Instead, just:
            #   - propagate any existing WCS object
            #   - copy whatever header we have and fix NAXIS1/2
            w_existing = (
                pmeta.get("roi_wcs")
                or pmeta.get("wcs")
                or pmeta.get("original_wcs")
            )

            if w_existing is not None:
                meta["wcs"] = w_existing


            if base_hdr is not None:
                hdr = base_hdr.copy()
                hdr["NAXIS1"] = int(W)
                hdr["NAXIS2"] = int(H)

                meta["original_header"] = hdr
                meta["fits_header"] = hdr
                meta["header"] = hdr


                # Snapshot is optional here; no WCS rebuild
                try:
                    from setiastro.saspro.doc_manager import _dm_json_sanitize
                    meta["__header_snapshot__"] = {
                        "format": "dict",
                        "items": {str(k): _dm_json_sanitize(v) for k, v in hdr.items()},
                    }

                except Exception as e:

                    meta.pop("__header_snapshot__", None)

        # ---- 5) Create a real ImageDocument so Explorer sees it as a normal doc ----

        new_doc = dm.open_array(crop, metadata=meta, title=meta.get("display_name"))


        # IMPORTANT: do NOT call any "rebuild cropped WCS" helpers here.
        # We already have a correct, final ROI header.

        # ---- 6) Find the subwindow that doc_manager already spawned ----
        sw = None
        try:

            for sub in self.mdi.subWindowList():
                w = sub.widget() if hasattr(sub, "widget") else None
                d = getattr(w, "document", None)
                # DEBUG: print each candidate

                if d is new_doc:
                    sw = sub

                    break
            if sw is None:
                pass
        except Exception as e:
            print("[Main] ROI promotion: error searching for subwindow:", e)

        # ---- 7) Apply viewstate to that subwindow ----
        if sw and hasattr(sw, "widget"):

            wv = sw.widget()
            if st.get("autostretch") and hasattr(wv, "set_autostretch"):

                wv.set_autostretch(True)
                if hasattr(wv, "set_autostretch_target"):
                    wv.set_autostretch_target(float(st.get("autostretch_target", 0.25)))
            if hasattr(wv, "set_view_transform"):

                wv.set_view_transform(
                    float(st.get("scale", 1.0)),
                    int(st.get("hval", 0)),
                    int(st.get("vval", 0)),
                    from_link=False,
                )
        else:
            pass


    def _on_mdi_viewstate_drop(self, st: dict, target_sw: object | None):
        dm = self.doc_manager

        uid     = st.get("doc_uid")
        doc_ptr = st.get("doc_ptr")
        fpath   = (st.get("file_path") or "").strip()

        doc = dm.resolve_doc_from_drag(uid=uid, doc_ptr=doc_ptr, file_path=fpath)

        if doc is None:
            self._log("[viewstate-drop] could not resolve source document; aborting.")
            return

        # --- ROI/preview metadata ---
        pmeta       = getattr(doc, "metadata", {}) or {}
        base_uid    = pmeta.get("base_doc_uid")
        roi_base_doc = dm._by_uid.get(base_uid) if base_uid else None

        force_new   = (target_sw is None)
        source_kind = st.get("source_kind")
        roi         = st.get("roi")
        is_preview  = (source_kind in ("preview", "roi-preview")) or bool(roi)

        # Preview of an already-promoted ROI doc → treat as plain duplicate
        if is_preview and roi_base_doc is not None:
            if (getattr(roi_base_doc, "metadata", {}) or {}).get("is_roi_doc"):
                doc = roi_base_doc
                is_preview = False
                roi = None

        # ROI promotion: genuine preview of a full base doc
        if force_new and is_preview and roi and len(roi) == 4:
            if not pmeta.get("is_roi_doc"):
                # roi_doc_ptr is set by _start_viewstate_drag when on a preview tab
                roi_doc_ptr = st.get("roi_doc_ptr")
                if roi_doc_ptr is not None:
                    try:
                        ptr = int(roi_doc_ptr)
                        # scan all subwindow views for the ROI doc
                        from setiastro.saspro.subwindow import ImageSubWindow
                        for sw in self.mdi.subWindowList():
                            try:
                                w = sw.widget()
                                if not isinstance(w, ImageSubWindow):
                                    continue
                                dm2 = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
                                if dm2 is None:
                                    continue
                                roi_doc = dm2.get_document_for_view(w)
                                if roi_doc is not None and id(roi_doc) == ptr:
                                    if getattr(roi_doc, "image", None) is not None:
                                        doc = roi_doc
                                    break
                            except Exception:
                                continue
                    except Exception as e:
                        print(f"[DUP DEBUG] roi_doc_ptr resolution failed: {e}")

                try:
                    self._promote_roi_preview_to_real_doc(st, doc)
                    return
                except Exception as e:
                    self._log(f"[viewstate-drop ROI] promotion failed: {e}")
        if force_new:
            # Build a clean base name from the drag payload
            base_name = _strip_ui_decorations(
                (st.get("source_view_title") or "").strip()
                or (doc.display_name() if hasattr(doc, "display_name") else "Untitled")
            )

            new_doc = self.docman.duplicate_document(
                doc, new_name=f"{base_name}_duplicate"
            )

            def _apply_when_ready():
                sw = self._find_subwindow_for_doc(new_doc)
                if not sw:
                    QTimer.singleShot(0, _apply_when_ready)
                    return
                self._apply_view_state_to_view(sw.widget(), st)
                try:
                    drop_pos = getattr(self, "_pending_spawn_cursor_pos", None)
                    if drop_pos is not None:
                        mdi_pos = self.mdi.mapFromGlobal(drop_pos)
                        sw.move(max(0, mdi_pos.x() - sw.width() // 2),
                                max(0, mdi_pos.y() - 16))
                    self._pending_spawn_cursor_pos = None
                except Exception:
                    pass
                self.mdi.setActiveSubWindow(sw)
                self._log(f"Duplicated -> '{new_doc.display_name()}'")

            QTimer.singleShot(0, _apply_when_ready)

        else:
            # Drop onto existing subwindow → copy view transform only
            tgt = target_sw.widget() if hasattr(target_sw, "widget") else None
            if tgt and hasattr(tgt, "set_view_transform"):
                tgt.set_view_transform(
                    float(st.get("scale", 1.0)),
                    int(st.get("hval", 0)),
                    int(st.get("vval", 0)),
                    from_link=False,
                )
            if tgt and st.get("autostretch") and hasattr(tgt, "set_autostretch"):
                tgt.set_autostretch(True)
                if hasattr(tgt, "set_autostretch_target"):
                    tgt.set_autostretch_target(float(st.get("autostretch_target", 0.25)))

    def _on_doc_region_updated(self, doc, roi):
        sw = self._find_subwindow_for_doc(doc)
        if not sw:
            return
        vw = sw.widget()

        if hasattr(vw, "refresh_from_docman"):
            vw.refresh_from_docman()

        try:
            vw._refresh_local_undo_buttons()
        except Exception:
            pass

        # Defer replay button update so headless history is populated first
        try:
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(0, vw._update_replay_button)
        except Exception:
            pass

    def _alive(self, obj) -> bool:
        if obj is None:
            return False
        try:
            _ = obj.metaObject()  # raises if C++ object already deleted
            return True
        except RuntimeError:
            return False

    def _on_document_added(self, doc):
        self._spawn_subwindow_for(doc)

    # --- UI scaffolding ---
    def _on_console_context_menu(self, pos):
        lw = self.console
        global_pos = lw.viewport().mapToGlobal(pos)

        menu = QMenu(lw)
        act_copy_selected = menu.addAction(self.tr("Copy Selected"))
        act_copy_all      = menu.addAction(self.tr("Copy All"))
        menu.addSeparator()
        act_select_all    = menu.addAction(self.tr("Select All Lines"))
        act_clear         = menu.addAction(self.tr("Clear Console"))

        action = menu.exec(global_pos)
        if action is None:
            return

        if action is act_select_all:
            # thanks to ExtendedSelection this will highlight every row
            lw.selectAll()

        elif action is act_copy_selected:
            items = lw.selectedItems()
            # if nothing is selected, fall back to the row under the cursor
            if not items:
                item = lw.itemAt(pos)
                if item is not None:
                    items = [item]
            if items:
                text = "\n".join(i.text() for i in items)
                QGuiApplication.clipboard().setText(text)

        elif action is act_copy_all:
            lines = [lw.item(i).text() for i in range(lw.count())]
            if lines:
                QGuiApplication.clipboard().setText("\n".join(lines))

        elif action is act_clear:
            lw.clear()


    def _first_place_status_log_if_needed(self):
        s = self.settings  # QSettings you already have
        flag_key = "ui/status_log/placed_v1"

        # If we've already placed it once, or a full window state exists, do nothing
        if s.value(flag_key, False, type=bool):
            return

        # If you have a "main window state" key, use it to detect prior layouts:
        has_main_state = s.contains("mainwindow/state") or s.contains("ui/window_state")
        if has_main_state:
            return

        # Defer until after the window has a real geometry
        def _place():
            # OPTION A: float it centered on first run (recommended)
            self.status_log_dock.setFloating(True)

            g = self.frameGeometry()  # screen coords incl. frame
            w = min(900, int(g.width() * 0.6))
            h = min(320, int(g.height() * 0.3))
            x = g.x() + (g.width() - w) // 2
            y = g.y() + 60

            self.status_log_dock.resize(w, h)
            self.status_log_dock.move(x, y)
            self.status_log_dock.show()
            self.status_log_dock.raise_()

            # Remember we've "introduced" it once
            s.setValue(flag_key, True)
            s.sync()

            # Optional: immediately persist the whole layout so next launch restores it
            try:
                s.setValue("mainwindow/state", self.saveState())
            except Exception:
                pass

        QTimer.singleShot(0, _place)


    def _open_user_scripts_github(self):
        # User script examples on GitHub
        url = QUrl("https://drive.google.com/drive/folders/1TSxKZey4R_t7F2RsB53Hd1SBIGXv3-Nl?usp=drive_link")
        QDesktopServices.openUrl(url)

    def _open_scripts_discord_forum(self):
        # Scripts Discord forum
        url = QUrl("https://discord.gg/vvYH82C82f")
        QDesktopServices.openUrl(url)

    # ----------------------------------------
    # Recent images / projects
    # ----------------------------------------
    def _clear_recent_images(self):
        self._recent_image_paths = []
        self._save_recent_lists()
        self._rebuild_recent_menus()

    def _clear_recent_projects(self):
        self._recent_project_paths = []
        self._save_recent_lists()
        self._rebuild_recent_menus()

    def _on_exit(self):
        # Funnel through closeEvent so your confirmation + state saves run
        self.close()

    # --- Link UI helpers (methods on AstroSuiteProMainWindow) ---
    def _cycle_group_for_active(self):
        g = self._current_group_of_active()
        order = [None, "A", "B", "C", "D"]  # how we cycle
        try:
            i = order.index(g)
        except ValueError:
            i = 0
        nxt = order[(i + 1) % len(order)]
        self._set_group_for_active(nxt)

    def _refresh_group_badges(self):
        # Update all window titles to include [A]/[B]/...
        for sw in self.mdi.subWindowList():
            v = sw.widget()
            try:
                g = self.linker.group_of(v)
            except Exception:
                g = None
            # Have each view rebuild its title with group suffix
            try:
                base = v.base_doc_title()
            except Exception:
                base = sw.windowTitle()
            suffix = f"  [Group {g}]" if g else ""
            try:
                v._rebuild_title(base=base + suffix)
            except Exception:
                # fallback: set directly
                sw.setWindowTitle((base or "Untitled") + suffix)
                sw.setToolTip(sw.windowTitle())


    def _set_group_for_active(self, name_or_none):
        sw = self.mdi.activeSubWindow()
        if not sw:
            return
        view = sw.widget()
        if hasattr(self, "linker"):
            self.linker.set_view_group(view, name_or_none)
        self._sync_link_action_state()
        self._refresh_group_badges()
        # Status bar toast
        sb = self.statusBar() if hasattr(self, "statusBar") else None
        if sb:
            msg = "Link: None" if not name_or_none else f"Link: Group {name_or_none}"
            sb.showMessage(msg, 2500)

    def _current_group_of_active(self):
        sw = self.mdi.activeSubWindow()
        if not sw:
            return None
        return self.linker.group_of(sw.widget()) if hasattr(self, "linker") else None

    def _on_linkview_drop(self, payload: dict, target_sw: QMdiSubWindow | None):
        if not target_sw:
            return
        target_view = target_sw.widget()
        if not hasattr(target_view, "set_view_transform"):
            return

        src_id = payload.get("source_view_id")
        if src_id is None:
            return

        # find the source by id(self) that was serialized
        src_view = None
        for sw in self.mdi.subWindowList():
            w = sw.widget()
            if id(w) == src_id:
                src_view = w
                break
        if src_view is None or src_view is target_view:
            return

        self._link_views_bidirectional(src_view, target_view, payload.get("modes", {}))

    def _link_views_bidirectional(self, a, b, modes):
        # Create a small registry to avoid duplicate connections
        if not hasattr(self, "_view_links"):
            self._view_links = set()
        key = tuple(sorted((id(a), id(b))))
        if key in self._view_links:
            return
        self._view_links.add(key)

        # Copy autostretch state once (optional)
        if modes.get("autostretch_once", True):
            try:
                b.set_autostretch(a.autostretch_enabled)
                b.set_autostretch_profile(a.autostretch_profile)
                b.set_autostretch_target(a.autostretch_target)
                b.set_autostretch_sigma(a.autostretch_sigma)
            except Exception:
                pass

        # Live pan/zoom both ways
        def apply_to(dst):
            return lambda scale, h, v: dst.set_view_transform(scale, h, v, from_link=True)

        a.viewTransformChanged.connect(apply_to(b))
        b.viewTransformChanged.connect(apply_to(a))

        # Immediately snap B to A so they look linked right away
        try:
            s, h, v = a._current_transform()
            b.set_view_transform(s, h, v, from_link=True)
        except Exception:
            pass

        # Optional: toast/status to confirm
        try:
            self.statusBar().showMessage(f"Linked views: {a.base_doc_title()} <-> {b.base_doc_title()}", 4000)
        except Exception:
            pass


    # --- Shortcuts -> View Panels (dynamic) --------------------------------------
    def _auto_fit_all_subwindows(self):
        """Apply auto-fit to every visible subwindow when the mode is enabled."""
        if not getattr(self, "_auto_fit_on_resize", False):
            return

        subs = self._visible_subwindows()
        if not subs:
            return

        # Remember current active so we can restore it
        prev_active = self.mdi.activeSubWindow()

        for sw in subs:
            # Make this subwindow active so _zoom_active_fit() works on it
            self.mdi.setActiveSubWindow(sw)
            self._zoom_active_fit()

        # Restore previously active subwindow if still around
        if prev_active and prev_active in subs:
            self.mdi.setActiveSubWindow(prev_active)


    def _visible_subwindows(self):
        # Only arrange visible, non-minimized views
        subs = [sw for sw in self.mdi.subWindowList()
                if sw.isVisible() and not (sw.windowState() & Qt.WindowState.WindowMinimized)]
        return subs

    def _cascade_views(self):
        """Cascade all subwindows and auto-fit their contents."""
        self._cascade_subwindows_custom()

    def _cascade_subwindows_custom(self, *, size_factor: float = 0.6, offset: int = 30):
        """
        Custom cascade layout: stagger all visible subwindows from top-left,
        with a consistent height and width derived from each image's aspect ratio.
        Also auto-fits each view while preserving a clean z-order.
        """
        # Get visible subwindows in a stable order
        try:
            order_enum = QMdiArea.WindowOrder
            subs = list(self.mdi.subWindowList(order_enum.CreationOrder))
        except Exception:
            subs = list(self.mdi.subWindowList())

        subs = [sw for sw in subs if sw.isVisible()]
        if not subs:
            return

        # Remember which window was active so we can restore it
        prev_active = self.mdi.activeSubWindow()
        if prev_active in subs:
            subs.remove(prev_active)
            subs.append(prev_active)

        # Ensure subwindow view mode (not tabbed)
        try:
            self.mdi.setViewMode(QMdiArea.ViewMode.SubWindowView)
        except Exception:
            pass

        vp = self.mdi.viewport()
        area = vp.rect() if vp is not None else self.mdi.rect()

        base_height = int(area.height() * size_factor)
        x = 0
        y = 0

        BORDER_WIDTH_FACTOR = 0.9  # shrink width by 10% to account for chrome/header

        for sw in subs:
            # Make sure window isn't maximized
            try:
                sw.showNormal()
            except Exception:
                pass

            view = sw.widget()

            # --- Get intrinsic image size using the SAME helper as zoom ---
            img_w = img_h = None
            try:
                img_w, img_h = self._infer_image_size(view)
            except Exception:
                img_w = img_h = None

            if not img_w or not img_h:
                aspect = 1.0
            else:
                aspect = float(img_w) / float(img_h)

            # Clamp aspect ratio to something sane
            if aspect <= 0:
                aspect = 1.0
            aspect = max(0.3, min(aspect, 4.0))

            # Base width from aspect ratio
            width = int(base_height * aspect)

            # Reduce width a bit so the viewport fits inside the framed window
            width = int(width * BORDER_WIDTH_FACTOR)

            max_width = area.width()
            if width > max_width:
                width = max_width

            # Place & size
            sw.resize(width, base_height)
            sw.move(x + area.x(), y + area.y())

            # Make it active so zoom/fit works on this one and z-order is in cascade order
            try:
                self.mdi.setActiveSubWindow(sw)
            except Exception:
                pass

            # Auto-fit this window's contents using your existing zoom logic
            if getattr(self, "_auto_fit_on_resize", False):
                try:
                    self._zoom_active_fit()
                except Exception:
                    pass

            x += offset
            y += offset

            # Wrap if we go off the bottom/right
            if (x + width > area.width()) or (y + base_height > area.height()):
                x = 0
                y = 0

        # Restore previously active window, if still around
        if prev_active and prev_active in subs:
            try:
                self.mdi.setActiveSubWindow(prev_active)
            except Exception:
                pass

    def _tile_views(self):
        self.mdi.tileSubWindows()
        self._auto_fit_all_subwindows()

    def _tile_views_direction(self, direction: str):
        """direction: 'v' for vertical columns, 'h' for horizontal rows"""
        subs = self._visible_subwindows()
        if not subs:
            return
        area = self.mdi.viewport().rect()
        # account for MDI viewport origin in global coords
        off = self.mdi.viewport().mapTo(self.mdi, area.topLeft())
        origin_x, origin_y = off.x(), off.y()

        n = len(subs)
        if direction == "v":  # columns
            col_w = max(1, area.width() // n)
            for i, sw in enumerate(subs):
                sw.setGeometry(origin_x + i*col_w, origin_y, col_w, area.height())
        else:  # rows
            row_h = max(1, area.height() // n)
            for i, sw in enumerate(subs):
                sw.setGeometry(origin_x, origin_y + i*row_h, area.width(), row_h)

        self._auto_fit_all_subwindows()


    def _tile_views_grid(self):
        """Arrange near-square grid across the MDI area."""
        subs = self._visible_subwindows()
        if not subs:
            return
        area = self.mdi.viewport().rect()
        off = self.mdi.viewport().mapTo(self.mdi, area.topLeft())
        origin_x, origin_y = off.x(), off.y()

        n = len(subs)
        # rows x cols ~ square
        cols = int(max(1, math.ceil(math.sqrt(n))))
        rows = int(max(1, math.ceil(n / cols)))

        cell_w = max(1, area.width() // cols)
        cell_h = max(1, area.height() // rows)

        for idx, sw in enumerate(subs):
            r = idx // cols
            c = idx % cols
            sw.setGeometry(origin_x + c*cell_w, origin_y + r*cell_h, cell_w, cell_h)

        self._auto_fit_all_subwindows()

    def _ensure_view_panels_menu(self):
        if getattr(self, "_shutting_down", False):
            return getattr(self, "_menu_view_panels", None)

        # if cached menu died (e.g., after repolish), drop it
        if not self._alive(getattr(self, "_menu_view_panels", None)):
            self._menu_view_panels = None

        if self._menu_view_panels:
            return self._menu_view_panels

        shortcuts_menu = None
        for act in self.menuBar().actions():
            m = act.menu()
            if m and (m.title().replace("&", "").strip().lower() == "view"):
                shortcuts_menu = m
                break
        if shortcuts_menu is None:
            shortcuts_menu = self.menuBar().addMenu("&View")

        self._menu_view_panels = shortcuts_menu.addMenu("View Panels")
        self._view_panels_actions = {}
        return self._menu_view_panels

    def _is_inactive_or_minimized(self) -> bool:
        app = QApplication.instance()
        try:
            inactive = app.applicationState() != Qt.ApplicationState.ApplicationActive
        except Exception:
            inactive = False
        return bool(self.windowState() & Qt.WindowState.WindowMinimized) or inactive

    def _register_dock_in_view_menu(self, dock: QDockWidget):
        if dock is None:
            return
        if not dock.objectName():
            dock.setObjectName(dock.windowTitle().replace(" ", "") + "Dock")

        menu = self._ensure_view_panels_menu()
        name = dock.objectName()
        title = dock.windowTitle() or name

        act = self._view_panels_actions.get(name)
        if act is None:
            act = QAction(title, self, checkable=True)
            self._view_panels_actions[name] = act
            menu.addAction(act)

            def _on_action_toggled(checked, d=dock, n=name):
                if self._suspend_dock_sync or self._is_inactive_or_minimized():
                    return
                self._dock_vis_intended[n] = bool(checked)
                d.setVisible(bool(checked))
                # capture a last-good layout whenever the user changes vis while active
                try:
                    self._last_good_state = self.saveState()
                except Exception:
                    pass

            act.toggled.connect(_on_action_toggled)

            def _on_dock_vis_changed(vis, a=act, n=name):
                # Ignore layout churn during minimize/restore; don't let "False" uncheck the action.
                if self._suspend_dock_sync or self._is_inactive_or_minimized():
                    return
                a.setChecked(bool(vis))
                self._dock_vis_intended[n] = bool(vis)
                try:
                    self._last_good_state = self.saveState()
                except Exception:
                    pass

            dock.visibilityChanged.connect(_on_dock_vis_changed)

            dock.destroyed.connect(lambda _=None, n=name: self._remove_dock_from_view_menu(n))

        act.setChecked(dock.isVisible())
        self._dock_vis_intended[name] = dock.isVisible()

    # --- File pickers ---
    def _export_shortcuts_dialog(self):
        from PyQt6.QtWidgets import QFileDialog
        fn, _ = QFileDialog.getSaveFileName(
            self, "Export Shortcuts",
            "shortcuts.sass",
            "SAS Shortcuts (*.sass);;JSON (*.json);;All Files (*)"
        )
        if not fn:
            return
        ok, msg = self.shortcuts.export_to_file(fn)
        if not ok:
            try: self._log(f"Export failed: {msg}")
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

    def _import_shortcuts_dialog(self):
        from PyQt6.QtWidgets import QFileDialog, QMessageBox
        fn, _ = QFileDialog.getOpenFileName(
            self, "Import Shortcuts",
            "", "SAS Shortcuts (*.sass *.json);;All Files (*)"
        )
        if not fn:
            return

        # Ask merge vs replace
        btn = QMessageBox.question(
            self, "Import Shortcuts",
            "Replace existing shortcuts? (Choose No to merge.)",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        replace = (btn == QMessageBox.StandardButton.Yes)

        ok, msg = self.shortcuts.import_from_file(fn, replace_existing=replace)
        if not ok:
            try: self._log(f"Import failed: {msg}")
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

    def changeEvent(self, ev):
        super().changeEvent(ev)
        if ev.type() == QEvent.Type.ActivationChange:
            if platform.system() == "Darwin" and self.isActiveWindow():
                app = QApplication.instance()
                if app:
                    for window in app.topLevelWidgets():
                        if (
                            window is not self
                            and window.__class__.__name__ not in ('_EarlySplash',)
                            and window.isVisible()
                            and not window.isMinimized()
                        ):
                            window.raise_()
        if ev.type() == QEvent.Type.WindowStateChange:
            if self.windowState() & Qt.WindowState.WindowMinimized:
                # entering minimized -- just guard; do not snapshot false vis
                self._suspend_dock_sync = True
                return
            # leaving minimized / other state change
            if self._suspend_dock_sync:
                try:
                    # Restore the last good layout if we have it
                    if self._last_good_state:
                        self.restoreState(self._last_good_state)
                except Exception:
                    pass
                # Enforce intended vis for each known dock (in case restoreState wasn't enough)
                for name, want in dict(self._dock_vis_intended).items():
                    d = self.findChild(QDockWidget, name)
                    if d:
                        if want: d.show()
                        else:    d.hide()
                # Re-sync menu checks
                for name, act in getattr(self, "_view_panels_actions", {}).items():
                    dock = self.findChild(QDockWidget, name)
                    if dock:
                        act.setChecked(dock.isVisible())
                # Resume normal syncing
                self._suspend_dock_sync = False
                # Capture a fresh last-good layout now that we're back
                try:
                    self._last_good_state = self.saveState()
                except Exception:
                    pass

    def _remove_dock_from_view_menu(self, name: str):
        if getattr(self, "_shutting_down", False):
            self._view_panels_actions.pop(name, None)
            return
        act = self._view_panels_actions.pop(name, None)
        if not act:
            return
        m = self._ensure_view_panels_menu()
        if not self._alive(m):
            return
        try:
            m.removeAction(act)
        except RuntimeError:
            pass
        try:
            act.deleteLater()
        except Exception:
            pass


    def _open_view_bundles(self):
        from setiastro.saspro.view_bundle import show_view_bundles
        try:

            show_view_bundles(self)
        except Exception as e:
            QMessageBox.warning(self, self.tr("View Bundles"), f"Open failed:\n{e}")

    def _open_function_bundles(self):
        from setiastro.saspro.function_bundle import show_function_bundles
        try:

            show_function_bundles(self)
        except Exception as e:
            QMessageBox.warning(self, self.tr("Function Bundles"), f"Open failed:\n{e}")

    def _open_scripts_folder(self):
        if hasattr(self, "scriptman"):
            self.scriptman.open_scripts_folder()

    def _reload_scripts(self):
        if not hasattr(self, "scriptman"):
            return
        self.scriptman.load_registry()
        if hasattr(self, "menu_scripts") and self.menu_scripts:
            self.scriptman.rebuild_menu(self.menu_scripts)
        self._log("[Scripts] Reload complete.")

    def _create_sample_script(self):
        if not hasattr(self, "scriptman"):
            return
        self.scriptman.create_sample_script()

    def _show_script_editor(self):
        if not hasattr(self, "script_editor_dock") or self.script_editor_dock is None:
            from setiastro.saspro.ops.script_editor import ScriptEditorDock
            self.script_editor_dock = ScriptEditorDock(self, parent=self)
            self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.script_editor_dock)
        self.script_editor_dock.show()
        self.script_editor_dock.raise_()
        self.script_editor_dock.activateWindow()

    def _build_cheats_keyboard_rows(self):
        rows = []

        # 1) All QActions (you already have a collector; fall back if missing)
        try:
            actions = self._collect_all_qactions()
        except Exception:
            actions = self.findChildren(QAction)

        for act in actions:
            for seq in _seqs_for_action(act):
                rows.append((_qs_to_str(seq), _describe_action(act), _where_for_action(act)))

        # 2) Ad-hoc QShortcuts created in code
        for sc in self.findChildren(QShortcut):
            seq = sc.key()
            if seq and not seq.isEmpty():
                rows.append((_qs_to_str(seq), _describe_shortcut(sc), _where_for_shortcut(sc)))

        # 3) App-level shortcuts not represented by QAction/QShortcut
        try:
            add_extra_shortcuts(rows)  # ✅ Ctrl+K, Ctrl+Alt+M, etc.
        except Exception:
            pass

        # De-duplicate and sort by shortcut text
        rows = _uniq_keep_order(rows)
        rows.sort(key=lambda r: (r[0].lower(), r[1].lower()))
        return rows

    def _build_cheats_gesture_rows(self):
        # Manual list (extend anytime). Format: (Gesture, Context, Effect)
        rows = [
            # Command search
            ("A", "Display Stretch", self.tr("Toggle Display Auto-Stretch")),
            ("Ctrl+I", "Invert", self.tr("Invert the Image")),
            ("Ctrl+Shift+P", "Command Search", self.tr("Focus the command search bar; Enter runs first match")),

            # View Icon
            ("Drag view -> Off to Canvas", "View", self.tr("Duplicate Image")),
            ("Drag view -> On to Other Image", "View", self.tr("Copy Zoom and Pan")),
            ("Shift+Drag -> On to Other Image", "View", self.tr("Apply that image to the other as a mask")), 
            ("Ctrl+Drag -> On to Other Image", "View", self.tr("Copy Astrometric Solution")),            

            # View zoom
            ("Ctrl+1", "View", self.tr("Zoom to 100% (1:1)")),
            ("Ctrl+0", "View", self.tr("Fit image to current window")),
            ("Ctrl++", "View", self.tr("Zoom In")),
            ("Ctrl+-", "View", self.tr("Zoom Out")),

            # Window switching
            ("Ctrl+PgDown", "MDI", self.tr("Switch to previously active view")),
            ("Ctrl+PgUp",   "MDI", self.tr("Switch to next active view")),

            # Shortcuts canvas + buttons
            ("Alt+Drag (toolbar button)", "Toolbar", self.tr("Create a desktop shortcut for that action")),
            ("Alt+Drag (shortcut button -> view)", "Shortcuts", self.tr("Headless apply the shortcut's command/preset to a view")),
            ("Ctrl/Shift+Click", "Shortcuts", self.tr("Multi-select shortcut buttons")),
            ("Drag (selection)", "Shortcuts", self.tr("Move selected shortcut buttons")),
            ("Delete / Backspace", "Shortcuts", self.tr("Delete selected shortcut buttons")),
            ("Ctrl+A", "Shortcuts", self.tr("Select all shortcut buttons")),
            ("Double-click empty area", "MDI background", self.tr("Open files dialog")),

            # Layers dock
            ("Drag view -> Layers list", "Layers", self.tr("Add dragged view as a new layer (on top)")),
            ("Shift+Drag mask -> Layers list", "Layers", self.tr("Attach dragged image as mask to the selected layer")),

            # Crop tool
            ("Click-drag", "Crop Tool", self.tr("Draw a crop rectangle")),
            ("Drag corner handles", "Crop Tool", self.tr("Resize crop rectangle")),
            ("Shift+Drag on box", "Crop Tool", self.tr("Rotate crop rectangle")),
        ]
        return rows

    def _show_cheat_sheet(self):
        kb = self._build_cheats_keyboard_rows()
        gs = self._build_cheats_gesture_rows()
        dlg = _CheatSheetDialog(self, kb, gs)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.show()

    def _doc_by_ptr(self, ptr: int):
        dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
        if dm and hasattr(dm, "all_documents"):
            for d in dm.all_documents():
                if id(d) == ptr:
                    return d
        return None

    def _close_all_subwindows(self):
        for sw in list(self.mdi.subWindowList()):
            try:
                sw.close()
            except Exception:
                pass

    def _clear_all_documents(self):
        dm = getattr(self, "doc_manager", None)
        if not dm:
            return
        # Make a copy because closing views may mutate _docs via signals
        for doc in list(dm._docs):
            try:
                self._safe_close_doc(doc)
            except Exception:
                # fallback: force drop
                try: dm.close_document(doc)
                except Exception as e:
                    import logging
                    logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

    def _clear_minimized_shelf(self):
        try:
            if hasattr(self, "window_shelf") and self.window_shelf:
                self.window_shelf.clear_all()
        except Exception:
            pass

    def _confirm_discard(self, title=None, msg=None):
        if title is None:
            title = self.tr("New Project")
        if msg is None:
            msg = self.tr("This will close all views and clear desktop shortcuts. Continue?")
        btn = QMessageBox.question(self, title, msg,
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.No)
        return btn == QMessageBox.StandardButton.Yes

    def _clear_views_keep_shortcuts(self):
        if not self._confirm_discard(
            title=self.tr("Clear All Views"),
            msg=self.tr("Close all views and documents? Desktop shortcuts will be preserved.")
        ):
            return

        # Close views + docs + minimized shelf (same as _new_project)
        self._close_all_subwindows()
        self._clear_all_documents()
        self._clear_minimized_shelf()

        # DO NOT clear shortcuts or their persisted layout.
        # Just bring the canvas forward so users can keep working.
        try:
            if getattr(self, "shortcuts", None):
                self.shortcuts.canvas.raise_()
                self.shortcuts.canvas.show()
                self.shortcuts.canvas.setFocus()
        except Exception:
            pass

        self._log("Cleared all views (shortcuts preserved).")

    def _ask_project_compress(self) -> bool:
        """
        Returns True if the user wants compression.
        Respects a remembered preference in QSettings.
        """
        s = QSettings()
        has_pref = s.contains("projects/compress")
        if has_pref:
            # read as bool
            return s.value("projects/compress", True, type=bool)

        msg = QMessageBox(self)
        msg.setWindowTitle("Save Project")
        msg.setText("Compress project file for smaller size?\n\n"
                    "Yes = smaller file, slower save\n"
                    "No  = larger file, faster save")
        msg.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        msg.setDefaultButton(QMessageBox.StandardButton.Yes)

        remember = QCheckBox("Remember my choice")
        msg.setCheckBox(remember)

        choice = msg.exec()
        compress = (choice == QMessageBox.StandardButton.Yes)

        if remember.isChecked():
            s.setValue("projects/compress", compress)
            s.sync()

        return compress

    def _prepare_for_project_load(self, title: str = "Load Project") -> bool:
        """Confirm and clear current desktop before loading a project."""
        if getattr(self, "doc_manager", None) and self.doc_manager._docs:
            if not self._confirm_discard(
                title=title,
                msg=self.tr(
                    "Loading a project will close current views and replace desktop shortcuts.\n"
                    "Continue?"
                ),
            ):
                return False
            self._close_all_subwindows()
            self._clear_all_documents()
            self._clear_minimized_shelf()
            if getattr(self, "shortcuts", None):
                try:
                    self.shortcuts.canvas.raise_()
                    self.shortcuts.canvas.show()
                    self.shortcuts.canvas.setFocus()
                except Exception:
                    pass
        return True

    def _do_load_project_path(self, path: str):
        from setiastro.saspro.project_io import ProjectWriter, ProjectReader
        """Internal helper to actually load a .sas file."""
        if not path:
            return

        # ensure DocManager exists
        if not hasattr(self, "doc_manager") or self.doc_manager is None:
            from setiastro.saspro.doc_manager import DocManager
            self.doc_manager = DocManager(
                image_manager=getattr(self, "image_manager", None), parent=self
            )

        # progress ("thinking") dialog
        dlg = QProgressDialog("Loading project...", "", 0, 0, self)
        dlg.setWindowTitle("Loading")
        try:
            dlg.setWindowModality(Qt.WindowModality.ApplicationModal)
        except AttributeError:  # PyQt5 fallback
            dlg.setWindowModality(Qt.ApplicationModal)
        try:
            dlg.setCancelButton(None)
        except TypeError:
            dlg.setCancelButtonText("")
        dlg.setAutoClose(False)
        dlg.setAutoReset(False)
        dlg.show()

        try:
            ProjectReader(self).read(path)
            self._log("Project loaded.")
            self._add_recent_project(path)   # âœ... track in MRU
        except Exception as e:
            QMessageBox.critical(self, "Load Project", f"Failed to load:\n{e}")
        finally:
            dlg.close()


    def _show_mask_overlay(self):
        vw = self._active_view()
        if not vw:
            return
        # require an active mask on this doc
        doc = getattr(vw, "document", None)
        has_mask = bool(doc and getattr(doc, "active_mask_id", None))
        if not has_mask:
            QMessageBox.information(self, "Mask Overlay", "No active mask on this image.")
            return
        vw.show_mask_overlay = True
        # ensure visuals are up-to-date immediately
        try:
            vw._set_mask_highlight(True)
        except Exception:
            pass
        vw._render(rebuild=True)
        self._refresh_mask_action_states()

    def _hide_mask_overlay(self):
        vw = self._active_view()
        if not vw:
            return
        vw.show_mask_overlay = False
        vw._render(rebuild=True)
        self._refresh_mask_action_states()

    def _open_softproof(self):
        doc = self._active_doc()
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, self.tr("Soft Proof"), self.tr("No active image."))
            return
        try:
            from setiastro.saspro.softproof_dialog_pro import SoftProofDialog
            dlg = SoftProofDialog(np.asarray(doc.image).copy(), parent=self)
            dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
            dlg.show()
        except Exception as exc:
            QMessageBox.warning(
                self,
                self.tr("Soft Proof"),
                self.tr("Could not open soft proof preview:\n\n{error}").format(error=exc),
            )

    def _invert_mask(self):
        import numpy as np
        doc = self._active_doc()
        if not doc:
            return
        mid = getattr(doc, "active_mask_id", None)
        if not mid:
            return
        layer = (getattr(doc, "masks", {}) or {}).get(mid)
        if layer is None or getattr(layer, "data", None) is None:
            return

        m = np.asarray(layer.data)
        if m.size == 0:
            return

        # invert (preserve dtype)
        if m.dtype.kind in "ui":
            maxv = np.iinfo(m.dtype).max
            layer.data = (maxv - m).astype(m.dtype, copy=False)
        else:
            layer.data = (1.0 - m.astype(np.float32, copy=False)).clip(0.0, 1.0)

        # notify listeners (triggers ImageSubWindow.render via your existing hookup)
        if hasattr(doc, "changed"):
            doc.changed.emit()

        # and explicitly refresh the active view overlay right now
        vw = self._active_view()
        if vw and hasattr(vw, "refresh_mask_overlay"):
            vw.refresh_mask_overlay()

        # keep menu states tidy
        if hasattr(self, "_refresh_mask_action_states"):
            self._refresh_mask_action_states()


    # ---------------- Settings Caching ----------------
    def _preload_settings(self):
        """Build the SettingsDialog in the background so it opens instantly."""
        if getattr(self, "_settings_dlg_cache", None) is None:
            from setiastro.saspro.ops.settings import SettingsDialog
            try:
                self._settings_dlg_cache = SettingsDialog(self, self.settings)
            except Exception as e:
                # Log error but don't crash if preload fails
                print(f"Error preloading settings: {e}")

    def _open_benchmark(self):
        from setiastro.saspro.ops.benchmark import BenchmarkDialog  # new file below

        if getattr(self, "_bench_dlg_cache", None) is None:
            self._bench_dlg_cache = BenchmarkDialog(self)

        dlg = self._bench_dlg_cache
        if hasattr(dlg, "refresh_ui"):
            dlg.refresh_ui()
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

    def apply_display_settings_to_open_views(self, force_rebuild: bool = False):
        try:
            from setiastro.saspro.subwindow import ImageSubWindow
            for sw in list(ImageSubWindow._registry.values()):
                try:
                    if force_rebuild:
                        for attr in ("_qimg_src", "_pm_src", "_pm_src_wcs", "_pm_src_wcs_key"):
                            if hasattr(sw, attr):
                                setattr(sw, attr, None)
                    sw.reload_display_settings()
                    if force_rebuild and hasattr(sw, "refresh_from_docman"):
                        sw.refresh_from_docman()
                except Exception:
                    pass
        except Exception:
            pass

        # also repaint the mdi area
        try:
            if hasattr(self, "mdi") and hasattr(self.mdi, "viewport"):
                self.mdi.viewport().update()
        except Exception:
            pass

    def _open_settings(self):
        from setiastro.saspro.ops.settings import SettingsDialog
        
        # Create cache if it doesn't exist (e.g. opened before preload timer fired)
        if getattr(self, "_settings_dlg_cache", None) is None:
            self._settings_dlg_cache = SettingsDialog(self, self.settings)

        dlg = self._settings_dlg_cache
        
        # Refresh UI from current settings before showing
        if hasattr(dlg, "refresh_ui"):
            dlg.refresh_ui()
            
        if dlg.exec():
            # (Optional) react to changes if needed
            pass

    # ---------------- Custom Background ----------------
    def _choose_custom_background(self):
        """Ask the user to pick a JPG/PNG and apply it as app background. Persists in QSettings."""
        path, _ = QFileDialog.getOpenFileName(self, "Select background image", "", "Images (*.png *.jpg *.jpeg)")
        if not path:
            return
        try:
            self.settings.setValue("ui/custom_background", path)
            self.settings.sync()
            self._custom_bg_path = path
            self._apply_custom_background(path)
        except Exception as e:
            QMessageBox.warning(self, "Background error", f"Could not apply background: {e}")

    def _clear_custom_background(self):
        """Clear any custom background (removes setting and restores default palette)."""
        try:
            self.settings.remove("ui/custom_background")
            self.settings.sync()
            self._custom_bg_path = ""
            # clear internal custom pixmap and restore default palette/styles
            try:
                self._custom_bg_pixmap = QPixmap()
            except Exception:
                pass
            try:
                self.setAutoFillBackground(False)
                self.setPalette(QApplication.palette())
            except Exception:
                pass
            # also clear MDI stylesheet fallback
            try:
                if hasattr(self, "mdi") and self.mdi is not None:
                    self.mdi.setStyleSheet("")
                    # trigger repaint so paintEvent draws default background
                    try:
                        self.mdi.viewport().update()
                    except Exception:
                        pass
            except Exception:
                pass
        except Exception as e:
            QMessageBox.warning(self, "Background error", f"Could not clear background: {e}")

    def _apply_custom_background(self, path: str, silent: bool = False):
        """Apply a background image from `path` to the main window (and MDI if present).

        The image is scaled to the current window size for a single non-tiled background.
        """
        try:
            pix = QPixmap(path)
            if pix.isNull():
                # If we failed to load, remove any stale persisted reference so we don't
                # repeatedly try to load it on future starts. Optionally warn the user
                # when not running in silent mode.
                try:
                    self.settings.remove("ui/custom_background")
                    self.settings.sync()
                except Exception:
                    pass
                if not silent:
                    QMessageBox.warning(self, "Background load failed", "Could not load image file.")
                return

            # Keep the original pixmap around and let the paintEvent scale/draw it
            try:
                self._custom_bg_pixmap = QPixmap(path)
                if self._custom_bg_pixmap.isNull():
                    QMessageBox.warning(self, "Background load failed", "Could not load image file.")
                    return
                self._custom_bg_path = path
            except Exception:
                # fallback: set via palette as a best-effort
                sz = self.size()
                if sz.width() > 0 and sz.height() > 0:
                    pix = pix.scaled(sz, Qt.AspectRatioMode.KeepAspectRatioByExpanding, Qt.TransformationMode.SmoothTransformation)
                brush = QBrush(pix)
                pal = self.palette()
                pal.setBrush(QPalette.ColorRole.Window, brush)
                self.setAutoFillBackground(True)
                self.setPalette(pal)

            # Trigger repaint so paintEvent uses the new custom pixmap
            try:
                if hasattr(self, "mdi") and self.mdi is not None:
                    # clear any stylesheet fallback (we rely on paintEvent now)
                    try:
                        self.mdi.setStyleSheet("")
                    except Exception:
                        pass
                    try:
                        self.mdi.viewport().update()
                    except Exception:
                        pass
            except Exception:
                pass
        except Exception as e:
            QMessageBox.warning(self, "Background error", str(e))

    def graxpert_path(self) -> str:
        return self.settings.value("paths/graxpert", "", type=str)

    def cosmic_clarity_path(self) -> str:
        return self.settings.value("paths/cosmic_clarity", "", type=str)

    def starnet_path(self) -> str:
        return self.settings.value("paths/starnet", "", type=str)

    def _open_icon_table(self):
        from setiastro.saspro.icon_table import IconTablePanel
        if self._icon_table is None:
            self._icon_table = IconTablePanel(self, self.shortcuts, parent=self)
            self._icon_table.restore_window_state()
        self._icon_table.show()
        self._icon_table.raise_()
        self._icon_table.activateWindow()

    def _restore_icon_table_if_needed(self):
        """Called on startup if the icon table was open at last shutdown."""
        try:
            from setiastro.saspro.icon_table import open_icon_table
            # open_icon_table constructs the panel; its restore_window_state()
            # picks up saved geometry before we show it.
            if self._icon_table is None:
                from setiastro.saspro.icon_table import IconTablePanel
                self._icon_table = IconTablePanel(self, self.shortcuts, parent=self)
                self._icon_table.restore_window_state()
            self._icon_table.show()
            self._icon_table.raise_()
        except Exception:
            pass

    def _unwrap_history_doc(self, d):
        """
        Return the *real* document that owns the history stack for `d`.
        Unwraps proxies/ROI/preview wrappers when present.
        """
        seen = set()
        while d is not None and id(d) not in seen:
            seen.add(id(d))

            # Common wrappers: ROI/proxy sets _parent_doc or base_document
            for key in ("history_document", "get_history_document", "base_document", "_parent_doc"):
                try:
                    v = getattr(d, key, None)
                    if callable(v):
                        v = v()
                    if v is not None:
                        d = v
                        break
                except Exception:
                    pass
            else:
                # _DocProxy pattern: _target() returns current doc
                try:
                    tgt = getattr(d, "_target", None)
                    if callable(tgt):
                        t = tgt()
                        if t is not None and t is not d:
                            d = t
                            continue
                except Exception:
                    pass
                # Nothing else to unwrap
                break
        return d

    def _active_history_doc(self):
        dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
        if not dm:
            return None

        # Prefer the currently active subwindow doc, then fall back to doc_manager's active doc.
        d = None
        try:
            sw = self.mdi.activeSubWindow()
            if sw is not None and sw.widget() is not None:
                d = getattr(sw.widget(), "document", None)
        except Exception:
            d = None
        if d is None:
            d = dm.get_active_document()

        return self._unwrap_history_doc(d)

    def _subwindow_for_history_doc(self, hist_doc):
        """
        Return the QMdiSubWindow showing a view whose base/history doc resolves to `hist_doc`.
        """
        if hist_doc is None:
            return None
        try:
            for sw in self.mdi.subWindowList():
                try:
                    vw = sw.widget()
                except RuntimeError:
                    continue
                if vw is None:
                    continue
                # Try explicit base link first
                base = getattr(vw, "base_document", None)
                if base is hist_doc:
                    return sw
                # Then unwrap the view's document to its history root
                vdoc = getattr(vw, "document", None)
                if vdoc is not None and self._unwrap_history_doc(vdoc) is hist_doc:
                    return sw
        except Exception:
            pass
        return None

    # ---------- actions ----------
    def _current_document(self):
        sw = self.mdi.activeSubWindow()
        if not sw:
            return None
        vw = sw.widget()
        return getattr(vw, "document", None)

    def _find_subwindow_for_doc(self, doc):
        """
        Return the QMdiSubWindow showing `doc`, if any.

        Matching rules (in order):
        1) view.base_document is `doc` (identity)
        2) view.document resolves (via _target if proxy) to `doc` (identity)
        We do NOT match by display_name or file_path to avoid aliasing duplicates.
        """
        try:
            for sw in self.mdi.subWindowList():
                # Be defensive about deleted wrappers
                try:
                    w = sw.widget()
                except RuntimeError:
                    continue
                if w is None:
                    continue

                # 1) Prefer explicit base handle installed by _spawn_subwindow_for
                base = getattr(w, "base_document", None)
                if base is doc:
                    return sw

                # 2) Fall back to the view's document (unwrap proxy if present)
                vdoc = getattr(w, "document", None)
                # If this is our _DocProxy, resolve to its current target
                try:
                    if hasattr(vdoc, "_target") and callable(vdoc._target):
                        vdoc = vdoc._target()
                except Exception:
                    pass

                if vdoc is doc:
                    return sw

            # No identity match
            return None
        except Exception:
            return None


    def _normalize_base_doc(self, doc):
        """If doc is an ROI/proxy, return its base/parent; else return doc."""
        return getattr(doc, "_parent_doc", None) or doc

    def _open_subwindow_for_added_doc(self, doc):
        """
        Called when DocManager emits documentAdded(doc).
        Avoid dupes, create a subwindow, connect close hook, and activate it.
        """
        base = self._normalize_base_doc(doc)

        # Avoid duplicate views if one already exists for this *base* doc
        sw_existing = self._find_subwindow_for_doc(base)
        if sw_existing:
            # still ensure the explorer row text is fresh
            try:
                self._update_explorer_item_for_doc(base)
            except Exception:
                pass
            QTimer.singleShot(0, lambda: self.mdi.setActiveSubWindow(sw_existing))
            return

        try:
            sw = self._spawn_subwindow_for(base)  # ensure you pass base
            if sw:
                w = sw.widget()
                # Wire the close hook once
                if hasattr(w, "aboutToClose"):
                    try:
                        # Avoid multiple connections if re-spawned somehow
                        w.aboutToClose.disconnect(self._on_view_about_to_close)
                    except Exception:
                        pass
                    w.aboutToClose.connect(self._on_view_about_to_close)

                # Activate on next tick
                QTimer.singleShot(0, lambda: self.mdi.setActiveSubWindow(sw))
        except Exception as e:
            # Safe fallback: show a very simple subwindow so user sees *something*
            try:
                if hasattr(self, "_log"):
                    self._log(f"Failed to open subwindow for {base.display_name()}: {e}")
            except Exception:
                pass
            from PyQt6.QtWidgets import QLabel, QMdiSubWindow
            w = QLabel(base.display_name()); setattr(w, "document", base)
            wrapper = QMdiSubWindow(self); wrapper.setWidget(w)
            self.mdi.addSubWindow(wrapper); wrapper.show()


    def _action_create_mask(self):
        from setiastro.saspro.mask_creation import create_mask_and_attach
        doc = self._current_document()
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        created = create_mask_and_attach(self, doc)
        # Optional toast/log
        if created and hasattr(self, "_log"):
            self._log("Mask created and set active.")

    def _format_explorer_title(self, doc) -> str:
        name = _strip_ui_decorations(doc.display_name() or "Untitled")

        dims = ""
        try:
            import numpy as np
            arr = getattr(doc, "image", None)
            if isinstance(arr, np.ndarray) and arr.size:
                h, w = arr.shape[:2]
                c = arr.shape[2] if arr.ndim == 3 else 1
                dims = f"  --  {h}x{w}x{c}"
        except Exception:
            pass

        return f"{name}{dims}"

    def _update_explorer_item_for_doc(self, doc):
        # Delegate to DockMixin implementation if present
        try:
            return super()._update_explorer_item_for_doc(doc)
        except Exception:
            pass

        # Fallback: tree-safe implementation
        if not hasattr(self, "explorer") or self.explorer is None:
            return
        try:
            n = self.explorer.topLevelItemCount()
        except Exception:
            return

        for i in range(n):
            it = self.explorer.topLevelItem(i)
            if it.data(0, Qt.ItemDataRole.UserRole) is doc:
                try:
                    self._refresh_explorer_row(it, doc)
                except Exception:
                    pass
                return
    #-----------FUNCTIONS----------------

    # --- WCS summary popup ----------------------------------------
    def _show_wcs_update_popup(self, debug_summary: dict, step_name: str):
        from setiastro.saspro.wcs_update import update_wcs_after_crop
        """
        Show a small WCS update summary dialog using the debug payload
        from update_wcs_after_crop (stored under '__wcs_debug__').
        """
        import math

        before = debug_summary.get("before", {}) or {}
        after  = debug_summary.get("after", {}) or {}
        fit    = debug_summary.get("fit", {}) or {}

        def _fmt_pair(p, fmt="{:.6f}"):
            if not isinstance(p, (list, tuple)) or len(p) != 2:
                return "n/a"
            a, b = p
            def _one(x):
                try:
                    if x is None or not math.isfinite(float(x)):
                        return "n/a"
                    return fmt.format(float(x))
                except Exception:
                    return "n/a"
            return f"({_one(a)}, {_one(b)})"

        def _fmt_one(x, fmt="{:.3f}"):
            try:
                if x is None or not math.isfinite(float(x)):
                    return "n/a"
                return fmt.format(float(x))
            except Exception:
                return "n/a"

        msg_lines = [
            f"{step_name}: WCS updated.",
            "",
            "BEFORE:",
            f"  CRVAL (deg):    { _fmt_pair(before.get('crval_deg')) }",
            f"  CRPIX (pix):    { _fmt_pair(before.get('crpix_pix'), fmt='{:.2f}') }",
            f"  Scale (as/px):  { _fmt_pair(before.get('scale_as_per_pix'), fmt='{:.3f}') }",
            f"  Rotation (deg): { _fmt_one(before.get('rot_deg'), fmt='{:.3f}') }",
            "",
            "AFTER:",
            f"  CRVAL (deg):    { _fmt_pair(after.get('crval_deg')) }",
            f"  CRPIX (pix):    { _fmt_pair(after.get('crpix_pix'), fmt='{:.2f}') }",
            f"  Scale (as/px):  { _fmt_pair(after.get('scale_as_per_pix'), fmt='{:.3f}') }",
            f"  Rotation (deg): { _fmt_one(after.get('rot_deg'), fmt='{:.3f}') }",
        ]

        size = after.get("size")
        if isinstance(size, (list, tuple)) and len(size) == 2:
            msg_lines.append(f"  Image size:     {int(size[0])} Ã-- {int(size[1])}")

        rms  = _fmt_one(fit.get("rms_arcsec"), fmt="{:.3f}")
        p50  = _fmt_one(fit.get("p50_arcsec"), fmt="{:.3f}")
        p95  = _fmt_one(fit.get("p95_arcsec"), fmt="{:.3f}")
        msg_lines += [
            "",
            "Fit residuals (arcsec):",
            f"  RMS: {rms}   median: {p50}   p95: {p95}",
        ]

        coerced = debug_summary.get("coerced_to_2d", None)
        if coerced is True:
            msg_lines.append("")
            msg_lines.append("Note: WCS was coerced from 3-D to 2-D for refitting.")

        text = "\n".join(msg_lines)
        QMessageBox.information(self, "WCS Updated", text)

    def _bake_display_stretch(self):
        """Bake the *currently displayed* Display-Stretch into the image data.

        Applies the exact LUT the view is showing (via the view's own apply path)
        rather than recomputing a stretch, which would drift from the preview if
        the image was modified (e.g. denoised) since the stretch was toggled on.
        """
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Display-Stretch", "No active image window.")
            return

        view = sw.widget()
        doc = getattr(view, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Display-Stretch", "Active window has no image.")
            return

        if not getattr(view, "autostretch_enabled", False):
            QMessageBox.information(
                self, "Display-Stretch",
                "Display-Stretch isn't on for this view.\nTurn it on first, then bake it in."
            )
            return

        a = np.asarray(doc.image)
        if a.size == 0:
            QMessageBox.information(self, "Display-Stretch", "Image is empty.")
            return

        stretched01 = None
        if hasattr(view, "apply_current_display_stretch"):
            stretched01 = view.apply_current_display_stretch()
        if stretched01 is None:
            QMessageBox.warning(
                self, "Display-Stretch",
                "Couldn't read the active display-stretch. Toggle it off and on, then retry."
            )
            return

        # back to original dtype
        if np.issubdtype(a.dtype, np.integer):
            info = np.iinfo(a.dtype)
            out = (np.clip(stretched01, 0.0, 1.0) * float(info.max)).astype(a.dtype, copy=False)
        else:
            out = np.clip(stretched01, 0.0, 1.0).astype(a.dtype, copy=False)

        meta = {
            "step_name": "Display-Stretch (baked)",
            "autostretch_target": float(getattr(view, "autostretch_target", 0.0)),
            "autostretch_sigma": float(getattr(view, "autostretch_sigma", 0.0)),
            "autostretch_linked": bool(getattr(view, "_autostretch_linked", False)),
            "autostretch_no_black_clip": bool(getattr(view, "_no_black_clip", False)),
            "baked_from_display_lut": True,
        }

        try:
            if hasattr(doc, "set_image"):
                doc.set_image(out, meta)
            elif hasattr(doc, "update_image"):
                doc.update_image(out, meta)
            else:
                doc.image = out
        except Exception as e:
            QMessageBox.critical(self, "Display-Stretch", f"Failed to update image:\n{e}")
            return

        # turn display-stretch off so the baked (already-stretched) data shows linearly,
        # i.e. identical to the preview
        if hasattr(view, "set_autostretch"):
            view.set_autostretch(False)
        self._sync_autostretch_action(False)

        try:
            self._log(f"Display-Stretch baked into image -> {sw.windowTitle()}")
        except Exception:
            pass


    def _open_histogram(self):
        from setiastro.saspro.histogram import HistogramDialog
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Histogram", "No active image window.")
            return

        doc = sw.widget().document

        # make sure we have a place to hold dialogs
        if not hasattr(self, "_open_histograms"):
            self._open_histograms = []

        dlg = HistogramDialog(self, doc)
        dlg.setWindowTitle(f"Histogram -- {sw.windowTitle()}")
        try:
            dlg.setWindowIcon(QIcon(histogram_path))
        except Exception:
            pass

        # this is the key: stay on top
        # dlg.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)

        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

        # keep it alive
        self._open_histograms.append(dlg)

        # optional: prune on close
        dlg.finished.connect(lambda _: self._open_histograms.remove(dlg))

        if hasattr(self, "_log"):
            self._log(f"Opened Histogram for {doc.display_name()}")


    def _open_crop_dialog(self):
        from setiastro.saspro.crop_dialog_pro import CropDialogPro
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Crop", "No active image window.")
            return
        doc = sw.widget().document
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Crop", "Active document has no image.")
            return
        dlg = CropDialogPro(self, doc)
        try:
            dlg.setWindowIcon(QIcon(cropicon_path))
        except Exception:
            pass

        dlg.crop_applied.connect(lambda *_: QTimer.singleShot(0, self._zoom_active_fit))
        dlg.show()

    def _open_statistical_stretch(self):
        from setiastro.saspro.stat_stretch import StatisticalStretchDialog
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        view = sw.widget()
        # ROI-aware: always resolve via DocManager for THIS view
        doc = self.doc_manager.get_document_for_view(view)

        dlg = StatisticalStretchDialog(self, doc)
        try:
            dlg.setWindowIcon(QIcon(statstretch_path))
        except Exception:
            pass
        dlg.resize(900, 600)
        dlg.show()


    def _open_star_stretch(self):
        from setiastro.saspro.star_stretch import StarStretchDialog
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        doc = sw.widget().document
        dlg = StarStretchDialog(self, doc)
        try:
            dlg.setWindowIcon(QIcon(starstretch_path))
        except Exception:
            pass
        dlg.resize(1000, 650)
        dlg.show()
        self._log("Functions: opened Star Stretch.")

    def _open_histogram_transform(self):
        from setiastro.saspro.histogram_transform_pro import HistogramTransformDialogPro

        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return

        doc = sw.widget().document
        dlg = HistogramTransformDialogPro(self, doc)
        try:
            dlg.setWindowIcon(QIcon(histogram_transform_path))
        except Exception:
            pass
        dlg.resize(1100, 720)
        dlg.show()
        self._log("Functions: opened Histogram Transform.")

    def _open_curves_editor(self):
        from setiastro.saspro.curve_editor_pro import CurvesDialogPro
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        doc = sw.widget().document

        dlg = CurvesDialogPro(self, doc)
        try:
            dlg.setWindowIcon(QIcon(curves_path))
        except Exception:
            pass        
        dlg.resize(1000, 650)
        dlg.show()   # non-modal; you can open one per subwindow

    def _open_hyperbolic(self):
        from setiastro.saspro.ghs_dialog_pro import GhsDialogPro
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        doc = sw.widget().document
        dlg = GhsDialogPro(self, doc)  # class below
        try:
            dlg.setWindowIcon(QIcon(uhs_path))
        except Exception:
            pass        
        dlg.resize(1000, 650)
        dlg.show()

    def _open_satchroma_tool(self):
        doc = self._active_doc()
        if not doc:
            QMessageBox.information(self, "SatChroma", "No active image.")
            return
        from setiastro.saspro.satchroma_tool import SatChromaTool
        w = SatChromaTool(doc_manager=self.docman, document=doc, parent=self)
        w.setWindowIcon(QIcon(satchroma_path))
        w.show()

    def _remove_stars(self, doc=None):
        from setiastro.saspro.remove_stars import remove_stars
        """
        Wrapper so both the menu and Replay Last Action can call star removal
        on a specific document (ROI, base, etc.).
        """
        # If replay passed a specific doc, use it.
        if doc is None:
            sw = self.mdi.activeSubWindow()
            if not sw:
                QMessageBox.information(self, "No image", "Open an image first.")
                return
            doc = sw.widget().document

        remove_stars(self, doc)

    def _add_stars(self, doc=None):
        from setiastro.saspro.add_stars import add_stars
        """
        Wrapper so both the menu and Replay Last Action can call add_stars
        on a specific document (ROI, base, etc.).
        """
        # If replay passed a specific doc, use it.
        if doc is None:
            sw = self.mdi.activeSubWindow()
            if not sw:
                QMessageBox.information(self, "No image", "Open an image first.")
                return

        add_stars(self)

    def _open_cosmetic_correction(self):
        from setiastro.saspro.cosmetic_correction import (
            open_cosmetic_correction_dialog,
            open_cosmetic_correction_batch,
        )
        sw = self.mdi.activeSubWindow()
        if not sw:
            # No active image → jump straight into batch mode.
            open_cosmetic_correction_batch(self)
            self._log("Functions: opened Cosmetic Correction (batch, no active image).")
            return

        view = sw.widget()
        # ROI-aware: always resolve via DocManager for THIS view
        doc = self.doc_manager.get_document_for_view(view)
        if doc is None or getattr(doc, "image", None) is None:
            open_cosmetic_correction_batch(self)
            self._log("Functions: opened Cosmetic Correction (batch, no image loaded).")
            return

        open_cosmetic_correction_dialog(self, doc=doc)
        self._log("Functions: opened Cosmetic Correction.")

    def _open_graxpert(self):
        from setiastro.saspro.graxpert import remove_gradient_with_graxpert
        """Open GraXpert for the active document (same style as Star Stretch)."""
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "GraXpert", "Open an image first.")
            return

        view = sw.widget()
        doc = getattr(view, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "GraXpert", "Active document has no image.")
            return

        # Let pro.graxpert handle the UI + progress and apply_edit back to this doc
        remove_gradient_with_graxpert(self, target_doc=doc)

        try:
            self._log("Functions: ran GraXpert on active document.")
        except Exception:
            pass

    def _open_abe_tool(self):        
        from setiastro.saspro.abe import ABEDialog
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        doc = sw.widget().document
        dlg = ABEDialog(self, doc)
        try:
            dlg.setWindowIcon(QIcon(abeicon_path))
        except Exception:
            pass  
        dlg.resize(980, 620)
        dlg.show()

    def _open_background_neutral(self):
        from setiastro.saspro.backgroundneutral import BackgroundNeutralizationDialog
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        doc = sw.widget().document
        try:

            dlg = BackgroundNeutralizationDialog(self, doc, icon=QIcon(neutral_path))
        except Exception as e:
            QMessageBox.warning(self, "Background Neutralization", f"Failed to open dialog:\n{e}")
            return
        dlg.resize(900, 600)
        dlg.show()

    def _apply_background_neutral_preset_to_doc(self, doc, preset: dict):
        from setiastro.saspro.backgroundneutral import apply_background_neutral_to_doc
        apply_background_neutral_to_doc(doc, preset or {"mode": "auto"})

    def _open_white_balance(self):
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        doc = sw.widget().document
        try:
            from setiastro.saspro.whitebalance import WhiteBalanceDialog
            dlg = WhiteBalanceDialog(self, doc, icon=QIcon(whitebalance_path))
            dlg.show()
        except Exception as e:
            QMessageBox.warning(self, "White Balance", f"Failed to open dialog:\n{e}")

    def _apply_white_balance_preset_to_doc(self, doc, preset: dict | None):
        from setiastro.saspro.whitebalance import apply_white_balance_to_doc
        apply_white_balance_to_doc(doc, preset or {"mode": "star", "threshold": 50.0})

    def _apply_convo_preset_to_doc(self, doc, preset: dict):
        """
        Headless apply of Convo/Deconvo/TV to a specific document (ROI or base),
        and record it as the last headless command for Replay Last Action.
        """
        from setiastro.saspro.convo_preset import apply_convo_via_preset

        if doc is None or getattr(doc, "image", None) is None:
            return

        # Actually apply
        apply_convo_via_preset(self, doc, preset or {})

        # Record for replay-last-action
        try:
            op = (preset or {}).get("op", "convolution")
            self._last_headless_command = {
                "cid": "convo",
                "preset": dict(preset or {}),
            }
            if hasattr(self, "_log"):
                name = doc.display_name() if hasattr(doc, "display_name") else "Image"
                self._log(f"Convo/Deconvo preset ({op}) applied to '{name}'")
        except Exception:
            pass


    def _open_remove_green(self, doc=None):
        """
        Open Remove Green (SCNR) for the current view's document.
        If doc is passed (e.g. from Replay), use that; otherwise use the
        active subwindow's document (ROI or full).
        """
        from setiastro.saspro.remove_green import RemoveGreenDialog

        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        doc = sw.widget().document

        try:
            dlg = RemoveGreenDialog(self, doc, parent=self)
            dlg.show()
        except Exception as e:
            QMessageBox.warning(self, "Remove Green", f"Failed to open dialog:\n{e}")


    def SFCC_show(self):
        from setiastro.saspro.sfcc import SFCCDialog
        from setiastro.saspro.doc_manager import DocManager
        if getattr(self, "SFCC_window", None) and self.SFCC_window.isVisible():
            self.SFCC_window.raise_()
            self.SFCC_window.activateWindow()
            return

        # ensure we have a DocManager (if you already create it, keep yours)
        if not hasattr(self, "doc_manager") or self.doc_manager is None:
            self.doc_manager = DocManager(image_manager=getattr(self, "image_manager", None), parent=self)

        if not os.path.exists(sasp_data_path):
            QMessageBox.critical(self, "Missing Resource", f"SASP Data file not found:\n{sasp_data_path}")
            return

        self.SFCC_window = SFCCDialog(
            doc_manager=self.doc_manager,
            sasp_data_path=sasp_data_path,
            parent=self
        )
        try:
            self.SFCC_window.setWindowIcon(QIcon(spcc_icon_path))
        except Exception:
            pass

        try:
            self.SFCC_window.destroyed.connect(lambda _=None: setattr(self, "SFCC_window", None))
        except Exception:
            pass
        self.SFCC_window.show()

    def SSSC_show(self):
        from setiastro.saspro.sssc_loader import SSSCSplash, SSSCLoader
        from setiastro.saspro.doc_manager import DocManager

        if getattr(self, "SSSC_window", None) and self.SSSC_window.isVisible():
            self.SSSC_window.raise_()
            self.SSSC_window.activateWindow()
            return

        if not hasattr(self, "doc_manager") or self.doc_manager is None:
            self.doc_manager = DocManager(
                image_manager=getattr(self, "image_manager", None), parent=self)

        if not os.path.exists(sasp_data_path):
            QMessageBox.critical(self, "Missing Resource",
                f"SASP Data file not found:\n{sasp_data_path}")
            return

        splash = SSSCSplash(parent=self, sssc_path=sssc_path)
        splash.show()
        QApplication.processEvents()

        self._sssc_loader = SSSCLoader(parent=self)

        def _on_ready():
            splash.set_status("Building interface…")
            QApplication.processEvents()
            try:
                from setiastro.saspro.sssc import SSSCDialog  # already cached, instant
                self.SSSC_window = SSSCDialog(
                    doc_manager=self.doc_manager,
                    sasp_data_path=sasp_data_path,
                    parent=self,
                )
                try:
                    self.SSSC_window.setWindowIcon(QIcon(sssc_path))
                except Exception:
                    pass
                try:
                    self.SSSC_window.destroyed.connect(
                        lambda _=None: setattr(self, "SSSC_window", None))
                except Exception:
                    pass
                splash.close()
                self.SSSC_window.show()
            except Exception as exc:
                splash.close()
                QMessageBox.critical(self, "SSSC Error", f"Failed to open SSSC:\n{exc}")

        def _on_progress(msg):
            splash.set_status(msg)

        def _on_error(msg):
            splash.close()
            QMessageBox.critical(self, "SSSC Error", f"Failed to open SSSC:\n{msg}")

        self._sssc_loader.progress.connect(_on_progress)
        self._sssc_loader.ready.connect(_on_ready)
        self._sssc_loader.error.connect(_on_error)
        self._sssc_loader.start()

    def _open_nbextract(self):
        from setiastro.saspro.nbextract import NBExtractDialog
        from setiastro.saspro.doc_manager import DocManager

        if getattr(self, "_nbextract_window", None) and self._nbextract_window.isVisible():
            self._nbextract_window.raise_()
            self._nbextract_window.activateWindow()
            return

        if not hasattr(self, "doc_manager") or self.doc_manager is None:
            self.doc_manager = DocManager(
                image_manager=getattr(self, "image_manager", None),
                parent=self,
            )

        if not os.path.exists(sasp_data_path):
            QMessageBox.critical(
                self, "Missing Resource",
                f"SASP data file not found:\n{sasp_data_path}"
            )
            return

        self._nbextract_window = NBExtractDialog(
            doc_manager=self.doc_manager,
            sasp_data_path=sasp_data_path,
            parent=self,
        )

        try:
            self._nbextract_window.setWindowIcon(QIcon(nbextract_icon))
        except Exception:
            pass

        try:
            self._nbextract_window.destroyed.connect(
                lambda _=None: setattr(self, "_nbextract_window", None)
            )
        except Exception:
            pass

        self._nbextract_window.show()

    def _open_gaia_database(self):
        from setiastro.saspro.gaia_database import GaiaDatabaseDialog
        if getattr(self, "_gaia_db_window", None) and self._gaia_db_window.isVisible():
            self._gaia_db_window.raise_()
            self._gaia_db_window.activateWindow()
            return
        self._gaia_db_window = GaiaDatabaseDialog(parent=self)
        try:
            self._gaia_db_window.setWindowIcon(QIcon(gaia_path))
        except Exception:
            pass
        try:
            self._gaia_db_window.destroyed.connect(
                lambda _=None: setattr(self, "_gaia_db_window", None)
            )
        except Exception:
            pass
        self._gaia_db_window.show()

    def _open_magnitude_tool(self):
        import os
        from PyQt6.QtGui import QIcon
        from PyQt6.QtWidgets import QMessageBox

        # Keep same window-singleton behavior as SFCC
        if getattr(self, "MAG_window", None) and self.MAG_window.isVisible():
            self.MAG_window.raise_()
            self.MAG_window.activateWindow()
            return

        # ensure we have a DocManager (mirror SFCC pattern)
        from setiastro.saspro.doc_manager import DocManager
        if not hasattr(self, "doc_manager") or self.doc_manager is None:
            self.doc_manager = DocManager(image_manager=getattr(self, "image_manager", None), parent=self)

        # import tool
        from setiastro.saspro.magnitude_tool import MagnitudeToolDialog

        self.MAG_window = MagnitudeToolDialog(
            doc_manager=self.doc_manager,
            parent=self
        )

        # optional icon
        try:
            self.MAG_window.setWindowIcon(QIcon(magnitude_path))
        except Exception:
            pass

        # cleanup
        try:
            self.MAG_window.destroyed.connect(lambda _=None: setattr(self, "MAG_window", None))
        except Exception:
            pass

        self.MAG_window.show()

    def _open_snr_tool(self):
        from PyQt6.QtGui import QIcon

        if getattr(self, "SNR_window", None) and self.SNR_window.isVisible():
            self.SNR_window.raise_()
            self.SNR_window.activateWindow()
            return

        from setiastro.saspro.doc_manager import DocManager
        if not hasattr(self, "doc_manager") or self.doc_manager is None:
            self.doc_manager = DocManager(image_manager=getattr(self, "image_manager", None), parent=self)

        from setiastro.saspro.snr_tool import SNRToolDialog

        self.SNR_window = SNRToolDialog(
            parent=self,
            doc_manager=self.doc_manager,
            icon=QIcon(snr_path),
        )

        try:
            self.SNR_window.destroyed.connect(lambda _=None: setattr(self, "SNR_window", None))
        except Exception:
            pass

        self.SNR_window.show()


    def show_convo_deconvo(self, doc=None):
        # Reuse existing dialog if it's already open
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        doc = sw.widget().document

        from setiastro.saspro.convo import ConvoDeconvoDialog
        self.convo_window = ConvoDeconvoDialog(
            doc_manager=self.doc_manager,
            parent=self,
            doc=doc,  # <- KEY: bind dialog to this Document instance
        )
        try:
            self.convo_window.setWindowIcon(QIcon(convoicon_path))
        except Exception:
            pass
        try:
            self.convo_window.destroyed.connect(
                lambda _=None: setattr(self, "convo_window", None)
            )
        except Exception:
            pass

        self.convo_window.show()

    def _apply_extract_luminance_preset_to_doc(self, doc, preset=None):
        from PyQt6.QtWidgets import QMessageBox
        from setiastro.saspro.luminancerecombine import (
            compute_luminance,
            resolve_luma_profile_weights,
        )
        from setiastro.saspro.headless_utils import unwrap_docproxy
        import numpy as np

        doc = unwrap_docproxy(doc)
        p = dict(preset or {})

        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Extract Luminance", "No target image.")
            return

        img = np.asarray(doc.image)

        mode = str(p.get("mode", "rec709")).strip()
        resolved_method, w, profile_name = resolve_luma_profile_weights(mode)

        L = compute_luminance(img, method=resolved_method, weights=w)

        dm = getattr(self, "doc_manager", None)
        if dm is None:
            doc.apply_edit(L.astype(np.float32), step_name="Extract Luminance")
            return

        meta = {
            "step_name": "Extract Luminance",
            "luma_method": resolved_method,
        }
        if w is not None:
            meta["luma_weights"] = np.asarray(w, dtype=np.float32).tolist()
        if profile_name:
            meta["luma_profile"] = str(profile_name)

        try:
            suffix = f"{profile_name}" if profile_name else resolved_method
            new_doc = dm.create_document_from_array(
                L.astype(np.float32),
                name=f"{doc.display_name()} -- Luminance ({suffix})",
                is_mono=True,
                metadata=meta,
            )
            dm.add_document(new_doc)
        except Exception:
            doc.apply_edit(L.astype(np.float32), step_name="Extract Luminance")

    def _copy_active_to_clipboard(self):
        sw = None
        try:
            if getattr(self, "mdi", None) is not None:
                sw = self.mdi.activeSubWindow()
        except Exception:
            sw = None

        vw = None
        if sw is not None:
            try:
                vw = sw.widget()
            except Exception:
                vw = None

        # Preferred: copy what the user is actually seeing (viewport crop)
        if vw is not None and hasattr(vw, "copy_viewport_to_clipboard_image"):
            try:
                qimg = vw.copy_viewport_to_clipboard_image()
                if qimg is not None and not qimg.isNull():
                    QApplication.clipboard().setImage(qimg)
                    return
            except Exception as e:
                QMessageBox.warning(self, "Copy", f"Failed to copy viewport:\n\n{e}")
                return

        # Fallback: old behavior (raw doc -> full image)
        doc = self.docman.get_active_document()
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Copy", "No active image to copy.")
            return

        try:
            qimg = float01_to_qimage(doc.image)
            QApplication.clipboard().setImage(qimg)
        except Exception as e:
            QMessageBox.warning(self, "Copy", f"Failed to copy image:\n\n{e}")


    def _paste_clipboard_as_new_document(self):
        cb = QApplication.clipboard()
        md = cb.mimeData()

        # 1) If clipboard contains an image, paste as new document
        if cb.mimeData().hasImage():
            try:
                qimg = cb.image()
                arr = qimage_to_float01_rgb(qimg)

                meta = {
                    "display_name": f"Pasted {time.strftime('%H-%M-%S')}",
                    "bit_depth": "32-bit floating point",
                    "original_format": "clipboard",
                    "is_mono": False,
                    # IMPORTANT: clipboard has no FITS header/WCS
                }
                self.docman.open_array(arr, metadata=meta, title=meta["display_name"])
                return
            except Exception as e:
                QMessageBox.warning(self, "Paste", f"Failed to paste image:\n\n{e}")
                return

        # 2) Nice-to-have: paste file paths (copy file in Explorer/Finder)
        if md.hasUrls():
            urls = md.urls()
            paths = []
            for u in urls:
                try:
                    if u.isLocalFile():
                        paths.append(u.toLocalFile())
                except Exception:
                    pass

            if paths:
                opened = 0
                for p in paths:
                    try:
                        self.docman.open_path(p)
                        opened += 1
                    except Exception:
                        pass
                if opened:
                    return

        QMessageBox.information(self, "Paste", "Clipboard does not contain an image (or valid file paths).")



    def _extract_luminance(self, doc=None, preset: dict | None = None):
        from PyQt6.QtWidgets import QMessageBox
        from PyQt6.QtGui import QIcon
        from setiastro.saspro.luminancerecombine import (
            compute_luminance,
            resolve_luma_profile_weights,
            canonicalize_luma_key,
        )


        sw = None
        if doc is None:
            sw = self.mdi.activeSubWindow()
            if not sw:
                QMessageBox.information(self, "Extract Luminance", "No active image window.")
                return
            vw = sw.widget()
            doc = getattr(vw, "document", None)

        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Extract Luminance", "Active document has no image.")
            return

        img = np.asarray(doc.image)
        if img.ndim != 3 or img.shape[2] != 3:
            QMessageBox.information(self, "Extract Luminance", "Luminance extraction requires an RGB image.")
            return

        p = dict(preset or {})
        mode = str(
            p.get("mode",
            p.get("method",
            p.get("luma_method",
                getattr(self, "luma_method", "rec709"))))
        ).strip()

        resolved_method, w, profile_name = resolve_luma_profile_weights(mode)

        y = compute_luminance(img, method=resolved_method, weights=w)

        # ---- metadata & title ----
        base_meta = {}
        try:
            base_meta = dict(getattr(doc, "metadata", {}) or {})
        except Exception:
            pass

        meta = {
            **base_meta,
            "source": "ExtractLuminance",
            "is_mono": True,
            "bit_depth": "32f",
            # Store canonical profile key (e.g. "sensor:Sony IMX571 (ASI2600/QHY268)")
            # rather than internal dispatch method — preserves sensor identity for
            # round-tripping into Recombine Luminance.
            "luma_method": canonicalize_luma_key(mode),
            # Also keep the internal dispatch method for tools that need it directly.
            "luma_compute_method": resolved_method,
        }
        if w is not None:
            meta["luma_weights"] = np.asarray(w, dtype=np.float32).tolist()
        if profile_name:
            meta["luma_profile"] = str(profile_name)

        base_title = sw.windowTitle() if sw else (getattr(doc, "title", getattr(doc, "name", "")) or "Untitled")
        suffix = f"{profile_name}" if profile_name else resolved_method
        title = f"{base_title} -- Luminance ({suffix})"

        dm = getattr(self, "docman", None)
        if dm is None:
            QMessageBox.critical(self, "Extract Luminance", "DocManager not available.")
            return

        try:
            if hasattr(dm, "open_array"):
                new_doc = dm.open_array(y, metadata=meta, title=title)
            elif hasattr(dm, "open_numpy"):
                new_doc = dm.open_numpy(y, metadata=meta, title=title)
            elif hasattr(dm, "create_document"):
                new_doc = dm.create_document(image=y, metadata=meta, name=title)
            else:
                raise RuntimeError("DocManager lacks open_array/open_numpy/create_document")
        except Exception as e:
            QMessageBox.critical(self, "Extract Luminance", f"Failed to create document:\n{e}")
            return

        try:
            self._spawn_subwindow_for(new_doc)
            sub = self.mdi.activeSubWindow()
            if sub:
                sub.setWindowIcon(QIcon(LExtract_path))
        except Exception:
            pass

        try:
            remember = getattr(self, "remember_last_headless_command", None) or getattr(self, "_remember_last_headless_command", None)
            if callable(remember):
                remember("extract_luminance", {"mode": mode}, description="Extract Luminance")
        except Exception:
            pass

        if hasattr(self, "_log"):
            self._log(f"Extract Luminance ({suffix}) -> new mono document created.")

        return new_doc


    def _subwindow_docs(self):
        docs = []
        for sw in self.mdi.subWindowList():
            w = sw.widget()
            d = getattr(w, "document", None)
            if d is not None and getattr(d, "image", None) is not None:
                docs.append((sw.windowTitle(), d))
        return docs

    def _recombine_luminance_ui(self, target_doc=None):
        """Pick a luminance source and recombine into the target document."""
        from PyQt6.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QSlider,
            QDoubleSpinBox, QDialogButtonBox, QComboBox, QPushButton,
            QFrame,
        )
        from PyQt6.QtCore import Qt

        # ── Resolve target ────────────────────────────────────────────────────
        if target_doc is None:
            sw = self.mdi.activeSubWindow()
            if not sw:
                QMessageBox.information(self, "Recombine Luminance", "No active image window.")
                return
            target_doc = getattr(sw.widget(), "document", None)
            if target_doc is None or getattr(target_doc, "image", None) is None:
                QMessageBox.information(self, "Recombine Luminance", "Active window has no image.")
                return

        tgt_img = np.asarray(target_doc.image)
        if tgt_img.ndim != 3 or tgt_img.shape[2] != 3:
            QMessageBox.warning(self, "Recombine Luminance", "Target image must be RGB.")
            return

        # ── Gather candidates ─────────────────────────────────────────────────
        candidates = []
        for title, d in self._subwindow_docs():
            if d is target_doc:
                continue
            img = getattr(d, "image", None)
            if img is None:
                continue
            if img.ndim == 2 or (img.ndim == 3 and img.shape[2] in (1, 3)):
                candidates.append((title, d))

        if not candidates:
            QMessageBox.information(
                self, "Recombine Luminance",
                "Open a luminance (mono) view or any image to use as L."
            )
            return

        # ── Dialog ────────────────────────────────────────────────────────────
        dlg = QDialog(self)
        dlg.setWindowTitle("Recombine Luminance")
        dlg.setMinimumWidth(420)
        lay = QVBoxLayout(dlg)

        # Source selector
        lay.addWidget(QLabel("Luminance source:"))
        src_combo = QComboBox()
        for title, _ in candidates:
            src_combo.addItem(title)
        for i, (title, d) in enumerate(candidates):
            img = getattr(d, "image", None)
            if img is not None and img.ndim == 2:
                src_combo.setCurrentIndex(i)
                break
        lay.addWidget(src_combo)

        lay.addSpacing(8)

        # ── Luminance weighting profile ───────────────────────────────────────
        from setiastro.saspro.luminancerecombine import (
            iter_luma_profiles_by_category,
            guess_profile_from_metadata,
            find_sensor_profile_key_by_display_name,
        )

        lay.addWidget(QLabel(
            "Luminance weighting profile:\n"
            "Controls how R, G, B are weighted when computing/replacing Y.\n"
            "For sensor data, pick the matching sensor; Rec.709 is a safe default."
        ))
        profile_combo = QComboBox()
        # Populate grouped by category, using disabled header rows as separators.
        _current_category: list[str] = []
        for category_path, key, description, info in iter_luma_profiles_by_category():
            if category_path != _current_category:
                if profile_combo.count() > 0:
                    profile_combo.insertSeparator(profile_combo.count())
                cat_label = " / ".join(category_path) if category_path else ""
                header_idx = profile_combo.count()
                profile_combo.addItem(f"— {cat_label} —")
                _model = profile_combo.model()
                _item = _model.item(header_idx) if hasattr(_model, "item") else None
                if _item is not None:
                    _item.setEnabled(False)
                _current_category = list(category_path)
            profile_combo.addItem(description, userData=key)
            if info:
                profile_combo.setItemData(
                    profile_combo.count() - 1, info, Qt.ItemDataRole.ToolTipRole
                )

        # Helpers scoped to this dialog ------------------------------------------------
        def _profile_key_exists(key: str) -> bool:
            if not key:
                return False
            for i in range(profile_combo.count()):
                if profile_combo.itemData(i) == key:
                    return True
            return False

        def _select_profile_key(key: str) -> bool:
            for i in range(profile_combo.count()):
                if profile_combo.itemData(i) == key:
                    profile_combo.setCurrentIndex(i)
                    return True
            return False

        def _pick_default_for_source(src_doc_obj) -> str:
            """
            Priority:
              1. Source doc's luma_method metadata (L was extracted with a known method).
              2. Legacy recovery: source doc's luma_profile display name (for older
                 extracted-L docs where luma_method was collapsed to 'rec709' but
                 the sensor name survived in luma_profile).
              3. Target doc metadata auto-detect (INSTRUME etc.).
              4. Global self.luma_method (persisted).
              5. rec709.
            """
            src_meta = dict(getattr(src_doc_obj, "metadata", {}) or {})

            src_method = src_meta.get("luma_method")
            if src_method and _profile_key_exists(str(src_method)):
                return str(src_method)

            # Legacy recovery for older extracted-L docs
            legacy_key = find_sensor_profile_key_by_display_name(src_meta.get("luma_profile"))
            if legacy_key and _profile_key_exists(legacy_key):
                return legacy_key

            auto_key = guess_profile_from_metadata(getattr(target_doc, "metadata", {}) or {})
            if auto_key and _profile_key_exists(auto_key):
                return auto_key

            global_key = getattr(self, "luma_method", None)
            if global_key and _profile_key_exists(str(global_key)):
                return str(global_key)

            return "rec709"

        # Track whether the user has manually overridden the auto-selection; once
        # they do, we stop clobbering their choice when the source combo changes.
        _user_override = {"value": False}

        def _on_profile_user_changed(_idx):
            _user_override["value"] = True
        profile_combo.activated.connect(_on_profile_user_changed)  # activated = user-only

        def _on_source_changed(idx):
            if _user_override["value"]:
                return
            if 0 <= idx < len(candidates):
                _, new_src_doc = candidates[idx]
                _select_profile_key(_pick_default_for_source(new_src_doc))
        src_combo.currentIndexChanged.connect(_on_source_changed)

        # Initial selection based on the source that's currently chosen
        _initial_src_doc = candidates[src_combo.currentIndex()][1]
        _select_profile_key(_pick_default_for_source(_initial_src_doc))

        lay.addWidget(profile_combo)

        lay.addSpacing(8)

        # ── Blend ─────────────────────────────────────────────────────────────
        lay.addWidget(QLabel("Blend strength  (1.0 = full L replacement):"))

        def _linked_row(lo, hi, decimals, step, default, scale=100):
            """Return (row_layout, slider, spinbox). scale controls slider int range."""
            row = QHBoxLayout()
            slider = QSlider(Qt.Orientation.Horizontal)
            slider.setRange(int(round(lo * scale)), int(round(hi * scale)))
            slider.setValue(int(round(default * scale)))
            spin = QDoubleSpinBox()
            spin.setRange(lo, hi)
            spin.setSingleStep(step)
            spin.setDecimals(decimals)
            spin.setValue(default)
            spin.setFixedWidth(72)
            slider.valueChanged.connect(lambda v, s=spin, sc=scale: s.setValue(v / sc))
            spin.valueChanged.connect(lambda v, sl=slider, sc=scale: sl.setValue(int(round(v * sc))))
            row.addWidget(slider, 1)
            row.addWidget(spin)
            return row, slider, spin

        blend_row, blend_slider, blend_spin = _linked_row(0.0, 1.0, 2, 0.05, 1.0)
        lay.addLayout(blend_row)

        lay.addSpacing(8)

        # ── Advanced (collapsed by default) ───────────────────────────────────
        adv_btn = QPushButton("▶  Advanced")
        adv_btn.setCheckable(True)
        adv_btn.setChecked(False)
        adv_btn.setFlat(True)
        adv_btn.setStyleSheet("text-align:left; font-weight:600;")
        lay.addWidget(adv_btn)

        adv_frame = QFrame()
        adv_frame.setFrameShape(QFrame.Shape.StyledPanel)
        adv_frame.setVisible(False)
        adv_lay = QVBoxLayout(adv_frame)
        adv_lay.setContentsMargins(8, 6, 8, 6)
        adv_lay.setSpacing(6)

        # Saturation boost
        adv_lay.addWidget(QLabel(
            "Saturation boost  (0.0 = no change, applied before recombine):\n"
            "Enriches colour before L is placed — cannot skew the new luminance.\n"
            "Negative values desaturate."
        ))
        # Range -1.0..3.0, scale=100 → slider -100..300
        sat_row, sat_slider, sat_spin = _linked_row(-1.0, 3.0, 2, 0.05, 0.0, scale=100)
        adv_lay.addLayout(sat_row)

        adv_lay.addSpacing(4)

        # Chrominance NR
        adv_lay.addWidget(QLabel(
            "Chrominance NR  (σ px, 0.0 = disabled, applied before recombine):\n"
            "Blurs only Cb/Cr — preserves luma detail while reducing colour noise.\n"
            "Typical range: 0.5–3.0 px."
        ))
        # Range 0.0..20.0, scale=10 → slider 0..200 (0.1px steps)
        cnr_row, cnr_slider, cnr_spin = _linked_row(0.0, 20.0, 1, 0.5, 0.0, scale=10)
        adv_lay.addLayout(cnr_row)

        adv_lay.addSpacing(4)

        # Pedestal
        adv_lay.addWidget(QLabel(
            "Noise-floor pedestal  (0.05 = default 5% lift):\n"
            "Prevents near-zero hue skew in deep shadows.\n"
            "0.0 = disabled (pure linear scaling)."
        ))
        ped_row, ped_slider, ped_spin = _linked_row(0.0, 0.5, 3, 0.005, 0.05, scale=1000)
        adv_lay.addLayout(ped_row)

        adv_lay.addSpacing(4)

        # Soft knee
        adv_lay.addWidget(QLabel(
            "Highlight soft-knee  (0.0 = disabled):\n"
            "Compresses over-bright scaling to protect highlights."
        ))
        knee_row, knee_slider, knee_spin = _linked_row(0.0, 1.0, 2, 0.05, 0.0)
        adv_lay.addLayout(knee_row)

        lay.addWidget(adv_frame)

        def _toggle_adv(checked):
            adv_frame.setVisible(checked)
            adv_btn.setText(("▼" if checked else "▶") + "  Advanced")
            dlg.adjustSize()

        adv_btn.toggled.connect(_toggle_adv)

        lay.addSpacing(8)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        btn_row = QHBoxLayout()
        btn_row.setContentsMargins(0, 0, 0, 0)
        btn_help = make_help_button("luminance_recombine", dlg)
        btn_row.addWidget(btn_help)
        btn_row.addStretch(1)
        btn_row.addWidget(btns)
        lay.addLayout(btn_row)

        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        # Persist the chosen profile as the new global default
        _chosen_key = profile_combo.currentData()
        if _chosen_key:
            self.luma_method = _chosen_key

        idx               = src_combo.currentIndex()
        sel_title, src_doc = candidates[idx]
        blend             = float(blend_spin.value())
        pedestal          = float(ped_spin.value())
        soft_knee         = float(knee_spin.value())
        saturation_boost  = float(sat_spin.value())
        chrominance_nr    = float(cnr_spin.value())

        # ── Apply ─────────────────────────────────────────────────────────────
        try:
            from setiastro.saspro.luminancerecombine import (
                apply_recombine_to_doc,
                _to_float01_strict,
            )

            src_img = _to_float01_strict(np.asarray(src_doc.image))

            # Dropdown selection is authoritative. apply_recombine_to_doc
            # calls resolve_luma_profile_weights internally, which handles
            # sensor:xxx keys → per-sensor weight vectors automatically.
            method        = profile_combo.currentData() or "rec709"
            profile_label = profile_combo.currentText()

            apply_recombine_to_doc(
                target_doc,
                luminance_source_img=src_img,
                method=method,
                weights=None,
                noise_sigma=None,
                blend=blend,
                soft_knee=soft_knee,
                pedestal=pedestal,
                saturation_boost=saturation_boost,
                chrominance_nr_sigma=chrominance_nr,
            )

            try:
                self._log(
                    f"Recombine Luminance: '{sel_title}' → '{target_doc.display_name()}'"
                    f" [{profile_label}] blend={blend:.2f}  pedestal={pedestal:.3f}"
                    f"  knee={soft_knee:.2f}  sat={saturation_boost:.2f}"
                    f"  cnr={chrominance_nr:.1f}px"
                )
            except Exception:
                pass

        except Exception as e:
            QMessageBox.critical(self, "Recombine Luminance", f"Failed: {e}")

    def _rgb_extract_active(self):
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "RGB Extract", "No active image window.")
            return
        view = sw.widget()
        doc = getattr(view, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "RGB Extract", "Active document has no image.")
            return
        self._rgb_extract_on_doc(doc, base_title=sw.windowTitle())

    def _rgb_extract_on_doc(self, doc, base_title: str | None = None):
        img = getattr(doc, "image", None)
        if img is None:
            QMessageBox.information(self, "RGB Extract", "No image to extract.")
            return
        if img.ndim != 3 or img.shape[2] != 3:
            QMessageBox.information(self, "RGB Extract", "Image is not a 3-channel RGB image.")
            return

        try:
            r, g, b = extract_rgb_channels(img)
        except Exception as e:
            QMessageBox.critical(self, "RGB Extract", f"Failed to split channels:\n{e}")
            return

        dm = getattr(self, "docman", None)
        if not dm:
            QMessageBox.critical(self, "RGB Extract", "Document manager not available.")
            return

        # derive base name for the three windows
        base = base_title or (getattr(doc, "display_name", lambda: None)() or "RGB")

        def _open(arr, suffix):
            from astropy.io import fits

            # ---- 1) start from source metadata (preserve headers/WCS) ----
            src_meta = getattr(doc, "metadata", {}) or {}
            meta = dict(src_meta)  # shallow copy of top-level dict

            # Preserve header objects safely
            fits_hdr = src_meta.get("fits_header")
            wcs_hdr  = src_meta.get("wcs_header")
            orig_hdr = src_meta.get("original_header")

            # Keep them if they are astropy Headers; otherwise fall back gracefully
            meta["fits_header"] = fits_hdr.copy() if isinstance(fits_hdr, fits.Header) else fits_hdr
            meta["wcs_header"]  = wcs_hdr.copy()  if isinstance(wcs_hdr,  fits.Header) else wcs_hdr
            meta["original_header"] = orig_hdr.copy() if isinstance(orig_hdr, fits.Header) else orig_hdr

            # Preserve WCS object + flags (ok if None)
            if "wcs" in src_meta:
                meta["wcs"] = src_meta.get("wcs")
            if "HasAstrometricSolution" in src_meta:
                meta["HasAstrometricSolution"] = src_meta.get("HasAstrometricSolution")

            # Preserve image_meta mirror, but make it a copy so we don't mutate parent
            im = src_meta.get("image_meta")
            if isinstance(im, dict):
                meta["image_meta"] = dict(im)

            # ---- 2) overwrite/extend with RGB-extract specific fields ----
            base = base_title or (getattr(doc, "display_name", lambda: None)() or "RGB")
            title = f"{base}_{suffix}"
            try:
                fh = meta.get("fits_header")
                if isinstance(fh, fits.Header):
                    fh["NAXIS"] = 2
                    if "NAXIS3" in fh:
                        del fh["NAXIS3"]
            except Exception:
                pass
            meta.update({
                "source": "RGB Extract",
                "is_mono": True,
                "bit_depth": "32-bit floating point",
                "parent_title": base,
                "channel": suffix,   # handy for later
            })

            # ---- 3) create doc ----
            try:
                if hasattr(dm, "open_array"):
                    newdoc = dm.open_array(arr, metadata=meta, title=title)
                elif hasattr(dm, "open_numpy"):
                    newdoc = dm.open_numpy(arr, metadata=meta, title=title)
                else:
                    newdoc = dm.create_document(image=arr, metadata=meta, name=title)

                # ---- 4) ensure WCS is internally consistent on the new doc ----
                # If source had a WCS solution, rebuild original_header+wcs using your canonical path.
                try:
                    if meta.get("HasAstrometricSolution") or (meta.get("wcs_header") is not None):
                        wcs_dict = self._extract_wcs_dict(doc)  # from SOURCE doc
                        if wcs_dict:
                            self._apply_wcs_dict_to_doc(newdoc, dict(wcs_dict))
                except Exception:
                    pass

                self._spawn_subwindow_for(newdoc)

            except Exception as ex:
                QMessageBox.critical(self, "RGB Extract", f"Failed to open '{title}':\n{ex}")


        _open(r, "R")
        _open(g, "G")
        _open(b, "B")

        # optional log
        if hasattr(self, "_log"):
            self._log(f"RGB Extract -> created '{base}_R', '{base}_G', '{base}_B'")

    def _list_open_docs_for_rgb(self):
        items = []
        for sw in self.mdi.subWindowList():
            w = sw.widget()
            doc = getattr(w, "document", None)
            if doc is not None:
                items.append((sw.windowTitle(), doc))
        return items

    def _open_rgb_combination(self):
        from setiastro.saspro.rgb_combination import RGBCombinationDialogPro
        dlg = RGBCombinationDialogPro(
            parent=self,
            list_open_docs_fn=self._list_open_docs_for_rgb,
            doc_manager=getattr(self, "docman", None)
        )
        try:
            dlg.setWindowIcon(QIcon(rgbcombo_path))
        except Exception:
            pass
        dlg.resize(600, 360)
        dlg.show()

    def _open_blemish_blaster(self):
        from setiastro.saspro.blemish_blaster import BlemishBlasterDialogPro
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Blemish Blaster", "No active image window.")
            return
        view = sw.widget()
        doc  = getattr(view, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Blemish Blaster", "Active document has no image.")
            return
        dlg = BlemishBlasterDialogPro(self, doc)
        try:
            dlg.setWindowIcon(QIcon(blastericon_path))
        except Exception:
            pass
        dlg.resize(900, 650)
        dlg.show()

    def _open_clone_stamp(self):
        from setiastro.saspro.clone_stamp import CloneStampDialogPro
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Clone Stamp", "No active image window.")
            return
        view = sw.widget()
        doc  = getattr(view, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Clone Stamp", "Active document has no image.")
            return

        dlg = CloneStampDialogPro(self, doc)
        try:
            dlg.setWindowIcon(QIcon(clonestampicon_path))
        except Exception:
            pass
        dlg.resize(900, 650)
        dlg.show()


    def _open_wavescale_hdr(self):
        from setiastro.saspro.wavescale_hdr import WaveScaleHDRDialogPro
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "WaveScale HDR", "No active image window.")
            return
        view = sw.widget()
        doc = getattr(view, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "WaveScale HDR", "Active document has no image.")
            return

        dlg = WaveScaleHDRDialogPro(self, doc, icon_path=hdr_path)

        # -- NEW: capture preset for replay when user clicks Apply ------
        def _on_applied(doc_obj, preset: dict):
            try:
                # Whatever helper you used for Curves / GHS:
                # cid is what command-drop & replay will call.
                self._register_replay_action(
                    cid="wavescale_hdr",
                    label="WaveScale HDR",
                    preset=dict(preset or {}),
                    target_doc=doc_obj,
                )
            except Exception:
                pass

        try:
            dlg.applied_preset.connect(_on_applied)
        except Exception:
            pass
        # ----------------------------------------

        dlg.resize(980, 700)
        dlg.show()


    def _open_wavescale_dark_enhance(self):
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "WaveScale Dark Enhancer", "No active image window.")
            return
        view = sw.widget()
        doc  = getattr(view, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "WaveScale Dark Enhancer", "Active document has no image.")
            return

        try:
            # Prefer the Pro dialog name; fall back to the non-Pro name if that's what you used.
            from setiastro.saspro.wavescalede import WaveScaleDarkEnhancerDialogPro as _Dlg
        except Exception:
            try:
                from setiastro.saspro.wavescalede import WaveScaleDarkEnhanceDialog as _Dlg
            except Exception as e:
                QMessageBox.warning(self, "WaveScale Dark Enhancer", f"Failed to import dialog:\n{e}")
                return

        try:
            dlg = _Dlg(self, doc, icon_path=dse_icon_path)  # matches our Pro dialogs' __init__(parent, doc, icon_path)
        except TypeError:
            # if your ctor is (image_manager,parent) like the SASv2 snippet:
            dlg = _Dlg(image_manager=getattr(self, "image_manager", None), parent=self)
        try:
            dlg.setWindowIcon(QIcon(dse_icon_path))
        except Exception:
            pass
        dlg.resize(900, 650)
        dlg.show()

    def _open_fx_tool(self):
        """Open the FX dialog (Orton Glow, Soft Focus, Bloom, Vignette, Grain, Split Tone)
        on the active document."""
        doc = None
        if hasattr(self, "mdi") and self.mdi.activeSubWindow():
            sw = self.mdi.activeSubWindow().widget()
            doc = getattr(sw, "document", None)
        if doc is None and getattr(self, "docman", None) and self.docman._docs:
            doc = self.docman._docs[-1]
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        from setiastro.saspro.fx_module import FXDialog
        w = FXDialog(self, doc, parent=self)
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        try:
            w.setWindowIcon(QIcon(fx_path))
        except Exception:
            pass
        w.show()

    def _open_clahe(self):
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "CLAHE", "Open an image first.")
            return
        view = sw.widget()
        doc = getattr(view, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "CLAHE", "Active document has no image.")
            return
        try:
            from setiastro.saspro.clahe import CLAHEDialogPro
            dlg = CLAHEDialogPro(self, doc, icon=QIcon(clahe_path))
            dlg.resize(900, 650)
            dlg.show()
        except Exception as e:
            QMessageBox.warning(self, "CLAHE", f"Failed to open dialog:\n{e}")

    def _apply_clahe_preset_to_doc(self, doc, preset: dict | None):
        """
        Headless CLAHE apply on a document using a preset dict.
        Expected keys: clip_limit (float, e.g. 2.0), tile (int, e.g. 8)
        """
        try:
            from setiastro.saspro.clahe import apply_clahe_to_doc
            p = dict(preset or {"clip_limit": 2.0, "tile": 8})
            apply_clahe_to_doc(doc, p)

            # -- also register as last_headless_command for replay ------
            try:
                payload = {
                    "command_id": "clahe",
                    "preset": dict(p),
                }
                setattr(self, "_last_headless_command", payload)
            except Exception:
                pass
            # ----------------------------------------

        except Exception as e:
            raise RuntimeError(f"CLAHE apply failed: {e}")

    def _apply_morphology_preset_to_doc(self, doc, preset: dict | None):
        """
        Headless Morphology apply on a document using a preset dict.
        Expected keys:
           operation: "erosion" | "dilation" | "opening" | "closing"
           kernel: odd int (3,5,7,...)
           iterations: int
        """
        try:
            from setiastro.saspro.morphology import apply_morphology_to_doc
            p = dict(preset or {})
            apply_morphology_to_doc(doc, p)

            # -- also register as last_headless_command for replay ------
            try:
                payload = {
                    "command_id": "morphology",
                    "preset": dict(p),
                }
                setattr(self, "_last_headless_command", payload)
            except Exception:
                pass
            # ----------------------------------------

        except Exception as e:
            raise RuntimeError(f"Morphology apply failed: {e}")


    def _open_morphology(self, preset: dict | None = None):
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Morphology", "No active image window.")
            return
        doc = getattr(sw.widget(), "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Morphology", "Active document has no image.")
            return
        from setiastro.saspro.morphology import MorphologyDialogPro
        dlg = MorphologyDialogPro(self, doc, icon=QIcon(morpho_path), initial=preset or {})
        dlg.resize(900, 600)
        dlg.show()

    def _open_morphology_with_preset(self, preset: dict | None):
        self._open_morphology(preset or {})

    def _apply_pixelmath_preset_to_doc(self, doc, preset: dict | None):
        """
        Headless Pixel Math apply on a document using a preset dict.

        Preset fields:
           mode: 'single' or 'rgb' (optional, informational)
           expr:   single-expression mode (string)
           expr_r / expr_g / expr_b: per-channel expressions (strings)
        """
        from setiastro.saspro.pixelmath import apply_pixel_math_to_doc

        p = dict(preset or {})
        apply_pixel_math_to_doc(self, doc, p)

        # Also register as last_headless_command so replay uses this
        try:
            payload = {
                "command_id": "pixel_math",
                "preset": dict(p),
            }
            setattr(self, "_last_headless_command", payload)
        except Exception:
            pass


    def _open_pixel_math(self):
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Pixel Math", "No active image window.")
            return
        doc = getattr(sw.widget(), "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Pixel Math", "Active document has no image.")
            return
        from setiastro.saspro.pixelmath import PixelMathDialogPro
        dlg = PixelMathDialogPro(self, doc, icon=QIcon(pixelmath_path))
        dlg.resize(820, 560)
        dlg.show()

    def _open_signature_insert(self):
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Signature / Insert", "No active image window."); return
        doc = getattr(sw.widget(), "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Signature / Insert", "Active document has no image."); return
        from setiastro.saspro.signature_insert import SignatureInsertDialogPro
        dlg = SignatureInsertDialogPro(self, doc, icon=QIcon(signature_icon_path))
        dlg.show()

    def _open_halo_b_gon(self):
        sw = self.mdi.activeSubWindow()
        if not sw: 
            QMessageBox.information(self, "Halo-B-Gon", "No active image view."); return
        doc = getattr(sw.widget(), "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Halo-B-Gon", "Active view has no image."); return
        from setiastro.saspro.halobgon import HaloBGonDialogPro
        dlg = HaloBGonDialogPro(self, doc, icon=QIcon(halo_path))
        dlg.show()

    def _apply_halobgon_preset_to_doc(self, doc, preset: dict | None):
        """
        Headless Halo-B-Gon apply on a document using a preset dict.

        Preset keys:
           reduction: int 0..3
           linear: bool
        """
        from setiastro.saspro.halobgon import apply_halo_b_gon_to_doc

        p = dict(preset or {})
        apply_halo_b_gon_to_doc(self, doc, p)

        # Also register as last_headless_command so replay uses this
        try:
            payload = {
                "command_id": "halo_b_gon",
                "preset": dict(p),
            }
            setattr(self, "_last_headless_command", payload)
        except Exception:
            pass


    def _open_aberration_ai(self):
        from setiastro.saspro.aberration_ai import AberrationAIDialog
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Aberration Correction", "No active image view.")
            return

        w = sw.widget() if hasattr(sw, "widget") else None
        doc = getattr(w, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Aberration Correction", "Active view has no image.")
            return

        # Live active-doc resolver so the non-modal dialog tracks view switches
        # (a lambda closing over `doc` would pin it to this one image forever).
        def _get_active():
            try:
                d = getattr(self, "_active_doc", None)
                if callable(d):
                    r = d()
                    if r is not None:
                        return r
            except Exception:
                pass
            try:
                s = self.mdi.activeSubWindow()
                ww = s.widget() if (s and hasattr(s, "widget")) else None
                return getattr(ww, "document", None)
            except Exception:
                return None

        try:
            dlg = AberrationAIDialog(self, self.docman, _get_active, icon=QIcon(aberration_path))
            self._aberration_ai_dialog = dlg          # retain ref (dialog is NOT WA_DeleteOnClose)
            dlg.show(); dlg.raise_(); dlg.activateWindow()
        except Exception as e:
            print(f"Failed to open Aberration AI: {e}")

    def _execute_syqon_tools_command(self, preset: dict | None = None, target_sw=None):
        from setiastro.saspro.remove_stars_preset import run_remove_stars_via_preset
        from setiastro.saspro.syqon_tools import run_syqon_tools_via_preset

        preset = dict(preset or {})
        family = str(preset.get("family", "starless") or "starless").strip().lower()

        # Resolve the doc: prefer the explicit drop target, else the active doc.
        doc = None
        if target_sw is not None:
            try:
                w = target_sw.widget() if callable(getattr(target_sw, "widget", None)) else getattr(target_sw, "widget", None)
                if hasattr(w, "document") and w.document is not None:
                    doc = w.document
                elif hasattr(w, "doc") and w.doc is not None:
                    doc = w.doc
            except Exception:
                doc = None
        if doc is None:
            try:
                doc = self.get_active_doc()
            except Exception:
                doc = None

        # A drop on a specific window is a HEADLESS apply, regardless of auto_run.
        # auto_run only matters for the no-target path handled elsewhere. Only fall
        # back to the UI if we genuinely have no document to act on.
        if doc is None or getattr(doc, "image", None) is None:
            self._open_syqon_tools(preset)
            return

        # Starless is owned by remove_stars' preset runner.
        if family == "starless":
            remove_stars_preset = {
                "tool": "syqon",
                "model_kind": str(preset.get("starless_model_kind", "nadir") or "nadir"),
                "tile_size": int(preset.get("starless_tile_size", 512)),
                "overlap": int(preset.get("starless_overlap", 64)),
                "make_stars": bool(preset.get("starless_make_stars", True)),
                "pad_edges": bool(preset.get("starless_pad_edges", True)),
                "pad_pixels": int(preset.get("starless_pad_pixels", 128)),
                "stars_extract": str(preset.get("starless_stars_extract", "subtract")),
            }
            run_remove_stars_via_preset(self, doc, remove_stars_preset)
            return

        # Denoise (Prism) AND Sharpening (Parallax) both route through the shared
        # headless entrypoint, which dispatches on family internally.
        run_syqon_tools_via_preset(self, doc, preset)
        
    def _open_syqon_tools(self):
        from setiastro.saspro.syqon_tools import SyQonToolsDialog

        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "SyQon Tools", "No active image view.")
            return

        w = sw.widget() if hasattr(sw, "widget") else None
        doc = getattr(w, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "SyQon Tools", "Active view has no image.")
            return

        try:
            # keep one persistent reference so it does not get garbage-collected
            if not hasattr(self, "_syqon_tools_dialog"):
                self._syqon_tools_dialog = None

            # if already open, just bring it forward
            if self._syqon_tools_dialog is not None:
                try:
                    self._syqon_tools_dialog.show()
                    self._syqon_tools_dialog.raise_()
                    self._syqon_tools_dialog.activateWindow()
                    return
                except Exception:
                    self._syqon_tools_dialog = None

            # Resolve the ACTIVE doc live on every call — never freeze the doc
            # that was active when the dialog opened, or SyQon can't follow a
            # view switch. ROI-aware, matching _open_statistical_stretch.
            def _resolve_active_doc():
                sw2 = self.mdi.activeSubWindow()
                if not sw2:
                    return None
                view2 = sw2.widget() if hasattr(sw2, "widget") else None
                if view2 is None:
                    return None
                mgr = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
                try:
                    if mgr is not None and hasattr(mgr, "get_document_for_view"):
                        d = mgr.get_document_for_view(view2)
                        if d is not None:
                            return d
                except Exception:
                    pass
                return getattr(view2, "document", None) or getattr(view2, "doc", None)

            dlg = SyQonToolsDialog(
                self,
                self.docman,
                get_active_doc_callable=_resolve_active_doc,
                icon=QIcon(syqon_path),
            )

            # modeless behavior
            dlg.setModal(False)
            dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

            # clear reference when user closes it
            dlg.destroyed.connect(lambda *_: setattr(self, "_syqon_tools_dialog", None))

            self._syqon_tools_dialog = dlg
            dlg.show()
            dlg.raise_()
            dlg.activateWindow()

        except Exception as e:
            print(f"Failed to open SyQon Tools: {e}")

    def _open_rcastro(self):
        from setiastro.saspro.rcastro import open_rcastro_dialog
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "RC-Astro Tools", "No active image view.")
            return
        w   = sw.widget() if hasattr(sw, "widget") else None
        doc = getattr(w, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "RC-Astro Tools", "Active view has no image.")
            return

        # Clear stale reference if dialog was closed/destroyed
        if hasattr(self, "_rcastro_dlg") and self._rcastro_dlg is not None:
            try:
                if not self._rcastro_dlg.isVisible():
                    self._rcastro_dlg = None
            except RuntimeError:
                # C++ object already deleted
                self._rcastro_dlg = None

        if not hasattr(self, "_rcastro_dlg") or self._rcastro_dlg is None:
            self._rcastro_dlg = open_rcastro_dialog(
                self,
                doc=doc,
                rcastro_icon=QIcon(rcastro_path),
            )
            self._rcastro_dlg.destroyed.connect(
                lambda: setattr(self, "_rcastro_dlg", None))
        else:
            self._rcastro_dlg.raise_()
            self._rcastro_dlg.activateWindow()

    def _open_cosmic_clarity_ui(self):
        print("Opening Cosmic Clarity UI...")
        try:
            from setiastro.saspro import cosmicclarity as cc
            CosmicClarityDialogPro = cc.CosmicClarityDialogPro
        except Exception as e:
            import traceback
            print("Failed to import setiastro.saspro.cosmicclarity:", e)
            traceback.print_exc()
            QMessageBox.critical(
                self,
                "Cosmic Clarity",
                f"Failed to import Cosmic Clarity module:\n{e}"
            )
            return

        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Cosmic Clarity", "No active image view.")
            return

        w = sw.widget() if hasattr(sw, "widget") else None
        doc = getattr(w, "document", None)
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Cosmic Clarity", "Active view has no image.")
            return

        # Clear any stale headless flag when user explicitly opens the UI
        try:
            s = QSettings()
            s.remove("cc/headless_in_progress")
        except Exception:
            pass

        try:
            print("Creating CosmicClarityDialogPro (interactive, non-blocking)...")
            dlg = CosmicClarityDialogPro(
                self,
                doc,
                icon=QIcon(cosmic_path),
                headless=False,
                bypass_guard=True,
            )

            # Keep a strong reference so the dialog is not garbage collected.
            if not hasattr(self, "_cosmic_clarity_dialogs"):
                self._cosmic_clarity_dialogs = []
            self._cosmic_clarity_dialogs.append(dlg)

            def _cleanup_dialog(*_):
                try:
                    if hasattr(self, "_cosmic_clarity_dialogs") and dlg in self._cosmic_clarity_dialogs:
                        self._cosmic_clarity_dialogs.remove(dlg)
                except Exception:
                    pass
                try:
                    dlg.deleteLater()
                except Exception:
                    pass

            # Clean up whether the dialog is accepted, rejected, or just closed.
            try:
                dlg.finished.connect(_cleanup_dialog)
            except Exception:
                pass
            try:
                dlg.destroyed.connect(lambda *_: _cleanup_dialog())
            except Exception:
                pass

            dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
            dlg.show()
            dlg.raise_()
            dlg.activateWindow()

            print("Cosmic Clarity dialog shown non-blocking.")
        except Exception as e:
            import traceback
            print("Failed to open Cosmic Clarity UI:", e)
            traceback.print_exc()
            QMessageBox.critical(
                self,
                "Cosmic Clarity",
                f"Failed to open Cosmic Clarity UI:\n{e}"
            )

    def _open_cosmic_clarity_satellite(self):
        from setiastro.saspro.cosmicclarity import CosmicClaritySatelliteDialogPro

        # It's OK if there is no active subwindow or no image.
        sw = self.mdi.activeSubWindow() if hasattr(self, "mdi") else None
        doc = None
        if sw is not None and hasattr(sw, "widget") and sw.widget() is not None:
            w = sw.widget()
            doc = getattr(w, "document", None)

        try:
            # Reuse existing window if it's already open
            dlg = getattr(self, "_cc_satellite_dialog", None)
            if dlg is not None and dlg.isVisible():
                dlg.raise_()
                dlg.activateWindow()
                return

            # Create non-modal dialog and keep a reference to prevent GC
            dlg = CosmicClaritySatelliteDialogPro(self, doc, icon=QIcon(satellite_path))
            dlg.setModal(False)  # optional, show() is already non-modal
            dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

            # Clear reference when closed
            def _clear_ref(*args):
                if getattr(self, "_cc_satellite_dialog", None) is dlg:
                    self._cc_satellite_dialog = None

            dlg.destroyed.connect(_clear_ref)

            self._cc_satellite_dialog = dlg
            dlg.show()
            dlg.raise_()
            dlg.activateWindow()

        except Exception as e:
            print(f"Failed to open Cosmic Clarity Satellite: {e}")
            QMessageBox.critical(
                self,
                "Cosmic Clarity Satellite",
                f"Failed to open Cosmic Clarity Satellite:\n{e}"
            )


    def _open_history_explorer(self):
        from setiastro.saspro.history_explorer import HistoryExplorerDialog
        sw = self.mdi.activeSubWindow()
        doc = sw.widget().document if sw else None
        if not doc:
            QMessageBox.information(self, "History", "No active document.")
            return

        dlg = HistoryExplorerDialog(doc, parent=self)
        sub_title = sw.windowTitle() if sw else doc.display_name()
        dlg.setWindowTitle(f"History Explorer -- {sub_title}")
        dlg.show()
        self._log("History: opened History Explorer.")

    def _open_blink_tool(self):
        from setiastro.saspro.blink_comparator_pro import BlinkComparatorPro
        # Parent to the main window: ties the dialog's lifecycle to SASpro
        # (so it closes when SASpro closes) and lets normal OS window
        # stacking rules apply. Previously this had no parent AND
        # WindowStaysOnTopHint, which together made it an orphaned
        # always-on-top-of-everything window that survived app shutdown.
        dlg = BlinkComparatorPro(doc_manager=self.docman, parent=self)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.setWindowTitle("Blink Comparator")
        dlg.setWindowFlags(Qt.WindowType.Window)
        try:
            dlg.setWindowIcon(QIcon(blink_path))
        except Exception:
            pass
        dlg.sendToStacking.connect(
            lambda paths, target, d=dlg: self._on_blink_send_to_stacking(paths, target, d)
        )
        dlg.show()

    def _open_narrowband_normalization_tool(self):
        # Correct module import
        from setiastro.saspro.narrowband_normalization import NarrowbandNormalization

        w = NarrowbandNormalization(doc_manager=self.docman, parent=self)
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        w.setWindowTitle("Narrowband Normalization")
        try:
            w.setWindowIcon(QIcon(narrowbandnormalization_path))
        except Exception:
            pass
        w.show()

    def _open_ppp_tool(self):
        from setiastro.saspro.perfect_palette_picker import PerfectPalettePicker
        w = PerfectPalettePicker(doc_manager=self.docman)  # parent gives access to _spawn_subwindow_for
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        w.setWindowTitle("Perfect Palette Picker")
        try:
            w.setWindowIcon(QIcon(ppp_path))
        except Exception:
            pass        
        w.show()   

    def _open_nbtorgb_tool(self):
        from setiastro.saspro.nbtorgb_stars import NBtoRGBStars
        w = NBtoRGBStars(doc_manager=self.docman)
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        w.setWindowTitle("NB -> RGB Stars")
        try:
            w.setWindowIcon(QIcon(nbtorgb_path))
        except Exception:
            pass
        w.show()

    def _open_selective_color_tool(self):
        # get active document, same pattern you use elsewhere
        doc = None
        if hasattr(self, "mdi") and self.mdi.activeSubWindow():
            sw = self.mdi.activeSubWindow().widget()
            doc = getattr(sw, "document", None)
        if doc is None and getattr(self, "docman", None) and self.docman._docs:
            doc = self.docman._docs[-1]
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "No image", "Open an image first."); return

        from setiastro.saspro.selective_color import SelectiveColorCorrection
        w = SelectiveColorCorrection(doc_manager=self.docman, document=doc, parent=self,
                                    window_icon=QIcon(selectivecolor_path))
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        w.show()

    def _open_selective_lum_tool(self):
        """Open the Selective Luminance Correction dialog on the active document."""
        doc = None
        if hasattr(self, "mdi") and self.mdi.activeSubWindow():
            sw = self.mdi.activeSubWindow().widget()
            doc = getattr(sw, "document", None)
        if doc is None and getattr(self, "docman", None) and self.docman._docs:
            doc = self.docman._docs[-1]
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        from setiastro.saspro.selective_luma import SelectiveLuminanceCorrection
        w = SelectiveLuminanceCorrection(
            doc_manager=self.docman,
            document=doc,
            parent=self,
            window_icon=QIcon(selectivelum_path),
        )
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        w.show()

    def _open_freqsep_tool(self):
        from setiastro.saspro.frequency_separation import FrequencySeperationTab
        # get the active ImageDocument (same pattern you use elsewhere)
        doc = None
        if hasattr(self, "mdi") and self.mdi.activeSubWindow():
            sw = self.mdi.activeSubWindow().widget()
            doc = getattr(sw, "document", None)

        # fallback to last opened document if needed
        if doc is None and getattr(self, "docman", None) and self.docman._docs:
            doc = self.docman._docs[-1]

        w = FrequencySeperationTab(doc_manager=self.docman, document=doc, parent=self)
        w.setWindowFlag(Qt.WindowType.Window, True)
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        w.setWindowTitle("Frequency Separation")

        try:
            w.setWindowIcon(QIcon(freqsep_path))
        except Exception:
            pass         
        # If we have a document, preload its image/metadata before showing
        if doc is not None and getattr(doc, "image", None) is not None:
            w.set_image_from_doc(doc.image, doc.metadata)

        w.show()

    def _open_multiscale_decomp(self):
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Multiscale Decomposition", "No active image.")
            return
        view = sw.widget()
        # ROI-aware: always resolve via DocManager for THIS view
        # (so active_mask_id / masks are attached to the doc we pass in).
        doc = self.doc_manager.get_document_for_view(view)
        if not doc or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Multiscale Decomposition", "No active image.")
            return
        from setiastro.saspro.multiscale_decomp import MultiscaleDecompDialog
        dlg = MultiscaleDecompDialog(self, doc)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.setWindowTitle("Multiscale Decomposition")
        try:
            dlg.setWindowIcon(QIcon(multiscale_decomp_path))
        except Exception:
            pass

        dlg.show()

    def _open_slap_toolkit(self):
        from setiastro.saspro.slap_toolkit import show_slap_toolkit
        show_slap_toolkit(self)

    def _open_contsub_tool(self):
        from setiastro.saspro.continuum_subtract import ContinuumSubtractTab
        w = ContinuumSubtractTab(doc_manager=self.docman)
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        w.setWindowTitle("Continuum Subtract")
        try:
            w.setWindowIcon(QIcon(contsub_path))
        except Exception:
            pass
        w.show()

    def _open_narrowband_integration(self):
        from setiastro.saspro.narrowbandintegration import NarrowbandIntegrationDialog
        w = NarrowbandIntegrationDialog(doc_manager=self.docman, parent=self)
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        w.setWindowTitle("Narrowband Integration")
        try:
            w.setWindowIcon(QIcon(nbi_path))
        except Exception:
            pass
        w.show()

    def _open_image_combine(self):
        from setiastro.saspro.image_combine import ImageCombineDialog
        w = ImageCombineDialog(self)   # <- only pass self
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        w.setWindowTitle("Image Combination")
        try:
            w.setWindowIcon(QIcon(imagecombine_path))
        except Exception:
            pass        
        w.resize(900, 650)
        w.show()                       # <- modeless; no exec(), no result_preset()


    def _apply_image_combine_from_preset(self, preset: dict, *, target_doc=None):
        """
        Headless apply (supports drag+drop) or dialog-OK path.
        If target_doc is provided (drop onto a view), it's A; otherwise use preset/doc chooser.
        """
        dm = getattr(self, "doc_manager", None) or getattr(self, "dm", None)
        if dm is None:
            QMessageBox.warning(self, "Image Combine", "No document manager."); return

        docs = self._list_open_docs()
        if not docs:
            QMessageBox.information(self, "Image Combine", "No open images."); return

        mode   = preset.get("mode", "Blend")
        alpha  = float(preset.get("opacity", 1.0))
        lonly  = bool(preset.get("luma_only", False))
        output = preset.get("output", "replace")

        # Resolve A/B
        A = target_doc or next((d for d in docs if id(d) == preset.get("docA_id")), self._active_doc())
        B = next((d for d in docs if id(d) == preset.get("docB_id")), None)

        # fallback for B by title (useful for shortcut presets across sessions)
        if B is None:
            title = (preset.get("docB_title") or "").strip()
            if title:
                for d in docs:
                    if _display_name(d).strip() == title:
                        B = d; break

        # if still None and exactly two docs, pick the other
        if (A is not None) and (B is None) and len(docs) == 2:
            B = docs[0] if docs[1] is A else docs[1]

        if A is None or B is None:
            QMessageBox.warning(self, "Image Combine", "Could not resolve Source A and B."); return

        imgA = np.asarray(getattr(A, "image", None), dtype=np.float32)
        imgB = np.asarray(getattr(B, "image", None), dtype=np.float32)
        if imgA is None or imgB is None:
            QMessageBox.warning(self, "Image Combine", "One of the sources has no image."); return
        if imgA.shape[:2] != imgB.shape[:2]:
            QMessageBox.warning(self, "Image Combine", "Image sizes must match."); return

        from setiastro.saspro.image_combine import _blend_dispatch, _rgb_to_luma, _recombine_luma_into_rgb, _to_float01
        try:
            if lonly:
                if imgA.ndim != 3 or (imgA.shape[2] != 3):
                    QMessageBox.warning(self, "Luminance Blend", "Source A must be RGB."); return
                YA = _rgb_to_luma(imgA)
                YB = _rgb_to_luma(imgB)
                Ymix = _blend_dispatch(YA[..., None], YB[..., None], mode, alpha)[..., 0]
                result = _recombine_luma_into_rgb(Ymix, imgA)
                step = f"Luminance {mode}"
            else:
                A3 = imgA if imgA.ndim == 3 else imgA[..., None]
                B3 = imgB if imgB.ndim == 3 else imgB[..., None]
                result = _blend_dispatch(A3, B3, mode, alpha)
                if imgA.ndim == 2: result = result[..., 0]
                step = f"{mode} Combine"

            result = _to_float01(result)

            if output == "replace":
                if hasattr(A, "set_image"):
                    A.set_image(result, step_name=f"Image Combine: {step}")
                else:
                    A.image = result; A.changed.emit()
                self._log(f"Image Combine -> replaced '{_display_name(A)}' ({step})")
            else:
                newdoc = dm.create_document(result, metadata={
                    "display_name": f"Combined ({step})",
                    "bit_depth": "32-bit floating point",
                    "is_mono": (result.ndim == 2),
                    "source": f"Combine: {step}",
                }, name=f"Combined ({step})")
                self._spawn_subwindow_for(newdoc)
                self._log(f"Image Combine -> new view '{newdoc.display_name()}' ({step})")

        except Exception as e:
            QMessageBox.critical(self, "Image Combine", f"Failed:\n{e}")

    def _open_psf_viewer(self, preset: dict | None = None):
        from setiastro.saspro.psf_viewer import PSFViewer
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Pixel Math", "No active image window.")
            return

        dlg = PSFViewer(self.mdi.activeSubWindow().widget(), parent=self)
        dlg.setWindowIcon(QIcon(psf_path))

        # Optional preset support: {"threshold": int, "mode": "PSF"|"Flux", "log": bool, "zoom": int}
        if isinstance(preset, dict):
            if "threshold" in preset:
                try: dlg.threshold_slider.setValue(int(preset["threshold"]))
                except Exception as e:
                    import logging
                    logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
            if preset.get("mode") == "Flux":
                try: dlg.toggleHistogramMode()
                except Exception as e:
                    import logging
                    logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
            if bool(preset.get("log", False)) != bool(dlg.log_scale):
                try: dlg.log_toggle_button.setChecked(bool(preset.get("log", False)))
                except Exception as e:
                    import logging
                    logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
            if "zoom" in preset:
                try: dlg.zoom_slider.setValue(int(preset["zoom"]))
                except Exception as e:
                    import logging
                    logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

        dlg.show()

    def _open_image_peeker(self):
        from setiastro.saspro.image_peeker_pro import ImagePeekerDialogPro
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Image Peaker", "No active image window.")
            return

        dlg = ImagePeekerDialogPro(parent=self, document=sw, settings=self.settings)
        dlg.setWindowIcon(QIcon(peeker_icon))
        dlg.show()

    def _open_image_peeker_for_doc(self, doc, title_hint=None):
        from setiastro.saspro.image_peeker_pro import ImagePeekerDialogPro
        dlg = ImagePeekerDialogPro(parent=self, document=doc, settings=self.settings)
        try: dlg.setWindowIcon(QIcon(peeker_icon))
        except Exception as e:
            import logging
            logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
        dlg.show()
        if hasattr(self, "_log"):
            self._log(f"Opened Image Peeker for '{title_hint or getattr(doc, 'display_name', lambda:'view')()}'")


    def _open_plate_solver(self):
        from setiastro.saspro.plate_solver import open_plate_solver_with_preset
        open_plate_solver_with_preset(self)

    def _apply_plate_solve_to_doc(self, doc, preset=None):
        from setiastro.saspro.plate_solver import apply_plate_solve_to_doc
        if doc is None or getattr(doc, "image", None) is None:
            raise RuntimeError("No image to plate-solve.")
        ok, res = apply_plate_solve_to_doc(self, doc, self.settings, preset or {})
        if not ok:
            raise RuntimeError(str(res) or "Plate solve failed.")
        return res

    def _doc_has_wcs(self, doc) -> bool:
        if doc is None:
            return False
        meta = getattr(doc, "metadata", None) or {}
        if meta.get("wcs") is not None:
            return True

        hdr = meta.get("original_header") or meta.get("fits_header") or meta.get("header")
        if hdr is None:
            return False

        try:
            keys = {str(k).upper() for k in hdr.keys()}
        except Exception:
            try:
                keys = {str(k).upper() for k in dict(hdr).keys()}
            except Exception:
                return False

        return {"CTYPE1","CTYPE2","CRVAL1","CRVAL2"}.issubset(keys)

    def _open_unwarp(self):
        from setiastro.saspro.unwarp import UnwarpDialog
        dlg = UnwarpDialog(
            parent=self,
            settings=self.settings,
            doc_manager=self.doc_manager,
            list_open_docs_fn=self._list_open_docs,
            document=self._active_doc(),
        )
        dlg.setWindowIcon(QIcon(unwarp_path))
        dlg.show()

    def _open_finder_chart(self):
        doc = self._active_doc()
        if not self._doc_has_wcs(doc):
            QMessageBox.information(self, self.tr("Finder Chart"), self.tr("Active image has no astrometric solution (WCS). Plate solve first."))
            return

        from setiastro.saspro.finder_chart import FinderChartDialog
        dlg = FinderChartDialog(doc=doc, settings=self.settings, parent=self)
        dlg.setWindowIcon(QIcon(finderchart_path))
        dlg.show()

    def _open_stellar_alignment(self):
        from setiastro.saspro.star_alignment import StellarAlignmentDialog
        dlg = StellarAlignmentDialog(
            parent=self,
            settings=self.settings,
            doc_manager=self.doc_manager,            # <- so Apply/New use undo/redo + creation
            list_open_docs_fn=self._list_open_docs   # <- same helper used by RGB dialog
        )
        dlg.setWindowIcon(QIcon(staralign_path))
        dlg.show()   # modal (keeps workers/dialog alive)
        try:
            doc = self._active_doc()
            if doc:
                self._hdr_refresh_timer.start(0)
        except Exception:
            pass
        try:
            if hasattr(self, "_refresh_treebox"):
                self._refresh_treebox()
        except Exception:
            pass

    def _open_stellar_registration(self):
        # If we still have a handle, make sure it's alive before using it
        win = getattr(self, "_starreg_win", None)
        if win is not None:
            try:
                if win.isVisible():
                    win.raise_()
                    win.activateWindow()
                    return
            except RuntimeError:
                # C++ object was deleted; drop the stale Python handle
                self._starreg_win = None

        # Create a fresh window
        from setiastro.saspro.star_alignment import StarRegistrationWindow
        self._starreg_win = StarRegistrationWindow(parent=self)
        self._starreg_win.setWindowFlag(Qt.WindowType.Window, True)
        self._starreg_win.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        # When the window actually dies, clear our handle so future calls recreate it
        self._starreg_win.destroyed.connect(lambda: setattr(self, "_starreg_win", None))
        self._starreg_win.setWindowIcon(QIcon(starregistration_path))
        self._starreg_win.show()

    def _show_welcome(self):
        from setiastro.saspro.first_run_dialog import FirstRunDialog, _SETTINGS_KEY
        self.settings.remove(_SETTINGS_KEY)
        self.settings.sync()
        dlg = FirstRunDialog(self)
        dlg.exec()

    def _toggle_tips(self):
        currently_disabled = self.settings.value("tips/disabled", False, type=bool)
        if currently_disabled:
            self.settings.setValue("tips/disabled", False)
            self.settings.remove("tips/recently_seen")  # reset seen list so they get fresh tips
            self.settings.sync()
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.information(
                self,
                "Tips Enabled",
                "Tip of the day has been re-enabled.\nA tip will appear next time you launch SASpro."
            )
        else:
            self.settings.setValue("tips/disabled", True)
            self.settings.sync()
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.information(
                self,
                "Tips Disabled",
                "Tip of the day has been disabled.\nYou can re-enable it here at any time."
            )

    def _open_dither_analysis(self):
        win = getattr(self, "_dither_analysis_win", None)
        if win is not None:
            try:
                if win.isVisible():
                    win.raise_()
                    win.activateWindow()
                    return
            except RuntimeError:
                self._dither_analysis_win = None
        from setiastro.saspro.dither_analysis import DitherAnalysisWindow
        self._dither_analysis_win = DitherAnalysisWindow(parent=self)
        self._dither_analysis_win.setWindowFlag(Qt.WindowType.Window, True)
        self._dither_analysis_win.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self._dither_analysis_win.destroyed.connect(
            lambda: setattr(self, "_dither_analysis_win", None)
        )
        self._dither_analysis_win.setWindowIcon(QIcon(dithericon_path))
        self._dither_analysis_win.show()

    def _open_rgb_align(self):
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "RGB Align", "No active image window.")
            return

        view = sw.widget()
        from setiastro.saspro.rgbalign import RGBAlignDialog
        dlg = RGBAlignDialog(parent=self, document=view)
        dlg.setWindowIcon(QIcon(rgbalign_path))
        dlg.show()

    def _open_mosaic_master(self):
        from setiastro.saspro.mosaic_master import MosaicMasterDialog
        dlg = MosaicMasterDialog(
            settings=self.settings,
            parent=self,
            image_manager=getattr(self, "image_manager", None),
            doc_manager=getattr(self, "doc_manager", None),
            wrench_path=wrench_path,
            spinner_path=spinner_path,
            list_open_docs_fn=getattr(self, "_list_open_docs", None),  # <- add this
        )
        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(mosaic_path))
        dlg.show()

    def _open_surface_mosaic(self):
        from setiastro.saspro.surface_mosaic import SurfaceMosaicDialog
        w = SurfaceMosaicDialog(doc_manager=self.docman, parent=self)
        w.setWindowFlag(Qt.WindowType.Window, True)
        w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        w.setWindowTitle("Surface Mosaic")
        try:
            w.setWindowIcon(QIcon(surfacemosaic_path))
        except Exception:
            pass
        w.show()
        
    def _open_live_stacking(self):
        from setiastro.saspro.live_stacking import LiveStackWindow
        dlg = LiveStackWindow(
            parent=self,
            doc_manager=getattr(self, "doc_manager", None),   # pass doc_manager (not image_manager)
            wrench_path=wrench_path,                          # optional: for the settings button icon
            spinner_path=spinner_path                         # optional: if you want to reuse
        )
        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(livestacking_path))
        dlg.show()

    def _open_planetary_stacker(self):
        # import locally to avoid startup cost / circular imports
        from setiastro.saspro.serviewer import SERViewer
        dlg = SERViewer(self)
        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(planetarystacker_path))        
        dlg.show()

    def _open_planet_projection(self):
        from setiastro.saspro.planetprojection import PlanetProjectionDialog
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return

        view = sw.widget()
        doc = self.doc_manager.get_document_for_view(view)

        dlg = PlanetProjectionDialog(self, doc)
        try:
            # dlg.setWindowIcon(QIcon(planetprojection_path))
            pass
        except Exception:
            pass
        dlg.resize(980, 720)
        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(planetprojection_path))         
        dlg.show()
        self._log("Functions: opened Planet Projection.")

    def _open_flythrough(self):
        dlg = getattr(self, "_flythrough_dlg", None)
        if dlg is not None:
            try:
                if not dlg.isVisible():
                    dlg.show()
                dlg.raise_()
                dlg.activateWindow()
                return
            except RuntimeError:
                self._flythrough_dlg = None

        from setiastro.saspro.flythrough import open_flythrough_dialog

        def _list_open_docs():
            docs = []
            for sw in self.mdi.subWindowList():
                view = sw.widget()
                doc  = getattr(view, "document", None)
                if doc is None:
                    try:
                        doc = self.doc_manager.get_document_for_view(view)
                    except Exception:
                        pass
                if doc is not None and getattr(doc, "image", None) is not None:
                    docs.append((doc.display_name(), doc))
            return docs

        dlg = open_flythrough_dialog(
            self,
            list_open_docs_fn=_list_open_docs,
            doc_manager=self.doc_manager,
        )
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.destroyed.connect(lambda _=None: setattr(self, "_flythrough_dlg", None))
        dlg.setWindowIcon(QIcon(flythrough_path))
        self._flythrough_dlg = dlg
        self._log("Functions: opened Nebula Flythrough.")

    def _open_stacking_suite(self):
        # Reuse if we already have one
        dlg = getattr(self, "_stacking_suite", None)
        if dlg is not None:
            try:
                if not dlg.isVisible():
                    dlg.show()
                dlg.raise_()
                dlg.activateWindow()
                return dlg     # ðŸ'ˆ return existing
            except RuntimeError:
                self._stacking_suite = None  # C++ deleted, recreate

        from setiastro.saspro.stacking_suite import StackingSuiteDialog
        dlg = StackingSuiteDialog(
            parent=self,
            wrench_path=wrench_path,
            spinner_path=spinner_path,
        )
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.destroyed.connect(lambda _=None: setattr(self, "_stacking_suite", None))

        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(stacking_path))
        dlg.show()

        self._stacking_suite = dlg
        return dlg 

    def _on_blink_send_to_stacking(self, paths: list[str], target: str, blink_dlg=None):
        # 1) open / focus stacking first
        dlg = self._open_stacking_suite()
        # 2) push the files in
        dlg.ingest_paths_from_blink(paths, target)
        # 3) then re-raise blink so it doesn't get lost
        if blink_dlg is not None:
            try:
                blink_dlg.show()
                blink_dlg.raise_()
                blink_dlg.activateWindow()
            except Exception:
                pass

    # ============================================================
    # RGB / Mono / channel-order tools (replayable + bundle-able)
    # ============================================================

    def _resolve_active_doc(self):
        dm = getattr(self, "docman", None)
        if dm is None:
            return None
        try:
            return dm.get_active_document()
        except Exception:
            return None

    def _doc_name(self, doc) -> str:
        try:
            return getattr(doc, "display_name", lambda: None)() or getattr(doc, "name", "") or "Active"
        except Exception:
            return "Active"

    # ---- RGB → Mono -------------------------------------------------------

    def _rgb_to_mono_on_doc(self, doc, preset=None) -> bool:
        """Convert an RGB doc to mono (undoable) using a luminance method.
        Records a replay marker so it can be replayed / bundled. Works on any doc."""
        from setiastro.saspro.luminancerecombine import (
            compute_luminance, resolve_luma_profile_weights,
        )
        import numpy as np

        dm = getattr(self, "docman", None)
        if dm is None or doc is None:
            return False
        img = getattr(doc, "image", None)
        if img is None:
            return False

        x = np.asarray(img)
        name = self._doc_name(doc)

        if x.ndim == 2 or (x.ndim == 3 and x.shape[-1] == 1):
            if hasattr(self, "_log"):
                self._log(f"RGB → Mono: '{name}' is already mono (shape={x.shape}).")
            return False
        if not (x.ndim == 3 and x.shape[-1] >= 3):
            if hasattr(self, "_log"):
                self._log(f"RGB → Mono: unsupported shape {x.shape}.")
            return False

        preset = dict(preset or {})
        method = preset.get("luma_method") or getattr(self, "luma_method", "rec709")
        resolved_method, w, profile_name = resolve_luma_profile_weights(method)

        # Faithful replay of custom profiles: explicit weights in the preset win.
        pw = preset.get("luma_weights")
        if pw:
            try:
                w = np.asarray(pw, dtype=np.float32)
            except Exception:
                pass

        L = compute_luminance(x, method=resolved_method, weights=w).astype(np.float32)

        # Canonical replay preset (what _apply_rgb_to_mono_to_doc consumes).
        rp = {"luma_method": resolved_method}
        if w is not None:
            rp["luma_weights"] = np.asarray(w, dtype=np.float32).tolist()

        md = dict(getattr(doc, "metadata", None) or {})
        md["is_mono"] = True
        md["color_model"] = "Mono"
        md["channels"] = 1
        md["luma_method"] = resolved_method
        if w is not None:
            md["luma_weights"] = np.asarray(w, dtype=np.float32).tolist()
        if profile_name:
            md["luma_profile"] = str(profile_name)
        md["command_id"] = "rgb_to_mono"     # → stamped into the replay marker
        md["preset"] = dict(rp)
        md["__op_params__"] = {
            "op": "rgb_to_mono",
            "luma_method": resolved_method,
            "from_shape": tuple(x.shape),
            "to_shape": tuple(L.shape),
        }

        suffix = profile_name or resolved_method
        try:
            dm.update_active_document(L, metadata=md, step_name=f"RGB → Mono ({suffix})", doc=doc)
        except Exception:
            import traceback
            try:
                from PyQt6.QtWidgets import QMessageBox
                QMessageBox.critical(self, "RGB → Mono", traceback.format_exc())
            except Exception:
                pass
            return False

        try:
            self._last_headless_command = {"command_id": "rgb_to_mono", "preset": dict(rp)}
        except Exception:
            pass
        if hasattr(self, "_log"):
            self._log(f"RGB → Mono: '{name}' converted using {suffix} (shape {x.shape} → {L.shape}).")
        return True

    def _convert_rgb_to_mono_active(self):
        self._rgb_to_mono_on_doc(self._resolve_active_doc(), preset=None)

    def _apply_rgb_to_mono_to_doc(self, doc, preset=None):
        return self._rgb_to_mono_on_doc(doc, preset)

    # ---- Mono → RGB -------------------------------------------------------

    def _mono_to_rgb_on_doc(self, doc, preset=None) -> bool:
        """Convert a mono doc to RGB by triplicating the channel (undoable)."""
        import numpy as np

        dm = getattr(self, "docman", None)
        if dm is None or doc is None:
            return False
        img = getattr(doc, "image", None)
        if img is None:
            return False

        x = np.asarray(img)
        name = self._doc_name(doc)

        if x.ndim == 3 and x.shape[-1] == 3:
            if hasattr(self, "_log"):
                self._log(f"Mono → RGB: '{name}' is already RGB (shape={getattr(x,'shape',None)}).")
            return False

        if x.ndim == 2:
            mono = x; src_desc = "mono (H×W)"
        elif x.ndim == 3 and x.shape[-1] == 1:
            mono = x[..., 0]; src_desc = "mono (H×W×1)"
        else:
            if hasattr(self, "_log"):
                self._log(f"Mono → RGB: '{name}' not convertible (shape={getattr(x,'shape',None)}).")
            return False

        before_shape, before_dtype = getattr(x, "shape", None), getattr(x, "dtype", None)
        mono = mono.astype(np.float32, copy=False)
        rgb = np.stack([mono, mono, mono], axis=-1)

        rp = {"mode": "triplicate"}
        md = dict(getattr(doc, "metadata", None) or {})
        md["is_mono"] = False
        md["color_model"] = "RGB"
        md["channels"] = 3
        md["source"] = (md.get("source") or "Edit")
        md["command_id"] = "mono_to_rgb"
        md["preset"] = dict(rp)
        md["__op_params__"] = {
            "op": "mono_to_rgb",
            "mode": "triplicate",
            "from": str(src_desc),
            "from_shape": tuple(before_shape) if before_shape is not None else None,
            "to_shape": tuple(rgb.shape),
        }

        try:
            dm.update_active_document(rgb, metadata=md, step_name="Mono → RGB", doc=doc)
        except Exception:
            import traceback
            try:
                from PyQt6.QtWidgets import QMessageBox
                QMessageBox.critical(self, "Mono → RGB", traceback.format_exc())
            except Exception:
                pass
            return False

        try:
            self._last_headless_command = {"command_id": "mono_to_rgb", "preset": dict(rp)}
        except Exception:
            pass
        if hasattr(self, "_log"):
            self._log(f"Mono → RGB: '{name}' converted {src_desc} "
                    f"(shape={before_shape}, dtype={before_dtype}) → RGB (shape={rgb.shape}).")
        return True

    def _convert_mono_to_rgb_active(self):
        self._mono_to_rgb_on_doc(self._resolve_active_doc(), preset=None)

    def _apply_mono_to_rgb_to_doc(self, doc, preset=None):
        return self._mono_to_rgb_on_doc(doc, preset)

    # ---- Swap R ↔ B (bonus; same pattern) ---------------------------------

    def _swap_rb_on_doc(self, doc, preset=None) -> bool:
        import numpy as np

        dm = getattr(self, "docman", None)
        if dm is None or doc is None:
            return False
        img = getattr(doc, "image", None)
        if img is None:
            return False

        x = np.asarray(img)
        name = self._doc_name(doc)
        if not (x.ndim == 3 and x.shape[-1] == 3):
            if hasattr(self, "_log"):
                self._log(f"Swap R/B: '{name}' is not RGB (shape={getattr(x,'shape',None)}).")
            return False

        before_shape, before_dtype = x.shape, x.dtype
        out = x.copy()
        out[..., 0], out[..., 2] = x[..., 2], x[..., 0]

        rp = {}
        md = dict(getattr(doc, "metadata", None) or {})
        md["color_model"] = md.get("color_model", "RGB")
        md["channels"] = 3
        md["is_mono"] = False
        md["source"] = (md.get("source") or "Edit")
        md["command_id"] = "swap_rb"
        md["preset"] = dict(rp)
        md["__op_params__"] = {
            "op": "swap_rb",
            "from_shape": tuple(before_shape),
            "to_shape": tuple(out.shape),
            "dtype": str(before_dtype),
        }

        try:
            dm.update_active_document(out, metadata=md, step_name="Swap R ↔ B", doc=doc)
        except Exception:
            import traceback
            try:
                from PyQt6.QtWidgets import QMessageBox
                QMessageBox.critical(self, "Swap R/B", traceback.format_exc())
            except Exception:
                pass
            return False

        try:
            self._last_headless_command = {"command_id": "swap_rb", "preset": {}}
        except Exception:
            pass
        if hasattr(self, "_log"):
            self._log(f"Swap R/B: '{name}' swapped channels (shape={before_shape}, dtype={before_dtype}).")
        return True

    def _swap_rb_active(self):
        self._swap_rb_on_doc(self._resolve_active_doc(), preset=None)

    def _apply_swap_rb_to_doc(self, doc, preset=None):
        return self._swap_rb_on_doc(doc, preset)


    def _on_stackingsuite_relaunch(self, old_dir: str, new_dir: str):
        # Optional: respond to dialog's relaunch request
        try:
            if getattr(self, "_stacking_suite", None):
                self._stacking_suite.close()
        except Exception:
            pass
        self._stacking_suite = None

        # re-open
        self._open_stacking_suite()
        # if your dialog exposes a setter, apply the new directory:
        if hasattr(self._stacking_suite, "set_stacking_directory"):
            self._stacking_suite.set_stacking_directory(new_dir)

    def _open_supernova_hunter(self):
        from setiastro.saspro.supernovaasteroidhunter import SupernovaAsteroidHunterDialog
        dlg = SupernovaAsteroidHunterDialog(
            parent=self,
            settings=getattr(self, "settings", None),
            image_manager=getattr(self, "image_manager", None),
            doc_manager=getattr(self, "doc_manager", None),
            supernova_path=supernova_path,         # for the window icon
            wrench_path=wrench_path,               # optional if you want a settings icon later
            spinner_path=spinner_path              # optional
        )
        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(supernova_path))
        dlg.show()

    def _open_star_spikes(self, *, doc=None, preset: dict | None = None, title_hint: str | None = None):
        from setiastro.saspro.star_spikes import StarSpikesDialogPro
        dlg = StarSpikesDialogPro(
            parent=self,
            doc_manager=getattr(self, "docman", None),
            initial_doc=doc,
            jwstpupil_path=jwstpupil_path,
            aperture_help_path=aperture_path,
            spinner_path=spinner_path,  # optional; used if you want
        )
        if preset:
            dlg.apply_preset(preset)
        if title_hint:
            dlg.setWindowTitle(f"Diffraction Spikes -- {title_hint}")
        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(starspike_path))
        dlg.show()

    def _open_astrospike(self, *, doc=None):
        """Open the AstroSpike dialog with advanced diffraction effects."""
        from setiastro.saspro.astrospike import AstroSpikeDialog
        from setiastro.saspro.resources import Icons
        from setiastro.saspro.headless_utils import unwrap_docproxy
        
        # Get the active document first
        active_doc = doc
        if active_doc is None:
            sw = self.mdi.activeSubWindow()
            if sw:
                view = sw.widget()
                if hasattr(view, "document"):
                    active_doc = view.document
        
        # Unwrap DocProxy if needed - call _target() if it exists
        if active_doc and hasattr(active_doc, "_target"):
            active_doc = active_doc._target()
        else:
            active_doc = unwrap_docproxy(active_doc)
        
        # Print debug info
        print(f"[AstroSpike] Active document (unwrapped): {active_doc}")
        if active_doc and hasattr(active_doc, "image"):
            img = active_doc.image
            print(f"[AstroSpike] Active image shape: {img.shape if img is not None else 'None'}")
        
        # Create a callback to get the current image from the active document
        def get_image_callback():
            """Get image from active document if available."""
            if active_doc and hasattr(active_doc, "image"):
                img = active_doc.image
                if img is not None:
                    print(f"[AstroSpike] Callback: Retrieved image shape {img.shape}, dtype {img.dtype}")
                    # Ensure correct format for the script
                    if img.dtype == np.uint8:
                        return img.astype(np.float32) / 255.0
                    elif img.dtype == np.float32:
                        if img.max() > 1.0:
                            return img / 255.0
                        return img
                    else:
                        return img.astype(np.float32)
                else:
                    print("[AstroSpike] Callback: image is None")
            else:
                print("[AstroSpike] Callback: active_doc or image attribute not available")
            return None
        
        # Create a callback to set the image back to the document
        def set_image_callback(image_data, step_name):
            """Apply the result image back to the active document."""
            if active_doc and hasattr(active_doc, "apply_edit"):
                print(f"[AstroSpike] Setting image back to document, shape: {image_data.shape}")
                # Use apply_edit for proper undo/redo integration
                meta = {
                    "step_name": step_name,
                    "astrospike": True
                }
                active_doc.apply_edit(image_data.astype(np.float32, copy=False), metadata=meta, step_name=step_name)
            elif active_doc and hasattr(active_doc, "set_image"):
                print(f"[AstroSpike] Setting image via set_image, shape: {image_data.shape}")
                active_doc.set_image(image_data, metadata={}, step_name=step_name)
            elif active_doc and hasattr(active_doc, "image"):
                print(f"[AstroSpike] Setting image directly, shape: {image_data.shape}")
                active_doc.image = image_data
            else:
                print("[AstroSpike] Cannot set image - active_doc or methods not available")
        
        icon_path = Icons().ASTRO_SPIKE
        dlg = AstroSpikeDialog(parent=self, icon_path=icon_path, get_image_callback=get_image_callback, set_image_callback=set_image_callback)
        dlg.showMaximized()
        dlg.exec()

    def _open_exo_detector(self):
        # Lazy import to avoid loading lightkurve at startup (~12s)
        from setiastro.saspro.exoplanet_detector import ExoPlanetWindow
        dlg = ExoPlanetWindow(
            parent=self,
            wrench_path=wrench_path,
        )
        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(exoicon_path))

        # Optional WIMI wiring (safe guards so we don't assume exact API names)
        if hasattr(self, "wimi_tab"):
            # WIMI -> dialog: emit RA/Dec once solved
            if hasattr(self.wimi_tab, "wcsCoordinatesAvailable"):
                self.wimi_tab.wcsCoordinatesAvailable.connect(dlg.receive_wcs_coordinates)
            # dialog -> WIMI: send a reference FITS path to solve
            # (rename this to whatever your WIMI expects; kept guarded)
            if hasattr(self.wimi_tab, "open_reference_path"):
                dlg.referenceSelected.connect(self.wimi_tab.open_reference_path)

        dlg.show()

    def _open_isophote(self):
        from setiastro.saspro.isophote import IsophoteModelerDialog
        # Mirror PSF opener: use MDI active subwindow -> widget -> document -> image
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "GLIMR", "No active image window.")
            return

        view = sw.widget()
        doc = getattr(view, "document", None) or view

        # Grab image from the doc (same style as PSF)
        img = getattr(doc, "image", None)
        if img is None:
            QMessageBox.information(self, "GLIMR", "Active view has no image data.")
            return

        # Ensure ndarray
        try:
            arr = np.asarray(img)
        except Exception:
            QMessageBox.information(self, "GLIMR", "Could not read image data from the active view.")
            return

        # Coerce to mono float32 in [0,1]
        if arr.ndim == 3 and arr.shape[-1] in (3, 4):
            mono = arr[..., :3].mean(axis=2)
        else:
            mono = arr
        mono = mono.astype(np.float32, copy=False)

        if np.issubdtype(arr.dtype, np.integer):
            info = np.iinfo(arr.dtype)
            rng = max(1, info.max - info.min)
            mono = (mono - float(info.min)) / float(rng)
        else:
            # assume already roughly normalized; clamp into display range
            mono = np.clip(mono, 0.0, 1.0)

        # doc_manager only used for pushing new docs/views from the dialog
        dm = getattr(self, "doc_manager", None)

        dlg = IsophoteModelerDialog(
            mono_image=mono,
            parent=self,
            title_hint="GLIMR -- Isophote Modeler",
            doc_manager=dm,
        )
        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(isophote_path))
        dlg.show()

    def _open_atlas(self):
        doc = self._active_doc()
        from setiastro.saspro.atlas_dialog import AtlasDialog
        dlg = AtlasDialog(doc=doc, settings=self.settings, parent=self)
        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(atlas_path))
        dlg.show()

    def _open_whats_in_my_sky(self):
        from setiastro.saspro.wims import WhatsInMySkyDialog
        dlg = WhatsInMySkyDialog(
            parent=self,
            wims_path=wims_path,          # window icon
            wrench_path=wrench_path       # optional settings icon
        )
        dlg.setWindowFlag(Qt.WindowType.Window, True)
        dlg.setWindowIcon(QIcon(wims_path))
        dlg.show()

    def _open_wimi(self):
        from setiastro.saspro.wimi_loader import WIMISplash, WIMILoader
        splash = WIMISplash(parent=self, wimi_path=wimi_path)
        splash.show()
        QApplication.processEvents()

        self._wimi_loader = WIMILoader(
            parent_widget=self,
            wimi_path=wimi_path,
            wrench_path=wrench_path,
            settings=getattr(self, "settings", None),
            doc_manager=getattr(self, "doc_manager", None),
        )

        def _on_imported():
            """Called on GUI thread after the slow import finishes."""
            splash.set_status("Building interface…")
            QApplication.processEvents()
            try:
                from setiastro.saspro.wimi import WIMIDialog   # already cached, instant
                dlg = WIMIDialog(
                    parent=self,
                    settings=getattr(self, "settings", None),
                    doc_manager=getattr(self, "doc_manager", None),
                    wimi_path=wimi_path,
                    wrench_path=wrench_path,
                )
                dlg.setWindowFlag(Qt.WindowType.Window, True)
                dlg.setWindowIcon(QIcon(wimi_path))
                splash.close()
                dlg.show()
            except Exception as exc:
                splash.close()
                QMessageBox.critical(self, "WIMI Error", f"Failed to open WIMI:\n{exc}")

        def _on_progress(msg):
            splash.set_status(msg)

        def _on_error(msg):
            splash.close()
            QMessageBox.critical(self, "WIMI Error", f"Failed to open WIMI:\n{msg}")

        self._wimi_loader.progress.connect(_on_progress)
        self._wimi_loader.ready.connect(_on_imported)
        self._wimi_loader.error.connect(_on_error)
        self._wimi_loader.start()


    def _open_fits_modifier(self):
        from setiastro.saspro.fitsmodifier import FITSModifier
        doc = self.doc_manager.get_active_document()
        if not doc:
            QMessageBox.information(self, "FITS Header Editor", "No active image window.")
            return

        file_path = doc.metadata.get("file_path")
        header    = doc.metadata.get("original_header") or {}

        dlg = FITSModifier(
            file_path=file_path if (file_path and os.path.isfile(file_path)) else None,
            header=header,
            doc_manager=self.doc_manager,
            active_document=doc,
            parent=self,
        )
        # dlg.setWindowIcon(QIcon("..."))  # optional
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.show()

    def _open_fits_batch_modifier(self):
        from setiastro.saspro.fitsmodifier import BatchFITSHeaderDialog
        """
        doc = self.doc_manager.get_active_document()
        if not doc:
            QMessageBox.information(self, "FITS Header Editor", "No active image window.")
            return
        file_path = doc.metadata.get("file_path")
        header    = doc.metadata.get("original_header") or {}
        """
        dlg = BatchFITSHeaderDialog(
            parent=self,
        )
        # dlg.setWindowIcon(QIcon("..."))  # optional
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.show()



    def _open_batch_renamer(self):
        from setiastro.saspro.batch_renamer import BatchRenamerDialog
        dlg = BatchRenamerDialog(parent=self)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.show()

    def _open_astrobin_exporter(self):
        from setiastro.saspro.astrobin_exporter import AstrobinExporterDialog
        # you said this is defined in the parent main UI:
        # astrobin_filters_csv_path = os.path.join(sys._MEIPASS, 'astrobin_filters.csv')

        dlg = AstrobinExporterDialog(self, offline_filters_csv=astrobin_filters_csv_path)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.show()

    def _open_batch_convert(self):
        from setiastro.saspro.batch_convert import BatchConvertDialog
        dlg = BatchConvertDialog(self)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.show()

    def _open_copy_astrometry(self):
        from setiastro.saspro.copyastro import CopyAstrometryDialog
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Copy Astrometric Solution", "No active image window.")
            return

        dlg = CopyAstrometryDialog(parent=self, target=sw)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.show()

    def _open_acv_exporter(self):
        from setiastro.saspro.acv_exporter import AstroCatalogueViewerExporterDialog

        dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
        if dm is None:
            QMessageBox.information(self, "Astro Catalogue Viewer Exporter", "No document manager available.")
            return

        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Astro Catalogue Viewer Exporter", "Open an image first.")
            return

        view = sw.widget()
        active_doc = None

        # Prefer ROI-aware resolution
        try:
            if hasattr(dm, "get_document_for_view"):
                active_doc = dm.get_document_for_view(view)
        except Exception:
            active_doc = None

        # Fallback
        if active_doc is None:
            try:
                active_doc = getattr(view, "document", None)
            except Exception:
                active_doc = None

        if active_doc is None or getattr(active_doc, "image", None) is None:
            QMessageBox.information(self, "Astro Catalogue Viewer Exporter", "No active image.")
            return

        dlg = AstroCatalogueViewerExporterDialog(self, dm, active_doc)
        try:
            dlg.setWindowIcon(QIcon(acv_icon_path))
        except Exception:
            pass
        dlg.show()


    def _open_linear_fit(self):
        from setiastro.saspro.linear_fit import LinearFitDialog
        dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
        if dm is None:
            QMessageBox.information(self, "Linear Fit", "No document manager available.")
            return

        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return

        view = sw.widget()
        active_doc = None

        # Prefer ROI-aware resolution from DocManager
        try:
            if hasattr(dm, "get_document_for_view"):
                active_doc = dm.get_document_for_view(view)
        except Exception:
            active_doc = None

        # Fallback to the view's base document
        if active_doc is None:
            try:
                active_doc = getattr(view, "document", None)
            except Exception:
                active_doc = None

        if active_doc is None or getattr(active_doc, "image", None) is None:
            QMessageBox.information(self, "Linear Fit", "No active image.")
            return

        dlg = LinearFitDialog(self, dm, active_doc)  # <-- pass ROI-aware doc + DM
        try:
            dlg.setWindowIcon(QIcon(self._icon_path("linear_fit")))
        except Exception:
            pass
        dlg.resize(900, 600)
        dlg.show()


    def _open_debayer(self):
        from setiastro.saspro.debayer import DebayerDialog
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "No image", "Open an image first.")
            return
        try:
            doc = sw.widget().document
        except Exception:
            QMessageBox.information(self, "Debayer", "No active image.")
            return
        dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
        if dm is None:
            QMessageBox.information(self, "Debayer", "No document manager available.")
            return
        dlg = DebayerDialog(self, dm, doc)
        try:
            dlg.setWindowIcon(QIcon(self._icon_path("debayer")))
        except Exception:
            pass
        dlg.resize(700, 420)
        dlg.show()

    def _open_workflows(self):
        from setiastro.saspro.workflows import show_workflow_dialog
        show_workflow_dialog(self)


    def _open_mini_workflow(self):
        from setiastro.saspro.workflows import show_mini_workflow_dialog
        show_mini_workflow_dialog(self)

    def _about(self):
        dlg = AboutDialog(
            parent=self,
            version=getattr(self, "_version", ""),
            build_timestamp=getattr(self, "_build_timestamp", ""),
        )
        dlg.exec()

    def _show_diagnostics_report(self):
        dlg = DiagnosticsReportDialog(self)
        dlg.exec()

    #######-------COMMAND DROPS-------#################
    def remember_last_headless_command(
        self,
        command_id: str,
        preset: dict | None = None,
        description: str = "",
    ):
        """
        Store the last headless-style command so subwindows can ask to replay it.
        Also appends it to a rolling history for the replay dropdown.
        Shape matches what _handle_command_drop expects.
        """
        payload = {
            "command_id": command_id,
            "preset": dict(preset or {}),
        }
        # Keep old single-slot behavior for "Replay last"
        self._last_headless_command = payload

        # NEW: append to history with a human label
        try:
            desc = (description or command_id).strip()
        except Exception:
            desc = command_id

        entry = {
            "command_id": command_id,
            "preset": dict(preset or {}),
            "description": desc,
        }

        hist = getattr(self, "_headless_history", None)
        if hist is None:
            self._headless_history = hist = []

        hist.append(entry)

        # Cap the list
        max_len = getattr(self, "_headless_history_max", 50) or 0
        if max_len and len(hist) > max_len:
            del hist[:-max_len]



    def _remember_last_headless_command(self, command_id: str, preset: dict | None = None, description: str = ""):
        """
        Private alias so older/newer call sites can use the underscored name.
        """
        return self.remember_last_headless_command(command_id, preset, description)

    def get_headless_history(self) -> list[dict]:
        """
        Return a *copy* of the headless history list.
        Each entry: {"command_id", "preset", "description"}.
        Newest is last.
        """
        return list(getattr(self, "_headless_history", []) or [])

    def replay_headless_history_entry_on_base(self, index: int, target_sw=None):
        """
        Replay a specific history entry on the base doc of target_sw,
        reusing replay_last_action_on_base for all the special cases.
        """
        hist = getattr(self, "_headless_history", [])
        if not hist:
            QMessageBox.information(self, "Replay Action", "There are no actions in history yet.")
            return

        try:
            entry = hist[index]
        except IndexError:
            QMessageBox.warning(self, "Replay Action", "Selected history item is no longer available.")
            return

        # Build a payload in the same schema replay_last_action_on_base expects
        payload = {
            "command_id": entry.get("command_id"),
            "preset": dict(entry.get("preset") or {}),
        }

        # Temporarily override _last_headless_command so we can reuse
        # your big replay_last_action_on_base() switchboard unchanged.
        old = getattr(self, "_last_headless_command", None)
        try:
            self._last_headless_command = payload
            self.replay_last_action_on_base(target_sw=target_sw)
        finally:
            self._last_headless_command = old


    def replay_last_action_on_subwindow(self, target_sw=None):
        """
        Called by subwindow(s) when the Replay button is clicked.
        Uses the stored headless command and routes it through _handle_command_drop.
        """
        payload = getattr(self, "_last_headless_command", None)


        if not payload:
            QMessageBox.information(
                self, "Replay Last Action",
                "There is no previous action to replay yet."
            )
            return

        # Resolve target subwindow
        if target_sw is None and hasattr(self, "mdi"):
            target_sw = self.mdi.activeSubWindow()

        if target_sw is None:
            QMessageBox.information(
                self, "Replay Last Action",
                "No active image view to apply the action to."
            )
            return

        try:
            self._handle_command_drop(dict(payload), target_sw=target_sw)
        except Exception as e:
            QMessageBox.critical(self, "Replay Last Action", f"Replay failed:\n{e}")

    def replay_last_action_on_base(self, target_sw=None):
        """
        Replay last headless command, but target the *base* document behind the view.
        Used by preview tabs that want "do this again on the full image".
        """
        payload = getattr(self, "_last_headless_command", None) or {}


        if not payload:
            QMessageBox.information(
                self, "Replay Last Action",
                "There is no previous action to replay yet."
            )
            return

        # Resolve target subwindow
        if target_sw is None and hasattr(self, "mdi"):
            target_sw = self.mdi.activeSubWindow()

        if target_sw is None:
            QMessageBox.information(
                self, "Replay Last Action",
                "No active image view to apply the action to."
            )
            return

        # Resolve the *base* document for this subwindow
        base_doc = self._target_doc_from_subwindow(target_sw) if hasattr(self, "_target_doc_from_subwindow") else None
        if base_doc is None or getattr(base_doc, "image", None) is None:
            QMessageBox.information(self, "Replay Last Action", "No base image to apply the action to.")
            return


        # ---- Extract cid + preset from payload (support both old + new schemas) ----
        cid_raw = payload.get("command_id")
        if cid_raw is None:
            cid_raw = payload.get("cid")
        cid = str(cid_raw or "").strip().lower()

        preset = payload.get("preset") or {}
        if not isinstance(preset, dict):
            try:
                preset = dict(preset)
            except Exception:
                preset = {}

        # ---- SPECIAL CASES: always run on base_doc ----
        if cid == "stat_stretch":
            try:
                self._apply_stat_stretch_preset_to_doc(base_doc, preset)
                try:
                    self._log(f"[Replay] Applied Statistical Stretch preset to base of '{target_sw.windowTitle()}'")
                except Exception:
                    pass
            except Exception as e:
                QMessageBox.warning(self, "Preset apply failed", str(e))
            return

        if cid == "pedestal":
            try:
                from setiastro.saspro.pedestal import remove_pedestal
                remove_pedestal(self, target_doc=base_doc)
                try:
                    self._log(f"[Replay] Applied Pedestal Removal to base of '{target_sw.windowTitle()}'")
                except Exception:
                    pass
            except Exception as e:
                QMessageBox.warning(self, "Pedestal Removal", str(e))
            return

        if cid == "linear_fit":
            try:
                from setiastro.saspro.linear_fit import apply_linear_fit_to_doc
                apply_linear_fit_to_doc(self, base_doc, preset)
                try:
                    self._log(f"[Replay] Applied Linear Fit preset to base of '{target_sw.windowTitle()}'")
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "Linear Fit", f"Replay-on-base failed:\n{e}")
                except Exception:
                    pass
            return

        if cid == "star_stretch":
            try:
                self._apply_star_stretch_preset_to_doc(base_doc, preset)
                try:
                    self._log(f"[Replay] Applied Star Stretch preset to base of '{target_sw.windowTitle()}'")
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "Star Stretch", f"Replay-on-base failed:\n{e}")
                except Exception:
                    pass
            return
        if cid == "texture_clarity":
            try:
                from setiastro.saspro.texture_clarity import texture_clarity_headless

                preset_dict = preset if isinstance(preset, dict) else {}
                texture_clarity_headless(
                    base_doc,
                    texture_amount = float(preset_dict.get("t_amt", 0.0)),
                    texture_radius = float(preset_dict.get("t_rad", 1.0)),
                    clarity_amount = float(preset_dict.get("c_amt", 0.0)),
                    clarity_radius = float(preset_dict.get("c_rad", 1.0)),
                    mask_strength  = float(preset_dict.get("mask_str", 1.0)),
                )

                try:
                    self._log(
                        f"[Replay] Applied Texture and Clarity to base of "
                        f"'{target_sw.windowTitle()}' "
                        f"(t_amt={preset_dict.get('t_amt',0):.2f}, "
                        f"c_amt={preset_dict.get('c_amt',0):.2f})"
                    )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "Texture and Clarity", f"Replay-on-base failed:\n{e}")
                except Exception:
                    print("Texture and Clarity replay-on-base failed:", e)
            return
        if cid == "levels":
            try:
                from setiastro.saspro.levels_preset import apply_levels_via_preset

                preset_dict = preset if isinstance(preset, dict) else {}
                apply_levels_via_preset(self, base_doc, preset_dict)

                try:
                    ch = str(preset_dict.get("channel", "L"))
                    b = float(preset_dict.get("black", 0.0))
                    m = float(preset_dict.get("mid", 0.5))
                    w = float(preset_dict.get("white", 1.0))
                    self._log(
                        f"[Replay] Applied Levels to base of '{target_sw.windowTitle()}' "
                        f"(ch={ch}, black={b:.5f}, mid={m:.5f}, white={w:.5f})"
                    )
                except Exception:
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(self, "Levels", f"Replay-on-base failed:\n{e}")
                except Exception:
                    print("Levels replay-on-base failed:", e)
            return

        if cid == "curves":
            try:
                # preset = payload.get("preset") from above
                preset_dict = preset if isinstance(preset, dict) else {}
                op = preset_dict.get("_ops")

                if op:
                    # New, exact replay: use the headless op engine strictly on base_doc
                    from setiastro.saspro.curve_editor_pro import apply_curves_ops
                    ok = apply_curves_ops(base_doc, op)
                    if not ok:
                        raise RuntimeError("apply_curves_ops() returned False")

                    try:
                        self._log(
                            f"[Replay] Applied Curves (ops) to base of "
                            f"'{target_sw.windowTitle()}'"
                        )
                    except Exception:
                        pass
                    return

                # Fallback for older payloads without _ops: use preset-style helper
                from setiastro.saspro.curves_preset import apply_curves_via_preset
                apply_curves_via_preset(self, base_doc, preset_dict)

                try:
                    self._log(
                        f"[Replay] Applied Curves (preset) to base of "
                        f"'{target_sw.windowTitle()}'"
                    )
                except Exception:
                    pass
                return

            except Exception as e:
                try:
                    QMessageBox.warning(
                        self, "Curves", f"Replay-on-base failed:\n{e}"
                    )
                except Exception:
                    print("Replay-on-base Curves failed:", e)
            return
        if cid == "cosmetic_correction":
            try:
                from setiastro.saspro.cosmetic_correction import apply_cosmetic_correction_preset_to_doc
                preset_dict = preset if isinstance(preset, dict) else {}

                # Re-run Cosmetic Correction on the *base* document
                apply_cosmetic_correction_preset_to_doc(self, base_doc, preset_dict)

                try:
                    hs = float(preset_dict.get("hot_sigma", 3.0))
                    cs = float(preset_dict.get("cold_sigma", 3.0))
                    ch = bool(preset_dict.get("correct_hot", True))
                    cc = bool(preset_dict.get("correct_cold", True))
                    bp = str(preset_dict.get("bayer_pattern", "") or "").strip() or "auto"
                    self._log(
                        f"[Replay] Applied Cosmetic Correction to base of "
                        f"'{target_sw.windowTitle()}' "
                        f"(hot σ={hs:.2f} {'on' if ch else 'off'}, "
                        f"cold σ={cs:.2f} {'on' if cc else 'off'}, bayer={bp})"
                    )
                except Exception:
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(
                        self,
                        "Cosmetic Correction",
                        f"Replay-on-base failed:\n{e}",
                    )
                except Exception:
                    print("Cosmetic Correction replay-on-base failed:", e)
            return
        if cid == "satchroma":
            try:
                from setiastro.saspro.satchroma_preset import apply_satchroma_via_preset
                preset_dict = preset if isinstance(preset, dict) else {}
                apply_satchroma_via_preset(self, base_doc, preset_dict)
                try:
                    mode_names = {0: "Saturation (HSV)", 1: "Chroma (Lab)"}
                    mode_name  = mode_names.get(int(preset_dict.get("mode", 0)), "Saturation")
                    strength   = float(preset_dict.get("strength", 1.0))
                    self._log(
                        f"[Replay] Applied SatChroma to base of "
                        f"'{target_sw.windowTitle()}' "
                        f"(mode={mode_name}, strength={strength:.2f})"
                    )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "SatChroma",
                                        f"Replay-on-base failed:\n{e}")
                except Exception:
                    print("SatChroma replay-on-base failed:", e)
            return

        if cid == "fx":
            try:
                from setiastro.saspro.fx_preset import apply_fx_via_preset, fx_effect_display_name
                preset_dict = preset if isinstance(preset, dict) else {}
                apply_fx_via_preset(self, base_doc, preset_dict)
                try:
                    effect_name = fx_effect_display_name(preset_dict.get("effect", "orton_glow"))
                    self._log(
                        f"[Replay] Applied FX ({effect_name}) to base of "
                        f"'{target_sw.windowTitle()}'"
                    )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "FX", f"Replay-on-base failed:\n{e}")
                except Exception:
                    print("FX replay-on-base failed:", e)
            return

        if cid == "ghs":
            try:
                from setiastro.saspro.ghs_preset import apply_ghs_via_preset

                # Normalize payload -> dict
                preset_dict = preset if isinstance(preset, dict) else {}

                # DEBUG: what did we actually get?
                try:
                    self._log(
                        f"[Replay] GHS replay-on-base: "
                        f"preset_keys={list(preset_dict.keys())}"
                    )
                except Exception:
                    print(
                        "[Replay] GHS replay-on-base: preset_keys=",
                        list(preset_dict.keys()),
                    )

                apply_ghs_via_preset(self, base_doc, preset_dict or {})

                try:
                    self._log(
                        f"[Replay] Applied GHS preset to base of "
                        f"'{target_sw.windowTitle()}'"
                    )
                except Exception:
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(self, "GHS", f"Apply failed:\n{e}")
                except Exception:
                    print("GHS replay-on-base failed:", e)
            return

        if cid == "abe":
            try:
                from setiastro.saspro.abe_preset import apply_abe_via_preset

                # Normalize payload -> dict
                preset_dict = preset if isinstance(preset, dict) else {}

                # DEBUG
                try:
                    self._log(
                        f"[Replay] ABE replay-on-base: "
                        f"preset_keys={list(preset_dict.keys())}"
                    )
                except Exception:
                    print(
                        "[Replay] ABE replay-on-base: preset_keys=",
                        list(preset_dict.keys()),
                    )

                apply_abe_via_preset(self, base_doc, preset_dict or {})

                try:
                    self._log(
                        f"[Replay] Applied ABE preset to base of "
                        f"'{target_sw.windowTitle()}' (no exclusions)"
                    )
                except Exception:
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(
                        self, "ABE", f"Replay-on-base failed:\n{e}"
                    )
                except Exception:
                    print("ABE replay-on-base failed:", e)
            return
        if cid == "graxpert":
            try:
                from setiastro.saspro.graxpert_preset import run_graxpert_via_preset

                preset_dict = preset if isinstance(preset, dict) else {}
                op = str(preset_dict.get("op", "background")).lower()
                gpu_val = bool(preset_dict.get("gpu", True))

                # Normalize for logging
                if op == "denoise":
                    strength_raw = preset_dict.get("strength", 0.50)
                    try:
                        strength_val = float(strength_raw)
                    except Exception:
                        strength_val = 0.50
                    ai_ver = preset_dict.get("ai_version") or "latest"
                    log_msg = (
                        f"GraXpert Denoise "
                        f"(strength={strength_val:.2f}, model={ai_ver}, "
                        f"gpu={'on' if gpu_val else 'off'})"
                    )
                else:
                    smooth_raw = preset_dict.get("smoothing", 0.10)
                    try:
                        smooth_val = float(smooth_raw)
                    except Exception:
                        smooth_val = 0.10
                    log_msg = (
                        f"GraXpert Gradient Removal "
                        f"(smoothing={smooth_val:.2f}, gpu={'on' if gpu_val else 'off'})"
                    )

                # ðŸ" Re-run GraXpert on the *base* document
                run_graxpert_via_preset(self, preset_dict, target_doc=base_doc)

                try:
                    self._log(
                        f"[Replay] Applied {log_msg} to base of "
                        f"'{target_sw.windowTitle()}'"
                    )
                except Exception:
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(self, "GraXpert", f"Replay-on-base failed:\n{e}")
                except Exception:
                    print("GraXpert replay-on-base failed:", e)
            return
        if cid == "remove_stars":
            try:
                from setiastro.saspro.remove_stars_preset import run_remove_stars_via_preset

                # Normalize payload -> dict
                preset_dict = preset if isinstance(preset, dict) else {}

                # ðŸ" Re-run Remove Stars on the *base* document
                run_remove_stars_via_preset(self, preset_dict, target_doc=base_doc)

                # Logging (mirror command-drop logging but with replay/base info)
                tool = str(preset_dict.get("tool", "starnet")).lower()
                try:
                    if tool.startswith("star"):
                        lin = bool(preset_dict.get("linear", True))
                        self._log(
                            f"[Replay] Ran Remove Stars on base "
                            f"(tool=StarNet, linear={'yes' if lin else 'no'}) "
                            f"for '{target_sw.windowTitle()}'"
                        )
                    else:
                        mode   = preset_dict.get("mode", "unscreen")
                        stride = int(preset_dict.get("stride", 512))
                        gpu    = not bool(preset_dict.get("disable_gpu", False))
                        show   = bool(preset_dict.get("show_extracted_stars", True))
                        self._log(
                            f"[Replay] Ran Remove Stars on base "
                            f"(tool=DarkStar, mode={mode}, stride={stride}, "
                            f"gpu={'on' if gpu else 'off'}, "
                            f"stars={'on' if show else 'off'}) "
                            f"for '{target_sw.windowTitle()}'"
                        )
                except Exception:
                    # Logging should never break replay
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(
                        self, "Remove Stars",
                        f"Replay-on-base failed:\n{e}"
                    )
                except Exception:
                    print("Remove Stars replay-on-base failed:", e)
            return
        if cid == "background_neutral":
            try:
                # Normalize payload -> dict
                preset_dict = preset if isinstance(preset, dict) else {}

                # Re-run BN on the *base* document
                self._apply_background_neutral_preset_to_doc(base_doc, preset_dict)

                try:
                    mode = str(preset_dict.get("mode", "auto")).lower()
                    self._log(
                        f"[Replay] Applied Background Neutralization "
                        f"(mode={mode}) to base of '{target_sw.windowTitle()}'"
                    )
                except Exception:
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(
                        self,
                        "Background Neutralization",
                        f"Replay-on-base failed:\n{e}",
                    )
                except Exception:
                    print("Background Neutralization replay-on-base failed:", e)
            return
        if cid == "white_balance":
            try:
                # Normalize payload -> dict
                preset_dict = preset if isinstance(preset, dict) else {}

                # Re-run WB on the *base* document via the existing helper
                self._apply_white_balance_preset_to_doc(base_doc, preset_dict)

                # Optional: nice logging describing the mode/params
                try:
                    mode = str(preset_dict.get("mode", "star")).lower()
                    if mode == "manual":
                        r = float(preset_dict.get("r_gain", 1.0))
                        g = float(preset_dict.get("g_gain", 1.0))
                        b = float(preset_dict.get("b_gain", 1.0))
                        detail = f"manual (R={r:.3f}, G={g:.3f}, B={b:.3f})"
                    elif mode == "auto":
                        detail = "auto"
                    else:
                        thr = float(preset_dict.get("threshold", 50.0))
                        reuse = bool(preset_dict.get("reuse_cached_sources", True))
                        detail = (
                            f"star-based (thr={thr:.1f}, "
                            f"reuse={'yes' if reuse else 'no'})"
                        )

                    self._log(
                        f"[Replay] Applied White Balance {detail} "
                        f"to base of '{target_sw.windowTitle()}'"
                    )
                except Exception:
                    # Logging should never break replay
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(
                        self,
                        "White Balance",
                        f"Replay-on-base failed:\n{e}",
                    )
                except Exception:
                    print("White Balance replay-on-base failed:", e)
            return
        if cid == "remove_green":
            try:
                from setiastro.saspro.remove_green import apply_remove_green_preset_to_doc

                preset_dict = preset if isinstance(preset, dict) else {}

                # Re-run Remove Green on the *base* document
                apply_remove_green_preset_to_doc(self, base_doc, preset_dict)

                try:
                    amt = float(preset_dict.get(
                        "amount",
                        preset_dict.get("strength",
                                        preset_dict.get("value", 1.0))
                    ))
                    mode = str(preset_dict.get(
                        "mode",
                        preset_dict.get("neutral_mode", "avg")
                    )).lower()
                    preserve = bool(preset_dict.get(
                        "preserve_lightness",
                        preset_dict.get("preserve", True)
                    ))
                    channel = str(preset_dict.get(
                        "channel",
                        preset_dict.get("target_channel", "G")
                    )).upper()
                    self._log(
                        f"[Replay] Applied Remove Green to base of "
                        f"'{target_sw.windowTitle()}' "
                        f"(channel={channel}, amount={amt:.2f}, mode={mode}, "
                        f"preserve_lightness={'yes' if preserve else 'no'})"
                    )
                except Exception:
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(
                        self,
                        "Remove Green",
                        f"Replay-on-base failed:\n{e}",
                    )
                except Exception:
                    print("Remove Green replay-on-base failed:", e)
            return
        if cid == "convo":
            try:
                self._apply_convo_preset_to_doc(base_doc, preset)
                try:
                    op = str(preset.get("op", "convolution"))
                    self._log(
                        f"[Replay] Applied Convo/Deconvo ({op}) preset to base of "
                        f"'{target_sw.windowTitle()}'"
                    )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(
                        self,
                        "Convo / Deconvo",
                        f"Replay-on-base failed:\n{e}",
                    )
                except Exception:
                    print("Convo replay-on-base failed:", e)
            return  # <- IMPORTANT: don't fall through to _handle_command_drop
        if cid == "wavescale_hdr":
            try:
                from setiastro.saspro.wavescale_hdr_preset import run_wavescale_hdr_via_preset

                # Normalize payload -> dict
                preset_dict = preset if isinstance(preset, dict) else {}

                # DEBUG (optional)
                try:
                    self._log(
                        f"[Replay] WaveScale HDR replay-on-base: "
                        f"preset_keys={list(preset_dict.keys())}"
                    )
                except Exception:
                    print(
                        "[Replay] WaveScale HDR replay-on-base: preset_keys=",
                        list(preset_dict.keys()),
                    )

                # ðŸ" Re-run WaveScale HDR on the *base* document
                run_wavescale_hdr_via_preset(self, preset_dict, target_doc=base_doc)

                # Logging similar to the command-drop handler
                try:
                    ns = int(preset_dict.get("n_scales", 5))
                    try:
                        comp = float(preset_dict.get("compression_factor", 1.5))
                    except Exception:
                        comp = 1.5
                    try:
                        mg = float(preset_dict.get("mask_gamma", 5.0))
                    except Exception:
                        mg = 5.0

                    self._log(
                        f"[Replay] Applied WaveScale HDR to base of "
                        f"'{target_sw.windowTitle()}' "
                        f"(n_scales={ns}, compression={comp:.2f}, mask_gamma={mg:.2f})"
                    )
                except Exception:
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(
                        self,
                        "WaveScale HDR",
                        f"Replay-on-base failed:\n{e}",
                    )
                except Exception:
                    print("WaveScale HDR replay-on-base failed:", e)
            return
        if cid == "wavescale_dark_enhance":
            try:
                # Normalize payload -> dict
                preset_dict = preset if isinstance(preset, dict) else {}

                n_scales   = int(preset_dict.get("n_scales", 6))
                boost      = float(preset_dict.get("boost_factor", 5.0))
                mask_gamma = float(preset_dict.get("mask_gamma", 1.0))
                iters      = int(preset_dict.get("iterations", 2))

                # Prefer helper if it exists (handles masks / blending)
                if hasattr(self, "_apply_wavescale_dark_enhance_preset_to_doc"):
                    self._apply_wavescale_dark_enhance_preset_to_doc(base_doc, {
                        "n_scales": n_scales,
                        "boost_factor": boost,
                        "mask_gamma": mask_gamma,
                        "iterations": iters,
                    })
                else:
                    # Fallback: direct compute, similar to _handle_command_drop
                    from setiastro.saspro.wavescalede import compute_wavescale_dse
                    import numpy as np

                    img = np.asarray(getattr(base_doc, "image", None), dtype=np.float32)
                    if img.size:
                        mx = float(np.nanmax(img))
                        if np.isfinite(mx) and mx > 1.0:
                            img = img / mx
                    img = np.clip(img, 0.0, 1.0).astype(np.float32, copy=False)

                    out, _ = compute_wavescale_dse(
                        img,
                        n_scales=n_scales,
                        boost_factor=boost,
                        mask_gamma=mask_gamma,
                        iterations=iters,
                    )
                    out = np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)

                    if hasattr(base_doc, "set_image"):
                        base_doc.set_image(out, step_name="WaveScale Dark Enhancer")
                    else:
                        base_doc.image = out

                try:
                    self._log(
                        f"[Replay] WaveScale Dark Enhancer applied to base of "
                        f"'{target_sw.windowTitle()}' "
                        f"(n_scales={n_scales}, boost={boost}, "
                        f"gamma={mask_gamma}, iter={iters})"
                    )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(
                        self,
                        "WaveScale Dark Enhancer",
                        f"Replay-on-base failed:\n{e}",
                    )
                except Exception:
                    print("WaveScale Dark Enhancer replay-on-base failed:", e)
            return
        if cid == "clahe":
            try:
                # normalize preset
                p = preset if isinstance(preset, dict) else {}
                # prefer your helper (respects masks & bit depth)
                if hasattr(self, "_apply_clahe_preset_to_doc"):
                    self._apply_clahe_preset_to_doc(base_doc, p)
                else:
                    from setiastro.saspro.clahe import apply_clahe_to_doc
                    apply_clahe_to_doc(base_doc, p)

                # optional logging
                try:
                    clip = p.get("clip_limit", 2.0)
                    tile = p.get("tile", 8)
                    if hasattr(self, "_log"):
                        self._log(
                            f"[Replay] CLAHE applied to base of "
                            f"'{target_sw.windowTitle()}' "
                            f"(clip_limit={clip}, tile={tile})"
                        )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "CLAHE", f"Replay-on-base failed:\n{e}")
                except Exception:
                    print("CLAHE replay-on-base failed:", e)
            return
        if cid == "morphology":
            try:
                p = preset if isinstance(preset, dict) else {}

                # Prefer our helper that also maintains replay state
                if hasattr(self, "_apply_morphology_preset_to_doc"):
                    self._apply_morphology_preset_to_doc(base_doc, p)
                else:
                    from setiastro.saspro.morphology import apply_morphology_to_doc
                    apply_morphology_to_doc(base_doc, p)

                # optional logging
                try:
                    op   = p.get("operation", "erosion")
                    kern = p.get("kernel", 3)
                    it   = p.get("iterations", 1)
                    if hasattr(self, "_log"):
                        self._log(
                            f"[Replay] Morphology applied to base of "
                            f"'{target_sw.windowTitle()}' "
                            f"(op={op}, kernel={kern}, iter={it})"
                        )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "Morphology", f"Replay-on-base failed:\n{e}")
                except Exception:
                    print("Morphology replay-on-base failed:", e)
            return
        if cid == "pixel_math":
            try:
                p = dict(preset or {})

                # Prefer helper that keeps replay state in sync
                if hasattr(self, "_apply_pixelmath_preset_to_doc"):
                    self._apply_pixelmath_preset_to_doc(base_doc, p)
                else:
                    from setiastro.saspro.pixelmath import apply_pixel_math_to_doc
                    apply_pixel_math_to_doc(self, base_doc, p)

                expr = (p.get("expr") or "").strip()
                if expr:
                    desc = expr
                else:
                    desc = (
                        f"R:{p.get('expr_r', '')} "
                        f"G:{p.get('expr_g', '')} "
                        f"B:{p.get('expr_b', '')}"
                    )

                try:
                    if hasattr(self, "_log"):
                        self._log(
                            f"[Replay] Pixel Math applied to base of "
                            f"'{target_sw.windowTitle()}' -> {desc}"
                        )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "Pixel Math", f"Replay-on-base failed:\n{e}")
                except Exception:
                    print("Pixel Math replay-on-base failed:", e)
            return
        if cid == "halo_b_gon":
            try:
                p = dict(preset or {})

                if hasattr(self, "_apply_halobgon_preset_to_doc"):
                    self._apply_halobgon_preset_to_doc(base_doc, p)
                else:
                    from setiastro.saspro.halobgon import apply_halo_b_gon_to_doc
                    apply_halo_b_gon_to_doc(self, base_doc, p)

                lvl = int(p.get("reduction", 0))
                lin = bool(p.get("linear", False))
                try:
                    if hasattr(self, "_log"):
                        self._log(
                            f"[Replay] Halo-B-Gon applied to base of "
                            f"'{target_sw.windowTitle()}' "
                            f"(level={lvl}, linear={lin})"
                        )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "Halo-B-Gon", f"Replay-on-base failed:\n{e}")
                except Exception:
                    print("Halo-B-Gon replay-on-base failed:", e)
            return
        if cid == "aberrationai":
            try:
                from setiastro.saspro.aberration_ai_preset import run_aberration_ai_via_preset
                # Apply the same preset, but explicitly on the base_doc
                run_aberration_ai_via_preset(self, preset or {}, doc=base_doc)

                pp = preset or {}
                auto = bool(pp.get("auto_gpu", True))
                prov = pp.get("provider", "auto" if auto else "CPUExecutionProvider")
                patch = int(pp.get("patch", 512))
                overlap = int(pp.get("overlap", 64))
                border = int(pp.get("border_px", 10))

                if hasattr(self, "_log"):
                    self._log(
                        f"[Replay] Aberration AI applied to base of "
                        f"'{target_sw.windowTitle()}' "
                        f"(patch={patch}, overlap={overlap}, border={border}px, provider={prov})"
                    )
            except Exception as e:
                try:
                    QMessageBox.warning(self, "Aberration AI", f"Replay-on-base failed:\n{e}")
                except Exception:
                    print("Replay Aberration AI failed:", e)
            return
        if cid == "cosmic_clarity":
            try:
                from setiastro.saspro.cosmicclarity_preset import run_cosmicclarity_via_preset

                # Normalize preset -> dict
                preset_dict = preset if isinstance(preset, dict) else {}
                run_cosmicclarity_via_preset(self, preset_dict, doc=base_doc)

                try:
                    m = preset_dict.get("mode", "sharpen")
                    self._log(
                        f"[Replay] Replayed Cosmic Clarity (mode={m}) "
                        f"on base of '{target_sw.windowTitle()}'"
                    )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(
                        self, "Cosmic Clarity",
                        f"Replay-on-base failed:\n{e}"
                    )
                except Exception:
                    print("Cosmic Clarity replay-on-base failed:", e)
            return
        if cid == "rcastro":
            try:
                from setiastro.saspro.rcastro import run_rcastro_via_preset

                preset_dict = preset if isinstance(preset, dict) else {}
                run_rcastro_via_preset(self, preset_dict, doc=base_doc)

                try:
                    _rc_labels = {
                        "bxt": "BlurXTerminator",
                        "sxt": "StarXTerminator",
                        "nxt": "NoiseXTerminator",
                    }
                    product = preset_dict.get("product", "bxt")
                    self._log(
                        f"[Replay] Replayed RC-Astro {_rc_labels.get(product, product.upper())} "
                        f"on base of '{target_sw.windowTitle()}'"
                    )
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(
                        self, "RC-Astro",
                        f"Replay-on-base failed:\n{e}"
                    )
                except Exception:
                    print("RC-Astro replay-on-base failed:", e)
            return
        # ---- For everything else, fall back to the normal command-drop behavior ----
        try:
            self._handle_command_drop(dict(payload), target_sw=target_sw)
        except Exception as e:
            QMessageBox.critical(self, "Replay Last Action", f"Replay failed:\n{e}")



    def _on_view_replay_last_requested(self, view):
        """
        Slot for ImageSubWindow.replayOnBaseRequested(view).
        Find the QMdiSubWindow that wraps this view and forward
        to replay_last_action_on_base().
        """
        target_sw = None
        if hasattr(self, "mdi"):
            for sw in self.mdi.subWindowList():
                if sw.widget() is view:
                    target_sw = sw
                    break

        # DEBUG
        try:
            self._log(
                f"[Replay] _on_view_replay_last_requested: view id={id(view)}, "
                f"found_subwindow={bool(target_sw)}"
            )
        except Exception:
            print(
                f"[Replay] _on_view_replay_last_requested: view id={id(view)}, "
                f"found_subwindow={bool(target_sw)}"
            )

        # ðŸ" For preview-tab replay -> run on base doc
        self.replay_last_action_on_base(target_sw=target_sw)



    # --- Command drop handling ----------------------------------------


    def _handle_command_drop(self, payload: dict, target_sw):
        # --- Debug: track raw calls ---
        cid_raw = (payload or {}).get("command_id")
        ts = time.monotonic()
        target_id = id(target_sw) if target_sw is not None else None

        # --- end debug header ---
        cid = payload.get("command_id")
        preset = payload.get("preset") or {}
    
        payload = payload or {}

        # 🔍 Global debug sniffer
        try:
            print(
                f"[HCD] DROP cid={cid!r}, target_sw={repr(target_sw)}, payload_keys={list((payload or {}).keys())}",
                flush=True,
            )
        except Exception:
            pass
        try:
            QApplication.processEvents()
        except Exception:
            pass
        def _extract_cid(p):
            # accept several shapes: "command_id": str | dict | list, or "command": {...}
            c = p.get("command_id")
            if isinstance(c, dict):
                c = c.get("id") or c.get("name") or c.get("command_id")
            elif isinstance(c, (list, tuple)):
                c = c[0] if c else None

            if not c:
                cmd = p.get("command")
                if isinstance(cmd, dict):
                    c = cmd.get("id") or cmd.get("name") or cmd.get("command_id")

            # last-ditch: stringify non-strings
            if c is None:
                c = ""
            if not isinstance(c, str):
                c = str(c)
            return c

        cid_raw = _extract_cid(payload)
        preset = payload.get("preset")
        if not isinstance(preset, dict):
            preset = {}

        from setiastro.saspro.command_ids import normalize_command_id

        def _cid_norm(c: str) -> str:
            s = (c or "").strip()
            if s.lower().startswith("script:"):
                return "script:" + s.split(":", 1)[1]
            return normalize_command_id(s)

        cid = _cid_norm(cid_raw)

        # ----- Scripts: "script:<script_id>" -----
        if isinstance(cid, str) and cid.startswith("script:"):
            sid = cid.split(":", 1)[1]

            # If dropped on a view, make it active so scripts operate on that doc
            try:
                if target_sw is not None:
                    self.mdi.setActiveSubWindow(target_sw)
                    QApplication.processEvents()
            except Exception:
                pass

            sm = getattr(self, "scriptman", None)
            if sm is None:
                QMessageBox.warning(self, "Scripts", "Script manager is not available.")
                return

            try:
                # Prefer an explicit id runner if you have one
                if callable(getattr(sm, "run_by_id", None)):
                    sm.run_by_id(sid)
                elif callable(getattr(sm, "run_script_id", None)):
                    sm.run_script_id(sid)
                else:
                    # Fallback: find entry and run
                    entry = None
                    reg = getattr(sm, "registry", None)
                    if reg:
                        for e in reg:
                            if getattr(e, "script_id", None) == sid:
                                entry = e
                                break
                    if entry is None:
                        raise RuntimeError(f"Unknown script id: {sid!r}")
                    sm.run_entry(entry)

                try:
                    self._log(f"Ran Script '{sid}'")
                except Exception:
                    pass

            except Exception as e:
                QMessageBox.critical(self, "Script failed", f"{sid}\n\n{e}")
            return


        def _call_any(method_names: list[str], *args, **kwargs) -> bool:
            for name in method_names:
                m = getattr(self, name, None)
                if callable(m):
                    m(*args, **kwargs)
                    return True
            return False

        # ----- Function bundle: run a sequence of steps on the target view(s) -----
        # ----- Function bundle: run a sequence of steps on the target view(s) -----
        if cid in ("function_bundle", "bundle_functions"):
            from PyQt6.QtWidgets import QApplication

            payload = payload or {}
            steps   = list((payload or {}).get("steps") or [])
            inherit = bool((payload or {}).get("inherit_target", True))

            print(
                f"[HCD] ENTER function_bundle: inherit={inherit}, target_sw={repr(target_sw)}, steps={len(steps)}, payload={payload!r}",
                flush=True,
            )
            QApplication.processEvents()

            if not steps:
                print("[HCD] function_bundle: NO STEPS, returning", flush=True)
                QApplication.processEvents()
                return

            # If user dropped onto the background (no direct target), support 'targets'
            if target_sw is None:
                targets = (payload or {}).get("targets")
                print(f"[HCD] function_bundle: NO target_sw, targets={targets!r}", flush=True)
                QApplication.processEvents()

                if targets == "all_open":
                    print("[HCD] function_bundle: apply to ALL OPEN subwindows", flush=True)
                    QApplication.processEvents()
                    for sw in list(self.mdi.subWindowList()):
                        print(f"[HCD]   all_open -> sw={repr(sw)}", flush=True)
                        QApplication.processEvents()
                        for i, st in enumerate(steps, start=1):
                            if not isinstance(st, dict) or not st.get("command_id"):
                                print(f"[HCD]     skip step[{i}]: bad payload {st!r}", flush=True)
                                QApplication.processEvents()
                                continue
                            cid2 = st.get("command_id")
                            print(f"[HCD]     BEGIN step[{i}/{len(steps)}] cid={cid2}", flush=True)
                            QApplication.processEvents()
                            try:
                                self._handle_command_drop(st, target_sw=sw)
                                print(f"[HCD]     END   step[{i}/{len(steps)}] cid={cid2} OK", flush=True)
                            except Exception as e:
                                print(f"[HCD]     END   step[{i}/{len(steps)}] cid={cid2} ERROR={e!r}", flush=True)
                            QApplication.processEvents()
                    print("[HCD] EXIT function_bundle (all_open)", flush=True)
                    QApplication.processEvents()
                    return

                if isinstance(targets, (list, tuple)):
                    print(f"[HCD] function_bundle: apply to explicit targets={targets!r}", flush=True)
                    QApplication.processEvents()
                    for ptr in targets:
                        try:
                            doc, sw = self._find_doc_by_id(int(ptr))
                            print(f"[HCD]   _find_doc_by_id({ptr}) -> sw={repr(sw)}", flush=True)
                        except Exception as e:
                            print(f"[HCD]   _find_doc_by_id({ptr}) ERROR={e!r}", flush=True)
                            sw = None
                        QApplication.processEvents()
                        if sw:
                            for i, st in enumerate(steps, start=1):
                                if not isinstance(st, dict) or not st.get("command_id"):
                                    print(f"[HCD]     skip step[{i}]: bad payload {st!r}", flush=True)
                                    QApplication.processEvents()
                                    continue
                                cid2 = st.get("command_id")
                                print(f"[HCD]     BEGIN step[{i}/{len(steps)}] cid={cid2}", flush=True)
                                QApplication.processEvents()
                                try:
                                    self._handle_command_drop(st, target_sw=sw)
                                    print(f"[HCD]     END   step[{i}/{len(steps)}] cid={cid2} OK", flush=True)
                                except Exception as e:
                                    print(f"[HCD]     END   step[{i}/{len(steps)}] cid={cid2} ERROR={e!r}", flush=True)
                                QApplication.processEvents()
                    print("[HCD] EXIT function_bundle (explicit targets)", flush=True)
                    QApplication.processEvents()
                    return

                # No target info -> open Function Bundles UI
                print("[HCD] function_bundle: no target info, opening Function Bundles UI", flush=True)
                QApplication.processEvents()
                try:
                    from setiastro.saspro.function_bundle import show_function_bundles
                    show_function_bundles(self)
                except Exception as e:
                    print(f"[HCD] show_function_bundles ERROR={e!r}", flush=True)
                    QApplication.processEvents()
                print("[HCD] EXIT function_bundle (UI path)", flush=True)
                QApplication.processEvents()
                return

            # We DO have an explicit target subwindow -> run the sequence there.
            print(f"[HCD] function_bundle: USING target_sw={repr(target_sw)}", flush=True)
            QApplication.processEvents()

            for i, st in enumerate(steps, start=1):
                if not isinstance(st, dict) or not st.get("command_id"):
                    print(f"[HCD]   skip step[{i}]: bad payload {st!r}", flush=True)
                    QApplication.processEvents()
                    continue

                cid2 = st.get("command_id")
                is_cc = str(cid2).lower().startswith("cosmic")
                print(
                    f"[HCD]   BEGIN step[{i}/{len(steps)}]{' (CC)' if is_cc else ''} cid={cid2}, payload={st!r}",
                    flush=True,
                )
                QApplication.processEvents()

                try:
                    self._handle_command_drop(st, target_sw=target_sw if inherit else None)
                    print(
                        f"[HCD]   END   step[{i}/{len(steps)}]{' (CC)' if is_cc else ''} cid={cid2} OK",
                        flush=True,
                    )
                except Exception as e:
                    print(
                        f"[HCD]   END   step[{i}/{len(steps)}]{' (CC)' if is_cc else ''} cid={cid2} ERROR={e!r}",
                        flush=True,
                    )

                QApplication.processEvents()

            print("[HCD] EXIT function_bundle (explicit target)", flush=True)
            QApplication.processEvents()
            return
        # --- Bundle runner ----------------------------------------
        if cid in ("bundle", "__bundle_exec__"):
            steps = list((payload or {}).get("steps") or [])
            if not steps:
                return

            # Resolve targets
            targets = (payload or {}).get("targets", None)
            def _iter_bundle_targets():
                # explicit list of doc pointers
                if isinstance(targets, (list, tuple)):
                    for ptr in targets:
                        try:
                            d, sw = self._find_doc_by_id(int(ptr))
                        except Exception:
                            d, sw = None, None
                        if sw is not None:
                            yield sw
                    return
                # special keywords
                if isinstance(targets, str) and targets.lower() == "all_open":
                    for sw in self.mdi.subWindowList():
                        if sw and sw.isVisible():
                            yield sw
                    return
                # default: the explicit drop target, else the active subwindow
                if target_sw is not None:
                    yield target_sw
                    return
                sw = self.mdi.activeSubWindow()
                if sw:
                    yield sw

            stop_on_error = bool((payload or {}).get("stop_on_error", False))

            # Optional: light progress text in Console
            try: self._log(f"Bundle: {len(steps)} step(s) -> {targets or 'target view'}")
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")


            for sw in _iter_bundle_targets():
                if sw is None: 
                    continue
                title = getattr(sw, "windowTitle", lambda: "view")()
                for i, sp in enumerate(steps, start=1):
                    try:
                        # allow nested bundles but guard against weird payloads
                        if not isinstance(sp, dict) or "command_id" not in sp:
                            continue
                        QCoreApplication.processEvents()
                        # Reuse this dispatcher on the specific subwindow target
                        self._handle_command_drop(sp, sw)
                        QCoreApplication.processEvents()
                        try: self._log(f"Bundle [{i}/{len(steps)}] on '{title}' -> {sp.get('command_id')}")
                        except Exception as e:
                            import logging
                            logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
                    except Exception as e:
                        try: self._log(f"Bundle step failed on '{title}': {e}")
                        except Exception as e:
                            import logging
                            logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
                        if stop_on_error:
                            QMessageBox.warning(self, "Bundle", f"Stopped on error:\n{e}")
                            return
                        # else continue to next step

            try: self._log("Bundle complete.")
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
            return

        # ------------------- No target subwindow -> open UIs / active ops -------------------
        if target_sw is None:
            if cid == "stat_stretch":
                self._open_statistical_stretch_with_preset(preset); return
            if cid == "star_stretch":
                self._open_star_stretch_with_preset(preset); return
            if cid == "remove_green":
                from setiastro.saspro.remove_green import open_remove_green_dialog
                open_remove_green_dialog(self, preset); return
            if cid == "pedestal":
                from setiastro.saspro.pedestal import open_remove_pedestal_with_preset
                open_remove_pedestal_with_preset(self, preset); return            
            if cid == "extract_luminance":
                self._extract_luminance(doc=None); return
            if cid == "recombine_luminance":
                self._recombine_luminance_ui(target_doc=None); return
            if cid == "wavescale_hdr":
                self._open_wavescale_hdr(); return
            if cid == "wavescale_dark_enhance":
                self._open_wavescale_dark_enhance(); return
            if cid == "clahe":
                self._open_clahe(); return
            if cid == "pixel_math":
                self._open_pixel_math(); return
            if cid == "halo_b_gon":
                self._open_halo_b_gon(); return
            if cid == "rgb_combine":
                self._open_rgb_combination(); return
            if cid == "curves":
                from setiastro.saspro.curves_preset import open_curves_with_preset
                open_curves_with_preset(self, preset)
                return
            if cid == "crop":
                try:
                    from setiastro.saspro.crop_preset import run_crop_via_preset
                    run_crop_via_preset(self, preset or {}, target_doc=None)
                    self._log("Ran Crop headlessly on active view.")
                except Exception as e:
                    QMessageBox.warning(self, "Crop", f"Apply failed:\n{e}")
                return
            
            if cid == "star_align":
                try:
                    from setiastro.saspro.star_alignment_preset import run_star_alignment_via_preset
                    run_star_alignment_via_preset(self, preset or {}, target_doc=doc)
                    rp = preset or {}
                    rm = str(rp.get("ref_mode", "active"))
                    rn = (rp.get("ref_name") or os.path.basename(rp.get("ref_file","")) or
                        (str(rp.get("ref_ptr")) if rp.get("ref_ptr") is not None else "active"))
                    self._log(f"Ran Star Alignment (ref={rm}:{rn}, overwrite={'yes' if rp.get('overwrite', False) else 'no'})")
                except Exception as e:
                    
                    QMessageBox.warning(self, "Star Alignment", f"Apply failed:\n{e}")
                return            
            if target_sw is None:
                if cid == "ghs":
                    from setiastro.saspro.ghs_preset import open_ghs_with_preset
                    open_ghs_with_preset(self, preset)
                    return

            if cid == "syqontools":
                from setiastro.saspro.syqon_tools import open_syqontools_with_preset
                open_syqontools_with_preset(self, preset)
                return

            if cid == "export_fits":
                self._open_export_fits(preset)
                return

            # Fallback: trigger QAction by cid (ok when no target)
            act = self._find_action_by_cid(cid)
            if act:
                act.trigger()
            return


        # ------------------- Dropped on a specific subwindow -> HEADLESS APPLY -------------------
        view = target_sw.widget()
        doc = getattr(view, "document", None)

        # NEW: resolve the base document (for Preview tabs, this is the full-frame doc)
        base_doc = getattr(view, "base_document", None)
        if base_doc is None:
            base_doc = doc

        # --- Existing image-processing blocks (unchanged) ---
        if cid == "export_fits":
            try:
                self._apply_export_fits_to_doc(doc, preset or {})
            except Exception as e:
                QMessageBox.warning(self, "Export FITS", str(e))
            return

        if cid == "stat_stretch":
            try:
                self._apply_stat_stretch_preset_to_doc(doc, preset)
                self._log(f"Applied Statistical Stretch preset to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Preset apply failed", str(e))
            return

        if cid == "star_stretch":
            try:
                self._apply_star_stretch_preset_to_doc(doc, preset)
                self._log(f"Applied Star Stretch preset to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Preset apply failed", str(e))
            return

        if cid == "levels":
            try:
                from setiastro.saspro.levels_preset import apply_levels_via_preset
                apply_levels_via_preset(self, doc, preset or {})
                try:
                    self._log(f"Applied Levels preset to '{target_sw.windowTitle()}'")
                except Exception:
                    pass

                # remember last headless command for replay
                try:
                    self._last_headless_command = {"command_id": "levels", "preset": dict(preset or {})}
                except Exception:
                    pass

            except Exception as e:
                try:
                    QMessageBox.warning(self, "Levels", f"Apply failed:\n{e}")
                except Exception:
                    pass
            return

        if cid == "curves":
            try:
                from setiastro.saspro.curves_preset import apply_curves_via_preset
                apply_curves_via_preset(self, doc, preset or {})
                self._log(f"Applied Curves preset to '{target_sw.windowTitle()}'")
            except Exception as e:
                
                QMessageBox.warning(self, "Curves", f"Apply failed:\n{e}")
            return

        if cid == "satchroma":
            try:
                from setiastro.saspro.satchroma_preset import apply_satchroma_via_preset
                apply_satchroma_via_preset(self, doc, preset or {})
                try:
                    self._log(
                        f"Applied SatChroma preset to '{target_sw.windowTitle()}'"
                    )
                except Exception:
                    pass
                try:
                    self._last_headless_command = {
                        "command_id": "satchroma",
                        "preset":     dict(preset or {}),
                    }
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "SatChroma", f"Apply failed:\n{e}")
                except Exception:
                    pass
            return
        if cid == "unwarp":
            # Unwarp needs the full frame + its real WCS/SIP, so prefer the base
            # document (a Preview/ROI doc won't carry the full solution).
            u_doc = base_doc if base_doc is not None else doc
            if u_doc is None or getattr(u_doc, "image", None) is None:
                QMessageBox.information(self, "Unwarp", "Target view has no image.")
                return
            try:
                from setiastro.saspro.unwarp import apply_unwarp_to_doc
                ok = apply_unwarp_to_doc(u_doc, preset or {}, main_window=self)
                if ok:
                    try:
                        self._last_headless_command = {
                            "command_id": "unwarp",
                            "preset": dict(preset or {}),
                        }
                    except Exception:
                        pass
                    self._log(f"Applied Unwarp (remove SIP) to '{target_sw.windowTitle()}'")
                else:
                    # No WCS / no SIP → apply_unwarp_to_doc is a logged no-op
                    QMessageBox.information(
                        self, "Unwarp",
                        "This image has no SIP distortion to remove.\n"
                        "Plate solve with SIP enabled first.")
            except Exception as e:
                QMessageBox.warning(self, "Unwarp", f"Apply failed:\n{e}")
            return
        if cid == "fx":
            try:
                from setiastro.saspro.fx_preset import apply_fx_via_preset, fx_effect_display_name
                apply_fx_via_preset(self, doc, preset or {})
                try:
                    effect_name = fx_effect_display_name((preset or {}).get("effect", "orton_glow"))
                    self._log(f"Applied FX ({effect_name}) preset to '{target_sw.windowTitle()}'")
                except Exception:
                    pass
                try:
                    self._last_headless_command = {
                        "command_id": "fx",
                        "preset":     dict(preset or {}),
                    }
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "FX", f"Apply failed:\n{e}")
                except Exception:
                    pass
            return

        if cid == "syqontools":
            self._execute_syqon_tools_command(preset, target_sw=target_sw)
            return

        if cid == "ghs":
            try:
                from setiastro.saspro.ghs_preset import apply_ghs_via_preset
                apply_ghs_via_preset(self, doc, preset or {})
                self._log(f"Applied GHS preset to '{target_sw.windowTitle()}'")
            except Exception as e:
                
                QMessageBox.warning(self, "GHS", f"Apply failed:\n{e}")
            return
        if cid == "crop":
            try:
                from setiastro.saspro.crop_preset import apply_crop_via_preset
                apply_crop_via_preset(self, doc, preset or {})
                self._log(f"Applied Crop preset to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Crop", f"Apply failed:\n{e}")
            return

        if cid == "pedestal":
            try:
                from setiastro.saspro.pedestal import remove_pedestal
                remove_pedestal(self, target_doc=doc, preset=preset or {})
                try:
                    self._log(f"Applied Remove Pedestal to '{target_sw.windowTitle()}'")
                except Exception:
                    pass
                try:
                    self._last_headless_command = {
                        "command_id": "pedestal",
                        "preset": dict(preset or {}),
                    }
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, "Remove Pedestal", f"Apply failed:\n{e}")
                except Exception:
                    pass
            return

        if cid == "abe":
            try:
                from setiastro.saspro.abe_preset import apply_abe_via_preset
                apply_abe_via_preset(self, doc, preset or {})
                self._log(f"Applied ABE preset to '{target_sw.windowTitle()}' (no exclusions)")
            except Exception as e:
                QMessageBox.warning(self, "ABE", f"Apply failed:\n{e}")
            return

        if cid == "graxpert":
            from setiastro.saspro.graxpert_preset import run_graxpert_via_preset

            if doc is None or getattr(doc, "image", None) is None:
                QMessageBox.warning(self, "GraXpert", "Target document has no image.")
                return

            p = preset or {}
            op = str(p.get("op", "background")).lower()  # "background" or "denoise"

            # Run headless on this specific document (ROI or full frame)
            run_graxpert_via_preset(self, p, target_doc=doc)

            # Logging
            gpu_val = bool(p.get("gpu", True))
            if op == "denoise":
                s_raw = p.get("strength", 0.50)
                try:
                    s_val = float(s_raw)
                except Exception:
                    s_val = 0.50
                ai_ver = p.get("ai_version") or "latest"
                self._log(
                    f"Ran GraXpert Denoise "
                    f"(strength={s_val:.2f}, model={ai_ver}, gpu={'on' if gpu_val else 'off'})"
                )
            else:
                s_raw = p.get("smoothing", 0.10)
                try:
                    s_val = float(s_raw)
                except Exception:
                    s_val = 0.10
                self._log(
                    f"Ran GraXpert Gradient Removal "
                    f"(smoothing={round(s_val, 2)}, gpu={'on' if gpu_val else 'off'})"
                )
            return


        if cid == "convo":
            try:
                self._apply_convo_preset_to_doc(doc, preset or {})
            except Exception as e:
                QMessageBox.warning(self, "Convo/Deconvo", f"Apply failed:\n{e}")
            return

        if cid == "remove_stars":
            from setiastro.saspro.remove_stars_preset import run_remove_stars_via_preset

            if doc is None or getattr(doc, "image", None) is None:
                QMessageBox.warning(self, "Remove Stars", "Target document has no image.")
                return

            # Run headless on this specific document (ROI or full frame)
            run_remove_stars_via_preset(self, preset or {}, target_doc=doc)

            # safe logging (no nested format specs)
            tool = str((preset or {}).get("tool", "starnet"))
            if tool.lower().startswith("star"):
                lin = bool((preset or {}).get("linear", True))
                self._log(f"Ran Remove Stars (tool=StarNet, linear={'yes' if lin else 'no'})")
            else:
                mode = (preset or {}).get("mode", "unscreen")
                stride = int((preset or {}).get("stride", 512))
                gpu = not bool((preset or {}).get("disable_gpu", False))
                show = bool((preset or {}).get("show_extracted_stars", True))
                self._log(
                    f"Ran Remove Stars (tool=DarkStar, mode={mode}, "
                    f"stride={stride}, gpu={'on' if gpu else 'off'}, "
                    f"stars={'on' if show else 'off'})"
                )
            return


        if cid == "aberrationai":
            from setiastro.saspro.aberration_ai_preset import run_aberration_ai_via_preset
            run_aberration_ai_via_preset(self, preset or {})
            # safe, simple log
            pp = preset or {}
            auto = bool(pp.get("auto_gpu", True))
            prov = pp.get("provider", "auto" if auto else "CPUExecutionProvider")
            self._log(f"Ran Aberration AI (patch={int(pp.get('patch',512))}, overlap={int(pp.get('overlap',64))}, border={int(pp.get('border_px',10))}px, provider={prov})")
            return

        if cid == "cosmic_clarity":
            from setiastro.saspro.cosmicclarity_preset import run_cosmicclarity_via_preset

            # resolve doc from the target subwindow if present
            doc = None
            try:
                if target_sw is not None:
                    vw = target_sw.widget()
                    doc = getattr(vw, "document", None)
            except Exception:
                doc = None

            run_cosmicclarity_via_preset(self, preset or {}, doc=doc)  # <-- pass doc

            try:
                m = (preset or {}).get("mode", "sharpen")
                self._log(f"Ran Cosmic Clarity (mode={m})")
            except Exception:
                pass
            return
        if cid == "rcastro":
            from setiastro.saspro.rcastro import run_rcastro_via_preset

            doc = None
            try:
                if target_sw is not None:
                    vw = target_sw.widget()
                    doc = getattr(vw, "document", None)
            except Exception:
                doc = None

            run_rcastro_via_preset(self, preset or {}, doc=doc)

            try:
                _rc_labels = {"bxt": "BlurXTerminator", "sxt": "StarXTerminator", "nxt": "NoiseXTerminator"}
                product = (preset or {}).get("product", "bxt")
                self._log(f"Ran RC-Astro {_rc_labels.get(product, product.upper())}")
            except Exception:
                pass
            return
        if cid == "linear_fit":
            try:
                doc = self.doc_manager.get_active_document()
                from setiastro.saspro.linear_fit import apply_linear_fit_via_preset
                apply_linear_fit_via_preset(self, self.doc_manager, doc, preset or {})
                self._log("Applied Linear Fit")
            except Exception as e:
                QMessageBox.warning(self, "Linear Fit", f"Apply failed:\n{e}")
            return

        if cid == "remove_green":
            try:
                from setiastro.saspro.remove_green import apply_remove_green_preset_to_doc

                # Normalize any legacy keys into a canonical preset
                raw = preset if isinstance(preset, dict) else {}
                amt = float(raw.get("amount",
                                    raw.get("strength",
                                            raw.get("value", 1.0))))
                mode = str(raw.get("mode",
                                   raw.get("neutral_mode", "avg"))).lower()
                preserve = bool(raw.get("preserve_lightness",
                                        raw.get("preserve", True)))
                channel = str(raw.get("channel",
                                      raw.get("target_channel", "G"))).upper()

                preset_dict = {
                    "amount": amt,
                    "mode": mode,
                    "preserve_lightness": preserve,
                    "channel": channel,
                }

                # Apply to the current doc (ROI or full view)
                apply_remove_green_preset_to_doc(self, doc, preset_dict)

                # Record for Replay Last Action so preview -> base works
                try:
                    self._last_headless_command = {
                        "command_id": "remove_green",
                        "preset": dict(preset_dict),
                    }
                    if hasattr(self, "_log"):
                        self._log(
                            f"[Replay] Recorded Remove Green preset from command drop "
                            f"(channel={channel}, amount={amt:.2f}, mode={mode}, "
                            f"preserve_lightness={'yes' if preserve else 'no'})"
                        )
                except Exception:
                    # Don't let logging break the command
                    pass

            except Exception as e:
                QMessageBox.warning(self, "Remove Green", str(e))
            return


        if cid == "star_align":
            try:
                from setiastro.saspro.star_alignment_preset import run_star_alignment_via_preset
                run_star_alignment_via_preset(self, preset or {}, target_doc=doc)
                # simple, robust logging
                rp = preset or {}
                rm = rp.get("ref_mode", "active")
                rn = rp.get("ref_name") or os.path.basename(rp.get("ref_file","")) or "active"
                self._log(f"Ran Star Alignment (ref={rm}:{rn}, overwrite={'yes' if rp.get('overwrite', False) else 'no'})")
            except Exception as e:
                
                QMessageBox.warning(self, "Star Alignment", f"Apply failed:\n{e}")
            return

        if cid == "rgb_align":
            # 1) find the document
            doc = None
            view = None
            if target_sw is not None:
                view = target_sw.widget()
                doc = getattr(view, "document", None)
            if doc is None and hasattr(self, "_active_doc"):
                # your existing helper
                doc = self._active_doc()

            if not doc or getattr(doc, "image", None) is None:
                QMessageBox.information(self, "RGB Align", "No image in the dropped/active view.")
                return

            # 2) if we were called WITH a preset -> headless
            #    (this is what shortcuts / Alt-drag will supply)
            if preset:
                self._log(f"Running RGB Align headlessly on '{target_sw.windowTitle()}'")
                QApplication.processEvents()
                try:
                    from setiastro.saspro.rgbalign import run_rgb_align_headless
                    
                    run_rgb_align_headless(self, doc, preset)
                except Exception as e:
                    QMessageBox.critical(self, "RGB Align", f"Headless failed:\n{e}")
                return

            # 3) otherwise -> open the dialog like before
            try:
                from setiastro.saspro.rgbalign import RGBAlignDialog
                dlg = RGBAlignDialog(parent=self, document=view or doc)
                try:
                    dlg.setWindowIcon(QIcon(rgbalign_path))
                except Exception:
                    pass
                dlg.show()
            except Exception as e:
                QMessageBox.critical(self, "RGB Align", f"Open failed:\n{e}")
            return


        if cid == "background_neutral":
            try:
                self._apply_background_neutral_preset_to_doc(doc, preset)
                self._log(f"Background Neutralization applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Background Neutralization", str(e))
            return

        if cid == "white_balance":
            try:
                # Normalize preset -> dict and supply sensible defaults
                preset_dict = preset if isinstance(preset, dict) else {}
                if not preset_dict:
                    preset_dict = {
                        "mode": "star",
                        "threshold": 50.0,
                        "reuse_cached_sources": True,
                    }

                # Apply to the *current* doc (ROI or full), just like before
                self._apply_white_balance_preset_to_doc(doc, preset_dict)

                # Record for Replay Last Action so preview -> base replay works
                try:
                    self._last_headless_command = {
                        "command_id": "white_balance",
                        "preset": preset_dict,
                    }

                    # Optional: nice logging
                    mode = str(preset_dict.get("mode", "star")).lower()
                    if mode == "manual":
                        r = float(preset_dict.get("r_gain", 1.0))
                        g = float(preset_dict.get("g_gain", 1.0))
                        b = float(preset_dict.get("b_gain", 1.0))
                        self._log(
                            f"[Replay] Recorded White Balance preset from command drop "
                            f"(mode=manual, R={r:.3f}, G={g:.3f}, B={b:.3f})"
                        )
                    elif mode == "auto":
                        self._log(
                            "[Replay] Recorded White Balance preset from command drop (mode=auto)"
                        )
                    else:
                        thr = float(preset_dict.get("threshold", 50.0))
                        reuse = bool(preset_dict.get("reuse_cached_sources", True))
                        self._log(
                            f"[Replay] Recorded White Balance preset from command drop "
                            f"(mode=star, threshold={thr:.1f}, "
                            f"reuse={'yes' if reuse else 'no'})"
                        )
                except Exception:
                    # Recording/logging must never break the command
                    pass

                # Existing log about the actual apply
                self._log(f"White Balance applied to '{target_sw.windowTitle()}'")

            except Exception as e:
                QMessageBox.warning(self, "White Balance", str(e))
            return


        if cid == "wavescale_hdr":
            from setiastro.saspro.wavescale_hdr_preset import run_wavescale_hdr_via_preset
            run_wavescale_hdr_via_preset(self, preset or {}, target_doc=doc)
            # safe, readable log
            pp = preset or {}
            ns = int(pp.get("n_scales", 5))
            try:
                comp = float(pp.get("compression_factor", 1.5))
            except Exception:
                comp = 1.5
            try:
                mg = float(pp.get("mask_gamma", 5.0))
            except Exception:
                mg = 5.0
            self._log(f"Ran WaveScale HDR (n_scales={ns}, compression={comp:.2f}, mask_gamma={mg:.2f})")
            return

        if cid == "wavescale_dark_enhance":
            try:
                from setiastro.saspro.wavescalede_preset import run_wavescalede_via_preset
                run_wavescalede_via_preset(self, preset or {}, target_doc=doc)
                pp = preset or {}
                ns   = int(pp.get("n_scales", 6))
                try: bf = float(pp.get("boost_factor", 5.0))
                except Exception: bf = 5.0
                try: mg = float(pp.get("mask_gamma", 1.0))
                except Exception: mg = 1.0
                it   = int(pp.get("iterations", 2))
                self._log(f"Ran WaveScale Dark Enhancer (n_scales={ns}, boost={bf:.2f}, mask_gamma={mg:.2f}, iters={it})")
            except Exception as e:
                
                QMessageBox.warning(self, "WaveScale Dark Enhancer", f"Apply failed:\n{e}")
            return
        if cid == "texture_clarity":
            from setiastro.saspro.texture_clarity import texture_clarity_headless
            texture_clarity_headless(
                doc,
                texture_amount    = preset.get("t_amt", 0.0),
                texture_radius    = preset.get("t_rad", 1.0),
                unsharp_amount    = preset.get("u_amt", 0.0),
                unsharp_radius    = preset.get("u_rad", 2.0),
                unsharp_threshold = preset.get("u_thr", 0.0),
                clarity_amount    = preset.get("c_amt", 0.0),
                clarity_radius    = preset.get("c_rad", 1.0),
                mask_strength     = preset.get("mask_str", 1.0),
            )
            return

        if cid == "extract_luminance":
            try:
                self._extract_luminance(doc=doc)
                self._log(f"Extract Luminance -> new doc from '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Extract Luminance", str(e))
            return

        if cid == "recombine_luminance":
            self._recombine_luminance_ui(target_doc=doc)
            self._log(f"Recombined Luminance -> doc '{target_sw.windowTitle()}'")
            return

        if cid == "rgb_extract":
            self._rgb_extract_on_doc(doc, base_title=target_sw.windowTitle())
            self._log(f"Extracted R, G, and B channels from '{target_sw.windowTitle()}'")
            return

        if cid == "blemish_blaster":
            from setiastro.saspro.blemish_blaster import BlemishBlasterDialogPro
            dlg = BlemishBlasterDialogPro(self, doc)
            try: dlg.setWindowIcon(QIcon(blastericon_path))
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
            dlg.resize(900, 650)
            dlg.show()
            return

        if cid == "cosmetic_correction":
            try:
                from setiastro.saspro.cosmetic_correction import apply_cosmetic_correction_preset_to_doc
                apply_cosmetic_correction_preset_to_doc(self, doc, preset or {})
                self._log(f"Applied Cosmetic Correction preset to '{target_sw.windowTitle()}'")

                # remember last headless command for replay
                try:
                    self._last_headless_command = {"command_id": "cosmetic_correction", "preset": dict(preset or {})}
                except Exception:
                    pass

            except Exception as e:
                QMessageBox.warning(self, "Preset apply failed", str(e))
            return

        if cid == "wavescale_hdr":
            # (unchanged block)
            from setiastro.saspro.wavescale_hdr import compute_wavescale_hdr
            try:
                img = np.asarray(doc.image, dtype=np.float32)
                if img.ndim == 2:
                    base_rgb = np.repeat(img[:, :, None], 3, axis=2); was_mono, mono_shape = True, img.shape
                elif img.ndim == 3 and img.shape[2] == 1:
                    base_rgb = np.repeat(img, 3, axis=2); was_mono, mono_shape = True, img.shape
                else:
                    base_rgb = img[:, :, :3]; was_mono, mono_shape = False, None

                n_scales = int(preset.get("n_scales", 5))
                compression_factor = float(preset.get("compression_factor", 1.5))
                mask_gamma = float(preset.get("mask_gamma", 5.0))

                transformed, mask = compute_wavescale_hdr(
                    np.clip(base_rgb, 0, 1),
                    n_scales=n_scales, compression_factor=compression_factor, mask_gamma=mask_gamma
                )
                m3 = np.repeat(mask[..., None], 3, axis=2)
                blended = base_rgb * (1.0 - m3) + transformed * m3

                if was_mono:
                    out = np.mean(blended, axis=2, dtype=np.float32)
                    if len(mono_shape) == 3 and mono_shape[2] == 1:
                        out = out[:, :, None]
                else:
                    out = blended

                out = np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)
                if hasattr(doc, "set_image"): doc.set_image(out, step_name="WaveScale HDR")
                else: doc.image = out

                self._log(f"WaveScale HDR applied to '{target_sw.windowTitle()}' (n_scales={n_scales}, comp={compression_factor}, gamma={mask_gamma})")
            except Exception as e:
                QMessageBox.warning(self, "WaveScale HDR", f"Preset apply failed:\n{e}")
            return

        if cid == "wavescale_dark_enhance":
            n_scales     = int(preset.get("n_scales", 6))
            boost_factor = float(preset.get("boost_factor", 5.0))
            mask_gamma   = float(preset.get("mask_gamma", 1.0))
            iterations   = int(preset.get("iterations", 2))
            try:
                if hasattr(self, "_apply_wavescale_dark_enhance_preset_to_doc"):
                    self._apply_wavescale_dark_enhance_preset_to_doc(doc, {
                        "n_scales": n_scales, "boost_factor": boost_factor,
                        "mask_gamma": mask_gamma, "iterations": iterations,
                    })
                else:
                    from setiastro.saspro.wavescalede import compute_wavescale_dse
                    img = np.asarray(doc.image, dtype=np.float32)
                    if img.size:
                        mx = float(np.nanmax(img))
                        if np.isfinite(mx) and mx > 1.0:
                            img = img / mx
                    img = np.clip(img, 0.0, 1.0).astype(np.float32, copy=False)
                    out, _ = compute_wavescale_dse(
                        img, n_scales=n_scales, boost_factor=boost_factor,
                        mask_gamma=mask_gamma, iterations=iterations
                    )
                    out = np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)
                    if hasattr(doc, "set_image"): doc.set_image(out, step_name="WaveScale Dark Enhance")
                    else: doc.image = out
                self._log(f"WaveScale Dark Enhancer applied to '{target_sw.windowTitle()}' (n_scales={n_scales}, boost={boost_factor}, gamma={mask_gamma}, iter={iterations})")
            except Exception as e:
                QMessageBox.warning(self, "WaveScale Dark Enhancer", f"Preset apply failed:\n{e}")
            return

        if cid == "clahe":
            try:
                self._apply_clahe_preset_to_doc(doc, preset)
                self._log(f"CLAHE applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "CLAHE", str(e))
            return

        if cid == "morphology":
            try:
                if hasattr(self, "_apply_morphology_preset_to_doc"):
                    self._apply_morphology_preset_to_doc(doc, preset)
                else:
                    from setiastro.saspro.morphology import apply_morphology_to_doc
                    apply_morphology_to_doc(doc, preset)

                self._log(f"Morphology applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Morphology", str(e))
            return

        if cid == "pixel_math":
            try:
                p = dict(preset or {})

                if hasattr(self, "_apply_pixelmath_preset_to_doc"):
                    self._apply_pixelmath_preset_to_doc(doc, p)
                else:
                    from setiastro.saspro.pixelmath import apply_pixel_math_to_doc
                    apply_pixel_math_to_doc(self, doc, p)

                expr = (p.get("expr") or "").strip()
                if expr:
                    desc = expr
                else:
                    desc = (
                        f"R:{p.get('expr_r', '')} "
                        f"G:{p.get('expr_g', '')} "
                        f"B:{p.get('expr_b', '')}"
                    )

                self._log(f"Pixel Math applied to '{target_sw.windowTitle()}' -> {desc}")
            except Exception as e:
                QMessageBox.warning(self, "Pixel Math", f"Preset apply failed:\n{e}")
            return


        if cid == "signature_insert":
            try:
                from setiastro.saspro.signature_insert import apply_signature_preset_to_doc
                out = apply_signature_preset_to_doc(doc, preset)
                if hasattr(doc, "set_image"): doc.set_image(out, step_name="Signature / Insert")
                else: doc.image = out
                fp = preset.get("file_path", "<file>"); pos = preset.get("position", "bottom_right")
                self._log(f"Signature preset applied to '{target_sw.windowTitle()}' (file={fp}, pos={pos}, scale={preset.get('scale',100)}%, rot={preset.get('rotation',0)}Â deg, op={preset.get('opacity',100)}%)")
            except Exception as e:
                QMessageBox.warning(self, "Signature / Insert", f"Preset apply failed:\n{e}")
            return

        if cid == "halo_b_gon":
            try:
                p = dict(preset or {})

                if hasattr(self, "_apply_halobgon_preset_to_doc"):
                    self._apply_halobgon_preset_to_doc(doc, p)
                else:
                    from setiastro.saspro.halobgon import apply_halo_b_gon_to_doc
                    apply_halo_b_gon_to_doc(self, doc, p)

                lvl = int(p.get("reduction", 0))
                lin = bool(p.get("linear", False))
                self._log(
                    f"Halo-B-Gon applied to '{target_sw.windowTitle()}' "
                    f"(level={lvl}, linear={lin})"
                )
            except Exception as e:
                QMessageBox.warning(self, "Halo-B-Gon", f"Preset apply failed:\n{e}")
            return


        # ----- Geometry (headless; accept all old/new ids) -----
        if cid == "geom_invert":
            try:
                _call_any(["_apply_geom_invert_to_doc"], doc)
                self._log(f"Inverted '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Invert", str(e))
            return

        if cid == "geom_flip_horizontal":
            try:
                called = _call_any(["_apply_geom_flip_h_to_doc", "_apply_geom_flip_horizontal_to_doc"], doc)
                if not called:
                    raise RuntimeError("No flip-horizontal apply method found")
                self._log(f"Flip Horizontal applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Flip Horizontal", str(e))
            return

        if cid == "geom_flip_vertical":
            try:
                called = _call_any(["_apply_geom_flip_v_to_doc", "_apply_geom_flip_vertical_to_doc"], doc)
                if not called:
                    raise RuntimeError("No flip-vertical apply method found")
                self._log(f"Flip Vertical applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Flip Vertical", str(e))
            return

        if cid == "geom_rotate_clockwise":
            try:
                called = _call_any(["_apply_geom_rot_cw_to_doc", "_apply_geom_rotate_cw_to_doc"], doc)
                if not called:
                    raise RuntimeError("No rotate-cw apply method found")
                self._log(f"Rotate 90Â deg CW applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Rotate 90Â deg CW", str(e))
            return

        if cid == "geom_rotate_counterclockwise":
            try:
                called = _call_any(["_apply_geom_rot_ccw_to_doc", "_apply_geom_rotate_ccw_to_doc"], doc)
                if not called:
                    raise RuntimeError("No rotate-ccw apply method found")
                self._log(f"Rotate 90Â deg CCW applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Rotate 90Â deg CCW", str(e))
            return

        if cid == "geom_rotate_180":
            try:
                called = _call_any(["_apply_geom_rot_180_to_doc"], doc)
                if not called:
                    raise RuntimeError("No rotate-180 apply method found")
                self._log(f"Rotate 180Â deg applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Rotate 180Â deg", str(e))
            return

        if cid == "geom_rotate_any":
            try:
                angle = float(preset.get("angle_deg", preset.get("angle", 0.0)))
                called = _call_any(["_apply_geom_rot_any_to_doc"], doc, angle_deg=angle)
                if not called:
                    raise RuntimeError("No rotate-any apply method found")
                self._log(f"Rotate ({angle:g}°) applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Rotate...", str(e))
            return

        if cid == "geom_rescale":
            try:
                factor = float(preset.get("factor", 1.0))
                # support both names you've used
                called = _call_any(
                    ["_apply_rescale_preset_to_doc", "_apply_geom_rescale_to_doc"],
                    doc, {"factor": factor} if "_apply_rescale_preset_to_doc" in dir(self) else factor
                )
                if not called:
                    # last resort: try signature (doc, preset)
                    _call_any(["_apply_rescale_preset_to_doc"], doc, {"factor": factor})
                self._log(f"Rescale Ã--{factor:g} applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Rescale", str(e))
            return
        if cid == "geom_resize_canvas":
            try:
                width = int(preset.get("width", preset.get("new_w", 0)))
                height = int(preset.get("height", preset.get("new_h", 0)))
                anchor = str(preset.get("anchor", "center"))
                fill_value = float(preset.get("fill_value", 0.0))
                update_wcs = bool(preset.get("update_wcs", True))

                payload = {
                    "width": width,
                    "height": height,
                    "new_w": width,
                    "new_h": height,
                    "anchor": anchor,
                    "fill_value": fill_value,
                    "update_wcs": update_wcs,
                }

                called = False

                if hasattr(self, "_apply_geom_resize_canvas_preset_to_doc"):
                    called = _call_any(
                        ["_apply_geom_resize_canvas_preset_to_doc"],
                        doc, payload
                    )

                if not called and hasattr(self, "_apply_geom_resize_canvas_to_doc"):
                    called = _call_any(
                        ["_apply_geom_resize_canvas_to_doc"],
                        doc,
                        new_w=width,
                        new_h=height,
                        anchor=anchor,
                        fill_value=fill_value,
                        update_wcs=update_wcs,
                    )

                if not called:
                    raise RuntimeError("No resize canvas handler found")

                self._log(
                    f"Resize Canvas applied to '{target_sw.windowTitle()}' "
                    f"({width}x{height}, anchor={anchor})"
                )
            except Exception as e:
                QMessageBox.warning(self, "Resize Canvas", str(e))
            return        
        if cid == "debayer":
            try:
                # Resolve a document from (a) the provided 'view' (DnD) or (b) the active subwindow.
                def _resolve_doc(v):
                    if v is None:
                        return None
                    # direct document?
                    if hasattr(v, "document"):
                        return v.document
                    # some wrappers expose a callable or attr named 'widget'
                    wattr = getattr(v, "widget", None)
                    if callable(wattr):
                        try:
                            w = wattr()
                            if hasattr(w, "document"):
                                return w.document
                        except Exception:
                            pass
                    elif wattr is not None and hasattr(wattr, "document"):
                        return wattr.document
                    # some subwindows use 'view' instead of 'widget'
                    vattr = getattr(v, "view", None)
                    if vattr is not None and hasattr(vattr, "document"):
                        return vattr.document
                    return None

                # 1) try the view passed by the shortcuts manager (DnD path)
                doc = _resolve_doc(view)

                # 2) fallback to active subwindow
                if doc is None:
                    sw = self.mdi.activeSubWindow()
                    doc = _resolve_doc(sw)

                if doc is None or getattr(doc, "image", None) is None:
                    QMessageBox.information(self, "Debayer", "No active image.")
                    return

                dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
                from setiastro.saspro.debayer import apply_debayer_preset_to_doc  # ensure imported
                pattern_used, _ = apply_debayer_preset_to_doc(dm, doc, preset or {})

                # get a friendly title for logs
                title = None
                dn = getattr(doc, "display_name", None)
                if callable(dn):
                    title = dn()
                if not title:
                    title = getattr(doc, "name", None) or getattr(doc, "title", None) or "Untitled"

                self._log(f"Applied Debayer ({pattern_used}) to '{title}'")
            except Exception as e:
                QMessageBox.warning(self, "Debayer failed", str(e))
            return   
        if cid == "image_combine":
            if target_sw is None:
                # Open the dialog (use preset defaults if present)
                self._open_image_combine()
                return
            # Dropped on a specific subwindow -> treat that doc as A, resolve B from preset/heuristics
            view = target_sw.widget()
            docA = getattr(view, "document", None)
            if docA is None or getattr(docA, "image", None) is None:
                QMessageBox.information(self, "Image Combine", "Target view has no image."); return
            try:
                p = dict(preset or {})
                p.setdefault("output", p.get("output", "replace"))   # default drop replaces A
                self._apply_image_combine_from_preset(p, target_doc=docA)
                return
            except Exception as e:
                QMessageBox.warning(self, "Image Combine", f"Preset apply failed:\n{e}")
                return
        if cid == "psf_viewer":
            # Open viewer; optional preset keys: threshold/mode/log/zoom
            try:
                self._open_psf_viewer(preset)
                self._log("Opened PSF Viewer" + (f" with preset {preset}" if preset else ""))
            except Exception as e:
                QMessageBox.warning(self, "PSF Viewer", f"Open failed:\n{e}")
            return            
        if cid == "plate_solve":
            doc = None
            if target_sw is not None:
                try:
                    doc = self._target_doc_from_subwindow(target_sw)
                except Exception:
                    doc = None
            if doc is None and hasattr(self, "_active_doc"):
                try:
                    doc = self._active_doc()
                except Exception:
                    doc = None
            if not doc or getattr(doc, "image", None) is None:
                QMessageBox.information(self, "Plate Solver", "No active image view.")
                return

            solver = str((preset or {}).get("solver") or (preset or {}).get("solver_pref") or "").lower()
            pref = solver or (self.settings.value("plate_solver/preference", "both", type=str) or "both").lower()
            if pref not in ("gaia_only", "astrometry_only"):
                astap_path = self.settings.value("paths/astap", "", type=str)
                if not astap_path or not os.path.exists(astap_path):
                    QMessageBox.information(
                        self, "Plate Solver",
                        "ASTAP executable not set. Go to Preferences -> ASTAP executable."
                    )
                    return

            try:
                hdr = self._apply_plate_solve_to_doc(doc, preset or {})
                h = hdr

                def _ff(x):
                    try: return float(x)
                    except Exception: return None

                ra  = _ff(h.get("CRVAL1")) if hasattr(h, "get") else None
                dec = _ff(h.get("CRVAL2")) if hasattr(h, "get") else None
                cd11 = _ff(h.get("CD1_1")) if hasattr(h, "get") else None
                cd21 = _ff(h.get("CD2_1")) if hasattr(h, "get") else None
                cd11 = cd11 if cd11 is not None else (_ff(h.get("CDELT1")) if hasattr(h, "get") else None)
                cd21 = cd21 if cd21 is not None else (_ff(h.get("CDELT2")) if hasattr(h, "get") else None)
                scale = None
                if cd11 is not None or cd21 is not None:
                    a = cd11 or 0.0; b = cd21 or 0.0
                    scale = (a*a + b*b) ** 0.5 * 3600.0

                msg = "Plate solve complete"
                if ra is not None and dec is not None:
                    msg += f" | RA={ra:.6f} deg, Dec={dec:.6f} deg"
                if scale is not None:
                    msg += f" | scale~{scale:.3f}\"/px"

                if hasattr(self, "_log"):
                    self._log(msg)
                else:
                    print(msg)
            except Exception as e:
                QMessageBox.warning(self, "Plate Solver", f"Plate solve failed:\n{e}")
            self._hdr_refresh_timer.start(0)
            return
        if cid == "star_align":
            # For alignment we need user choice of source/target, so open the dialog.
            # (We map DnD -> QAction via reg("star_align", self.act_star_align) already,
            # but keep this for parity with your explicit cid switch.)
            try:
                self._open_stellar_alignment()
            except Exception as e:
                QMessageBox.critical(self, "Stellar Alignment", f"Unhandled error:\n{e}")
            return
        if cid == "star_register":
            try:
                self._open_stellar_registration()
            except Exception as e:
                QMessageBox.critical(self, "Stellar Register", f"Unhandled error:\n{e}")
            return
        if cid == "image_peeker":
            doc = None
            if target_sw is not None:
                view = target_sw.widget()
                doc = getattr(view, "document", None)
            if doc is None and hasattr(self, "_active_doc"):
                doc = self._active_doc()
            if not doc or getattr(doc, "image", None) is None:
                QMessageBox.information(self, "Image Peeker", "No image in the dropped/active view.")
                return
            self._open_image_peeker_for_doc(doc, title_hint=getattr(target_sw, "windowTitle", lambda:"view")())
            return
        if cid == "star_spikes":
            doc = None
            if target_sw is not None:
                view = target_sw.widget()
                doc = getattr(view, "document", None)
            if doc is None and hasattr(self, "_active_doc"):
                # if you keep a helper; otherwise use docman.get_active_document()
                try:
                    doc = self._active_doc()
                except Exception:
                    pass
            if doc is None and hasattr(self, "docman"):
                doc = self.docman.get_active_document()
            if not doc or getattr(doc, "image", None) is None:
                QMessageBox.information(self, "Diffraction Spikes", "No image in the dropped/active view.")
                return
            self._open_star_spikes(doc=doc, preset=payload.get("preset") or {},
                                title_hint=getattr(target_sw, "windowTitle", lambda:"view")())
            return
        if cid == "multiscale_decomp":
            if doc is None or getattr(doc, "image", None) is None:
                QMessageBox.information(self, "Multiscale Decomposition", "Target view has no image.")
                return
            try:
                from setiastro.saspro.multiscale_decomp import apply_multiscale_decomp_headless
                apply_multiscale_decomp_headless(self, preset or {}, doc=doc)
                try:
                    self._last_headless_command = {
                        "command_id": "multiscale_decomp",
                        "preset": dict(preset or {}),
                    }
                except Exception:
                    pass
                self._log(f"Applied Multiscale Decomposition to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, "Multiscale Decomposition", f"Apply failed:\n{e}")
            return
        # ---------- Unknown cid with a doc: try a generic _apply_{cid}_to_doc  ----------
        generic = getattr(self, f"_apply_{cid}_to_doc", None)
        if callable(generic):
            try:
                # try passing preset if the method accepts it; otherwise call with (doc)
                try:
                    generic(doc, preset)
                except TypeError:
                    generic(doc)
                self._log(f"{cid} applied to '{target_sw.windowTitle()}'")
            except Exception as e:
                QMessageBox.warning(self, cid.replace("_", " ").title(), str(e))
            return

        # ---------- Final fallback: trigger the registered QAction on the target view ----------
        # Function-bundle steps for commands that don't have a dedicated HCD branch or
        # an _apply_{cid}_to_doc method (e.g. checkpoint_save, some project-level ops)
        # end up here. Activate the target subwindow so the action runs against the
        # right doc, then trigger the QAction like a normal menu/toolbar invocation.
        #
        # NB: we import QApplication locally because the function_bundle branch
        # above also has `from PyQt6.QtWidgets import QApplication`, which turns
        # QApplication into a function-local name for the entire method (Python
        # scoping rule). If we hit this fallback without going through that branch,
        # the module-level QApplication would raise UnboundLocalError.
        from PyQt6.QtWidgets import QApplication as _QApplication
        try:
            act = self._find_action_by_cid(cid)
        except Exception:
            act = None
        if act is not None:
            try:
                if target_sw is not None:
                    self.mdi.setActiveSubWindow(target_sw)
                    _QApplication.processEvents()
                act.trigger()
                try:
                    self._log(f"{cid} triggered on '{target_sw.windowTitle()}' (QAction fallback)")
                except Exception:
                    pass
            except Exception as e:
                try:
                    QMessageBox.warning(self, cid.replace("_", " ").title(), str(e))
                except Exception:
                    pass
            return

        # Truly unknown — log so we notice next time
        try:
            self._log(f"[HCD] unhandled command_id={cid!r} (no HCD branch, no _apply_*_to_doc, no QAction)")
        except Exception:
            pass

    def _find_action_by_cid(self, cid: str) -> QAction | None:
        if not cid:
            return None
        # We registered command ids on actions via register_action(...)
        for a in self.findChildren(QAction):
            if a.property("command_id") == cid or a.objectName() == cid:
                return a
        return None

    def _find_doc_by_id(self, doc_ptr):
        if doc_ptr is None:
            return None, None
        for sw in self.mdi.subWindowList():
            w = sw.widget()
            d = getattr(w, "document", None)
            if d is not None and id(d) == doc_ptr:
                return d, sw
        return None, None

    # in AstroSuiteProMainWindow (or wherever your drop handlers are)
    def _resolve_doc_from_payload(self, payload: dict, *, prefer_base: bool = True):
        dm = getattr(self, "docman", None) or getattr(self, "doc_manager", None)
        if dm is None:
            return None

        # Try base_doc_uid first when prefer_base is set
        if prefer_base:
            base_uid = (payload.get("base_doc_uid") or "").strip()
            if base_uid:
                d = dm._by_uid.get(base_uid)
                if d is not None:
                    return d

        # Then the doc's own uid
        doc_uid = (payload.get("doc_uid") or "").strip()
        if doc_uid:
            d = dm._by_uid.get(doc_uid)
            if d is not None:
                return d

        # Normalize pointer across all drag types
        raw_ptr = (
            payload.get("mask_doc_ptr")
            or payload.get("wcs_from_doc_ptr")
            or payload.get("doc_ptr")
        )

        # Scan subwindows by id() — catches DocProxy objects which live in
        # subwindows but are not registered in dm._docs or dm._by_uid
        if raw_ptr is not None:
            ptr = int(raw_ptr)
            for sw in self.mdi.subWindowList():
                try:
                    w = sw.widget()
                except RuntimeError:
                    continue
                d = getattr(w, "document", None)
                if d is not None and id(d) == ptr:
                    return d

        # Final fallback through canonical resolver (file_path match)
        fpath = (payload.get("file_path") or "").strip()
        if fpath:
            return dm.resolve_doc_from_drag(uid=None, doc_ptr=None, file_path=fpath)

        return None

    def _target_doc_from_subwindow(self, subwin) -> object | None:
        """
        Resolve the *base* target document for a QMdiSubWindow.

        For ROI/preview-aware views, this prefers view.base_document so that
        "apply to base" operations don't accidentally hit the preview/proxy doc.
        """
        if subwin is None:
            return None

        w = subwin.widget()
        dm = getattr(self, "docman", None) or getattr(self, "doc_manager", None)

        # 0) NEW: prefer explicit base_document on the view
        base = getattr(w, "base_document", None)
        if base is not None:
            return base

        # 1) OLD behavior: ask DocManager (may return a proxy/ROI doc on older views)
        if dm and hasattr(dm, "get_document_for_view"):
            try:
                d = dm.get_document_for_view(w)
                if d is not None:
                    return d
            except Exception:
                pass

        # 2) Fallbacks
        if hasattr(w, "document"):
            return w.document

        if hasattr(self, "get_active_document"):
            try:
                return self.get_active_document()
            except Exception:
                pass

        return None

    def _apply_wcs_dict_to_doc(self, doc, wcs_dict: dict) -> bool:
        """
        Apply a WCS/SIP solution (flat dict of FITS cards) to an ImageDocument.

        CLEAN-SLATE semantics:
          - The incoming wcs_dict FULLY REPLACES any prior WCS/SIP solution.
          - Stale WCS/SIP cards are stripped from the acquisition header first.
          - wcs_header is rebuilt card-by-card from wcs_dict, never by
            re-parsing a serialized header string (no column drift possible).
          - original_header = acquisition (WCS-stripped) + fresh WCS/SIP.

        Used by CopyAstrometryDialog and Ctrl+drag/drop ASTROMETRY payloads.
        """
        if doc is None or not wcs_dict:
            return False

        from astropy.io import fits
        from astropy.wcs import WCS
        import numpy as _np
        import re as _re
        import sys

        print(f"[apply IN ] CRPIX1={wcs_dict.get('CRPIX1')!r}", file=sys.stderr)

        # ---- helpers ----------------------------------------------------
        def _is_wcs_or_sip_key(k) -> bool:
            K = str(k).upper()
            if K in ("NAXIS", "NAXIS1", "NAXIS2", "NAXIS3"):
                return False  # image geometry, not the solution — keep it
            if K in getattr(self, "_WCS_KEY_SET", set()):
                return True
            if K in ("RADECSYS", "EPOCH", "A_ORDER", "B_ORDER", "AP_ORDER", "BP_ORDER"):
                return True
            if _re.match(r"^(A|B|AP|BP)_\d+_\d+$", K):
                return True
            return False

        def _clean_val(v):
            # Repair a value that leaked its '=' separator / quotes upstream;
            # return a number when it clearly is one, else leave unchanged.
            if isinstance(v, (bool, int, float, _np.integer, _np.floating)) or v is None:
                return v.item() if hasattr(v, "item") else v
            s = str(v).strip()
            if (s.startswith("'") and s.endswith("'")) or (s.startswith('"') and s.endswith('"')):
                s = s[1:-1].strip()
            if s.startswith("="):
                s = s[1:].strip()
            try:
                return int(s) if _re.fullmatch(r"[+-]?\d+", s) else float(s)
            except Exception:
                return v

        def _hdr_from_any(raw) -> fits.Header:
            """Coerce any stored header form into a clean fits.Header. String
            blobs are parsed PER CARD, so a stray '\\n' can never drift the
            fixed-width column boundaries the way Header.fromstring does."""
            if raw is None:
                return fits.Header()
            if isinstance(raw, fits.Header):
                return raw.copy()
            if isinstance(raw, dict):
                fmt = raw.get("format")
                if fmt == "fits-cards" and isinstance(raw.get("cards"), list):
                    h = fits.Header()
                    for card in raw["cards"]:
                        try:
                            k = str(card[0]).strip()
                            if not k:
                                continue
                            c = str(card[2]) if len(card) > 2 else ""
                            h[k] = (_clean_val(card[1]), c)
                        except Exception:
                            continue
                    return h
                if fmt == "dict" and isinstance(raw.get("items"), dict):
                    h = fits.Header()
                    for k, v in raw["items"].items():
                        try:
                            h[str(k)] = _clean_val(v)
                        except Exception:
                            continue
                    return h
                h = fits.Header()
                for k, v in raw.items():
                    if k in ("format", "items", "cards", "text"):
                        continue
                    try:
                        h[str(k)] = _clean_val(v)
                    except Exception:
                        continue
                return h
            if isinstance(raw, str):
                s = raw.strip()
                if not s:
                    return fits.Header()
                if "\n" in s:  # tostring(sep='\n') / repr → parse line by line
                    h = fits.Header()
                    for line in s.split("\n"):
                        line = line.rstrip()
                        if not line or line.strip() == "END":
                            continue
                        try:
                            h.append(fits.Card.fromstring(line), end=True)
                        except Exception:
                            continue
                    return h
                try:
                    return fits.Header.fromstring(s)  # genuine 80-col blob, safe
                except Exception:
                    return fits.Header()
            return fits.Header()

        meta = getattr(doc, "metadata", {}) or {}

        # ---- 1) Acquisition header (prefer fits_header, else original) --
        acq = meta.get("fits_header")
        if not isinstance(acq, fits.Header):
            acq = _hdr_from_any(acq if acq is not None else meta.get("original_header"))

        # ---- 2) Strip ALL stale WCS/SIP cards ---------------------------
        acq_clean = fits.Header()
        for card in acq.cards:
            try:
                if card.keyword in ("", "COMMENT", "HISTORY"):
                    acq_clean.append(card, end=True)
                elif not _is_wcs_or_sip_key(card.keyword):
                    acq_clean.append(card, end=True)
            except Exception:
                continue

        # ---- 3) Build a FRESH wcs_header from the incoming dict ONLY -----
        w = self._coerce_wcs_numbers(dict(wcs_dict)) if hasattr(self, "_coerce_wcs_numbers") else dict(wcs_dict)
        wcs_hdr = fits.Header()
        for k, v in w.items():
            try:
                wcs_hdr[str(k).upper()] = _clean_val(v)
            except Exception:
                pass

        # ---- 4) Combine: acquisition (stripped) + fresh WCS -------------
        full_hdr = acq_clean.copy()
        for card in wcs_hdr.cards:
            try:
                full_hdr[card.keyword] = (card.value, card.comment)
            except Exception:
                pass

        # ---- 5) Solution flags -----------------------------------------
        try:
            full_hdr["HasAstrometricSolution"] = True
        except Exception:
            pass
        meta["HasAstrometricSolution"] = True

        # ---- 6) Mirror clean WCS into image_meta["WCS"] ----------------
        im = meta.get("image_meta")
        if not isinstance(im, dict):
            im = {}
        im["WCS"] = {str(k).upper(): _clean_val(v) for k, v in w.items()}
        meta["image_meta"] = im

        # ---- 7) Rebuild astropy WCS ------------------------------------
        try:
            meta["wcs"] = WCS(full_hdr)
        except Exception as e:
            try:
                import logging
                logging.getLogger(__name__).warning(
                    f"_apply_wcs_dict_to_doc: WCS(full_hdr) failed: {e}"
                )
            except Exception:
                pass
            meta.pop("wcs", None)

        # ---- 8) Store clean headers (all real fits.Header objects) ------
        meta["fits_header"]     = acq_clean
        meta["wcs_header"]      = wcs_hdr
        meta["original_header"] = full_hdr

        # ---- 9) Refresh JSON-safe snapshot so the dock shows clean data -
        meta.pop("__header_snapshot__", None)
        try:
            from setiastro.saspro.doc_manager import _snapshot_header_for_metadata
            _snapshot_header_for_metadata(meta)
        except Exception:
            pass

        doc.metadata = meta

        # ---- 10) Notify UI / listeners ---------------------------------
        if hasattr(doc, "changed"):
            try:
                doc.changed.emit()
            except Exception:
                pass
        if hasattr(self, "_refresh_header_viewer"):
            try:
                self._refresh_header_viewer(doc)
            except Exception:
                pass
        if hasattr(self, "currentDocumentChanged"):
            try:
                self.currentDocumentChanged.emit(doc)
            except Exception:
                pass

        print(f"[apply OUT] CRPIX1={(doc.metadata.get('wcs_header') or {}).get('CRPIX1', '<none>')!r}", file=sys.stderr)
        return True
    
    def _on_astrometry_drop(self, payload: dict, target_subwindow):
        """
        Handle MIME_ASTROMETRY drops. Copies WCS/SIP from the *base* source doc
        into the true target doc (base if a preview tab is active).
        """
        dm = getattr(self, "docman", None) or getattr(self, "doc_manager", None)
        if dm is None:
            QMessageBox.information(self, "Copy Astrometry", "No document manager.")
            return

        # 1) Resolve source (prefer base doc over preview/proxy)
        src_doc = self._resolve_doc_from_payload(payload, prefer_base=True)
        if src_doc is None:
            QMessageBox.information(self, "Copy Astrometry", "Source view not found.")
            return

        # 2) Resolve target (map preview tab -> ROI doc -> base doc as needed)
        tgt_doc = self._target_doc_from_subwindow(target_subwindow)
        if tgt_doc is None:
            QMessageBox.information(self, "Copy Astrometry", "No target image.")
            return

        # 3) Extract WCS dict from source
        if hasattr(self, "_extract_wcs_dict"):
            try:
                wcs = self._extract_wcs_dict(src_doc)
            except Exception:
                wcs = {}
        else:
            wcs = {}

        if not wcs:
            QMessageBox.information(self, "Copy Astrometry", "Source has no WCS/SIP solution.")
            return

        # 4) Apply to target
        ok = False
        if hasattr(self, "_apply_wcs_dict_to_doc"):
            try:
                ok = bool(self._apply_wcs_dict_to_doc(tgt_doc, dict(wcs)))
            except Exception:
                ok = False

        if not ok:
            QMessageBox.warning(self, "Copy Astrometry", "Failed to apply astrometric solution.")
            return

        # 5) Refresh UI bits immediately
        try:
            if hasattr(self, "_refresh_header_viewer"):
                self._refresh_header_viewer(tgt_doc)
            if hasattr(self, "currentDocumentChanged"):
                self.currentDocumentChanged.emit(tgt_doc)
        except Exception:
            pass

        try:
            sname = getattr(src_doc, "display_name", lambda: None)() or "Source"
            tname = getattr(tgt_doc, "display_name", lambda: None)() or "Target"
            QMessageBox.information(self, "Copy Astrometry",
                                    f"Copied solution from '{sname}' to '{tname}'.")
        except Exception:
            pass

    def _on_remove_pedestal(self):
        from setiastro.saspro.pedestal import open_remove_pedestal_dialog
        # Opens the live dialog on the active document (DocManager/MDI-resolved).
        # Apply + replay bookkeeping now happen inside the dialog.
        open_remove_pedestal_dialog(self)

    def _open_statistical_stretch_with_preset(self, preset: dict):
        """
        Open the Statistical Stretch dialog and prefill its controls from preset.
        """
        sw = self.mdi.activeSubWindow()
        if not sw:
            
            QMessageBox.information(self, "No image", "Open an image first.")
            return

        doc = sw.widget().document
        from setiastro.saspro.stat_stretch import StatisticalStretchDialog  # adjust import if needed

        dlg = StatisticalStretchDialog(self, doc)

        # prefill if keys exist (ignore missing keys gracefully)
        try:
            if "target_median" in preset:
                dlg.spin_target.setValue(float(preset["target_median"]))
            if "linked" in preset:
                dlg.chk_linked.setChecked(bool(preset["linked"]))
            if "normalize" in preset:
                dlg.chk_normalize.setChecked(bool(preset["normalize"]))
            if "apply_curves" in preset:
                dlg.chk_curves.setChecked(bool(preset["apply_curves"]))
            if "curves_boost" in preset:
                dlg.sld_curves.setValue(int(round(float(preset["curves_boost"]) * 100)))
        except Exception:
            pass  # never block the dialog if a value is off-type

        try:

            dlg.setWindowIcon(QIcon(statstretch_path))
        except Exception:
            pass

        dlg.resize(900, 600)
        dlg.show()


    def _apply_stat_stretch_preset_to_doc(self, doc, preset: dict):
        """Headless apply of Statistical Stretch to a SPECIFIC doc — synchronous
        and pinned to `doc` (no async job, no following the active view, no
        dialog/thread left hanging around)."""
        if getattr(self, "_stat_stretch_apply_in_progress", False):
            return
        self._stat_stretch_apply_in_progress = True
        dlg = None
        try:
            from setiastro.saspro.stat_stretch import StatisticalStretchDialog
            dlg = StatisticalStretchDialog(self, doc)
            dlg._headless = True   # don't follow active doc, don't save geometry

            try:
                if "target_median" in preset:
                    dlg.spin_target.setValue(float(preset["target_median"]))
                if "linked" in preset:
                    dlg.chk_linked.setChecked(bool(preset["linked"]))
                if "normalize" in preset:
                    dlg.chk_normalize.setChecked(bool(preset["normalize"]))
                if "apply_curves" in preset and hasattr(dlg, "chk_curves"):
                    dlg.chk_curves.setChecked(bool(preset["apply_curves"]))
                if "curves_boost" in preset and hasattr(dlg, "sld_curves"):
                    dlg.sld_curves.setValue(int(round(float(preset["curves_boost"]) * 100)))
            except Exception:
                pass

            # Compute + commit synchronously, bound to `doc`. No QThread means
            # nothing can change the active document out from under us.
            out = dlg._run_stretch()
            if out is not None:
                dlg._apply_out_to_doc(out)
        finally:
            self._stat_stretch_apply_in_progress = False
            try:
                if dlg is not None:
                    dlg.close()
                    dlg.deleteLater()
            except Exception:
                pass



    def _open_star_stretch_with_preset(self, preset: dict):
        from setiastro.saspro.star_stretch import StarStretchDialog
        """Background drop -> open Star Stretch dialog with controls preloaded."""
        sw = self.mdi.activeSubWindow()
        if not sw:
            QMessageBox.information(self, "Star Stretch", "No active image window.")
            return
        doc = sw.widget().document
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Star Stretch", "Active document has no image.")
            return

        dlg = StarStretchDialog(self, doc)

        # Accept synonyms, fall back to dialog defaults
        amt = preset.get("stretch_factor",
            preset.get("stretch_amount",
            preset.get("amount", None)))
        if amt is not None:
            try: dlg.sld_st.setValue(int(float(amt) * 100.0))
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

        sat = preset.get("color_boost", preset.get("saturation", None))
        if sat is not None:
            try: dlg.sld_sat.setValue(int(float(sat) * 100.0))
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

        scnr = preset.get("scnr_green", preset.get("scnr", None))
        if scnr is not None:
            try: dlg.chk_scnr.setChecked(bool(scnr))
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

        dlg.resize(1000, 650)
        dlg.show()
        if hasattr(self, "_log"):
            self._log("Star Stretch: opened dialog with preset.")

    def _apply_star_stretch_preset_to_doc(self, doc, preset: dict):
        """
        Drop on a specific subwindow -> apply Star Stretch headlessly to that doc.
        Uses your Numba kernel (applyPixelMath_numba). If unavailable, raises.
        """
        import numpy as np
        try:
            from setiastro.saspro.legacy.numba_utils import applyPixelMath_numba, applySCNR_numba
            _has_numba = True
        except Exception:
            _has_numba = False
            applyPixelMath_numba = None
            # lightweight SCNR fallback (same as in pro/star_stretch.py)
            def applySCNR_numba(image_array: np.ndarray) -> np.ndarray:
                img = image_array.astype(np.float32, copy=False)
                if img.ndim != 3 or img.shape[2] != 3:
                    return img
                r = img[..., 0]; g = img[..., 1]; b = img[..., 2]
                g2 = np.minimum(g, 0.5 * (r + b))
                out = img.copy()
                out[..., 1] = g2
                return np.clip(out, 0.0, 1.0)

        img = getattr(doc, "image", None)
        if img is None:
            raise RuntimeError("Document has no image.")

        # read preset (accept a few aliases)
        amount = float(preset.get("stretch_factor",
                preset.get("stretch_amount",
                preset.get("amount", 5.0))))  # 0..8
        sat    = float(preset.get("color_boost", preset.get("saturation", 1.0)))  # 0..2
        scnr   = bool(preset.get("scnr_green", preset.get("scnr", False)))

        # convert to float 0..1
        a = np.asarray(img)
        if a.dtype.kind in "ui":
            a = a.astype(np.float32) / float(np.iinfo(a.dtype).max)
        elif a.dtype.kind == "f":
            mx = float(a.max()) if a.size else 1.0
            a = a.astype(np.float32) / (mx if mx > 1.0 else 1.0)
        else:
            a = a.astype(np.float32)

        # mono -> 3ch temporarily
        need_collapse = False
        if a.ndim == 2:
            a = np.stack([a]*3, axis=-1); need_collapse = True
        elif a.ndim == 3 and a.shape[2] == 1:
            a = np.repeat(a, 3, axis=2); need_collapse = True

        if applyPixelMath_numba is None:
            raise RuntimeError("Star Stretch requires Numba kernel (applyPixelMath_numba) for headless run.")

        out = applyPixelMath_numba(a, amount)

        # color boost
        if out.ndim == 3 and out.shape[2] == 3 and abs(sat - 1.0) > 1e-6:
            mean = out.mean(axis=2, keepdims=True)
            out = mean + (out - mean) * sat
            out = np.clip(out, 0.0, 1.0)

        # SCNR
        if scnr and out.ndim == 3 and out.shape[2] == 3:
            out = applySCNR_numba(out.astype(np.float32, copy=False))

        if need_collapse:
            out = out[..., 0]

        meta = {
            "step_name": "Star Stretch",
            "command_id": "star_stretch",
            "preset": {
                "stretch_factor": amount,
                "color_boost": sat,
                "scnr_green": scnr,
            },
            "star_stretch": {
                "stretch_factor": amount,
                "color_boost": sat,
                "scnr_green": scnr,
                "numba": _has_numba,
            }
        }
        doc.apply_edit(out.astype(np.float32, copy=False), metadata=meta, step_name="Star Stretch")


    # --- Command Search (palette) ----------------------------------------
    def _strip_menu_text(self, s: str) -> str:
        return s.replace("&", "").replace("...", "").strip()

    # --- Command palette helpers (safe: no receivers/emit on Qt signals) ---

    def _is_action_commandy(self, act: QAction) -> bool:
        """Heuristic: action is a real, user-triggerable command."""
        if act is None:
            return False
        if act.isSeparator():
            return False
        # Exclude submenu containers -- we want leaf commands only
        if act.menu() is not None:
            return False
        # Text visible to users?
        txt = (act.text() or "").strip().replace("&", "")
        if not txt:
            return False
        # Optional heuristics:
        if not act.isEnabled():
            return False
        # Allow opt-out per action if you ever need it:
        if bool(act.property("cmdp_exclude")):
            return False
        return True

    def _collect_all_qactions(self) -> list[QAction]:
        """Gather every 'leaf' QAction from menubar + toolbars without using receivers()."""
        from PyQt6.QtWidgets import QToolBar, QMenu
        seen, out = set(), []

        # Menus: recurse into each top-level QMenu
        for top_act in self.menuBar().actions():
            m = top_act.menu()
            if m is None:
                # Top-level action without a submenu (rare) -- include if commandy
                if self._is_action_commandy(top_act) and id(top_act) not in seen:
                    out.append(top_act); seen.add(id(top_act))
                continue
            for act in self._iter_menu_actions(m):
                if self._is_action_commandy(act) and id(act) not in seen:
                    out.append(act); seen.add(id(act))

        # Toolbars
        for tb in self.findChildren(QToolBar):
            for act in tb.actions():
                if self._is_action_commandy(act) and id(act) not in seen:
                    out.append(act); seen.add(id(act))

        return out


    def _install_command_search(self):

        # Clean up any old placement (corner widget / toolbar / dock)
        mb = self.menuBar()
        mb.setNativeMenuBar(False)
        old = mb.cornerWidget(Qt.Corner.TopRightCorner)
        if old:
            old.deleteLater()
            mb.setCornerWidget(None, Qt.Corner.TopRightCorner)

        tb = getattr(self, "_search_tb", None)
        if tb:
            try: self.removeToolBar(tb)
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
            tb.deleteLater()
            self._search_tb = None

        old_dock = getattr(self, "_search_dock", None)
        if old_dock:
            try: old_dock.hide(); old_dock.setParent(None)
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
            old_dock.deleteLater()
            self._search_dock = None

        # --- Right-side mini dock with the search box ---
        self._search_dock = QDockWidget(self.tr("Command Search"), self)
        self._search_dock.setObjectName("CommandSearchDock")
        # âœ... Allow moving/closing like other panels
        self._search_dock.setAllowedAreas(
            Qt.DockWidgetArea.LeftDockWidgetArea |
            Qt.DockWidgetArea.RightDockWidgetArea |
            Qt.DockWidgetArea.TopDockWidgetArea |
            Qt.DockWidgetArea.BottomDockWidgetArea
        )
        self._search_dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetMovable |
            QDockWidget.DockWidgetFeature.DockWidgetClosable |
            QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )

        holder = QWidget(self._search_dock)
        lay = QHBoxLayout(holder)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(6)

        self._cmd_edit = QLineEdit(holder)
        self._cmd_edit.setPlaceholderText("Search commands...  (Ctrl+Shift+P)")
        self._cmd_edit.setClearButtonEnabled(True)
        self._cmd_edit.setMinimumWidth(240)
        self._cmd_edit.setMaximumWidth(700)
        self._cmd_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        lay.addWidget(self._cmd_edit, 1)

        holder.setMaximumHeight(44)  # keep the dock short
        self._search_dock.setWidget(holder)

        # Add to the RIGHT area
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self._search_dock)

        # Make sure it's ABOVE Layers/Header
        layers_dock = getattr(self, "layers_dock", None) or getattr(self, "_layers_dock", None)
        header_dock = getattr(self, "header_dock", None) or getattr(self, "_header_viewer_dock", None)
        try:
            if layers_dock:
                # split so Layers goes BELOW search
                self.splitDockWidget(self._search_dock, layers_dock, Qt.Orientation.Vertical)
            if header_dock and layers_dock:
                # keep header under layers (or whatever arrangement you prefer)
                # If you tabify layers/header, comment the line below and use tabifyDockWidget
                self.splitDockWidget(layers_dock, header_dock, Qt.Orientation.Vertical)
        except Exception:
            pass

        # ---- Completer + model (same behavior as before) ----
        self._cmd_model = QStandardItemModel(self)
        self._cmd_completer = QCompleter(self._cmd_model, self)
        self._cmd_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._cmd_completer.setFilterMode(Qt.MatchFlag.MatchContains)

        popup = QListView(self)
        popup.setMinimumWidth(420)
        popup.setIconSize(QSize(18, 18))
        self._cmd_completer.setPopup(popup)

        self._cmd_edit.setCompleter(self._cmd_completer)
        self._cmd_completer.activated[QModelIndex].connect(self._run_selected_completion)

        # Shortcut to focus it
        QShortcut(QKeySequence("Ctrl+Shift+P"), self, activated=self._focus_command_search)


        # Enter runs the matched / highlighted completion (not blindly row 0)
        self._cmd_edit.returnPressed.connect(self._trigger_first_visible_completion)

        # Initial population
        self._build_command_model()

        # After window state restore, re-pin it to the top of the right area
        if not self.settings.value("window_layout/restored", False, type=bool):
            try:
                layers_dock = getattr(self, "layers_dock", None) or getattr(self, "_layers_dock", None)
                header_dock = getattr(self, "header_dock", None) or getattr(self, "_header_viewer_dock", None)
                if layers_dock:
                    self.splitDockWidget(self._search_dock, layers_dock, Qt.Orientation.Vertical)
                if header_dock and layers_dock:
                    self.splitDockWidget(layers_dock, header_dock, Qt.Orientation.Vertical)
            except Exception:
                pass



    def _build_command_model(self):
        self._cmd_model.clear()
        self._cmd_model.setColumnCount(1)

        actions = self._collect_all_qactions()
        actions.sort(key=lambda a: self._strip_menu_text(a.text()).lower())

        for act in actions:
            title = self._strip_menu_text(act.text())
            if not title:
                continue
            item = QStandardItem(act.icon(), title)
            item.setEditable(False)
            item.setData(act, _ROLE_ACTION)
            self._cmd_model.appendRow(item)

        self._cmd_completer.setCompletionColumn(0)
        self._cmd_completer.popup().setModelColumn(0)

    def _run_selected_completion(self, index: QModelIndex):
        if index.isValid():
            act = index.data(_ROLE_ACTION)
            if isinstance(act, QAction) and act.isEnabled():
                act.trigger()

    def _trigger_first_visible_completion(self):
        """Run exact edit-text match, else highlighted popup row, else first filter hit."""
        text = (self._cmd_edit.text() or "").strip()
        if text:
            needle = text.casefold()
            for row in range(self._cmd_model.rowCount()):
                idx = self._cmd_model.index(row, 0)
                title = (idx.data(Qt.ItemDataRole.DisplayRole) or "").strip()
                if title.casefold() == needle:
                    self._run_selected_completion(idx)
                    return
        
        popup = self._cmd_completer.popup()
        if popup is not None and popup.isVisible():
            cur = popup.currentIndex()
            if cur.isValid():
                self._run_selected_completion(cur)
                return

        m = popup.model() if popup is not None else None
        if m is None:
            m = self._cmd_completer.completionModel()
        if m and m.rowCount() > 0:
            self._run_selected_completion(m.index(0, 0))

    def _focus_command_search(self):
        self._cmd_edit.setFocus(Qt.FocusReason.ShortcutFocusReason)
        self._cmd_edit.selectAll()

    # --- Actions ----------------------------------------
    def set_document(self, doc):
        self._doc = doc
        if doc is None:
            self._clear()                      # <- must fully clear visible content
            self.setWindowTitle("Header (No image)")
            return
        self._populate_from(doc)
        self.setWindowTitle("Header")

    # --- Helpers ---
    def _remember_active_pair(self, new_sw):
        """Remember last and current active subwindow so we can â€˜bounce'."""
        if new_sw is None:
            return
        if new_sw is self._current_active_sw:
            return
        # only remember last if it still exists
        if self._current_active_sw in self.mdi.subWindowList():
            self._last_active_sw = self._current_active_sw
        else:
            self._last_active_sw = None
        self._current_active_sw = new_sw

    def _toggle_last_active_view(self):
        last = getattr(self, "_last_active_sw", None)
        if not last or last not in self.mdi.subWindowList() or not last.isVisible():
            return  # nothing to bounce to
        self.mdi.setActiveSubWindow(last)

    # In AstroSuiteProMainWindow
    def _on_image_region_updated_global(self, doc, roi_tuple_or_none):
        def _roi_intersects(a, b):
            ax, ay, aw, ah = map(int, a)
            bx, by, bw, bh = map(int, b)
            if aw <= 0 or ah <= 0 or bw <= 0 or bh <= 0:
                return False
            return not (ax+aw <= bx or bx+bw <= ax or ay+ah <= by or by+bh <= ay)

        for sw in self.mdi.subWindowList():
            view = getattr(sw, "widget", lambda: None)()
            if view is None:
                continue
            base = getattr(view, "base_document", None) or getattr(view, "document", None)
            if base is not doc:
                continue
            if not (hasattr(view, "has_active_preview") and view.has_active_preview()):
                if hasattr(view, "refresh_from_docman"):
                    view.refresh_from_docman()
                continue
            try:
                my_roi = view.current_preview_roi()
            except Exception:
                my_roi = None
            if my_roi is None or roi_tuple_or_none is None or _roi_intersects(my_roi, roi_tuple_or_none):
                if hasattr(view, "refresh_from_docman"):
                    view.refresh_from_docman()

    def _hook_preview_awareness(self, view):
        def _on_any_preview_change(*_):
            try:
                dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
                if dm and hasattr(dm, "get_document_for_view"):
                    resolved = dm.get_document_for_view(view)
                    if hasattr(dm, "set_active_document"):
                        dm.set_active_document(resolved)
            except Exception:
                pass
            try: self._schedule_undo_redo_label_refresh()
            except Exception: pass
            try: self._refresh_mask_action_states()
            except Exception: pass
            try:
                if hasattr(self, "_hdr_refresh_timer"):
                    self._hdr_refresh_timer.start(0)
            except Exception: pass

        # Connect to the tab widget directly — this is the only signal we need
        try:
            tabs = getattr(view, "_tabs", None)
            if tabs is not None:
                tabs.currentChanged.connect(_on_any_preview_change)
        except Exception:
            pass

    def _pretty_title(self, doc, *, linked: bool | None = None) -> str:
        md = (getattr(doc, "metadata", {}) or {})

        # ✅ 1) Prefer explicit display_name (what duplicate/rename intends)
        name = (md.get("display_name") or "").strip()

        # 2) Fallback to file_path (but only if display_name is missing)
        if not name:
            fp = (md.get("file_path") or "").strip()
            if fp:
                name = os.path.splitext(os.path.basename(fp))[0]

        # 3) Fallback to doc.display_name()
        if not name:
            name = getattr(doc, "display_name", lambda: "Untitled")()
            name = (name or "Untitled").replace("[LINK] ", "").strip()

            # If it looks like a filename, drop extension
            base, ext = os.path.splitext(name)
            if ext and len(ext) <= 10:
                name = base

        # linked marker logic
        if linked is None:
            linked = hasattr(doc, "_parent_doc")
        return f"[LINK] {name}" if linked else name


    def _build_subwindow_title_for_doc(self, doc) -> str:
        """
        Build a unique, human-friendly title for a QMdiSubWindow
        that shows this document. If multiple views exist for the
        same doc, append [View N].

        IMPORTANT: This is called *after* the new subwindow has been
        added to the QMdiArea, so the first view will already give
        count == 1.
        """
        # Base label (reuse pretty_title logic, but keep it unlinked
        # like your old _spawn_subwindow_for did)
        base = self._pretty_title(doc, linked=False)

        # Count how many existing views show this *same* doc
        count = 0
        try:
            for sw in self.mdi.subWindowList():
                w = sw.widget() if hasattr(sw, "widget") else None
                if w is None:
                    continue
                # For image views we have base_document; for others fall back
                d = getattr(w, "base_document", None) or getattr(w, "document", None)
                if d is doc:
                    count += 1
        except Exception:
            pass

        # If this is the only view (count == 1), or something weird (0),
        # just show the base title with no [View N] suffix.
        if count <= 1:
            return base

        # Subsequent views -> base + [View N], where N == count
        return f"{base} [View {count}]"

    def _unique_window_title(self, base: str) -> str:
        """
        Return a window title based on `base` that is not already used by
        any QMdiSubWindow. If `base` is free, use it; otherwise append
        ' [View N]' with the first free N.
        """
        base = (base or "Untitled").strip()

        existing = set()
        try:
            for sw in self.mdi.subWindowList():
                if sw is None:
                    continue
                t = sw.windowTitle() or ""
                if t:
                    existing.add(t)
        except Exception:
            pass

        # First use: plain base
        if base not in existing:
            return base

        # Subsequent uses: base [View 2], [View 3], ...
        n = 2
        while True:
            cand = f"{base} [View {n}]"
            if cand not in existing:
                return cand
            n += 1

    
    def _doc_window_title(self, doc) -> str:
        md = getattr(doc, "metadata", {}) or {}

        t = (md.get("display_name") or "").strip()
        if not t:
            try:
                t = (doc.display_name() or "").strip()
            except Exception:
                t = ""

        if not t:
            fp = (md.get("file_path") or "").strip()
            if fp:
                t = os.path.splitext(os.path.basename(fp))[0]   # ✅ strip ext here too

        t = t or "Untitled"

        # strip glyphs etc
        try:
            t = _strip_ui_decorations(t)
        except Exception:
            pass

        # ✅ ALWAYS strip filename-like extension at the very end
        t = _strip_filename_ext(t)

        return t

    def _mdi_begin_open_batch(self, mode: str = "cascade"):
        self._mdi_open_batch += 1
        self._mdi_place_mode = mode or "cascade"
        self._mdi_next_pos = None

    def _mdi_end_open_batch(self):
        self._mdi_open_batch = max(0, self._mdi_open_batch - 1)
        if self._mdi_open_batch == 0:
            self._mdi_next_pos = None

    def _mdi_compute_initial_pos(self) -> QPoint:
        area = (self.mdi.viewport().geometry() if self.mdi.viewport() else self.mdi.contentsRect())
        # Put first window a bit inset so titlebars don’t clip
        return QPoint(area.left() + 18, area.top() + 18)

    def _mdi_place_subwindow(self, sw, target_w: int, target_h: int):
        """Deterministic placement. Uses a stable cursor during batch opens."""
        vp = self.mdi.viewport()
        area = vp.geometry() if vp else self.mdi.contentsRect()

        if self._mdi_next_pos is None:
            self._mdi_next_pos = self._mdi_compute_initial_pos()

        x = self._mdi_next_pos.x()
        y = self._mdi_next_pos.y()

        # keep inside viewport; reset when we hit edge
        if (x + target_w > area.right() - 10) or (y + 40 > area.bottom() - 10):
            x = area.left() + 18
            y = area.top() + 18

        sw.move(x, y)

        # advance cursor
        step = int(self._mdi_cascade_step)
        self._mdi_next_pos = QPoint(x + step, y + step)

    def _spawn_subwindow_for(self, doc, *, force_new: bool = False):
        """
        Open a subwindow for `doc`. If one already exists and force_new=False,
        simply raise/show the existing one. If force_new=True, always spawn a
        brand-new view (useful for 'duplicate view' drops on the MDI background).
        """
        # -- 0) Reuse existing unless caller explicitly wants a new one
        if not force_new:
            existing = self._find_subwindow_for_doc(doc)
            if existing:
                try:
                    # ensure really visible and focused
                    existing.show()
                    wst = existing.windowState()
                    if wst & Qt.WindowState.WindowMinimized:
                        existing.setWindowState(wst & ~Qt.WindowState.WindowMinimized)
                    self.mdi.setActiveSubWindow(existing)
                    existing.raise_()
                except Exception:
                    pass
                return existing

        # Track whether there were any visible subwindows before we add this one
        first_window = False
        try:
            subs = [s for s in self.mdi.subWindowList() if s.isVisible()]
            first_window = (len(subs) == 0)
        except Exception:
            # be conservative on error - just don't special-case it
            first_window = False

        # -- 1) Import view classes
        try:
            from setiastro.saspro.subwindow import ImageSubWindow, TableSubWindow
        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            QMessageBox.critical(self, "View Import Error",
                                f"Failed to import view classes from setiastro.saspro.subwindow:\n{e}\n\n{tb}")
            from PyQt6.QtWidgets import QLabel
            w = QLabel(doc.display_name()); setattr(w, "document", doc)
            wrapper = self.mdi.addSubWindow(w)
            wrapper.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
            wrapper.show()
            return wrapper

        # -- 2) Table vs Image detection (unchanged)
        md = (getattr(doc, "metadata", {}) or {})
        is_table = (md.get("doc_type") == "table") or (hasattr(doc, "rows") and hasattr(doc, "headers"))

        # -- 3) Construct the view (log all errors, fall back to label)
        try:
            view = TableSubWindow(doc) if is_table else ImageSubWindow(doc)
        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            try:
                self._log(f"[spawn] View construction failed: {e}\n{tb}")
            except Exception:
                pass
            from PyQt6.QtWidgets import QLabel
            view = QLabel(doc.display_name()); setattr(view, "document", doc)

        # -- 4) DocManager wiring (prefer self.doc_manager, fall back to self.docman)
        dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
        if hasattr(view, "set_doc_manager") and dm is not None:
            try:
                view.set_doc_manager(dm)
            except Exception:
                pass

        # -- 5) ROI-aware proxy: keep base handle, expose live proxy at view.document
        try:
            setattr(view, "base_document", doc)  # explicit base (non-ROI) doc
            if dm is not None:
                view.document = _DocProxy(dm, view, doc)
            else:
                setattr(view, "document", doc)
        except Exception as e:
            print(f"Failed to install DocProxy: {e}")
            try:
                self._log(f"[spawn] Failed to install DocProxy: {e}")
            except Exception:
                pass
            try:
                setattr(view, "document", doc)
            except Exception:
                pass

        # ðŸ"-- REPLAY: connect ImageSubWindow -> MainWindow (support old + new signal names)
        replay_sig = None
        sig_name_used = None
        for name in ("replayOnBaseRequested", "replayLastRequested"):
            s = getattr(view, name, None)
            if s is not None:
                replay_sig = s
                sig_name_used = name
                break

        if replay_sig is not None:
            try:
                replay_sig.connect(self._on_view_replay_last_requested)

            except Exception as e:
                try:
                    self._log(f"[Replay] FAILED to connect {sig_name_used} for view id={id(view)}: {e}")
                except Exception:
                    print(f"[Replay] FAILED to connect {sig_name_used} for view id={id(view)}: {e}")

        self._hook_preview_awareness(view)

        base_title  = self._doc_window_title(doc)      # ✅ use metadata display_name
        final_title = self._unique_window_title(base_title)

        # -- 6) Add subwindow and set chrome
        sw = self.mdi.addSubWindow(view)
        sw.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        if hasattr(view, "resized"):
            view.resized.connect(self._on_view_resized)
        sw.setWindowIcon(self.app_icon)
        sw.setWindowTitle(final_title)

        # Apply standard window flags
        flags = sw.windowFlags()
        flags |= Qt.WindowType.WindowCloseButtonHint
        flags |= Qt.WindowType.WindowMinimizeButtonHint
        flags |= Qt.WindowType.WindowMaximizeButtonHint
        sw.setWindowFlags(flags)

        # -------------------------------------------------------------------------
        # Explicitly size the window to valid dimensions so it doesn't default
        # to "maximized" or "full MDI area" if the previous window was large.
        # We target ~60% of the viewport height, clamped to sane bounds.
        # -------------------------------------------------------------------------
        vp = self.mdi.viewport()
        # Use viewport geometry in MDI coordinates (NOT viewport-local rect)
        area = vp.geometry() if vp else self.mdi.contentsRect()
        
        # Determine aspect ratio
        img_w = img_h = None
        try:
            img_w, img_h = self._infer_image_size(view)
        except Exception:
            pass

        if not img_w or not img_h:
            aspect = 1.0
        else:
            aspect = float(img_w) / float(img_h)

        # Clamp aspect
        aspect = max(0.3, min(aspect, 4.0))

        target_h = int(area.height() * 0.6)
        target_w = int(target_h * aspect)
        
        # Ensure it fits within the area (with some margin)
        max_w = int(area.width() * 0.9)
        max_h = int(area.height() * 0.9)
        
        if target_w > max_w:
            target_w = max_w
            # Recalculate height to preserve aspect, if possible
            target_h = int(target_w / aspect)
        
        if target_h > max_h:
            target_h = max_h

        # Enforce minimums
        target_w = max(200, target_w)
        target_h = max(200, target_h)

        sw.resize(target_w, target_h)
        sw.showNormal()  # clears any "maximized" flag from previous active window

        # Deterministic placement (batch-aware)
        try:
            self._mdi_place_subwindow(sw, target_w, target_h)
        except Exception:
            # absolute fallback: top-left-ish
            try:
                sw.move(area.left() + 18, area.top() + 18)
            except Exception:
                pass

        # Show / activate
        sw.show()
        sw.raise_()
        self.mdi.setActiveSubWindow(sw)

        # Optional minimize/restore interceptor
        if hasattr(self, "_minimize_interceptor"):
            try:
                sw.installEventFilter(self._minimize_interceptor)
            except Exception:
                pass

        # Shelf cleanup on destroy
        try:
            sw.destroyed.connect(
                lambda _=None, s=sw:
                hasattr(self, "window_shelf") and self.window_shelf.remove_for_subwindow(s)
            )
        except Exception:
            pass

        # Close handling hooks
        if hasattr(view, "aboutToClose"):
            try:
                # avoid accidental double connections if respawned
                try:
                    view.aboutToClose.disconnect()
                except Exception:
                    pass
                # forward the *base* doc to the slot
                view.aboutToClose.connect(lambda _=None, d=doc, v=view: self._on_view_about_to_close(d, sender_view=v))
            except Exception:
                pass
        else:
            # Worst-case fallback: if the view doesn't expose aboutToClose, use destroyed
            try:
                import weakref
                self_ref = weakref.ref(self)
                sw.destroyed.connect(
                    lambda _=None, d=doc, v=view, self_ref=self_ref: (
                        self_ref() is not None and
                        not getattr(self_ref(), "_shutting_down", False) and
                        self_ref()._on_view_about_to_close(d, sender_view=v)
                    )
                )
            except Exception:
                pass

        # Keep undo/redo labels in sync
        try:
            doc.changed.connect(self.update_undo_redo_action_labels)
        except Exception:
            pass

        # -- 7) Initial sizing + scale
        if is_table:
            # Tables still get a reasonable fixed size
            sw.resize(1000, 700)
        else:
            # Image docs: just do a one-time fit-to-window into whatever
            # geometry Qt gave this subwindow. This avoids hard 900x700 boxes.
            try:
                if self.mdi.activeSubWindow() is not sw:
                    self.mdi.setActiveSubWindow(sw)
                self._zoom_active_fit()
            except Exception:
                pass

        # -- 8) Sync autostretch UI state
        if hasattr(view, "autostretch_enabled"):
            try:
                self._sync_autostretch_action(view.autostretch_enabled)
            except Exception:
                pass

        # -- 9) View-level duplicate signal -> route to handler
        if hasattr(view, "requestDuplicate"):
            try:
                view.requestDuplicate.connect(self._duplicate_view_from_signal)
            except Exception:
                pass

        # -- 10) Log if image missing (non-table)
        if not is_table and getattr(doc, "image", None) is None:
            try:
                self._log(f"[spawn] No image and not recognized as table; metadata keys: "
                        f"{list((getattr(doc,'metadata',{}) or {}).keys())}")
            except Exception:
                pass

        # activate hook
        try:
            self._on_subwindow_activated(sw)
        except Exception:
            pass

        try:
            self._fix_mdi_titlebar_emboss("#dcdcdc" if self._theme_mode()=="dark" else "#f0f0f0")
        except Exception:
            pass

        try:
            drop_pos = getattr(self, "_pending_spawn_cursor_pos", None)
            if drop_pos is not None and sw is not None and force_new:
                mdi_pos = self.mdi.mapFromGlobal(drop_pos)
                sw.move(max(0, mdi_pos.x() - sw.width() // 2),
                        max(0, mdi_pos.y() - 16))
            self._pending_spawn_cursor_pos = None
        except Exception:
            pass
        return sw

    def _activate_neighbor_on_close(self, closing_sw):
        try:
            all_subs = [sw for sw in self.mdi.subWindowList() if sw.isVisible()]
            neighbors = [sw for sw in all_subs if sw is not closing_sw]
            if not neighbors:
                return

            try:
                idx = all_subs.index(closing_sw)
            except ValueError:
                QTimer.singleShot(0, lambda sw=neighbors[-1]: self._safe_activate_sw(sw))
                return

            # Prefer the one that slides into this slot (idx),
            # fall back to the one just before (idx-1) if we were last
            if idx < len(neighbors):
                candidate = neighbors[idx]
            else:
                candidate = neighbors[idx - 1]

            QTimer.singleShot(0, lambda sw=candidate: self._safe_activate_sw(sw))
        except Exception:
            pass

    def _safe_activate_sw(self, sw):
        try:
            from PyQt6 import sip
            if sip.isdeleted(sw):
                return
        except Exception:
            pass
        try:
            self.mdi.setActiveSubWindow(sw)
            sw.activateWindow()
            sw.setFocus()
        except Exception:
            pass

    def _on_view_about_to_close(self, doc, sender_view=None):
        try:
            from PyQt6.QtWidgets import QApplication
            app = QApplication.instance()
            if app is None or app.closingDown():
                return
        except Exception:
            return
        if getattr(self, "_shutting_down", False):
            return

        base = self._normalize_base_doc(doc)
        if base is None:
            return

        # --- Find the closing subwindow and schedule neighbor activation ---
        closing_sw = None
        try:
            for sw in self.mdi.subWindowList():
                try:
                    w = sw.widget()
                except RuntimeError:
                    continue
                if sender_view is not None and w is sender_view:
                    closing_sw = sw
                    break
                if sender_view is None and getattr(w, "base_document", None) is base:
                    closing_sw = sw
                    break
        except Exception:
            pass

        if closing_sw is not None:
            self._activate_neighbor_on_close(closing_sw)
        # --- end neighbor activation ---

        still_open = []
        try:
            for sw in self.mdi.subWindowList():
                try:
                    w = sw.widget()
                except RuntimeError:
                    continue
                if getattr(w, "base_document", None) is base:
                    if sender_view is not None and w is sender_view:
                        continue
                    still_open.append(sw)
        except Exception:
            return

        if not still_open:
            try:
                self.docman.close_document(base)
                if hasattr(self, "_log"):
                    self._log(f"Closed: {base.display_name()}")
            except Exception:
                pass

        try:
            QTimer.singleShot(0, self._maybe_clear_ui_after_close)
        except Exception:
            pass

    def _maybe_clear_ui_after_close(self):
        from setiastro.saspro.header_viewer import HeaderViewerDock
        # If no subwindows remain, clear all "active doc" UI bits, including header
        if not self.mdi.subWindowList():
            self.currentDocumentChanged.emit(None)   # drives HeaderViewerDock.set_document(None)
            self._schedule_undo_redo_label_refresh()
            self._hdr_refresh_timer.start(0)       # belt-and-suspenders for manual widgets
            # If your dock has its own set_document, call it explicitly too
            hv = getattr(self, "header_viewer", None)
            if hv and hasattr(hv, "set_document"):
                try:
                    hv.set_document(None)
                except Exception:
                    pass

    def _duplicate_view_from_signal(self, source_view):
        print("Duplicating view from signal...")
        from PyQt6.QtCore import QTimer

        doc = getattr(source_view, "document", None)
        if doc is None:
            return

        base_doc = getattr(source_view, "base_document", None)
        if base_doc is None:
            try:
                base_doc = doc._target()
            except Exception:
                base_doc = doc

        if getattr(base_doc, "image", None) is None:
            return

        # ── NEW: if a preview tab is active, duplicate the ROI doc's current
        #         edited image rather than the pristine base document ──────────
        source_doc_for_dup = base_doc
        extra_name_hint = None
        if getattr(source_view, "has_active_preview", lambda: False)():
            dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
            if dm is not None:
                try:
                    roi_doc = dm.get_document_for_view(source_view)
                    if roi_doc is not None and getattr(roi_doc, "image", None) is not None:
                        source_doc_for_dup = roi_doc
                        extra_name_hint = source_view.current_preview_name()
                except Exception:
                    pass
        # ──────────────────────────────────────────────────────────────────────

        # Capture source view state
        hbar = source_view.scroll.horizontalScrollBar()
        vbar = source_view.scroll.verticalScrollBar()
        state = {
            "scale": float(getattr(source_view, "scale", 1.0)),
            "hval": int(hbar.value()),
            "vval": int(vbar.value()),
            "autostretch": bool(getattr(source_view, "autostretch_enabled", False)),
            "autostretch_target": float(getattr(source_view, "autostretch_target", 0.25)),
        }

        try:
            base_name = self._doc_window_title(base_doc)
        except Exception:
            base_name = "Untitled"
        try:
            base_name = normalize_doc_title(base_name)
        except Exception:
            base_name = (base_name or "Untitled").strip()

        if extra_name_hint:
            try:
                base_name = f"{base_name}_{normalize_doc_title(extra_name_hint)}"
            except Exception:
                pass

        existing = set()
        try:
            dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
            docs = []
            if dm is not None:
                if hasattr(dm, "documents"):
                    docs = list(dm.documents())
                elif hasattr(dm, "_docs"):
                    docs = list(dm._docs)
            for d in docs:
                try:
                    md = getattr(d, "metadata", {}) or {}
                    dn = (md.get("display_name") or "").strip() or (d.display_name() or "").strip()
                    dn = normalize_doc_title(dn)
                    if dn:
                        existing.add(dn)
                except Exception:
                    pass
        except Exception:
            pass

        candidate = f"{base_name}_duplicate"
        if candidate in existing:
            n = 2
            while True:
                cand = f"{base_name}_duplicate{n}"
                if cand not in existing:
                    candidate = cand
                    break
                n += 1

        # Duplicate from the ROI doc (edited preview) or base doc
        new_doc = self.docman.duplicate_document(source_doc_for_dup, new_name=candidate)
        print(f"  Duplicated document ID {id(source_doc_for_dup)} -> {id(new_doc)}")

        # Clear masks on the duplicate
        try:
            mid = getattr(new_doc, "active_mask_id", None)
            if mid and hasattr(new_doc, "remove_mask"):
                new_doc.remove_mask(mid)
            if hasattr(new_doc, "masks") and getattr(new_doc, "masks", None):
                try:
                    new_doc.masks.clear()
                except Exception:
                    new_doc.masks = {}
            new_doc.active_mask_id = None
            if hasattr(new_doc, "changed"):
                new_doc.changed.emit()
        except Exception:
            try:
                new_doc.active_mask_id = None
                if hasattr(new_doc, "masks"):
                    new_doc.masks = {}
                if hasattr(new_doc, "changed"):
                    new_doc.changed.emit()
            except Exception:
                pass

        sw = self._spawn_subwindow_for(new_doc, force_new=True)
        print(f"  Spawned subwindow for duplicated document ID {id(new_doc)}")

        try:
            drop_pos = getattr(self, "_pending_spawn_cursor_pos", None)
            if drop_pos is not None and sw is not None:
                mdi_pos = self.mdi.mapFromGlobal(drop_pos)
                sw.move(max(0, mdi_pos.x() - sw.width() // 2),
                        max(0, mdi_pos.y() - 16))
            self._pending_spawn_cursor_pos = None
        except Exception:
            pass

        if not sw:
            def _retry_spawn():
                sw2 = self._spawn_subwindow_for(new_doc, force_new=True)
                if not sw2 and hasattr(self, "_log"):
                    self._log("[duplicate] failed to spawn subwindow for duplicated document")
            QTimer.singleShot(0, _retry_spawn)
            return

        view = sw.widget()
        if hasattr(view, "_mask_dot_enabled") and view._mask_dot_enabled:
            view._mask_dot_enabled = False
            try:
                view._rebuild_title()
            except Exception:
                t = getattr(view, "base_doc_title", lambda: new_doc.display_name())()
                sw.setWindowTitle(t)
                sw.setToolTip(t)

        try:
            self._apply_view_state_to_view(view, state)
        except Exception:
            pass

        self.mdi.setActiveSubWindow(sw)
        print(f"  Activated subwindow for duplicated document ID {id(new_doc)}")
        if hasattr(self, "_log"):
            self._log(f"Duplicated as independent document -> '{new_doc.display_name()}'")

    def _apply_view_state_to_view(self, view, state: dict):
        if not hasattr(view, "scroll"):
            return
        try:
            view.set_autostretch(state.get("autostretch", getattr(view, "autostretch_enabled", False)))
            view.set_autostretch_target(state.get("autostretch_target", getattr(view, "autostretch_target", 0.25)))
            view.set_scale(state.get("scale", getattr(view, "scale", 1.0)))
            QApplication.processEvents()
            view.scroll.horizontalScrollBar().setValue(int(state.get("hval", 0)))
            view.scroll.verticalScrollBar().setValue(int(state.get("vval", 0)))
        except Exception:
            pass


    def _apply_view_state_to_sub(self, state: dict, target_sw):
        view = target_sw.widget()
        if not hasattr(view, "scroll"):
            return
        view.set_autostretch(state.get("autostretch", getattr(view, "autostretch_enabled", False)))
        view.set_autostretch_target(state.get("autostretch_target", getattr(view, "autostretch_target", 0.25)))
        view.set_scale(state.get("scale", getattr(view, "scale", 1.0)))
        QApplication.processEvents()
        try:
            view.scroll.horizontalScrollBar().setValue(int(state.get("hval", 0)))
            view.scroll.verticalScrollBar().setValue(int(state.get("vval", 0)))
        except Exception:
            pass

        if hasattr(self, "_log"):
            self._log(f"Copied view state -> '{target_sw.windowTitle()}'")

    def _open_from_explorer(self, doc):
        # Route through the active method — this ensures shelf restore works correctly
        # if anything still calls this stale method
        for i in range(self.explorer.topLevelItemCount()):
            it = self.explorer.topLevelItem(i)
            if it.data(0, Qt.ItemDataRole.UserRole) is doc:
                self._activate_or_open_from_explorer(it)
                return
        # fallback if doc isn't in explorer yet
        self._spawn_subwindow_for(doc, force_new=False)

    def _activate_or_open_from_explorer(self, item):
        doc = item.data(0, Qt.ItemDataRole.UserRole)
        if doc is None:
            return

        shelf = getattr(self, "window_shelf", None)
        if shelf is not None:
            for i in range(shelf.list.count()):
                it = shelf.list.item(i)
                tok = it.data(Qt.ItemDataRole.UserRole)
                sub = shelf._tok2sub.get(tok)
                if sub is not None and not shelf._is_dead(sub):
                    w = sub.widget()
                    if w is not None and getattr(w, "base_document", None) is doc:
                        shelf.list.itemClicked.emit(it)
                        return

        sw = self._find_subwindow_for_doc(doc)
        if sw:
            self.mdi.setActiveSubWindow(sw)
            sw.show()
            sw.raise_()
            return

        try:
            self._open_subwindow_for_added_doc(doc)
        except Exception:
            pass

    def _set_linked_stretch_from_action(self, checked: bool):
        # persist as the default for *new* views
        self.settings.setValue("display/stretch_linked", bool(checked))

        # apply to the current view immediately (if any)
        sw = self.mdi.activeSubWindow()
        if not sw:
            return
        view = sw.widget()
        if hasattr(view, "set_autostretch_linked"):
            view.set_autostretch_linked(bool(checked))
            # If stretch is off, turn it on so the user sees the effect right away
            if not getattr(view, "autostretch_enabled", False):
                view.set_autostretch(True)
                self._sync_autostretch_action(True)

        self._log(f"Display-Stretch mode -> {'LINKED' if checked else 'UNLINKED'}")



    def _on_subwindow_activated(self, sw):
        # -- Clear previous active marker (guard dead wrappers)
        prev = getattr(self, "_last_active_view", None)
        if _is_alive(prev):
            try:
                # hasattr on dead wrappers can raise; gate with _is_alive first
                if hasattr(prev, "set_active_highlight"):
                    prev.set_active_highlight(False)
            except RuntimeError:
                pass
            except Exception:
                pass

        # -- Resolve the newly activated view safely
        new_view = _safe_widget(sw)
        if _is_alive(new_view):
            try:
                if hasattr(new_view, "set_active_highlight"):
                    new_view.set_active_highlight(True)
            except RuntimeError:
                pass
            except Exception:
                pass

        # Remember for next time (store None if dead/missing)
        self._last_active_view = new_view if _is_alive(new_view) else None

        # -- Safely pull the document and emit signal
        doc = None
        try:
            w = _safe_widget(sw)
            doc = w.document if _is_alive(w) and hasattr(w, "document") else None
        except RuntimeError:
            doc = None
        except Exception:
            doc = None

        try:
            self.currentDocumentChanged.emit(doc)
        except Exception:
            pass

        # Sync DocManager active, guarded
        try:
            self._sync_docman_active(doc)
        except Exception:
            pass

        # Toolbar/menu states
        try:
            if hasattr(self, "act_zoom_1_1"):
                self.act_zoom_1_1.setEnabled(bool(new_view))
        except Exception:
            pass

        # Autostretch checkbox reflect active view
        try:
            from PyQt6.QtCore import QSignalBlocker
            if hasattr(self, "act_autostretch"):
                block = QSignalBlocker(self.act_autostretch)
                if _is_alive(new_view) and hasattr(new_view, "autostretch_enabled"):
                    self.act_autostretch.setChecked(bool(getattr(new_view, "autostretch_enabled")))
                else:
                    self.act_autostretch.setChecked(False)
        except Exception:
            pass

        # Linked stretch action
        try:
            if hasattr(self, "act_stretch_linked"):
                if not _is_alive(new_view):
                    self.act_stretch_linked.setEnabled(False)
                else:
                    is_mono = False
                    try:
                        if hasattr(new_view, "is_mono"):
                            is_mono = bool(new_view.is_mono())
                    except Exception:
                        is_mono = False
                    self.act_stretch_linked.setEnabled(not is_mono)
                    if hasattr(new_view, "is_autostretch_linked"):
                        from PyQt6.QtCore import QSignalBlocker
                        with QSignalBlocker(self.act_stretch_linked):
                            try:
                                self.act_stretch_linked.setChecked(bool(new_view.is_autostretch_linked()))
                            except Exception:
                                self.act_stretch_linked.setChecked(False)
        except Exception:
            pass

        # Misc UI refreshes (guarded)
        try:
            self._schedule_undo_redo_label_refresh()
        except Exception:
            pass
        #try:
        #    if hasattr(self, "_hdr_refresh_timer") and self._hdr_refresh_timer is not None:
        #        self._hdr_refresh_timer.start(0)
        #except Exception:
        #    pass
        try:
            self._refresh_mask_action_states()
        except Exception:
            pass
        try:
            self._fix_mdi_titlebar_emboss("#dcdcdc" if self._theme_mode()=="dark" else "#f0f0f0")
        except Exception:
            pass

    def _sync_docman_active(self, doc):
        dm = self.doc_manager
        try:
            if hasattr(dm, "set_active_document") and callable(dm.set_active_document):
                dm.set_active_document(doc)
            else:
                # best-effort fallback
                setattr(dm, "_active_document", doc)
        except Exception:
            pass

    def _list_open_docs(self):
        docs = []
        for sw in self.mdi.subWindowList():
            d = getattr(sw.widget(), "document", None)
            if d:
                docs.append(d)
        return docs

    def _active_view(self):
        sw = self.mdi.activeSubWindow()
        return sw.widget() if sw else None

    def _active_doc(self):
        dm = getattr(self, "doc_manager", None) or getattr(self, "docman", None)
        if not dm:
            return None
        return dm.get_active_document()

    def _document_has_edits(self, doc) -> bool:
        # Prefer a dedicated 'dirty' indicator if your ImageDocument exposes one
        dirty_attr = getattr(doc, "dirty", None)
        if callable(dirty_attr):
            try:
                return bool(dirty_attr())
            except Exception:
                pass
        elif isinstance(dirty_attr, bool):
            return dirty_attr

        # Fallback heuristic: anything to undo = user edited since load/reset
        try:
            return bool(doc.can_undo())
        except Exception:
            return False

    def _log(self, msg):
        self.console.addItem(msg)
        self.console.scrollToBottom()

    def _safe_close_doc(self, doc):
        # skip if app is shutting down or docman already gone
        if self._shutting_down:
            return
        dm = getattr(self, "docman", None)
        if dm is None:
            return
        try:
            if sip.isdeleted(dm):
                return
        except Exception:
            # sip may not be able to inspect; fall back and hope for the best
            pass
        dm.close_document(doc)

    def _restore_window_placement(self):
        s = self.settings
        try:
            geo = s.value("ui/main/geometry")
            st  = s.value("ui/main/state")
            is_max = s.value("ui/main/maximized", False, type=bool)
            if geo is not None and len(geo) > 0:
                self.restoreGeometry(geo)
            if st is not None and len(st) > 0:
                result = self.restoreState(st, version=1)
                if not result:
                    s.remove("ui/main/state")
            from PyQt6.QtGui import QGuiApplication
            r = self.frameGeometry()
            scr = QGuiApplication.screenAt(r.center()) or QGuiApplication.primaryScreen()
            if scr:
                ag = scr.availableGeometry()
                if not ag.intersects(r):
                    self.move(ag.center() - self.rect().center())
            if is_max:
                self.showMaximized()
        except Exception:
            pass

    def _ensure_persistent_names(self):
        def _safe_name(title: str, prefix: str):
            t = title or ""
            t = "".join(ch if ch.isalnum() else "_" for ch in t)
            t = t.strip("_") or "Untitled"
            return f"{prefix}_{t}"

        # Docks
        for dock in self.findChildren(QDockWidget):
            if not dock.objectName():
                dock.setObjectName(_safe_name(dock.windowTitle(), "Dock"))

        # Toolbars
        for tb in self.findChildren(QToolBar):
            if not tb.objectName():
                tb.setObjectName(_safe_name(tb.windowTitle(), "Toolbar"))

    def _clear_view_bundles_for_next_launch(self):
        """
        On app exit, wipe any saved doc_ptrs in View Bundles so they don't point
        to stale objects on next run. We keep bundle names/uuids/file_paths, just
        empty the 'doc_ptrs' lists.

        This handles both the old v2 and the new v3 stores.
        """
        try:
            s = QSettings()

            def _scrub_doc_ptrs(key: str):
                raw = s.value(key, "[]", type=str) or "[]"
                try:
                    data = json.loads(raw)
                except Exception:
                    data = []
                if isinstance(data, list):
                    for b in data:
                        if isinstance(b, dict):
                            b["doc_ptrs"] = []  # drop all view pointers
                    s.setValue(key, json.dumps(data, ensure_ascii=False))
                else:
                    s.setValue(key, "[]")

            # scrub both generations
            _scrub_doc_ptrs("viewbundles/v2")
            _scrub_doc_ptrs("viewbundles/v3")

            # nuke legacy v1 entirely
            s.setValue("viewbundles/v1", "[]")

            s.sync()
        except Exception:
            # last-resort: write empty arrays everywhere
            try:
                s = QSettings()
                s.setValue("viewbundles/v1", "[]")
                s.setValue("viewbundles/v2", "[]")
                s.setValue("viewbundles/v3", "[]")
                s.sync()
            except Exception:
                pass


    def showEvent(self, ev):
        super().showEvent(ev)
        # when returning from the taskbar, some platforms don't emit WindowStateChange reliably
        if self._suspend_dock_sync:
            QTimer.singleShot(0, lambda: self.changeEvent(QEvent(QEvent.Type.WindowStateChange)))

    def resizeEvent(self, event):
        super().resizeEvent(event)

    def moveEvent(self, event):
        super().moveEvent(event)

    def changeEvent(self, event):
        super().changeEvent(event)
        # 1. Existing logic for dock sync (re-instated from showEvent logic if needed, but usually changeEvent is enough)
        # (The snippet viewed previously showed showEvent firing a oneshot to call changeEvent)
        
        # 2. Resource Monitor Sync — it's a docked panel now, so pause its
        # polling while the window is minimized and resume when restored,
        # instead of showing/hiding a floating overlay.
        if event.type() == QEvent.Type.WindowStateChange:
            rmd = getattr(self, "resource_monitor_dock", None)
            if rmd is not None:
                try:
                    minimized = bool(self.windowState() & Qt.WindowState.WindowMinimized)
                    rmd.backend.set_active(not minimized)
                except Exception:
                    pass

    def save_ui_state(self):
        """Save window geometry, state, and shortcuts to settings."""
        self._ensure_persistent_names()
        try:
            if self.isMaximized():
                self.settings.setValue("ui/main/maximized", True)
                # To get accurate geometry for non-maximized state, we'd need to showNormal()
                # but that causes flicker. For a restart, we'll just save what we have.
            else:
                self.settings.setValue("ui/main/maximized", False)
                self.settings.setValue("ui/main/geometry", self.saveGeometry())

            self.settings.setValue("ui/main/state", self.saveState(version=1))
        except Exception:
            pass

        # save shortcuts
        try:
            save_on_exit = self.settings.value("shortcuts/save_on_exit", True, type=bool)
        except Exception:
            save_on_exit = True
        if save_on_exit and hasattr(self, "shortcuts"):
            try:
                self.shortcuts.save_shortcuts()
            except Exception:
                pass
        
        self.settings.sync()

    def on_fade_in_complete(self):
        """Called when main window fade-in is finished."""
        self._fade_in_complete = True
        # If the icon table was open at last shutdown, re-open it in place.
        try:
            from PyQt6.QtCore import QSettings
            if QSettings().value("icon_table/visible", False, type=bool):
                # Slight delay so fade + monitor come up first — same pattern
                # you use for the resource monitor above.
                QTimer.singleShot(500, self._restore_icon_table_if_needed)
        except Exception:
            pass        
        # (The resource monitor is a docked panel now; it appears with the rest
        # of the layout via restoreState — no deferred overlay show needed.)

    def keyPressEvent(self, event):
        """Handle key press events for secret shortcuts."""
        if (
            event.modifiers() == (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.AltModifier)
            and event.key() == Qt.Key.Key_M
        ):
            self._launch_bored_minigame()
            event.accept()
            return

        super().keyPressEvent(event)

    def _launch_bored_minigame(self):
        # Handle both frozen (PyInstaller) and normal execution
        if getattr(sys, 'frozen', False):
            # PyInstaller extracts to sys._MEIPASS
            base_pkg = sys._MEIPASS
            minigame_path = os.path.join(base_pkg, "setiastro", "saspro", 
                                        "widgets", "minigame", "index.html")
        else:
            base_pkg = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            minigame_path = os.path.join(base_pkg, "widgets", "minigame", "index.html")
        
        if os.path.exists(minigame_path):
            QDesktopServices.openUrl(QUrl.fromLocalFile(minigame_path))
        else:
            QMessageBox.information(
                self,
                self.tr("Bored?"),
                self.tr("The minigame could not be found.")
            )
            
    def _open_texture_clarity(self):
        try:
            from setiastro.saspro.texture_clarity import open_texture_clarity_dialog
            open_texture_clarity_dialog(self)
        except Exception as e:
            print(f"Error opening Texture & Clarity: {e}")

    def _update_usage_stats(self):
        try:
            now = time.time()
            elapsed = now - self._session_start_time
            self._session_start_time = now  # Reset session start to avoid double counting
            
            total = self.settings.value("stats/total_time_seconds", 0.0, type=float)
            self.settings.setValue("stats/total_time_seconds", total + elapsed)
        except Exception:
            pass

    def _on_tool_triggered(self):
        """Slot to track tool usage count."""
        try:
            count = self.settings.value("stats/opened_tools_count", 0, type=int)
            self.settings.setValue("stats/opened_tools_count", count + 1)
        except Exception:
            pass

    def save_main_window_state(self):
        s = self.settings
        k = self._mw_key()

        is_full = bool(self.windowState() & Qt.WindowState.WindowFullScreen)
        is_max  = bool(self.windowState() & Qt.WindowState.WindowMaximized)

        s.setValue(f"{k}/fullscreen", is_full)
        s.setValue(f"{k}/maximized", is_max)

        try:
            if is_max or is_full:
                s.setValue(f"{k}/geometry_normal", self.normalGeometry())
            else:
                s.setValue(f"{k}/geometry_normal", None)
        except Exception:
            pass

        try:
            s.setValue(f"{k}/geometry", self.saveGeometry())
        except Exception:
            pass
        try:
            s.setValue(f"{k}/state", self.saveState())
        except Exception:
            pass

        # Save dock host state
        try:
            self.save_dock_host_state()
        except Exception:
            pass
        # Persist icon-table geometry + visibility so it re-opens
        # where the user last left it.
        try:
            if getattr(self, "_icon_table", None) is not None:
                # Use runtime isVisible(); if the widget's been closed the
                # value is already False.
                self._icon_table.save_window_state()
        except Exception:
            pass
        s.sync()

    def restore_main_window_state(self):
        s = self.settings
        k = self._mw_key()

        st = s.value(f"{k}/state", None)
        if st is not None and len(st) > 0:
            result = self.restoreState(st)
            if not result:
                s.remove(f"{k}/state")

        geom = s.value(f"{k}/geometry", None)
        if geom is not None and len(geom) > 0:
            self.restoreGeometry(geom)

        was_max = s.value(f"{k}/maximized", False, type=bool)
        was_full = s.value(f"{k}/fullscreen", False, type=bool)
        if was_full:
            self.showFullScreen()
        elif was_max:
            self.showMaximized()


    def closeEvent(self, e):
        self._update_usage_stats()
        self._shutting_down = True

        try:
            self.save_main_window_state()
        except Exception:
            pass

        # Optimization: If restarting (e.g. language change), bypass confirmation and close immediately
        if getattr(self, "_is_restarting", False):
            e.accept()
            return
        
        # Check if we have already faded out
        if getattr(self, "_fade_out_complete", False):
            # Proceed with shutdown
            self._do_shutdown_steps(e)
            return

        try:
            if hasattr(self, "_orig_stdout") and self._orig_stdout is not None:
                sys.stdout = self._orig_stdout
            if hasattr(self, "_orig_stderr") and self._orig_stderr is not None:
                sys.stderr = self._orig_stderr
        except Exception:
            pass        

        # --- Confirmation Logic ---
        self._shutting_down = True

        # Gather open docs
        docs = []
        for sw in self.mdi.subWindowList():
            vw = sw.widget()
            d = getattr(vw, "document", None)
            if d and d not in docs:
                docs.append(d)

        edited = [d for d in docs if self._document_has_edits(d)]
        # If user has disabled exit confirmation (optional setting, but default is confirm)
        confirm = True 
        
        if confirm:
            msg = self.tr("Exit Seti Astro Suite Pro?")
            detail = []
            if docs:
                detail.append(self.tr("Open images:") + f" {len(docs)}")
            if edited:
                detail.append(self.tr("Edited since open:") + f" {len(edited)}")
            if detail:
                msg += "\n\n" + "\n".join(detail)

            # --- stay-on-top message box ---
            mbox = QMessageBox(self)
            mbox.setIcon(QMessageBox.Icon.Question)
            mbox.setWindowTitle(self.tr("Confirm Exit"))
            mbox.setText(msg)
            mbox.setStandardButtons(
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            mbox.setDefaultButton(QMessageBox.StandardButton.No)
            mbox.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)
            mbox.raise_()
            mbox.activateWindow()
            btn = mbox.exec()

            if btn != QMessageBox.StandardButton.Yes:
                e.ignore()
                self._shutting_down = False
                return

        # --- User confirmed (or no confirm needed) ---
        # Start Fade Out Animation
        e.ignore() # Defer close until animation completes
        self.setEnabled(False) # Prevent further interaction
        
        # Stop the resource monitor's background polling before shutdown/fade.
        rmd = getattr(self, "resource_monitor_dock", None)
        if rmd is not None:
            try:
                rmd.backend.stop()
            except Exception:
                pass
        try:
            host = getattr(self, "dock_host", None)
            if host is not None:
                self.save_dock_host_state()  # capture current arrangement
                host.hide()                  # hide immediately (clean visual)
                # don't close yet — let _do_shutdown_steps do it
                # so Qt doesn't destroy docks before state is flushed
        except Exception:
            pass
        # Linux compositors don't support window opacity — skip the fade and
        # shut down immediately.
        import platform
        if platform.system() == "Linux":
            self._do_shutdown_steps(e)
            return

        # Start Fade Out Animation (Windows / macOS only)
        e.ignore()           # Defer close until animation completes
        self.setEnabled(False)  # Prevent further interaction

        self._anim_close = QPropertyAnimation(self, b"windowOpacity")
        self._anim_close.setDuration(800)
        self._anim_close.setStartValue(1.0)
        self._anim_close.setEndValue(0.0)
        self._anim_close.setEasingCurve(QEasingCurve.Type.OutQuad)
        self._anim_close.finished.connect(self._on_fade_out_finished)
        self._anim_close.start()

    def _on_fade_out_finished(self):
        """Called when close animation completes."""    
        self._fade_out_complete = True
        self.close()

    def _do_shutdown_steps(self, e):
        self._force_close_all = True
        self._shutting_down = True
        # User has confirmed exit. Un-shelve any minimized views before we
        # persist UI state and before Qt tears the shelf down.
        shelf = getattr(self, "window_shelf", None)
        if shelf is not None and not shelf._is_dead(shelf):
            shelf.restore_all()
        self.save_ui_state()

        # Now safe to fully close the dock host
        try:
            host = getattr(self, "dock_host", None)
            if host is not None:
                host.hide()
                host.close()
        except Exception:
            pass

        try:
            for t in list(getattr(self, "_bg_threads", [])):
                try:
                    t.wait(3000)
                except Exception:
                    pass
        except Exception:
            pass

        self._clear_view_bundles_for_next_launch()
        super().closeEvent(e)

# CheatSheet dialog and helper functions imported from setiastro.saspro.cheat_sheet
from setiastro.saspro.cheat_sheet import (
    CheatSheetDialog as _CheatSheetDialog,
    add_extra_shortcuts,
    _qs_to_str,
    _clean_text,
    _uniq_keep_order,
    _seqs_for_action,
    _where_for_action,
    _describe_action,
    _describe_shortcut,
    _where_for_shortcut,
)

# _ProjectSaveWorker and install_crash_handlers imported from setiastro.saspro.widgets.common_utilities
