<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="it">
  <context>
    <name>ABEDialog</name>
    <message>
      <source># sample points:</source>
      <translation># punti campione:</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Automatic Background Extraction (ABE)</source>
      <translation>Estrazione Automatica Sfondo (ABE)</translation>
    </message>
    <message>
      <source>Clear Exclusions</source>
      <translation>Cancella esclusioni</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Create background document</source>
      <translation>Crea documento sfondo</translation>
    </message>
    <message>
      <source>Downsample factor:</source>
      <translation>Fattore sottocampionamento:</translation>
    </message>
    <message>
      <source>Enable RBF refinement (after polynomial)</source>
      <translation>Abilita rifinitura RBF (dopo polinomiale)</translation>
    </message>
    <message>
      <source>Patch size (px):</source>
      <translation>Dimensione patch (px):</translation>
    </message>
    <message>
      <source>Polynomial degree:</source>
      <translation>Grado polinomiale:</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Preview background instead of corrected</source>
      <translation>Anteprima sfondo invece che corretto</translation>
    </message>
    <message>
      <source>RBF Refinement</source>
      <translation>Rifinitura RBF</translation>
    </message>
    <message>
      <source>Smooth (x0.01):</source>
      <translation>Levigatura (x0.01):</translation>
    </message>
    <message>
      <source>ABE</source>
      <translation>ABE</translation>
    </message>
    <message>
      <source>Add Sample</source>
      <translation>Aggiungi campione</translation>
    </message>
    <message>
      <source>Auto Generate Samples</source>
      <translation>Genera campioni automaticamente</translation>
    </message>
    <message>
      <source>Automatic Background Extraction</source>
      <translation>Estrazione sfondo automatica</translation>
    </message>
    <message>
      <source>Background Model</source>
      <translation>Modello sfondo</translation>
    </message>
    <message>
      <source>Clear Samples</source>
      <translation>Cancella campioni</translation>
    </message>
    <message>
      <source>Correction</source>
      <translation>Correzione</translation>
    </message>
    <message>
      <source>Divide</source>
      <translation>Dividi</translation>
    </message>
    <message>
      <source>Done</source>
      <translation>Fatto</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Generate Background Model</source>
      <translation>Genera modello sfondo</translation>
    </message>
    <message>
      <source>Grid Size</source>
      <translation>Dimensione griglia</translation>
    </message>
    <message>
      <source>Iterations</source>
      <translation>Iterazioni</translation>
    </message>
    <message>
      <source>Polynomial Degree</source>
      <translation>Grado polinomiale</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Protect Stars</source>
      <translation>Proteggi stelle</translation>
    </message>
    <message>
      <source>Remove Sample</source>
      <translation>Rimuovi campione</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Sample Points</source>
      <translation>Punti campione</translation>
    </message>
    <message>
      <source>Sample Radius</source>
      <translation>Raggio campione</translation>
    </message>
    <message>
      <source>Samples</source>
      <translation>Campioni</translation>
    </message>
    <message>
      <source>Show Grid</source>
      <translation>Mostra griglia</translation>
    </message>
    <message>
      <source>Show Samples</source>
      <translation>Mostra campioni</translation>
    </message>
    <message>
      <source>Smoothness</source>
      <translation>Morbidezza</translation>
    </message>
    <message>
      <source>Star Detection</source>
      <translation>Rilevamento stelle</translation>
    </message>
    <message>
      <source>Subtract</source>
      <translation>Sottrai</translation>
    </message>
    <message>
      <source>Threshold</source>
      <translation>Soglia</translation>
    </message>
    <message>
      <source>Tolerance</source>
      <translation>Tolleranza</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Avviso</translation>
    </message>
  </context>
  <context>
    <name>AberrationAIDialog</name>
    <message>
      <source>Auto GPU (if available)</source>
      <translation>GPU automatica (se disponibile)</translation>
    </message>
    <message>
      <source>Browse…</source>
      <translation>Sfoglia…</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Download latest model…</source>
      <translation>Scarica ultimo modello…</translation>
    </message>
    <message>
      <source>Model:</source>
      <translation>Modello:</translation>
    </message>
    <message>
      <source>Open model folder</source>
      <translation>Apri cartella modello</translation>
    </message>
    <message>
      <source>Overlap</source>
      <translation>Sovrapposizione</translation>
    </message>
    <message>
      <source>Patch</source>
      <translation>Patch</translation>
    </message>
    <message>
      <source>Provider:</source>
      <translation>Provider:</translation>
    </message>
    <message>
      <source>R.A.'s Aberration Correction (AI)</source>
      <translation>Correzione Aberrazione R.A. (AI)</translation>
    </message>
    <message>
      <source>Run</source>
      <translation>Esegui</translation>
    </message>
  </context>
  <context>
    <name>AboutDialog</name>
    <message>
      <source>About Seti Astro Suite</source>
      <translation>Informazioni su Seti Astro Suite</translation>
    </message>
    <message>
      <source>Build:</source>
      <translation>Build:</translation>
    </message>
    <message>
      <source>Click here to donate</source>
      <translation>Clicca qui per donare</translation>
    </message>
    <message>
      <source>Collaborators: Fabio Tempera</source>
      <translation>Collaboratori: Fabio Tempera</translation>
    </message>
    <message>
      <source>Copyright © 2025 Seti Astro</source>
      <translation>Copyright © 2025 Seti Astro</translation>
    </message>
    <message>
      <source>Donations:</source>
      <translation>Donazioni:</translation>
    </message>
    <message>
      <source>Website:</source>
      <translation>Sito web:</translation>
    </message>
    <message>
      <source>Written by Franklin Marek</source>
      <translation>Scritto da Franklin Marek</translation>
    </message>
    <message>
      <source>About</source>
      <translation>Informazioni</translation>
    </message>
    <message>
      <source>All rights reserved</source>
      <translation>Tutti i diritti riservati</translation>
    </message>
    <message>
      <source>Build</source>
      <translation>Build</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Controlla aggiornamenti</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Copyright</source>
      <translation>Copyright</translation>
    </message>
    <message>
      <source>Credits</source>
      <translation>Crediti</translation>
    </message>
    <message>
      <source>Documentation</source>
      <translation>Documentazione</translation>
    </message>
    <message>
      <source>License</source>
      <translation>Licenza</translation>
    </message>
    <message>
      <source>Support</source>
      <translation>Supporto</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versione</translation>
    </message>
    <message>
      <source>Website</source>
      <translation>Sito web</translation>
    </message>
  </context>
  <context>
    <name>AddStarsDialog</name>
    <message>
      <source>Add Stars to Image</source>
      <translation>Aggiungi stelle all'immagine</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Blend Ratio (Screen/Add Intensity):</source>
      <translation>Rapporto fusione (Schermo/Aggiungi intensità):</translation>
    </message>
    <message>
      <source>Blend Type:</source>
      <translation>Tipo fusione:</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Load from File</source>
      <translation>Carica da file</translation>
    </message>
    <message>
      <source>Refresh Views</source>
      <translation>Aggiorna viste</translation>
    </message>
    <message>
      <source>Starless View:</source>
      <translation>Vista senza stelle:</translation>
    </message>
    <message>
      <source>Stars-Only View:</source>
      <translation>Vista solo stelle:</translation>
    </message>
    <message>
      <source>Add</source>
      <translation>Aggiungi</translation>
    </message>
    <message>
      <source>Add Stars</source>
      <translation>Aggiungi stelle</translation>
    </message>
    <message>
      <source>Blend Mode</source>
      <translation>Modalità fusione</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Create new image</source>
      <translation>Crea nuova immagine</translation>
    </message>
    <message>
      <source>Lighten</source>
      <translation>Schiarisci</translation>
    </message>
    <message>
      <source>Linear Dodge</source>
      <translation>Dodge lineare</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Replace active image</source>
      <translation>Sostituisci immagine attiva</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Screen</source>
      <translation>Schermo</translation>
    </message>
    <message>
      <source>Select starless view</source>
      <translation>Seleziona vista senza stelle</translation>
    </message>
    <message>
      <source>Select stars view</source>
      <translation>Seleziona vista solo stelle</translation>
    </message>
    <message>
      <source>Star Brightness</source>
      <translation>Luminosità stelle</translation>
    </message>
    <message>
      <source>Star Saturation</source>
      <translation>Saturazione stelle</translation>
    </message>
    <message>
      <source>Star Size</source>
      <translation>Dimensione stelle</translation>
    </message>
    <message>
      <source>Starless Image</source>
      <translation>Immagine senza stelle</translation>
    </message>
    <message>
      <source>Stars-Only Image</source>
      <translation>Immagine solo stelle</translation>
    </message>
  </context>
  <context>
    <name>AfterAlignWorker</name>
    <message>
      <source>Post-alignment complete.

{0}</source>
      <translation>Post-allineamento completato.

{0}</translation>
    </message>
    <message>
      <source>Post-alignment failed: {0}</source>
      <translation>Post-allineamento fallito: {0}</translation>
    </message>
  </context>
  <context>
    <name>AstroSuiteProMainWindow</name>
    <message>
      <source>Command Search</source>
      <translation>Ricerca Comandi</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Visualizza</translation>
    </message>
    <message>
      <source>Functions</source>
      <translation>Funzioni</translation>
    </message>
    <message>
      <source>Cosmic Clarity</source>
      <translation>Cosmic Clarity</translation>
    </message>
    <message>
      <source>Tools</source>
      <translation>Strumenti</translation>
    </message>
    <message>
      <source>Geometry</source>
      <translation>Geometria</translation>
    </message>
    <message>
      <source>Star Stuff</source>
      <translation>Stelle</translation>
    </message>
    <message>
      <source>Masks</source>
      <translation>Maschere</translation>
    </message>
    <message>
      <source>What's In My...</source>
      <translation>What's In My...</translation>
    </message>
    <message>
      <source>Bundles</source>
      <translation>Bundle</translation>
    </message>
    <message>
      <source>Explorer</source>
      <translation>Esplora Risorse</translation>
    </message>
    <message>
      <source>Console / Status</source>
      <translation>Console / Stato</translation>
    </message>
    <message>
      <source>Header Viewer</source>
      <translation>Visualizzatore Intestazione</translation>
    </message>
    <message>
      <source>Layers</source>
      <translation>Livelli</translation>
    </message>
    <message>
      <source>Window Shelf</source>
      <translation>Scaffale Finestre</translation>
    </message>
    <message>
      <source>&amp;About</source>
      <translation>&amp;Info</translation>
    </message>
    <message>
      <source>&amp;Edit</source>
      <translation>&amp;Modifica</translation>
    </message>
    <message>
      <source>&amp;Exit</source>
      <translation>&amp;Esci</translation>
    </message>
    <message>
      <source>&amp;File</source>
      <translation>&amp;File</translation>
    </message>
    <message>
      <source>&amp;Functions</source>
      <translation>&amp;Funzioni</translation>
    </message>
    <message>
      <source>&amp;Geometry</source>
      <translation>&amp;Geometria</translation>
    </message>
    <message>
      <source>&amp;Header Mods &amp;&amp; Misc</source>
      <translation>&amp;Modifica Header e Varie</translation>
    </message>
    <message>
      <source>&amp;History</source>
      <translation>&amp;Cronologia</translation>
    </message>
    <message>
      <source>&amp;Masks</source>
      <translation>&amp;Maschere</translation>
    </message>
    <message>
      <source>&amp;Scripts</source>
      <translation>&amp;Script</translation>
    </message>
    <message>
      <source>&amp;Settings</source>
      <translation>&amp;Impostazioni</translation>
    </message>
    <message>
      <source>&amp;Shortcuts</source>
      <translation>&amp;Scorciatoie</translation>
    </message>
    <message>
      <source>&amp;Smart Tools</source>
      <translation>&amp;Strumenti Smart</translation>
    </message>
    <message>
      <source>&amp;Star Stuff</source>
      <translation>&amp;Stelle</translation>
    </message>
    <message>
      <source>&amp;Tools</source>
      <translation>&amp;Strumenti</translation>
    </message>
    <message>
      <source>&amp;View</source>
      <translation>&amp;Vista</translation>
    </message>
    <message>
      <source>&amp;What's In My...</source>
      <translation>&amp;Cosa c'è nella mia...</translation>
    </message>
    <message>
      <source>1:1</source>
      <translation>1:1</translation>
    </message>
    <message>
      <source>ABE...</source>
      <translation>ABE...</translation>
    </message>
    <message>
      <source>Aberration Correction (AI)...</source>
      <translation>Correzione aberrazione (AI)...</translation>
    </message>
    <message>
      <source>About...</source>
      <translation>Informazioni...</translation>
    </message>
    <message>
      <source>Add Stars...</source>
      <translation>Aggiungi stelle...</translation>
    </message>
    <message>
      <source>Add diffraction spikes to detected stars</source>
      <translation>Aggiungi spike di diffrazione alle stelle rilevate</translation>
    </message>
    <message>
      <source>Add signatures/overlays and bake them into the active image</source>
      <translation>Aggiungi firme/overlay e incorporali nell'immagine attiva</translation>
    </message>
    <message>
      <source>Adjust specific hue ranges with CMY/RGB controls</source>
      <translation>Regola intervalli tonalità specifici con controlli CMY/RGB</translation>
    </message>
    <message>
      <source>Advanced diffraction spikes with halos, flares and rainbow effects</source>
      <translation>Spike di diffrazione avanzati con aloni, flare ed effetti arcobaleno</translation>
    </message>
    <message>
      <source>Align R and B channels to G using astroalign (affine/homography/poly)</source>
      <translation>Allinea canali R e B a G usando astroalign (affine/omografia/poli)</translation>
    </message>
    <message>
      <source>Align images via astroalign / triangles</source>
      <translation>Allinea immagini tramite astroalign / triangoli</translation>
    </message>
    <message>
      <source>Apply Mask</source>
      <translation>Applica maschera</translation>
    </message>
    <message>
      <source>Apply a mask document to the active image</source>
      <translation>Applica un documento maschera all'immagine attiva</translation>
    </message>
    <message>
      <source>Apply the current Display-Stretch to the image and add an undo step</source>
      <translation>Applica il Display-Stretch corrente all'immagine e aggiungi un passo annulla</translation>
    </message>
    <message>
      <source>Apply the same stretch to all RGB channels</source>
      <translation>Applica lo stesso stretch a tutti i canali RGB</translation>
    </message>
    <message>
      <source>Apply white balance (Star-Based, Manual, or Auto)</source>
      <translation>Applica bilanciamento bianco (Basato su stelle, Manuale o Auto)</translation>
    </message>
    <message>
      <source>Arcsinh star stretch with optional SCNR and color boost</source>
      <translation>Star stretch arcsinh con SCNR opzionale e boost colore</translation>
    </message>
    <message>
      <source>Arrange subwindows in a near-square grid</source>
      <translation>Disponi sottofinestre in una griglia quasi quadrata</translation>
    </message>
    <message>
      <source>AstroBin Exporter...</source>
      <translation>Esportatore AstroBin...</translation>
    </message>
    <message>
      <source>AstroSpike...</source>
      <translation>AstroSpike...</translation>
    </message>
    <message>
      <source>Auto-fit on Resize</source>
      <translation>Adatta automaticamente al ridimensionamento</translation>
    </message>
    <message>
      <source>Automatic Background Extraction</source>
      <translation>Estrazione automatica sfondo</translation>
    </message>
    <message>
      <source>Background Neutralization...</source>
      <translation>Neutralizzazione sfondo...</translation>
    </message>
    <message>
      <source>Batch Converter...</source>
      <translation>Convertitore batch...</translation>
    </message>
    <message>
      <source>Batch Modify FITS Headers</source>
      <translation>Modifica batch header FITS</translation>
    </message>
    <message>
      <source>Batch Rename from FITS...</source>
      <translation>Rinomina batch da FITS...</translation>
    </message>
    <message>
      <source>Batch-align frames to a reference</source>
      <translation>Allinea in batch frame a un riferimento</translation>
    </message>
    <message>
      <source>Blemish Blaster...</source>
      <translation>Blemish Blaster...</translation>
    </message>
    <message>
      <source>Blend a starless view with a stars-only view</source>
      <translation>Fondi una vista senza stelle con una vista solo stelle</translation>
    </message>
    <message>
      <source>Blend two open images (replace A or create new)</source>
      <translation>Fondi due immagini aperte (sostituisci A o crea nuova)</translation>
    </message>
    <message>
      <source>Blink Comparator...</source>
      <translation>Comparatore Blink...</translation>
    </message>
    <message>
      <source>Build mosaics from overlapping frames</source>
      <translation>Costruisci mosaici da frame sovrapposti</translation>
    </message>
    <message>
      <source>CLAHE...</source>
      <translation>CLAHE...</translation>
    </message>
    <message>
      <source>Cascade Views</source>
      <translation>Cascata viste</translation>
    </message>
    <message>
      <source>Cascade all subwindows</source>
      <translation>Sovrapponi tutte le sottofinestre</translation>
    </message>
    <message>
      <source>Check for Updates...</source>
      <translation>Controlla aggiornamenti...</translation>
    </message>
    <message>
      <source>Clear All Shortcuts</source>
      <translation>Cancella tutte le scorciatoie</translation>
    </message>
    <message>
      <source>Clear All Views</source>
      <translation>Chiudi tutte le viste</translation>
    </message>
    <message>
      <source>Clear Console</source>
      <translation>Pulisci console</translation>
    </message>
    <message>
      <source>Clear List</source>
      <translation>Cancella lista</translation>
    </message>
    <message>
      <source>Close all views and clear shortcuts</source>
      <translation>Chiudi tutte le viste e cancella scorciatoie</translation>
    </message>
    <message>
      <source>Close all views and documents, keep desktop shortcuts</source>
      <translation>Chiudi tutte le viste e documenti, mantieni scorciatoie desktop</translation>
    </message>
    <message>
      <source>Combine narrowband to RGB with optional OSC stars</source>
      <translation>Combina narrowband in RGB con stelle OSC opzionali</translation>
    </message>
    <message>
      <source>Combine three mono images into RGB</source>
      <translation>Combina tre immagini mono in RGB</translation>
    </message>
    <message>
      <source>Compare a stack of images by blinking</source>
      <translation>Confronta una pila di immagini lampeggiando</translation>
    </message>
    <message>
      <source>Continuum Subtract (NB - scaled broadband)</source>
      <translation>Sottrazione continuum (NB - banda larga scalata)</translation>
    </message>
    <message>
      <source>Continuum Subtract...</source>
      <translation>Sottrazione continuum...</translation>
    </message>
    <message>
      <source>Contrast Limited Adaptive Histogram Equalization</source>
      <translation>Equalizzazione istogramma adattiva a contrasto limitato</translation>
    </message>
    <message>
      <source>Convolution / Deconvolution...</source>
      <translation>Convoluzione / Deconvoluzione...</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Copia tutto</translation>
    </message>
    <message>
      <source>Copy Astrometric Solution...</source>
      <translation>Copia soluzione astrometrica...</translation>
    </message>
    <message>
      <source>Copy Selected</source>
      <translation>Copia selezionato</translation>
    </message>
    <message>
      <source>Copy View (zoom/pan)</source>
      <translation>Copia vista (zoom/pan)</translation>
    </message>
    <message>
      <source>Cosmic Clarity Satellite...</source>
      <translation>Cosmic Clarity Satellite...</translation>
    </message>
    <message>
      <source>Cosmic Clarity UI...</source>
      <translation>Cosmic Clarity UI...</translation>
    </message>
    <message>
      <source>Create Mask...</source>
      <translation>Crea maschera...</translation>
    </message>
    <message>
      <source>Create Sample Scripts...</source>
      <translation>Crea script di esempio...</translation>
    </message>
    <message>
      <source>Create a mask from the active image</source>
      <translation>Crea una maschera dall'immagine attiva</translation>
    </message>
    <message>
      <source>Create a new mono document using the selected luminance method</source>
      <translation>Crea un nuovo documento mono usando il metodo luminanza selezionato</translation>
    </message>
    <message>
      <source>Create and run bundles of functions/shortcuts</source>
      <translation>Crea ed esegui bundle di funzioni/scorciatoie</translation>
    </message>
    <message>
      <source>Create bundles of views; drop shortcuts to apply to all</source>
      <translation>Crea bundle di viste; rilascia scorciatoie per applicare a tutti</translation>
    </message>
    <message>
      <source>Crop / rotate with handles</source>
      <translation>Ritaglia / ruota con maniglie</translation>
    </message>
    <message>
      <source>Crop...</source>
      <translation>Ritaglia...</translation>
    </message>
    <message>
      <source>Curves Editor...</source>
      <translation>Editor curve...</translation>
    </message>
    <message>
      <source>Debayer...</source>
      <translation>Debayer...</translation>
    </message>
    <message>
      <source>Demosaic a Bayer-mosaic mono image to RGB</source>
      <translation>Demosaica un'immagine mono mosaico Bayer in RGB</translation>
    </message>
    <message>
      <source>Detect exoplanet transits from time-series subs</source>
      <translation>Rileva transiti esopianeti da sub serie temporali</translation>
    </message>
    <message>
      <source>Diffraction Spikes...</source>
      <translation>Spike di diffrazione...</translation>
    </message>
    <message>
      <source>Display-Stretch</source>
      <translation>Display-Stretch</translation>
    </message>
    <message>
      <source>Documentation...</source>
      <translation>Documentazione...</translation>
    </message>
    <message>
      <source>Enhance faint/dark structures with wavelet-guided masking</source>
      <translation>Migliora strutture deboli/scure con mascheratura guidata da wavelet</translation>
    </message>
    <message>
      <source>Erosion, dilation, opening, and closing.</source>
      <translation>Erosione, dilatazione, apertura e chiusura.</translation>
    </message>
    <message>
      <source>Evaluate expressions using open view names</source>
      <translation>Valuta espressioni usando nomi viste aperte</translation>
    </message>
    <message>
      <source>Exoplanet Detector...</source>
      <translation>Rilevatore esopianeti...</translation>
    </message>
    <message>
      <source>Export Shortcuts...</source>
      <translation>Esporta scorciatoie...</translation>
    </message>
    <message>
      <source>Extract Luminance</source>
      <translation>Estrai luminanza</translation>
    </message>
    <message>
      <source>Extract R/G/B as three mono documents</source>
      <translation>Estrai R/G/B come tre documenti mono</translation>
    </message>
    <message>
      <source>FITS Header Batch Modifier...</source>
      <translation>Modificatore batch header FITS...</translation>
    </message>
    <message>
      <source>FITS Header Modifier...</source>
      <translation>Modificatore header FITS...</translation>
    </message>
    <message>
      <source>Find transients/anomalies across frames</source>
      <translation>Trova transienti/anomalie tra frame</translation>
    </message>
    <message>
      <source>Fit</source>
      <translation>Adatta</translation>
    </message>
    <message>
      <source>Fit galaxy isophotes and reveal residuals</source>
      <translation>Adatta isofote galassia e rivela residui</translation>
    </message>
    <message>
      <source>Fit image to current window</source>
      <translation>Adatta immagine alla finestra corrente</translation>
    </message>
    <message>
      <source>Flip Horizontal</source>
      <translation>Capovolgi orizzontale</translation>
    </message>
    <message>
      <source>Flip Vertical</source>
      <translation>Capovolgi verticale</translation>
    </message>
    <message>
      <source>Flip image left&lt;-&gt;right</source>
      <translation>Capovolgi immagine sinistra&lt;-&gt;destra</translation>
    </message>
    <message>
      <source>Flip image top&lt;-&gt;bottom</source>
      <translation>Capovolgi immagine alto&lt;-&gt;basso</translation>
    </message>
    <message>
      <source>Frequency Separation...</source>
      <translation>Separazione frequenze...</translation>
    </message>
    <message>
      <source>Function Bundles...</source>
      <translation>Bundle funzioni...</translation>
    </message>
    <message>
      <source>GLIMR -- Isophote Modeler...</source>
      <translation>GLIMR -- Modellatore isofote...</translation>
    </message>
    <message>
      <source>Generalized hyperbolic stretch (α/beta/gamma, LP/HP, pivot)</source>
      <translation>Stretch iperbolico generalizzato (α/beta/gamma, LP/HP, pivot)</translation>
    </message>
    <message>
      <source>Group A</source>
      <translation>Gruppo A</translation>
    </message>
    <message>
      <source>Group B</source>
      <translation>Gruppo B</translation>
    </message>
    <message>
      <source>Group C</source>
      <translation>Gruppo C</translation>
    </message>
    <message>
      <source>Group D</source>
      <translation>Gruppo D</translation>
    </message>
    <message>
      <source>Halo-B-Gon...</source>
      <translation>Halo-B-Gon...</translation>
    </message>
    <message>
      <source>Hard (target 0.50, σ 2)</source>
      <translation>Forte (target 0.50, σ 2)</translation>
    </message>
    <message>
      <source>Hard-Display-Stretch</source>
      <translation>Display-Stretch forte</translation>
    </message>
    <message>
      <source>Hide Mask Overlay</source>
      <translation>Nascondi overlay maschera</translation>
    </message>
    <message>
      <source>Histogram...</source>
      <translation>Istogramma...</translation>
    </message>
    <message>
      <source>History Explorer...</source>
      <translation>Esplora cronologia...</translation>
    </message>
    <message>
      <source>Hyperbolic Stretch...</source>
      <translation>Stretch iperbolico...</translation>
    </message>
    <message>
      <source>Identify objects in a plate-solved frame</source>
      <translation>Identifica oggetti in un frame risolto</translation>
    </message>
    <message>
      <source>Image Combine...</source>
      <translation>Combina immagini...</translation>
    </message>
    <message>
      <source>Image Inspector and Focal Plane Analysis</source>
      <translation>Ispettore immagine e analisi piano focale</translation>
    </message>
    <message>
      <source>Image Peeker...</source>
      <translation>Image Peeker...</translation>
    </message>
    <message>
      <source>Import Shortcuts...</source>
      <translation>Importa scorciatoie...</translation>
    </message>
    <message>
      <source>Inspect and restore from the slot's history</source>
      <translation>Ispeziona e ripristina dalla cronologia dello slot</translation>
    </message>
    <message>
      <source>Inspect star PSF/HFR and flux histograms (SEP)</source>
      <translation>Ispeziona PSF/HFR stelle e istogrammi flusso (SEP)</translation>
    </message>
    <message>
      <source>Interactive blemish removal on the active view</source>
      <translation>Rimozione imperfezioni interattiva sulla vista attiva</translation>
    </message>
    <message>
      <source>Invert</source>
      <translation>Inverti</translation>
    </message>
    <message>
      <source>Invert Mask</source>
      <translation>Inverti maschera</translation>
    </message>
    <message>
      <source>Invert image colors</source>
      <translation>Inverti colori immagine</translation>
    </message>
    <message>
      <source>Keyboard Shortcut Cheat Sheet...</source>
      <translation>Schema scorciatoie tastiera...</translation>
    </message>
    <message>
      <source>Linear Fit...</source>
      <translation>Fit lineare...</translation>
    </message>
    <message>
      <source>Link Pan/Zoom</source>
      <translation>Collega Pan/Zoom</translation>
    </message>
    <message>
      <source>Link RGB channels</source>
      <translation>Collega canali RGB</translation>
    </message>
    <message>
      <source>Live Stacking...</source>
      <translation>Live Stacking...</translation>
    </message>
    <message>
      <source>Live monitor and stack incoming frames</source>
      <translation>Monitora e impila frame in arrivo in tempo reale</translation>
    </message>
    <message>
      <source>Load Project...</source>
      <translation>Carica progetto...</translation>
    </message>
    <message>
      <source>Load a .sas project (views, histories, shortcuts)</source>
      <translation>Carica un progetto .sas (viste, cronologie, scorciatoie)</translation>
    </message>
    <message>
      <source>Make Display-Stretch Permanent</source>
      <translation>Rendi permanente Display-Stretch</translation>
    </message>
    <message>
      <source>Match image levels using Linear Fit</source>
      <translation>Adatta livelli immagine usando Fit lineare</translation>
    </message>
    <message>
      <source>Mid (target 0.40, σ 3)</source>
      <translation>Medio (target 0.40, σ 3)</translation>
    </message>
    <message>
      <source>Morphological Operations...</source>
      <translation>Operazioni morfologiche...</translation>
    </message>
    <message>
      <source>Mosaic Master...</source>
      <translation>Mosaic Master...</translation>
    </message>
    <message>
      <source>Multiscale Decomposition...</source>
      <translation>Decomposizione multiscala...</translation>
    </message>
    <message>
      <source>Multiscale detail/residual decomposition with per-layer controls</source>
      <translation>Decomposizione multiscala dettaglio/residuo con controlli per livello</translation>
    </message>
    <message>
      <source>NB-&gt;RGB Stars...</source>
      <translation>NB-&gt;RGB Stelle...</translation>
    </message>
    <message>
      <source>Neutralize background color balance using a sampled region</source>
      <translation>Neutralizza bilanciamento colore sfondo usando una regione campionata</translation>
    </message>
    <message>
      <source>New Project</source>
      <translation>Nuovo progetto</translation>
    </message>
    <message>
      <source>No recent images</source>
      <translation>Nessuna immagine recente</translation>
    </message>
    <message>
      <source>No recent projects</source>
      <translation>Nessun progetto recente</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nessuno</translation>
    </message>
    <message>
      <source>Normal (target 0.30, σ 5)</source>
      <translation>Normale (target 0.30, σ 5)</translation>
    </message>
    <message>
      <source>Open Convolution / Deconvolution</source>
      <translation>Apri Convoluzione / Deconvoluzione</translation>
    </message>
    <message>
      <source>Open Recent Images</source>
      <translation>Immagini recenti</translation>
    </message>
    <message>
      <source>Open Recent Projects</source>
      <translation>Progetti recenti</translation>
    </message>
    <message>
      <source>Open SFCC (Pickles + Filters + Sensor QE)</source>
      <translation>Apri SFCC (Pickles + Filtri + QE Sensore)</translation>
    </message>
    <message>
      <source>Open Scripts Folder...</source>
      <translation>Apri cartella script...</translation>
    </message>
    <message>
      <source>Open Scripts Forum (Discord)...</source>
      <translation>Apri forum script (Discord)...</translation>
    </message>
    <message>
      <source>Open User Scripts (GitHub)...</source>
      <translation>Apri script utente (GitHub)...</translation>
    </message>
    <message>
      <source>Open image(s)</source>
      <translation>Apri immagine/i</translation>
    </message>
    <message>
      <source>Open the Curves Editor for the active image</source>
      <translation>Apri l'editor curve per l'immagine attiva</translation>
    </message>
    <message>
      <source>Open the SASpro user scripts folder</source>
      <translation>Apri la cartella script utente SASpro</translation>
    </message>
    <message>
      <source>Open the Seti Astro Suite Pro online documentation</source>
      <translation>Apri la documentazione online di Seti Astro Suite Pro</translation>
    </message>
    <message>
      <source>Open the built-in script editor</source>
      <translation>Apri l'editor script integrato</translation>
    </message>
    <message>
      <source>Open...</source>
      <translation>Apri...</translation>
    </message>
    <message>
      <source>PSF Viewer...</source>
      <translation>Visualizzatore PSF...</translation>
    </message>
    <message>
      <source>Paste View</source>
      <translation>Incolla vista</translation>
    </message>
    <message>
      <source>Perfect Palette Picker...</source>
      <translation>Perfect Palette Picker...</translation>
    </message>
    <message>
      <source>Pick the perfect palette for your image</source>
      <translation>Scegli la palette perfetta per la tua immagine</translation>
    </message>
    <message>
      <source>Pixel Math...</source>
      <translation>Pixel Math...</translation>
    </message>
    <message>
      <source>Plan targets by altitude, transit time, and lunar separation</source>
      <translation>Pianifica target per altitudine, tempo transito e separazione lunare</translation>
    </message>
    <message>
      <source>Plate Solver...</source>
      <translation>Plate Solver...</translation>
    </message>
    <message>
      <source>Preferences...</source>
      <translation>Preferenze...</translation>
    </message>
    <message>
      <source>Presets</source>
      <translation>Preset</translation>
    </message>
    <message>
      <source>RGB Align...</source>
      <translation>Allineamento RGB...</translation>
    </message>
    <message>
      <source>RGB Combination...</source>
      <translation>Combinazione RGB...</translation>
    </message>
    <message>
      <source>RGB Extract</source>
      <translation>Estrai RGB</translation>
    </message>
    <message>
      <source>Recombine Luminance...</source>
      <translation>Ricombina luminanza...</translation>
    </message>
    <message>
      <source>Redo</source>
      <translation>Ripeti</translation>
    </message>
    <message>
      <source>Reload Scripts</source>
      <translation>Ricarica script</translation>
    </message>
    <message>
      <source>Remove Active Mask</source>
      <translation>Rimuovi maschera attiva</translation>
    </message>
    <message>
      <source>Remove Gradient (GraXpert)...</source>
      <translation>Rimuovi gradiente (GraXpert)...</translation>
    </message>
    <message>
      <source>Remove Green...</source>
      <translation>Rimuovi verde...</translation>
    </message>
    <message>
      <source>Remove Pedestal</source>
      <translation>Rimuovi piedistallo</translation>
    </message>
    <message>
      <source>Remove Stars...</source>
      <translation>Rimuovi stelle...</translation>
    </message>
    <message>
      <source>Remove the active mask from the active image</source>
      <translation>Rimuovi la maschera attiva dall'immagine attiva</translation>
    </message>
    <message>
      <source>Remove those pesky halos around your stars</source>
      <translation>Rimuovi quegli aloni fastidiosi intorno alle tue stelle</translation>
    </message>
    <message>
      <source>Replace the active image's luminance from another view</source>
      <translation>Sostituisci la luminanza dell'immagine attiva da un'altra vista</translation>
    </message>
    <message>
      <source>Rescale image by a factor</source>
      <translation>Ridimensiona immagine per un fattore</translation>
    </message>
    <message>
      <source>Rescale...</source>
      <translation>Ridimensiona...</translation>
    </message>
    <message>
      <source>Rescan the scripts folder and reload .py files</source>
      <translation>Riscansiona la cartella script e ricarica file .py</translation>
    </message>
    <message>
      <source>Rotate 180°</source>
      <translation>Ruota 180°</translation>
    </message>
    <message>
      <source>Rotate 90° Clockwise</source>
      <translation>Ruota 90° orario</translation>
    </message>
    <message>
      <source>Rotate 90° Counterclockwise</source>
      <translation>Ruota 90° antiorario</translation>
    </message>
    <message>
      <source>Rotate image 180°</source>
      <translation>Ruota immagine 180°</translation>
    </message>
    <message>
      <source>Rotate image 90° clockwise</source>
      <translation>Ruota immagine 90° in senso orario</translation>
    </message>
    <message>
      <source>Rotate image 90° counterclockwise</source>
      <translation>Ruota immagine 90° in senso antiorario</translation>
    </message>
    <message>
      <source>Run GraXpert background extraction on the active image</source>
      <translation>Esegui estrazione sfondo GraXpert sull'immagine attiva</translation>
    </message>
    <message>
      <source>Run star removal on the active image</source>
      <translation>Esegui rimozione stelle sull'immagine attiva</translation>
    </message>
    <message>
      <source>SCNR-style green channel removal.</source>
      <translation>Rimozione canale verde stile SCNR.</translation>
    </message>
    <message>
      <source>Save As...</source>
      <translation>Salva come...</translation>
    </message>
    <message>
      <source>Save Project...</source>
      <translation>Salva progetto...</translation>
    </message>
    <message>
      <source>Save all views, histories, and shortcuts to a .sas file</source>
      <translation>Salva tutte le viste, cronologie e scorciatoie in un file .sas</translation>
    </message>
    <message>
      <source>Save the active image</source>
      <translation>Salva l'immagine attiva</translation>
    </message>
    <message>
      <source>Script Editor...</source>
      <translation>Editor script...</translation>
    </message>
    <message>
      <source>Select All Lines</source>
      <translation>Seleziona tutte le righe</translation>
    </message>
    <message>
      <source>Selective Color Correction...</source>
      <translation>Correzione colore selettiva...</translation>
    </message>
    <message>
      <source>Set Sigma...</source>
      <translation>Imposta Sigma...</translation>
    </message>
    <message>
      <source>Set Target Median...</source>
      <translation>Imposta mediana target...</translation>
    </message>
    <message>
      <source>Set the sigma for Display-Stretch (e.g., 5.0)</source>
      <translation>Imposta il sigma per Display-Stretch (es. 5.0)</translation>
    </message>
    <message>
      <source>Set the target median for Display-Stretch (e.g., 0.30)</source>
      <translation>Imposta la mediana target per Display-Stretch (es. 0.30)</translation>
    </message>
    <message>
      <source>Show Mask Overlay</source>
      <translation>Mostra overlay maschera</translation>
    </message>
    <message>
      <source>Signature / Insert...</source>
      <translation>Firma / Inserisci...</translation>
    </message>
    <message>
      <source>Smart Grid</source>
      <translation>Griglia intelligente</translation>
    </message>
    <message>
      <source>Solve WCS/SIP for the active image or a file</source>
      <translation>Risolvi WCS/SIP per l'immagine attiva o un file</translation>
    </message>
    <message>
      <source>Spectral Flux Color Calibration...</source>
      <translation>Calibrazione colore flusso spettrale...</translation>
    </message>
    <message>
      <source>Split into LF/HF and enhance HF (scale, wavelet, denoise)</source>
      <translation>Dividi in LF/HF e migliora HF (scala, wavelet, denoise)</translation>
    </message>
    <message>
      <source>Split the workspace into equal horizontal rows</source>
      <translation>Dividi lo spazio di lavoro in righe orizzontali uguali</translation>
    </message>
    <message>
      <source>Split the workspace into equal vertical columns</source>
      <translation>Dividi lo spazio di lavoro in colonne verticali uguali</translation>
    </message>
    <message>
      <source>Stacking Suite...</source>
      <translation>Stacking Suite...</translation>
    </message>
    <message>
      <source>Stacking! Darks, Flats, Lights, Calibration, Drizzle, and more!!</source>
      <translation>Stacking! Dark, Flat, Light, Calibrazione, Drizzle e altro!!</translation>
    </message>
    <message>
      <source>Star Stretch...</source>
      <translation>Star Stretch...</translation>
    </message>
    <message>
      <source>Start a new project? This closes all views and clears desktop shortcuts.</source>
      <translation>Iniziare un nuovo progetto? Questo chiuderà tutte le viste e cancellerà le scorciatoie del desktop.</translation>
    </message>
    <message>
      <source>Statistical Stretch...</source>
      <translation>Stretch statistico...</translation>
    </message>
    <message>
      <source>Statistics...</source>
      <translation>Statistiche...</translation>
    </message>
    <message>
      <source>Stellar Alignment...</source>
      <translation>Allineamento stellare...</translation>
    </message>
    <message>
      <source>Stellar Register...</source>
      <translation>Registrazione stellare...</translation>
    </message>
    <message>
      <source>Stretch the image using median/SD statistics</source>
      <translation>Stretcha l'immagine usando statistiche mediana/SD</translation>
    </message>
    <message>
      <source>Subtract per-channel minimum.
Click: active view
Alt+Drag: drop onto a view</source>
      <translation>Sottrai minimo per canale.
Click: vista attiva
Alt+Trascina: rilascia su una vista</translation>
    </message>
    <message>
      <source>Supernova / Asteroid Hunter...</source>
      <translation>Cacciatore Supernove / Asteroidi...</translation>
    </message>
    <message>
      <source>System Monitor</source>
      <translation>Monitor di Sistema</translation>
    </message>
    <message>
      <source>Tile Horizontally</source>
      <translation>Affianca orizzontalmente</translation>
    </message>
    <message>
      <source>Tile Vertically</source>
      <translation>Affianca verticalmente</translation>
    </message>
    <message>
      <source>Tile Views</source>
      <translation>Affianca viste</translation>
    </message>
    <message>
      <source>Tile all subwindows</source>
      <translation>Affianca tutte le sottofinestre</translation>
    </message>
    <message>
      <source>Toggle display auto-stretch for the active window</source>
      <translation>Attiva/disattiva auto-stretch per la finestra attiva</translation>
    </message>
    <message>
      <source>Toggle hard profile for Display-Stretch (H)</source>
      <translation>Attiva/disattiva profilo forte per Display-Stretch (H)</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>View Bundles...</source>
      <translation>Visualizza bundle...</translation>
    </message>
    <message>
      <source>View histogram and basic stats for the active image</source>
      <translation>Visualizza istogramma e statistiche base per l'immagine attiva</translation>
    </message>
    <message>
      <source>View/Edit FITS headers</source>
      <translation>Visualizza/Modifica header FITS</translation>
    </message>
    <message>
      <source>Wave-scale HDR with luminance-masked starlet</source>
      <translation>HDR wave-scale con starlet mascherato in luminanza</translation>
    </message>
    <message>
      <source>WaveScale Dark Enhancer...</source>
      <translation>WaveScale Dark Enhancer...</translation>
    </message>
    <message>
      <source>WaveScale HDR...</source>
      <translation>WaveScale HDR...</translation>
    </message>
    <message>
      <source>What's In My Image...</source>
      <translation>What's In My Image...</translation>
    </message>
    <message>
      <source>What's In My Sky...</source>
      <translation>What's In My Sky...</translation>
    </message>
    <message>
      <source>White Balance...</source>
      <translation>Bilanciamento bianco...</translation>
    </message>
    <message>
      <source>Write a ready-to-edit sample script into the scripts folder</source>
      <translation>Scrivi uno script di esempio pronto da modificare nella cartella script</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
    <message>
      <source>Zoom in</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom out</source>
      <translation>Riduci</translation>
    </message>
    <message>
      <source>Zoom to 100% (pixel-for-pixel)</source>
      <translation>Zoom al 100% (pixel per pixel)</translation>
    </message>
    <message>
      <source>View Bundles</source>
      <translation>Visualizza Combinazioni</translation>
    </message>
    <message>
      <source>Function Bundles</source>
      <translation>Combinazioni di Funzioni</translation>
    </message>
    <message>
      <source>Delete selected shortcut buttons</source>
      <translation>Elimina i pulsanti di scelta rapida selezionati</translation>
    </message>
    <message>
      <source>Toggle Display Auto-Stretch</source>
      <translation>Attiva/Disattiva Auto-Stretch Display</translation>
    </message>
    <message>
      <source>Invert the Image</source>
      <translation>Inverti l'immagine</translation>
    </message>
    <message>
      <source>Focus the command search bar; Enter runs first match</source>
      <translation>Focus barra ricerca comandi; Invio esegue primo match</translation>
    </message>
    <message>
      <source>Duplicate Image</source>
      <translation>Duplica immagine</translation>
    </message>
    <message>
      <source>Copy Zoom and Pan</source>
      <translation>Copia Zoom e Pan</translation>
    </message>
    <message>
      <source>Apply that image to the other as a mask</source>
      <translation>Applica immagine all'altra come maschera</translation>
    </message>
    <message>
      <source>Zoom to 100% (1:1)</source>
      <translation>Zoom al 100% (1:1)</translation>
    </message>
    <message>
      <source>Switch to previously active view</source>
      <translation>Passa alla vista attiva precedente</translation>
    </message>
    <message>
      <source>Switch to next active view</source>
      <translation>Passa alla vista attiva successiva</translation>
    </message>
    <message>
      <source>Create a desktop shortcut for that action</source>
      <translation>Crea una scorciatoia sul desktop per questa azione</translation>
    </message>
    <message>
      <source>Headless apply the shortcut's command/preset to a view</source>
      <translation>Applica comando/preset scorciatoia a vista (senza GUI)</translation>
    </message>
    <message>
      <source>Multi-select shortcut buttons</source>
      <translation>Selezione multipla pulsanti scorciatoia</translation>
    </message>
    <message>
      <source>Move selected shortcut buttons</source>
      <translation>Sposta pulsanti scorciatoia selezionati</translation>
    </message>
    <message>
      <source>Select all shortcut buttons</source>
      <translation>Seleziona tutti i pulsanti scorciatoia</translation>
    </message>
    <message>
      <source>Open files dialog</source>
      <translation>Apri finestra file</translation>
    </message>
    <message>
      <source>Add dragged view as a new layer (on top)</source>
      <translation>Aggiungi vista trascinata come nuovo livello (in alto)</translation>
    </message>
    <message>
      <source>Attach dragged image as mask to the selected layer</source>
      <translation>Allega immagine trascinata come maschera al livello</translation>
    </message>
    <message>
      <source>Draw a crop rectangle</source>
      <translation>Disegna rettangolo ritaglio</translation>
    </message>
    <message>
      <source>Resize crop rectangle</source>
      <translation>Ridimensiona rettangolo ritaglio</translation>
    </message>
    <message>
      <source>Rotate crop rectangle</source>
      <translation>Ruota rettangolo ritaglio</translation>
    </message>
    <message>
      <source>Loading a project will close current views and replace desktop shortcuts.
Continue?</source>
      <translation>Il caricamento di un progetto chiuderà le viste correnti e sostituirà le scorciatoie sul desktop.
Continuare?</translation>
    </message>
  </context>
  <context>
    <name>AstrobinExportTab</name>
    <message>
      <source> ({0} failed)</source>
      <translation> ({0} falliti)</translation>
    </message>
    <message>
      <source> — skipped {0} XISF (reader unavailable)</source>
      <translation> — saltati {0} XISF (reader non disponibile)</translation>
    </message>
    <message>
      <source># Subs</source>
      <translation># Sottopose</translation>
    </message>
    <message>
      <source>(e.g. 4408)</source>
      <translation>(es. 4408)</translation>
    </message>
    <message>
      <source>0–9</source>
      <translation>0–9</translation>
    </message>
    <message>
      <source>API Key</source>
      <translation>Chiave API</translation>
    </message>
    <message>
      <source>API Secret</source>
      <translation>Segreto API</translation>
    </message>
    <message>
      <source>Accessories</source>
      <translation>Accessori</translation>
    </message>
    <message>
      <source>Acquisition details</source>
      <translation>Dettagli acquisizione</translation>
    </message>
    <message>
      <source>Add Files…</source>
      <translation>Aggiungi File…</translation>
    </message>
    <message>
      <source>Add watermark</source>
      <translation>Aggiungi watermark</translation>
    </message>
    <message>
      <source>All selected files are already in the list.</source>
      <translation>Tutti i file selezionati sono già nella lista.</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>AstroBin Export</source>
      <translation>Esportazione AstroBin</translation>
    </message>
    <message>
      <source>Astrobin Export</source>
      <translation>Esporta su Astrobin</translation>
    </message>
    <message>
      <source>Astrobin Filter ID</source>
      <translation>ID Filtro Astrobin</translation>
    </message>
    <message>
      <source>Astrobin Link</source>
      <translation>Link Astrobin</translation>
    </message>
    <message>
      <source>Bandwidth</source>
      <translation>Larghezza Banda</translation>
    </message>
    <message>
      <source>Bias (#)</source>
      <translation>Bias (#)</translation>
    </message>
    <message>
      <source>Bortle</source>
      <translation>Bortle</translation>
    </message>
    <message>
      <source>Bortle scale</source>
      <translation>Scala Bortle</translation>
    </message>
    <message>
      <source>Brand</source>
      <translation>Marca</translation>
    </message>
    <message>
      <source>Browse Filters</source>
      <translation>Sfoglia Filtri</translation>
    </message>
    <message>
      <source>Browse...</source>
      <translation>Sfoglia...</translation>
    </message>
    <message>
      <source>CSV Files (*.csv);;All Files (*)</source>
      <translation>File CSV (*.csv);;Tutti i File (*)</translation>
    </message>
    <message>
      <source>CSV Load Error</source>
      <translation>Errore Caricamento CSV</translation>
    </message>
    <message>
      <source>CSV copied to clipboard.</source>
      <translation>CSV copiato negli appunti.</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation>Camera</translation>
    </message>
    <message>
      <source>Catalog CSV loaded.</source>
      <translation>CSV catalogo caricato.</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Cancella</translation>
    </message>
    <message>
      <source>Cleared. Load FITS via 'Select Folder…' or 'Add Files…' to begin.</source>
      <translation>Cancellato. Carica FITS tramite 'Seleziona Cartella…' o 'Aggiungi File…' per iniziare.</translation>
    </message>
    <message>
      <source>Copied</source>
      <translation>Copiato</translation>
    </message>
    <message>
      <source>Copy CSV</source>
      <translation>Copia CSV</translation>
    </message>
    <message>
      <source>Copy to Clipboard</source>
      <translation>Copia negli Appunti</translation>
    </message>
    <message>
      <source>Could not load Astrobin filters: {0}</source>
      <translation>Impossibile caricare filtri Astrobin: {0}</translation>
    </message>
    <message>
      <source>Could not load equipment CSV: {0}</source>
      <translation>Impossibile caricare CSV equipaggiamento: {0}</translation>
    </message>
    <message>
      <source>Could not load filter mapping CSV: {0}</source>
      <translation>Impossibile caricare CSV mappatura filtri: {0}</translation>
    </message>
    <message>
      <source>Could not save filter mapping CSV: {0}</source>
      <translation>Impossibile salvare CSV mappatura filtri: {0}</translation>
    </message>
    <message>
      <source>Credentials invalid</source>
      <translation>Credenziali non valide</translation>
    </message>
    <message>
      <source>Credentials valid</source>
      <translation>Credenziali valide</translation>
    </message>
    <message>
      <source>Darks (#)</source>
      <translation>Dark (#)</translation>
    </message>
    <message>
      <source>Data source</source>
      <translation>Fonte dati</translation>
    </message>
    <message>
      <source>Deep sky</source>
      <translation>Cielo profondo</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>Descrizione</translation>
    </message>
    <message>
      <source>Enter your AstroBin API key</source>
      <translation>Inserisci la tua chiave API AstroBin</translation>
    </message>
    <message>
      <source>Enter your AstroBin API secret</source>
      <translation>Inserisci il tuo segreto API AstroBin</translation>
    </message>
    <message>
      <source>Equipment</source>
      <translation>Attrezzatura</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Export settings</source>
      <translation>Impostazioni esportazione</translation>
    </message>
    <message>
      <source>Exposure (s)</source>
      <translation>Esposizione (s)</translation>
    </message>
    <message>
      <source>Exposure: {0}</source>
      <translation>Esposizione: {0}</translation>
    </message>
    <message>
      <source>FITS Files (*.fits *.fit *.fts);;All Files (*.*)</source>
      <translation>File FITS (*.fits *.fit *.fts);;Tutti i File (*.*)</translation>
    </message>
    <message>
      <source>FITS/XISF (*.fit *.fits *.xisf);;All Files (*)</source>
      <translation>FITS/XISF (*.fit *.fits *.xisf);;Tutti i File (*)</translation>
    </message>
    <message>
      <source>Failed to load filter mappings: {0}</source>
      <translation>Caricamento mappature filtri fallito: {0}</translation>
    </message>
    <message>
      <source>Failed to save filter mappings: {0}</source>
      <translation>Salvataggio mappature filtri fallito: {0}</translation>
    </message>
    <message>
      <source>Files (Object → Filter → Exposure)</source>
      <translation>File (Oggetto → Filtro → Esposizione)</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Filtro</translation>
    </message>
    <message>
      <source>Filter Browser</source>
      <translation>Browser Filtri</translation>
    </message>
    <message>
      <source>Filter mappings loaded successfully.</source>
      <translation>Mappature filtri caricate con successo.</translation>
    </message>
    <message>
      <source>Filter mappings saved successfully.</source>
      <translation>Mappature filtri salvate con successo.</translation>
    </message>
    <message>
      <source>Filter: {0}</source>
      <translation>Filtro: {0}</translation>
    </message>
    <message>
      <source>Filters</source>
      <translation>Filtri</translation>
    </message>
    <message>
      <source>Filters Found:</source>
      <translation>Filtri Trovati:</translation>
    </message>
    <message>
      <source>Flat-darks (#)</source>
      <translation>Flat-dark (#)</translation>
    </message>
    <message>
      <source>Flats (#)</source>
      <translation>Flat (#)</translation>
    </message>
    <message>
      <source>From active view</source>
      <translation>Da vista attiva</translation>
    </message>
    <message>
      <source>From file</source>
      <translation>Da file</translation>
    </message>
    <message>
      <source>Gear</source>
      <translation>Attrezzatura</translation>
    </message>
    <message>
      <source>Global inputs (used if FITS headers are missing/zero)</source>
      <translation>Input globali (usati se header FITS mancanti/zero)</translation>
    </message>
    <message>
      <source>Group nights noon → noon (local time)</source>
      <translation>Raggruppa notti mezzogiorno → mezzogiorno (ora locale)</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Image Information</source>
      <translation>Informazioni immagine</translation>
    </message>
    <message>
      <source>Image Selection</source>
      <translation>Selezione immagine</translation>
    </message>
    <message>
      <source>Image format</source>
      <translation>Formato immagine</translation>
    </message>
    <message>
      <source>Input Files</source>
      <translation>File di Input</translation>
    </message>
    <message>
      <source>Integration summary copied!</source>
      <translation>Riepilogo integrazione copiato!</translation>
    </message>
    <message>
      <source>Load Catalog</source>
      <translation>Carica Catalogo</translation>
    </message>
    <message>
      <source>Load FITS Headers</source>
      <translation>Carica Header FITS</translation>
    </message>
    <message>
      <source>Load FITS via 'Select Folder…' or 'Add Files…' to begin.</source>
      <translation>Carica FITS tramite 'Seleziona Cartella…' o 'Aggiungi File…' per iniziare.</translation>
    </message>
    <message>
      <source>Load FITS/XISF via 'Select Folder…' or 'Add Files…' to begin.</source>
      <translation>Carica FITS/XISF tramite 'Seleziona Cartella…' o 'Aggiungi File…' per iniziare.</translation>
    </message>
    <message>
      <source>Load Filter Mappings from CSV</source>
      <translation>Carica Mappature Filtri da CSV</translation>
    </message>
    <message>
      <source>Load Telescope/Camera from CSV</source>
      <translation>Carica Telescopio/Camera da CSV</translation>
    </message>
    <message>
      <source>Loaded {0} file(s)</source>
      <translation>Caricati {0} file</translation>
    </message>
    <message>
      <source>Loaded {0} filters.</source>
      <translation>Caricati {0} filtri.</translation>
    </message>
    <message>
      <source>Loading filters from Astrobin...</source>
      <translation>Caricamento filtri da Astrobin...</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Posizione</translation>
    </message>
    <message>
      <source>Manage Filter IDs…</source>
      <translation>Gestisci ID Filtri…</translation>
    </message>
    <message>
      <source>Maximum dimension</source>
      <translation>Dimensione massima</translation>
    </message>
    <message>
      <source>Mean FWHM</source>
      <translation>FWHM Medio</translation>
    </message>
    <message>
      <source>Mean SQM</source>
      <translation>SQM Medio</translation>
    </message>
    <message>
      <source>Mount</source>
      <translation>Montatura</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Nome</translation>
    </message>
    <message>
      <source>No .fit/.fits/.xisf files found.</source>
      <translation>Nessun file .fit/.fits/.xisf trovato.</translation>
    </message>
    <message>
      <source>No FITS files selected.</source>
      <translation>Nessun file FITS selezionato.</translation>
    </message>
    <message>
      <source>No Images</source>
      <translation>Nessuna Immagine</translation>
    </message>
    <message>
      <source>No New Files</source>
      <translation>Nessun Nuovo File</translation>
    </message>
    <message>
      <source>No integration data to copy.</source>
      <translation>Nessun dato di integrazione da copiare.</translation>
    </message>
    <message>
      <source>No mappings set</source>
      <translation>Nessun mapping impostato</translation>
    </message>
    <message>
      <source>Noctilucent clouds</source>
      <translation>Nubi nottilucenti</translation>
    </message>
    <message>
      <source>Northern lights</source>
      <translation>Aurora boreale</translation>
    </message>
    <message>
      <source>Nothing to copy</source>
      <translation>Niente da copiare</translation>
    </message>
    <message>
      <source>Object: {0}</source>
      <translation>Oggetto: {0}</translation>
    </message>
    <message>
      <source>Open AstroBin Equipment Explorer (Filters)</source>
      <translation>Apri AstroBin Equipment Explorer (Filtri)</translation>
    </message>
    <message>
      <source>Own data</source>
      <translation>Dati propri</translation>
    </message>
    <message>
      <source>Prevents splitting a single observing night at midnight.</source>
      <translation>Evita di dividere una singola notte osservativa a mezzanotte.</translation>
    </message>
    <message>
      <source>Processing details</source>
      <translation>Dettagli elaborazione</translation>
    </message>
    <message>
      <source>Quality</source>
      <translation>Qualità</translation>
    </message>
    <message>
      <source>Recompute</source>
      <translation>Ricalcola</translation>
    </message>
    <message>
      <source>Remote source</source>
      <translation>Sorgente remota</translation>
    </message>
    <message>
      <source>Resize</source>
      <translation>Ridimensiona</translation>
    </message>
    <message>
      <source>SQM value</source>
      <translation>Valore SQM</translation>
    </message>
    <message>
      <source>Save Filter Mapping CSV</source>
      <translation>Salva CSV Mappatura Filtri</translation>
    </message>
    <message>
      <source>Save Filter Mappings to CSV</source>
      <translation>Salva Mappature Filtri in CSV</translation>
    </message>
    <message>
      <source>Save credentials</source>
      <translation>Salva credenziali</translation>
    </message>
    <message>
      <source>Search:</source>
      <translation>Cerca:</translation>
    </message>
    <message>
      <source>Seeing</source>
      <translation>Seeing</translation>
    </message>
    <message>
      <source>Select</source>
      <translation>Seleziona</translation>
    </message>
    <message>
      <source>Select Equipment CSV</source>
      <translation>Seleziona CSV Equipaggiamento</translation>
    </message>
    <message>
      <source>Select FITS Files</source>
      <translation>Seleziona File FITS</translation>
    </message>
    <message>
      <source>Select FITS/XISF Files</source>
      <translation>Seleziona File FITS/XISF</translation>
    </message>
    <message>
      <source>Select Filter Mapping CSV</source>
      <translation>Seleziona CSV Mappatura Filtri</translation>
    </message>
    <message>
      <source>Select Folder Containing FITS/XISF Files</source>
      <translation>Seleziona Cartella Contenente File FITS/XISF</translation>
    </message>
    <message>
      <source>Select Folder…</source>
      <translation>Seleziona Cartella…</translation>
    </message>
    <message>
      <source>Select image to export</source>
      <translation>Seleziona immagine da esportare</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Dimensione</translation>
    </message>
    <message>
      <source>Software</source>
      <translation>Software</translation>
    </message>
    <message>
      <source>Solar system</source>
      <translation>Sistema solare</translation>
    </message>
    <message>
      <source>Star trails</source>
      <translation>Star trail</translation>
    </message>
    <message>
      <source>Subject type</source>
      <translation>Tipo soggetto</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Successo</translation>
    </message>
    <message>
      <source>Telescope</source>
      <translation>Telescopio</translation>
    </message>
    <message>
      <source>Telescope/Camera Selection:</source>
      <translation>Selezione Telescopio/Camera:</translation>
    </message>
    <message>
      <source>There is no CSV content yet.</source>
      <translation>Non c'è ancora contenuto CSV.</translation>
    </message>
    <message>
      <source>Title</source>
      <translation>Titolo</translation>
    </message>
    <message>
      <source>Total Frames:</source>
      <translation>Frame Totali:</translation>
    </message>
    <message>
      <source>Total Integration Time</source>
      <translation>Tempo Integrazione Totale</translation>
    </message>
    <message>
      <source>Total Integration:</source>
      <translation>Integrazione Totale:</translation>
    </message>
    <message>
      <source>Transparency</source>
      <translation>Trasparenza</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Tipo</translation>
    </message>
    <message>
      <source>Upload</source>
      <translation>Carica</translation>
    </message>
    <message>
      <source>Upload complete</source>
      <translation>Caricamento completato</translation>
    </message>
    <message>
      <source>Upload failed</source>
      <translation>Caricamento fallito</translation>
    </message>
    <message>
      <source>Upload to AstroBin</source>
      <translation>Carica su AstroBin</translation>
    </message>
    <message>
      <source>Uploading...</source>
      <translation>Caricamento...</translation>
    </message>
    <message>
      <source>Validate credentials</source>
      <translation>Valida credenziali</translation>
    </message>
    <message>
      <source>View on AstroBin</source>
      <translation>Visualizza su AstroBin</translation>
    </message>
    <message>
      <source>Watermark</source>
      <translation>Watermark</translation>
    </message>
    <message>
      <source>Watermark opacity</source>
      <translation>Opacità watermark</translation>
    </message>
    <message>
      <source>Watermark position</source>
      <translation>Posizione watermark</translation>
    </message>
    <message>
      <source>Watermark text</source>
      <translation>Testo watermark</translation>
    </message>
    <message>
      <source>Wide field</source>
      <translation>Campo largo</translation>
    </message>
    <message>
      <source>bias</source>
      <translation>bias</translation>
    </message>
    <message>
      <source>binning</source>
      <translation>binning</translation>
    </message>
    <message>
      <source>bortle</source>
      <translation>bortle</translation>
    </message>
    <message>
      <source>darks</source>
      <translation>dark</translation>
    </message>
    <message>
      <source>date</source>
      <translation>data</translation>
    </message>
    <message>
      <source>duration</source>
      <translation>durata</translation>
    </message>
    <message>
      <source>e.g. 2.10</source>
      <translation>es. 2.10</translation>
    </message>
    <message>
      <source>e.g. 21.30</source>
      <translation>es. 21.30</translation>
    </message>
    <message>
      <source>e.g. 4.0</source>
      <translation>es. 4.0</translation>
    </message>
    <message>
      <source>e.g. 4408</source>
      <translation>es. 4408</translation>
    </message>
    <message>
      <source>f/number</source>
      <translation>f/numero</translation>
    </message>
    <message>
      <source>fNumber</source>
      <translation>fNumber</translation>
    </message>
    <message>
      <source>filter</source>
      <translation>filtro</translation>
    </message>
    <message>
      <source>flatDarks</source>
      <translation>flatDark</translation>
    </message>
    <message>
      <source>flats</source>
      <translation>flat</translation>
    </message>
    <message>
      <source>gain</source>
      <translation>gain</translation>
    </message>
    <message>
      <source>h</source>
      <translation>h</translation>
    </message>
    <message>
      <source>iso</source>
      <translation>iso</translation>
    </message>
    <message>
      <source>m</source>
      <translation>m</translation>
    </message>
    <message>
      <source>meanFwhm</source>
      <translation>fwhmMedio</translation>
    </message>
    <message>
      <source>meanSqm</source>
      <translation>sqmMedio</translation>
    </message>
    <message>
      <source>number</source>
      <translation>numero</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>sensorCooling</source>
      <translation>raffreddamentoSensore</translation>
    </message>
    <message>
      <source>temperature</source>
      <translation>temperatura</translation>
    </message>
  </context>
  <context>
    <name>AstrobinExporterDialog</name>
    <message>
      <source>AstroBin Exporter</source>
      <translation>Esportatore AstroBin</translation>
    </message>
  </context>
  <context>
    <name>BackgroundNeutralizationDialog</name>
    <message>
      <source>Apply Neutralization</source>
      <translation>Applica neutralizzazione</translation>
    </message>
    <message>
      <source>Background Neutralization</source>
      <translation>Neutralizzazione sfondo</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Enable Auto-Stretch</source>
      <translation>Abilita auto-stretch</translation>
    </message>
    <message>
      <source>Find Background</source>
      <translation>Trova sfondo</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Blu</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Current Background</source>
      <translation>Sfondo attuale</translation>
    </message>
    <message>
      <source>Custom</source>
      <translation>Personalizzato</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Verde</translation>
    </message>
    <message>
      <source>Neutral Gray</source>
      <translation>Grigio neutro</translation>
    </message>
    <message>
      <source>Pick Region</source>
      <translation>Seleziona regione</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Red</source>
      <translation>Rosso</translation>
    </message>
    <message>
      <source>Region Size</source>
      <translation>Dimensione regione</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Sample Region</source>
      <translation>Regione campione</translation>
    </message>
    <message>
      <source>Target Background</source>
      <translation>Sfondo target</translation>
    </message>
    <message>
      <source>Target Color</source>
      <translation>Colore target</translation>
    </message>
  </context>
  <context>
    <name>BatchConvertDialog</name>
    <message>
      <source>Batch Convert</source>
      <translation>Conversione batch</translation>
    </message>
    <message>
      <source>Bit depth:</source>
      <translation>Profondità bit:</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Output format:</source>
      <translation>Formato output:</translation>
    </message>
    <message>
      <source>Start</source>
      <translation>Avvia</translation>
    </message>
    <message>
      <source>16-bit</source>
      <translation>16-bit</translation>
    </message>
    <message>
      <source>32-bit float</source>
      <translation>32-bit float</translation>
    </message>
    <message>
      <source>8-bit</source>
      <translation>8-bit</translation>
    </message>
    <message>
      <source>Add Files...</source>
      <translation>Aggiungi file...</translation>
    </message>
    <message>
      <source>Add Folder...</source>
      <translation>Aggiungi cartella...</translation>
    </message>
    <message>
      <source>Bit Depth</source>
      <translation>Profondità bit</translation>
    </message>
    <message>
      <source>Browse...</source>
      <translation>Sfoglia...</translation>
    </message>
    <message>
      <source>Clear All</source>
      <translation>Cancella tutto</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Complete</source>
      <translation>Completo</translation>
    </message>
    <message>
      <source>Convert</source>
      <translation>Converti</translation>
    </message>
    <message>
      <source>Converted {0} files</source>
      <translation>Convertiti {0} file</translation>
    </message>
    <message>
      <source>Converting file {0} of {1}</source>
      <translation>Conversione file {0} di {1}</translation>
    </message>
    <message>
      <source>Custom directory</source>
      <translation>Cartella personalizzata</translation>
    </message>
    <message>
      <source>Input Files</source>
      <translation>File di input</translation>
    </message>
    <message>
      <source>Output Directory</source>
      <translation>Cartella di output</translation>
    </message>
    <message>
      <source>Output Format</source>
      <translation>Formato output</translation>
    </message>
    <message>
      <source>Output Settings</source>
      <translation>Impostazioni output</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Remove Selected</source>
      <translation>Rimuovi selezionati</translation>
    </message>
    <message>
      <source>Same as input</source>
      <translation>Come input</translation>
    </message>
  </context>
  <context>
    <name>BatchFITSHeaderDialog</name>
    <message>
      <source>Add if missing (for Add/Update)</source>
      <translation>Aggiungi se mancante (per Aggiungi/Aggiorna)</translation>
    </message>
    <message>
      <source>Add/Update</source>
      <translation>Aggiungi/Aggiorna</translation>
    </message>
    <message>
      <source>Apply to all HDUs</source>
      <translation>Applica a tutti gli HDU</translation>
    </message>
    <message>
      <source>Batch Complete</source>
      <translation>Batch completato</translation>
    </message>
    <message>
      <source>Batch Modify FITS Headers</source>
      <translation>Modifica batch header FITS</translation>
    </message>
    <message>
      <source>Choose FITS Files…</source>
      <translation>Scegli file FITS…</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Comment (optional)</source>
      <translation>Commento (opzionale)</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Elimina</translation>
    </message>
    <message>
      <source>FITS files (*.fits *.fit *.fts *.fz)</source>
      <translation>File FITS (*.fits *.fit *.fts *.fz)</translation>
    </message>
    <message>
      <source>KEYWORD</source>
      <translation>PAROLA CHIAVE</translation>
    </message>
    <message>
      <source>Missing keyword</source>
      <translation>Parola chiave mancante</translation>
    </message>
    <message>
      <source>No files</source>
      <translation>Nessun file</translation>
    </message>
    <message>
      <source>No files selected</source>
      <translation>Nessun file selezionato</translation>
    </message>
    <message>
      <source>Please choose one or more FITS files.</source>
      <translation>Seleziona uno o più file FITS.</translation>
    </message>
    <message>
      <source>Please enter a FITS keyword.</source>
      <translation>Inserisci una parola chiave FITS.</translation>
    </message>
    <message>
      <source>Run</source>
      <translation>Esegui</translation>
    </message>
    <message>
      <source>Select FITS files</source>
      <translation>Seleziona file FITS</translation>
    </message>
    <message>
      <source>Updated {0} file(s); {1} error(s).</source>
      <translation>Aggiornati {0} file; {1} errori.</translation>
    </message>
    <message>
      <source>Value (leave blank for delete)</source>
      <translation>Valore (lascia vuoto per eliminare)</translation>
    </message>
    <message>
      <source>{0} files selected</source>
      <translation>{0} file selezionati</translation>
    </message>
  </context>
  <context>
    <name>BatchRenamerDialog</name>
    <message>
      <source>(optional) Rename into this folder; leave empty to rename in place</source>
      <translation>(opzionale) Rinomina in questa cartella; lascia vuoto per rinominare in loco</translation>
    </message>
    <message>
      <source>Add FITS files</source>
      <translation>Aggiungi file FITS</translation>
    </message>
    <message>
      <source>Add Files...</source>
      <translation>Aggiungi file...</translation>
    </message>
    <message>
      <source>Add Files…</source>
      <translation>Aggiungi File…</translation>
    </message>
    <message>
      <source>Add Folder...</source>
      <translation>Aggiungi cartella...</translation>
    </message>
    <message>
      <source>All files renamed.</source>
      <translation>Tutti i file rinominati.</translation>
    </message>
    <message>
      <source>Apply Rename</source>
      <translation>Applica Rinomina</translation>
    </message>
    <message>
      <source>As is</source>
      <translation>Come è</translation>
    </message>
    <message>
      <source>Available FITS keywords (double-click to insert):</source>
      <translation>Keyword FITS disponibili (doppio clic per inserire):</translation>
    </message>
    <message>
      <source>Available tokens</source>
      <translation>Token disponibili</translation>
    </message>
    <message>
      <source>Available tokens: {name}, {date}, {time}, {counter}, {ext}</source>
      <translation>Token disponibili: {name}, {date}, {time}, {counter}, {ext}</translation>
    </message>
    <message>
      <source>Batch File Renamer</source>
      <translation>Rinominatore File in Batch</translation>
    </message>
    <message>
      <source>Batch Rename</source>
      <translation>Rinomina in batch</translation>
    </message>
    <message>
      <source>Batch Rename from FITS</source>
      <translation>Rinomina in batch da FITS</translation>
    </message>
    <message>
      <source>Browse...</source>
      <translation>Sfoglia...</translation>
    </message>
    <message>
      <source>Browse…</source>
      <translation>Sfoglia…</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Case</source>
      <translation>Maiuscole/Minuscole</translation>
    </message>
    <message>
      <source>Case sensitive</source>
      <translation>Maiuscole/minuscole</translation>
    </message>
    <message>
      <source>Choose Destination Folder</source>
      <translation>Scegli Cartella Destinazione</translation>
    </message>
    <message>
      <source>Clear All</source>
      <translation>Cancella tutto</translation>
    </message>
    <message>
      <source>Clear Selections</source>
      <translation>Cancella Selezioni</translation>
    </message>
    <message>
      <source>Collisions</source>
      <translation>Collisioni</translation>
    </message>
    <message>
      <source>Complete</source>
      <translation>Completato</translation>
    </message>
    <message>
      <source>Copy files</source>
      <translation>Copia file</translation>
    </message>
    <message>
      <source>Counter Padding</source>
      <translation>Padding Contatore</translation>
    </message>
    <message>
      <source>Counter Start</source>
      <translation>Inizio Contatore</translation>
    </message>
    <message>
      <source>Current Name</source>
      <translation>Nome Attuale</translation>
    </message>
    <message>
      <source>Custom folder</source>
      <translation>Cartella personalizzata</translation>
    </message>
    <message>
      <source>Date format</source>
      <translation>Formato data</translation>
    </message>
    <message>
      <source>Destination:</source>
      <translation>Destinazione:</translation>
    </message>
    <message>
      <source>Done</source>
      <translation>Completato</translation>
    </message>
    <message>
      <source>Done with errors</source>
      <translation>Completato con errori</translation>
    </message>
    <message>
      <source>Dry Run</source>
      <translation>Prova a Secco</translation>
    </message>
    <message>
      <source>ERROR: {0}</source>
      <translation>ERRORE: {0}</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Error renaming files: {0}</source>
      <translation>Errore nella rinomina dei file: {0}</translation>
    </message>
    <message>
      <source>FITS files (*.fit *.fits *.fts *.fz);;All files (*)</source>
      <translation>File FITS (*.fit *.fits *.fts *.fz);;Tutti i file (*)</translation>
    </message>
    <message>
      <source>Failed to rename {0} files</source>
      <translation>Rinomina fallita per {0} file</translation>
    </message>
    <message>
      <source>File already exists</source>
      <translation>File già esistente</translation>
    </message>
    <message>
      <source>Filename pattern</source>
      <translation>Pattern nome file</translation>
    </message>
    <message>
      <source>Files renamed successfully.</source>
      <translation>File rinominati con successo.</translation>
    </message>
    <message>
      <source>Filter Pattern</source>
      <translation>Filtro Pattern</translation>
    </message>
    <message>
      <source>Find</source>
      <translation>Trova</translation>
    </message>
    <message>
      <source>Include Subfolders</source>
      <translation>Includi Sottocartelle</translation>
    </message>
    <message>
      <source>Index start:</source>
      <translation>Inizio indice:</translation>
    </message>
    <message>
      <source>Insert</source>
      <translation>Inserisci</translation>
    </message>
    <message>
      <source>Insert token</source>
      <translation>Inserisci token</translation>
    </message>
    <message>
      <source>Lowercase</source>
      <translation>Minuscole</translation>
    </message>
    <message>
      <source>Move files</source>
      <translation>Sposta file</translation>
    </message>
    <message>
      <source>New Name</source>
      <translation>Nuovo Nome</translation>
    </message>
    <message>
      <source>New name</source>
      <translation>Nuovo nome</translation>
    </message>
    <message>
      <source>No files found matching the pattern.</source>
      <translation>Nessun file trovato corrispondente al pattern.</translation>
    </message>
    <message>
      <source>No files to rename.</source>
      <translation>Nessun file da rinominare.</translation>
    </message>
    <message>
      <source>No previous rename operation to undo.</source>
      <translation>Nessuna operazione di rinomina precedente da annullare.</translation>
    </message>
    <message>
      <source>Old path</source>
      <translation>Percorso vecchio</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Opzioni</translation>
    </message>
    <message>
      <source>Original Name</source>
      <translation>Nome originale</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Output</translation>
    </message>
    <message>
      <source>Overwrite</source>
      <translation>Sovrascrivi</translation>
    </message>
    <message>
      <source>Overwrite all</source>
      <translation>Sovrascrivi tutto</translation>
    </message>
    <message>
      <source>Overwrite?</source>
      <translation>Sovrascrivere?</translation>
    </message>
    <message>
      <source>Padding</source>
      <translation>Padding</translation>
    </message>
    <message>
      <source>Pattern</source>
      <translation>Pattern</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Preview Changes</source>
      <translation>Anteprima Modifiche</translation>
    </message>
    <message>
      <source>Processing</source>
      <translation>Elaborazione</translation>
    </message>
    <message>
      <source>Remove Selected</source>
      <translation>Rimuovi selezionati</translation>
    </message>
    <message>
      <source>Rename</source>
      <translation>Rinomina</translation>
    </message>
    <message>
      <source>Rename All</source>
      <translation>Rinomina tutto</translation>
    </message>
    <message>
      <source>Rename Collision</source>
      <translation>Collisione Rinomina</translation>
    </message>
    <message>
      <source>Rename Pattern</source>
      <translation>Pattern Rinomina</translation>
    </message>
    <message>
      <source>Renamed {0} files</source>
      <translation>Rinominati {0} file</translation>
    </message>
    <message>
      <source>Renaming files...</source>
      <translation>Rinomina file in corso...</translation>
    </message>
    <message>
      <source>Renaming...</source>
      <translation>Rinomina...</translation>
    </message>
    <message>
      <source>Replace</source>
      <translation>Sostituisci</translation>
    </message>
    <message>
      <source>Replace with</source>
      <translation>Sostituisci con</translation>
    </message>
    <message>
      <source>Same folder</source>
      <translation>Stessa cartella</translation>
    </message>
    <message>
      <source>Scan Folder…</source>
      <translation>Scansiona Cartella…</translation>
    </message>
    <message>
      <source>Select Folder</source>
      <translation>Seleziona Cartella</translation>
    </message>
    <message>
      <source>Select Source Folder</source>
      <translation>Seleziona Cartella Sorgente</translation>
    </message>
    <message>
      <source>Select a folder or add files…</source>
      <translation>Seleziona una cartella o aggiungi file…</translation>
    </message>
    <message>
      <source>Separator</source>
      <translation>Separatore</translation>
    </message>
    <message>
      <source>Skip</source>
      <translation>Salta</translation>
    </message>
    <message>
      <source>Skip all</source>
      <translation>Salta tutto</translation>
    </message>
    <message>
      <source>Some files could not be renamed ({0} errors).</source>
      <translation>Alcuni file non sono stati rinominati ({0} errori).</translation>
    </message>
    <message>
      <source>Some files would have the same name after renaming. Please adjust the pattern.</source>
      <translation>Alcuni file avrebbero lo stesso nome dopo la rinomina. Modifica il pattern.</translation>
    </message>
    <message>
      <source>Source Files</source>
      <translation>File sorgente</translation>
    </message>
    <message>
      <source>Source Folder</source>
      <translation>Cartella Sorgente</translation>
    </message>
    <message>
      <source>Source:</source>
      <translation>Sorgente:</translation>
    </message>
    <message>
      <source>Start number</source>
      <translation>Numero iniziale</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Stato</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Successo</translation>
    </message>
    <message>
      <source>Template:</source>
      <translation>Template:</translation>
    </message>
    <message>
      <source>Time format</source>
      <translation>Formato ora</translation>
    </message>
    <message>
      <source>Title case</source>
      <translation>Prima maiuscola</translation>
    </message>
    <message>
      <source>Two or more files would map to the same name. Adjust your pattern.</source>
      <translation>Due o più file avrebbero lo stesso nome. Modifica il pattern.</translation>
    </message>
    <message>
      <source>Undo Last Rename</source>
      <translation>Annulla Ultima Rinomina</translation>
    </message>
    <message>
      <source>Uppercase</source>
      <translation>Maiuscole</translation>
    </message>
    <message>
      <source>Use regex</source>
      <translation>Usa regex</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Attenzione</translation>
    </message>
    <message>
      <source>append .{ext} if missing</source>
      <translation>aggiungi .{ext} se mancante</translation>
    </message>
    <message>
      <source>e.g. *.fits, *.tif</source>
      <translation>es. *.fits, *.tif</translation>
    </message>
    <message>
      <source>e.g. LIGHT_{FILTER}_{EXPOSURE:.0f}s_{DATE-OBS:%Y%m%d}_{#03}.{ext}</source>
      <translation>es. LIGHT_{FILTER}_{EXPOSURE:.0f}s_{DATE-OBS:%Y%m%d}_{#03}.{ext}</translation>
    </message>
    <message>
      <source>e.g. {name}_{date}_{counter}</source>
      <translation>es. {name}_{date}_{counter}</translation>
    </message>
    <message>
      <source>lowercase</source>
      <translation>minuscolo</translation>
    </message>
    <message>
      <source>name collision</source>
      <translation>collisione nome</translation>
    </message>
    <message>
      <source>ok</source>
      <translation>ok</translation>
    </message>
    <message>
      <source>renamed</source>
      <translation>rinominato</translation>
    </message>
    <message>
      <source>spaces→_</source>
      <translation>spazi→_</translation>
    </message>
    <message>
      <source>will overwrite</source>
      <translation>sovrascriverà</translation>
    </message>
  </context>
  <context>
    <name>BatchSettingsDialog</name>
    <message>
      <source>Apply to All</source>
      <translation>Applica a Tutti</translation>
    </message>
    <message>
      <source>Batch Settings</source>
      <translation>Impostazioni Batch</translation>
    </message>
    <message>
      <source>Bit Depth</source>
      <translation>Profondità Bit</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Exposure Time (seconds):</source>
      <translation>Tempo Esposizione (secondi):</translation>
    </message>
    <message>
      <source>Filter:</source>
      <translation>Filtro:</translation>
    </message>
    <message>
      <source>Image Type (IMAGETYP):</source>
      <translation>Tipo Immagine (IMAGETYP):</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Output Format</source>
      <translation>Formato Output</translation>
    </message>
    <message>
      <source>Set Type, Exposure, and Filter for All Files</source>
      <translation>Imposta Tipo, Esposizione e Filtro per Tutti i File</translation>
    </message>
  </context>
  <context>
    <name>BlemishBlasterDialogPro</name>
    <message>
      <source>Apply to Document</source>
      <translation>Applica al documento</translation>
    </message>
    <message>
      <source>Auto-stretch preview</source>
      <translation>Anteprima auto-stretch</translation>
    </message>
    <message>
      <source>Blemish Blaster</source>
      <translation>Blemish Blaster</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Controls</source>
      <translation>Controlli</translation>
    </message>
    <message>
      <source>Feather:</source>
      <translation>Sfumatura:</translation>
    </message>
    <message>
      <source>Linked color channels</source>
      <translation>Canali colore collegati</translation>
    </message>
    <message>
      <source>Opacity:</source>
      <translation>Opacità:</translation>
    </message>
    <message>
      <source>Radius:</source>
      <translation>Raggio:</translation>
    </message>
    <message>
      <source>Redo</source>
      <translation>Ripeti</translation>
    </message>
    <message>
      <source>Target median:</source>
      <translation>Mediana target:</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Annulla</translation>
    </message>
  </context>
  <context>
    <name>BlinkComparatorPro</name>
    <message>
      <source>Blink Comparator</source>
      <translation>Comparatore Blink</translation>
    </message>
  </context>
  <context>
    <name>BlinkTab</name>
    <message>
      <source>

{0} file(s) could not be renamed:</source>
      <translation>

{0} file non sono stati rinominati:</translation>
    </message>
    <message>
      <source>0 = infinite</source>
      <translation>0 = infinito</translation>
    </message>
    <message>
      <source>Absolute Difference</source>
      <translation>Differenza Assoluta</translation>
    </message>
    <message>
      <source>Add Additional</source>
      <translation>Aggiungi Altri</translation>
    </message>
    <message>
      <source>Add Additional Images</source>
      <translation>Aggiungi Immagini Aggiuntive</translation>
    </message>
    <message>
      <source>Add Frames</source>
      <translation>Aggiungi Frame</translation>
    </message>
    <message>
      <source>Add Images</source>
      <translation>Aggiungi immagini</translation>
    </message>
    <message>
      <source>Aggressive Stretch</source>
      <translation>Stretch Aggressivo</translation>
    </message>
    <message>
      <source>Align images</source>
      <translation>Allinea immagini</translation>
    </message>
    <message>
      <source>Aligning frames...</source>
      <translation>Allineamento frame...</translation>
    </message>
    <message>
      <source>Aligning...</source>
      <translation>Allineamento...</translation>
    </message>
    <message>
      <source>Alignment Method:</source>
      <translation>Metodo Allineamento:</translation>
    </message>
    <message>
      <source>Alignment complete</source>
      <translation>Allineamento completato</translation>
    </message>
    <message>
      <source>Alignment complete.</source>
      <translation>Allineamento completato.</translation>
    </message>
    <message>
      <source>Alignment failed</source>
      <translation>Allineamento fallito</translation>
    </message>
    <message>
      <source>Alignment failed: {0}</source>
      <translation>Allineamento fallito: {0}</translation>
    </message>
    <message>
      <source>All</source>
      <translation>Tutti</translation>
    </message>
    <message>
      <source>Apply to All Frames</source>
      <translation>Applica a Tutti i Frame</translation>
    </message>
    <message>
      <source>Are you sure you want to clear all loaded images?</source>
      <translation>Sei sicuro di voler cancellare tutte le immagini caricate?</translation>
    </message>
    <message>
      <source>Are you sure you want to permanently delete {0} flagged images? This action is irreversible.</source>
      <translation>Sei sicuro di voler eliminare permanentemente {0} immagini segnate? Questa azione è irreversibile.</translation>
    </message>
    <message>
      <source>Are you sure you want to permanently delete {0} selected images? This action is irreversible.</source>
      <translation>Sei sicuro di voler eliminare permanentemente {0} immagini selezionate? Questa azione è irreversibile.</translation>
    </message>
    <message>
      <source>Auto Align Frames</source>
      <translation>Allinea Frame Automaticamente</translation>
    </message>
    <message>
      <source>Auto Stretch</source>
      <translation>Auto Stretch</translation>
    </message>
    <message>
      <source>Auto-align</source>
      <translation>Allineamento auto</translation>
    </message>
    <message>
      <source>Auto-stretch</source>
      <translation>Auto-stretch</translation>
    </message>
    <message>
      <source>Batch Deletion</source>
      <translation>Eliminazione in Batch</translation>
    </message>
    <message>
      <source>Batch Move</source>
      <translation>Spostamento in Batch</translation>
    </message>
    <message>
      <source>Batch Operations</source>
      <translation>Operazioni Batch</translation>
    </message>
    <message>
      <source>Batch Rename</source>
      <translation>Rinomina in Batch</translation>
    </message>
    <message>
      <source>Batch Rename Selected…</source>
      <translation>Rinomina Selezionati in Batch…</translation>
    </message>
    <message>
      <source>Blink</source>
      <translation>Blink</translation>
    </message>
    <message>
      <source>Blink Comparator</source>
      <translation>Comparatore Blink</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Cancel Export</source>
      <translation>Annulla Esportazione</translation>
    </message>
    <message>
      <source>Clear All</source>
      <translation>Cancella Tutto</translation>
    </message>
    <message>
      <source>Clear All Images</source>
      <translation>Cancella Tutte le Immagini</translation>
    </message>
    <message>
      <source>Clear Flags</source>
      <translation>Cancella Segnalazioni</translation>
    </message>
    <message>
      <source>Clear Images</source>
      <translation>Cancella Immagini</translation>
    </message>
    <message>
      <source>Clear marks</source>
      <translation>Cancella segni</translation>
    </message>
    <message>
      <source>Confirm Batch Deletion</source>
      <translation>Conferma Eliminazione in Batch</translation>
    </message>
    <message>
      <source>Confirm Delete</source>
      <translation>Conferma Eliminazione</translation>
    </message>
    <message>
      <source>Confirm Deletion</source>
      <translation>Conferma Eliminazione</translation>
    </message>
    <message>
      <source>Copy coordinates</source>
      <translation>Copia coordinate</translation>
    </message>
    <message>
      <source>Crop All</source>
      <translation>Ritaglia Tutti</translation>
    </message>
    <message>
      <source>Crossfade</source>
      <translation>Dissolvenza Incrociata</translation>
    </message>
    <message>
      <source>Current frame</source>
      <translation>Frame corrente</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Data</translation>
    </message>
    <message>
      <source>Delay (ms)</source>
      <translation>Ritardo (ms)</translation>
    </message>
    <message>
      <source>Delete All Flagged Images</source>
      <translation>Elimina Tutte le Immagini Segnate</translation>
    </message>
    <message>
      <source>Delete Flagged</source>
      <translation>Elimina Segnati</translation>
    </message>
    <message>
      <source>Delete Selected Items</source>
      <translation>Elimina Elementi Selezionati</translation>
    </message>
    <message>
      <source>Delete flagged frame(s)?</source>
      <translation>Eliminare i frame segnati?</translation>
    </message>
    <message>
      <source>Deleted {0} flagged images.</source>
      <translation>Eliminate {0} immagini segnate.</translation>
    </message>
    <message>
      <source>Difference Mode</source>
      <translation>Modalità Differenza</translation>
    </message>
    <message>
      <source>Difference mode</source>
      <translation>Modalità differenza</translation>
    </message>
    <message>
      <source>Difference threshold</source>
      <translation>Soglia differenza</translation>
    </message>
    <message>
      <source>Doc Manager</source>
      <translation>Gestore Doc</translation>
    </message>
    <message>
      <source>DocManager lacks open_array/open_numpy/create_document</source>
      <translation>DocManager manca di open_array/open_numpy/create_document</translation>
    </message>
    <message>
      <source>DocManager returned no document.</source>
      <translation>DocManager non ha restituito nessun documento.</translation>
    </message>
    <message>
      <source>Document Manager</source>
      <translation>Gestore Documenti</translation>
    </message>
    <message>
      <source>Duplicate Frame</source>
      <translation>Duplica Frame</translation>
    </message>
    <message>
      <source>Duration:</source>
      <translation>Durata:</translation>
    </message>
    <message>
      <source>Empty image</source>
      <translation>Immagine vuota</translation>
    </message>
    <message>
      <source>Enter a prefix or suffix to rename selected files:</source>
      <translation>Inserisci prefisso o suffisso per rinominare i file selezionati:</translation>
    </message>
    <message>
      <source>Enter new name:</source>
      <translation>Inserisci nuovo nome:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Export</source>
      <translation>Esporta</translation>
    </message>
    <message>
      <source>Export All as FITS</source>
      <translation>Esporta Tutti come FITS</translation>
    </message>
    <message>
      <source>Export All as PNG</source>
      <translation>Esporta Tutti come PNG</translation>
    </message>
    <message>
      <source>Export All as TIFF</source>
      <translation>Esporta Tutti come TIFF</translation>
    </message>
    <message>
      <source>Export Blink Video</source>
      <translation>Esporta Video Blink</translation>
    </message>
    <message>
      <source>Export Frames</source>
      <translation>Esporta Frame</translation>
    </message>
    <message>
      <source>Export GIF</source>
      <translation>Esporta GIF</translation>
    </message>
    <message>
      <source>Export Video</source>
      <translation>Esporta Video</translation>
    </message>
    <message>
      <source>Export Video…</source>
      <translation>Esporta Video…</translation>
    </message>
    <message>
      <source>Export animation</source>
      <translation>Esporta animazione</translation>
    </message>
    <message>
      <source>Export canceled.</source>
      <translation>Esportazione annullata.</translation>
    </message>
    <message>
      <source>Export cancelled.</source>
      <translation>Esportazione annullata.</translation>
    </message>
    <message>
      <source>Export marks</source>
      <translation>Esporta segni</translation>
    </message>
    <message>
      <source>Export only selected frames</source>
      <translation>Esporta solo frame selezionati</translation>
    </message>
    <message>
      <source>Export video</source>
      <translation>Esporta video</translation>
    </message>
    <message>
      <source>Exporting video...</source>
      <translation>Esportazione video...</translation>
    </message>
    <message>
      <source>Exposure: {0}</source>
      <translation>Esposizione: {0}</translation>
    </message>
    <message>
      <source>FITS header</source>
      <translation>Header FITS</translation>
    </message>
    <message>
      <source>FPS:</source>
      <translation>FPS:</translation>
    </message>
    <message>
      <source>Failed to create document:
{0}</source>
      <translation>Creazione documento fallita:
{0}</translation>
    </message>
    <message>
      <source>Failed to load frame: {0}</source>
      <translation>Caricamento frame fallito: {0}</translation>
    </message>
    <message>
      <source>Failed to move {0}: {1}</source>
      <translation>Spostamento {0} fallito: {1}</translation>
    </message>
    <message>
      <source>Failed to open subwindow:
{0}</source>
      <translation>Apertura sottofinestra fallita:
{0}</translation>
    </message>
    <message>
      <source>Failed to rename the file: {0}</source>
      <translation>Rinomina file fallita: {0}</translation>
    </message>
    <message>
      <source>Filename</source>
      <translation>Nome File</translation>
    </message>
    <message>
      <source>Filter: {0}</source>
      <translation>Filtro: {0}</translation>
    </message>
    <message>
      <source>First</source>
      <translation>Primo</translation>
    </message>
    <message>
      <source>First Frame</source>
      <translation>Primo Frame</translation>
    </message>
    <message>
      <source>Fit to Preview</source>
      <translation>Adatta all'Anteprima</translation>
    </message>
    <message>
      <source>Flag</source>
      <translation>Bandiera</translation>
    </message>
    <message>
      <source>Flag All</source>
      <translation>Segna Tutti</translation>
    </message>
    <message>
      <source>Flag Selected</source>
      <translation>Segna Selezionati</translation>
    </message>
    <message>
      <source>Flagged frames moved to: {0}</source>
      <translation>Frame segnati spostati in: {0}</translation>
    </message>
    <message>
      <source>Frame</source>
      <translation>Frame</translation>
    </message>
    <message>
      <source>Frame Rate:</source>
      <translation>Framerate:</translation>
    </message>
    <message>
      <source>Frame rate</source>
      <translation>Frame rate</translation>
    </message>
    <message>
      <source>Frame {0} of {1}</source>
      <translation>Frame {0} di {1}</translation>
    </message>
    <message>
      <source>Frames exported to: {0}</source>
      <translation>Frame esportati in: {0}</translation>
    </message>
    <message>
      <source>Frames loaded successfully.</source>
      <translation>Frame caricati con successo.</translation>
    </message>
    <message>
      <source>Full Affine</source>
      <translation>Affine Completo</translation>
    </message>
    <message>
      <source>GIF Files (*.gif)</source>
      <translation>File GIF (*.gif)</translation>
    </message>
    <message>
      <source>GIF export failed: {0}</source>
      <translation>Esportazione GIF fallita: {0}</translation>
    </message>
    <message>
      <source>GIF exported: {0}</source>
      <translation>GIF esportato: {0}</translation>
    </message>
    <message>
      <source>Hide Flagged</source>
      <translation>Nascondi Segnati</translation>
    </message>
    <message>
      <source>Highlight differences</source>
      <translation>Evidenzia differenze</translation>
    </message>
    <message>
      <source>Homography</source>
      <translation>Omografia</translation>
    </message>
    <message>
      <source>Image Files</source>
      <translation>File Immagine</translation>
    </message>
    <message>
      <source>Image Files (*.fits *.fit *.tif *.tiff *.png *.jpg *.jpeg);;All Files (*)</source>
      <translation>File Immagine (*.fits *.fit *.tif *.tiff *.png *.jpg *.jpeg);;Tutti i File (*)</translation>
    </message>
    <message>
      <source>Image info</source>
      <translation>Info immagine</translation>
    </message>
    <message>
      <source>Images (*.png *.tif *.tiff *.fits *.fit *.xisf *.cr2 *.cr3 *.nef *.arw *.dng *.raf *.orf *.rw2 *.pef);;All Files (*)</source>
      <translation>Immagini (*.png *.tif *.tiff *.fits *.fit *.xisf *.cr2 *.cr3 *.nef *.arw *.dng *.raf *.orf *.rw2 *.pef);;Tutti i File (*)</translation>
    </message>
    <message>
      <source>Images (*.png *.tif *.tiff *.fits *.fit *.xisf *.cr2 *.nef *.arw *.dng *.raf *.orf *.rw2 *.pef);;All Files (*)</source>
      <translation>Immagini (*.png *.tif *.tiff *.fits *.fit *.xisf *.cr2 *.nef *.arw *.dng *.raf *.orf *.rw2 *.pef);;Tutti i File (*)</translation>
    </message>
    <message>
      <source>Individual Stretch</source>
      <translation>Stretch Individuale</translation>
    </message>
    <message>
      <source>Individual stretch</source>
      <translation>Stretch individuale</translation>
    </message>
    <message>
      <source>Invert Flags</source>
      <translation>Inverti Segnature</translation>
    </message>
    <message>
      <source>Invert difference</source>
      <translation>Inverti differenza</translation>
    </message>
    <message>
      <source>Last</source>
      <translation>Ultimo</translation>
    </message>
    <message>
      <source>Last Frame</source>
      <translation>Ultimo Frame</translation>
    </message>
    <message>
      <source>Link stretch</source>
      <translation>Collega stretch</translation>
    </message>
    <message>
      <source>Linked Stretch</source>
      <translation>Stretch Collegato</translation>
    </message>
    <message>
      <source>Load images before exporting.</source>
      <translation>Carica immagini prima di esportare.</translation>
    </message>
    <message>
      <source>Load some images first.</source>
      <translation>Carica prima alcune immagini.</translation>
    </message>
    <message>
      <source>Loaded {0} images.</source>
      <translation>Caricate {0} immagini.</translation>
    </message>
    <message>
      <source>Loaded {0} image{1}.</source>
      <translation>Caricata {0} immagine{1}.</translation>
    </message>
    <message>
      <source>Loading frame {0} of {1}...</source>
      <translation>Caricamento frame {0} di {1}...</translation>
    </message>
    <message>
      <source>Loading frames...</source>
      <translation>Caricamento frame...</translation>
    </message>
    <message>
      <source>Loading images...</source>
      <translation>Caricamento immagini...</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Caricamento...</translation>
    </message>
    <message>
      <source>Loop</source>
      <translation>Loop</translation>
    </message>
    <message>
      <source>Loop Count:</source>
      <translation>Conteggio Loop:</translation>
    </message>
    <message>
      <source>Main window or DocManager not available.</source>
      <translation>Finestra principale o DocManager non disponibile.</translation>
    </message>
    <message>
      <source>Manual align</source>
      <translation>Allineamento manuale</translation>
    </message>
    <message>
      <source>Mark as reference</source>
      <translation>Segna come riferimento</translation>
    </message>
    <message>
      <source>Mark transient</source>
      <translation>Segna transiente</translation>
    </message>
    <message>
      <source>Move All Flagged Images</source>
      <translation>Sposta Tutte le Immagini Segnate</translation>
    </message>
    <message>
      <source>Move Down</source>
      <translation>Sposta Giù</translation>
    </message>
    <message>
      <source>Move Flagged to Folder</source>
      <translation>Sposta Segnati in Cartella</translation>
    </message>
    <message>
      <source>Move Selected Items</source>
      <translation>Sposta Elementi Selezionati</translation>
    </message>
    <message>
      <source>Move Up</source>
      <translation>Sposta Su</translation>
    </message>
    <message>
      <source>Moved {0} flagged images.</source>
      <translation>Spostate {0} immagini segnate.</translation>
    </message>
    <message>
      <source>Next</source>
      <translation>Successivo</translation>
    </message>
    <message>
      <source>Next Frame</source>
      <translation>Frame Successivo</translation>
    </message>
    <message>
      <source>No Flagged Images</source>
      <translation>Nessuna Immagine Segnata</translation>
    </message>
    <message>
      <source>No Frames</source>
      <translation>Nessun Frame</translation>
    </message>
    <message>
      <source>No Images</source>
      <translation>Nessuna Immagine</translation>
    </message>
    <message>
      <source>No Images Found</source>
      <translation>Nessuna Immagine Trovata</translation>
    </message>
    <message>
      <source>No New Images</source>
      <translation>Nessuna Nuova Immagine</translation>
    </message>
    <message>
      <source>No Prefix</source>
      <translation>Nessun Prefisso</translation>
    </message>
    <message>
      <source>No Selection</source>
      <translation>Nessuna Selezione</translation>
    </message>
    <message>
      <source>No compatible video codec found.

Tip: install FFmpeg or `pip install imageio[ffmpeg]` for a portable fallback.</source>
      <translation>Nessun codec video compatibile trovato.

Suggerimento: installa FFmpeg o `pip install imageio[ffmpeg]` per un fallback portabile.</translation>
    </message>
    <message>
      <source>No frames loaded.</source>
      <translation>Nessun frame caricato.</translation>
    </message>
    <message>
      <source>No frames were written (codec/back-end issue?).</source>
      <translation>Nessun frame scritto (problema codec/back-end?).</translation>
    </message>
    <message>
      <source>No image is currently selected to flag.</source>
      <translation>Nessuna immagine attualmente selezionata da segnare.</translation>
    </message>
    <message>
      <source>No image loaded. Cannot fit to preview.</source>
      <translation>Nessuna immagine caricata. Impossibile adattare all'anteprima.</translation>
    </message>
    <message>
      <source>No image selected.</source>
      <translation>Nessuna immagine selezionata.</translation>
    </message>
    <message>
      <source>No images</source>
      <translation>Nessuna immagine</translation>
    </message>
    <message>
      <source>No images loaded</source>
      <translation>Nessuna immagine caricata</translation>
    </message>
    <message>
      <source>No individual frames selected.</source>
      <translation>Nessun frame individuale selezionato.</translation>
    </message>
    <message>
      <source>No items selected for deletion.</source>
      <translation>Nessun elemento selezionato per l'eliminazione.</translation>
    </message>
    <message>
      <source>No items selected for moving.</source>
      <translation>Nessun elemento selezionato per lo spostamento.</translation>
    </message>
    <message>
      <source>No items selected for renaming.</source>
      <translation>Nessun elemento selezionato per la rinomina.</translation>
    </message>
    <message>
      <source>No new images selected or already loaded.</source>
      <translation>Nessuna nuova immagine selezionata o già caricata.</translation>
    </message>
    <message>
      <source>No new images were selected or all selected images are already loaded.</source>
      <translation>Nessuna nuova immagine selezionata o tutte le immagini selezionate sono già caricate.</translation>
    </message>
    <message>
      <source>No prefix entered. This will not change any filenames.

Continue anyway?</source>
      <translation>Nessun prefisso inserito. Questo non cambierà nessun nome file.

Continuare comunque?</translation>
    </message>
    <message>
      <source>No supported image files were found in the selected directory.</source>
      <translation>Nessun file immagine supportato trovato nella cartella selezionata.</translation>
    </message>
    <message>
      <source>Normalize All</source>
      <translation>Normalizza Tutti</translation>
    </message>
    <message>
      <source>Nothing to export.</source>
      <translation>Niente da esportare.</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Object: {0}</source>
      <translation>Oggetto: {0}</translation>
    </message>
    <message>
      <source>Only one frame</source>
      <translation>Solo un frame</translation>
    </message>
    <message>
      <source>Opacity:</source>
      <translation>Opacità:</translation>
    </message>
    <message>
      <source>Open Images</source>
      <translation>Apri Immagini</translation>
    </message>
    <message>
      <source>Open in Document Window</source>
      <translation>Apri in Finestra Documento</translation>
    </message>
    <message>
      <source>Output Format:</source>
      <translation>Formato Output:</translation>
    </message>
    <message>
      <source>Overlay mode</source>
      <translation>Modalità overlay</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Pausa</translation>
    </message>
    <message>
      <source>Ping Pong</source>
      <translation>Ping Pong</translation>
    </message>
    <message>
      <source>Ping-pong</source>
      <translation>Ping-pong</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Riproduci</translation>
    </message>
    <message>
      <source>Playback speed (0.1–10.0 fps)</source>
      <translation>Velocità riproduzione (0.1–10.0 fps)</translation>
    </message>
    <message>
      <source>Prefix</source>
      <translation>Prefisso</translation>
    </message>
    <message>
      <source>Prefix to add to flagged image filenames:</source>
      <translation>Prefisso da aggiungere ai nomi file immagini segnate:</translation>
    </message>
    <message>
      <source>Press 'F' to flag/unflag an image.
Right-click on an image for more options.</source>
      <translation>Premi 'F' per segnalare/desegnalare un'immagine.
Clic destro su un'immagine per più opzioni.</translation>
    </message>
    <message>
      <source>Previous</source>
      <translation>Precedente</translation>
    </message>
    <message>
      <source>Previous Frame</source>
      <translation>Frame Precedente</translation>
    </message>
    <message>
      <source>Quality</source>
      <translation>Qualità</translation>
    </message>
    <message>
      <source>Quality:</source>
      <translation>Qualità:</translation>
    </message>
    <message>
      <source>Reference Frame</source>
      <translation>Frame di Riferimento</translation>
    </message>
    <message>
      <source>Remove Image</source>
      <translation>Rimuovi immagine</translation>
    </message>
    <message>
      <source>Remove Selected</source>
      <translation>Rimuovi Selezionati</translation>
    </message>
    <message>
      <source>Rename</source>
      <translation>Rinomina</translation>
    </message>
    <message>
      <source>Rename Flagged Images</source>
      <translation>Rinomina Immagini Segnate</translation>
    </message>
    <message>
      <source>Rename Flagged Images…</source>
      <translation>Rinomina Immagini Segnate…</translation>
    </message>
    <message>
      <source>Rename Image</source>
      <translation>Rinomina Immagine</translation>
    </message>
    <message>
      <source>Rename flagged images</source>
      <translation>Rinomina immagini segnate</translation>
    </message>
    <message>
      <source>Renamed {0} flagged image{1}.</source>
      <translation>Rinominate {0} immagine{1} segnata.</translation>
    </message>
    <message>
      <source>Rendering video…</source>
      <translation>Rendering video…</translation>
    </message>
    <message>
      <source>Reset Stretch</source>
      <translation>Reimposta Stretch</translation>
    </message>
    <message>
      <source>Reset alignment</source>
      <translation>Reimposta allineamento</translation>
    </message>
    <message>
      <source>Resolution</source>
      <translation>Risoluzione</translation>
    </message>
    <message>
      <source>Reverse Order</source>
      <translation>Inverti Ordine</translation>
    </message>
    <message>
      <source>Rotate All</source>
      <translation>Ruota Tutti</translation>
    </message>
    <message>
      <source>Save All</source>
      <translation>Salva Tutti</translation>
    </message>
    <message>
      <source>Save GIF</source>
      <translation>Salva GIF</translation>
    </message>
    <message>
      <source>Save Video</source>
      <translation>Salva Video</translation>
    </message>
    <message>
      <source>Saved: {0}
Frames: {1} @ {2} fps</source>
      <translation>Salvato: {0}
Frame: {1} @ {2} fps</translation>
    </message>
    <message>
      <source>Search transients</source>
      <translation>Cerca transienti</translation>
    </message>
    <message>
      <source>Searching...</source>
      <translation>Ricerca...</translation>
    </message>
    <message>
      <source>Select Destination Folder</source>
      <translation>Seleziona Cartella Destinazione</translation>
    </message>
    <message>
      <source>Select Directory</source>
      <translation>Seleziona Cartella</translation>
    </message>
    <message>
      <source>Select Frames</source>
      <translation>Seleziona Frame</translation>
    </message>
    <message>
      <source>Select Images</source>
      <translation>Seleziona Immagini</translation>
    </message>
    <message>
      <source>Select Output Folder</source>
      <translation>Seleziona Cartella Output</translation>
    </message>
    <message>
      <source>Send selected (or all) blink files to the Stacking Suite → Image Integration tab</source>
      <translation>Invia file blink selezionati (o tutti) alla Suite Stacking → scheda Integrazione Immagini</translation>
    </message>
    <message>
      <source>Send selected (or all) blink files to the Stacking Suite → Light tab</source>
      <translation>Invia file blink selezionati (o tutti) alla Suite Stacking → scheda Light</translation>
    </message>
    <message>
      <source>Send to Stacking → Integration</source>
      <translation>Invia a Stacking → Integrazione</translation>
    </message>
    <message>
      <source>Send to Stacking → Lights</source>
      <translation>Invia a Stacking → Light</translation>
    </message>
    <message>
      <source>Set as Reference</source>
      <translation>Imposta come Riferimento</translation>
    </message>
    <message>
      <source>Show Difference</source>
      <translation>Mostra Differenza</translation>
    </message>
    <message>
      <source>Show Flagged Only</source>
      <translation>Mostra Solo Segnati</translation>
    </message>
    <message>
      <source>Show Metrics</source>
      <translation>Mostra Metriche</translation>
    </message>
    <message>
      <source>Show crosshair</source>
      <translation>Mostra mirino</translation>
    </message>
    <message>
      <source>Show filename</source>
      <translation>Mostra nome file</translation>
    </message>
    <message>
      <source>Show grid</source>
      <translation>Mostra griglia</translation>
    </message>
    <message>
      <source>Show histogram</source>
      <translation>Mostra istogramma</translation>
    </message>
    <message>
      <source>Show timestamp</source>
      <translation>Mostra timestamp</translation>
    </message>
    <message>
      <source>Side by side</source>
      <translation>Affiancato</translation>
    </message>
    <message>
      <source>Signed Difference</source>
      <translation>Differenza con Segno</translation>
    </message>
    <message>
      <source>Single pass</source>
      <translation>Passaggio singolo</translation>
    </message>
    <message>
      <source>Size:</source>
      <translation>Dimensione:</translation>
    </message>
    <message>
      <source>Sort by Date</source>
      <translation>Ordina per Data</translation>
    </message>
    <message>
      <source>Sort by Name</source>
      <translation>Ordina per Nome</translation>
    </message>
    <message>
      <source>Speed</source>
      <translation>Velocità</translation>
    </message>
    <message>
      <source>Speed:</source>
      <translation>Velocità:</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Stop</translation>
    </message>
    <message>
      <source>Suffix</source>
      <translation>Suffisso</translation>
    </message>
    <message>
      <source>Sync pan</source>
      <translation>Sincronizza pan</translation>
    </message>
    <message>
      <source>Sync zoom</source>
      <translation>Sincronizza zoom</translation>
    </message>
    <message>
      <source>There are no flagged images to delete.</source>
      <translation>Non ci sono immagini segnate da eliminare.</translation>
    </message>
    <message>
      <source>There are no flagged images to move.</source>
      <translation>Non ci sono immagini segnate da spostare.</translation>
    </message>
    <message>
      <source>There are no flagged images to rename.</source>
      <translation>Non ci sono immagini segnate da rinominare.</translation>
    </message>
    <message>
      <source>There are no images to send.</source>
      <translation>Non ci sono immagini da inviare.</translation>
    </message>
    <message>
      <source>Total frames</source>
      <translation>Frame totali</translation>
    </message>
    <message>
      <source>Transients found</source>
      <translation>Transienti trovati</translation>
    </message>
    <message>
      <source>Translation + Rotation</source>
      <translation>Traslazione + Rotazione</translation>
    </message>
    <message>
      <source>Translation Only</source>
      <translation>Solo Traslazione</translation>
    </message>
    <message>
      <source>UI</source>
      <translation>UI</translation>
    </message>
    <message>
      <source>Unflag All</source>
      <translation>Rimuovi Segnatura Tutti</translation>
    </message>
    <message>
      <source>Unflag Selected</source>
      <translation>Rimuovi Segnatura Selezionati</translation>
    </message>
    <message>
      <source>Unsupported Bayer pattern: {0}</source>
      <translation>Pattern Bayer non supportato: {0}</translation>
    </message>
    <message>
      <source>Video (*.mp4 *.avi)</source>
      <translation>Video (*.mp4 *.avi)</translation>
    </message>
    <message>
      <source>Video Codec:</source>
      <translation>Codec Video:</translation>
    </message>
    <message>
      <source>Video Export (optional)</source>
      <translation>Esportazione Video (opzionale)</translation>
    </message>
    <message>
      <source>Video Files (*.mp4 *.avi *.mov)</source>
      <translation>File Video (*.mp4 *.avi *.mov)</translation>
    </message>
    <message>
      <source>Video Options</source>
      <translation>Opzioni Video</translation>
    </message>
    <message>
      <source>Video export failed: {0}</source>
      <translation>Esportazione video fallita: {0}</translation>
    </message>
    <message>
      <source>Video exported: {0}</source>
      <translation>Video esportato: {0}</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Avviso</translation>
    </message>
    <message>
      <source>You're about to export a video with a single frame. Continue?</source>
      <translation>Stai per esportare un video con un singolo frame. Continuare?</translation>
    </message>
    <message>
      <source>Zoom 100%</source>
      <translation>Zoom 100%</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Zoom Avanti</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Zoom Indietro</translation>
    </message>
    <message>
      <source>Zoom to fit</source>
      <translation>Adatta allo zoom</translation>
    </message>
    <message>
      <source>{0} frames</source>
      <translation>{0} frame</translation>
    </message>
    <message>
      <source>{0} frames deleted.</source>
      <translation>{0} frame eliminati.</translation>
    </message>
    <message>
      <source>→ Stacking: Integration</source>
      <translation>→ Stacking: Integrazione</translation>
    </message>
    <message>
      <source>→ Stacking: Lights</source>
      <translation>→ Stacking: Light</translation>
    </message>
  </context>
  <context>
    <name>CLAHEDialogPro</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>CLAHE</source>
      <translation>CLAHE</translation>
    </message>
    <message>
      <source>CLAHE Parameters</source>
      <translation>Parametri CLAHE</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Clip Limit:</source>
      <translation>Limite clip:</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Reimposta</translation>
    </message>
    <message>
      <source>Tile Size (px):</source>
      <translation>Dimensione tile (px):</translation>
    </message>
  </context>
  <context>
    <name>CheatSheet</name>
    <message>
      <source>Action</source>
      <translation>Azione</translation>
    </message>
    <message>
      <source>Menus/Toolbar</source>
      <translation>Menu/Barra strumenti</translation>
    </message>
    <message>
      <source>Shortcut</source>
      <translation>Scorciatoia</translation>
    </message>
    <message>
      <source>Window</source>
      <translation>Finestra</translation>
    </message>
  </context>
  <context>
    <name>CheatSheetDialog</name>
    <message>
      <source>Action</source>
      <translation>Azione</translation>
    </message>
    <message>
      <source>Additional &amp; Mouse &amp; Drag</source>
      <translation>Aggiuntivi &amp; Mouse &amp; Trascinamento</translation>
    </message>
    <message>
      <source>Base Keyboard</source>
      <translation>Tastiera base</translation>
    </message>
    <message>
      <source>Cheat sheet copied to clipboard.</source>
      <translation>Schema scorciatoie copiato negli appunti.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Context</source>
      <translation>Contesto</translation>
    </message>
    <message>
      <source>Copied</source>
      <translation>Copiato</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copia</translation>
    </message>
    <message>
      <source>Effect</source>
      <translation>Effetto</translation>
    </message>
    <message>
      <source>Gesture</source>
      <translation>Gesto</translation>
    </message>
    <message>
      <source>Keyboard Shortcut Cheat Sheet</source>
      <translation>Schema scorciatoie tastiera</translation>
    </message>
    <message>
      <source>Shortcut</source>
      <translation>Scorciatoia</translation>
    </message>
    <message>
      <source>Where</source>
      <translation>Dove</translation>
    </message>
    <message>
      <source>All</source>
      <translation>Tutto</translation>
    </message>
    <message>
      <source>Category</source>
      <translation>Categoria</translation>
    </message>
    <message>
      <source>Cheat Sheet</source>
      <translation>Foglio riassuntivo</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Modifica</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Image</source>
      <translation>Immagine</translation>
    </message>
    <message>
      <source>Keyboard Shortcuts</source>
      <translation>Scorciatoie tastiera</translation>
    </message>
    <message>
      <source>Print</source>
      <translation>Stampa</translation>
    </message>
    <message>
      <source>Search</source>
      <translation>Cerca</translation>
    </message>
    <message>
      <source>Tools</source>
      <translation>Strumenti</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Vista</translation>
    </message>
  </context>
  <context>
    <name>ContinuumSubtractTab</name>
    <message>
      <source>Clear Loaded Images</source>
      <translation>Cancella immagini caricate</translation>
    </message>
    <message>
      <source>Continuum Sources</source>
      <translation>Sorgenti continuum</translation>
    </message>
    <message>
      <source>Denoise continuum result with Cosmic Clarity (0.9)</source>
      <translation>Denoise risultato continuum con Cosmic Clarity (0.9)</translation>
    </message>
    <message>
      <source>Execute</source>
      <translation>Esegui</translation>
    </message>
    <message>
      <source>Narrowband Filters</source>
      <translation>Filtri narrowband</translation>
    </message>
    <message>
      <source>Output Linear Image Only</source>
      <translation>Output solo immagine lineare</translation>
    </message>
    <message>
      <source>Star-Based WB</source>
      <translation>WB basato su stelle</translation>
    </message>
  </context>
  <context>
    <name>ConvoDeconvoDialog</name>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Convolution</source>
      <translation>Convoluzione</translation>
    </message>
    <message>
      <source>Convolution / Deconvolution</source>
      <translation>Convoluzione / Deconvoluzione</translation>
    </message>
    <message>
      <source>Deconvolution</source>
      <translation>Deconvoluzione</translation>
    </message>
    <message>
      <source>PSF Estimator</source>
      <translation>Stimatore PSF</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Push</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>TV Denoise</source>
      <translation>Denoise TV</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Annulla</translation>
    </message>
  </context>
  <context>
    <name>CosmicClarityDialogPro</name>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Cosmic Clarity</source>
      <translation>Cosmic Clarity</translation>
    </message>
    <message>
      <source>Execute</source>
      <translation>Esegui</translation>
    </message>
    <message>
      <source>Mode:</source>
      <translation>Modalità:</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Parameters</source>
      <translation>Parametri</translation>
    </message>
    <message>
      <source>Use GPU:</source>
      <translation>Usa GPU:</translation>
    </message>
    <message>
      <source>Yes</source>
      <translation>Sì</translation>
    </message>
  </context>
  <context>
    <name>CrashHandler</name>
    <message>
      <source>Details are available below and in saspro.log.</source>
      <translation>I dettagli sono disponibili sotto e in saspro.log.</translation>
    </message>
    <message>
      <source>Unhandled Exception</source>
      <translation>Eccezione non gestita</translation>
    </message>
    <message>
      <source>Unhandled Thread Exception</source>
      <translation>Eccezione thread non gestita</translation>
    </message>
  </context>
  <context>
    <name>CropDialogPro</name>
    <message>
      <source>Applied crop to all open images. Any Astrometric Solutions has been updated.</source>
      <translation>Ritaglio applicato a tutte le immagini aperte. Le soluzioni astrometriche sono state aggiornate.</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Apply failed</source>
      <translation>Applicazione fallita</translation>
    </message>
    <message>
      <source>Apply this crop to {0} open image(s)?</source>
      <translation>Applicare questo ritaglio a {0} immagini aperte?</translation>
    </message>
    <message>
      <source>Aspect Ratio:</source>
      <translation>Rapporto d'aspetto:</translation>
    </message>
    <message>
      <source>Astrometric solution updated ✔️

</source>
      <translation>Soluzione astrometrica aggiornata ✔️

</translation>
    </message>
    <message>
      <source>Batch Crop</source>
      <translation>Ritaglio batch</translation>
    </message>
    <message>
      <source>Batch Crop (all open)</source>
      <translation>Ritaglio batch (tutti aperti)</translation>
    </message>
    <message>
      <source>Bottom</source>
      <translation>Basso</translation>
    </message>
    <message>
      <source>CRVAL: ({0:.6f}, {1:.6f}) → ({2:.6f}, {3:.6f})
</source>
      <translation>CRVAL: ({0:.6f}, {1:.6f}) → ({2:.6f}, {3:.6f})
</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Confirm Batch</source>
      <translation>Conferma batch</translation>
    </message>
    <message>
      <source>Crop Tool</source>
      <translation>Strumento ritaglio</translation>
    </message>
    <message>
      <source>Draw &amp; finalize a crop first.</source>
      <translation>Disegna e finalizza prima un ritaglio.</translation>
    </message>
    <message>
      <source>Fit residuals: RMS {0:.3f}"  (p95 {1:.3f}")</source>
      <translation>Residui fit: RMS {0:.3f}"  (p95 {1:.3f}")</translation>
    </message>
    <message>
      <source>Fit to View</source>
      <translation>Adatta alla vista</translation>
    </message>
    <message>
      <source>Free</source>
      <translation>Libero</translation>
    </message>
    <message>
      <source>Invalid crop bounds.</source>
      <translation>Limiti ritaglio non validi.</translation>
    </message>
    <message>
      <source>Invalid crop size.</source>
      <translation>Dimensione ritaglio non valida.</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Sinistra</translation>
    </message>
    <message>
      <source>Load Previous Crop</source>
      <translation>Carica ritaglio precedente</translation>
    </message>
    <message>
      <source>Margins (px):</source>
      <translation>Margini (px):</translation>
    </message>
    <message>
      <source>Model: {0}   Image: {1}
</source>
      <translation>Modello: {0}   Immagine: {1}
</translation>
    </message>
    <message>
      <source>No Images</source>
      <translation>Nessuna immagine</translation>
    </message>
    <message>
      <source>No Previous</source>
      <translation>Nessun precedente</translation>
    </message>
    <message>
      <source>No Selection</source>
      <translation>Nessuna selezione</translation>
    </message>
    <message>
      <source>No open images to crop.</source>
      <translation>Nessuna immagine aperta da ritagliare.</translation>
    </message>
    <message>
      <source>No previous crop stored.</source>
      <translation>Nessun ritaglio precedente salvato.</translation>
    </message>
    <message>
      <source>Original</source>
      <translation>Originale</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Destra</translation>
    </message>
    <message>
      <source>Selection: {0}×{1} px</source>
      <translation>Selezione: {0}×{1} px</translation>
    </message>
    <message>
      <source>Selection: —</source>
      <translation>Selezione: —</translation>
    </message>
    <message>
      <source>Toggle Autostretch</source>
      <translation>Attiva/Disattiva autostretch</translation>
    </message>
    <message>
      <source>Top</source>
      <translation>Alto</translation>
    </message>
    <message>
      <source>WCS Updated</source>
      <translation>WCS aggiornato</translation>
    </message>
    <message>
      <source>Zoom 100%</source>
      <translation>Zoom 100%</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
    <message>
      <source>• Click–drag to draw a crop
• Drag corner handles to resize
• Shift + drag on box to rotate</source>
      <translation>• Clicca e trascina per disegnare un ritaglio
• Trascina le maniglie agli angoli per ridimensionare
• Shift + trascina sul riquadro per ruotare</translation>
    </message>
  </context>
  <context>
    <name>CurveEditor</name>
    <message>
      <source>Inflection @ K={0:.3f}</source>
      <translation>Inflessione @ K={0:.3f}</translation>
    </message>
  </context>
  <context>
    <name>CurvesDialogPro</name>
    <message>
      <source>Apply to Document</source>
      <translation>Applica al documento</translation>
    </message>
    <message>
      <source>Curves Editor</source>
      <translation>Editor curve</translation>
    </message>
    <message>
      <source>Manage…</source>
      <translation>Gestisci…</translation>
    </message>
    <message>
      <source>Presets</source>
      <translation>Preset</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Reimposta</translation>
    </message>
    <message>
      <source>Save as Preset...</source>
      <translation>Salva come preset...</translation>
    </message>
    <message>
      <source>Toggle Preview</source>
      <translation>Attiva/Disattiva anteprima</translation>
    </message>
  </context>
  <context>
    <name>DSEWorker</name>
    <message>
      <source>Analyzing dark structure…</source>
      <translation>Analisi struttura scura…</translation>
    </message>
    <message>
      <source>Finalizing…</source>
      <translation>Finalizzazione…</translation>
    </message>
  </context>
  <context>
    <name>DebayerDialog</name>
    <message>
      <source>Bayer pattern</source>
      <translation>Pattern Bayer</translation>
    </message>
    <message>
      <source>Debayer</source>
      <translation>Debayer</translation>
    </message>
    <message>
      <source>Method</source>
      <translation>Metodo</translation>
    </message>
    <message>
      <source>AHD</source>
      <translation>AHD</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Auto-detect</source>
      <translation>Rilevamento auto</translation>
    </message>
    <message>
      <source>BGGR</source>
      <translation>BGGR</translation>
    </message>
    <message>
      <source>Bayer Pattern</source>
      <translation>Pattern Bayer</translation>
    </message>
    <message>
      <source>Bilinear</source>
      <translation>Bilineare</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>DCB</source>
      <translation>DCB</translation>
    </message>
    <message>
      <source>GBRG</source>
      <translation>GBRG</translation>
    </message>
    <message>
      <source>GRBG</source>
      <translation>GRBG</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>RGGB</source>
      <translation>RGGB</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Super Pixel</source>
      <translation>Super Pixel</translation>
    </message>
    <message>
      <source>VNG</source>
      <translation>VNG</translation>
    </message>
  </context>
  <context>
    <name>DistortionGridDialog</name>
    <message>
      <source>Astrometric Distortion &amp; Histogram</source>
      <translation>Distorsione astrometrica e istogramma</translation>
    </message>
    <message>
      <source>Astrometric Distortion Grid</source>
      <translation>Griglia distorsione astrometrica</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Distortion</source>
      <translation>Distorsione</translation>
    </message>
    <message>
      <source>Distortion (″)</source>
      <translation>Distorsione (″)</translation>
    </message>
    <message>
      <source>Not enough stars found.</source>
      <translation>Stelle insufficienti trovate.</translation>
    </message>
    <message>
      <source>Number of stars</source>
      <translation>Numero di stelle</translation>
    </message>
    <message>
      <source>Residual histogram</source>
      <translation>Istogramma residui</translation>
    </message>
  </context>
  <context>
    <name>DockMixin</name>
    <message>
      <source>Console / Status</source>
      <translation>Console / Stato</translation>
    </message>
    <message>
      <source>Explorer</source>
      <translation>Esplora</translation>
    </message>
    <message>
      <source>Show System Log Panel</source>
      <translation>Mostra pannello log di sistema</translation>
    </message>
    <message>
      <source>System Log</source>
      <translation>Log di sistema</translation>
    </message>
  </context>
  <context>
    <name>DraggableToolBar</name>
    <message>
      <source>Delete Selected</source>
      <translation>Elimina Selezionato</translation>
    </message>
    <message>
      <source>Clear Selection</source>
      <translation>Pulisci Selezione</translation>
    </message>
    <message>
      <source>View Bundles…</source>
      <translation>Visualizza Bundle…</translation>
    </message>
    <message>
      <source>Function Bundles…</source>
      <translation>Bundle Funzioni…</translation>
    </message>
    <message>
      <source>Lock Toolbar Icons</source>
      <translation>Blocca icone della barra strumenti</translation>
    </message>
    <message>
      <source>Show hidden…</source>
      <translation>Mostra nascosti…</translation>
    </message>
    <message>
      <source>Reset hidden icons</source>
      <translation>Reimposta icone nascoste</translation>
    </message>
    <message>
      <source>Create Desktop Shortcut</source>
      <translation>Crea collegamento sul desktop</translation>
    </message>
    <message>
      <source>Hide this icon</source>
      <translation>Nascondi questa icona</translation>
    </message>
    <message>
      <source>Tip: Alt+Drag to create</source>
      <translation>Suggerimento: Alt+Trascina per creare</translation>
    </message>
  </context>
  <context>
    <name>ExoPlanetWindow</name>
    <message>
      <source>1: Load Raw Subs…</source>
      <translation>1: Carica Sub grezzi…</translation>
    </message>
    <message>
      <source>1a: Calibrate &amp;&amp; Align Subs</source>
      <translation>1a: Calibra e Allinea Sub</translation>
    </message>
    <message>
      <source>2: Measure &amp;&amp; Photometry</source>
      <translation>2: Misura e Fotometria</translation>
    </message>
    <message>
      <source>Aligned Subs</source>
      <translation>Sub allineati</translation>
    </message>
    <message>
      <source>Exoplanet Transit Detector</source>
      <translation>Rilevatore transiti esopianeti</translation>
    </message>
    <message>
      <source>Load Master Dark…</source>
      <translation>Carica Master Dark…</translation>
    </message>
    <message>
      <source>Load Master Flat…</source>
      <translation>Carica Master Flat…</translation>
    </message>
    <message>
      <source>Load, Measure &amp;&amp; Photometry…</source>
      <translation>Carica, Misura e Fotometria…</translation>
    </message>
    <message>
      <source>Mode:</source>
      <translation>Modalità:</translation>
    </message>
    <message>
      <source>Raw Subs</source>
      <translation>Sub grezzi</translation>
    </message>
  </context>
  <context>
    <name>FITSModifier</name>
    <message>
      <source>(no file)</source>
      <translation>(nessun file)</translation>
    </message>
    <message>
      <source>Add/Update</source>
      <translation>Aggiungi/Aggiorna</translation>
    </message>
    <message>
      <source>Apply add/update/delete to all HDUs</source>
      <translation>Applica aggiungi/aggiorna/elimina a tutti gli HDU</translation>
    </message>
    <message>
      <source>Batch Modify...</source>
      <translation>Modifica batch...</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Commento</translation>
    </message>
    <message>
      <source>Comment (optional)</source>
      <translation>Commento (opzionale)</translation>
    </message>
    <message>
      <source>Could not save:
{0}</source>
      <translation>Impossibile salvare:
{0}</translation>
    </message>
    <message>
      <source>Delete Selected</source>
      <translation>Elimina selezionati</translation>
    </message>
    <message>
      <source>FITS (*.fits *.fit);;TIFF (*.tif *.tiff);;PNG (*.png);;JPEG (*.jpg *.jpeg);;XISF (*.xisf)</source>
      <translation>FITS (*.fits *.fit);;TIFF (*.tif *.tiff);;PNG (*.png);;JPEG (*.jpg *.jpeg);;XISF (*.xisf)</translation>
    </message>
    <message>
      <source>FITS Header Editor</source>
      <translation>Editor header FITS</translation>
    </message>
    <message>
      <source>FITS files (*.fits *.fit *.fts *.fz)</source>
      <translation>File FITS (*.fits *.fit *.fts *.fz)</translation>
    </message>
    <message>
      <source>File:</source>
      <translation>File:</translation>
    </message>
    <message>
      <source>HDU:</source>
      <translation>HDU:</translation>
    </message>
    <message>
      <source>Invalid FITS</source>
      <translation>FITS non valido</translation>
    </message>
    <message>
      <source>KEYWORD</source>
      <translation>PAROLA CHIAVE</translation>
    </message>
    <message>
      <source>Keyword</source>
      <translation>Parola chiave</translation>
    </message>
    <message>
      <source>No Image</source>
      <translation>Nessuna immagine</translation>
    </message>
    <message>
      <source>No active image/document to save.</source>
      <translation>Nessuna immagine/documento attivo da salvare.</translation>
    </message>
    <message>
      <source>Open FITS</source>
      <translation>Apri FITS</translation>
    </message>
    <message>
      <source>Open FITS…</source>
      <translation>Apri FITS…</translation>
    </message>
    <message>
      <source>Reload</source>
      <translation>Ricarica</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Save Error</source>
      <translation>Errore salvataggio</translation>
    </message>
    <message>
      <source>Save Image As</source>
      <translation>Salva immagine come</translation>
    </message>
    <message>
      <source>Save a Copy As…</source>
      <translation>Salva una copia come…</translation>
    </message>
    <message>
      <source>Saved Copy</source>
      <translation>Copia salvata</translation>
    </message>
    <message>
      <source>Saved a copy to:
{0}</source>
      <translation>Copia salvata in:
{0}</translation>
    </message>
    <message>
      <source>This file does not appear to be a valid FITS:

{0}

{1}

Tip: Choose a FITS file via 'Open FITS…' or edit an in-memory header.</source>
      <translation>Questo file non sembra essere un FITS valido:

{0}

{1}

Suggerimento: Scegli un file FITS tramite 'Apri FITS…' o modifica un header in memoria.</translation>
    </message>
    <message>
      <source>Value</source>
      <translation>Valore</translation>
    </message>
  </context>
  <context>
    <name>FileMixin</name>
    <message>
      <source>Failed to save:
{e}</source>
      <translation>Salvataggio fallito:
{e}</translation>
    </message>
    <message>
      <source>Failed to save:
{msg}</source>
      <translation>Salvataggio fallito:
{msg}</translation>
    </message>
    <message>
      <source>File not found</source>
      <translation>File non trovato</translation>
    </message>
    <message>
      <source>Load Project</source>
      <translation>Carica progetto</translation>
    </message>
    <message>
      <source>New Project</source>
      <translation>Nuovo progetto</translation>
    </message>
    <message>
      <source>No documents to save.</source>
      <translation>Nessun documento da salvare.</translation>
    </message>
    <message>
      <source>Open Images</source>
      <translation>Apri immagini</translation>
    </message>
    <message>
      <source>Open failed</source>
      <translation>Apertura fallita</translation>
    </message>
    <message>
      <source>Project not found</source>
      <translation>Progetto non trovato</translation>
    </message>
    <message>
      <source>Save As</source>
      <translation>Salva come</translation>
    </message>
    <message>
      <source>Save Project</source>
      <translation>Salva progetto</translation>
    </message>
    <message>
      <source>Save failed</source>
      <translation>Salvataggio fallito</translation>
    </message>
    <message>
      <source>Saving</source>
      <translation>Salvataggio</translation>
    </message>
    <message>
      <source>Saving project...</source>
      <translation>Salvataggio progetto...</translation>
    </message>
    <message>
      <source>Start a new project? This closes all views and clears desktop shortcuts.</source>
      <translation>Iniziare un nuovo progetto? Questo chiuderà tutte le viste e cancellerà le scorciatoie.</translation>
    </message>
    <message>
      <source>The file does not exist:
{path}

Remove it from the recent images list?</source>
      <translation>Il file non esiste:
{path}

Rimuoverlo dalla lista immagini recenti?</translation>
    </message>
    <message>
      <source>The project file does not exist:
{path}

Remove it from the recent projects list?</source>
      <translation>Il file progetto non esiste:
{path}

Rimuoverlo dalla lista progetti recenti?</translation>
    </message>
    <message>
      <source>All Files</source>
      <translation>Tutti i file</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Clear Recent</source>
      <translation>Cancella recenti</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Close All</source>
      <translation>Chiudi tutti</translation>
    </message>
    <message>
      <source>Don't Save</source>
      <translation>Non salvare</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Esci</translation>
    </message>
    <message>
      <source>Export As...</source>
      <translation>Esporta come...</translation>
    </message>
    <message>
      <source>Export...</source>
      <translation>Esporta...</translation>
    </message>
    <message>
      <source>Image Files</source>
      <translation>File immagine</translation>
    </message>
    <message>
      <source>New</source>
      <translation>Nuovo</translation>
    </message>
    <message>
      <source>Open Recent</source>
      <translation>Apri recenti</translation>
    </message>
    <message>
      <source>Open...</source>
      <translation>Apri...</translation>
    </message>
    <message>
      <source>Print...</source>
      <translation>Stampa...</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Save All</source>
      <translation>Salva tutti</translation>
    </message>
    <message>
      <source>Save As...</source>
      <translation>Salva come...</translation>
    </message>
    <message>
      <source>Save Image</source>
      <translation>Salva immagine</translation>
    </message>
    <message>
      <source>Save changes before closing?</source>
      <translation>Salvare le modifiche prima di chiudere?</translation>
    </message>
    <message>
      <source>Select Image File</source>
      <translation>Seleziona file immagine</translation>
    </message>
    <message>
      <source>Unsaved Changes</source>
      <translation>Modifiche non salvate</translation>
    </message>
    <message>
      <source>Untitled</source>
      <translation>Senza titolo</translation>
    </message>
  </context>
  <context>
    <name>FilterIdDialog</name>
    <message>
      <source>Add row</source>
      <translation>Aggiungi riga</translation>
    </message>
    <message>
      <source>AstroBin Filter IDs</source>
      <translation>ID filtri AstroBin</translation>
    </message>
    <message>
      <source>AstroBin ID</source>
      <translation>ID AstroBin</translation>
    </message>
    <message>
      <source>Brand</source>
      <translation>Marca</translation>
    </message>
    <message>
      <source>CSV files (*.csv);;All files (*)</source>
      <translation>File CSV (*.csv);;Tutti i file (*)</translation>
    </message>
    <message>
      <source>Delete selected</source>
      <translation>Elimina selezionati</translation>
    </message>
    <message>
      <source>Edit filter names and their AstroBin numeric IDs.</source>
      <translation>Modifica nomi filtri e i loro ID numerici AstroBin.</translation>
    </message>
    <message>
      <source>Filter name</source>
      <translation>Nome filtro</translation>
    </message>
    <message>
      <source>ID</source>
      <translation>ID</translation>
    </message>
    <message>
      <source>Load offline DB…</source>
      <translation>Carica DB offline…</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Nome</translation>
    </message>
    <message>
      <source>No DB</source>
      <translation>Nessun DB</translation>
    </message>
    <message>
      <source>Offline filters database not loaded yet.</source>
      <translation>Database filtri offline non ancora caricato.</translation>
    </message>
    <message>
      <source>Open AstroBin Equipment Explorer (Filters)</source>
      <translation>Apri AstroBin Equipment Explorer (Filtri)</translation>
    </message>
    <message>
      <source>Search AstroBin Filters (offline)</source>
      <translation>Cerca filtri AstroBin (offline)</translation>
    </message>
    <message>
      <source>Search ID, brand, or name…</source>
      <translation>Cerca ID, marca o nome…</translation>
    </message>
    <message>
      <source>Search offline DB…</source>
      <translation>Cerca nel DB offline…</translation>
    </message>
    <message>
      <source>Search or load the offline filters database.</source>
      <translation>Cerca o carica il database filtri offline.</translation>
    </message>
    <message>
      <source>Select AstroBin Filters CSV</source>
      <translation>Seleziona CSV filtri AstroBin</translation>
    </message>
  </context>
  <context>
    <name>FrequencySeperationTab</name>
    <message>
      <source>&lt;b&gt;HF Enhancements&lt;/b&gt;</source>
      <translation>&lt;b&gt;Miglioramenti HF&lt;/b&gt;</translation>
    </message>
    <message>
      <source>Apply - Split HF &amp; LF</source>
      <translation>Applica - Separa HF e LF</translation>
    </message>
    <message>
      <source>Apply HF Enhancements</source>
      <translation>Applica miglioramenti HF</translation>
    </message>
    <message>
      <source>Combine HF+LF -&gt; Push</source>
      <translation>Combina HF+LF -&gt; Applica</translation>
    </message>
    <message>
      <source>Enable HF Denoise</source>
      <translation>Abilita denoise HF</translation>
    </message>
    <message>
      <source>Enable Sharpen Scale</source>
      <translation>Abilita scala nitidezza</translation>
    </message>
    <message>
      <source>Enable Wavelet Sharpening</source>
      <translation>Abilita nitidezza wavelet</translation>
    </message>
    <message>
      <source>Method:</source>
      <translation>Metodo:</translation>
    </message>
    <message>
      <source>Push HF</source>
      <translation>Applica HF</translation>
    </message>
    <message>
      <source>Push LF</source>
      <translation>Applica LF</translation>
    </message>
  </context>
  <context>
    <name>FunctionBundleDialog</name>
    <message>
      <source>Apply to Active View</source>
      <translation>Applica a Vista Attiva</translation>
    </message>
    <message>
      <source>Apply to View Bundle…</source>
      <translation>Applica a Pacchetto Viste…</translation>
    </message>
    <message>
      <source>Clear Steps</source>
      <translation>Pulisci Passaggi</translation>
    </message>
    <message>
      <source>Compress to Chip</source>
      <translation>Comprimi in Chip</translation>
    </message>
    <message>
      <source>Drag Bundle</source>
      <translation>Trascina Pacchetto</translation>
    </message>
    <message>
      <source>Edit Preset…</source>
      <translation>Modifica Preset…</translation>
    </message>
    <message>
      <source>Remove Selected</source>
      <translation>Rimuovi Selezionati</translation>
    </message>
    <message>
      <source>▲ Move Up</source>
      <translation>▲ Sposta Su</translation>
    </message>
    <message>
      <source>▼ Move Down</source>
      <translation>▼ Sposta Giù</translation>
    </message>
    <message>
      <source>Function Bundles</source>
      <translation>Pacchetti Funzioni</translation>
    </message>
    <message>
      <source>New</source>
      <translation>Nuovo</translation>
    </message>
    <message>
      <source>Duplicate</source>
      <translation>Duplica</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Elimina</translation>
    </message>
    <message>
      <source>Drop shortcuts here to add steps</source>
      <translation>Trascina qui le scorciatoie per aggiungere passaggi</translation>
    </message>
    <message>
      <source>Delete Chip</source>
      <translation>Elimina Chip</translation>
    </message>
  </context>
  <context>
    <name>GeometryMixin</name>
    <message>
      <source>Active view has no image.</source>
      <translation>La vista attiva non ha immagine.</translation>
    </message>
    <message>
      <source>Enter scaling factor (e.g., 0.5 for 50%, 2 for 200%):</source>
      <translation>Inserisci fattore di scala (es. 0.5 per 50%, 2 per 200%):</translation>
    </message>
    <message>
      <source>Flip Horizontal</source>
      <translation>Capovolgi orizzontale</translation>
    </message>
    <message>
      <source>Flip Vertical</source>
      <translation>Capovolgi verticale</translation>
    </message>
    <message>
      <source>Invert</source>
      <translation>Inverti</translation>
    </message>
    <message>
      <source>Rescale Image</source>
      <translation>Ridimensiona immagine</translation>
    </message>
    <message>
      <source>Rotate 180°</source>
      <translation>Ruota 180°</translation>
    </message>
    <message>
      <source>Rotate 90° CCW</source>
      <translation>Ruota 90° antiorario</translation>
    </message>
    <message>
      <source>Rotate 90° CW</source>
      <translation>Ruota 90° orario</translation>
    </message>
  </context>
  <context>
    <name>GhsDialogPro</name>
    <message>
      <source>Open a Histogram for this image.
Ctrl+Click on the histogram to set the GHS pivot.</source>
      <translation>Apri un istogramma per questa immagine.
Ctrl+Click sull'istogramma per impostare il pivot GHS.</translation>
    </message>
  </context>
  <context>
    <name>GlimrDialog</name>
    <message>
      <source>Allow higher harmonics</source>
      <translation>Consenti armoniche superiori</translation>
    </message>
    <message>
      <source>Auto-detect center</source>
      <translation>Rileva centro automaticamente</translation>
    </message>
    <message>
      <source>Center</source>
      <translation>Centro</translation>
    </message>
    <message>
      <source>Clip iterations</source>
      <translation>Iterazioni clipping</translation>
    </message>
    <message>
      <source>Create mask</source>
      <translation>Crea maschera</translation>
    </message>
    <message>
      <source>Create model</source>
      <translation>Crea modello</translation>
    </message>
    <message>
      <source>Ellipticity</source>
      <translation>Ellitticità</translation>
    </message>
    <message>
      <source>Ellipticity profile</source>
      <translation>Profilo ellitticità</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Export</source>
      <translation>Esporta</translation>
    </message>
    <message>
      <source>Export model</source>
      <translation>Esporta modello</translation>
    </message>
    <message>
      <source>Export residuals</source>
      <translation>Esporta residui</translation>
    </message>
    <message>
      <source>Export table</source>
      <translation>Esporta tabella</translation>
    </message>
    <message>
      <source>Fit isophotes</source>
      <translation>Adatta isofote</translation>
    </message>
    <message>
      <source>Fitting complete</source>
      <translation>Fitting completato</translation>
    </message>
    <message>
      <source>Fitting failed</source>
      <translation>Fitting fallito</translation>
    </message>
    <message>
      <source>Fitting parameters</source>
      <translation>Parametri fitting</translation>
    </message>
    <message>
      <source>Fitting...</source>
      <translation>Fitting...</translation>
    </message>
    <message>
      <source>Fix center</source>
      <translation>Fissa centro</translation>
    </message>
    <message>
      <source>Fix ellipticity</source>
      <translation>Fissa ellitticità</translation>
    </message>
    <message>
      <source>Fix position angle</source>
      <translation>Fissa angolo posizione</translation>
    </message>
    <message>
      <source>GLIMR</source>
      <translation>GLIMR</translation>
    </message>
    <message>
      <source>GLIMR - Galaxy Isophote Modeler</source>
      <translation>GLIMR - Modellatore Isofote Galassie</translation>
    </message>
    <message>
      <source>Geometry</source>
      <translation>Geometria</translation>
    </message>
    <message>
      <source>Intensity</source>
      <translation>Intensità</translation>
    </message>
    <message>
      <source>Isophote Fitting</source>
      <translation>Fitting isofote</translation>
    </message>
    <message>
      <source>Isophote table</source>
      <translation>Tabella isofote</translation>
    </message>
    <message>
      <source>Linear step</source>
      <translation>Passo lineare</translation>
    </message>
    <message>
      <source>Logarithmic step</source>
      <translation>Passo logaritmico</translation>
    </message>
    <message>
      <source>Manual center</source>
      <translation>Centro manuale</translation>
    </message>
    <message>
      <source>Masking</source>
      <translation>Mascheratura</translation>
    </message>
    <message>
      <source>Maximum radius</source>
      <translation>Raggio massimo</translation>
    </message>
    <message>
      <source>Minimum radius</source>
      <translation>Raggio minimo</translation>
    </message>
    <message>
      <source>Model</source>
      <translation>Modello</translation>
    </message>
    <message>
      <source>Pick center</source>
      <translation>Scegli centro</translation>
    </message>
    <message>
      <source>Plot results</source>
      <translation>Grafico risultati</translation>
    </message>
    <message>
      <source>Position angle</source>
      <translation>Angolo posizione</translation>
    </message>
    <message>
      <source>Position angle profile</source>
      <translation>Profilo angolo posizione</translation>
    </message>
    <message>
      <source>Results</source>
      <translation>Risultati</translation>
    </message>
    <message>
      <source>Semi-major axis</source>
      <translation>Semiasse maggiore</translation>
    </message>
    <message>
      <source>Show residuals</source>
      <translation>Mostra residui</translation>
    </message>
    <message>
      <source>Sigma clipping</source>
      <translation>Sigma clipping</translation>
    </message>
    <message>
      <source>Step size</source>
      <translation>Dimensione passo</translation>
    </message>
    <message>
      <source>Subtract model</source>
      <translation>Sottrai modello</translation>
    </message>
    <message>
      <source>Surface brightness profile</source>
      <translation>Profilo brillanza superficiale</translation>
    </message>
    <message>
      <source>Use mask</source>
      <translation>Usa maschera</translation>
    </message>
    <message>
      <source>X</source>
      <translation>X</translation>
    </message>
    <message>
      <source>Y</source>
      <translation>Y</translation>
    </message>
  </context>
  <context>
    <name>HeaderMixin</name>
    <message>
      <source>Comment</source>
      <translation>Commento</translation>
    </message>
    <message>
      <source>Header</source>
      <translation>Header</translation>
    </message>
    <message>
      <source>Key</source>
      <translation>Chiave</translation>
    </message>
    <message>
      <source>No header</source>
      <translation>Nessun header</translation>
    </message>
    <message>
      <source>No image</source>
      <translation>Nessuna immagine</translation>
    </message>
    <message>
      <source>Value</source>
      <translation>Valore</translation>
    </message>
  </context>
  <context>
    <name>HeaderViewerDock</name>
    <message>
      <source>CSV (*.csv)</source>
      <translation>CSV (*.csv)</translation>
    </message>
    <message>
      <source>FITS Header</source>
      <translation>Header FITS</translation>
    </message>
    <message>
      <source>Failed to save:
{0}</source>
      <translation>Salvataggio fallito:
{0}</translation>
    </message>
    <message>
      <source>Header (dict from document)</source>
      <translation>Header (dict dal documento)</translation>
    </message>
    <message>
      <source>Header (snapshot)</source>
      <translation>Header (snapshot)</translation>
    </message>
    <message>
      <source>Header Viewer</source>
      <translation>Visualizzatore header</translation>
    </message>
    <message>
      <source>Header: {0}</source>
      <translation>Header: {0}</translation>
    </message>
    <message>
      <source>Key</source>
      <translation>Chiave</translation>
    </message>
    <message>
      <source>Metadata</source>
      <translation>Metadati</translation>
    </message>
    <message>
      <source>Save Metadata</source>
      <translation>Salva metadati</translation>
    </message>
    <message>
      <source>Save Metadata…</source>
      <translation>Salva metadati…</translation>
    </message>
    <message>
      <source>Untitled</source>
      <translation>Senza titolo</translation>
    </message>
    <message>
      <source>Value</source>
      <translation>Valore</translation>
    </message>
    <message>
      <source>WCS</source>
      <translation>WCS</translation>
    </message>
    <message>
      <source>XISF File Metadata</source>
      <translation>Metadati file XISF</translation>
    </message>
    <message>
      <source>XISF Image Metadata</source>
      <translation>Metadati immagine XISF</translation>
    </message>
    <message>
      <source>XISF Properties</source>
      <translation>Proprietà XISF</translation>
    </message>
    <message>
      <source>XISF Properties (document)</source>
      <translation>Proprietà XISF (documento)</translation>
    </message>
  </context>
  <context>
    <name>HistogramDialog</name>
    <message>
      <source>Set your camera's true saturation level for clipping warnings.
Tip: take an overexposed frame and see its max ADU.</source>
      <translation>Imposta il vero livello di saturazione della tua fotocamera per avvisi di clipping.
Suggerimento: scatta un frame sovraesposto e guarda il suo ADU massimo.</translation>
    </message>
  </context>
  <context>
    <name>HistoryExplorer</name>
    <message>
      <source>Action</source>
      <translation>Azione</translation>
    </message>
    <message>
      <source>Clear history</source>
      <translation>Cancella cronologia</translation>
    </message>
    <message>
      <source>Compare with current</source>
      <translation>Confronta con attuale</translation>
    </message>
    <message>
      <source>Create snapshot</source>
      <translation>Crea istantanea</translation>
    </message>
    <message>
      <source>Current state</source>
      <translation>Stato corrente</translation>
    </message>
    <message>
      <source>Delete snapshot</source>
      <translation>Elimina istantanea</translation>
    </message>
    <message>
      <source>History</source>
      <translation>Cronologia</translation>
    </message>
    <message>
      <source>History Explorer</source>
      <translation>Esplora cronologia</translation>
    </message>
    <message>
      <source>Load snapshot</source>
      <translation>Carica istantanea</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modificato</translation>
    </message>
    <message>
      <source>No history available</source>
      <translation>Nessuna cronologia disponibile</translation>
    </message>
    <message>
      <source>Original</source>
      <translation>Originale</translation>
    </message>
    <message>
      <source>Redo</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Restore this state</source>
      <translation>Ripristina questo stato</translation>
    </message>
    <message>
      <source>Snapshot</source>
      <translation>Istantanea</translation>
    </message>
    <message>
      <source>Snapshots</source>
      <translation>Istantanee</translation>
    </message>
    <message>
      <source>Step</source>
      <translation>Passo</translation>
    </message>
    <message>
      <source>Timestamp</source>
      <translation>Timestamp</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Annulla</translation>
    </message>
  </context>
  <context>
    <name>ImagePeekerDialogPro</name>
    <message>
      <source>ASTAP/Astrometry failed:
{0}</source>
      <translation>ASTAP/Astrometry fallito:
{0}</translation>
    </message>
    <message>
      <source>Analysis:</source>
      <translation>Analisi:</translation>
    </message>
    <message>
      <source>Aperture (mm):</source>
      <translation>Apertura (mm):</translation>
    </message>
    <message>
      <source>Astrometric Distortion Analysis</source>
      <translation>Analisi distorsione astrometrica</translation>
    </message>
    <message>
      <source>Cannot determine pixel scale.</source>
      <translation>Impossibile determinare la scala pixel.</translation>
    </message>
    <message>
      <source>Choose separation color</source>
      <translation>Scegli colore separazione</translation>
    </message>
    <message>
      <source>Eccentricity Map</source>
      <translation>Mappa eccentricità</translation>
    </message>
    <message>
      <source>Exit without Saving</source>
      <translation>Esci senza salvare</translation>
    </message>
    <message>
      <source>FWHM Heatmap</source>
      <translation>Mappa calore FWHM</translation>
    </message>
    <message>
      <source>Focal Plane Analysis</source>
      <translation>Analisi piano focale</translation>
    </message>
    <message>
      <source>Focal length (mm):</source>
      <translation>Lunghezza focale (mm):</translation>
    </message>
    <message>
      <source>Grid parameters</source>
      <translation>Parametri griglia</translation>
    </message>
    <message>
      <source>Grid size:</source>
      <translation>Dimensione griglia:</translation>
    </message>
    <message>
      <source>Image Peeker</source>
      <translation>Image Peeker</translation>
    </message>
    <message>
      <source>No Distortion Model</source>
      <translation>Nessun modello distorsione</translation>
    </message>
    <message>
      <source>No image</source>
      <translation>Nessuna immagine</translation>
    </message>
    <message>
      <source>No image loaded to peek at!</source>
      <translation>Nessuna immagine caricata da esaminare!</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nessuna</translation>
    </message>
    <message>
      <source>Orientation Map</source>
      <translation>Mappa orientamento</translation>
    </message>
    <message>
      <source>Panel size:</source>
      <translation>Dimensione pannello:</translation>
    </message>
    <message>
      <source>Pixel size (µm):</source>
      <translation>Dimensione pixel (µm):</translation>
    </message>
    <message>
      <source>Plate Solve</source>
      <translation>Risolvi plate</translation>
    </message>
    <message>
      <source>Plate solve did not produce a readable WCS header.</source>
      <translation>Il plate solve non ha prodotto un header WCS leggibile.</translation>
    </message>
    <message>
      <source>Processing…</source>
      <translation>Elaborazione…</translation>
    </message>
    <message>
      <source>Running {0}…</source>
      <translation>Esecuzione {0}…</translation>
    </message>
    <message>
      <source>Save Settings &amp;&amp; Exit</source>
      <translation>Salva impostazioni ed esci</translation>
    </message>
    <message>
      <source>Sensor Tilt (µm)</source>
      <translation>Inclinazione sensore (µm)</translation>
    </message>
    <message>
      <source>Separation:</source>
      <translation>Separazione:</translation>
    </message>
    <message>
      <source>This image has a valid WCS, but no SIP distortion terms (A_*, B_*).
Astrometric distortion analysis requires a SIP-enabled solve.

Re-solve with distortion fitting enabled in ASTAP.</source>
      <translation>Questa immagine ha un WCS valido, ma nessun termine di distorsione SIP (A_*, B_*).
L'analisi della distorsione astrometrica richiede una soluzione con SIP abilitato.

Risolvi di nuovo con il fitting della distorsione abilitato in ASTAP.</translation>
    </message>
    <message>
      <source>Tilt Analysis</source>
      <translation>Analisi inclinazione</translation>
    </message>
    <message>
      <source>WCS Error</source>
      <translation>Errore WCS</translation>
    </message>
  </context>
  <context>
    <name>ImagePreviewDialog</name>
    <message>
      <source>1:1 (100%)</source>
      <translation>1:1 (100%)</translation>
    </message>
    <message>
      <source>AutoStretch (Off)</source>
      <translation>AutoStretch (Off)</translation>
    </message>
    <message>
      <source>AutoStretch (On)</source>
      <translation>AutoStretch (On)</translation>
    </message>
    <message>
      <source>Fit to Preview</source>
      <translation>Adatta all'anteprima</translation>
    </message>
    <message>
      <source>Image Preview</source>
      <translation>Anteprima immagine</translation>
    </message>
    <message>
      <source>Toggle AutoStretch</source>
      <translation>Attiva/Disattiva AutoStretch</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
    <message>
      <source>Actual Size</source>
      <translation>Dimensione reale</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Fit to Window</source>
      <translation>Adatta alla finestra</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Info</translation>
    </message>
    <message>
      <source>Open</source>
      <translation>Apri</translation>
    </message>
    <message>
      <source>Pan</source>
      <translation>Panoramica</translation>
    </message>
  </context>
  <context>
    <name>ImageSubWindow</name>
    <message>
      <source>Clear View Name (use doc name)</source>
      <translation>Cancella nome vista (usa nome documento)</translation>
    </message>
    <message>
      <source>Click: replay the last action on the base image.
Arrow: pick a specific past action to replay on the base image.</source>
      <translation>Click: ripeti l'ultima azione sull'immagine base.
Freccia: scegli un'azione passata specifica da ripetere sull'immagine base.</translation>
    </message>
    <message>
      <source>Close Image?</source>
      <translation>Chiudere immagine?</translation>
    </message>
    <message>
      <source>Create Preview (drag rectangle)</source>
      <translation>Crea anteprima (trascina rettangolo)</translation>
    </message>
    <message>
      <source>Create Preview: click, then drag on the image to define a preview rectangle.</source>
      <translation>Crea anteprima: clicca, poi trascina sull'immagine per definire un rettangolo di anteprima.</translation>
    </message>
    <message>
      <source>Drag onto another window to copy zoom/pan.
Double-click to duplicate this view.</source>
      <translation>Trascina su un'altra finestra per copiare zoom/pan.
Doppio click per duplicare questa vista.</translation>
    </message>
    <message>
      <source>Full</source>
      <translation>Completo</translation>
    </message>
    <message>
      <source>New document name:</source>
      <translation>Nuovo nome documento:</translation>
    </message>
    <message>
      <source>New view name:</source>
      <translation>Nuovo nome vista:</translation>
    </message>
    <message>
      <source>Press Space + Click/Drag to probe pixels (WCS shown if available)</source>
      <translation>Premi Spazio + Click/Trascina per sondare i pixel (WCS mostrato se disponibile)</translation>
    </message>
    <message>
      <source>Preview mode: drag a rectangle on the image to create a preview.</source>
      <translation>Modalità anteprima: trascina un rettangolo sull'immagine per creare un'anteprima.</translation>
    </message>
    <message>
      <source>Preview {0} ({1}×{2})</source>
      <translation>Anteprima {0} ({1}×{2})</translation>
    </message>
    <message>
      <source>Redo (this view)</source>
      <translation>Ripeti (questa vista)</translation>
    </message>
    <message>
      <source>Rename Document</source>
      <translation>Rinomina documento</translation>
    </message>
    <message>
      <source>Rename Document…</source>
      <translation>Rinomina documento…</translation>
    </message>
    <message>
      <source>Rename View</source>
      <translation>Rinomina vista</translation>
    </message>
    <message>
      <source>Rename View… (F2)</source>
      <translation>Rinomina vista… (F2)</translation>
    </message>
    <message>
      <source>Send to Shelf</source>
      <translation>Invia allo scaffale</translation>
    </message>
    <message>
      <source>Show pixel/WCS readout hint</source>
      <translation>Mostra suggerimento lettura pixel/WCS</translation>
    </message>
    <message>
      <source>This image has edits that aren't applied/saved.
Close anyway?</source>
      <translation>Questa immagine ha modifiche non applicate/salvate.
Chiudere comunque?</translation>
    </message>
    <message>
      <source>This image has edits that aren’t applied/saved.
Close anyway?</source>
      <translation>Questa immagine ha modifiche non applicate/salvate.
Chiudere comunque?</translation>
    </message>
    <message>
      <source>Toggle WCS grid overlay (if WCS exists)</source>
      <translation>Attiva/Disattiva overlay griglia WCS (se WCS esiste)</translation>
    </message>
    <message>
      <source>Undo (this view)</source>
      <translation>Annulla (questa vista)</translation>
    </message>
    <message>
      <source>Unlink from Linked Views</source>
      <translation>Scollega dalle viste collegate</translation>
    </message>
    <message>
      <source>Untitled</source>
      <translation>Senza titolo</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Vista</translation>
    </message>
    <message>
      <source>100%</source>
      <translation>100%</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Fit</source>
      <translation>Adatta</translation>
    </message>
    <message>
      <source>Maximize</source>
      <translation>Massimizza</translation>
    </message>
    <message>
      <source>Minimize</source>
      <translation>Riduci a icona</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modificato</translation>
    </message>
    <message>
      <source>Read-only</source>
      <translation>Sola lettura</translation>
    </message>
    <message>
      <source>Redo</source>
      <translation>Ripeti</translation>
    </message>
    <message>
      <source>Restore</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Save As...</source>
      <translation>Salva come...</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Unsaved changes</source>
      <translation>Modifiche non salvate</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
  </context>
  <context>
    <name>LivePreviewDialog</name>
    <message>
      <source>Live Mask Preview</source>
      <translation>Anteprima maschera live</translation>
    </message>
  </context>
  <context>
    <name>Main</name>
    <message>
      <source>An unexpected error occurred.</source>
      <translation>Si è verificato un errore imprevisto.</translation>
    </message>
    <message>
      <source>Application Error</source>
      <translation>Errore applicazione</translation>
    </message>
  </context>
  <context>
    <name>MaskCreationDialog</name>
    <message>
      <source>Edge Blur (px):</source>
      <translation>Sfocatura bordi (px):</translation>
    </message>
    <message>
      <source>Ellipse</source>
      <translation>Ellisse</translation>
    </message>
    <message>
      <source>Freehand</source>
      <translation>Mano libera</translation>
    </message>
    <message>
      <source>Mask Creation</source>
      <translation>Creazione maschera</translation>
    </message>
    <message>
      <source>Select Entire Image</source>
      <translation>Seleziona intera immagine</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Center</source>
      <translation>Centro</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Create Mask</source>
      <translation>Crea maschera</translation>
    </message>
    <message>
      <source>Custom Mask</source>
      <translation>Maschera personalizzata</translation>
    </message>
    <message>
      <source>Detection Threshold</source>
      <translation>Soglia rilevamento</translation>
    </message>
    <message>
      <source>End Point</source>
      <translation>Punto finale</translation>
    </message>
    <message>
      <source>Feather</source>
      <translation>Sfumatura</translation>
    </message>
    <message>
      <source>Gradient</source>
      <translation>Gradiente</translation>
    </message>
    <message>
      <source>Gradient Mask</source>
      <translation>Maschera gradiente</translation>
    </message>
    <message>
      <source>Grow Radius</source>
      <translation>Raggio crescita</translation>
    </message>
    <message>
      <source>High</source>
      <translation>Alto</translation>
    </message>
    <message>
      <source>Invert</source>
      <translation>Inverti</translation>
    </message>
    <message>
      <source>Linear</source>
      <translation>Lineare</translation>
    </message>
    <message>
      <source>Load Mask...</source>
      <translation>Carica maschera...</translation>
    </message>
    <message>
      <source>Low</source>
      <translation>Basso</translation>
    </message>
    <message>
      <source>Luminance Mask</source>
      <translation>Maschera luminanza</translation>
    </message>
    <message>
      <source>Mask Type</source>
      <translation>Tipo maschera</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Radial</source>
      <translation>Radiale</translation>
    </message>
    <message>
      <source>Radial Mask</source>
      <translation>Maschera radiale</translation>
    </message>
    <message>
      <source>Radius</source>
      <translation>Raggio</translation>
    </message>
    <message>
      <source>Range</source>
      <translation>Intervallo</translation>
    </message>
    <message>
      <source>Range Mask</source>
      <translation>Maschera intervallo</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Save Mask...</source>
      <translation>Salva maschera...</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Impostazioni</translation>
    </message>
    <message>
      <source>Smoothness</source>
      <translation>Morbidezza</translation>
    </message>
    <message>
      <source>Star Detection</source>
      <translation>Rilevamento stelle</translation>
    </message>
    <message>
      <source>Star Mask</source>
      <translation>Maschera stelle</translation>
    </message>
    <message>
      <source>Star Size</source>
      <translation>Dimensione stelle</translation>
    </message>
    <message>
      <source>Start Point</source>
      <translation>Punto iniziale</translation>
    </message>
  </context>
  <context>
    <name>MaskMixin</name>
    <message>
      <source>Choose Mask Image</source>
      <translation>Scegli immagine maschera</translation>
    </message>
    <message>
      <source>Could not resolve mask document.</source>
      <translation>Impossibile risolvere documento maschera.</translation>
    </message>
    <message>
      <source>Mask</source>
      <translation>Maschera</translation>
    </message>
    <message>
      <source>Mask Overlay</source>
      <translation>Overlay maschera</translation>
    </message>
    <message>
      <source>No active document.</source>
      <translation>Nessun documento attivo.</translation>
    </message>
    <message>
      <source>No active mask on this image.</source>
      <translation>Nessuna maschera attiva su questa immagine.</translation>
    </message>
    <message>
      <source>No active mask to remove.</source>
      <translation>Nessuna maschera attiva da rimuovere.</translation>
    </message>
    <message>
      <source>No image</source>
      <translation>Nessuna immagine</translation>
    </message>
    <message>
      <source>Open an image first.</source>
      <translation>Apri prima un'immagine.</translation>
    </message>
    <message>
      <source>Open another image to use as a mask.</source>
      <translation>Apri un'altra immagine da usare come maschera.</translation>
    </message>
    <message>
      <source>Use this image as mask:</source>
      <translation>Usa questa immagine come maschera:</translation>
    </message>
    <message>
      <source>Apply Mask</source>
      <translation>Applica maschera</translation>
    </message>
    <message>
      <source>Create Mask</source>
      <translation>Crea maschera</translation>
    </message>
    <message>
      <source>Hide Mask</source>
      <translation>Nascondi maschera</translation>
    </message>
    <message>
      <source>Invert Mask</source>
      <translation>Inverti maschera</translation>
    </message>
    <message>
      <source>Load Mask...</source>
      <translation>Carica maschera...</translation>
    </message>
    <message>
      <source>Mask Active</source>
      <translation>Maschera attiva</translation>
    </message>
    <message>
      <source>No Mask</source>
      <translation>Nessuna maschera</translation>
    </message>
    <message>
      <source>Remove Mask</source>
      <translation>Rimuovi maschera</translation>
    </message>
    <message>
      <source>Save Mask...</source>
      <translation>Salva maschera...</translation>
    </message>
    <message>
      <source>Show Mask</source>
      <translation>Mostra maschera</translation>
    </message>
  </context>
  <context>
    <name>MaskPreviewDialog</name>
    <message>
      <source>Mask Preview</source>
      <translation>Anteprima maschera</translation>
    </message>
    <message>
      <source>Push as New Document…</source>
      <translation>Applica come nuovo documento…</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Blu</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Color</source>
      <translation>Colore</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Verde</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation>Opacità</translation>
    </message>
    <message>
      <source>Red</source>
      <translation>Rosso</translation>
    </message>
  </context>
  <context>
    <name>MenuMixin</name>
    <message>
      <source>&amp;About</source>
      <translation>&amp;Info</translation>
    </message>
    <message>
      <source>&amp;Edit</source>
      <translation>&amp;Modifica</translation>
    </message>
    <message>
      <source>&amp;File</source>
      <translation>&amp;File</translation>
    </message>
    <message>
      <source>&amp;Functions</source>
      <translation>&amp;Funzioni</translation>
    </message>
    <message>
      <source>&amp;Geometry</source>
      <translation>&amp;Geometria</translation>
    </message>
    <message>
      <source>&amp;Header Mods &amp;&amp; Misc</source>
      <translation>&amp;Modifica Header e Varie</translation>
    </message>
    <message>
      <source>&amp;History</source>
      <translation>&amp;Cronologia</translation>
    </message>
    <message>
      <source>&amp;Masks</source>
      <translation>&amp;Maschere</translation>
    </message>
    <message>
      <source>&amp;Scripts</source>
      <translation>&amp;Script</translation>
    </message>
    <message>
      <source>&amp;Settings</source>
      <translation>&amp;Impostazioni</translation>
    </message>
    <message>
      <source>&amp;Shortcuts</source>
      <translation>&amp;Scorciatoie</translation>
    </message>
    <message>
      <source>&amp;Smart Tools</source>
      <translation>&amp;Strumenti Smart</translation>
    </message>
    <message>
      <source>&amp;Star Stuff</source>
      <translation>&amp;Stelle</translation>
    </message>
    <message>
      <source>&amp;Tools</source>
      <translation>&amp;Strumenti</translation>
    </message>
    <message>
      <source>&amp;View</source>
      <translation>&amp;Vista</translation>
    </message>
    <message>
      <source>&amp;What's In My...</source>
      <translation>&amp;Cosa c'è nella mia...</translation>
    </message>
    <message>
      <source>About...</source>
      <translation>Informazioni...</translation>
    </message>
    <message>
      <source>Clear All Shortcuts</source>
      <translation>Cancella tutte le scorciatoie</translation>
    </message>
    <message>
      <source>Clear List</source>
      <translation>Cancella lista</translation>
    </message>
    <message>
      <source>Export Shortcuts...</source>
      <translation>Esporta scorciatoie...</translation>
    </message>
    <message>
      <source>Group A</source>
      <translation>Gruppo A</translation>
    </message>
    <message>
      <source>Group B</source>
      <translation>Gruppo B</translation>
    </message>
    <message>
      <source>Group C</source>
      <translation>Gruppo C</translation>
    </message>
    <message>
      <source>Group D</source>
      <translation>Gruppo D</translation>
    </message>
    <message>
      <source>Import Shortcuts...</source>
      <translation>Importa scorciatoie...</translation>
    </message>
    <message>
      <source>Keyboard Shortcut Cheat Sheet...</source>
      <translation>Schema scorciatoie tastiera...</translation>
    </message>
    <message>
      <source>No recent images</source>
      <translation>Nessuna immagine recente</translation>
    </message>
    <message>
      <source>No recent projects</source>
      <translation>Nessun progetto recente</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nessuno</translation>
    </message>
    <message>
      <source>Open Recent Images</source>
      <translation>Immagini recenti</translation>
    </message>
    <message>
      <source>Open Recent Projects</source>
      <translation>Progetti recenti</translation>
    </message>
    <message>
      <source>Preferences...</source>
      <translation>Preferenze...</translation>
    </message>
  </context>
  <context>
    <name>MetricsPanel</name>
    <message>
      <source>Background</source>
      <translation>Sfondo</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Computing frame metrics…</source>
      <translation>Calcolo metriche frame…</translation>
    </message>
    <message>
      <source>Don't show again</source>
      <translation>Non mostrare più</translation>
    </message>
    <message>
      <source>Eccentricity</source>
      <translation>Eccentricità</translation>
    </message>
    <message>
      <source>FWHM (px)</source>
      <translation>FWHM (px)</translation>
    </message>
    <message>
      <source>Heads-up</source>
      <translation>Attenzione</translation>
    </message>
    <message>
      <source>Star Count</source>
      <translation>Conteggio stelle</translation>
    </message>
    <message>
      <source>This is going to use ALL your CPU cores and the UI may lock up until it finishes.

Continue?</source>
      <translation>Questo utilizzerà TUTTI i core della CPU e l'interfaccia potrebbe bloccarsi fino al termine.

Continuare?</translation>
    </message>
  </context>
  <context>
    <name>MetricsWindow</name>
    <message>
      <source>All</source>
      <translation>Tutti</translation>
    </message>
    <message>
      <source>Flagged Items {0}/{1}  ({2:.1f}%)</source>
      <translation>Elementi contrassegnati {0}/{1}  ({2:.1f}%)</translation>
    </message>
    <message>
      <source>Frame Metrics</source>
      <translation>Metriche frame</translation>
    </message>
    <message>
      <source>Instructions:
 • Use the filter dropdown to restrict by FILTER.
 • Click a dot to flag/unflag a frame.
 • Shift-click a dot to preview the image.
 • Drag the red lines to set thresholds.</source>
      <translation>Istruzioni:
 • Usa il menu a tendina filtro per restringere per FILTRO.
 • Clicca un punto per contrassegnare/decontrassegnare un frame.
 • Shift+click su un punto per anteprima dell'immagine.
 • Trascina le linee rosse per impostare le soglie.</translation>
    </message>
  </context>
  <context>
    <name>MinorBodyWorker</name>
    <message>
      <source>Minor-body search: preparing catalog query...</source>
      <translation>Ricerca corpi minori: preparazione query catalogo...</translation>
    </message>
  </context>
  <context>
    <name>MorphologyDialogPro</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Iterations:</source>
      <translation>Iterazioni:</translation>
    </message>
    <message>
      <source>Kernel size:</source>
      <translation>Dimensione kernel:</translation>
    </message>
    <message>
      <source>Morphological Operations</source>
      <translation>Operazioni morfologiche</translation>
    </message>
    <message>
      <source>Morphological Parameters</source>
      <translation>Parametri morfologici</translation>
    </message>
    <message>
      <source>Operation:</source>
      <translation>Operazione:</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Reimposta</translation>
    </message>
  </context>
  <context>
    <name>PixelMathDialog</name>
    <message>
      <source>Add blend</source>
      <translation>Fusione aggiungi</translation>
    </message>
    <message>
      <source>Available views</source>
      <translation>Viste disponibili</translation>
    </message>
    <message>
      <source>Average</source>
      <translation>Media</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Cancella</translation>
    </message>
    <message>
      <source>Color</source>
      <translation>Colore</translation>
    </message>
    <message>
      <source>Create new image</source>
      <translation>Crea nuova immagine</translation>
    </message>
    <message>
      <source>Difference</source>
      <translation>Differenza</translation>
    </message>
    <message>
      <source>Division by zero</source>
      <translation>Divisione per zero</translation>
    </message>
    <message>
      <source>Enter expression</source>
      <translation>Inserisci espressione</translation>
    </message>
    <message>
      <source>Evaluate</source>
      <translation>Valuta</translation>
    </message>
    <message>
      <source>Expression</source>
      <translation>Espressione</translation>
    </message>
    <message>
      <source>Functions</source>
      <translation>Funzioni</translation>
    </message>
    <message>
      <source>History</source>
      <translation>Cronologia</translation>
    </message>
    <message>
      <source>Insert function</source>
      <translation>Inserisci funzione</translation>
    </message>
    <message>
      <source>Insert variable</source>
      <translation>Inserisci variabile</translation>
    </message>
    <message>
      <source>Invalid expression</source>
      <translation>Espressione non valida</translation>
    </message>
    <message>
      <source>Load expression</source>
      <translation>Carica espressione</translation>
    </message>
    <message>
      <source>Logical</source>
      <translation>Logiche</translation>
    </message>
    <message>
      <source>Luminance mask</source>
      <translation>Maschera luminanza</translation>
    </message>
    <message>
      <source>Mathematical</source>
      <translation>Matematiche</translation>
    </message>
    <message>
      <source>Maximum</source>
      <translation>Massimo</translation>
    </message>
    <message>
      <source>Minimum</source>
      <translation>Minimo</translation>
    </message>
    <message>
      <source>Multiply blend</source>
      <translation>Fusione moltiplica</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Output</translation>
    </message>
    <message>
      <source>Pixel Math</source>
      <translation>Pixel Math</translation>
    </message>
    <message>
      <source>Presets</source>
      <translation>Preset</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Range mask</source>
      <translation>Maschera intervallo</translation>
    </message>
    <message>
      <source>Replace active image</source>
      <translation>Sostituisci immagine attiva</translation>
    </message>
    <message>
      <source>Result</source>
      <translation>Risultato</translation>
    </message>
    <message>
      <source>Save expression</source>
      <translation>Salva espressione</translation>
    </message>
    <message>
      <source>Screen blend</source>
      <translation>Fusione schermo</translation>
    </message>
    <message>
      <source>Star mask</source>
      <translation>Maschera stelle</translation>
    </message>
    <message>
      <source>Statistical</source>
      <translation>Statistiche</translation>
    </message>
    <message>
      <source>Subtract blend</source>
      <translation>Fusione sottrai</translation>
    </message>
    <message>
      <source>Syntax error</source>
      <translation>Errore sintassi</translation>
    </message>
    <message>
      <source>Variable not found</source>
      <translation>Variabile non trovata</translation>
    </message>
    <message>
      <source>Variables</source>
      <translation>Variabili</translation>
    </message>
  </context>
  <context>
    <name>PlateSolver</name>
    <message>
      <source>ASTAP path is not set (see Preferences) or file not found.</source>
      <translation>Percorso ASTAP non impostato (vedi Preferenze) o file non trovato.</translation>
    </message>
    <message>
      <source>ASTAP returned a non-zero exit code.</source>
      <translation>ASTAP ha restituito un codice di uscita non zero.</translation>
    </message>
    <message>
      <source>ASTAP timed out.</source>
      <translation>ASTAP scaduto.</translation>
    </message>
    <message>
      <source>Active document has no image data.</source>
      <translation>Il documento attivo non ha dati immagine.</translation>
    </message>
    <message>
      <source>Astrometry.net API Key</source>
      <translation>Chiave API Astrometry.net</translation>
    </message>
    <message>
      <source>Astrometry.net calibration not received in time.</source>
      <translation>Calibrazione Astrometry.net non ricevuta in tempo.</translation>
    </message>
    <message>
      <source>Astrometry.net job ID not received in time.</source>
      <translation>ID lavoro Astrometry.net non ricevuto in tempo.</translation>
    </message>
    <message>
      <source>Astrometry.net login failed.</source>
      <translation>Login Astrometry.net fallito.</translation>
    </message>
    <message>
      <source>Astrometry.net upload failed.</source>
      <translation>Caricamento Astrometry.net fallito.</translation>
    </message>
    <message>
      <source>Enter your Astrometry.net API key:</source>
      <translation>Inserisci la tua chiave API Astrometry.net:</translation>
    </message>
    <message>
      <source>Failed to start ASTAP: {0}</source>
      <translation>Avvio ASTAP fallito: {0}</translation>
    </message>
    <message>
      <source>No active document to plate-solve.</source>
      <translation>Nessun documento attivo da risolvere.</translation>
    </message>
    <message>
      <source>Status:</source>
      <translation>Stato:</translation>
    </message>
    <message>
      <source>Status: ASTAP failed ({0}). Falling back to Astrometry.net…</source>
      <translation>Stato: ASTAP fallito ({0}). Fallback a Astrometry.net…</translation>
    </message>
    <message>
      <source>Status: ASTAP failed to start.</source>
      <translation>Stato: avvio ASTAP fallito.</translation>
    </message>
    <message>
      <source>Status: ASTAP solving…</source>
      <translation>Stato: risoluzione ASTAP…</translation>
    </message>
    <message>
      <source>Status: ASTAP timed out.</source>
      <translation>Stato: ASTAP scaduto.</translation>
    </message>
    <message>
      <source>Status: Astrometry.net failed ({0}).</source>
      <translation>Stato: Astrometry.net fallito ({0}).</translation>
    </message>
    <message>
      <source>Status: Building WCS header from calibration…</source>
      <translation>Stato: Costruzione header WCS dalla calibrazione…</translation>
    </message>
    <message>
      <source>Status: Downloading WCS file (with SIP) from Astrometry.net…</source>
      <translation>Stato: Download file WCS (con SIP) da Astrometry.net…</translation>
    </message>
    <message>
      <source>Status: Job assigned (ID {0}).</source>
      <translation>Stato: Lavoro assegnato (ID {0}).</translation>
    </message>
    <message>
      <source>Status: Logging in to Astrometry.net…</source>
      <translation>Stato: Accesso a Astrometry.net…</translation>
    </message>
    <message>
      <source>Status: Login canceled (no API key).</source>
      <translation>Stato: Login annullato (nessuna chiave API).</translation>
    </message>
    <message>
      <source>Status: Login failed.</source>
      <translation>Stato: Login fallito.</translation>
    </message>
    <message>
      <source>Status: Login successful.</source>
      <translation>Stato: Login riuscito.</translation>
    </message>
    <message>
      <source>Status: Plate solve completed.</source>
      <translation>Stato: Plate solve completato.</translation>
    </message>
    <message>
      <source>Status: Preparing full-res 16-bit FITS for web solve…</source>
      <translation>Stato: Preparazione FITS 16-bit piena risoluzione per solve web…</translation>
    </message>
    <message>
      <source>Status: Preparing plate solve…</source>
      <translation>Stato: Preparazione plate solve…</translation>
    </message>
    <message>
      <source>Status: Running local solve-field…</source>
      <translation>Stato: Esecuzione solve-field locale…</translation>
    </message>
    <message>
      <source>Status: Solution received.</source>
      <translation>Stato: Soluzione ricevuta.</translation>
    </message>
    <message>
      <source>Status: Solved via Astrometry.net.</source>
      <translation>Stato: Risolto tramite Astrometry.net.</translation>
    </message>
    <message>
      <source>Status: Solved with ASTAP.</source>
      <translation>Stato: Risolto con ASTAP.</translation>
    </message>
    <message>
      <source>Status: Solving with ASTAP…</source>
      <translation>Stato: Risoluzione con ASTAP…</translation>
    </message>
    <message>
      <source>Status: Upload complete.</source>
      <translation>Stato: Caricamento completato.</translation>
    </message>
    <message>
      <source>Status: Upload failed (temp FITS empty).</source>
      <translation>Stato: Caricamento fallito (FITS temporaneo vuoto).</translation>
    </message>
    <message>
      <source>Status: Upload failed.</source>
      <translation>Stato: Caricamento fallito.</translation>
    </message>
    <message>
      <source>Status: Uploading image to Astrometry.net…</source>
      <translation>Stato: Caricamento immagine su Astrometry.net…</translation>
    </message>
    <message>
      <source>Status: Waiting for job assignment…</source>
      <translation>Stato: In attesa assegnazione lavoro…</translation>
    </message>
    <message>
      <source>Status: Waiting for solution…</source>
      <translation>Stato: In attesa soluzione…</translation>
    </message>
    <message>
      <source>Status: process did not exit normally.</source>
      <translation>Stato: processo non terminato normalmente.</translation>
    </message>
    <message>
      <source>Status: process timed out.</source>
      <translation>Stato: processo scaduto.</translation>
    </message>
    <message>
      <source>Status: solve-field failed to start.</source>
      <translation>Stato: avvio solve-field fallito.</translation>
    </message>
    <message>
      <source>Status: solve-field failed.</source>
      <translation>Stato: solve-field fallito.</translation>
    </message>
    <message>
      <source>Status: solve-field timed out.</source>
      <translation>Stato: solve-field scaduto.</translation>
    </message>
    <message>
      <source>Status: {0} retry {1}/{2}…</source>
      <translation>Stato: {0} tentativo {1}/{2}…</translation>
    </message>
    <message>
      <source>Temp FITS for web upload is empty/tiny ({0} bytes).</source>
      <translation>FITS temporaneo per upload web vuoto/piccolo ({0} bytes).</translation>
    </message>
    <message>
      <source>requests not available for astrometry.net API.</source>
      <translation>requests non disponibile per API astrometry.net.</translation>
    </message>
    <message>
      <source>solve-field not configured.</source>
      <translation>solve-field non configurato.</translation>
    </message>
    <message>
      <source>solve-field returned no header.</source>
      <translation>solve-field non ha restituito header.</translation>
    </message>
    <message>
      <source>Active Image</source>
      <translation>Immagine attiva</translation>
    </message>
    <message>
      <source>Apply WCS</source>
      <translation>Applica WCS</translation>
    </message>
    <message>
      <source>Auto-detect</source>
      <translation>Rilevamento auto</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Center Dec</source>
      <translation>Dec centrale</translation>
    </message>
    <message>
      <source>Center RA</source>
      <translation>AR centrale</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Copy to Clipboard</source>
      <translation>Copia negli appunti</translation>
    </message>
    <message>
      <source>Dec (J2000)</source>
      <translation>Dec (J2000)</translation>
    </message>
    <message>
      <source>Failed</source>
      <translation>Fallito</translation>
    </message>
    <message>
      <source>Field Height</source>
      <translation>Altezza campo</translation>
    </message>
    <message>
      <source>Field Width</source>
      <translation>Larghezza campo</translation>
    </message>
    <message>
      <source>From File...</source>
      <translation>Da file...</translation>
    </message>
    <message>
      <source>Hints</source>
      <translation>Suggerimenti</translation>
    </message>
    <message>
      <source>Image</source>
      <translation>Immagine</translation>
    </message>
    <message>
      <source>Local</source>
      <translation>Locale</translation>
    </message>
    <message>
      <source>No solution found</source>
      <translation>Nessuna soluzione trovata</translation>
    </message>
    <message>
      <source>Online</source>
      <translation>Online</translation>
    </message>
    <message>
      <source>Pixel Scale</source>
      <translation>Scala pixel</translation>
    </message>
    <message>
      <source>Plate Solver</source>
      <translation>Plate Solver</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>RA (J2000)</source>
      <translation>AR (J2000)</translation>
    </message>
    <message>
      <source>RMS Error</source>
      <translation>Errore RMS</translation>
    </message>
    <message>
      <source>Radius</source>
      <translation>Raggio</translation>
    </message>
    <message>
      <source>Ready</source>
      <translation>Pronto</translation>
    </message>
    <message>
      <source>Results</source>
      <translation>Risultati</translation>
    </message>
    <message>
      <source>Rotation</source>
      <translation>Rotazione</translation>
    </message>
    <message>
      <source>Scale</source>
      <translation>Scala</translation>
    </message>
    <message>
      <source>Solution found!</source>
      <translation>Soluzione trovata!</translation>
    </message>
    <message>
      <source>Solve</source>
      <translation>Risolvi</translation>
    </message>
    <message>
      <source>Solver</source>
      <translation>Risolutore</translation>
    </message>
    <message>
      <source>Solver Settings</source>
      <translation>Impostazioni risolutore</translation>
    </message>
    <message>
      <source>Solving...</source>
      <translation>Risoluzione...</translation>
    </message>
    <message>
      <source>Stars Matched</source>
      <translation>Stelle abbinate</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Stato</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Successo</translation>
    </message>
    <message>
      <source>Timeout</source>
      <translation>Timeout</translation>
    </message>
    <message>
      <source>View in Aladin</source>
      <translation>Visualizza in Aladin</translation>
    </message>
    <message>
      <source>arcsec/pixel</source>
      <translation>arcsec/pixel</translation>
    </message>
    <message>
      <source>deg</source>
      <translation>gradi</translation>
    </message>
  </context>
  <context>
    <name>PlateSolverDialog</name>
    <message>
      <source>  ✔ saved: </source>
      <translation>  ✔ salvato: </translation>
    </message>
    <message>
      <source>  ❌ Failed to load</source>
      <translation>  ❌ Caricamento fallito</translation>
    </message>
    <message>
      <source>  ❌ error: </source>
      <translation>  ❌ errore: </translation>
    </message>
    <message>
      <source>ASTAP -fov. Compute uses image height × scale; Auto lets ASTAP infer.</source>
      <translation>ASTAP -fov. Calcola usa altezza immagine × scala; Auto lascia inferire ASTAP.</translation>
    </message>
    <message>
      <source>ASTAP -r. Auto lets ASTAP choose; Value forces a cone radius.</source>
      <translation>ASTAP -r. Auto lascia scegliere ASTAP; Valore forza un raggio cono.</translation>
    </message>
    <message>
      <source>ASTAP path missing.
Set it in Preferences → ASTAP executable.</source>
      <translation>Percorso ASTAP mancante.
Impostalo in Preferenze → Eseguibile ASTAP.</translation>
    </message>
    <message>
      <source>ASTAP path missing. Set Preferences → ASTAP executable.</source>
      <translation>Percorso ASTAP mancante. Imposta Preferenze → Eseguibile ASTAP.</translation>
    </message>
    <message>
      <source>Active View</source>
      <translation>Vista attiva</translation>
    </message>
    <message>
      <source>Auto (-fov 0)</source>
      <translation>Automatico (-fov 0)</translation>
    </message>
    <message>
      <source>Auto (-r 0)</source>
      <translation>Automatico (-r 0)</translation>
    </message>
    <message>
      <source>Auto (from header)</source>
      <translation>Automatico (da header)</translation>
    </message>
    <message>
      <source>Batch</source>
      <translation>Batch</translation>
    </message>
    <message>
      <source>Batch plate solving completed.</source>
      <translation>Plate solving batch completato.</translation>
    </message>
    <message>
      <source>Browse Input…</source>
      <translation>Sfoglia input…</translation>
    </message>
    <message>
      <source>Browse Output…</source>
      <translation>Sfoglia output…</translation>
    </message>
    <message>
      <source>Browse…</source>
      <translation>Sfoglia…</translation>
    </message>
    <message>
      <source>Cannot read image:
{0}</source>
      <translation>Impossibile leggere immagine:
{0}</translation>
    </message>
    <message>
      <source>Choose Image</source>
      <translation>Scegli immagine</translation>
    </message>
    <message>
      <source>Choose a file to solve.</source>
      <translation>Scegli un file da risolvere.</translation>
    </message>
    <message>
      <source>Choose an image…</source>
      <translation>Scegli un'immagine…</translation>
    </message>
    <message>
      <source>Choose input directory</source>
      <translation>Scegli cartella input</translation>
    </message>
    <message>
      <source>Choose output directory</source>
      <translation>Scegli cartella output</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Compute from scale</source>
      <translation>Calcola da scala</translation>
    </message>
    <message>
      <source>Dec (e.g. +40:42:43 or 40.7123)</source>
      <translation>Dec (es. +40:42:43 o 40.7123)</translation>
    </message>
    <message>
      <source>FITS files (*.fits *.fit)</source>
      <translation>File FITS (*.fits *.fit)</translation>
    </message>
    <message>
      <source>FOV:</source>
      <translation>FOV:</translation>
    </message>
    <message>
      <source>Failed to save: {0}</source>
      <translation>Salvataggio fallito: {0}</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Found {0} files. Starting batch…</source>
      <translation>Trovati {0} file. Avvio batch…</translation>
    </message>
    <message>
      <source>Images (*.fits *.fit *.xisf *.tif *.tiff *.png *.jpg *.jpeg);;All files (*)</source>
      <translation>Immagini (*.fits *.fit *.xisf *.tif *.tiff *.png *.jpg *.jpeg);;Tutti i file (*)</translation>
    </message>
    <message>
      <source>Input directory</source>
      <translation>Cartella input</translation>
    </message>
    <message>
      <source>Manual</source>
      <translation>Manuale</translation>
    </message>
    <message>
      <source>Manual RA/Dec/Scale:</source>
      <translation>RA/Dec/Scala manuali:</translation>
    </message>
    <message>
      <source>Mode:</source>
      <translation>Modalità:</translation>
    </message>
    <message>
      <source>No acceptable image files found.</source>
      <translation>Nessun file immagine accettabile trovato.</translation>
    </message>
    <message>
      <source>No active image view.</source>
      <translation>Nessuna vista immagine attiva.</translation>
    </message>
    <message>
      <source>None (blind)</source>
      <translation>Nessuno (cieco)</translation>
    </message>
    <message>
      <source>Output directory</source>
      <translation>Cartella output</translation>
    </message>
    <message>
      <source>Pixel scale in arcseconds/pixel (e.g., 1.46).</source>
      <translation>Scala pixel in arcosecondi/pixel (es. 1.46).</translation>
    </message>
    <message>
      <source>Plate Solver</source>
      <translation>Plate Solver</translation>
    </message>
    <message>
      <source>Please choose a valid input directory.</source>
      <translation>Scegli una cartella input valida.</translation>
    </message>
    <message>
      <source>Please choose a valid output directory.</source>
      <translation>Scegli una cartella output valida.</translation>
    </message>
    <message>
      <source>RA (e.g. 22:32:14 or 338.1385)</source>
      <translation>RA (es. 22:32:14 o 338.1385)</translation>
    </message>
    <message>
      <source>Save Error</source>
      <translation>Errore salvataggio</translation>
    </message>
    <message>
      <source>Save Plate-Solved FITS</source>
      <translation>Salva FITS risolto</translation>
    </message>
    <message>
      <source>Scale [" / px] (e.g. 1.46)</source>
      <translation>Scala [" / px] (es. 1.46)</translation>
    </message>
    <message>
      <source>Search radius:</source>
      <translation>Raggio ricerca:</translation>
    </message>
    <message>
      <source>Seed mode:</source>
      <translation>Modalità seed:</translation>
    </message>
    <message>
      <source>Seeding &amp; Constraints</source>
      <translation>Seed e vincoli</translation>
    </message>
    <message>
      <source>Selected file does not exist.</source>
      <translation>Il file selezionato non esiste.</translation>
    </message>
    <message>
      <source>Solve the currently active image view.</source>
      <translation>Risolvi la vista immagine attualmente attiva.</translation>
    </message>
    <message>
      <source>Solved (not saved).</source>
      <translation>Risolto (non salvato).</translation>
    </message>
    <message>
      <source>Solved FITS saved:
{0}</source>
      <translation>FITS risolto salvato:
{0}</translation>
    </message>
    <message>
      <source>Solved with ASTAP (WCS + SIP applied to active doc).</source>
      <translation>Risolto con ASTAP (WCS + SIP applicato al doc attivo).</translation>
    </message>
    <message>
      <source>Start</source>
      <translation>Avvia</translation>
    </message>
    <message>
      <source>Status:</source>
      <translation>Stato:</translation>
    </message>
    <message>
      <source>Unsupported or unreadable image.</source>
      <translation>Immagine non supportata o illeggibile.</translation>
    </message>
    <message>
      <source>Use FITS header, your manual RA/Dec/scale, or blind solve.</source>
      <translation>Usa header FITS, i tuoi RA/Dec/scala manuali, o solve cieco.</translation>
    </message>
    <message>
      <source>Value (deg)</source>
      <translation>Valore (gradi)</translation>
    </message>
    <message>
      <source>e.g. 1.80</source>
      <translation>es. 1.80</translation>
    </message>
    <message>
      <source>e.g. 5.0</source>
      <translation>es. 5.0</translation>
    </message>
    <message>
      <source>Advanced Options</source>
      <translation>Opzioni avanzate</translation>
    </message>
    <message>
      <source>Apply to Image</source>
      <translation>Applica a immagine</translation>
    </message>
    <message>
      <source>Browse...</source>
      <translation>Sfoglia...</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Center Dec</source>
      <translation>Dec centrale</translation>
    </message>
    <message>
      <source>Center RA</source>
      <translation>AR centrale</translation>
    </message>
    <message>
      <source>Downsample</source>
      <translation>Sottocampiona</translation>
    </message>
    <message>
      <source>Export Annotation</source>
      <translation>Esporta annotazione</translation>
    </message>
    <message>
      <source>Image Source</source>
      <translation>Sorgente immagine</translation>
    </message>
    <message>
      <source>Load from file</source>
      <translation>Carica da file</translation>
    </message>
    <message>
      <source>Max</source>
      <translation>Max</translation>
    </message>
    <message>
      <source>Max Stars</source>
      <translation>Stelle max</translation>
    </message>
    <message>
      <source>Min</source>
      <translation>Min</translation>
    </message>
    <message>
      <source>Pixel Scale Range</source>
      <translation>Intervallo scala pixel</translation>
    </message>
    <message>
      <source>Plate Solve</source>
      <translation>Plate Solve</translation>
    </message>
    <message>
      <source>Save WCS</source>
      <translation>Salva WCS</translation>
    </message>
    <message>
      <source>Search Parameters</source>
      <translation>Parametri ricerca</translation>
    </message>
    <message>
      <source>Search Radius</source>
      <translation>Raggio ricerca</translation>
    </message>
    <message>
      <source>Solution</source>
      <translation>Soluzione</translation>
    </message>
    <message>
      <source>Solve</source>
      <translation>Risolvi</translation>
    </message>
    <message>
      <source>Solver Configuration</source>
      <translation>Configurazione risolutore</translation>
    </message>
    <message>
      <source>Solver Type</source>
      <translation>Tipo risolutore</translation>
    </message>
    <message>
      <source>Use active view</source>
      <translation>Usa vista attiva</translation>
    </message>
    <message>
      <source>Use image hints</source>
      <translation>Usa suggerimenti immagine</translation>
    </message>
  </context>
  <context>
    <name>PreviewPane</name>
    <message>
      <source>AutoStretch</source>
      <translation>AutoStretch</translation>
    </message>
    <message>
      <source>Fit to Preview</source>
      <translation>Adatta all'anteprima</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
  </context>
  <context>
    <name>RGBAlignDialog</name>
    <message>
      <source>Align</source>
      <translation>Allinea</translation>
    </message>
    <message>
      <source>Alignment model:</source>
      <translation>Modello allineamento:</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Create new document (keep original)</source>
      <translation>Crea nuovo documento (mantieni originale)</translation>
    </message>
    <message>
      <source>RGB Align</source>
      <translation>Allineamento RGB</translation>
    </message>
    <message>
      <source>SEP sigma:</source>
      <translation>Sigma SEP:</translation>
    </message>
    <message>
      <source>Trial detect stars</source>
      <translation>Test rilevamento stelle</translation>
    </message>
    <message>
      <source>Affine</source>
      <translation>Affine</translation>
    </message>
    <message>
      <source>Align B to G</source>
      <translation>Allinea B a G</translation>
    </message>
    <message>
      <source>Align R to G</source>
      <translation>Allinea R a G</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Blu</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Verde</translation>
    </message>
    <message>
      <source>Homography</source>
      <translation>Omografia</translation>
    </message>
    <message>
      <source>Method</source>
      <translation>Metodo</translation>
    </message>
    <message>
      <source>Polynomial</source>
      <translation>Polinomiale</translation>
    </message>
    <message>
      <source>Polynomial Order</source>
      <translation>Ordine polinomiale</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>RGB Alignment</source>
      <translation>Allineamento RGB</translation>
    </message>
    <message>
      <source>Red</source>
      <translation>Rosso</translation>
    </message>
    <message>
      <source>Reference Channel</source>
      <translation>Canale riferimento</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Show before/after</source>
      <translation>Mostra prima/dopo</translation>
    </message>
  </context>
  <context>
    <name>RGBCombinationDialogPro</name>
    <message>
      <source>Blue:</source>
      <translation>Blu:</translation>
    </message>
    <message>
      <source>Blue: Not selected</source>
      <translation>Blu: Non selezionato</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Combine</source>
      <translation>Combina</translation>
    </message>
    <message>
      <source>Files</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Green:</source>
      <translation>Verde:</translation>
    </message>
    <message>
      <source>Green: Not selected</source>
      <translation>Verde: Non selezionato</translation>
    </message>
    <message>
      <source>Load Blue…</source>
      <translation>Carica blu…</translation>
    </message>
    <message>
      <source>Load Green…</source>
      <translation>Carica verde…</translation>
    </message>
    <message>
      <source>Load Individual Files</source>
      <translation>Carica file individuali</translation>
    </message>
    <message>
      <source>Load Red…</source>
      <translation>Carica rosso…</translation>
    </message>
    <message>
      <source>RGB Combination</source>
      <translation>Combinazione RGB</translation>
    </message>
    <message>
      <source>Red:</source>
      <translation>Rosso:</translation>
    </message>
    <message>
      <source>Red: Not selected</source>
      <translation>Rosso: Non selezionato</translation>
    </message>
    <message>
      <source>Select Open Views for R / G / B</source>
      <translation>Seleziona viste aperte per R / G / B</translation>
    </message>
    <message>
      <source>Select RGB Combination Mode</source>
      <translation>Seleziona modalità combinazione RGB</translation>
    </message>
    <message>
      <source>Use Open Views</source>
      <translation>Usa viste aperte</translation>
    </message>
  </context>
  <context>
    <name>ReferenceFrameReviewDialog</name>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Disable Autostretch</source>
      <translation>Disabilita autostretch</translation>
    </message>
    <message>
      <source>Enable Autostretch</source>
      <translation>Abilita autostretch</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>FITS Files (*.fits *.fit);;All Files (*)</source>
      <translation>File FITS (*.fits *.fit);;Tutti i file (*)</translation>
    </message>
    <message>
      <source>Failed to load the reference image.</source>
      <translation>Caricamento immagine di riferimento fallito.</translation>
    </message>
    <message>
      <source>Reference Frame Review</source>
      <translation>Revisione frame di riferimento</translation>
    </message>
    <message>
      <source>Reference Preview</source>
      <translation>Anteprima riferimento</translation>
    </message>
    <message>
      <source>Reference image not loaded.</source>
      <translation>Immagine di riferimento non caricata.</translation>
    </message>
    <message>
      <source>Select New Reference Frame</source>
      <translation>Seleziona nuovo frame di riferimento</translation>
    </message>
    <message>
      <source>Unable to load preview.</source>
      <translation>Impossibile caricare anteprima.</translation>
    </message>
    <message>
      <source>Use This Reference Frame</source>
      <translation>Usa questo frame di riferimento</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
  </context>
  <context>
    <name>ReferenceOverlayDialog</name>
    <message>
      <source>Reference Frame: Stars Overlay</source>
      <translation>Frame di riferimento: Overlay stelle</translation>
    </message>
  </context>
  <context>
    <name>RemoveGreenDialog</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Neutral mode:</source>
      <translation>Modalità neutrale:</translation>
    </message>
    <message>
      <source>Preserve lightness</source>
      <translation>Preserva luminosità</translation>
    </message>
    <message>
      <source>Remove Green (SCNR)</source>
      <translation>Rimuovi verde (SCNR)</translation>
    </message>
    <message>
      <source>Select the amount to remove green noise:</source>
      <translation>Seleziona la quantità di rumore verde da rimuovere:</translation>
    </message>
  </context>
  <context>
    <name>SaveOptionsDialog</name>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Choose bit depth for export:</source>
      <translation>Scegli profondità bit per esportazione:</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Save Options</source>
      <translation>Opzioni salvataggio</translation>
    </message>
  </context>
  <context>
    <name>SelectiveColorCorrection</name>
    <message>
      <source>Complementary colors (CMY)</source>
      <translation>Colori complementari (CMY)</translation>
    </message>
    <message>
      <source>Luminance, Chroma/Saturation, Contrast</source>
      <translation>Luminanza, Croma/Saturazione, Contrasto</translation>
    </message>
    <message>
      <source>Mask</source>
      <translation>Maschera</translation>
    </message>
    <message>
      <source>RGB Colors</source>
      <translation>Colori RGB</translation>
    </message>
    <message>
      <source>Selective Color Correction</source>
      <translation>Correzione colore selettiva</translation>
    </message>
  </context>
  <context>
    <name>SettingsDialog</name>
    <message>
      <source>ASTAP executable:</source>
      <translation>Eseguibile ASTAP:</translation>
    </message>
    <message>
      <source>Astrometry.net API key:</source>
      <translation>Chiave API Astrometry.net:</translation>
    </message>
    <message>
      <source>Check Now…</source>
      <translation>Controlla ora…</translation>
    </message>
    <message>
      <source>Chinese</source>
      <translation>Cinese</translation>
    </message>
    <message>
      <source>Choose Background…</source>
      <translation>Scegli sfondo…</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Cancella</translation>
    </message>
    <message>
      <source>Compute autostretch on a 24-bit histogram (smoother gradients).</source>
      <translation>Calcola autostretch su istogramma 24-bit (gradienti più uniformi).</translation>
    </message>
    <message>
      <source>Cosmic Clarity folder:</source>
      <translation>Cartella Cosmic Clarity:</translation>
    </message>
    <message>
      <source>Customize…</source>
      <translation>Personalizza…</translation>
    </message>
    <message>
      <source>Edit custom colors and font</source>
      <translation>Modifica colori e font personalizzati</translation>
    </message>
    <message>
      <source>English</source>
      <translation>Inglese</translation>
    </message>
    <message>
      <source>French</source>
      <translation>Francese</translation>
    </message>
    <message>
      <source>German</source>
      <translation>Tedesco</translation>
    </message>
    <message>
      <source>GraXpert executable:</source>
      <translation>Eseguibile GraXpert:</translation>
    </message>
    <message>
      <source>High-quality autostretch (24-bit; better gradients)</source>
      <translation>Autostretch alta qualità (24-bit; gradienti migliori)</translation>
    </message>
    <message>
      <source>Italian</source>
      <translation>Italiano</translation>
    </message>
    <message>
      <source>Japanese</source>
      <translation>Giapponese</translation>
    </message>
    <message>
      <source>Language changed. Please manually restart the application to apply the new language.</source>
      <translation>Lingua modificata. Riavvia manualmente l'applicazione per applicare la nuova lingua.</translation>
    </message>
    <message>
      <source>Language:</source>
      <translation>Lingua:</translation>
    </message>
    <message>
      <source>Pick a PNG or JPG to use as the application background</source>
      <translation>Scegli un PNG o JPG da usare come sfondo applicazione</translation>
    </message>
    <message>
      <source>Portuguese</source>
      <translation>Portoghese</translation>
    </message>
    <message>
      <source>Remove custom background and restore default</source>
      <translation>Rimuovi sfondo personalizzato e ripristina predefinito</translation>
    </message>
    <message>
      <source>Restart required</source>
      <translation>Riavvio richiesto</translation>
    </message>
    <message>
      <source>Restore default updates URL</source>
      <translation>Ripristina URL aggiornamenti predefinito</translation>
    </message>
    <message>
      <source>Run an update check immediately</source>
      <translation>Esegui controllo aggiornamenti immediatamente</translation>
    </message>
    <message>
      <source>Save desktop shortcuts on exit</source>
      <translation>Salva scorciatoie desktop all'uscita</translation>
    </message>
    <message>
      <source>Spanish</source>
      <translation>Spagnolo</translation>
    </message>
    <message>
      <source>StarNet executable:</source>
      <translation>Eseguibile StarNet:</translation>
    </message>
    <message>
      <source>The application will now restart to apply the language change.</source>
      <translation>L'applicazione verrà riavviata per applicare il cambio di lingua.</translation>
    </message>
    <message>
      <source>Theme:</source>
      <translation>Tema:</translation>
    </message>
    <message>
      <source>(Not required) Additional Model Paths for Denoise and Satellites</source>
      <translation>(Non richiesto) Percorsi modelli aggiuntivi per Denoise e Satelliti</translation>
    </message>
    <message>
      <source>AHD (default)</source>
      <translation>AHD (predefinito)</translation>
    </message>
    <message>
      <source>About</source>
      <translation>Informazioni</translation>
    </message>
    <message>
      <source>Adobe DNG demosaic:</source>
      <translation>Demosaic Adobe DNG:</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Astrometry.net API key</source>
      <translation>Chiave API Astrometry.net</translation>
    </message>
    <message>
      <source>Astrometry.net Fallback:</source>
      <translation>Fallback Astrometry.net:</translation>
    </message>
    <message>
      <source>Auto</source>
      <translation>Auto</translation>
    </message>
    <message>
      <source>Auto (system)</source>
      <translation>Auto (sistema)</translation>
    </message>
    <message>
      <source>Auto-detect (use FITS header)</source>
      <translation>Rileva automaticamente (usa header FITS)</translation>
    </message>
    <message>
      <source>Auto-save</source>
      <translation>Auto-save</translation>
    </message>
    <message>
      <source>Best (bilinear, slower)</source>
      <translation>Best (bilinear, slower)</translation>
    </message>
    <message>
      <source>Browse...</source>
      <translation>Sfoglia...</translation>
    </message>
    <message>
      <source>Browse…</source>
      <translation>Sfoglia…</translation>
    </message>
    <message>
      <source>Bundle folder is stored under the SASP data folder</source>
      <translation>Bundle folder is stored under the SASP data folder</translation>
    </message>
    <message>
      <source>Bundles folder</source>
      <translation>Bundles folder</translation>
    </message>
    <message>
      <source>CPU</source>
      <translation>CPU</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Check this if your mono camera produces FITS that look like color mosaics</source>
      <translation>Check this if your mono camera produces FITS that look like color mosaics</translation>
    </message>
    <message>
      <source>Choose SASP Data Folder</source>
      <translation>Choose SASP Data Folder</translation>
    </message>
    <message>
      <source>Choose…</source>
      <translation>Choose…</translation>
    </message>
    <message>
      <source>Cosmic Clarity</source>
      <translation>Cosmic Clarity</translation>
    </message>
    <message>
      <source>Cosmic Clarity Denoise Path:</source>
      <translation>Cosmic Clarity Denoise Path:</translation>
    </message>
    <message>
      <source>Cosmic Clarity Executable Path (XL model included)</source>
      <translation>Cosmic Clarity Executable Path (XL model included)</translation>
    </message>
    <message>
      <source>Cosmic Clarity Path:</source>
      <translation>Cosmic Clarity Path:</translation>
    </message>
    <message>
      <source>Cosmic Clarity Satellite Path:</source>
      <translation>Cosmic Clarity Satellite Path:</translation>
    </message>
    <message>
      <source>Cosmic Clarity Settings</source>
      <translation>Cosmic Clarity Settings</translation>
    </message>
    <message>
      <source>Cosmic Clarity Stellar Path:</source>
      <translation>Cosmic Clarity Stellar Path:</translation>
    </message>
    <message>
      <source>DHT (high quality)</source>
      <translation>DHT (high quality)</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Scuro</translation>
    </message>
    <message>
      <source>Dark (default)</source>
      <translation>Dark (default)</translation>
    </message>
    <message>
      <source>Debayer Mono FITS</source>
      <translation>Debayer Mono FITS</translation>
    </message>
    <message>
      <source>Debayer Pattern</source>
      <translation>Debayer Pattern</translation>
    </message>
    <message>
      <source>Debayer mono files using FITS header BAYERPAT/COLORTYP</source>
      <translation>Debayer mono files using FITS header BAYERPAT/COLORTYP</translation>
    </message>
    <message>
      <source>Default Image Directory</source>
      <translation>Default Image Directory</translation>
    </message>
    <message>
      <source>Default: 128. Smaller tiles use less memory but may be slower.</source>
      <translation>Default: 128. Smaller tiles use less memory but may be slower.</translation>
    </message>
    <message>
      <source>Default: 2048. Smaller = less memory but slower preview renders.</source>
      <translation>Default: 2048. Smaller = less memory but slower preview renders.</translation>
    </message>
    <message>
      <source>Default: 2048. Smaller = less memory, slower.</source>
      <translation>Default: 2048. Smaller = less memory, slower.</translation>
    </message>
    <message>
      <source>Default: 256. Larger can be faster but uses more memory.</source>
      <translation>Default: 256. Larger can be faster but uses more memory.</translation>
    </message>
    <message>
      <source>Default: 3. Number of images to keep in memory.</source>
      <translation>Default: 3. Number of images to keep in memory.</translation>
    </message>
    <message>
      <source>Default: 4 (or half your CPU cores).</source>
      <translation>Default: 4 (or half your CPU cores).</translation>
    </message>
    <message>
      <source>Default: 4. Too many workers can exceed GPU memory.</source>
      <translation>Default: 4. Too many workers can exceed GPU memory.</translation>
    </message>
    <message>
      <source>Default: Half your CPU cores (min 2).</source>
      <translation>Default: Half your CPU cores (min 2).</translation>
    </message>
    <message>
      <source>Denoise Model Downloaded</source>
      <translation>Denoise Model Downloaded</translation>
    </message>
    <message>
      <source>Display</source>
      <translation>Display</translation>
    </message>
    <message>
      <source>Display-Stretch: Soft/Hard Profile</source>
      <translation>Display-Stretch: Soft/Hard Profile</translation>
    </message>
    <message>
      <source>Download Denoise Model</source>
      <translation>Download Denoise Model</translation>
    </message>
    <message>
      <source>Download Error</source>
      <translation>Download Error</translation>
    </message>
    <message>
      <source>Download Satellite Model</source>
      <translation>Download Satellite Model</translation>
    </message>
    <message>
      <source>Downloading Denoise Model…</source>
      <translation>Downloading Denoise Model…</translation>
    </message>
    <message>
      <source>Downloading Satellite Model…</source>
      <translation>Downloading Satellite Model…</translation>
    </message>
    <message>
      <source>Draft</source>
      <translation>Draft</translation>
    </message>
    <message>
      <source>Enable GPU</source>
      <translation>Abilita GPU</translation>
    </message>
    <message>
      <source>Enable auto-save</source>
      <translation>Enable auto-save</translation>
    </message>
    <message>
      <source>Failed to download model:
{0}</source>
      <translation>Failed to download model:
{0}</translation>
    </message>
    <message>
      <source>Fast (nearest, pixelated)</source>
      <translation>Fast (nearest, pixelated)</translation>
    </message>
    <message>
      <source>Files</source>
      <translation>Files</translation>
    </message>
    <message>
      <source>GPU Acceleration</source>
      <translation>Accelerazione GPU</translation>
    </message>
    <message>
      <source>GPU Device</source>
      <translation>GPU Device</translation>
    </message>
    <message>
      <source>General</source>
      <translation>Generale</translation>
    </message>
    <message>
      <source>GraXpert</source>
      <translation>GraXpert</translation>
    </message>
    <message>
      <source>GraXpert Executable Path</source>
      <translation>GraXpert Executable Path</translation>
    </message>
    <message>
      <source>GraXpert Path:</source>
      <translation>GraXpert Path:</translation>
    </message>
    <message>
      <source>GraXpert Settings</source>
      <translation>GraXpert Settings</translation>
    </message>
    <message>
      <source>Grid Overlay</source>
      <translation>Grid Overlay</translation>
    </message>
    <message>
      <source>Grid line color:</source>
      <translation>Grid line color:</translation>
    </message>
    <message>
      <source>Hard</source>
      <translation>Hard</translation>
    </message>
    <message>
      <source>High</source>
      <translation>Alto</translation>
    </message>
    <message>
      <source>Image Quality</source>
      <translation>Image Quality</translation>
    </message>
    <message>
      <source>Image Viewer</source>
      <translation>Image Viewer</translation>
    </message>
    <message>
      <source>Image cache size (slots):</source>
      <translation>Image cache size (slots):</translation>
    </message>
    <message>
      <source>Inference Device:</source>
      <translation>Inference Device:</translation>
    </message>
    <message>
      <source>Interface</source>
      <translation>Interfaccia</translation>
    </message>
    <message>
      <source>Interval (minutes)</source>
      <translation>Interval (minutes)</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>Lingua</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Chiaro</translation>
    </message>
    <message>
      <source>Local Astrometry.net (solve-field):</source>
      <translation>Local Astrometry.net (solve-field):</translation>
    </message>
    <message>
      <source>MB</source>
      <translation>MB</translation>
    </message>
    <message>
      <source>MF Deconvolution Tile size (px):</source>
      <translation>MF Deconvolution Tile size (px):</translation>
    </message>
    <message>
      <source>MF Parallel workers:</source>
      <translation>MF Parallel workers:</translation>
    </message>
    <message>
      <source>Maximum steps</source>
      <translation>Maximum steps</translation>
    </message>
    <message>
      <source>Memory Limit</source>
      <translation>Memory Limit</translation>
    </message>
    <message>
      <source>Memory settings</source>
      <translation>Memory settings</translation>
    </message>
    <message>
      <source>Multi-Frame Deconvolution</source>
      <translation>Multi-Frame Deconvolution</translation>
    </message>
    <message>
      <source>None (skip fallback)</source>
      <translation>None (skip fallback)</translation>
    </message>
    <message>
      <source>Normal</source>
      <translation>Normal</translation>
    </message>
    <message>
      <source>Note: Some settings require restarting SASpro to take effect.</source>
      <translation>Note: Some settings require restarting SASpro to take effect.</translation>
    </message>
    <message>
      <source>Number of parallel image workers:</source>
      <translation>Number of parallel image workers:</translation>
    </message>
    <message>
      <source>Number of parallel stacking workers:</source>
      <translation>Number of parallel stacking workers:</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>PPG (fast)</source>
      <translation>PPG (fast)</translation>
    </message>
    <message>
      <source>Performance</source>
      <translation>Prestazioni</translation>
    </message>
    <message>
      <source>Plate Solving</source>
      <translation>Plate Solving</translation>
    </message>
    <message>
      <source>Plate-Solve Engine</source>
      <translation>Plate-Solve Engine</translation>
    </message>
    <message>
      <source>Preferences</source>
      <translation>Preferenze</translation>
    </message>
    <message>
      <source>Preview Quality</source>
      <translation>Preview Quality</translation>
    </message>
    <message>
      <source>Preview Tile size (px):</source>
      <translation>Preview Tile size (px):</translation>
    </message>
    <message>
      <source>Processing</source>
      <translation>Elaborazione</translation>
    </message>
    <message>
      <source>RAW Handling</source>
      <translation>RAW Handling</translation>
    </message>
    <message>
      <source>Rendering Quality:</source>
      <translation>Rendering Quality:</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Restore Defaults</translation>
    </message>
    <message>
      <source>SASP Data Folder:</source>
      <translation>SASP Data Folder:</translation>
    </message>
    <message>
      <source>Satellite Model Downloaded</source>
      <translation>Satellite Model Downloaded</translation>
    </message>
    <message>
      <source>Seti Astro Suite Pro</source>
      <translation>Seti Astro Suite Pro</translation>
    </message>
    <message>
      <source>Seti Astro User ID</source>
      <translation>Seti Astro User ID</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Impostazioni</translation>
    </message>
    <message>
      <source>Show grid overlay in image views</source>
      <translation>Show grid overlay in image views</translation>
    </message>
    <message>
      <source>Soft (default)</source>
      <translation>Soft (default)</translation>
    </message>
    <message>
      <source>Some changes require a restart to take effect.</source>
      <translation>Some changes require a restart to take effect.</translation>
    </message>
    <message>
      <source>Stacking Suite</source>
      <translation>Stacking Suite</translation>
    </message>
    <message>
      <source>Stacking Suite Tile size (px):</source>
      <translation>Stacking Suite Tile size (px):</translation>
    </message>
    <message>
      <source>System</source>
      <translation>System</translation>
    </message>
    <message>
      <source>The Denoise model has been downloaded to:
{0}</source>
      <translation>The Denoise model has been downloaded to:
{0}</translation>
    </message>
    <message>
      <source>The Satellite model has been downloaded to:
{0}</source>
      <translation>The Satellite model has been downloaded to:
{0}</translation>
    </message>
    <message>
      <source>Theme</source>
      <translation>Tema</translation>
    </message>
    <message>
      <source>Threads</source>
      <translation>Threads</translation>
    </message>
    <message>
      <source>Tile size (px):</source>
      <translation>Tile size (px):</translation>
    </message>
    <message>
      <source>Undo History</source>
      <translation>Undo History</translation>
    </message>
    <message>
      <source>Use Astrometry.net (web) as fallback</source>
      <translation>Use Astrometry.net (web) as fallback</translation>
    </message>
    <message>
      <source>Web fallback (free quota)</source>
      <translation>Web fallback (free quota)</translation>
    </message>
    <message>
      <source>Your numeric user ID from setiastrophotography.com:</source>
      <translation>Your numeric user ID from setiastrophotography.com:</translation>
    </message>
    <message>
      <source>rawpy extra args (advanced, JSON list):</source>
      <translation>rawpy extra args (advanced, JSON list):</translation>
    </message>
  </context>
  <context>
    <name>ShortcutButton</name>
    <message>
      <source>Clear Preset</source>
      <translation>Cancella Preset</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Elimina</translation>
    </message>
    <message>
      <source>Edit Preset (JSON)</source>
      <translation>Modifica Preset (JSON)</translation>
    </message>
    <message>
      <source>Edit Preset…</source>
      <translation>Modifica Preset…</translation>
    </message>
    <message>
      <source>Invalid JSON</source>
      <translation>JSON non valido</translation>
    </message>
    <message>
      <source>Name:</source>
      <translation>Nome:</translation>
    </message>
    <message>
      <source>Preset must be a JSON object</source>
      <translation>Il preset deve essere un oggetto JSON</translation>
    </message>
    <message>
      <source>Preset saved</source>
      <translation>Preset salvato</translation>
    </message>
    <message>
      <source>Preset stored on shortcut.</source>
      <translation>Preset memorizzato nel collegamento.</translation>
    </message>
    <message>
      <source>Preset:</source>
      <translation>Preset:</translation>
    </message>
    <message>
      <source>Rename Shortcut</source>
      <translation>Rinomina Collegamento</translation>
    </message>
    <message>
      <source>Rename…</source>
      <translation>Rinomina…</translation>
    </message>
    <message>
      <source>Run</source>
      <translation>Esegui</translation>
    </message>
  </context>
  <context>
    <name>SignatureInsertDialogPro</name>
    <message>
      <source>Signature / Insert</source>
      <translation>Firma / Inserisci</translation>
    </message>
    <message>
      <source>Add Image</source>
      <translation>Aggiungi immagine</translation>
    </message>
    <message>
      <source>Add Shape</source>
      <translation>Aggiungi forma</translation>
    </message>
    <message>
      <source>Add Text</source>
      <translation>Aggiungi testo</translation>
    </message>
    <message>
      <source>Apply to Active Document</source>
      <translation>Applica a documento attivo</translation>
    </message>
    <message>
      <source>Arrow (down)</source>
      <translation>Freccia (giù)</translation>
    </message>
    <message>
      <source>Arrow (left)</source>
      <translation>Freccia (sinistra)</translation>
    </message>
    <message>
      <source>Arrow (poly)</source>
      <translation>Freccia (poli)</translation>
    </message>
    <message>
      <source>Arrow (right)</source>
      <translation>Freccia (destra)</translation>
    </message>
    <message>
      <source>Arrow (up)</source>
      <translation>Freccia (su)</translation>
    </message>
    <message>
      <source>Bold</source>
      <translation>Grassetto</translation>
    </message>
    <message>
      <source>Border:</source>
      <translation>Border:</translation>
    </message>
    <message>
      <source>Choose Image</source>
      <translation>Choose Image</translation>
    </message>
    <message>
      <source>Choose…</source>
      <translation>Choose…</translation>
    </message>
    <message>
      <source>Color:</source>
      <translation>Color:</translation>
    </message>
    <message>
      <source>Delete Overlay</source>
      <translation>Delete Overlay</translation>
    </message>
    <message>
      <source>Ellipse</source>
      <translation>Ellisse</translation>
    </message>
    <message>
      <source>Enter text:</source>
      <translation>Enter text:</translation>
    </message>
    <message>
      <source>Failed to read the active view; cannot apply overlays.</source>
      <translation>Failed to read the active view; cannot apply overlays.</translation>
    </message>
    <message>
      <source>Fill:</source>
      <translation>Fill:</translation>
    </message>
    <message>
      <source>Fit to Preview</source>
      <translation>Fit to Preview</translation>
    </message>
    <message>
      <source>Font size:</source>
      <translation>Font size:</translation>
    </message>
    <message>
      <source>Font:</source>
      <translation>Font:</translation>
    </message>
    <message>
      <source>Height:</source>
      <translation>Height:</translation>
    </message>
    <message>
      <source>Image</source>
      <translation>Immagine</translation>
    </message>
    <message>
      <source>Image Files (*.png *.jpg *.jpeg *.bmp *.gif *.tif *.tiff);;All Files (*)</source>
      <translation>Image Files (*.png *.jpg *.jpeg *.bmp *.gif *.tif *.tiff);;All Files (*)</translation>
    </message>
    <message>
      <source>Italic</source>
      <translation>Corsivo</translation>
    </message>
    <message>
      <source>Line</source>
      <translation>Linea</translation>
    </message>
    <message>
      <source>Move Down</source>
      <translation>Sposta giù</translation>
    </message>
    <message>
      <source>Move Up</source>
      <translation>Sposta su</translation>
    </message>
    <message>
      <source>No active document to apply overlays.</source>
      <translation>No active document to apply overlays.</translation>
    </message>
    <message>
      <source>None</source>
      <translation>None</translation>
    </message>
    <message>
      <source>Outline:</source>
      <translation>Outline:</translation>
    </message>
    <message>
      <source>Overlays (text, images, shapes)</source>
      <translation>Overlays (text, images, shapes)</translation>
    </message>
    <message>
      <source>Overlays applied to active document.</source>
      <translation>Overlays applied to active document.</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Ready</source>
      <translation>Pronto</translation>
    </message>
    <message>
      <source>Rectangle</source>
      <translation>Rettangolo</translation>
    </message>
    <message>
      <source>Render at full resolution</source>
      <translation>Render at full resolution</translation>
    </message>
    <message>
      <source>Selected overlay</source>
      <translation>Selected overlay</translation>
    </message>
    <message>
      <source>Select…</source>
      <translation>Select…</translation>
    </message>
    <message>
      <source>Shape</source>
      <translation>Forma</translation>
    </message>
    <message>
      <source>Signature Insert</source>
      <translation>Inserisci firma</translation>
    </message>
    <message>
      <source>Size:</source>
      <translation>Size:</translation>
    </message>
    <message>
      <source>Text</source>
      <translation>Testo</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Triangle</translation>
    </message>
    <message>
      <source>Type:</source>
      <translation>Type:</translation>
    </message>
    <message>
      <source>Width:</source>
      <translation>Width:</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
    <message>
      <source>px</source>
      <translation>px</translation>
    </message>
  </context>
  <context>
    <name>Splash</name>
    <message>
      <source>  •  Build {0}</source>
      <translation>  •  Build {0}</translation>
    </message>
    <message>
      <source>  •  Running locally from source code</source>
      <translation>  •  Esecuzione locale da codice sorgente</translation>
    </message>
    <message>
      <source>Building main window...</source>
      <translation>Costruzione finestra principale...</translation>
    </message>
    <message>
      <source>Configuring Qt message handler...</source>
      <translation>Configurazione gestore messaggi Qt...</translation>
    </message>
    <message>
      <source>Configuring matplotlib...</source>
      <translation>Configurazione matplotlib...</translation>
    </message>
    <message>
      <source>Configuring multiprocessing...</source>
      <translation>Configurazione multiprocessing...</translation>
    </message>
    <message>
      <source>Creating image manager...</source>
      <translation>Creazione gestore immagini...</translation>
    </message>
    <message>
      <source>Initializing Python runtime...</source>
      <translation>Inizializzazione runtime Python...</translation>
    </message>
    <message>
      <source>Installing crash handlers...</source>
      <translation>Installazione gestori crash...</translation>
    </message>
    <message>
      <source>Loading MDI widgets...</source>
      <translation>Caricamento widget MDI...</translation>
    </message>
    <message>
      <source>Loading NumPy...</source>
      <translation>Caricamento NumPy...</translation>
    </message>
    <message>
      <source>Loading OpenCV...</source>
      <translation>Caricamento OpenCV...</translation>
    </message>
    <message>
      <source>Loading PyQt6 components...</source>
      <translation>Caricamento componenti PyQt6...</translation>
    </message>
    <message>
      <source>Loading PyTorch runtime...</source>
      <translation>Caricamento runtime PyTorch...</translation>
    </message>
    <message>
      <source>Loading UI utilities...</source>
      <translation>Caricamento utilità UI...</translation>
    </message>
    <message>
      <source>Loading image libraries...</source>
      <translation>Caricamento librerie immagini...</translation>
    </message>
    <message>
      <source>Loading image manager...</source>
      <translation>Caricamento gestore immagini...</translation>
    </message>
    <message>
      <source>Loading main window module...</source>
      <translation>Caricamento modulo finestra principale...</translation>
    </message>
    <message>
      <source>Loading reproject library...</source>
      <translation>Caricamento libreria reproject...</translation>
    </message>
    <message>
      <source>Loading resources...</source>
      <translation>Caricamento risorse...</translation>
    </message>
    <message>
      <source>Loading standard libraries...</source>
      <translation>Caricamento librerie standard...</translation>
    </message>
    <message>
      <source>Modules loaded, finalizing...</source>
      <translation>Moduli caricati, finalizzazione...</translation>
    </message>
    <message>
      <source>Ready!</source>
      <translation>Pronto!</translation>
    </message>
    <message>
      <source>Setting up logging...</source>
      <translation>Configurazione logging...</translation>
    </message>
    <message>
      <source>Showing main window...</source>
      <translation>Visualizzazione finestra principale...</translation>
    </message>
    <message>
      <source>Starting...</source>
      <translation>Avvio...</translation>
    </message>
    <message>
      <source>Suppressing warnings...</source>
      <translation>Soppressione avvisi...</translation>
    </message>
    <message>
      <source>Version {0}</source>
      <translation>Versione {0}</translation>
    </message>
    <message>
      <source>Initializing GPU…</source>
      <translation>Inizializzazione GPU…</translation>
    </message>
    <message>
      <source>Splash</source>
      <translation>Splash</translation>
    </message>
  </context>
  <context>
    <name>StackingSuiteDialog</name>
    <message>
      <source>

(Comet Star Removal is currently OFF in Settings.)</source>
      <translation>

(La Rimozione Stelle Cometa è attualmente DISATTIVATA nelle Impostazioni.)</translation>
    </message>
    <message>
      <source>

Linux tip:
 • Install python3.12 or 3.11 via your package manager
 • Then relaunch the app.</source>
      <translation>

Suggerimento Linux:
 • Installa python3.12 o 3.11 via il tuo package manager
 • Poi rilancia l'app.</translation>
    </message>
    <message>
      <source>

Windows tip:
 • Install Python 3.12/3.11/3.10 (x64) from python.org
 • Then relaunch the app.</source>
      <translation>

Suggerimento Windows:
 • Installa Python 3.12/3.11/3.10 (x64) da python.org
 • Poi rilancia l'app.</translation>
    </message>
    <message>
      <source>

macOS tip (Apple Silicon):
 • Install Python 3.12:  brew install python@3.12
 • Then relaunch the app so it can create its runtime with 3.12.</source>
      <translation>

Suggerimento macOS (Apple Silicon):
 • Installa Python 3.12:  brew install python@3.12
 • Poi rilancia l'app così può creare il suo runtime con 3.12.</translation>
    </message>
    <message>
      <source>    ✓ [{0}/{1}] starless saved</source>
      <translation>    ✓ [{0}/{1}] starless salvato</translation>
    </message>
    <message>
      <source>   With &lt;~40–55% fill, expect visible patching even with many frames)</source>
      <translation>   Con &lt;~40–55% riempimento, aspettati patch visibili anche con molti frame)</translation>
    </message>
    <message>
      <source>   With &lt;~40–55% fill, expect visible patching even with many frames.</source>
      <translation>   Con &lt;~40–55% riempimento, aspettati patch visibili anche con molti frame.</translation>
    </message>
    <message>
      <source>   bbox(ref)→reg: ({0:.1f},{1:.1f}) to ({2:.1f},{3:.1f}); canvas {4}×{5} @ {6}×</source>
      <translation>   bbox(ref)→reg: ({0:.1f},{1:.1f}) a ({2:.1f},{3:.1f}); canvas {4}×{5} @ {6}×</translation>
    </message>
    <message>
      <source>   originals needed (sample): {0}</source>
      <translation>   originali necessari (campione): {0}</translation>
    </message>
    <message>
      <source>   sasd FILEs (sample):       {0}</source>
      <translation>   FILE sasd (campione):       {0}</translation>
    </message>
    <message>
      <source>   • Tile source: STARLESS (pre-aligned)</source>
      <translation>   • Sorgente tile: STARLESS (pre-allineato)</translation>
    </message>
    <message>
      <source>   ↳ Integration done in {0:.1f}s.</source>
      <translation>   ↳ Integrazione completata in {0:.1f}s.</translation>
    </message>
    <message>
      <source>   ⚠️ Starless reader path mismatch at i={0}; got {1}, expected {2}. Using index order.</source>
      <translation>   ⚠️ Mismatch percorso reader starless a i={0}; ottenuto {1}, previsto {2}. Uso ordine indice.</translation>
    </message>
    <message>
      <source>  • {0} → {1}</source>
      <translation>  • {0} → {1}</translation>
    </message>
    <message>
      <source>  ↳ tile {0} done in {1:.3f}s  (~{2:.1f} MPx/s)</source>
      <translation>  ↳ tile {0} completata in {1:.3f}s  (~{2:.1f} MPx/s)</translation>
    </message>
    <message>
      <source>  ◦ DarkStar comet star removal…</source>
      <translation>  ◦ Rimozione stelle cometa DarkStar…</translation>
    </message>
    <message>
      <source>  ◦ StarNet comet star removal…</source>
      <translation>  ◦ Rimozione stelle cometa StarNet…</translation>
    </message>
    <message>
      <source>  ◦ applying rejection algorithm: {0}</source>
      <translation>  ◦ applicazione algoritmo rifiuto: {0}</translation>
    </message>
    <message>
      <source>  ◦ seed xy={0:.1f},{1:.1f} within {2}×{3}? {4}</source>
      <translation>  ◦ seed xy={0:.1f},{1:.1f} dentro {2}×{3}? {4}</translation>
    </message>
    <message>
      <source>  ◦ seeding first registered frame with _comet_ref_xy</source>
      <translation>  ◦ seeding primo frame registrato con _comet_ref_xy</translation>
    </message>
    <message>
      <source>  ◦ user cancelled or no edits — using auto centroids</source>
      <translation>  ◦ utente annullato o nessuna modifica — uso centroidi auto</translation>
    </message>
    <message>
      <source>  ◦ user confirmed/edited {0} centroids</source>
      <translation>  ◦ utente confermato/modificato {0} centroidi</translation>
    </message>
    <message>
      <source>  ◦ using user seed on {0}</source>
      <translation>  ◦ uso seed utente su {0}</translation>
    </message>
    <message>
      <source>  ⚠️ comet preview skipped: no worker emitter present</source>
      <translation>  ⚠️ anteprima cometa saltata: nessun emitter worker presente</translation>
    </message>
    <message>
      <source>  ⚠️ comet preview skipped: {0!r}</source>
      <translation>  ⚠️ anteprima cometa saltata: {0!r}</translation>
    </message>
    <message>
      <source>  ⚠️ comet preview unavailable (no UI target)</source>
      <translation>  ⚠️ anteprima cometa non disponibile (nessun target UI)</translation>
    </message>
    <message>
      <source>  ⚠️ star removal failed on {0}: {1}</source>
      <translation>  ⚠️ rimozione stelle fallita su {0}: {1}</translation>
    </message>
    <message>
      <source>  ⚠️ user seed: no affine for that registered file</source>
      <translation>  ⚠️ seed utente: nessun affine per quel file registrato</translation>
    </message>
    <message>
      <source>  ❌ {0}</source>
      <translation>  ❌ {0}</translation>
    </message>
    <message>
      <source> (repaired {0})</source>
      <translation> (riparato {0})</translation>
    </message>
    <message>
      <source> + CFA</source>
      <translation> + CFA</translation>
    </message>
    <message>
      <source> + drizzle</source>
      <translation> + drizzle</translation>
    </message>
    <message>
      <source> [GPU]</source>
      <translation> [GPU]</translation>
    </message>
    <message>
      <source>'Luma' deconvolves luminance only; 'PerChannel' runs on RGB independently.</source>
      <translation>'Luma' deconvolve solo luminanza; 'PerChannel' lavora su RGB indipendentemente.</translation>
    </message>
    <message>
      <source>(&lt;0 = scale×RMS, &gt;0 = absolute Δ)</source>
      <translation>(&lt;0 = scala×RMS, &gt;0 = Δ assoluto)</translation>
    </message>
    <message>
      <source>(fallback)</source>
      <translation>(fallback)</translation>
    </message>
    <message>
      <source>(score={0:.4f})</source>
      <translation>(punteggio={0:.4f})</translation>
    </message>
    <message>
      <source>**Frame Weights Debug Log:**</source>
      <translation>**Log Debug Pesi Frame:**</translation>
    </message>
    <message>
      <source>1 file · {0}</source>
      <translation>1 file · {0}</translation>
    </message>
    <message>
      <source>16-bit unsigned</source>
      <translation>16-bit senza segno</translation>
    </message>
    <message>
      <source>1× (native)</source>
      <translation>1× (nativo)</translation>
    </message>
    <message>
      <source>2× (super-resolution)</source>
      <translation>2× (super-risoluzione)</translation>
    </message>
    <message>
      <source>32-bit float</source>
      <translation>32-bit float</translation>
    </message>
    <message>
      <source>3× (extreme)</source>
      <translation>3× (estremo)</translation>
    </message>
    <message>
      <source>64-bit float</source>
      <translation>64-bit float</translation>
    </message>
    <message>
      <source>64-bit uses ~2× RAM; 32-bit is faster/lighter.</source>
      <translation>64-bit usa ~2× RAM; 32-bit è più veloce/leggero.</translation>
    </message>
    <message>
      <source>ABE Mode:</source>
      <translation>Modalità ABE:</translation>
    </message>
    <message>
      <source>AHD</source>
      <translation>AHD</translation>
    </message>
    <message>
      <source>AIRMASS</source>
      <translation>Massa d'aria</translation>
    </message>
    <message>
      <source>APTDIA</source>
      <translation>Diametro apertura</translation>
    </message>
    <message>
      <source>About CUDA</source>
      <translation>Info CUDA</translation>
    </message>
    <message>
      <source>Acceleration</source>
      <translation>Accelerazione</translation>
    </message>
    <message>
      <source>Accept max shift (px):</source>
      <translation>Spostamento max accettato (px):</translation>
    </message>
    <message>
      <source>Accept tolerance (px):</source>
      <translation>Tolleranza accettazione (px):</translation>
    </message>
    <message>
      <source>Accurate (3 passes)</source>
      <translation>Accurato (3 passate)</translation>
    </message>
    <message>
      <source>Accurate (Star Matching)</source>
      <translation>Accurato (Star Matching)</translation>
    </message>
    <message>
      <source>Add Bias Frames</source>
      <translation>Aggiungi Frame Bias</translation>
    </message>
    <message>
      <source>Add Conversion Directory</source>
      <translation>Aggiungi Cartella Conversione</translation>
    </message>
    <message>
      <source>Add Conversion Files</source>
      <translation>Aggiungi File Conversione</translation>
    </message>
    <message>
      <source>Add Dark Directory</source>
      <translation>Aggiungi Cartella Dark</translation>
    </message>
    <message>
      <source>Add Dark Files</source>
      <translation>Aggiungi File Dark</translation>
    </message>
    <message>
      <source>Add Dark Frames</source>
      <translation>Aggiungi Frame Dark</translation>
    </message>
    <message>
      <source>Add Files...</source>
      <translation>Aggiungi file...</translation>
    </message>
    <message>
      <source>Add Flat Directory</source>
      <translation>Aggiungi Cartella Flat</translation>
    </message>
    <message>
      <source>Add Flat Files</source>
      <translation>Aggiungi File Flat</translation>
    </message>
    <message>
      <source>Add Flat Frames</source>
      <translation>Aggiungi Frame Flat</translation>
    </message>
    <message>
      <source>Add Folder...</source>
      <translation>Aggiungi cartella...</translation>
    </message>
    <message>
      <source>Add Light Directory</source>
      <translation>Aggiungi Cartella Luce</translation>
    </message>
    <message>
      <source>Add Light Files</source>
      <translation>Aggiungi File Light</translation>
    </message>
    <message>
      <source>Add Light Frames</source>
      <translation>Aggiungi Frame Luce</translation>
    </message>
    <message>
      <source>Add files to the stacking queue</source>
      <translation>Aggiungi file alla coda stacking</translation>
    </message>
    <message>
      <source>Add to {0} tab</source>
      <translation>Aggiungi alla scheda {0}</translation>
    </message>
    <message>
      <source>Added {0}/{1} Light frames</source>
      <translation>Aggiunti {0}/{1} frame Light</translation>
    </message>
    <message>
      <source>Adding Blink files to Image Integration…</source>
      <translation>Aggiunta file Blink a Integrazione Immagine…</translation>
    </message>
    <message>
      <source>Adding Blink files to Light tab…</source>
      <translation>Aggiunta file Blink alla scheda Light…</translation>
    </message>
    <message>
      <source>Adding {0} Files…</source>
      <translation>Aggiunta {0} File…</translation>
    </message>
    <message>
      <source>Adding {0} from Directory…</source>
      <translation>Aggiunta {0} da Cartella…</translation>
    </message>
    <message>
      <source>Additive</source>
      <translation>Additiva</translation>
    </message>
    <message>
      <source>Additive with Scaling</source>
      <translation>Additiva con scala</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Avanzate</translation>
    </message>
    <message>
      <source>Advanced Options</source>
      <translation>Opzioni Avanzate</translation>
    </message>
    <message>
      <source>Advanced Settings</source>
      <translation>Impostazioni Avanzate</translation>
    </message>
    <message>
      <source>Affine (fast)</source>
      <translation>Affine (veloce)</translation>
    </message>
    <message>
      <source>After installation, restart the app for changes to take effect.</source>
      <translation>Dopo l'installazione, riavvia l'app perché le modifiche abbiano effetto.</translation>
    </message>
    <message>
      <source>After installing CUDA, restart the app.</source>
      <translation>Dopo aver installato CUDA, riavvia l'app.</translation>
    </message>
    <message>
      <source>Algorithm:</source>
      <translation>Algoritmo:</translation>
    </message>
    <message>
      <source>Aligning stars…</source>
      <translation>Allineamento stelle…</translation>
    </message>
    <message>
      <source>Aligning stars… ({0}/{1})</source>
      <translation>Allineamento stelle… ({0}/{1})</translation>
    </message>
    <message>
      <source>Alignment</source>
      <translation>Allineamento</translation>
    </message>
    <message>
      <source>Alignment Mode:</source>
      <translation>Modalità Allineamento:</translation>
    </message>
    <message>
      <source>Alignment Settings</source>
      <translation>Impostazioni Allineamento</translation>
    </message>
    <message>
      <source>All Supported Files</source>
      <translation>Tutti i file supportati</translation>
    </message>
    <message>
      <source>All stacking finished successfully.
</source>
      <translation>Tutto lo stacking completato con successo.
</translation>
    </message>
    <message>
      <source>Also output Stars+Comet blend</source>
      <translation>Output anche blend Stelle+Cometa</translation>
    </message>
    <message>
      <source>Analyze</source>
      <translation>Analizza</translation>
    </message>
    <message>
      <source>Analyzing frames...</source>
      <translation>Analisi frame...</translation>
    </message>
    <message>
      <source>Apply Bias Subtraction (For CCD Users)</source>
      <translation>Applica Sottrazione Bias (Per Utenti CCD)</translation>
    </message>
    <message>
      <source>Apply Pedestal</source>
      <translation>Applica Piedistallo</translation>
    </message>
    <message>
      <source>Apply Settings</source>
      <translation>Applica Impostazioni</translation>
    </message>
    <message>
      <source>Apply color matrix</source>
      <translation>Applica matrice colore</translation>
    </message>
    <message>
      <source>Apply cosmetic correction</source>
      <translation>Applica correzione cosmetica</translation>
    </message>
    <message>
      <source>Apply debayer</source>
      <translation>Applica debayer</translation>
    </message>
    <message>
      <source>Apply distortion model</source>
      <translation>Applica modello distorsione</translation>
    </message>
    <message>
      <source>Apply filter</source>
      <translation>Applica filtro</translation>
    </message>
    <message>
      <source>Apply hot pixel removal</source>
      <translation>Applica rimozione hot pixel</translation>
    </message>
    <message>
      <source>Apply this choice to all remaining mismatches of this kind</source>
      <translation>Applica questa scelta a tutte le discrepanze rimanenti di questo tipo</translation>
    </message>
    <message>
      <source>Apply to Group</source>
      <translation>Applica al Gruppo</translation>
    </message>
    <message>
      <source>Apply to all frames</source>
      <translation>Applica a tutti i frame</translation>
    </message>
    <message>
      <source>Applying calibration...</source>
      <translation>Applicazione calibrazione...</translation>
    </message>
    <message>
      <source>Applying rejection...</source>
      <translation>Applicazione reiezione...</translation>
    </message>
    <message>
      <source>Are you sure you want to cancel stacking?</source>
      <translation>Sei sicuro di voler annullare lo stacking?</translation>
    </message>
    <message>
      <source>Are you sure you want to remove all frames?</source>
      <translation>Sei sicuro di voler rimuovere tutti i frame?</translation>
    </message>
    <message>
      <source>Assigning best Master Dark/Flat…</source>
      <translation>Assegnazione miglior Master Dark/Flat…</translation>
    </message>
    <message>
      <source>Auto</source>
      <translation>Auto</translation>
    </message>
    <message>
      <source>Auto (from stars)</source>
      <translation>Auto (dalle stelle)</translation>
    </message>
    <message>
      <source>Auto (not set)</source>
      <translation>Auto (non impostato)</translation>
    </message>
    <message>
      <source>Auto (use all cores)</source>
      <translation>Auto (usa tutti i core)</translation>
    </message>
    <message>
      <source>Auto Crop</source>
      <translation>Ritaglio Automatico</translation>
    </message>
    <message>
      <source>Auto Noise Map</source>
      <translation>Mappa Rumore Auto</translation>
    </message>
    <message>
      <source>Auto Star Mask</source>
      <translation>Maschera Stelle Auto</translation>
    </message>
    <message>
      <source>Auto Weight</source>
      <translation>Peso Automatico</translation>
    </message>
    <message>
      <source>Auto crop</source>
      <translation>Ritaglia automaticamente</translation>
    </message>
    <message>
      <source>Auto-Accept Best Reference</source>
      <translation>Auto-Accetta Miglior Riferimento</translation>
    </message>
    <message>
      <source>Auto-Select Best Reference</source>
      <translation>Auto-Seleziona Miglior Riferimento</translation>
    </message>
    <message>
      <source>Auto-Select Closest Master Dark</source>
      <translation>Auto-Seleziona Master Dark più Vicino</translation>
    </message>
    <message>
      <source>Auto-Select by Metadata</source>
      <translation>Auto-Seleziona per Metadati</translation>
    </message>
    <message>
      <source>Auto-accept measured reference</source>
      <translation>Auto-accetta riferimento misurato</translation>
    </message>
    <message>
      <source>Auto-crop output</source>
      <translation>Output auto-ritaglio</translation>
    </message>
    <message>
      <source>Auto-cropped files saved:</source>
      <translation>File auto-ritagliati salvati:</translation>
    </message>
    <message>
      <source>Auto-detect</source>
      <translation>Rilevamento automatico</translation>
    </message>
    <message>
      <source>Auto-detect panels</source>
      <translation>Rileva pannelli automaticamente</translation>
    </message>
    <message>
      <source>Auto-detect session</source>
      <translation>Auto-rileva sessione</translation>
    </message>
    <message>
      <source>Auto-match calibration frames</source>
      <translation>Abbina automaticamente frame calibrazione</translation>
    </message>
    <message>
      <source>Auto-name</source>
      <translation>Nome automatico</translation>
    </message>
    <message>
      <source>Auto-register &amp; integrate after calibration</source>
      <translation>Auto-registra &amp; integra dopo calibrazione</translation>
    </message>
    <message>
      <source>Average</source>
      <translation>Media</translation>
    </message>
    <message>
      <source>BAYERPAT</source>
      <translation>Pattern Bayer</translation>
    </message>
    <message>
      <source>BGGR</source>
      <translation>BGGR</translation>
    </message>
    <message>
      <source>Backend: CPU (Python version not supported for GPU install)</source>
      <translation>Backend: CPU (Versione Python non supportata per installazione GPU)</translation>
    </message>
    <message>
      <source>Backend: installing…</source>
      <translation>Backend: installazione…</translation>
    </message>
    <message>
      <source>Backend: {0}</source>
      <translation>Backend: {0}</translation>
    </message>
    <message>
      <source>Background</source>
      <translation>Sfondo</translation>
    </message>
    <message>
      <source>Background Normalization</source>
      <translation>Normalizzazione Sfondo</translation>
    </message>
    <message>
      <source>Background level</source>
      <translation>Livello sfondo</translation>
    </message>
    <message>
      <source>Background matching</source>
      <translation>Matching sfondo</translation>
    </message>
    <message>
      <source>Background model</source>
      <translation>Modello sfondo</translation>
    </message>
    <message>
      <source>Batch Convert Files to Debayered FITS (.fit)</source>
      <translation>Converti File in Batch a FITS Debayerizzato (.fit)</translation>
    </message>
    <message>
      <source>Bayer Pattern</source>
      <translation>Pattern Bayer</translation>
    </message>
    <message>
      <source>Before saving: min = {0:.4f}, max = {1:.4f}</source>
      <translation>Prima del salvataggio: min = {0:.4f}, max = {1:.4f}</translation>
    </message>
    <message>
      <source>Best</source>
      <translation>Migliore</translation>
    </message>
    <message>
      <source>Best Quality</source>
      <translation>Migliore qualità</translation>
    </message>
    <message>
      <source>Bias</source>
      <translation>Bias</translation>
    </message>
    <message>
      <source>Bias Subtracted</source>
      <translation>Bias Sottratto</translation>
    </message>
    <message>
      <source>Bias: {0}</source>
      <translation>Bias: {0}</translation>
    </message>
    <message>
      <source>Bicubic</source>
      <translation>Bicubico</translation>
    </message>
    <message>
      <source>Bicubic Interpolation</source>
      <translation>Interpolazione Bicubica</translation>
    </message>
    <message>
      <source>Bilinear</source>
      <translation>Bilineare</translation>
    </message>
    <message>
      <source>Bilinear Interpolation</source>
      <translation>Interpolazione Bilineare</translation>
    </message>
    <message>
      <source>Binning</source>
      <translation>Binning</translation>
    </message>
    <message>
      <source>Biweight Estimator</source>
      <translation>Stimatore Biweight</translation>
    </message>
    <message>
      <source>Biweight constant:</source>
      <translation>Costante Biweight:</translation>
    </message>
    <message>
      <source>Blend Ratio:</source>
      <translation>Rapporto Miscela:</translation>
    </message>
    <message>
      <source>Blending method</source>
      <translation>Metodo fusione</translation>
    </message>
    <message>
      <source>Both (comet + stars)</source>
      <translation>Entrambi (cometa + stelle)</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Sfoglia</translation>
    </message>
    <message>
      <source>Browse...</source>
      <translation>Sfoglia...</translation>
    </message>
    <message>
      <source>CCD-TEMP</source>
      <translation>Temp-CCD</translation>
    </message>
    <message>
      <source>CFA Drizzle</source>
      <translation>Drizzle CFA</translation>
    </message>
    <message>
      <source>CFA Drizzle (Bayer)</source>
      <translation>CFA Drizzle (Bayer)</translation>
    </message>
    <message>
      <source>CFA Drizzle is enabled but at least one group has only {0} frames.

CFA Drizzle typically needs ≥{1} frames (scale {2:.0f}×) for good coverage.
Switch to Edge-Aware Interpolation for this run?</source>
      <translation>CFA Drizzle abilitato ma almeno un gruppo ha solo {0} frame.

CFA Drizzle tipicamente necessita ≥{1} frame (scala {2:.0f}×) per buona copertura.
Passare a Interpolazione Edge-Aware per questa esecuzione?</translation>
    </message>
    <message>
      <source>CFA Drizzle: Low Sample Count</source>
      <translation>CFA Drizzle: Conteggio Campioni Basso</translation>
    </message>
    <message>
      <source>CFA Edge-Aware Interp</source>
      <translation>Interp CFA Edge-Aware</translation>
    </message>
    <message>
      <source>CMOS users: Bias Subtraction is not needed.
Modern CMOS cameras use Correlated Double Sampling (CDS),
meaning bias is already subtracted at the sensor level.</source>
      <translation>Utenti CMOS: La Sottrazione Bias non è necessaria.
Le moderne camere CMOS usano Correlated Double Sampling (CDS),
quindi il bias è già sottratto a livello sensore.</translation>
    </message>
    <message>
      <source>CPU only</source>
      <translation>Solo CPU</translation>
    </message>
    <message>
      <source>CUDA Installation Info</source>
      <translation>Info Installazione CUDA</translation>
    </message>
    <message>
      <source>Cache size (MB)</source>
      <translation>Dimensione cache (MB)</translation>
    </message>
    <message>
      <source>Calculate from frames</source>
      <translation>Calcola dai frame</translation>
    </message>
    <message>
      <source>Calculating alignment...</source>
      <translation>Calcolo allineamento...</translation>
    </message>
    <message>
      <source>Calculating autocrop bounding box…</source>
      <translation>Calcolo bounding box auto-ritaglio…</translation>
    </message>
    <message>
      <source>Calibrated Light Frames</source>
      <translation>Frame Light Calibrati</translation>
    </message>
    <message>
      <source>Calibrating...</source>
      <translation>Calibrazione...</translation>
    </message>
    <message>
      <source>Calibration</source>
      <translation>Calibrazione</translation>
    </message>
    <message>
      <source>Calibration Settings</source>
      <translation>Impostazioni Calibrazione</translation>
    </message>
    <message>
      <source>Calibration complete</source>
      <translation>Calibrazione completata</translation>
    </message>
    <message>
      <source>Calibration mismatch</source>
      <translation>Calibrazione non corrispondente</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation>Camera</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Cancel the current operation</source>
      <translation>Annulla l'operazione corrente</translation>
    </message>
    <message>
      <source>Cannot write to output directory</source>
      <translation>Impossibile scrivere nella cartella output</translation>
    </message>
    <message>
      <source>Caps Astroalign max_control_points (typical 500–1500). Lower = faster, higher = more robust.</source>
      <translation>Limita max_control_points di Astroalign (tipico 500–1500). Più basso = più veloce, più alto = più robusto.</translation>
    </message>
    <message>
      <source>Capture Date</source>
      <translation>Data cattura</translation>
    </message>
    <message>
      <source>Choose the initial seed image for MFDeconv:
• Robust μ–σ: running mean with sigma clipping (RAM-friendly, default)
• Median: tiled median stack (more outlier-resistant; heavier I/O, esp. for XISF)</source>
      <translation>Scegli l'immagine seed iniziale per MFDeconv:
• μ–σ Robusto: media mobile con sigma clipping (leggero RAM, default)
• Mediana: stack mediana a tile (più resistente outlier; I/O pesante, spec. per XISF)</translation>
    </message>
    <message>
      <source>Chunk Size:</source>
      <translation>Dimensione Chunk:</translation>
    </message>
    <message>
      <source>Chunk size</source>
      <translation>Dimensione chunk</translation>
    </message>
    <message>
      <source>Circular</source>
      <translation>Circolare</translation>
    </message>
    <message>
      <source>Circular (disk)</source>
      <translation>Circolare (disco)</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Cancella</translation>
    </message>
    <message>
      <source>Clear All</source>
      <translation>Cancella Tutto</translation>
    </message>
    <message>
      <source>Clear List</source>
      <translation>Cancella Lista</translation>
    </message>
    <message>
      <source>Clear Selection</source>
      <translation>Cancella Selezione</translation>
    </message>
    <message>
      <source>Clear all files from queue</source>
      <translation>Pulisci tutti i file dalla coda</translation>
    </message>
    <message>
      <source>Clear existing session?</source>
      <translation>Cancellare sessione esistente?</translation>
    </message>
    <message>
      <source>Click to select files</source>
      <translation>Clicca per selezionare file</translation>
    </message>
    <message>
      <source>Clip (lo/hi):</source>
      <translation>Clip (basso/alto):</translation>
    </message>
    <message>
      <source>Clip high</source>
      <translation>Taglia alto</translation>
    </message>
    <message>
      <source>Clip low</source>
      <translation>Taglia basso</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Cold Pixel Removal</source>
      <translation>Rimozione Pixel Freddi</translation>
    </message>
    <message>
      <source>Cold Threshold:</source>
      <translation>Soglia Freddi</translation>
    </message>
    <message>
      <source>Cold pixel detection</source>
      <translation>Rilevamento cold pixel</translation>
    </message>
    <message>
      <source>Cold pixel replacement</source>
      <translation>Sostituzione cold pixel</translation>
    </message>
    <message>
      <source>Cold pixel threshold (σ)</source>
      <translation>Soglia cold pixel (σ)</translation>
    </message>
    <message>
      <source>Cold σ:</source>
      <translation>σ Freddi:</translation>
    </message>
    <message>
      <source>Color matrix</source>
      <translation>Matrice colore</translation>
    </message>
    <message>
      <source>Color mode:</source>
      <translation>Modalità colore:</translation>
    </message>
    <message>
      <source>Columns</source>
      <translation>Colonne</translation>
    </message>
    <message>
      <source>Combine panels</source>
      <translation>Combina pannelli</translation>
    </message>
    <message>
      <source>Comet (High-Clip Percentile tuning)</source>
      <translation>Cometa (tuning Percentile High-Clip)</translation>
    </message>
    <message>
      <source>Comet Center</source>
      <translation>Centro Cometa</translation>
    </message>
    <message>
      <source>Comet Detection:</source>
      <translation>Rilevamento Cometa:</translation>
    </message>
    <message>
      <source>Comet Mode</source>
      <translation>Modalità Cometa</translation>
    </message>
    <message>
      <source>Comet Star Removal (Optional)</source>
      <translation>Rimozione Stelle Cometa (Opzionale)</translation>
    </message>
    <message>
      <source>Comet alignment</source>
      <translation>Allineamento cometa</translation>
    </message>
    <message>
      <source>Complete</source>
      <translation>Completato</translation>
    </message>
    <message>
      <source>Confirm action</source>
      <translation>Conferma azione</translation>
    </message>
    <message>
      <source>Controls down-weighting strength.</source>
      <translation>Controlla la forza del down-weighting.</translation>
    </message>
    <message>
      <source>Conversion complete.</source>
      <translation>Conversione completata.</translation>
    </message>
    <message>
      <source>Conversion list cleared.</source>
      <translation>Lista conversione cancellata.</translation>
    </message>
    <message>
      <source>Conversion output directory set to: {0}</source>
      <translation>Cartella output conversione impostata a: {0}</translation>
    </message>
    <message>
      <source>Convert All Files to FITS</source>
      <translation>Converti Tutti i File in FITS</translation>
    </message>
    <message>
      <source>Convert Non-FITS Formats</source>
      <translation>Converti Formati Non-FITS</translation>
    </message>
    <message>
      <source>Converted</source>
      <translation>Convertito</translation>
    </message>
    <message>
      <source>Converted {0} to FITS with IMAGETYP={1}, EXPTIME={2}.</source>
      <translation>Convertito {0} in FITS con IMAGETYP={1}, EXPTIME={2}.</translation>
    </message>
    <message>
      <source>Copy commands</source>
      <translation>Copia comandi</translation>
    </message>
    <message>
      <source>Core mask feather (px):</source>
      <translation>Sfumatura maschera nucleo (px):</translation>
    </message>
    <message>
      <source>Corrections</source>
      <translation>Correzioni</translation>
    </message>
    <message>
      <source>Cosmetic Correction</source>
      <translation>Correzione Cosmetica</translation>
    </message>
    <message>
      <source>Cosmetic Correction (Advanced)</source>
      <translation>Correzione Cosmetica (Avanzata)</translation>
    </message>
    <message>
      <source>Cosmetic Correction Applied (debayered/mono)</source>
      <translation>Correzione Cosmetica Applicata (debayerizzato/mono)</translation>
    </message>
    <message>
      <source>Cosmetic Correction Applied for Bayer Pattern ({0})</source>
      <translation>Correzione Cosmetica Applicata per Pattern Bayer ({0})</translation>
    </message>
    <message>
      <source>Could not load {0} to create memmap cache.</source>
      <translation>Impossibile caricare {0} per creare cache memmap.</translation>
    </message>
    <message>
      <source>Could not load:
{0}

{1}</source>
      <translation>Impossibile caricare:
{0}

{1}</translation>
    </message>
    <message>
      <source>Coverage:</source>
      <translation>Copertura:</translation>
    </message>
    <message>
      <source>Create Comet-Only Stack</source>
      <translation>Crea Stack Solo Cometa</translation>
    </message>
    <message>
      <source>Create Master</source>
      <translation>Crea Master</translation>
    </message>
    <message>
      <source>Create Master Bias</source>
      <translation>Crea Master Bias</translation>
    </message>
    <message>
      <source>Create Master Calibration Files</source>
      <translation>Crea File Calibrazione Master</translation>
    </message>
    <message>
      <source>Create Master Dark</source>
      <translation>Crea Master Dark</translation>
    </message>
    <message>
      <source>Create Master Darks</source>
      <translation>Crea Master Dark</translation>
    </message>
    <message>
      <source>Create Master Flat</source>
      <translation>Crea Master Flat</translation>
    </message>
    <message>
      <source>Create Master Flats</source>
      <translation>Crea Master Flat</translation>
    </message>
    <message>
      <source>Create Masters</source>
      <translation>Crea Master</translation>
    </message>
    <message>
      <source>Create Stars+Comet Blend</source>
      <translation>Crea Miscela Stelle+Cometa</translation>
    </message>
    <message>
      <source>Create comet-aligned version</source>
      <translation>Crea versione allineata alla cometa</translation>
    </message>
    <message>
      <source>Create log file</source>
      <translation>Crea file log</translation>
    </message>
    <message>
      <source>Create star-aligned version</source>
      <translation>Crea versione allineata alle stelle</translation>
    </message>
    <message>
      <source>Creating master bias...</source>
      <translation>Creazione master bias...</translation>
    </message>
    <message>
      <source>Creating master dark...</source>
      <translation>Creazione master dark...</translation>
    </message>
    <message>
      <source>Creating master flat...</source>
      <translation>Creazione master flat...</translation>
    </message>
    <message>
      <source>Crop Method:</source>
      <translation>Metodo Ritaglio:</translation>
    </message>
    <message>
      <source>Crop Padding (px):</source>
      <translation>Padding Ritaglio (px):</translation>
    </message>
    <message>
      <source>Crop final image to pixels covered by ≥ Coverage % of frames</source>
      <translation>Ritaglia immagine finale ai pixel coperti da ≥ Copertura % dei frame</translation>
    </message>
    <message>
      <source>Crop to common area</source>
      <translation>Ritaglia ad area comune</translation>
    </message>
    <message>
      <source>Cross Correlation</source>
      <translation>Cross correlazione</translation>
    </message>
    <message>
      <source>Current Status: {0}</source>
      <translation>Stato Attuale: {0}</translation>
    </message>
    <message>
      <source>Current Step</source>
      <translation>Passo corrente</translation>
    </message>
    <message>
      <source>Current frame</source>
      <translation>Frame corrente</translation>
    </message>
    <message>
      <source>Current stacking settings saved to profile '{0}'.</source>
      <translation>Impostazioni stacking correnti salvate nel profilo '{0}'.</translation>
    </message>
    <message>
      <source>Custom</source>
      <translation>Personalizzato</translation>
    </message>
    <message>
      <source>Custom Weight</source>
      <translation>Peso personalizzato</translation>
    </message>
    <message>
      <source>Custom directory</source>
      <translation>Cartella personalizzata</translation>
    </message>
    <message>
      <source>Custom matrix</source>
      <translation>Matrice personalizzata</translation>
    </message>
    <message>
      <source>DCB</source>
      <translation>DCB</translation>
    </message>
    <message>
      <source>DEBUG: File '{0}' does not exist on disk.</source>
      <translation>DEBUG: File '{0}' non esiste su disco.</translation>
    </message>
    <message>
      <source>DEC</source>
      <translation>DEC</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Dark</translation>
    </message>
    <message>
      <source>Dark Flat</source>
      <translation>Dark Flat</translation>
    </message>
    <message>
      <source>Dark Flats</source>
      <translation>Dark Flat</translation>
    </message>
    <message>
      <source>Dark Frames</source>
      <translation>Frame Dark</translation>
    </message>
    <message>
      <source>Dark Subtracted: {0}</source>
      <translation>Dark Sottratto: {0}</translation>
    </message>
    <message>
      <source>DarkStar</source>
      <translation>DarkStar</translation>
    </message>
    <message>
      <source>Darks</source>
      <translation>Dark</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Data</translation>
    </message>
    <message>
      <source>Dead column detection</source>
      <translation>Rilevamento colonne morte</translation>
    </message>
    <message>
      <source>Dead row detection</source>
      <translation>Rilevamento righe morte</translation>
    </message>
    <message>
      <source>Debayer</source>
      <translation>Debayer</translation>
    </message>
    <message>
      <source>Debayer Method</source>
      <translation>Metodo Debayer</translation>
    </message>
    <message>
      <source>Debayer Settings</source>
      <translation>Impostazioni Debayer</translation>
    </message>
    <message>
      <source>Debayer before calibration</source>
      <translation>Debayer prima della calibrazione</translation>
    </message>
    <message>
      <source>Debug Mode</source>
      <translation>Modalità Debug</translation>
    </message>
    <message>
      <source>Dec rate (arcsec/min)</source>
      <translation>Velocità Dec (arcsec/min)</translation>
    </message>
    <message>
      <source>Deconvolution Iterations:</source>
      <translation>Iterazioni Deconvoluzione:</translation>
    </message>
    <message>
      <source>Deconvolution Strength:</source>
      <translation>Forza Deconvoluzione:</translation>
    </message>
    <message>
      <source>Deconvolving '{0}' ({1} frames)…</source>
      <translation>Deconvoluzione '{0}' ({1} frame)…</translation>
    </message>
    <message>
      <source>Default</source>
      <translation>Predefinito</translation>
    </message>
    <message>
      <source>Defect Map Files</source>
      <translation>File mappa difetti</translation>
    </message>
    <message>
      <source>Defect map</source>
      <translation>Mappa difetti</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Elimina</translation>
    </message>
    <message>
      <source>Delete profile</source>
      <translation>Elimina profilo</translation>
    </message>
    <message>
      <source>Delete stacking profile '{0}'?</source>
      <translation>Eliminare profilo stacking '{0}'?</translation>
    </message>
    <message>
      <source>Detect bad columns</source>
      <translation>Rileva colonne difettose</translation>
    </message>
    <message>
      <source>Detect bad rows</source>
      <translation>Rileva righe difettose</translation>
    </message>
    <message>
      <source>Detect dithering</source>
      <translation>Rileva dithering</translation>
    </message>
    <message>
      <source>Detected backend:</source>
      <translation>Backend rilevato:</translation>
    </message>
    <message>
      <source>Detecting stars...</source>
      <translation>Rilevamento stelle...</translation>
    </message>
    <message>
      <source>Detection scale</source>
      <translation>Scala rilevamento</translation>
    </message>
    <message>
      <source>Detection threshold</source>
      <translation>Soglia rilevamento</translation>
    </message>
    <message>
      <source>Dilate (+px):</source>
      <translation>Dilata (+px):</translation>
    </message>
    <message>
      <source>Distortion / Transform</source>
      <translation>Distorsione / Trasformazione</translation>
    </message>
    <message>
      <source>Distortion correction</source>
      <translation>Correzione distorsione</translation>
    </message>
    <message>
      <source>Dithering</source>
      <translation>Dithering</translation>
    </message>
    <message>
      <source>Dithering pattern</source>
      <translation>Pattern dithering</translation>
    </message>
    <message>
      <source>Dithering scale</source>
      <translation>Scala dithering</translation>
    </message>
    <message>
      <source>Divide (flat-like)</source>
      <translation>Dividi (tipo flat)</translation>
    </message>
    <message>
      <source>Divide gain limits:</source>
      <translation>Limiti guadagno divisione:</translation>
    </message>
    <message>
      <source>Double-click to preview</source>
      <translation>Doppio click per anteprima</translation>
    </message>
    <message>
      <source>Downloads PyTorch with the right backend (CUDA/MPS/CPU). One-time per machine.</source>
      <translation>Scarica PyTorch con il backend corretto (CUDA/MPS/CPU). Una volta per macchina.</translation>
    </message>
    <message>
      <source>Downsample (AREA):</source>
      <translation>Downsample (AREA):</translation>
    </message>
    <message>
      <source>Downsample:</source>
      <translation>Sottocampionamento:</translation>
    </message>
    <message>
      <source>Drag and drop files here</source>
      <translation>Trascina e rilascia file qui</translation>
    </message>
    <message>
      <source>Drizzle</source>
      <translation>Drizzle</translation>
    </message>
    <message>
      <source>Drizzle Integration</source>
      <translation>Integrazione Drizzle</translation>
    </message>
    <message>
      <source>Drizzle Kernel:</source>
      <translation>Kernel Drizzle:</translation>
    </message>
    <message>
      <source>Drizzle Scale:</source>
      <translation>Scala Drizzle:</translation>
    </message>
    <message>
      <source>Drizzle Settings</source>
      <translation>Impostazioni Drizzle</translation>
    </message>
    <message>
      <source>Drizzle cfg → scale={0}×, pixfrac={1:.3f}, kernel={2}</source>
      <translation>Config Drizzle → scala={0}×, pixfrac={1:.3f}, kernel={2}</translation>
    </message>
    <message>
      <source>Drizzle: False</source>
      <translation>Drizzle: Falso</translation>
    </message>
    <message>
      <source>Drizzle: True, Scale: {0:g}x, Drop: {1:.2f}</source>
      <translation>Drizzle: Vero, Scala: {0:g}x, Drop: {1:.2f}</translation>
    </message>
    <message>
      <source>Drizzle: True, Scale: {0}, Drop: {1:.2f}</source>
      <translation>Drizzle: Vero, Scala: {0}, Drop: {1:.2f}</translation>
    </message>
    <message>
      <source>Drizzle: {0}</source>
      <translation>Drizzle: {0}</translation>
    </message>
    <message>
      <source>Drizzle: {0}, Scale: {1}, Drop:{2}</source>
      <translation>Drizzle: {0}, Scala: {1}, Drop:{2}</translation>
    </message>
    <message>
      <source>Drop Fraction (pixfrac):</source>
      <translation>Frazione Drop (pixfrac):</translation>
    </message>
    <message>
      <source>Drop Shrink:</source>
      <translation>Riduzione Drop:</translation>
    </message>
    <message>
      <source>Drop Size (Pixfrac)</source>
      <translation>Dim. goccia (Pixfrac)</translation>
    </message>
    <message>
      <source>EGAIN</source>
      <translation>Guadagno elettronico</translation>
    </message>
    <message>
      <source>EQUINOX</source>
      <translation>Equinozio</translation>
    </message>
    <message>
      <source>ESD threshold:</source>
      <translation>Soglia ESD:</translation>
    </message>
    <message>
      <source>EXPTIME</source>
      <translation>Tempo esposizione</translation>
    </message>
    <message>
      <source>Eccentricity</source>
      <translation>Eccentricità</translation>
    </message>
    <message>
      <source>Elapsed time</source>
      <translation>Tempo trascorso</translation>
    </message>
    <message>
      <source>Ellipse scale:</source>
      <translation>Scala ellisse:</translation>
    </message>
    <message>
      <source>Enable ABE Pre-Processing</source>
      <translation>Abilita Pre-Elaborazione ABE</translation>
    </message>
    <message>
      <source>Enable Auto Crop</source>
      <translation>Abilita Ritaglio Automatico</translation>
    </message>
    <message>
      <source>Enable Comet Stacking</source>
      <translation>Abilita Stacking Cometa</translation>
    </message>
    <message>
      <source>Enable Cosmetic Correction</source>
      <translation>Abilita Correzione Cosmetica</translation>
    </message>
    <message>
      <source>Enable Drizzle</source>
      <translation>Abilita Drizzle</translation>
    </message>
    <message>
      <source>Enable GPU Acceleration</source>
      <translation>Abilita Accelerazione GPU</translation>
    </message>
    <message>
      <source>Enable GPU/MPS via PyTorch when supported; falls back to CPU automatically.</source>
      <translation>Abilita GPU/MPS via PyTorch quando supportato; fallback automatico su CPU.</translation>
    </message>
    <message>
      <source>Enable MF Deconvolution</source>
      <translation>Abilita Deconvoluzione MF</translation>
    </message>
    <message>
      <source>Enable MFDeconv during integration</source>
      <translation>Abilita MFDeconv durante integrazione</translation>
    </message>
    <message>
      <source>Enable MPS (Apple Silicon)</source>
      <translation>Abilita MPS (Apple Silicon)</translation>
    </message>
    <message>
      <source>Enable Registration</source>
      <translation>Abilita registrazione</translation>
    </message>
    <message>
      <source>Enable Star Trails</source>
      <translation>Abilita Scie Stellari</translation>
    </message>
    <message>
      <source>Enable advanced cosmetic tuning</source>
      <translation>Abilita tuning cosmetico avanzato</translation>
    </message>
    <message>
      <source>Enable comet mode</source>
      <translation>Abilita modalità cometa</translation>
    </message>
    <message>
      <source>Enable cosmetic correction</source>
      <translation>Abilita correzione cosmetica</translation>
    </message>
    <message>
      <source>Enable local normalization</source>
      <translation>Abilita normalizzazione locale</translation>
    </message>
    <message>
      <source>Enable mosaic mode</source>
      <translation>Abilita modalità mosaico</translation>
    </message>
    <message>
      <source>Enable scoring</source>
      <translation>Abilita punteggio</translation>
    </message>
    <message>
      <source>Enter new group name:</source>
      <translation>Inserisci nuovo nome gruppo:</translation>
    </message>
    <message>
      <source>Enter session label (e.g., Night1, RedFilterSet2):</source>
      <translation>Inserisci etichetta sessione (es. Notte1, SetFiltroRosso2):</translation>
    </message>
    <message>
      <source>Enter session name:</source>
      <translation>Inserisci nome sessione:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Error converting {0}: {1}</source>
      <translation>Errore conversione {0}: {1}</translation>
    </message>
    <message>
      <source>Error: {0}</source>
      <translation>Errore: {0}</translation>
    </message>
    <message>
      <source>Estimated remaining</source>
      <translation>Tempo stimato rimanente</translation>
    </message>
    <message>
      <source>Exclude from Stack</source>
      <translation>Escludi da Stack</translation>
    </message>
    <message>
      <source>Exclude from stacking</source>
      <translation>Escludi dallo stacking</translation>
    </message>
    <message>
      <source>Expected dither (pixels)</source>
      <translation>Dither atteso (pixel)</translation>
    </message>
    <message>
      <source>Export Settings</source>
      <translation>Esporta Impostazioni</translation>
    </message>
    <message>
      <source>Exposure</source>
      <translation>Esposizione</translation>
    </message>
    <message>
      <source>Exposure Time</source>
      <translation>Tempo Esposizione</translation>
    </message>
    <message>
      <source>Exposure Tolerance (sec):</source>
      <translation>Tolleranza Esposizione (sec):</translation>
    </message>
    <message>
      <source>Exposure Tolerance (seconds):</source>
      <translation>Tolleranza Esposizione (secondi):</translation>
    </message>
    <message>
      <source>Extreme Studentized Deviate (ESD)</source>
      <translation>Deviazione Studentizzata Estrema (ESD)</translation>
    </message>
    <message>
      <source>FITS</source>
      <translation>FITS</translation>
    </message>
    <message>
      <source>FITS Files</source>
      <translation>File FITS</translation>
    </message>
    <message>
      <source>FITS Files (*.fit *.fits);;All Files (*)</source>
      <translation>File FITS (*.fit *.fits);;Tutti i File (*)</translation>
    </message>
    <message>
      <source>FITS Files (*.fits *.fit *.fts *.fits.gz *.fit.gz *.fz)</source>
      <translation>File FITS (*.fits *.fit *.fts *.fits.gz *.fit.gz *.fz)</translation>
    </message>
    <message>
      <source>FITS Files (*.fits *.fit *.fz *.xisf *.tif *.tiff *.png *.jpg *.jpeg)</source>
      <translation>File FITS (*.fits *.fit *.fz *.xisf *.tif *.tiff *.png *.jpg *.jpeg)</translation>
    </message>
    <message>
      <source>FITS Files (*.fits *.fit)</source>
      <translation>File FITS (*.fits *.fit)</translation>
    </message>
    <message>
      <source>FITS Images (*.fits *.fit);;All Files (*)</source>
      <translation>Immagini FITS (*.fits *.fit);;Tutti i File (*)</translation>
    </message>
    <message>
      <source>FOCALLEN</source>
      <translation>Lunghezza focale</translation>
    </message>
    <message>
      <source>FWHM</source>
      <translation>FWHM</translation>
    </message>
    <message>
      <source>FWHM (lower is better)</source>
      <translation>FWHM (più basso è meglio)</translation>
    </message>
    <message>
      <source>Failed to calibrate frame</source>
      <translation>Calibrazione frame fallita</translation>
    </message>
    <message>
      <source>Failed to load</source>
      <translation>Caricamento fallito</translation>
    </message>
    <message>
      <source>Failed to load frame</source>
      <translation>Caricamento frame fallito</translation>
    </message>
    <message>
      <source>Failed to load image.</source>
      <translation>Caricamento immagine fallito.</translation>
    </message>
    <message>
      <source>Failed to load session</source>
      <translation>Caricamento sessione fallito</translation>
    </message>
    <message>
      <source>Failed to load {0}</source>
      <translation>Caricamento fallito {0}</translation>
    </message>
    <message>
      <source>Failed to register frame</source>
      <translation>Registrazione frame fallita</translation>
    </message>
    <message>
      <source>Failed to save session</source>
      <translation>Salvataggio sessione fallito</translation>
    </message>
    <message>
      <source>Failed to stack frames</source>
      <translation>Stacking frame fallito</translation>
    </message>
    <message>
      <source>Falling back to CPU</source>
      <translation>Ritorno a CPU</translation>
    </message>
    <message>
      <source>Fast (1 pass)</source>
      <translation>Veloce (1 passata)</translation>
    </message>
    <message>
      <source>Fast (AstroAlign)</source>
      <translation>Veloce (AstroAlign)</translation>
    </message>
    <message>
      <source>Fast = single pass; Accurate = 3-pass refinement.</source>
      <translation>Veloce = passata singola; Accurato = raffinamento 3 passate.</translation>
    </message>
    <message>
      <source>Feather</source>
      <translation>Sfumatura</translation>
    </message>
    <message>
      <source>Feather width</source>
      <translation>Larghezza sfumatura</translation>
    </message>
    <message>
      <source>Feather σ (px):</source>
      <translation>Sfumatura σ (px):</translation>
    </message>
    <message>
      <source>Feature Matching</source>
      <translation>Matching caratteristiche</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Filename</source>
      <translation>Nome File</translation>
    </message>
    <message>
      <source>Fill value</source>
      <translation>Valore riempimento</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Filtro</translation>
    </message>
    <message>
      <source>Filter &amp; Exposure</source>
      <translation>Filtro &amp; Esposizione</translation>
    </message>
    <message>
      <source>Filter - Exposure - Size</source>
      <translation>Filtro - Esposizione - Dimensione</translation>
    </message>
    <message>
      <source>Filter by score</source>
      <translation>Filtra per punteggio</translation>
    </message>
    <message>
      <source>Filter={0}  Exp={1}</source>
      <translation>Filtro={0}  Esp={1}</translation>
    </message>
    <message>
      <source>Finalizing...</source>
      <translation>Finalizzazione...</translation>
    </message>
    <message>
      <source>First Frame</source>
      <translation>Primo frame</translation>
    </message>
    <message>
      <source>Flat</source>
      <translation>Flat</translation>
    </message>
    <message>
      <source>Flat Applied: {0}</source>
      <translation>Flat Applicato: {0}</translation>
    </message>
    <message>
      <source>Flat Frames</source>
      <translation>Frame Flat</translation>
    </message>
    <message>
      <source>Flats</source>
      <translation>Flat</translation>
    </message>
    <message>
      <source>Flipping Image</source>
      <translation>Ribaltamento Immagine</translation>
    </message>
    <message>
      <source>For OSC dual-band data: SII/OIII → R=SII, G=OIII; Ha/OIII → R=Ha, G=OIII</source>
      <translation>Per dati OSC dual-band: SII/OIII → R=SII, G=OIII; Ha/OIII → R=Ha, G=OIII</translation>
    </message>
    <message>
      <source>Found '{0}' with IMAGETYP = {1}
which looks like **{2}**, not {3}.

What would you like to do?</source>
      <translation>Trovato '{0}' con IMAGETYP = {1}
che sembra **{2}**, non {3}.

Cosa vuoi fare?</translation>
    </message>
    <message>
      <source>Fraction trimmed on each end before averaging.</source>
      <translation>Frazione tagliata ad ogni estremo prima della media.</translation>
    </message>
    <message>
      <source>Frame Filtering</source>
      <translation>Filtraggio frame</translation>
    </message>
    <message>
      <source>Frame Scoring</source>
      <translation>Punteggio frame</translation>
    </message>
    <message>
      <source>Frame dimensions mismatch</source>
      <translation>Dimensioni frame non corrispondenti</translation>
    </message>
    <message>
      <source>Frames per group:
</source>
      <translation>Frame per gruppo:
</translation>
    </message>
    <message>
      <source>Frames processed</source>
      <translation>Frame elaborati</translation>
    </message>
    <message>
      <source>From WCS</source>
      <translation>Da WCS</translation>
    </message>
    <message>
      <source>GBRG</source>
      <translation>GBRG</translation>
    </message>
    <message>
      <source>GPU Device:</source>
      <translation>Dispositivo GPU:</translation>
    </message>
    <message>
      <source>GPU acceleration not available</source>
      <translation>Accelerazione GPU non disponibile</translation>
    </message>
    <message>
      <source>GPU device</source>
      <translation>Dispositivo GPU</translation>
    </message>
    <message>
      <source>GPU still not being used?</source>
      <translation>GPU ancora non usata?</translation>
    </message>
    <message>
      <source>GRBG</source>
      <translation>GRBG</translation>
    </message>
    <message>
      <source>Gain</source>
      <translation>Guadagno</translation>
    </message>
    <message>
      <source>Gain Clip Max:</source>
      <translation>Gain Clip Max:</translation>
    </message>
    <message>
      <source>Gain Clip Min:</source>
      <translation>Gain Clip Min:</translation>
    </message>
    <message>
      <source>Gaussian</source>
      <translation>Gaussiano</translation>
    </message>
    <message>
      <source>Gaussian σ (px):</source>
      <translation>Gaussiana σ (px):</translation>
    </message>
    <message>
      <source>Generalized ESD</source>
      <translation>ESD Generalizzato</translation>
    </message>
    <message>
      <source>Generalized Extreme Studentized Deviate</source>
      <translation>Generalized Extreme Studentized Deviate</translation>
    </message>
    <message>
      <source>Generate defect map</source>
      <translation>Genera mappa difetti</translation>
    </message>
    <message>
      <source>Generate panel stacks</source>
      <translation>Genera stack pannelli</translation>
    </message>
    <message>
      <source>Gradient Removal (Pre-Integration)</source>
      <translation>Rimozione Gradiente (Pre-Integrazione)</translation>
    </message>
    <message>
      <source>Gradient matching</source>
      <translation>Matching gradiente</translation>
    </message>
    <message>
      <source>Gradient removal (ABE Poly²): mode={0}, samples={1}, downsample={2}, patch={3}, min_strength={4:.2f}%, gain_clip=[{5},{6}]</source>
      <translation>Rimozione gradiente (ABE Poly²): mode={0}, campioni={1}, sottocampionamento={2}, patch={3}, forza_min={4:.2f}%, gain_clip=[{5},{6}]</translation>
    </message>
    <message>
      <source>Grid size</source>
      <translation>Dimensione griglia</translation>
    </message>
    <message>
      <source>Group '{0}' has {1} file(s) after filtering.</source>
      <translation>Gruppo '{0}' ha {1} file dopo filtraggio.</translation>
    </message>
    <message>
      <source>Group By</source>
      <translation>Raggruppa per</translation>
    </message>
    <message>
      <source>Group Name:</source>
      <translation>Nome Gruppo:</translation>
    </message>
    <message>
      <source>Group by dither position</source>
      <translation>Raggruppa per posizione dither</translation>
    </message>
    <message>
      <source>H:</source>
      <translation>H:</translation>
    </message>
    <message>
      <source>Half Size</source>
      <translation>Metà dimensione</translation>
    </message>
    <message>
      <source>Height</source>
      <translation>Altezza</translation>
    </message>
    <message>
      <source>High Octane</source>
      <translation>High Octane</translation>
    </message>
    <message>
      <source>High-Octane (Let 'er rip)</source>
      <translation>Alta Potenza (Scatena tutto)</translation>
    </message>
    <message>
      <source>High-Octane (Let ’er rip)</source>
      <translation>Alta Potenza (Scatena tutto)</translation>
    </message>
    <message>
      <source>High-clip k / Percentile p:</source>
      <translation>k High-clip / Percentile p:</translation>
    </message>
    <message>
      <source>High/Low σ used by sigma-based rejection.</source>
      <translation>σ Alto/Basso usati dal rigetto basato su sigma.</translation>
    </message>
    <message>
      <source>High:</source>
      <translation>Alto:</translation>
    </message>
    <message>
      <source>Homography (full)</source>
      <translation>Omografia (completa)</translation>
    </message>
    <message>
      <source>Homography (projective)</source>
      <translation>Omografia (proiettiva)</translation>
    </message>
    <message>
      <source>Hot Pixel Removal</source>
      <translation>Rimozione Pixel Caldi</translation>
    </message>
    <message>
      <source>Hot Threshold:</source>
      <translation>Soglia Caldi:</translation>
    </message>
    <message>
      <source>Hot pixel detection</source>
      <translation>Rilevamento hot pixel</translation>
    </message>
    <message>
      <source>Hot pixel replacement</source>
      <translation>Sostituzione hot pixel</translation>
    </message>
    <message>
      <source>Hot pixel threshold</source>
      <translation>Soglia hot pixel</translation>
    </message>
    <message>
      <source>Hot pixel threshold (σ)</source>
      <translation>Soglia hot pixel (σ)</translation>
    </message>
    <message>
      <source>Hot σ:</source>
      <translation>σ Caldi:</translation>
    </message>
    <message>
      <source>Huber δ sets the cutoff between 'quadratic' (treat as normal) and 'linear' (treat as outlier) behavior.
• |residual| ≤ δ → quadratic (more aggressive corrections)
• |residual| &gt; δ → linear (gentler, more robust)
Negative values mean 'scale by RMS': e.g., δ = -2 uses 2×RMS.
Smaller |δ| (closer to 0) → more pixels counted as outliers → more conservative.
Examples: κ=1.1 &amp; δ=-0.7 = gentle; κ=2 &amp; δ=-2 = more aggressive.</source>
      <translation>Huber δ imposta il cutoff tra comportamento 'quadratico' (tratta come normale) e 'lineare' (tratta come outlier).
• |residuo| ≤ δ → quadratico (correzioni più aggressive)
• |residuo| &gt; δ → lineare (più delicato, più robusto)
Valori negativi significano 'scala per RMS': es., δ = -2 usa 2×RMS.
|δ| più piccolo (vicino a 0) → più pixel contati come outlier → più conservativo.
Esempi: κ=1.1 &amp; δ=-0.7 = delicato; κ=2 &amp; δ=-2 = più aggressivo.</translation>
    </message>
    <message>
      <source>Huber δ sets the cutoff between ‘quadratic’ (treat as normal) and ‘linear’ (treat as outlier) behavior.
• |residual| ≤ δ → quadratic (more aggressive corrections)
• |residual| &gt; δ → linear (gentler, more robust)
Negative values mean ‘scale by RMS’: e.g., δ = -2 uses 2×RMS.
Smaller |δ| (closer to 0) → more pixels counted as outliers → more conservative.
Examples: κ=1.1 &amp; δ=-0.7 = gentle; κ=2 &amp; δ=-2 = more aggressive.</source>
      <translation>Huber δ imposta il cutoff tra comportamento ‘quadratico’ (tratta come normale) e ‘lineare’ (tratta come outlier).
• |residuo| ≤ δ → quadratico (correzioni più aggressive)
• |residuo| &gt; δ → lineare (più delicato, più robusto)
Valori negativi significano ‘scala per RMS’: es., δ = -2 usa 2×RMS.
|δ| più piccolo (vicino a 0) → più pixel contati come outlier → più conservativo.
Esempi: κ=1.1 &amp; δ=-0.7 = delicato; κ=2 &amp; δ=-2 = più aggressivo.</translation>
    </message>
    <message>
      <source>Huber δ:</source>
      <translation>Huber δ:</translation>
    </message>
    <message>
      <source>IMAGETYP</source>
      <translation>Tipo immagine</translation>
    </message>
    <message>
      <source>INSTRUME</source>
      <translation>Strumento</translation>
    </message>
    <message>
      <source>IQR Clipping</source>
      <translation>IQR Clipping</translation>
    </message>
    <message>
      <source>ISO</source>
      <translation>ISO</translation>
    </message>
    <message>
      <source>If GPU still not being used — click for fix steps</source>
      <translation>Se GPU ancora non usata — clicca per passi correzione</translation>
    </message>
    <message>
      <source>If checked, the best measured frame is accepted automatically.</source>
      <translation>Se selezionato, il miglior frame misurato viene accettato automaticamente.</translation>
    </message>
    <message>
      <source>If enabled, saves the seed and every iteration image into a subfolder next to the final output.</source>
      <translation>Se abilitato, salva il seed e ogni immagine iterazione in una sottocartella accanto all'output finale.</translation>
    </message>
    <message>
      <source>Image Files</source>
      <translation>File immagine</translation>
    </message>
    <message>
      <source>Image Integration</source>
      <translation>Integrazione Immagine</translation>
    </message>
    <message>
      <source>Images (*.fit *.fits *.tif *.tiff *.png *.jpg *.jpeg)</source>
      <translation>Immagini (*.fit *.fits *.tif *.tiff *.png *.jpg *.jpeg)</translation>
    </message>
    <message>
      <source>Import Settings</source>
      <translation>Importa Impostazioni</translation>
    </message>
    <message>
      <source>Important: GPU stacking requires both CUDA and PyTorch-GPU.</source>
      <translation>Importante: lo stacking GPU richiede sia CUDA che PyTorch-GPU.</translation>
    </message>
    <message>
      <source>Include in Stack</source>
      <translation>Includi in Stack</translation>
    </message>
    <message>
      <source>Include in stacking</source>
      <translation>Includi nello stacking</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Info</translation>
    </message>
    <message>
      <source>Install PyTorch (CUDA)</source>
      <translation>Installa PyTorch (CUDA)</translation>
    </message>
    <message>
      <source>Install/Update GPU Acceleration…</source>
      <translation>Installa/Aggiorna Accelerazione GPU…</translation>
    </message>
    <message>
      <source>Installing GPU Acceleration</source>
      <translation>Installazione Accelerazione GPU</translation>
    </message>
    <message>
      <source>Installing NVIDIA CUDA for Stacking Suite</source>
      <translation>Installazione NVIDIA CUDA per Suite Stacking</translation>
    </message>
    <message>
      <source>Insufficient frames for stacking</source>
      <translation>Frame insufficienti per lo stacking</translation>
    </message>
    <message>
      <source>Integrate Only</source>
      <translation>Solo Integrazione</translation>
    </message>
    <message>
      <source>Integrate Previously Registered Images</source>
      <translation>Integra Immagini Precedentemente Registrate</translation>
    </message>
    <message>
      <source>Integrating comet tile {0}…</source>
      <translation>Integrazione tile cometa {0}…</translation>
    </message>
    <message>
      <source>Integrating tile {0}/{1} [y:{2}:{3} x:{4}:{5} size={6}×{7}] mode={8}…</source>
      <translation>Integrazione tile {0}/{1} [y:{2}:{3} x:{4}:{5} size={6}×{7}] mode={8}…</translation>
    </message>
    <message>
      <source>Integrating...</source>
      <translation>Integrazione...</translation>
    </message>
    <message>
      <source>Integration Algorithm</source>
      <translation>Algoritmo Integrazione</translation>
    </message>
    <message>
      <source>Integration Method</source>
      <translation>Metodo integrazione</translation>
    </message>
    <message>
      <source>Integration Method:</source>
      <translation>Metodo Integrazione:</translation>
    </message>
    <message>
      <source>Integration complete for group '{0}'.</source>
      <translation>Integrazione completata per gruppo '{0}'.</translation>
    </message>
    <message>
      <source>Internal Precision:</source>
      <translation>Precisione Interna:</translation>
    </message>
    <message>
      <source>Interpolation</source>
      <translation>Interpolazione</translation>
    </message>
    <message>
      <source>Invalid session file</source>
      <translation>File sessione non valido</translation>
    </message>
    <message>
      <source>Iterations</source>
      <translation>Iterazioni</translation>
    </message>
    <message>
      <source>Iterations (max):</source>
      <translation>Iterazioni (max):</translation>
    </message>
    <message>
      <source>Iterations:</source>
      <translation>Iterazioni:</translation>
    </message>
    <message>
      <source>Kappa-Sigma Clipping</source>
      <translation>Kappa-Sigma Clipping</translation>
    </message>
    <message>
      <source>Kappa:</source>
      <translation>Kappa:</translation>
    </message>
    <message>
      <source>Keep best %</source>
      <translation>Mantieni migliori %</translation>
    </message>
    <message>
      <source>Keep-floor:</source>
      <translation>Soglia minima:</translation>
    </message>
    <message>
      <source>Kernel</source>
      <translation>Kernel</translation>
    </message>
    <message>
      <source>Kernel width:</source>
      <translation>Larghezza kernel:</translation>
    </message>
    <message>
      <source>Kernel:</source>
      <translation>Kernel:</translation>
    </message>
    <message>
      <source>LWP (Local Weighted Polynomial)</source>
      <translation>LWP (Polinomiale Pesato Locale)</translation>
    </message>
    <message>
      <source>Lanczos</source>
      <translation>Lanczos</translation>
    </message>
    <message>
      <source>Lanczos Interpolation</source>
      <translation>Interpolazione Lanczos</translation>
    </message>
    <message>
      <source>Lanczos-2</source>
      <translation>Lanczos-2</translation>
    </message>
    <message>
      <source>Lanczos-3</source>
      <translation>Lanczos-3</translation>
    </message>
    <message>
      <source>Lanczos-4</source>
      <translation>Lanczos-4</translation>
    </message>
    <message>
      <source>Lanczos-5</source>
      <translation>Lanczos-5</translation>
    </message>
    <message>
      <source>Lanczos2</source>
      <translation>Lanczos2</translation>
    </message>
    <message>
      <source>Lanczos3</source>
      <translation>Lanczos3</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Light</translation>
    </message>
    <message>
      <source>Light Frames</source>
      <translation>Frame Luce</translation>
    </message>
    <message>
      <source>Lighten (screen)</source>
      <translation>Schiarisci (screen)</translation>
    </message>
    <message>
      <source>Lights</source>
      <translation>Light</translation>
    </message>
    <message>
      <source>Linear</source>
      <translation>Lineare</translation>
    </message>
    <message>
      <source>Linear Fit Clipping</source>
      <translation>Linear Fit Clipping</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carica</translation>
    </message>
    <message>
      <source>Load Master Dark</source>
      <translation>Carica Master Dark</translation>
    </message>
    <message>
      <source>Load Master Flat</source>
      <translation>Carica Master Flat</translation>
    </message>
    <message>
      <source>Load Session</source>
      <translation>Carica sessione</translation>
    </message>
    <message>
      <source>Load defect map</source>
      <translation>Carica mappa difetti</translation>
    </message>
    <message>
      <source>Load defect map...</source>
      <translation>Carica mappa difetti...</translation>
    </message>
    <message>
      <source>Load profile</source>
      <translation>Carica profilo</translation>
    </message>
    <message>
      <source>Load profile '{0}'?

This will overwrite the current stacking configuration and restart the Stacking Suite.</source>
      <translation>Caricare profilo '{0}'?

Questo sovrascriverà la configurazione stacking corrente e riavvierà la Suite Stacking.</translation>
    </message>
    <message>
      <source>Loading frames...</source>
      <translation>Caricamento frame...</translation>
    </message>
    <message>
      <source>Local Normalization</source>
      <translation>Normalizzazione locale</translation>
    </message>
    <message>
      <source>Lock Reference</source>
      <translation>Blocca Riferimento</translation>
    </message>
    <message>
      <source>Low/High Sigma:</source>
      <translation>Sigma Basso/Alto:</translation>
    </message>
    <message>
      <source>Low:</source>
      <translation>Basso:</translation>
    </message>
    <message>
      <source>Lower = more aggressive (MAD-based).</source>
      <translation>Più basso = più aggressivo (basato su MAD).</translation>
    </message>
    <message>
      <source>Lower = more aggressive outlier rejection.</source>
      <translation>Più basso = rigetto outlier più aggressivo.</translation>
    </message>
    <message>
      <source>Lower = stronger masking near stars; 0 = hard mask, 0.2 = gentle.</source>
      <translation>Più basso = mascheratura più forte vicino stelle; 0 = maschera dura, 0.2 = delicata.</translation>
    </message>
    <message>
      <source>MAD Clipping</source>
      <translation>MAD Clipping</translation>
    </message>
    <message>
      <source>MF Deconvolution</source>
      <translation>Deconvoluzione MF</translation>
    </message>
    <message>
      <source>MF Deconvolution Settings</source>
      <translation>Impostazioni Deconvoluzione MF</translation>
    </message>
    <message>
      <source>MFDeconv Engine</source>
      <translation>Motore MFDeconv</translation>
    </message>
    <message>
      <source>MFDeconv Engine:</source>
      <translation>Motore MFDeconv:</translation>
    </message>
    <message>
      <source>MFDeconv — Multi-Frame Deconvolution (ImageMM)</source>
      <translation>MFDeconv — Deconvoluzione Multi-Frame (ImageMM)</translation>
    </message>
    <message>
      <source>MFDeconv: Normal vs High Octane</source>
      <translation>MFDeconv: Normale vs High Octane</translation>
    </message>
    <message>
      <source>Manual</source>
      <translation>Manuale</translation>
    </message>
    <message>
      <source>Manual Selection</source>
      <translation>Selezione Manuale</translation>
    </message>
    <message>
      <source>Manual Session:</source>
      <translation>Sessione Manuale:</translation>
    </message>
    <message>
      <source>Manual Weight</source>
      <translation>Peso Manuale</translation>
    </message>
    <message>
      <source>Manual layout</source>
      <translation>Layout manuale</translation>
    </message>
    <message>
      <source>Mark as Reference</source>
      <translation>Segna come Riferimento</translation>
    </message>
    <message>
      <source>Mask-based (accurate)</source>
      <translation>Basato su Maschera (accurato)</translation>
    </message>
    <message>
      <source>Master Bias</source>
      <translation>Master Bias</translation>
    </message>
    <message>
      <source>Master Calibration Frames</source>
      <translation>Frame Calibrazione Master</translation>
    </message>
    <message>
      <source>Master Dark</source>
      <translation>Master Dark</translation>
    </message>
    <message>
      <source>Master Dark Flat</source>
      <translation>Master Dark Flat</translation>
    </message>
    <message>
      <source>Master Dark Used</source>
      <translation>Master Dark Usato</translation>
    </message>
    <message>
      <source>Master Darks</source>
      <translation>Master Dark</translation>
    </message>
    <message>
      <source>Master File</source>
      <translation>File Master</translation>
    </message>
    <message>
      <source>Master Flat</source>
      <translation>Master Flat</translation>
    </message>
    <message>
      <source>Master Flats</source>
      <translation>Master Flat</translation>
    </message>
    <message>
      <source>Master bias created</source>
      <translation>Master bias creato</translation>
    </message>
    <message>
      <source>Master dark created</source>
      <translation>Master dark creato</translation>
    </message>
    <message>
      <source>Master flat created</source>
      <translation>Master flat creato</translation>
    </message>
    <message>
      <source>Match by Exposure</source>
      <translation>Abbina per Esposizione</translation>
    </message>
    <message>
      <source>Match by Filter</source>
      <translation>Abbina per Filtro</translation>
    </message>
    <message>
      <source>Match by Gain/ISO</source>
      <translation>Abbina per Gain/ISO</translation>
    </message>
    <message>
      <source>Match by Temperature</source>
      <translation>Abbina per Temperatura</translation>
    </message>
    <message>
      <source>Match by:</source>
      <translation>Abbina per:</translation>
    </message>
    <message>
      <source>Max (brightest)</source>
      <translation>Max (più luminoso)</translation>
    </message>
    <message>
      <source>Max Shift (px):</source>
      <translation>Spostamento Max (px):</translation>
    </message>
    <message>
      <source>Max Stars:</source>
      <translation>Stelle Max:</translation>
    </message>
    <message>
      <source>Max Value</source>
      <translation>Valore Massimo</translation>
    </message>
    <message>
      <source>Max control points:</source>
      <translation>Punti controllo max:</translation>
    </message>
    <message>
      <source>Max ratio:</source>
      <translation>Rapporto max:</translation>
    </message>
    <message>
      <source>Max star radius (px):</source>
      <translation>Raggio stella max (px):</translation>
    </message>
    <message>
      <source>Max stars kept:</source>
      <translation>Stelle max mantenute:</translation>
    </message>
    <message>
      <source>Max stars:</source>
      <translation>Stelle max:</translation>
    </message>
    <message>
      <source>Maximum</source>
      <translation>Massimo</translation>
    </message>
    <message>
      <source>Maximum FWHM</source>
      <translation>FWHM massimo</translation>
    </message>
    <message>
      <source>Maximum background</source>
      <translation>Sfondo massimo</translation>
    </message>
    <message>
      <source>Maximum eccentricity</source>
      <translation>Eccentricità massima</translation>
    </message>
    <message>
      <source>Maximum roundness deviation</source>
      <translation>Deviazione rotondità massima</translation>
    </message>
    <message>
      <source>Maximum stars</source>
      <translation>Stelle massime</translation>
    </message>
    <message>
      <source>Mean</source>
      <translation>Media</translation>
    </message>
    <message>
      <source>Mean ratio:</source>
      <translation>Rapporto media:</translation>
    </message>
    <message>
      <source>Median</source>
      <translation>Mediana</translation>
    </message>
    <message>
      <source>Median (Sukhdeep et al.)</source>
      <translation>Mediana (Sukhdeep et al.)</translation>
    </message>
    <message>
      <source>Median Filter Radius:</source>
      <translation>Raggio Filtro Mediano:</translation>
    </message>
    <message>
      <source>Memory Limit (MB):</source>
      <translation>Limite Memoria (MB):</translation>
    </message>
    <message>
      <source>Memory allocation failed</source>
      <translation>Allocazione memoria fallita</translation>
    </message>
    <message>
      <source>Memory management</source>
      <translation>Gestione memoria</translation>
    </message>
    <message>
      <source>Memory optimization</source>
      <translation>Ottimizzazione memoria</translation>
    </message>
    <message>
      <source>Merge Groups</source>
      <translation>Unisci Gruppi</translation>
    </message>
    <message>
      <source>Metadata</source>
      <translation>Metadati</translation>
    </message>
    <message>
      <source>Min (darkest)</source>
      <translation>Min (più scuro)</translation>
    </message>
    <message>
      <source>Min Frames for Master:</source>
      <translation>Frame Minimi per Master:</translation>
    </message>
    <message>
      <source>Min Stars:</source>
      <translation>Stelle Min:</translation>
    </message>
    <message>
      <source>Min Strength:</source>
      <translation>Forza Minima:</translation>
    </message>
    <message>
      <source>Min iters:</source>
      <translation>Iterazioni min:</translation>
    </message>
    <message>
      <source>Min star area (px):</source>
      <translation>Area stella min (px):</translation>
    </message>
    <message>
      <source>Minimum</source>
      <translation>Minimo</translation>
    </message>
    <message>
      <source>Minimum connected-pixel area to keep a detection as a star (px). Helps reject hot pixels/noise.</source>
      <translation>Area minima pixel connessi per mantenere un rilevamento come stella (px). Aiuta a rifiutare pixel caldi/rumore.</translation>
    </message>
    <message>
      <source>Minimum score</source>
      <translation>Punteggio minimo</translation>
    </message>
    <message>
      <source>Minimum stars</source>
      <translation>Stelle minime</translation>
    </message>
    <message>
      <source>Mismatched Image Type</source>
      <translation>Tipo Immagine Non Corrispondente</translation>
    </message>
    <message>
      <source>Mix:</source>
      <translation>Mix:</translation>
    </message>
    <message>
      <source>Mode:</source>
      <translation>Modalità:</translation>
    </message>
    <message>
      <source>Model:</source>
      <translation>Modello:</translation>
    </message>
    <message>
      <source>Modified Z threshold:</source>
      <translation>Soglia Z Modificata:</translation>
    </message>
    <message>
      <source>Modified Z-Score Clipping</source>
      <translation>Clipping Z-Score Modificato</translation>
    </message>
    <message>
      <source>Mosaic Mode</source>
      <translation>Modalità Mosaico</translation>
    </message>
    <message>
      <source>Motion vector</source>
      <translation>Vettore movimento</translation>
    </message>
    <message>
      <source>Multi-Frame Deconvolution</source>
      <translation>Deconvoluzione Multi-Frame</translation>
    </message>
    <message>
      <source>Multi-band</source>
      <translation>Multi-banda</translation>
    </message>
    <message>
      <source>Multi-frame Deconvolution</source>
      <translation>Deconvoluzione Multi-frame</translation>
    </message>
    <message>
      <source>Multi-frame deconvolving…</source>
      <translation>Deconvoluzione multi-frame…</translation>
    </message>
    <message>
      <source>Multiplicative</source>
      <translation>Moltiplicativa</translation>
    </message>
    <message>
      <source>Multiplicative with Scaling</source>
      <translation>Moltiplicativa con scala</translation>
    </message>
    <message>
      <source>Naive (pixfrac=1)</source>
      <translation>Naive (pixfrac=1)</translation>
    </message>
    <message>
      <source>Nearest Neighbor</source>
      <translation>Nearest Neighbor</translation>
    </message>
    <message>
      <source>New Group</source>
      <translation>Nuovo Gruppo</translation>
    </message>
    <message>
      <source>New Session</source>
      <translation>Nuova sessione</translation>
    </message>
    <message>
      <source>New stacking profile</source>
      <translation>Nuovo profilo stacking</translation>
    </message>
    <message>
      <source>New…</source>
      <translation>Nuovo…</translation>
    </message>
    <message>
      <source>No Calibration</source>
      <translation>Nessuna Calibrazione</translation>
    </message>
    <message>
      <source>No Distortion (rotate/translate/scale)</source>
      <translation>Nessuna Distorsione (ruota/trasla/scala)</translation>
    </message>
    <message>
      <source>No Files</source>
      <translation>Nessun File</translation>
    </message>
    <message>
      <source>No Normalization</source>
      <translation>Nessuna normalizzazione</translation>
    </message>
    <message>
      <source>No Output Directory</source>
      <translation>Nessuna Cartella Output</translation>
    </message>
    <message>
      <source>No Rejection</source>
      <translation>Nessun Rifiuto</translation>
    </message>
    <message>
      <source>No Weighting</source>
      <translation>Nessun peso</translation>
    </message>
    <message>
      <source>No calibration frames</source>
      <translation>Nessun frame di calibrazione</translation>
    </message>
    <message>
      <source>No comet center was selected. Registration has been cancelled so you can try again.</source>
      <translation>Nessun centro cometa selezionato. La registrazione è stata annullata per riprovare.</translation>
    </message>
    <message>
      <source>No file chosen.</source>
      <translation>Nessun file scelto.</translation>
    </message>
    <message>
      <source>No file selected</source>
      <translation>Nessun file selezionato</translation>
    </message>
    <message>
      <source>No files selected for split.</source>
      <translation>Nessun file selezionato per divisione.</translation>
    </message>
    <message>
      <source>No frames loaded</source>
      <translation>Nessun frame caricato</translation>
    </message>
    <message>
      <source>No light frames</source>
      <translation>Nessun frame light</translation>
    </message>
    <message>
      <source>No new reference selected; using previous reference.</source>
      <translation>Nessun nuovo riferimento selezionato; uso riferimento precedente.</translation>
    </message>
    <message>
      <source>No output directory is set. Do you want to select one now?</source>
      <translation>Nessuna cartella output impostata. Vuoi selezionarne una ora?</translation>
    </message>
    <message>
      <source>No profile selected</source>
      <translation>Nessun profilo selezionato</translation>
    </message>
    <message>
      <source>No stacking folder selected</source>
      <translation>Nessuna cartella stacking selezionata</translation>
    </message>
    <message>
      <source>No stars detected in frame</source>
      <translation>Nessuna stella rilevata nel frame</translation>
    </message>
    <message>
      <source>Noise Evaluation</source>
      <translation>Valutazione rumore</translation>
    </message>
    <message>
      <source>Noise level</source>
      <translation>Livello rumore</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nessuno</translation>
    </message>
    <message>
      <source>None (Use Auto-Select)</source>
      <translation>Nessuno (Usa Auto-Selezione)</translation>
    </message>
    <message>
      <source>None (Use no Dark to Calibrate)</source>
      <translation>Nessuno (Non usare Dark per Calibrazione)</translation>
    </message>
    <message>
      <source>Normal</source>
      <translation>Normale</translation>
    </message>
    <message>
      <source>Normal (cuDNN-free)</source>
      <translation>Normale (senza cuDNN)</translation>
    </message>
    <message>
      <source>Normal (fallback)</source>
      <translation>Normale (fallback)</translation>
    </message>
    <message>
      <source>Normalization</source>
      <translation>Normalizzazione</translation>
    </message>
    <message>
      <source>Normalization &amp; Gradient (ABE Poly²)</source>
      <translation>Normalizzazione &amp; Gradiente (ABE Poly²)</translation>
    </message>
    <message>
      <source>Normalize by:</source>
      <translation>Normalizza per:</translation>
    </message>
    <message>
      <source>Notes</source>
      <translation>Note</translation>
    </message>
    <message>
      <source>Nucleus position</source>
      <translation>Posizione nucleo</translation>
    </message>
    <message>
      <source>Number of kappa-sigma iterations.</source>
      <translation>Numero di iterazioni kappa-sigma.</translation>
    </message>
    <message>
      <source>Number of threads</source>
      <translation>Numero di thread</translation>
    </message>
    <message>
      <source>Number of threads:</source>
      <translation>Numero di thread:</translation>
    </message>
    <message>
      <source>OBJECT</source>
      <translation>Oggetto</translation>
    </message>
    <message>
      <source>OFF</source>
      <translation>OFF</translation>
    </message>
    <message>
      <source>ON, Scale {0}, Drop {1:.2f}</source>
      <translation>ON, Scala {0}, Drop {1:.2f}</translation>
    </message>
    <message>
      <source>Observer</source>
      <translation>Osservatore</translation>
    </message>
    <message>
      <source>Offset</source>
      <translation>Offset</translation>
    </message>
    <message>
      <source>Open Command Prompt and run the following.

Step 1: uninstall PyTorch
Step 2: install the correct build for your GPU</source>
      <translation>Apri Prompt Comandi ed esegui i seguenti.

Passo 1: disinstalla PyTorch
Passo 2: installa la build corretta per la tua GPU</translation>
    </message>
    <message>
      <source>Open Log</source>
      <translation>Apri Log</translation>
    </message>
    <message>
      <source>Open in viewer</source>
      <translation>Apri nel visualizzatore</translation>
    </message>
    <message>
      <source>Open result when done</source>
      <translation>Apri risultato al termine</translation>
    </message>
    <message>
      <source>Open the main window to see the Stacking Log dock.</source>
      <translation>Apri la finestra principale per vedere il dock Log Stacking.</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Output</translation>
    </message>
    <message>
      <source>Output Bit Depth</source>
      <translation>Profondità bit output</translation>
    </message>
    <message>
      <source>Output Directory</source>
      <translation>Cartella output</translation>
    </message>
    <message>
      <source>Output Directory:</source>
      <translation>Cartella Output:</translation>
    </message>
    <message>
      <source>Output Filename</source>
      <translation>Nome file output</translation>
    </message>
    <message>
      <source>Output Format</source>
      <translation>Formato output</translation>
    </message>
    <message>
      <source>Output Settings</source>
      <translation>Impostazioni output</translation>
    </message>
    <message>
      <source>Output directory does not exist</source>
      <translation>Cartella output non esistente</translation>
    </message>
    <message>
      <source>Output directory is not set.</source>
      <translation>Cartella output non impostata.</translation>
    </message>
    <message>
      <source>Output pixel size</source>
      <translation>Dimensione pixel output</translation>
    </message>
    <message>
      <source>Output saved to:</source>
      <translation>Output salvato in:</translation>
    </message>
    <message>
      <source>Overall Progress</source>
      <translation>Progresso complessivo</translation>
    </message>
    <message>
      <source>Overlap</source>
      <translation>Sovrapposizione</translation>
    </message>
    <message>
      <source>Override Dark Frame</source>
      <translation>Override Frame Dark</translation>
    </message>
    <message>
      <source>Override Flat Frame</source>
      <translation>Override Frame Flat</translation>
    </message>
    <message>
      <source>Override Master Dark Selection</source>
      <translation>Override Selezione Master Dark</translation>
    </message>
    <message>
      <source>Overwrite existing file?</source>
      <translation>Sovrascrivere file esistente?</translation>
    </message>
    <message>
      <source>PIXSIZE1</source>
      <translation>Dim. pixel 1</translation>
    </message>
    <message>
      <source>PIXSIZE2</source>
      <translation>Dim. pixel 2</translation>
    </message>
    <message>
      <source>PSF Estimation:</source>
      <translation>Stima PSF:</translation>
    </message>
    <message>
      <source>PSF FWHM:</source>
      <translation>FWHM PSF:</translation>
    </message>
    <message>
      <source>Panel layout</source>
      <translation>Layout pannelli</translation>
    </message>
    <message>
      <source>Parallel Loading</source>
      <translation>Caricamento Parallelo</translation>
    </message>
    <message>
      <source>Parallel processing</source>
      <translation>Elaborazione parallela</translation>
    </message>
    <message>
      <source>Patch Size:</source>
      <translation>Dimensione Patch:</translation>
    </message>
    <message>
      <source>Patch size (small):</source>
      <translation>Dimensione patch (piccola):</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Percorso</translation>
    </message>
    <message>
      <source>Pattern</source>
      <translation>Pattern</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Pausa</translation>
    </message>
    <message>
      <source>Pedestal (0-1000):</source>
      <translation>Piedistallo (0-1000):</translation>
    </message>
    <message>
      <source>Pending</source>
      <translation>In Attesa</translation>
    </message>
    <message>
      <source>Per-frame alignment timeout for the parallel workers. Default 300s.</source>
      <translation>Timeout allineamento per-frame per i worker paralleli. Default 300s.</translation>
    </message>
    <message>
      <source>Percentile Clip</source>
      <translation>Percentile Clip</translation>
    </message>
    <message>
      <source>Percentile Clipping</source>
      <translation>Percentile Clipping</translation>
    </message>
    <message>
      <source>Percentile High</source>
      <translation>Percentile Alto</translation>
    </message>
    <message>
      <source>Percentile High:</source>
      <translation>Percentile Alto:</translation>
    </message>
    <message>
      <source>Percentile Low</source>
      <translation>Percentile Basso</translation>
    </message>
    <message>
      <source>Percentile Low:</source>
      <translation>Percentile Basso:</translation>
    </message>
    <message>
      <source>Performance</source>
      <translation>Prestazioni</translation>
    </message>
    <message>
      <source>Performance Settings</source>
      <translation>Impostazioni Prestazioni</translation>
    </message>
    <message>
      <source>Phase Correlation</source>
      <translation>Correlazione di fase</translation>
    </message>
    <message>
      <source>Pick a frame to mark the comet center</source>
      <translation>Scegli un frame per marcare il centro della cometa</translation>
    </message>
    <message>
      <source>Pick comet center…</source>
      <translation>Scegli centro cometa…</translation>
    </message>
    <message>
      <source>Pixel rejection (local)</source>
      <translation>Reiezione pixel (locale)</translation>
    </message>
    <message>
      <source>Pixels above this image quantile are treated as saturated and never replaced.</source>
      <translation>I pixel sopra questo quantile immagine sono trattati come saturi e mai sostituiti.</translation>
    </message>
    <message>
      <source>Please choose a profile to load.</source>
      <translation>Scegli un profilo da caricare.</translation>
    </message>
    <message>
      <source>Please select a conversion output directory first.</source>
      <translation>Seleziona prima una cartella output per la conversione.</translation>
    </message>
    <message>
      <source>Please set the stacking directory first using the wrench button.</source>
      <translation>Imposta prima la cartella stacking usando il pulsante chiave inglese.</translation>
    </message>
    <message>
      <source>Please set the stacking directory first.</source>
      <translation>Imposta prima la cartella stacking.</translation>
    </message>
    <message>
      <source>Please wait</source>
      <translation>Attendere prego</translation>
    </message>
    <message>
      <source>Point</source>
      <translation>Punto</translation>
    </message>
    <message>
      <source>Polynomial 3rd-order</source>
      <translation>Polinomiale 3° ordine</translation>
    </message>
    <message>
      <source>Polynomial 4th-order</source>
      <translation>Polinomiale 4° ordine</translation>
    </message>
    <message>
      <source>Polynomial Degree:</source>
      <translation>Grado Polinomiale:</translation>
    </message>
    <message>
      <source>Polynomial degree</source>
      <translation>Grado polinomiale</translation>
    </message>
    <message>
      <source>Post-Alignment</source>
      <translation>Post-Allineamento</translation>
    </message>
    <message>
      <source>Prefix</source>
      <translation>Prefisso</translation>
    </message>
    <message>
      <source>Preparing MF deconvolution…</source>
      <translation>Preparazione deconvoluzione MF…</translation>
    </message>
    <message>
      <source>Preparing runtime…</source>
      <translation>Preparazione runtime…</translation>
    </message>
    <message>
      <source>Preserve raw data</source>
      <translation>Preserva dati grezzi</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Preview background</source>
      <translation>Anteprima sfondo</translation>
    </message>
    <message>
      <source>Preview defects</source>
      <translation>Anteprima difetti</translation>
    </message>
    <message>
      <source>Preview filename</source>
      <translation>Anteprima nome file</translation>
    </message>
    <message>
      <source>Preview integration</source>
      <translation>Anteprima integrazione</translation>
    </message>
    <message>
      <source>Preview motion</source>
      <translation>Anteprima movimento</translation>
    </message>
    <message>
      <source>Preview size</source>
      <translation>Dimensione anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Profile name:</source>
      <translation>Nome profilo:</translation>
    </message>
    <message>
      <source>Profile saved</source>
      <translation>Profilo salvato</translation>
    </message>
    <message>
      <source>Profile:</source>
      <translation>Profilo:</translation>
    </message>
    <message>
      <source>Profiles</source>
      <translation>Profili</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation>Progresso</translation>
    </message>
    <message>
      <source>Progress initialized: {0} tiles across groups.</source>
      <translation>Progresso inizializzato: {0} tile tra i gruppi.</translation>
    </message>
    <message>
      <source>Protect core radius (px):</source>
      <translation>Raggio protezione nucleo (px):</translation>
    </message>
    <message>
      <source>Quality</source>
      <translation>Qualità</translation>
    </message>
    <message>
      <source>RA</source>
      <translation>AR</translation>
    </message>
    <message>
      <source>RA rate (arcsec/min)</source>
      <translation>Velocità AR (arcsec/min)</translation>
    </message>
    <message>
      <source>RANSAC Iterations:</source>
      <translation>Iterazioni RANSAC:</translation>
    </message>
    <message>
      <source>RANSAC Threshold:</source>
      <translation>Soglia RANSAC:</translation>
    </message>
    <message>
      <source>RANSAC reproj (px):</source>
      <translation>Riproiezione RANSAC (px):</translation>
    </message>
    <message>
      <source>RGGB</source>
      <translation>RGGB</translation>
    </message>
    <message>
      <source>Ready</source>
      <translation>Pronto</translation>
    </message>
    <message>
      <source>Recent Sessions</source>
      <translation>Sessioni recenti</translation>
    </message>
    <message>
      <source>Reconstruct on an r× super-res grid using SR PSFs.
Compute cost grows roughly ~ r^4. Drizzle usually provides better results.</source>
      <translation>Ricostruisci su griglia super-res r× usando PSF SR.
Costo computazionale cresce circa ~ r^4. Drizzle solitamente dà risultati migliori.</translation>
    </message>
    <message>
      <source>Recurse subfolders</source>
      <translation>Ricorsione sottocartelle</translation>
    </message>
    <message>
      <source>Reference Frame</source>
      <translation>Frame di riferimento</translation>
    </message>
    <message>
      <source>Reference frame not found</source>
      <translation>Frame di riferimento non trovato</translation>
    </message>
    <message>
      <source>Refinement:</source>
      <translation>Raffinamento:</translation>
    </message>
    <message>
      <source>Register &amp;&amp; Integrate</source>
      <translation>Registra &amp;&amp; Integra</translation>
    </message>
    <message>
      <source>Register Only</source>
      <translation>Solo Registrazione</translation>
    </message>
    <message>
      <source>Registering...</source>
      <translation>Registrazione...</translation>
    </message>
    <message>
      <source>Registration</source>
      <translation>Registrazione</translation>
    </message>
    <message>
      <source>Registration Method</source>
      <translation>Metodo registrazione</translation>
    </message>
    <message>
      <source>Registration Settings</source>
      <translation>Impostazioni registrazione</translation>
    </message>
    <message>
      <source>Registration complete</source>
      <translation>Registrazione completata</translation>
    </message>
    <message>
      <source>Registration failed for frame</source>
      <translation>Registrazione fallita per il frame</translation>
    </message>
    <message>
      <source>Registration in progress…</source>
      <translation>Registrazione in corso…</translation>
    </message>
    <message>
      <source>Regularization (lambda):</source>
      <translation>Regolarizzazione (lambda):</translation>
    </message>
    <message>
      <source>Regularization:</source>
      <translation>Regolarizzazione:</translation>
    </message>
    <message>
      <source>Reject a frame if its residual shift exceeds this many pixels after alignment.</source>
      <translation>Rifiuta un frame se il suo spostamento residuo supera questi pixel dopo l'allineamento.</translation>
    </message>
    <message>
      <source>Reject worst %</source>
      <translation>Rifiuta peggiori %</translation>
    </message>
    <message>
      <source>Rejected</source>
      <translation>Rifiutati</translation>
    </message>
    <message>
      <source>Rejection</source>
      <translation>Reiezione</translation>
    </message>
    <message>
      <source>Rejection Algorithm</source>
      <translation>Algoritmo Rifiuto</translation>
    </message>
    <message>
      <source>Rejection Method</source>
      <translation>Metodo di reiezione</translation>
    </message>
    <message>
      <source>Rejection Method:</source>
      <translation>Metodo Rifiuto:</translation>
    </message>
    <message>
      <source>Remove All</source>
      <translation>Rimuovi tutto</translation>
    </message>
    <message>
      <source>Remove Selected</source>
      <translation>Rimuovi Selezionati</translation>
    </message>
    <message>
      <source>Remove background gradient (ABE Poly²)</source>
      <translation>Rimuovi gradiente sfondo (ABE Poly²)</translation>
    </message>
    <message>
      <source>Remove from Group</source>
      <translation>Rimuovi dal Gruppo</translation>
    </message>
    <message>
      <source>Remove selected files from queue</source>
      <translation>Rimuovi file selezionati dalla coda</translation>
    </message>
    <message>
      <source>Remove stars on comet-aligned frames</source>
      <translation>Rimuovi stelle sui frame allineati cometa</translation>
    </message>
    <message>
      <source>Rename Group</source>
      <translation>Rinomina Gruppo</translation>
    </message>
    <message>
      <source>Requires 'Enable Drizzle'. Maps R/G/B CFA samples directly into channels (no interpolation).</source>
      <translation>Richiede 'Abilita Drizzle'. Mappa campioni R/G/B CFA direttamente nei canali (senza interpolazione).</translation>
    </message>
    <message>
      <source>Reset All</source>
      <translation>Reimposta Tutto</translation>
    </message>
    <message>
      <source>Reset MFDeconv to Recommended</source>
      <translation>Reimposta MFDeconv a Raccomandati</translation>
    </message>
    <message>
      <source>Reset filter</source>
      <translation>Reimposta filtro</translation>
    </message>
    <message>
      <source>Reset to Defaults</source>
      <translation>Reimposta Predefiniti</translation>
    </message>
    <message>
      <source>Restore MFDeconv star mask + variance map tuning to the recommended defaults.</source>
      <translation>Ripristina tuning maschera stelle + mappa varianza MFDeconv ai default raccomandati.</translation>
    </message>
    <message>
      <source>Restore Recommended</source>
      <translation>Ripristina Raccomandati</translation>
    </message>
    <message>
      <source>Resume</source>
      <translation>Riprendi</translation>
    </message>
    <message>
      <source>Review Reference Before Alignment</source>
      <translation>Rivedi Riferimento Prima dell'Allineamento</translation>
    </message>
    <message>
      <source>Right Click to Assign Session Keys if desired</source>
      <translation>Click Destro per Assegnare Chiavi Sessione se desiderato</translation>
    </message>
    <message>
      <source>Right-click for options</source>
      <translation>Click destro per opzioni</translation>
    </message>
    <message>
      <source>Robust μ–σ (live stack)</source>
      <translation>μ–σ Robusto (live stack)</translation>
    </message>
    <message>
      <source>Roundness (closer to 1 is better)</source>
      <translation>Rotondità (più vicino a 1 è meglio)</translation>
    </message>
    <message>
      <source>Rows</source>
      <translation>Righe</translation>
    </message>
    <message>
      <source>Runs multi-frame deconvolution during integration. Turn off if testing.</source>
      <translation>Esegue deconvoluzione multi-frame durante integrazione. Disattiva per test.</translation>
    </message>
    <message>
      <source>SET-TEMP</source>
      <translation>Temp-Impostata</translation>
    </message>
    <message>
      <source>SITELAT</source>
      <translation>Latitudine sito</translation>
    </message>
    <message>
      <source>SITELONG</source>
      <translation>Longitudine sito</translation>
    </message>
    <message>
      <source>SNR Weight</source>
      <translation>Peso SNR</translation>
    </message>
    <message>
      <source>Same as input</source>
      <translation>Stessa dell'input</translation>
    </message>
    <message>
      <source>Sample Points:</source>
      <translation>Punti Campione:</translation>
    </message>
    <message>
      <source>Sample points:</source>
      <translation>Punti campione:</translation>
    </message>
    <message>
      <source>Saturation quantile:</source>
      <translation>Quantile saturazione:</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Save Defect Map</source>
      <translation>Salva mappa difetti</translation>
    </message>
    <message>
      <source>Save Rejection Maps</source>
      <translation>Salva Mappe Rifiuto</translation>
    </message>
    <message>
      <source>Save Session</source>
      <translation>Salva sessione</translation>
    </message>
    <message>
      <source>Save Session As...</source>
      <translation>Salva sessione come...</translation>
    </message>
    <message>
      <source>Save Star-Trail Image</source>
      <translation>Salva Immagine Scie Stellari</translation>
    </message>
    <message>
      <source>Save all comet-aligned starless frames.
Requires: 'Create comet stack' AND 'Remove stars on comet-aligned frames'.</source>
      <translation>Salva tutti i frame cometa allineati senza stelle.
Richiede: 'Crea stack cometa' E 'Rimuovi stelle sui frame allineati cometa'.</translation>
    </message>
    <message>
      <source>Save all comet-aligned starless frames.
Requires: ‘Create comet stack’ AND ‘Remove stars on comet-aligned frames’.</source>
      <translation>Salva tutti i frame cometa allineati senza stelle.
Richiede: ‘Crea stack cometa’ E ‘Rimuovi stelle sui frame allineati cometa’.</translation>
    </message>
    <message>
      <source>Save all starless comet-aligned frames</source>
      <translation>Salva tutti i frame cometa allineati senza stelle</translation>
    </message>
    <message>
      <source>Save calibrated frames</source>
      <translation>Salva frame calibrati</translation>
    </message>
    <message>
      <source>Save defect map</source>
      <translation>Salva mappa difetti</translation>
    </message>
    <message>
      <source>Save defect map...</source>
      <translation>Salva mappa difetti...</translation>
    </message>
    <message>
      <source>Save intermediate files</source>
      <translation>Salva file intermedi</translation>
    </message>
    <message>
      <source>Save intermediate iterative images</source>
      <translation>Salva immagini iterative intermedie</translation>
    </message>
    <message>
      <source>Save profile as…</source>
      <translation>Salva profilo come…</translation>
    </message>
    <message>
      <source>Save registered frames</source>
      <translation>Salva frame registrati</translation>
    </message>
    <message>
      <source>Save rejection maps</source>
      <translation>Salva mappe reiezione</translation>
    </message>
    <message>
      <source>Save session before closing?</source>
      <translation>Salvare la sessione prima di chiudere?</translation>
    </message>
    <message>
      <source>Saved: {0} ({1}/{2})</source>
      <translation>Salvato: {0} ({1}/{2})</translation>
    </message>
    <message>
      <source>Scale</source>
      <translation>Scala</translation>
    </message>
    <message>
      <source>Scale to Reference</source>
      <translation>Scala al Riferimento</translation>
    </message>
    <message>
      <source>Scale:</source>
      <translation>Scala:</translation>
    </message>
    <message>
      <source>Score by</source>
      <translation>Punteggio per</translation>
    </message>
    <message>
      <source>Seed image:</source>
      <translation>Immagine seed:</translation>
    </message>
    <message>
      <source>Select Bias Directory</source>
      <translation>Seleziona Cartella Bias</translation>
    </message>
    <message>
      <source>Select Bias Files</source>
      <translation>Seleziona File Bias</translation>
    </message>
    <message>
      <source>Select Bias Frames</source>
      <translation>Seleziona frame Bias</translation>
    </message>
    <message>
      <source>Select Conversion Output Directory</source>
      <translation>Seleziona Cartella Output Conversione</translation>
    </message>
    <message>
      <source>Select Dark Directory</source>
      <translation>Seleziona Cartella Dark</translation>
    </message>
    <message>
      <source>Select Dark Files</source>
      <translation>Seleziona File Dark</translation>
    </message>
    <message>
      <source>Select Dark Flat Frames</source>
      <translation>Seleziona frame Dark Flat</translation>
    </message>
    <message>
      <source>Select Dark Frames</source>
      <translation>Seleziona frame Dark</translation>
    </message>
    <message>
      <source>Select Defect Map</source>
      <translation>Seleziona mappa difetti</translation>
    </message>
    <message>
      <source>Select Directory for Conversion</source>
      <translation>Seleziona Cartella per Conversione</translation>
    </message>
    <message>
      <source>Select Files for Conversion</source>
      <translation>Seleziona File per Conversione</translation>
    </message>
    <message>
      <source>Select Flat Directory</source>
      <translation>Seleziona Cartella Flat</translation>
    </message>
    <message>
      <source>Select Flat Files</source>
      <translation>Seleziona File Flat</translation>
    </message>
    <message>
      <source>Select Flat Frames</source>
      <translation>Seleziona frame Flat</translation>
    </message>
    <message>
      <source>Select Light Directory</source>
      <translation>Seleziona Cartella Light</translation>
    </message>
    <message>
      <source>Select Light Files</source>
      <translation>Seleziona File Light</translation>
    </message>
    <message>
      <source>Select Light Frames</source>
      <translation>Seleziona frame Light</translation>
    </message>
    <message>
      <source>Select Master Bias</source>
      <translation>Seleziona Master Bias</translation>
    </message>
    <message>
      <source>Select Master Bias File(s)</source>
      <translation>Seleziona File Master Bias</translation>
    </message>
    <message>
      <source>Select Master Bias Frame</source>
      <translation>Seleziona Frame Master Bias</translation>
    </message>
    <message>
      <source>Select Master Dark</source>
      <translation>Seleziona Master Dark</translation>
    </message>
    <message>
      <source>Select Master Dark File(s)</source>
      <translation>Seleziona File Master Dark</translation>
    </message>
    <message>
      <source>Select Master Flat</source>
      <translation>Seleziona Master Flat</translation>
    </message>
    <message>
      <source>Select Master Flat File(s)</source>
      <translation>Seleziona File Master Flat</translation>
    </message>
    <message>
      <source>Select New Reference Frame</source>
      <translation>Seleziona Nuovo Frame Riferimento</translation>
    </message>
    <message>
      <source>Select Output Directory</source>
      <translation>Seleziona Cartella Output</translation>
    </message>
    <message>
      <source>Select Reference Frame</source>
      <translation>Seleziona frame di riferimento</translation>
    </message>
    <message>
      <source>Select Reference Frame:</source>
      <translation>Seleziona Frame Riferimento:</translation>
    </message>
    <message>
      <source>Select Reference...</source>
      <translation>Seleziona riferimento...</translation>
    </message>
    <message>
      <source>Select Stacking Directory</source>
      <translation>Seleziona Cartella Stacking</translation>
    </message>
    <message>
      <source>Select files to split:</source>
      <translation>Seleziona file da dividere:</translation>
    </message>
    <message>
      <source>Select output directory for stacked images</source>
      <translation>Seleziona cartella output per immagini stacked</translation>
    </message>
    <message>
      <source>Selected</source>
      <translation>Selezionati</translation>
    </message>
    <message>
      <source>Send to {0} tab</source>
      <translation>Invia alla scheda {0}</translation>
    </message>
    <message>
      <source>Session</source>
      <translation>Sessione</translation>
    </message>
    <message>
      <source>Session Files</source>
      <translation>File sessione</translation>
    </message>
    <message>
      <source>Session Info</source>
      <translation>Info sessione</translation>
    </message>
    <message>
      <source>Session loaded</source>
      <translation>Sessione caricata</translation>
    </message>
    <message>
      <source>Session saved</source>
      <translation>Sessione salvata</translation>
    </message>
    <message>
      <source>Set Reference Frame</source>
      <translation>Imposta Frame Riferimento</translation>
    </message>
    <message>
      <source>Set Session Tag</source>
      <translation>Imposta Tag Sessione</translation>
    </message>
    <message>
      <source>Set Session Tag...</source>
      <translation>Imposta Tag Sessione...</translation>
    </message>
    <message>
      <source>Set Stacking Directory &amp; Sigma Clipping</source>
      <translation>Imposta Cartella Stacking e Sigma Clipping</translation>
    </message>
    <message>
      <source>Set as reference frame</source>
      <translation>Imposta come frame di riferimento</translation>
    </message>
    <message>
      <source>Sharpness</source>
      <translation>Nitidezza</translation>
    </message>
    <message>
      <source>Show preview</source>
      <translation>Mostra anteprima</translation>
    </message>
    <message>
      <source>Show the Stacking Suite log window</source>
      <translation>Mostra la finestra log della Suite Stacking</translation>
    </message>
    <message>
      <source>Sigma Clipping</source>
      <translation>Sigma Clipping</translation>
    </message>
    <message>
      <source>Sigma High</source>
      <translation>Sigma Alto</translation>
    </message>
    <message>
      <source>Sigma Low</source>
      <translation>Sigma Basso</translation>
    </message>
    <message>
      <source>Sigma thresholds:</source>
      <translation>Soglie Sigma:</translation>
    </message>
    <message>
      <source>Simple</source>
      <translation>Semplice</translation>
    </message>
    <message>
      <source>Simple Average (No Rejection)</source>
      <translation>Media Semplice (Nessun Rigetto)</translation>
    </message>
    <message>
      <source>Simple Median (No Rejection)</source>
      <translation>Mediana Semplice (Nessun Rigetto)</translation>
    </message>
    <message>
      <source>Size: {0}</source>
      <translation>Dimensione: {0}</translation>
    </message>
    <message>
      <source>Size: {0} | Session: {1}</source>
      <translation>Dimensione: {0} | Sessione: {1}</translation>
    </message>
    <message>
      <source>Size: {0}, Temp: {1}°C, Date: {2}</source>
      <translation>Dimensione: {0}, Temp: {1}°C, Data: {2}</translation>
    </message>
    <message>
      <source>Skip Normal Integration (MFDeconv only)</source>
      <translation>Salta Integrazione Normale (solo MFDeconv)</translation>
    </message>
    <message>
      <source>Skip file</source>
      <translation>Salta file</translation>
    </message>
    <message>
      <source>Skip if strength &lt;</source>
      <translation>Salta se forza &lt;</translation>
    </message>
    <message>
      <source>Skip registration/alignment and use Maximum-Intensity projection for star trails</source>
      <translation>Salta registrazione/allineamento e usa proiezione Massima Intensità per star trail</translation>
    </message>
    <message>
      <source>Smoothness</source>
      <translation>Morbidezza</translation>
    </message>
    <message>
      <source>Solve downsample:</source>
      <translation>Sottocampionamento risoluzione:</translation>
    </message>
    <message>
      <source>Sort</source>
      <translation>Ordina</translation>
    </message>
    <message>
      <source>Sort by Quality</source>
      <translation>Ordina per Qualità</translation>
    </message>
    <message>
      <source>Spline</source>
      <translation>Spline</translation>
    </message>
    <message>
      <source>Spline-3</source>
      <translation>Spline-3</translation>
    </message>
    <message>
      <source>Spline-5</source>
      <translation>Spline-5</translation>
    </message>
    <message>
      <source>Split Group</source>
      <translation>Dividi Gruppo</translation>
    </message>
    <message>
      <source>Split dual-band OSC before integration</source>
      <translation>Separa OSC dual-band prima dell'integrazione</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Quadrato</translation>
    </message>
    <message>
      <source>Square (pixfrac)</source>
      <translation>Quadrato (pixfrac)</translation>
    </message>
    <message>
      <source>Stack</source>
      <translation>Stack</translation>
    </message>
    <message>
      <source>Stack Method:</source>
      <translation>Metodo Stack:</translation>
    </message>
    <message>
      <source>Stack Mode:</source>
      <translation>Modalità Stack:</translation>
    </message>
    <message>
      <source>Stacking &amp; drizzle (if enabled)…</source>
      <translation>Stacking &amp; drizzle (se abilitato)…</translation>
    </message>
    <message>
      <source>Stacking Complete</source>
      <translation>Stacking Completato</translation>
    </message>
    <message>
      <source>Stacking Directory:</source>
      <translation>Cartella Stacking:</translation>
    </message>
    <message>
      <source>Stacking Log</source>
      <translation>Log Stacking</translation>
    </message>
    <message>
      <source>Stacking Settings</source>
      <translation>Impostazioni Stacking</translation>
    </message>
    <message>
      <source>Stacking Suite</source>
      <translation>Suite Stacking</translation>
    </message>
    <message>
      <source>Stacking cancelled by user</source>
      <translation>Stacking annullato dall'utente</translation>
    </message>
    <message>
      <source>Stacking complete!</source>
      <translation>Stacking completato!</translation>
    </message>
    <message>
      <source>Stacking...</source>
      <translation>Stacking...</translation>
    </message>
    <message>
      <source>Star Detection Threshold:</source>
      <translation>Soglia Rilevamento Stelle:</translation>
    </message>
    <message>
      <source>Star Removal for Comet</source>
      <translation>Rimozione Stelle per Cometa</translation>
    </message>
    <message>
      <source>Star Trail Mode</source>
      <translation>Modalità Scie Stellari</translation>
    </message>
    <message>
      <source>Star detect σ:</source>
      <translation>σ rilevamento stelle:</translation>
    </message>
    <message>
      <source>Star detection threshold in σ above background. Lower = more stars (faster saturation, more false positives); higher = fewer stars.</source>
      <translation>Soglia rilevamento stelle in σ sopra lo sfondo. Più bassa = più stelle (saturazione più veloce, più falsi positivi); più alta = meno stelle.</translation>
    </message>
    <message>
      <source>Star guards:</source>
      <translation>Guardie stelle:</translation>
    </message>
    <message>
      <source>Star saturation</source>
      <translation>Saturazione stelle</translation>
    </message>
    <message>
      <source>StarNet</source>
      <translation>StarNet</translation>
    </message>
    <message>
      <source>Stars</source>
      <translation>Stelle</translation>
    </message>
    <message>
      <source>Stars Weight</source>
      <translation>Peso stelle</translation>
    </message>
    <message>
      <source>Stars detected</source>
      <translation>Stelle rilevate</translation>
    </message>
    <message>
      <source>Start the stacking process</source>
      <translation>Avvia il processo di stacking</translation>
    </message>
    <message>
      <source>Starting Master Dark Creation...</source>
      <translation>Avvio Creazione Master Dark...</translation>
    </message>
    <message>
      <source>Starting Master Flat Creation...</source>
      <translation>Avvio Creazione Master Flat...</translation>
    </message>
    <message>
      <source>Starting integration for group '{0}' with {1} files.</source>
      <translation>Avvio integrazione per gruppo '{0}' con {1} file.</translation>
    </message>
    <message>
      <source>Status</source>
      <translation>Stato</translation>
    </message>
    <message>
      <source>Status: {0}</source>
      <translation>Stato: {0}</translation>
    </message>
    <message>
      <source>Std Dev</source>
      <translation>Dev. Std.</translation>
    </message>
    <message>
      <source>Std-devs from median; higher = more lenient.</source>
      <translation>Dev. std dalla mediana; più alto = più permissivo.</translation>
    </message>
    <message>
      <source>Stellar Alignment</source>
      <translation>Allineamento Stellare</translation>
    </message>
    <message>
      <source>Step 1: Install NVIDIA CUDA Toolkit 12.x</source>
      <translation>Passo 1: Installa NVIDIA CUDA Toolkit 12.x</translation>
    </message>
    <message>
      <source>Step 2: Install PyTorch with CUDA (click button below)</source>
      <translation>Passo 2: Installa PyTorch con CUDA (clicca bottone sotto)</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Ferma</translation>
    </message>
    <message>
      <source>Sub-pixel accuracy</source>
      <translation>Precisione sub-pixel</translation>
    </message>
    <message>
      <source>Subpixel Alignment</source>
      <translation>Allineamento Subpixel</translation>
    </message>
    <message>
      <source>Subtract (additive)</source>
      <translation>Sottrai (additivo)</translation>
    </message>
    <message>
      <source>Subtract comet</source>
      <translation>Sottrai cometa</translation>
    </message>
    <message>
      <source>Subtract stars</source>
      <translation>Sottrai stelle</translation>
    </message>
    <message>
      <source>Successfully stacked {0} frames</source>
      <translation>Stacking completato di {0} frame</translation>
    </message>
    <message>
      <source>Suffix</source>
      <translation>Suffisso</translation>
    </message>
    <message>
      <source>Sum</source>
      <translation>Somma</translation>
    </message>
    <message>
      <source>Super Pixel</source>
      <translation>Super Pixel</translation>
    </message>
    <message>
      <source>Super Resolution</source>
      <translation>Super Risoluzione</translation>
    </message>
    <message>
      <source>Super-resolution scale factor r (integer ≥2).</source>
      <translation>Fattore scala super-risoluzione r (intero ≥2).</translation>
    </message>
    <message>
      <source>Supported Files (*.fits *.fit *.fz *.fz *.fits.gz *.fit.gz *.tiff *.tif *.png *.jpg *.jpeg *.cr2 *.cr3 *.nef *.arw *.dng *.raf *.orf *.rw2 *.pef *.xisf)</source>
      <translation>File Supportati (*.fits *.fit *.fz *.fz *.fits.gz *.fit.gz *.tiff *.tif *.png *.jpg *.jpeg *.cr2 *.cr3 *.nef *.arw *.dng *.raf *.orf *.rw2 *.pef *.xisf)</translation>
    </message>
    <message>
      <source>TELESCOP</source>
      <translation>Telescopio</translation>
    </message>
    <message>
      <source>TIFF</source>
      <translation>TIFF</translation>
    </message>
    <message>
      <source>TIFF (*.tif);;PNG (*.png);;JPEG (*.jpg *.jpeg);;FITS (*.fits);;XISF (*.xisf)</source>
      <translation>TIFF (*.tif);;PNG (*.png);;JPEG (*.jpg *.jpeg);;FITS (*.fits);;XISF (*.xisf)</translation>
    </message>
    <message>
      <source>Target Name</source>
      <translation>Nome target</translation>
    </message>
    <message>
      <source>Telescope</source>
      <translation>Telescopio</translation>
    </message>
    <message>
      <source>Temperature</source>
      <translation>Temperatura</translation>
    </message>
    <message>
      <source>Temperature Tolerance (°C):</source>
      <translation>Tolleranza Temperatura (°C):</translation>
    </message>
    <message>
      <source>Template Matching</source>
      <translation>Template Matching</translation>
    </message>
    <message>
      <source>There are no files to convert.</source>
      <translation>Non ci sono file da convertire.</translation>
    </message>
    <message>
      <source>This app is running on Python {0}.{1}. GPU acceleration requires Python 3.10, 3.11, or 3.12.</source>
      <translation>Questa app gira su Python {0}.{1}. L'accelerazione GPU richiede Python 3.10, 3.11, o 3.12.</translation>
    </message>
    <message>
      <source>Thread Count:</source>
      <translation>Conteggio Thread:</translation>
    </message>
    <message>
      <source>Time</source>
      <translation>Ora</translation>
    </message>
    <message>
      <source>Timeout per frame (s):</source>
      <translation>Timeout per frame (s):</translation>
    </message>
    <message>
      <source>Too few matching stars</source>
      <translation>Troppe poche stelle corrispondenti</translation>
    </message>
    <message>
      <source>Tool:</source>
      <translation>Strumento:</translation>
    </message>
    <message>
      <source>Total</source>
      <translation>Totale</translation>
    </message>
    <message>
      <source>Track nucleus</source>
      <translation>Traccia nucleo</translation>
    </message>
    <message>
      <source>Track stars</source>
      <translation>Traccia stelle</translation>
    </message>
    <message>
      <source>Transform calculation failed</source>
      <translation>Calcolo trasformazione fallito</translation>
    </message>
    <message>
      <source>Transform-based (fast)</source>
      <translation>Basato su Trasformazione (veloce)</translation>
    </message>
    <message>
      <source>Transforming images...</source>
      <translation>Trasformazione immagini...</translation>
    </message>
    <message>
      <source>Triangle Match Tolerance:</source>
      <translation>Tolleranza Match Triangolo:</translation>
    </message>
    <message>
      <source>Triangle Similarity</source>
      <translation>Similarità triangoli</translation>
    </message>
    <message>
      <source>Trim fraction:</source>
      <translation>Frazione taglio:</translation>
    </message>
    <message>
      <source>Trimmed Mean</source>
      <translation>Media Tagliata</translation>
    </message>
    <message>
      <source>Turbo</source>
      <translation>Turbo</translation>
    </message>
    <message>
      <source>Turn Those Darks Into Master Darks</source>
      <translation>Trasforma Quei Dark in Master Dark</translation>
    </message>
    <message>
      <source>Turn Those Flats Into Master Flats</source>
      <translation>Trasforma Quei Flat in Master Flat</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Tipo</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Sconosciuto</translation>
    </message>
    <message>
      <source>Unmark Reference</source>
      <translation>Rimuovi Riferimento</translation>
    </message>
    <message>
      <source>Unsaved session</source>
      <translation>Sessione non salvata</translation>
    </message>
    <message>
      <source>Unsupported Python Version</source>
      <translation>Versione Python Non Supportata</translation>
    </message>
    <message>
      <source>Unsupported image ndim={0} for {1}</source>
      <translation>ndim immagine non supportato={0} per {1}</translation>
    </message>
    <message>
      <source>Update clip (κ):</source>
      <translation>Clip aggiornamento (κ):</translation>
    </message>
    <message>
      <source>Update preview automatically</source>
      <translation>Aggiorna anteprima automaticamente</translation>
    </message>
    <message>
      <source>Use GPU acceleration</source>
      <translation>Usa accelerazione GPU</translation>
    </message>
    <message>
      <source>Use Master Bias</source>
      <translation>Usa Master Bias</translation>
    </message>
    <message>
      <source>Use Master Dark</source>
      <translation>Usa Master Dark</translation>
    </message>
    <message>
      <source>Use Master Flat</source>
      <translation>Usa Master Flat</translation>
    </message>
    <message>
      <source>Use defect map</source>
      <translation>Usa mappa difetti</translation>
    </message>
    <message>
      <source>Use hardware acceleration if available</source>
      <translation>Usa accelerazione hardware se disponibile</translation>
    </message>
    <message>
      <source>Use memory mapping</source>
      <translation>Usa memory mapping</translation>
    </message>
    <message>
      <source>Use memory-mapped files</source>
      <translation>Usa file mappati in memoria</translation>
    </message>
    <message>
      <source>Use reference frame from this list</source>
      <translation>Usa frame di riferimento da questa lista</translation>
    </message>
    <message>
      <source>User selected a new reference frame: {0}</source>
      <translation>Utente ha selezionato nuovo frame riferimento: {0}</translation>
    </message>
    <message>
      <source>Using GPU for tile {0} with algo {1}</source>
      <translation>Uso GPU per tile {0} con algo {1}</translation>
    </message>
    <message>
      <source>Using Master Bias (for flats when needed): {0}</source>
      <translation>Uso Master Bias (per flat quando necessario): {0}</translation>
    </message>
    <message>
      <source>Using Master Bias: {0}</source>
      <translation>Uso Master Bias: {0}</translation>
    </message>
    <message>
      <source>Using {0} kernel drizzle ({1}).</source>
      <translation>Uso drizzle kernel {0} ({1}).</translation>
    </message>
    <message>
      <source>VNG</source>
      <translation>VNG</translation>
    </message>
    <message>
      <source>VarMap floor (log10):</source>
      <translation>Floor VarMap (log10):</translation>
    </message>
    <message>
      <source>VarMap sample stride:</source>
      <translation>Passo campione VarMap:</translation>
    </message>
    <message>
      <source>VarMap smooth σ:</source>
      <translation>VarMap σ smooth:</translation>
    </message>
    <message>
      <source>Verbose logging</source>
      <translation>Logging dettagliato</translation>
    </message>
    <message>
      <source>View frame header</source>
      <translation>Visualizza header frame</translation>
    </message>
    <message>
      <source>View frame info</source>
      <translation>Visualizza info frame</translation>
    </message>
    <message>
      <source>Visit the NVIDIA CUDA Downloads page in your browser to install CUDA Toolkit 12.x:

https://developer.nvidia.com/cuda-downloads</source>
      <translation>Visita la pagina NVIDIA CUDA Downloads nel browser per installare CUDA Toolkit 12.x:

https://developer.nvidia.com/cuda-downloads</translation>
    </message>
    <message>
      <source>W:</source>
      <translation>W:</translation>
    </message>
    <message>
      <source>WCS Alignment</source>
      <translation>Allineamento WCS</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Avviso</translation>
    </message>
    <message>
      <source>Warning: Could not read dimensions for {0}: {1}</source>
      <translation>Avviso: Impossibile leggere dimensioni per {0}: {1}</translation>
    </message>
    <message>
      <source>Weight Radius:</source>
      <translation>Raggio Peso:</translation>
    </message>
    <message>
      <source>Weight keyword</source>
      <translation>Keyword peso</translation>
    </message>
    <message>
      <source>Weight:</source>
      <translation>Peso:</translation>
    </message>
    <message>
      <source>Weighted Average</source>
      <translation>Media Pesata</translation>
    </message>
    <message>
      <source>Weighted Windsorized Sigma Clipping</source>
      <translation>Sigma Clipping Ponderato Windsorizzato</translation>
    </message>
    <message>
      <source>Weighting</source>
      <translation>Peso</translation>
    </message>
    <message>
      <source>When checked, once calibration finishes the app will switch to Image Registration and run 'Register and Integrate Images' automatically.</source>
      <translation>Quando selezionato, una volta finita la calibrazione l'app passerà a Registrazione Immagini ed eseguirà 'Registra e Integra Immagini' automaticamente.</translation>
    </message>
    <message>
      <source>Width</source>
      <translation>Larghezza</translation>
    </message>
    <message>
      <source>Winsorized Average</source>
      <translation>Media Winsorizzata</translation>
    </message>
    <message>
      <source>Winsorized Sigma</source>
      <translation>Sigma Winsorizzato</translation>
    </message>
    <message>
      <source>Winsorized Sigma Clipping</source>
      <translation>Winsorized Sigma Clipping</translation>
    </message>
    <message>
      <source>Worst</source>
      <translation>Peggiore</translation>
    </message>
    <message>
      <source>Writing output...</source>
      <translation>Scrittura output...</translation>
    </message>
    <message>
      <source>XBINNING</source>
      <translation>Binning X</translation>
    </message>
    <message>
      <source>XISF</source>
      <translation>XISF</translation>
    </message>
    <message>
      <source>YBINNING</source>
      <translation>Binning Y</translation>
    </message>
    <message>
      <source>[Stacking] tile {0}/{1} ts.shape={2}, N={3}, C={4}</source>
      <translation>[Stacking] tile {0}/{1} ts.shape={2}, N={3}, C={4}</translation>
    </message>
    <message>
      <source>bias</source>
      <translation>bias</translation>
    </message>
    <message>
      <source>circular</source>
      <translation>circolare</translation>
    </message>
    <message>
      <source>color</source>
      <translation>colore</translation>
    </message>
    <message>
      <source>compass Reference PA: (unknown)</source>
      <translation>compass PA Riferimento: (sconosciuto)</translation>
    </message>
    <message>
      <source>compass Reference PA: {0:.2f}°</source>
      <translation>compass PA Riferimento: {0:.2f}°</translation>
    </message>
    <message>
      <source>compass Tree snapshot → groups: {0}, leaves seen: {1}, paths kept: {2}</source>
      <translation>compass Snapshot albero → gruppi: {0}, foglie viste: {1}, percorsi mantenuti: {2}</translation>
    </message>
    <message>
      <source>dark</source>
      <translation>dark</translation>
    </message>
    <message>
      <source>darkflat</source>
      <translation>darkflat</translation>
    </message>
    <message>
      <source>e.g. M31</source>
      <translation>es. M31</translation>
    </message>
    <message>
      <source>flat</source>
      <translation>flat</translation>
    </message>
    <message>
      <source>folder change</source>
      <translation>cambio cartella</translation>
    </message>
    <message>
      <source>gaussian</source>
      <translation>gaussiano</translation>
    </message>
    <message>
      <source>light</source>
      <translation>light</translation>
    </message>
    <message>
      <source>log10 of variance floor (DN²). -8 ≡ 1e-8.</source>
      <translation>log10 del floor varianza (DN²). -8 ≡ 1e-8.</translation>
    </message>
    <message>
      <source>mono</source>
      <translation>mono</translation>
    </message>
    <message>
      <source>naive (square, pixfrac≈1)</source>
      <translation>naive (quadrato, pixfrac≈1)</translation>
    </message>
    <message>
      <source>precision → {0}</source>
      <translation>precisione → {0}</translation>
    </message>
    <message>
      <source>square</source>
      <translation>quadrato</translation>
    </message>
    <message>
      <source>{0:g}s</source>
      <translation>{0:g}s</translation>
    </message>
    <message>
      <source>{0} file</source>
      <translation>{0} file</translation>
    </message>
    <message>
      <source>{0} file · {1}</source>
      <translation>{0} file · {1}</translation>
    </message>
    <message>
      <source>{0} file(s)</source>
      <translation>{0} file</translation>
    </message>
    <message>
      <source>{0} files · {1}</source>
      <translation>{0} file · {1}</translation>
    </message>
    <message>
      <source>{0} files, {1:.0f}s–{2:.0f}s</source>
      <translation>{0} file, {1:.0f}s–{2:.0f}s</translation>
    </message>
    <message>
      <source>{0} {1}: {2}</source>
      <translation>{0} {1}: {2}</translation>
    </message>
    <message>
      <source>{0}: {1} frame(s)</source>
      <translation>{0}: {1} frame</translation>
    </message>
    <message>
      <source>{0}Alignment summary: {1} succeeded, {2} rejected.</source>
      <translation>{0}Riepilogo allineamento: {1} riusciti, {2} rifiutati.</translation>
    </message>
    <message>
      <source>{0}h {1}m {2}s</source>
      <translation>{0}h {1}m {2}s</translation>
    </message>
    <message>
      <source>{0}m {1}s</source>
      <translation>{0}m {1}s</translation>
    </message>
    <message>
      <source>{0}s</source>
      <translation>{0}s</translation>
    </message>
    <message>
      <source>{0}s ({1}) — tile {2}/{3} y:{4}-{5} x:{6}-{7}</source>
      <translation>{0}s ({1}) — tile {2}/{3} y:{4}-{5} x:{6}-{7}</translation>
    </message>
    <message>
      <source>κ (kappa) limits how big each multiplicative update can be per iteration.
• κ = 1.0 → no change (1×); larger κ allows bigger step sizes.
• Lower values = gentler, safer updates; higher values = faster but riskier.
Typical: 1.05–1.5 for conservative, ~2 for punchier updates.</source>
      <translation>κ (kappa) limita quanto grande può essere ogni aggiornamento moltiplicativo per iterazione.
• κ = 1.0 → nessun cambiamento (1×); κ più grande permette passi più grandi.
• Valori bassi = aggiornamenti più delicati e sicuri; valori alti = più veloci ma rischiosi.
Tipico: 1.05–1.5 per conservativo, ~2 per aggiornamenti più incisivi.</translation>
    </message>
    <message>
      <source>ρ (loss):</source>
      <translation>ρ (loss):</translation>
    </message>
    <message>
      <source>‘Luma’ deconvolves luminance only; ‘PerChannel’ runs on RGB independently.</source>
      <translation>‘Luma’ deconvolve solo luminanza; ‘PerChannel’ lavora su RGB indipendentemente.</translation>
    </message>
    <message>
      <source>• Hardware acceleration: {0}</source>
      <translation>• Accelerazione hardware: {0}</translation>
    </message>
    <message>
      <source>• Internal precision: {0}</source>
      <translation>• Precisione interna: {0}</translation>
    </message>
    <message>
      <source>• {0}  |  session: {1}  →  {2} files, {3}</source>
      <translation>• {0}  |  sessione: {1}  →  {2} file, {3}</translation>
    </message>
    <message>
      <source>• {0}  →  {1} files, {2}</source>
      <translation>• {0}  →  {1} file, {2}</translation>
    </message>
    <message>
      <source>• {0}: {1} stacked{2}</source>
      <translation>• {0}: {1} stackati{2}</translation>
    </message>
    <message>
      <source>ℹ️ CFA Drizzle kept despite low frame count (you chose No).</source>
      <translation>ℹ️ CFA Drizzle mantenuto nonostante conteggio frame basso (hai scelto No).</translation>
    </message>
    <message>
      <source>ℹ️ Could not resolve comet seed to reference (no matrix for that frame).</source>
      <translation>ℹ️ Impossibile risolvere seed cometa a riferimento (nessuna matrice per quel frame).</translation>
    </message>
    <message>
      <source>ℹ️ No dual-band frames detected or split.</source>
      <translation>ℹ️ Nessun frame dual-band rilevato o diviso.</translation>
    </message>
    <message>
      <source>ℹ️ Registration already in progress; auto-run skipped.</source>
      <translation>ℹ️ Registrazione già in corso; esecuzione auto saltata.</translation>
    </message>
    <message>
      <source>ℹ️ Single group spread {0:.3f}% &gt; tol {1:.2f}% → will normalize.</source>
      <translation>ℹ️ Spread gruppo singolo {0:.3f}% &gt; tol {1:.2f}% → normalizzerà.</translation>
    </message>
    <message>
      <source>ℹ️ Skipping rejection map save for '{0}' (drizzle disabled).</source>
      <translation>ℹ️ Salvataggio mappa rifiuto saltato per '{0}' (drizzle disabilitato).</translation>
    </message>
    <message>
      <source>ℹ️ This flat group: Auto-Select is OFF and no override set → No Calibration.</source>
      <translation>ℹ️ Questo gruppo flat: Auto-Selezione OFF e nessun override impostato → Nessuna Calibrazione.</translation>
    </message>
    <message>
      <source>ℹ️ This flat group: no matching Master Dark (size) — proceeding without subtraction.</source>
      <translation>ℹ️ Questo gruppo flat: nessun Master Dark corrispondente (dimensione) — procedo senza sottrazione.</translation>
    </message>
    <message>
      <source>ℹ️ This flat group: override = No Calibration.</source>
      <translation>ℹ️ Questo gruppo flat: override = Nessuna Calibrazione.</translation>
    </message>
    <message>
      <source>ℹ️ Using in-memory REF_SHAPE fallback: {0}×{1}</source>
      <translation>ℹ️ Uso fallback REF_SHAPE in memoria: {0}×{1}</translation>
    </message>
    <message>
      <source>ℹ️ {0} frame(s) had zero/NaN preview medians; using neutral scale for those.</source>
      <translation>ℹ️ {0} frame avevano mediane anteprima zero/NaN; uso scala neutra per quelli.</translation>
    </message>
    <message>
      <source>↻ 180° rotate (PA Δ≈180°): {0}</source>
      <translation>↻ Rotazione 180° (PA Δ≈180°): {0}</translation>
    </message>
    <message>
      <source>⏭️ Normal integration suppressed (MFDeconv-only run).</source>
      <translation>⏭️ Integrazione normale soppressa (esecuzione solo MFDeconv).</translation>
    </message>
    <message>
      <source>⏭️ Pixel-scale normalize skipped: single-group policy (no header reads).</source>
      <translation>⏭️ Normalizzazione pixel-scale saltata: policy gruppo singolo (nessuna lettura header).</translation>
    </message>
    <message>
      <source>⏭️ Pixel-scale normalize skipped: spread ≤ {0:.2f}% (single group).</source>
      <translation>⏭️ Normalizzazione pixel-scale saltata: spread ≤ {0:.2f}% (gruppo singolo).</translation>
    </message>
    <message>
      <source>⏳ Loading…</source>
      <translation>⏳ Caricamento…</translation>
    </message>
    <message>
      <source>⏳ Please wait…</source>
      <translation>⏳ Attendere prego…</translation>
    </message>
    <message>
      <source>⏳ Registering…</source>
      <translation>⏳ Registrazione…</translation>
    </message>
    <message>
      <source>⏸ Another job is running; ignoring extra click.</source>
      <translation>⏸ Un altro job in esecuzione; clic extra ignorato.</translation>
    </message>
    <message>
      <source>⏸ Registration already running; ignoring extra click.</source>
      <translation>⏸ Registrazione già in corso; clic extra ignorato.</translation>
    </message>
    <message>
      <source>▶️ Starting tile processing for group '{0}' ({1}s, {2}, session '{3}')</source>
      <translation>▶️ Avvio elaborazione tile per gruppo '{0}' ({1}s, {2}, sessione '{3}')</translation>
    </message>
    <message>
      <source>★★ Star-Trail Mode ★★ (Max-Value Stack)</source>
      <translation>★★ Modalità Star-Trail ★★ (Stack Valore Max)</translation>
    </message>
    <message>
      <source>⚖️ Computing frame weights…</source>
      <translation>⚖️ Calcolo pesi frame…</translation>
    </message>
    <message>
      <source>⚙️ Auto: starting registration &amp; integration…</source>
      <translation>⚙️ Auto: avvio registrazione &amp; integrazione…</translation>
    </message>
    <message>
      <source>⚙️ MFDeconv engine: {0}</source>
      <translation>⚙️ Motore MFDeconv: {0}</translation>
    </message>
    <message>
      <source>⚙️ Normalizing {0} flats by per-frame medians (central patch).</source>
      <translation>⚙️ Normalizzazione {0} flat per mediane per-frame (patch centrale).</translation>
    </message>
    <message>
      <source>⚙️ {0} reducer for flats — {1} ({2})</source>
      <translation>⚙️ Riduttore {0} per flat — {1} ({2})</translation>
    </message>
    <message>
      <source>⚙️ {0} selected for {1} frames (channels={2})</source>
      <translation>⚙️ {0} selezionato per {1} frame (canali={2})</translation>
    </message>
    <message>
      <source>⚠️ (MF) Auto-crop of output failed: {0}</source>
      <translation>⚠️ (MF) Auto-ritaglio output fallito: {0}</translation>
    </message>
    <message>
      <source>⚠️ (MF) Global crop failed: {0}</source>
      <translation>⚠️ (MF) Ritaglio globale fallito: {0}</translation>
    </message>
    <message>
      <source>⚠️ Auto register/integrate failed: {0}</source>
      <translation>⚠️ Registrazione/integrazione auto fallita: {0}</translation>
    </message>
    <message>
      <source>⚠️ CFA Drizzle: low-count fallback → using Edge-Aware Interpolation for this run.</source>
      <translation>⚠️ CFA Drizzle: fallback conteggio basso → uso Interpolazione Edge-Aware per questa esecuzione.</translation>
    </message>
    <message>
      <source>⚠️ Cannot load {0}; skipping.</source>
      <translation>⚠️ Impossibile caricare {0}; saltato.</translation>
    </message>
    <message>
      <source>⚠️ Cannot read image size for {0}: {1}</source>
      <translation>⚠️ Impossibile leggere dimensione immagine per {0}: {1}</translation>
    </message>
    <message>
      <source>⚠️ Comet seed resolve failed: {0}</source>
      <translation>⚠️ Risoluzione seed cometa fallita: {0}</translation>
    </message>
    <message>
      <source>⚠️ Comet star removal pre-process aborted: {0}</source>
      <translation>⚠️ Pre-elaborazione rimozione stelle cometa interrotta: {0}</translation>
    </message>
    <message>
      <source>⚠️ Could not ensure subfolders in '{0}': {1}</source>
      <translation>⚠️ Impossibile garantire sottocartelle in '{0}': {1}</translation>
    </message>
    <message>
      <source>⚠️ Could not load Master Bias: {0}</source>
      <translation>⚠️ Impossibile caricare Master Bias: {0}</translation>
    </message>
    <message>
      <source>⚠️ Could not load reference '{0}' for comet stack.</source>
      <translation>⚠️ Impossibile caricare riferimento '{0}' per stack cometa.</translation>
    </message>
    <message>
      <source>⚠️ Could not load reference '{0}' for group '{1}'.</source>
      <translation>⚠️ Impossibile caricare riferimento '{0}' per gruppo '{1}'.</translation>
    </message>
    <message>
      <source>⚠️ Could not load reference '{0}', skipping group.</source>
      <translation>⚠️ Impossibile caricare riferimento '{0}', gruppo saltato.</translation>
    </message>
    <message>
      <source>⚠️ Could not load {0} to determine drizzle shape!</source>
      <translation>⚠️ Impossibile caricare {0} per determinare forma drizzle!</translation>
    </message>
    <message>
      <source>⚠️ Could not read XISF {0}: {1}; treating as generic image</source>
      <translation>⚠️ Impossibile leggere XISF {0}: {1}; trattato come immagine generica</translation>
    </message>
    <message>
      <source>⚠️ Degenerate tile shape {0} at tile {1} [y:{2}:{3} x:{4}:{5}] – using CPU for this tile.</source>
      <translation>⚠️ Forma tile degenerata {0} a tile {1} [y:{2}:{3} x:{4}:{5}] – uso CPU per questa tile.</translation>
    </message>
    <message>
      <source>⚠️ ERROR: Could not parse {0}</source>
      <translation>⚠️ ERRORE: Impossibile parsare {0}</translation>
    </message>
    <message>
      <source>⚠️ Error normalizing {0}: {1}</source>
      <translation>⚠️ Errore normalizzazione {0}: {1}</translation>
    </message>
    <message>
      <source>⚠️ Error previewing {0}: {1}</source>
      <translation>⚠️ Errore anteprima {0}: {1}</translation>
    </message>
    <message>
      <source>⚠️ Error: No alignment data available.</source>
      <translation>⚠️ Errore: Nessun dato allineamento disponibile.</translation>
    </message>
    <message>
      <source>⚠️ Failed to load {0}; skipping</source>
      <translation>⚠️ Caricamento {0} fallito; saltato</translation>
    </message>
    <message>
      <source>⚠️ Failed to open images (memmap): {0}</source>
      <translation>⚠️ Apertura immagini fallita (memmap): {0}</translation>
    </message>
    <message>
      <source>⚠️ Failed to read {0} – skipping</source>
      <translation>⚠️ Lettura {0} fallita – saltato</translation>
    </message>
    <message>
      <source>⚠️ Failed to save transform file: {0}</source>
      <translation>⚠️ Salvataggio file trasformazione fallito: {0}</translation>
    </message>
    <message>
      <source>⚠️ Failed to write SASD v2 ({0}); writing affine-only fallback.</source>
      <translation>⚠️ Scrittura SASD v2 fallita ({0}); scrittura fallback solo-affine.</translation>
    </message>
    <message>
      <source>⚠️ File not found: {0}, skipping.</source>
      <translation>⚠️ File non trovato: {0}, saltato.</translation>
    </message>
    <message>
      <source>⚠️ GPU rejection failed on tile {0}/{1} shape={2}: {3} – falling back to CPU for this and remaining tiles.</source>
      <translation>⚠️ Rifiuto GPU fallito su tile {0}/{1} shape={2}: {3} – fallback a CPU per questa e le tile rimanenti.</translation>
    </message>
    <message>
      <source>⚠️ Global crop (mask-based) failed: {0}</source>
      <translation>⚠️ Ritaglio globale (basato su maschera) fallito: {0}</translation>
    </message>
    <message>
      <source>⚠️ Group '{0}' does not have enough frames to drizzle.</source>
      <translation>⚠️ Gruppo '{0}' non ha abbastanza frame per drizzle.</translation>
    </message>
    <message>
      <source>⚠️ Group '{0}' does not have enough frames to stack.</source>
      <translation>⚠️ Gruppo '{0}' non ha abbastanza frame per stackare.</translation>
    </message>
    <message>
      <source>⚠️ Image registration failed: {0}</source>
      <translation>⚠️ Registrazione immagine fallita: {0}</translation>
    </message>
    <message>
      <source>⚠️ MEF save failed ({0}); falling back to single-HDU save.</source>
      <translation>⚠️ Salvataggio MEF fallito ({0}); fallback a salvataggio HDU singolo.</translation>
    </message>
    <message>
      <source>⚠️ MFDeconv engine import failed ({0}); falling back to Normal.</source>
      <translation>⚠️ Importazione motore MFDeconv fallita ({0}); fallback a Normale.</translation>
    </message>
    <message>
      <source>⚠️ Missing REF_SHAPE in SASD; cannot drizzle.</source>
      <translation>⚠️ REF_SHAPE mancante in SASD; drizzle impossibile.</translation>
    </message>
    <message>
      <source>⚠️ No aligned frames available for MF deconvolution.</source>
      <translation>⚠️ Nessun frame allineato disponibile per deconvoluzione MF.</translation>
    </message>
    <message>
      <source>⚠️ No calibrated lights available for star trails.</source>
      <translation>⚠️ Nessun light calibrato disponibile per scie stellari.</translation>
    </message>
    <message>
      <source>⚠️ No data for {0}</source>
      <translation>⚠️ Nessun dato per {0}</translation>
    </message>
    <message>
      <source>⚠️ No eligible dark groups found to stack.</source>
      <translation>⚠️ Nessun gruppo dark eleggibile trovato per stack.</translation>
    </message>
    <message>
      <source>⚠️ No eligible flat groups found to stack.</source>
      <translation>⚠️ Nessun gruppo flat eleggibile trovato per stack.</translation>
    </message>
    <message>
      <source>⚠️ No frames could be measured!</source>
      <translation>⚠️ Nessun frame misurabile!</translation>
    </message>
    <message>
      <source>⚠️ No frames found in the registration tree!</source>
      <translation>⚠️ Nessun frame trovato nell'albero registrazione!</translation>
    </message>
    <message>
      <source>⚠️ No frames to stack; aborting.</source>
      <translation>⚠️ Nessun frame da stackare; interruzione.</translation>
    </message>
    <message>
      <source>⚠️ No leaf files selected to retag.</source>
      <translation>⚠️ Nessun file foglia selezionato per ri-taggare.</translation>
    </message>
    <message>
      <source>⚠️ No light files to register!</source>
      <translation>⚠️ Nessun file luce da registrare!</translation>
    </message>
    <message>
      <source>⚠️ No light frames available for stacking!</source>
      <translation>⚠️ Nessun frame luce disponibile per stacking!</translation>
    </message>
    <message>
      <source>⚠️ No registered images found!</source>
      <translation>⚠️ Nessuna immagine registrata trovata!</translation>
    </message>
    <message>
      <source>⚠️ No usable transform for {0} – skipping</source>
      <translation>⚠️ Nessuna trasformazione utilizzabile per {0} – saltato</translation>
    </message>
    <message>
      <source>⚠️ No valid frames to compute reference median; aborting star-trail.</source>
      <translation>⚠️ Nessun frame valido per calcolare mediana riferimento; scie stellari interrotte.</translation>
    </message>
    <message>
      <source>⚠️ No valid previews in this chunk (couldn't find image data in any HDU).</source>
      <translation>⚠️ Nessuna anteprima valida in questo chunk (impossibile trovare dati immagine in qualsiasi HDU).</translation>
    </message>
    <message>
      <source>⚠️ No valid previews in this chunk (couldn’t find image data in any HDU).</source>
      <translation>⚠️ Nessuna anteprima valida in questo chunk (impossibile trovare dati immagine in qualsiasi HDU).</translation>
    </message>
    <message>
      <source>⚠️ No valid previews in this chunk.</source>
      <translation>⚠️ Nessuna anteprima valida in questo chunk.</translation>
    </message>
    <message>
      <source>⚠️ Not enough frames with valid comet centroids; skipping comet stack.</source>
      <translation>⚠️ Frame insufficienti con centroidi cometa validi; stacking cometa saltato.</translation>
    </message>
    <message>
      <source>⚠️ Not enough valid frames in group '{0}' to stack.</source>
      <translation>⚠️ Frame validi insufficienti nel gruppo '{0}' per stackare.</translation>
    </message>
    <message>
      <source>⚠️ Override dark missing on disk; falling back to Auto/None.</source>
      <translation>⚠️ Dark override mancante su disco; fallback a Auto/Nessuno.</translation>
    </message>
    <message>
      <source>⚠️ Per-group transform crop failed for '{0}': {1}</source>
      <translation>⚠️ Ritaglio trasformazione per-gruppo fallito per '{0}': {1}</translation>
    </message>
    <message>
      <source>⚠️ Preview error for {0}: {1}</source>
      <translation>⚠️ Errore anteprima per {0}: {1}</translation>
    </message>
    <message>
      <source>⚠️ PyTorch reports no GPU but you have an NVIDIA card – restarting may help.</source>
      <translation>⚠️ PyTorch non rileva GPU ma hai una scheda NVIDIA – riavviare potrebbe aiutare.</translation>
    </message>
    <message>
      <source>⚠️ Reference file '{0}' not found, skipping group.</source>
      <translation>⚠️ File riferimento '{0}' non trovato, gruppo saltato.</translation>
    </message>
    <message>
      <source>⚠️ Skipping {0}s ({1}) - Not enough frames to stack.</source>
      <translation>⚠️ Saltato {0}s ({1}) - Frame insufficienti per stack.</translation>
    </message>
    <message>
      <source>⚠️ Skipping {0}s ({1}) [{2}] [{3}] - Not enough frames to stack.</source>
      <translation>⚠️ Saltato {0}s ({1}) [{2}] [{3}] - Frame insufficienti per stack.</translation>
    </message>
    <message>
      <source>⚠️ Split error on {0}: {1}</source>
      <translation>⚠️ Errore divisione su {0}: {1}</translation>
    </message>
    <message>
      <source>⚠️ Too many open files ({0}); falling back to lazy per-tile reads.</source>
      <translation>⚠️ Troppi file aperti ({0}); fallback a letture lazy per-tile.</translation>
    </message>
    <message>
      <source>⚠️ Transform-based global crop failed ({0}); falling back to mask-based.</source>
      <translation>⚠️ Ritaglio globale basato su trasformazione fallito ({0}); fallback a basato su maschera.</translation>
    </message>
    <message>
      <source>⚠️ Unsupported transform '{0}' – skipping {1}</source>
      <translation>⚠️ Trasformazione '{0}' non supportata – saltato {1}</translation>
    </message>
    <message>
      <source>⚠️ WARNING: No Master Calibration Files available.</source>
      <translation>⚠️ ATTENZIONE: Nessun File Calibrazione Master disponibile.</translation>
    </message>
    <message>
      <source>⚠️ WARNING: No Master Darks available.</source>
      <translation>⚠️ ATTENZIONE: Nessun Master Dark disponibile.</translation>
    </message>
    <message>
      <source>⚠️ Warning: {0}</source>
      <translation>⚠️ Avviso: {0}</translation>
    </message>
    <message>
      <source>⚠️ rebuild_flat_tree: could not parse key '{0}': {1}</source>
      <translation>⚠️ rebuild_flat_tree: impossibile analizzare chiave '{0}': {1}</translation>
    </message>
    <message>
      <source>⚠️ {0}</source>
      <translation>⚠️ {0}</translation>
    </message>
    <message>
      <source>⚠️ {0} frame has no aligned counterpart – skipping {1}</source>
      <translation>⚠️ Frame {0} non ha controparte allineata – saltato {1}</translation>
    </message>
    <message>
      <source>⚠️ {0} frames failed to align</source>
      <translation>⚠️ {0} frame non allineati</translation>
    </message>
    <message>
      <source>⚡ Fast mode: </source>
      <translation>⚡ Modalità veloce: </translation>
    </message>
    <message>
      <source>⛔ Master Dark creation cancelled during tile processing.</source>
      <translation>⛔ Creazione Master Dark annullata durante elaborazione tile.</translation>
    </message>
    <message>
      <source>⛔ Master Dark creation cancelled.</source>
      <translation>⛔ Creazione Master Dark annullata.</translation>
    </message>
    <message>
      <source>⛔ Master Dark creation cancelled; cleaning up temporary files.</source>
      <translation>⛔ Creazione Master Dark annullata; pulizia file temporanei.</translation>
    </message>
    <message>
      <source>⛔ Master Flat creation cancelled.</source>
      <translation>⛔ Creazione Master Flat annullata.</translation>
    </message>
    <message>
      <source>⛔ Master Flat creation cancelled; cleaning up temporary files.</source>
      <translation>⛔ Creazione Master Flat annullata; pulizia file temporanei.</translation>
    </message>
    <message>
      <source>✂️ (MF) Auto Crop: using transform footprints…</source>
      <translation>✂️ (MF) Auto Ritaglio: uso impronte trasformazione…</translation>
    </message>
    <message>
      <source>✂️ (MF) Auto-crop disabled (no common region).</source>
      <translation>✂️ (MF) Auto-ritaglio disabilitato (nessuna regione comune).</translation>
    </message>
    <message>
      <source>✂️ (MF) Mask-based crop → [{0}:{1}]×[{2}:{3}] ({4}×{5})</source>
      <translation>✂️ (MF) Ritaglio basato su maschera → [{0}:{1}]×[{2}:{3}] ({4}×{5})</translation>
    </message>
    <message>
      <source>✂️ (MF) No transforms/geometry available; falling back to mask-based method…</source>
      <translation>✂️ (MF) Nessuna trasformazione/geometria disponibile; fallback a metodo basato su maschera…</translation>
    </message>
    <message>
      <source>✂️ (MF) Saved auto-cropped copy → {0}</source>
      <translation>✂️ (MF) Copia auto-ritagliata salvata → {0}</translation>
    </message>
    <message>
      <source>✂️ (MF) Transform crop yielded no valid rect; falling back to mask-based method…</source>
      <translation>✂️ (MF) Ritaglio trasformazione non ha prodotto rect valido; fallback a metodo basato su maschera…</translation>
    </message>
    <message>
      <source>✂️ (MF) Transform crop → [{0}:{1}]×[{2}:{3}] ({4}×{5})</source>
      <translation>✂️ (MF) Ritaglio trasformazione → [{0}:{1}]×[{2}:{3}] ({4}×{5})</translation>
    </message>
    <message>
      <source>✂️ Auto Crop Enabled. Calculating bounding box…</source>
      <translation>✂️ Auto Ritaglio Abilitato. Calcolo bounding box…</translation>
    </message>
    <message>
      <source>✂️ Auto-crop: 0/{0} frames had usable transforms; skipping.</source>
      <translation>✂️ Auto-ritaglio: 0/{0} frame avevano trasformazioni utilizzabili; saltato.</translation>
    </message>
    <message>
      <source>✂️ Auto-crop: Loading transforms...</source>
      <translation>✂️ Auto-ritaglio: Caricamento trasformazioni...</translation>
    </message>
    <message>
      <source>✂️ Auto-crop: could not load first aligned ref.</source>
      <translation>✂️ Auto-ritaglio: impossibile caricare primo ref allineato.</translation>
    </message>
    <message>
      <source>✂️ Auto-crop: no common area found; skipping.</source>
      <translation>✂️ Auto-ritaglio: nessuna area comune trovata; saltato.</translation>
    </message>
    <message>
      <source>✂️ Auto-crop: no transforms file at {0}</source>
      <translation>✂️ Auto-ritaglio: nessun file trasformazioni a {0}</translation>
    </message>
    <message>
      <source>✂️ Auto-crop: rasterized {0}/{1} frames; need {2} per-pixel.</source>
      <translation>✂️ Auto-ritaglio: rasterizzati {0}/{1} frame; necessari {2} per-pixel.</translation>
    </message>
    <message>
      <source>✂️ Auto-crop: threshold produced empty mask.</source>
      <translation>✂️ Auto-ritaglio: soglia ha prodotto maschera vuota.</translation>
    </message>
    <message>
      <source>✂️ Auto-cropped to [{0}:{1}]×[{2}:{3}] (scale {4}×)</source>
      <translation>✂️ Auto-ritagliato a [{0}:{1}]×[{2}:{3}] (scala {4}×)</translation>
    </message>
    <message>
      <source>✂️ Drizzle (auto-cropped) saved: {0}</source>
      <translation>✂️ Drizzle (auto-ritagliato) salvato: {0}</translation>
    </message>
    <message>
      <source>✂️ Global crop disabled; will fall back to per-group.</source>
      <translation>✂️ Ritaglio globale disabilitato; fallback a per-gruppo.</translation>
    </message>
    <message>
      <source>✂️ Global crop rect={0} → size {1}×{2}</source>
      <translation>✂️ Rect ritaglio globale={0} → dimensione {1}×{2}</translation>
    </message>
    <message>
      <source>✂️ Global crop: mask shapes differ across groups.</source>
      <translation>✂️ Ritaglio globale: forme maschera differiscono tra i gruppi.</translation>
    </message>
    <message>
      <source>✂️ Global crop: no mask for '{0}' → disabling global crop.</source>
      <translation>✂️ Ritaglio globale: nessuna maschera per '{0}' → ritaglio globale disabilitato.</translation>
    </message>
    <message>
      <source>✂️ Global crop: rect too small; disabling global crop.</source>
      <translation>✂️ Ritaglio globale: rect troppo piccolo; ritaglio globale disabilitato.</translation>
    </message>
    <message>
      <source>✂️ Mask-based crop (global) → [{0}:{1}]×[{2}:{3}] ({4}×{5})</source>
      <translation>✂️ Ritaglio basato su maschera (globale) → [{0}:{1}]×[{2}:{3}] ({4}×{5})</translation>
    </message>
    <message>
      <source>✂️ No stable rect found for this group; per-image fallback will be used.</source>
      <translation>✂️ Nessun rect stabile trovato per questo gruppo; sarà usato fallback per-immagine.</translation>
    </message>
    <message>
      <source>✂️ No transforms/geometry available for fast global crop; falling back to mask-based.</source>
      <translation>✂️ Nessuna trasformazione/geometria disponibile per ritaglio globale veloce; fallback a basato su maschera.</translation>
    </message>
    <message>
      <source>✂️ Saved CometBlend (auto-cropped) → {0}</source>
      <translation>✂️ Salvato MiscelaCometa (auto-ritagliato) → {0}</translation>
    </message>
    <message>
      <source>✂️ Saved CometOnly (auto-cropped) → {0}</source>
      <translation>✂️ Salvato SoloCometa (auto-ritagliato) → {0}</translation>
    </message>
    <message>
      <source>✂️ Saved auto-cropped image for '{0}': {1}</source>
      <translation>✂️ Immagine auto-ritagliata salvata per '{0}': {1}</translation>
    </message>
    <message>
      <source>✂️ Transform crop (global) → [{0}:{1}]×[{2}:{3}] ({4}×{5})</source>
      <translation>✂️ Ritaglio trasformazione (globale) → [{0}:{1}]×[{2}:{3}] ({4}×{5})</translation>
    </message>
    <message>
      <source>✂️ Transform crop produced no stable global rect; falling back to mask-based.</source>
      <translation>✂️ Ritaglio trasformazione non ha prodotto rect globale stabile; fallback a basato su maschera.</translation>
    </message>
    <message>
      <source>✂️ Using fixed crop rect for '{0}': ({1},{2})–({3},{4})</source>
      <translation>✂️ Uso rect ritaglio fisso per '{0}': ({1},{2})–({3},{4})</translation>
    </message>
    <message>
      <source>✅ </source>
      <translation>✅ </translation>
    </message>
    <message>
      <source>✅ Added Master {0} -&gt; {1} under {2} with metadata: {3}</source>
      <translation>✅ Aggiunto Master {0} -&gt; {1} sotto {2} con metadata: {3}</translation>
    </message>
    <message>
      <source>✅ Added {0} as {1}</source>
      <translation>✅ Aggiunto {0} come {1}</translation>
    </message>
    <message>
      <source>✅ Added {0} file(s)</source>
      <translation>✅ Aggiunti {0} file</translation>
    </message>
    <message>
      <source>✅ Aligned {0} frames successfully</source>
      <translation>✅ Allineati {0} frame con successo</translation>
    </message>
    <message>
      <source>✅ All chunks complete! Measured {0} frames total.</source>
      <translation>✅ Tutti i chunk completati! Misurati {0} frame totali.</translation>
    </message>
    <message>
      <source>✅ All frames registered successfully!</source>
      <translation>✅ Tutti i frame registrati con successo!</translation>
    </message>
    <message>
      <source>✅ Auto-accept measured reference is enabled; using the measured best frame.</source>
      <translation>✅ Auto-accettazione riferimento misurato abilitata; uso miglior frame misurato.</translation>
    </message>
    <message>
      <source>✅ Calibrated {0} frames</source>
      <translation>✅ Calibrati {0} frame</translation>
    </message>
    <message>
      <source>✅ Calibration Complete!</source>
      <translation>✅ Calibrazione Completata!</translation>
    </message>
    <message>
      <source>✅ Chunked stacking {0} group(s)...</source>
      <translation>✅ Stacking a chunk {0} gruppo(i)...</translation>
    </message>
    <message>
      <source>✅ Comet seed set. Proceeding with registration…</source>
      <translation>✅ Seed cometa impostato. Proseguo con la registrazione…</translation>
    </message>
    <message>
      <source>✅ DEBUG: Added Master {0} -&gt; {1} under {2} with metadata: {3}</source>
      <translation>✅ DEBUG: Aggiunto Master {0} -&gt; {1} sotto {2} con metadata: {3}</translation>
    </message>
    <message>
      <source>✅ Drizzle (original) saved: {0}</source>
      <translation>✅ Drizzle (originale) salvato: {0}</translation>
    </message>
    <message>
      <source>✅ Dual-band split complete: Ha={0}, SII={1}, OIII={2}, Hb={3} (drizzle seeded on {4} new group(s))</source>
      <translation>✅ Divisione dual-band completata: Ha={0}, SII={1}, OIII={2}, Hb={3} (drizzle inizializzato su {4} nuovo(i) gruppo(i))</translation>
    </message>
    <message>
      <source>✅ Frame weights computed!</source>
      <translation>✅ Pesi frame calcolati!</translation>
    </message>
    <message>
      <source>✅ Group '{0}' not set for drizzle. Integrated image already saved.</source>
      <translation>✅ Gruppo '{0}' non impostato per drizzle. Immagine integrata già salvata.</translation>
    </message>
    <message>
      <source>✅ Group '{0}' stacked {1} frame(s)! Saved: {2}</source>
      <translation>✅ Gruppo '{0}' stackati {1} frame! Salvato: {2}</translation>
    </message>
    <message>
      <source>✅ MFDeconv complete for all groups. Skipping normal integration as requested.</source>
      <translation>✅ MFDeconv completata per tutti i gruppi. Integrazione normale saltata come richiesto.</translation>
    </message>
    <message>
      <source>✅ MFDeconv complete for all groups. Skipping normal integration.</source>
      <translation>✅ MFDeconv completata per tutti i gruppi. Integrazione normale saltata.</translation>
    </message>
    <message>
      <source>✅ Master Dark saved and added to UI: {0}</source>
      <translation>✅ Master Dark salvato e aggiunto a UI: {0}</translation>
    </message>
    <message>
      <source>✅ Master Dark saved: {0}</source>
      <translation>✅ Master Dark salvato: {0}</translation>
    </message>
    <message>
      <source>✅ Master Flat saved: {0}</source>
      <translation>✅ Master Flat salvato: {0}</translation>
    </message>
    <message>
      <source>✅ Master Light saved for group '{0}': {1}</source>
      <translation>✅ Master Light salvato per gruppo '{0}': {1}</translation>
    </message>
    <message>
      <source>✅ Master bias saved</source>
      <translation>✅ Master bias salvato</translation>
    </message>
    <message>
      <source>✅ Master dark saved</source>
      <translation>✅ Master dark salvato</translation>
    </message>
    <message>
      <source>✅ Master flat saved</source>
      <translation>✅ Master flat salvato</translation>
    </message>
    <message>
      <source>✅ Ready</source>
      <translation>✅ Pronto</translation>
    </message>
    <message>
      <source>✅ Removed {0} file(s)</source>
      <translation>✅ Rimossi {0} file</translation>
    </message>
    <message>
      <source>✅ SASD v2: loaded {0} transform(s).</source>
      <translation>✅ SASD v2: caricate {0} trasformazione(i).</translation>
    </message>
    <message>
      <source>✅ Saved CometBlend → {0}</source>
      <translation>✅ Salvato MiscelaCometa → {0}</translation>
    </message>
    <message>
      <source>✅ Saved CometOnly → {0}</source>
      <translation>✅ Salvato SoloCometa → {0}</translation>
    </message>
    <message>
      <source>✅ Saved integrated image (original) for '{0}': {1}</source>
      <translation>✅ Immagine integrata salvata (originale) per '{0}': {1}</translation>
    </message>
    <message>
      <source>✅ Saved integrated image (single-HDU) for '{0}': {1}</source>
      <translation>✅ Immagine integrata salvata (HDU singolo) per '{0}': {1}</translation>
    </message>
    <message>
      <source>✅ Saved integrated image (with rejection layers) for '{0}': {1}</source>
      <translation>✅ Immagine integrata salvata (con layer rifiuto) per '{0}': {1}</translation>
    </message>
    <message>
      <source>✅ Saved rejection map to {0}</source>
      <translation>✅ Mappa rifiuto salvata in {0}</translation>
    </message>
    <message>
      <source>✅ Saved stacking settings.</source>
      <translation>✅ Impostazioni stacking salvate.</translation>
    </message>
    <message>
      <source>✅ Star‐Trail image written to {0}</source>
      <translation>✅ Immagine scie stellari salvata in {0}</translation>
    </message>
    <message>
      <source>✅ Transform file saved as alignment_transforms.sasd (v2)</source>
      <translation>✅ File trasformazione salvato come alignment_transforms.sasd (v2)</translation>
    </message>
    <message>
      <source>✅ Transform file saved as {0}</source>
      <translation>✅ File trasformazione salvato come {0}</translation>
    </message>
    <message>
      <source>✅ Updated self.light_files to use debayered, normalized *_n.fit frames.</source>
      <translation>✅ Aggiornato self.light_files per usare frame debayerizzati, normalizzati *_n.fit.</translation>
    </message>
    <message>
      <source>✅ User reference is locked; skipping reference review dialog.</source>
      <translation>✅ Riferimento utente bloccato; dialogo revisione saltato.</translation>
    </message>
    <message>
      <source>✅ {0}</source>
      <translation>✅ {0}</translation>
    </message>
    <message>
      <source>✖ Star-trail save cancelled.</source>
      <translation>✖ Salvataggio scie stellari annullato.</translation>
    </message>
    <message>
      <source>✨ Comet star removal enabled — pre-processing frames…</source>
      <translation>✨ Rimozione stelle cometa abilitata — pre-elaborazione frame…</translation>
    </message>
    <message>
      <source>✨ Using comet-aligned STARLESS frames for stack ({0} files).</source>
      <translation>✨ Uso frame STARLESS allineati cometa per stack ({0} file).</translation>
    </message>
    <message>
      <source>❌ </source>
      <translation>❌ </translation>
    </message>
    <message>
      <source>❌ ERROR: Could not read FITS header for {0} - {1}</source>
      <translation>❌ ERRORE: Impossibile leggere header FITS per {0} - {1}</translation>
    </message>
    <message>
      <source>❌ ERROR: Failed to load {0}</source>
      <translation>❌ ERRORE: Caricamento {0} fallito</translation>
    </message>
    <message>
      <source>❌ Error: {0}</source>
      <translation>❌ Errore: {0}</translation>
    </message>
    <message>
      <source>❌ Failed to load reference {0}</source>
      <translation>❌ Caricamento riferimento {0} fallito</translation>
    </message>
    <message>
      <source>❌ Failed to memmap dark frames: {0}</source>
      <translation>❌ Memmap frame dark fallito: {0}</translation>
    </message>
    <message>
      <source>❌ Failed to memmap flat frames: {0}</source>
      <translation>❌ Memmap frame flat fallito: {0}</translation>
    </message>
    <message>
      <source>❌ GPU Acceleration install aborted: unsupported Python version.</source>
      <translation>❌ Installazione Accelerazione GPU annullata: versione Python non supportata.</translation>
    </message>
    <message>
      <source>❌ MFDeconv failed for '{0}': {1}</source>
      <translation>❌ MFDeconv fallita per '{0}': {1}</translation>
    </message>
    <message>
      <source>❌ Operation cancelled</source>
      <translation>❌ Operazione annullata</translation>
    </message>
    <message>
      <source>❌ Registration cancelled (no comet seed).</source>
      <translation>❌ Registrazione annullata (nessun seed cometa).</translation>
    </message>
    <message>
      <source>❌ {0}</source>
      <translation>❌ {0}</translation>
    </message>
    <message>
      <source>⤴ {0}: {1} files</source>
      <translation>⤴ {0}: {1} file</translation>
    </message>
    <message>
      <source>⭐ Stacking in progress…</source>
      <translation>⭐ Stacking in corso…</translation>
    </message>
    <message>
      <source>⭐ Star-Trail Mode disabled: other options re-enabled.</source>
      <translation>⭐ Modalità Star-Trail disabilitata: altre opzioni riabilitate.</translation>
    </message>
    <message>
      <source>⭐ Star-Trail Mode enabled: Drizzle, Comet stack, and MFDeconv disabled.</source>
      <translation>⭐ Modalità Star-Trail abilitata: Drizzle, Stack Cometa e MFDeconv disabilitati.</translation>
    </message>
    <message>
      <source>🌀 Normalizing chunk {0}/{1} ({2} frames)…</source>
      <translation>🌀 Normalizzazione chunk {0}/{1} ({2} frame)…</translation>
    </message>
    <message>
      <source>🌈 Splitting dual-band OSC frames into Ha / SII / OIII...</source>
      <translation>🌈 Divisione frame OSC dual-band in Ha / SII / OIII...</translation>
    </message>
    <message>
      <source>🌍 Loading {0} images in parallel for normalization (up to {1} threads)…</source>
      <translation>🌍 Caricamento {0} immagini in parallelo per normalizzazione (fino a {1} thread)…</translation>
    </message>
    <message>
      <source>🌍 Loading {0} previews in parallel (up to {1} threads)...</source>
      <translation>🌍 Caricamento {0} anteprime in parallelo (fino a {1} thread)...</translation>
    </message>
    <message>
      <source>🌍 Measuring global means in parallel...</source>
      <translation>🌍 Misurazione medie globali in parallelo...</translation>
    </message>
    <message>
      <source>🌓 This flat group: using AUTO dark → {0}</source>
      <translation>🌓 Questo gruppo flat: uso dark AUTO → {0}</translation>
    </message>
    <message>
      <source>🌓 This flat group: using OVERRIDE dark → {0}</source>
      <translation>🌓 Questo gruppo flat: uso dark OVERRIDE → {0}</translation>
    </message>
    <message>
      <source>🌠 Comet anchor in reference frame: ({0:.1f}, {1:.1f})</source>
      <translation>🌠 Ancoraggio cometa nel frame riferimento: ({0:.1f}, {1:.1f})</translation>
    </message>
    <message>
      <source>🌠 Comet mode enabled for this group</source>
      <translation>🌠 Modalità cometa abilitata per questo gruppo</translation>
    </message>
    <message>
      <source>🌠 Comet mode: please click the comet center to continue…</source>
      <translation>🌠 Modalità cometa: clicca sul centro della cometa per continuare…</translation>
    </message>
    <message>
      <source>🌠 Comet seed set on {0} at ({1:.1f}, {2:.1f}).</source>
      <translation>🌠 Seed cometa impostato su {0} a ({1:.1f}, {2:.1f}).</translation>
    </message>
    <message>
      <source>🌠 Create comet stack (comet-aligned)</source>
      <translation>🌠 Crea stack cometa (allineato cometa)</translation>
    </message>
    <message>
      <source>🌠 Star-Trail Mode enabled: skipping registration &amp; using max-value stack</source>
      <translation>🌠 Modalità Scie Stellari abilitata: registrazione saltata &amp; uso stack valore max</translation>
    </message>
    <message>
      <source>🎉 CUDA: torch.cuda.is_available() → True, GPU ready.</source>
      <translation>🎉 CUDA: torch.cuda.is_available() → True, GPU pronta.</translation>
    </message>
    <message>
      <source>🎯 Stacking complete!</source>
      <translation>🎯 Stacking completato!</translation>
    </message>
    <message>
      <source>🎯 Target pixel scale (hi-res): {0:.3f}"/px × {1:.3f}"/px</source>
      <translation>🎯 Scala pixel target (hi-res): {0:.3f}"/px × {1:.3f}"/px</translation>
    </message>
    <message>
      <source>🎯 Target pixel scale unknown (no WCS/pixel size). Will skip scale normalization.</source>
      <translation>🎯 Scala pixel target sconosciuta (nessun WCS/dimensione pixel). Normalizzazione scala saltata.</translation>
    </message>
    <message>
      <source>💡 For best results with CFA drizzle, aim for &gt;65% fill.</source>
      <translation>💡 Per migliori risultati con CFA drizzle, punta a &gt;65% riempimento.</translation>
    </message>
    <message>
      <source>💾 Saving result…</source>
      <translation>💾 Salvataggio risultato…</translation>
    </message>
    <message>
      <source>📁 Calibrated files saved to: {0}</source>
      <translation>📁 File calibrati salvati in: {0}</translation>
    </message>
    <message>
      <source>📁 Output saved to: {0}</source>
      <translation>📁 Output salvato in: {0}</translation>
    </message>
    <message>
      <source>📁 Post-align: {0} group(s), {1} aligned frame(s).</source>
      <translation>📁 Post-allineamento: {0} gruppo(i), {1} frame allineato(i).</translation>
    </message>
    <message>
      <source>📂 DEBUG: Master Files Stored: {0}</source>
      <translation>📂 DEBUG: File Master Salvati: {0}</translation>
    </message>
    <message>
      <source>📂 Loaded stacking profile: {0}</source>
      <translation>📂 Profilo stacking caricato: {0}</translation>
    </message>
    <message>
      <source>📂 Preparing to stack {0} frames in {1} groups.</source>
      <translation>📂 Preparazione stack {0} frame in {1} gruppi.</translation>
    </message>
    <message>
      <source>📂 {0} → StarCount={1}, Ecc={2:.4f}, Mean={3:.4f}, Weight={4:.4f}</source>
      <translation>📂 {0} → ConteggiStelle={1}, Ecc={2:.4f}, Media={3:.4f}, Peso={4:.4f}</translation>
    </message>
    <message>
      <source>📈 Dark groups summary:</source>
      <translation>📈 Riepilogo gruppi dark:</translation>
    </message>
    <message>
      <source>📈 Flat groups summary:</source>
      <translation>📈 Riepilogo gruppi flat:</translation>
    </message>
    <message>
      <source>📈 Light groups summary:</source>
      <translation>📈 Riepilogo gruppi light:</translation>
    </message>
    <message>
      <source>📊 (New) reference median: {0:.4f}</source>
      <translation>📊 Mediana (nuovo) riferimento: {0:.4f}</translation>
    </message>
    <message>
      <source>📊 Calculating statistics…</source>
      <translation>📊 Calcolo statistiche…</translation>
    </message>
    <message>
      <source>📊 Found {0} aligned/normalized frames. Measuring in parallel previews…</source>
      <translation>📊 Trovati {0} frame allineati/normalizzati. Misurazione anteprime parallele…</translation>
    </message>
    <message>
      <source>📊 Found {0} total frames. Now measuring in parallel batches...</source>
      <translation>📊 Trovati {0} frame totali. Misurazione in batch paralleli...</translation>
    </message>
    <message>
      <source>📊 Group '{0}' has {1} aligned file(s).</source>
      <translation>📊 Gruppo '{0}' ha {1} file allineato(i).</translation>
    </message>
    <message>
      <source>📊 Reference (debayered) median: {0:.4f}</source>
      <translation>📊 Mediana riferimento (debayerizzato): {0:.4f}</translation>
    </message>
    <message>
      <source>📊 Reference min={0:.6f}, normalized-median={1:.6f}</source>
      <translation>📊 Riferimento min={0:.6f}, mediana-normalizzata={1:.6f}</translation>
    </message>
    <message>
      <source>📊 Stacking group '{0}' with {1}</source>
      <translation>📊 Stacking gruppo '{0}' con {1}</translation>
    </message>
    <message>
      <source>📊 Stacking group '{0}' with {1}{2}</source>
      <translation>📊 Stacking gruppo '{0}' con {1}{2}</translation>
    </message>
    <message>
      <source>📊 Stacking {0} frames</source>
      <translation>📊 Stacking {0} frame</translation>
    </message>
    <message>
      <source>📌 Auto-selected reference: {0}</source>
      <translation>📌 Riferimento auto-selezionato: {0}</translation>
    </message>
    <message>
      <source>📌 Auto-selected reference: {0} {1}</source>
      <translation>📌 Riferimento auto-selezionato: {0} {1}</translation>
    </message>
    <message>
      <source>📌 Comet reference pixel @ {0} → ({1:.2f},{2:.2f})</source>
      <translation>📌 Pixel riferimento cometa @ {0} → ({1:.2f},{2:.2f})</translation>
    </message>
    <message>
      <source>📌 Reference for alignment (verbatim): {0}</source>
      <translation>📌 Riferimento per allineamento (letterale): {0}</translation>
    </message>
    <message>
      <source>📌 Using user-specified reference (locked): {0}</source>
      <translation>📌 Uso riferimento specificato dall'utente (bloccato): {0}</translation>
    </message>
    <message>
      <source>📌 Using user-specified reference: {0}</source>
      <translation>📌 Uso riferimento specificato dall'utente: {0}</translation>
    </message>
    <message>
      <source>📏 Pixel-scale normalize {0:.3f}"/{1:.3f}" → {2:.3f}"/{3:.3f}" | size {4}×{5} → {6}×{7}</source>
      <translation>📏 Normalizzazione pixel-scale {0:.3f}"/{1:.3f}" → {2:.3f}"/{3:.3f}" | dimensione {4}×{5} → {6}×{7}</translation>
    </message>
    <message>
      <source>📐 Applying geometric correction…</source>
      <translation>📐 Applicazione correzione geometrica…</translation>
    </message>
    <message>
      <source>📐 Drizzle for '{0}' at {1}× (drop={2}) using {3} frame(s).</source>
      <translation>📐 Drizzle per '{0}' a {1}× (drop={2}) usando {3} frame.</translation>
    </message>
    <message>
      <source>📜 Reading metadata for {0} files…</source>
      <translation>📜 Lettura metadati per {0} file…</translation>
    </message>
    <message>
      <source>📦 Debayering reference frame…</source>
      <translation>📦 Debayering frame riferimento…</translation>
    </message>
    <message>
      <source>📦 Debayering {0}…</source>
      <translation>📦 Debayering {0}…</translation>
    </message>
    <message>
      <source>📦 Measuring chunk {0}/{1} ({2} frames)</source>
      <translation>📦 Misurazione chunk {0}/{1} ({2} frame)</translation>
    </message>
    <message>
      <source>📦 {0} tiles to process for this group (chunk {1}×{2}).</source>
      <translation>📦 {0} tile da elaborare per questo gruppo (chunk {1}×{2}).</translation>
    </message>
    <message>
      <source>📷 Applying bias subtraction…</source>
      <translation>📷 Applicazione sottrazione bias…</translation>
    </message>
    <message>
      <source>📷 Applying dark subtraction…</source>
      <translation>📷 Applicazione sottrazione dark…</translation>
    </message>
    <message>
      <source>📷 Applying flat correction…</source>
      <translation>📷 Applicazione correzione flat…</translation>
    </message>
    <message>
      <source>🔀 Computing transforms…</source>
      <translation>🔀 Calcolo trasformazioni…</translation>
    </message>
    <message>
      <source>🔁 Restarting Stacking Suite to apply {0}…</source>
      <translation>🔁 Riavvio Suite Stacking per applicare {0}…</translation>
    </message>
    <message>
      <source>🔄 Aligning frame {0}…</source>
      <translation>🔄 Allineamento frame {0}…</translation>
    </message>
    <message>
      <source>🔄 Image Registration Started...</source>
      <translation>🔄 Registrazione Immagini Avviata...</translation>
    </message>
    <message>
      <source>🔄 Integrating Previously Registered Images…</source>
      <translation>🔄 Integrazione Immagini Precedentemente Registrate…</translation>
    </message>
    <message>
      <source>🔄 Normalizing frame {0}/{1}</source>
      <translation>🔄 Normalizzazione frame {0}/{1}</translation>
    </message>
    <message>
      <source>🔄 Processing files…</source>
      <translation>🔄 Elaborazione file…</translation>
    </message>
    <message>
      <source>🔍 Detected {0} stars</source>
      <translation>🔍 Rilevate {0} stelle</translation>
    </message>
    <message>
      <source>🔍 Detecting stars in reference frame…</source>
      <translation>🔍 Rilevamento stelle nel frame di riferimento…</translation>
    </message>
    <message>
      <source>🔎 CFA drizzle sub-pixel phase fill (8×8): {0:.1f}%</source>
      <translation>🔎 Riempimento fase sub-pixel CFA drizzle (8×8): {0:.1f}%</translation>
    </message>
    <message>
      <source>🔎 Discovered {0} flat groups ({1} eligible to stack) — {2} files total.</source>
      <translation>🔎 Scoperti {0} gruppi flat ({1} eleggibili per stack) — {2} file totali.</translation>
    </message>
    <message>
      <source>🔎 Discovered {0} grouped exposures ({1} eligible to stack) — {2} files total.</source>
      <translation>🔎 Scoperte {0} esposizioni raggruppate ({1} eleggibili per stack) — {2} file totali.</translation>
    </message>
    <message>
      <source>🔎 Scanning {0} file(s)…</source>
      <translation>🔎 Scansione {0} file…</translation>
    </message>
    <message>
      <source>🔢 Processing frame {0} of {1}</source>
      <translation>🔢 Elaborazione frame {0} di {1}</translation>
    </message>
    <message>
      <source>🔥🚀Register and Integrate Images🔥🚀</source>
      <translation>🔥🚀Registra e Integra Immagini🔥🚀</translation>
    </message>
    <message>
      <source>🔧 Applying corrections…</source>
      <translation>🔧 Applicazione correzioni…</translation>
    </message>
    <message>
      <source>🔧 Calibrating frame {0}…</source>
      <translation>🔧 Calibrazione frame {0}…</translation>
    </message>
    <message>
      <source>🔧 Comet stack chunk {0}×{1}</source>
      <translation>🔧 Chunk stack cometa {0}×{1}</translation>
    </message>
    <message>
      <source>🔧 Resampled for binning {0}×{1} → {2}×{3} size {4}×{5} → {6}×{7}</source>
      <translation>🔧 Ricampionato per binning {0}×{1} → {2}×{3} dimensione {4}×{5} → {6}×{7}</translation>
    </message>
    <message>
      <source>🔧 Using chunk size {0}×{1} for {2}</source>
      <translation>🔧 Uso dimensione chunk {0}×{1} per {2}</translation>
    </message>
    <message>
      <source>🔨 Creating master bias from {0} frames…</source>
      <translation>🔨 Creazione master bias da {0} frame…</translation>
    </message>
    <message>
      <source>🔨 Creating master dark from {0} frames…</source>
      <translation>🔨 Creazione master dark da {0} frame…</translation>
    </message>
    <message>
      <source>🔨 Creating master flat from {0} frames…</source>
      <translation>🔨 Creazione master flat da {0} frame…</translation>
    </message>
    <message>
      <source>🔬 Drizzle factor: {0}x</source>
      <translation>🔬 Fattore drizzle: {0}x</translation>
    </message>
    <message>
      <source>🔬 Drizzle integration complete</source>
      <translation>🔬 Integrazione drizzle completata</translation>
    </message>
    <message>
      <source>🔬 Output resolution: {0}x{1}</source>
      <translation>🔬 Risoluzione output: {0}x{1}</translation>
    </message>
    <message>
      <source>🔬 Using {0} kernel</source>
      <translation>🔬 Uso kernel {0}</translation>
    </message>
    <message>
      <source>🔭 Drizzle stacking for group '{0}' with {1} total rejected pixels.</source>
      <translation>🔭 Stacking drizzle per gruppo '{0}' con {1} pixel rifiutati totali.</translation>
    </message>
    <message>
      <source>🔹 [{0}/{1}] Integrating '{2}' with {3} file(s)…</source>
      <translation>🔹 [{0}/{1}] Integrazione '{2}' con {3} file…</translation>
    </message>
    <message>
      <source>🗂️ Creating temp memmap: {0} (shape={1}×{2}×{3}, dtype=float32)</source>
      <translation>🗂️ Creazione memmap temp: {0} (shape={1}×{2}×{3}, dtype=float32)</translation>
    </message>
    <message>
      <source>🚀 Calibrate Light Frames 🚀</source>
      <translation>🚀 Calibra Frame Light 🚀</translation>
    </message>
    <message>
      <source>🚨 Could not load reference {0}. Aborting.</source>
      <translation>🚨 Impossibile caricare riferimento {0}. Interruzione.</translation>
    </message>
    <message>
      <source>🚨 Reference file does not exist: {0}</source>
      <translation>🚨 File riferimento non esiste: {0}</translation>
    </message>
    <message>
      <source>🚨 Rejected {0} frame(s) due to shift &gt; {1}px.</source>
      <translation>🚨 Rifiutati {0} frame per spostamento &gt; {1}px.</translation>
    </message>
    <message>
      <source>🟠 Comet-aligned integration…</source>
      <translation>🟠 Integrazione allineata cometa…</translation>
    </message>
    <message>
      <source>🟡 Blending Stars+Comet (screen after 5% stretch; mix={0:.2f})…</source>
      <translation>🟡 Miscela Stelle+Cometa (screen dopo stretch 5%; mix={0:.2f})…</translation>
    </message>
    <message>
      <source>🟢 Assigned session '{0}' to group '{1}'</source>
      <translation>🟢 Sessione '{0}' assegnata al gruppo '{1}'</translation>
    </message>
    <message>
      <source>🟢 Assigned session '{0}' to {1} file(s).</source>
      <translation>🟢 Sessione '{0}' assegnata a {1} file.</translation>
    </message>
    <message>
      <source>🟢 Measuring comet centers (template match)…</source>
      <translation>🟢 Misurazione centri cometa (template match)…</translation>
    </message>
    <message>
      <source>🟢 Processing {0} darks for {1}s ({2}) exposure…</source>
      <translation>🟢 Elaborazione {0} dark per esposizione {1}s ({2})…</translation>
    </message>
    <message>
      <source>🟢 Processing {0} flats for {1} ({2}) [{3}] in session '{4}'…</source>
      <translation>🟢 Elaborazione {0} flat per {1} ({2}) [{3}] nella sessione '{4}'…</translation>
    </message>
    <message>
      <source>🧠 Selecting reference optimized for AstroAlign (starcount/(median*ecc))…</source>
      <translation>🧠 Selezione riferimento ottimizzato per AstroAlign (starcount/(median*ecc))…</translation>
    </message>
    <message>
      <source>🧩 Bayer flat group detected: {0}</source>
      <translation>🧩 Gruppo flat Bayer rilevato: {0}</translation>
    </message>
    <message>
      <source>🧪 Multi-frame PSF-aware deconvolution path enabled.</source>
      <translation>🧪 Percorso deconvoluzione PSF-aware multi-frame abilitato.</translation>
    </message>
    <message>
      <source>🧭 Drizzle uses {0} for {1}</source>
      <translation>🧭 Drizzle usa {0} per {1}</translation>
    </message>
    <message>
      <source>🧭 Total tiles to process: {0} (base chunk preference {1}×{2})</source>
      <translation>🧭 Tile totali da elaborare: {0} (preferenza chunk base {1}×{2})</translation>
    </message>
    <message>
      <source>🧮 Binning summary → target={0}×{1} (range observed: x=[{2}..{3}], y=[{4}..{5}])</source>
      <translation>🧮 Riepilogo binning → target={0}×{1} (range osservato: x=[{2}..{3}], y=[{4}..{5}])</translation>
    </message>
    <message>
      <source>🧹 Clearing selection…</source>
      <translation>🧹 Pulizia selezione…</translation>
    </message>
  </context>
  <context>
    <name>StarSpikesDialogPro</name>
    <message>
      <source>Aperture</source>
      <translation>Apertura</translation>
    </message>
    <message>
      <source>Aperture Help</source>
      <translation>Aiuto apertura</translation>
    </message>
    <message>
      <source>Aperture Type:</source>
      <translation>Tipo apertura:</translation>
    </message>
    <message>
      <source>Apply to Active Document</source>
      <translation>Applica al documento attivo</translation>
    </message>
    <message>
      <source>Detection Threshold (σ):</source>
      <translation>Soglia rilevamento (σ):</translation>
    </message>
    <message>
      <source>Diffraction Spikes</source>
      <translation>Spike di diffrazione</translation>
    </message>
    <message>
      <source>Fit to Preview</source>
      <translation>Adatta all'anteprima</translation>
    </message>
    <message>
      <source>Flux Min:</source>
      <translation>Flusso min:</translation>
    </message>
    <message>
      <source>Generate Spikes</source>
      <translation>Genera spike</translation>
    </message>
    <message>
      <source>Number of Vanes:</source>
      <translation>Numero di razze:</translation>
    </message>
    <message>
      <source>Obstruction:</source>
      <translation>Ostruzione:</translation>
    </message>
    <message>
      <source>PSF &amp; Synthesis</source>
      <translation>PSF e sintesi</translation>
    </message>
    <message>
      <source>PSF Blur Sigma:</source>
      <translation>Sigma sfocatura PSF:</translation>
    </message>
    <message>
      <source>Pupil Radius:</source>
      <translation>Raggio pupilla:</translation>
    </message>
    <message>
      <source>Ready</source>
      <translation>Pronto</translation>
    </message>
    <message>
      <source>Rotation (deg):</source>
      <translation>Rotazione (gradi):</translation>
    </message>
    <message>
      <source>Spike Boost:</source>
      <translation>Boost spike:</translation>
    </message>
    <message>
      <source>Star Detection</source>
      <translation>Rilevamento stelle</translation>
    </message>
    <message>
      <source>Vane Width:</source>
      <translation>Larghezza razza:</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
  </context>
  <context>
    <name>StarStretchDialog</name>
    <message>
      <source>Apply to Document</source>
      <translation>Applica al documento</translation>
    </message>
    <message>
      <source>Color Boost:</source>
      <translation>Boost colore:</translation>
    </message>
    <message>
      <source>Fit to Preview</source>
      <translation>Adatta all'anteprima</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Remove Green via SCNR (Optional)</source>
      <translation>Rimuovi verde via SCNR (opzionale)</translation>
    </message>
    <message>
      <source>Star Stretch</source>
      <translation>Star Stretch</translation>
    </message>
    <message>
      <source>Stretch Amount:</source>
      <translation>Quantità stretch:</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
  </context>
  <context>
    <name>StatisticalStretchDialog</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Curves boost</source>
      <translation>Boost curve</translation>
    </message>
    <message>
      <source>Linked channels</source>
      <translation>Canali collegati</translation>
    </message>
    <message>
      <source>Normalize to [0..1]</source>
      <translation>Normalizza a [0..1]</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Statistical Stretch</source>
      <translation>Stretch statistico</translation>
    </message>
    <message>
      <source>Strength:</source>
      <translation>Intensità:</translation>
    </message>
    <message>
      <source>Target median:</source>
      <translation>Mediana target:</translation>
    </message>
  </context>
  <context>
    <name>StatisticsDialog</name>
    <message>
      <source>App Statistics</source>
      <translation>Statistiche App</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Days</source>
      <translation>Giorni</translation>
    </message>
    <message>
      <source>Hours</source>
      <translation>Ore</translation>
    </message>
    <message>
      <source>Images Opened:</source>
      <translation>Immagini Aperte:</translation>
    </message>
    <message>
      <source>Minutes</source>
      <translation>Minuti</translation>
    </message>
    <message>
      <source>Time Spent:</source>
      <translation>Tempo Trascorso:</translation>
    </message>
    <message>
      <source>Tools Opened:</source>
      <translation>Strumenti Aperti:</translation>
    </message>
  </context>
  <context>
    <name>StatusLogWindow</name>
    <message>
      <source>Clear</source>
      <translation>Cancella</translation>
    </message>
    <message>
      <source>Stacking Suite Log</source>
      <translation>Log Stacking Suite</translation>
    </message>
  </context>
  <context>
    <name>SupernovaAsteroidHunterDialog</name>
    <message>
      <source>Images (*.png *.tif *.tiff *.fits *.fit *.xisf)</source>
      <translation>Immagini (*.png *.tif *.tiff *.fits *.fit *.xisf)</translation>
    </message>
  </context>
  <context>
    <name>SurfaceDialog</name>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Span: {0:.2f} … {1:.2f} {2}</source>
      <translation>Intervallo: {0:.2f} … {1:.2f} {2}</translation>
    </message>
  </context>
  <context>
    <name>TableSubWindow</name>
    <message>
      <source>CSV Files (*.csv)</source>
      <translation>File CSV (*.csv)</translation>
    </message>
    <message>
      <source>Export CSV</source>
      <translation>Esporta CSV</translation>
    </message>
    <message>
      <source>Export CSV…</source>
      <translation>Esporta CSV…</translation>
    </message>
    <message>
      <source>Failed to copy CSV:
{0}</source>
      <translation>Copia CSV fallita:
{0}</translation>
    </message>
    <message>
      <source>Failed to export CSV:
{0}</source>
      <translation>Esportazione CSV fallita:
{0}</translation>
    </message>
    <message>
      <source>Save CSV As…</source>
      <translation>Salva CSV come…</translation>
    </message>
  </context>
  <context>
    <name>TiltDialog</name>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Corner</source>
      <translation>Angolo</translation>
    </message>
    <message>
      <source>Tilt span: {0:.1f} µm … {1:.1f} µm</source>
      <translation>Intervallo inclinazione: {0:.1f} µm … {1:.1f} µm</translation>
    </message>
    <message>
      <source>Δ µm</source>
      <translation>Δ µm</translation>
    </message>
  </context>
  <context>
    <name>ToolbarMixin</name>
    <message>
      <source>&amp;Exit</source>
      <translation>&amp;Esci</translation>
    </message>
    <message>
      <source>1:1</source>
      <translation>1:1</translation>
    </message>
    <message>
      <source>ABE...</source>
      <translation>ABE...</translation>
    </message>
    <message>
      <source>Aberration Correction (AI)...</source>
      <translation>Correzione aberrazione (AI)...</translation>
    </message>
    <message>
      <source>Add Stars...</source>
      <translation>Aggiungi stelle...</translation>
    </message>
    <message>
      <source>Add diffraction spikes to detected stars</source>
      <translation>Aggiungi spike di diffrazione alle stelle rilevate</translation>
    </message>
    <message>
      <source>Add signatures/overlays and bake them into the active image</source>
      <translation>Aggiungi firme/overlay e incorporali nell'immagine attiva</translation>
    </message>
    <message>
      <source>Adjust specific hue ranges with CMY/RGB controls</source>
      <translation>Regola intervalli tonalità specifici con controlli CMY/RGB</translation>
    </message>
    <message>
      <source>Advanced diffraction spikes with halos, flares and rainbow effects</source>
      <translation>Spike di diffrazione avanzati con aloni, flare ed effetti arcobaleno</translation>
    </message>
    <message>
      <source>Align R and B channels to G using astroalign (affine/homography/poly)</source>
      <translation>Allinea canali R e B a G usando astroalign (affine/omografia/poli)</translation>
    </message>
    <message>
      <source>Align images via astroalign / triangles</source>
      <translation>Allinea immagini tramite astroalign / triangoli</translation>
    </message>
    <message>
      <source>Apply Mask</source>
      <translation>Applica maschera</translation>
    </message>
    <message>
      <source>Apply a mask document to the active image</source>
      <translation>Applica un documento maschera all'immagine attiva</translation>
    </message>
    <message>
      <source>Apply the current Display-Stretch to the image and add an undo step</source>
      <translation>Applica il Display-Stretch corrente all'immagine e aggiungi un passo annulla</translation>
    </message>
    <message>
      <source>Apply the same stretch to all RGB channels</source>
      <translation>Applica lo stesso stretch a tutti i canali RGB</translation>
    </message>
    <message>
      <source>Apply white balance (Star-Based, Manual, or Auto)</source>
      <translation>Applica bilanciamento bianco (Basato su stelle, Manuale o Auto)</translation>
    </message>
    <message>
      <source>Arcsinh star stretch with optional SCNR and color boost</source>
      <translation>Star stretch arcsinh con SCNR opzionale e boost colore</translation>
    </message>
    <message>
      <source>Arrange subwindows in a near-square grid</source>
      <translation>Disponi sottofinestre in una griglia quasi quadrata</translation>
    </message>
    <message>
      <source>AstroBin Exporter...</source>
      <translation>Esportatore AstroBin...</translation>
    </message>
    <message>
      <source>AstroSpike...</source>
      <translation>AstroSpike...</translation>
    </message>
    <message>
      <source>Auto-fit on Resize</source>
      <translation>Adatta automaticamente al ridimensionamento</translation>
    </message>
    <message>
      <source>Automatic Background Extraction</source>
      <translation>Estrazione automatica sfondo</translation>
    </message>
    <message>
      <source>Background Neutralization...</source>
      <translation>Neutralizzazione sfondo...</translation>
    </message>
    <message>
      <source>Batch Converter...</source>
      <translation>Convertitore batch...</translation>
    </message>
    <message>
      <source>Batch Modify FITS Headers</source>
      <translation>Modifica batch header FITS</translation>
    </message>
    <message>
      <source>Batch Rename from FITS...</source>
      <translation>Rinomina batch da FITS...</translation>
    </message>
    <message>
      <source>Batch-align frames to a reference</source>
      <translation>Allinea in batch frame a un riferimento</translation>
    </message>
    <message>
      <source>Blemish Blaster...</source>
      <translation>Blemish Blaster...</translation>
    </message>
    <message>
      <source>Blend a starless view with a stars-only view</source>
      <translation>Fondi una vista senza stelle con una vista solo stelle</translation>
    </message>
    <message>
      <source>Blend two open images (replace A or create new)</source>
      <translation>Fondi due immagini aperte (sostituisci A o crea nuova)</translation>
    </message>
    <message>
      <source>Blink Comparator...</source>
      <translation>Comparatore Blink...</translation>
    </message>
    <message>
      <source>Build mosaics from overlapping frames</source>
      <translation>Costruisci mosaici da frame sovrapposti</translation>
    </message>
    <message>
      <source>Bundles</source>
      <translation>Bundle</translation>
    </message>
    <message>
      <source>CLAHE...</source>
      <translation>CLAHE...</translation>
    </message>
    <message>
      <source>Cascade Views</source>
      <translation>Cascata viste</translation>
    </message>
    <message>
      <source>Cascade all subwindows</source>
      <translation>Sovrapponi tutte le sottofinestre</translation>
    </message>
    <message>
      <source>Check for Updates...</source>
      <translation>Controlla aggiornamenti...</translation>
    </message>
    <message>
      <source>Clear All Views</source>
      <translation>Chiudi tutte le viste</translation>
    </message>
    <message>
      <source>Close all views and clear shortcuts</source>
      <translation>Chiudi tutte le viste e cancella scorciatoie</translation>
    </message>
    <message>
      <source>Close all views and documents, keep desktop shortcuts</source>
      <translation>Chiudi tutte le viste e documenti, mantieni scorciatoie desktop</translation>
    </message>
    <message>
      <source>Combine narrowband to RGB with optional OSC stars</source>
      <translation>Combina narrowband in RGB con stelle OSC opzionali</translation>
    </message>
    <message>
      <source>Combine three mono images into RGB</source>
      <translation>Combina tre immagini mono in RGB</translation>
    </message>
    <message>
      <source>Compare a stack of images by blinking</source>
      <translation>Confronta una pila di immagini lampeggiando</translation>
    </message>
    <message>
      <source>Continuum Subtract (NB - scaled broadband)</source>
      <translation>Sottrazione continuum (NB - banda larga scalata)</translation>
    </message>
    <message>
      <source>Continuum Subtract...</source>
      <translation>Sottrazione continuum...</translation>
    </message>
    <message>
      <source>Contrast Limited Adaptive Histogram Equalization</source>
      <translation>Equalizzazione istogramma adattiva a contrasto limitato</translation>
    </message>
    <message>
      <source>Convolution / Deconvolution...</source>
      <translation>Convoluzione / Deconvoluzione...</translation>
    </message>
    <message>
      <source>Copy Astrometric Solution...</source>
      <translation>Copia soluzione astrometrica...</translation>
    </message>
    <message>
      <source>Copy View (zoom/pan)</source>
      <translation>Copia vista (zoom/pan)</translation>
    </message>
    <message>
      <source>Cosmic Clarity</source>
      <translation>Cosmic Clarity</translation>
    </message>
    <message>
      <source>Cosmic Clarity Satellite...</source>
      <translation>Cosmic Clarity Satellite...</translation>
    </message>
    <message>
      <source>Cosmic Clarity UI...</source>
      <translation>Cosmic Clarity UI...</translation>
    </message>
    <message>
      <source>Create Mask...</source>
      <translation>Crea maschera...</translation>
    </message>
    <message>
      <source>Create Sample Scripts...</source>
      <translation>Crea script di esempio...</translation>
    </message>
    <message>
      <source>Create a mask from the active image</source>
      <translation>Crea una maschera dall'immagine attiva</translation>
    </message>
    <message>
      <source>Create a new mono document using the selected luminance method</source>
      <translation>Crea un nuovo documento mono usando il metodo luminanza selezionato</translation>
    </message>
    <message>
      <source>Create and run bundles of functions/shortcuts</source>
      <translation>Crea ed esegui bundle di funzioni/scorciatoie</translation>
    </message>
    <message>
      <source>Create bundles of views; drop shortcuts to apply to all</source>
      <translation>Crea bundle di viste; rilascia scorciatoie per applicare a tutti</translation>
    </message>
    <message>
      <source>Crop / rotate with handles</source>
      <translation>Ritaglia / ruota con maniglie</translation>
    </message>
    <message>
      <source>Crop...</source>
      <translation>Ritaglia...</translation>
    </message>
    <message>
      <source>Curves Editor...</source>
      <translation>Editor curve...</translation>
    </message>
    <message>
      <source>Debayer...</source>
      <translation>Debayer...</translation>
    </message>
    <message>
      <source>Demosaic a Bayer-mosaic mono image to RGB</source>
      <translation>Demosaica un'immagine mono mosaico Bayer in RGB</translation>
    </message>
    <message>
      <source>Detect exoplanet transits from time-series subs</source>
      <translation>Rileva transiti esopianeti da sub serie temporali</translation>
    </message>
    <message>
      <source>Diffraction Spikes...</source>
      <translation>Spike di diffrazione...</translation>
    </message>
    <message>
      <source>Display-Stretch</source>
      <translation>Display-Stretch</translation>
    </message>
    <message>
      <source>Documentation...</source>
      <translation>Documentazione...</translation>
    </message>
    <message>
      <source>Enhance faint/dark structures with wavelet-guided masking</source>
      <translation>Migliora strutture deboli/scure con mascheratura guidata da wavelet</translation>
    </message>
    <message>
      <source>Erosion, dilation, opening, and closing.</source>
      <translation>Erosione, dilatazione, apertura e chiusura.</translation>
    </message>
    <message>
      <source>Evaluate expressions using open view names</source>
      <translation>Valuta espressioni usando nomi viste aperte</translation>
    </message>
    <message>
      <source>Exoplanet Detector...</source>
      <translation>Rilevatore esopianeti...</translation>
    </message>
    <message>
      <source>Extract Luminance</source>
      <translation>Estrai luminanza</translation>
    </message>
    <message>
      <source>Extract R/G/B as three mono documents</source>
      <translation>Estrai R/G/B come tre documenti mono</translation>
    </message>
    <message>
      <source>FITS Header Batch Modifier...</source>
      <translation>Modificatore batch header FITS...</translation>
    </message>
    <message>
      <source>FITS Header Modifier...</source>
      <translation>Modificatore header FITS...</translation>
    </message>
    <message>
      <source>Find transients/anomalies across frames</source>
      <translation>Trova transienti/anomalie tra frame</translation>
    </message>
    <message>
      <source>Fit</source>
      <translation>Adatta</translation>
    </message>
    <message>
      <source>Fit galaxy isophotes and reveal residuals</source>
      <translation>Adatta isofote galassia e rivela residui</translation>
    </message>
    <message>
      <source>Fit image to current window</source>
      <translation>Adatta immagine alla finestra corrente</translation>
    </message>
    <message>
      <source>Flip Horizontal</source>
      <translation>Capovolgi orizzontale</translation>
    </message>
    <message>
      <source>Flip Vertical</source>
      <translation>Capovolgi verticale</translation>
    </message>
    <message>
      <source>Flip image left&lt;-&gt;right</source>
      <translation>Capovolgi immagine sinistra&lt;-&gt;destra</translation>
    </message>
    <message>
      <source>Flip image top&lt;-&gt;bottom</source>
      <translation>Capovolgi immagine alto&lt;-&gt;basso</translation>
    </message>
    <message>
      <source>Frequency Separation...</source>
      <translation>Separazione frequenze...</translation>
    </message>
    <message>
      <source>Function Bundles...</source>
      <translation>Bundle funzioni...</translation>
    </message>
    <message>
      <source>Functions</source>
      <translation>Funzioni</translation>
    </message>
    <message>
      <source>GLIMR -- Isophote Modeler...</source>
      <translation>GLIMR -- Modellatore isofote...</translation>
    </message>
    <message>
      <source>Generalized hyperbolic stretch (α/beta/gamma, LP/HP, pivot)</source>
      <translation>Stretch iperbolico generalizzato (α/beta/gamma, LP/HP, pivot)</translation>
    </message>
    <message>
      <source>Geometry</source>
      <translation>Geometria</translation>
    </message>
    <message>
      <source>Halo-B-Gon...</source>
      <translation>Halo-B-Gon...</translation>
    </message>
    <message>
      <source>Hard (target 0.50, σ 2)</source>
      <translation>Forte (target 0.50, σ 2)</translation>
    </message>
    <message>
      <source>Hard-Display-Stretch</source>
      <translation>Display-Stretch forte</translation>
    </message>
    <message>
      <source>Hide Mask Overlay</source>
      <translation>Nascondi overlay maschera</translation>
    </message>
    <message>
      <source>Histogram...</source>
      <translation>Istogramma...</translation>
    </message>
    <message>
      <source>History Explorer...</source>
      <translation>Esplora cronologia...</translation>
    </message>
    <message>
      <source>Hyperbolic Stretch...</source>
      <translation>Stretch iperbolico...</translation>
    </message>
    <message>
      <source>Identify objects in a plate-solved frame</source>
      <translation>Identifica oggetti in un frame risolto</translation>
    </message>
    <message>
      <source>Image Combine...</source>
      <translation>Combina immagini...</translation>
    </message>
    <message>
      <source>Image Inspector and Focal Plane Analysis</source>
      <translation>Ispettore immagine e analisi piano focale</translation>
    </message>
    <message>
      <source>Image Peeker...</source>
      <translation>Image Peeker...</translation>
    </message>
    <message>
      <source>Inspect and restore from the slot's history</source>
      <translation>Ispeziona e ripristina dalla cronologia dello slot</translation>
    </message>
    <message>
      <source>Inspect star PSF/HFR and flux histograms (SEP)</source>
      <translation>Ispeziona PSF/HFR stelle e istogrammi flusso (SEP)</translation>
    </message>
    <message>
      <source>Interactive blemish removal on the active view</source>
      <translation>Rimozione imperfezioni interattiva sulla vista attiva</translation>
    </message>
    <message>
      <source>Invert</source>
      <translation>Inverti</translation>
    </message>
    <message>
      <source>Invert Mask</source>
      <translation>Inverti maschera</translation>
    </message>
    <message>
      <source>Invert image colors</source>
      <translation>Inverti colori immagine</translation>
    </message>
    <message>
      <source>Linear Fit...</source>
      <translation>Fit lineare...</translation>
    </message>
    <message>
      <source>Link Pan/Zoom</source>
      <translation>Collega Pan/Zoom</translation>
    </message>
    <message>
      <source>Link RGB channels</source>
      <translation>Collega canali RGB</translation>
    </message>
    <message>
      <source>Live Stacking...</source>
      <translation>Live Stacking...</translation>
    </message>
    <message>
      <source>Live monitor and stack incoming frames</source>
      <translation>Monitora e impila frame in arrivo in tempo reale</translation>
    </message>
    <message>
      <source>Load Project...</source>
      <translation>Carica progetto...</translation>
    </message>
    <message>
      <source>Load a .sas project (views, histories, shortcuts)</source>
      <translation>Carica un progetto .sas (viste, cronologie, scorciatoie)</translation>
    </message>
    <message>
      <source>Make Display-Stretch Permanent</source>
      <translation>Rendi permanente Display-Stretch</translation>
    </message>
    <message>
      <source>Masks</source>
      <translation>Maschere</translation>
    </message>
    <message>
      <source>Match image levels using Linear Fit</source>
      <translation>Adatta livelli immagine usando Fit lineare</translation>
    </message>
    <message>
      <source>Mid (target 0.40, σ 3)</source>
      <translation>Medio (target 0.40, σ 3)</translation>
    </message>
    <message>
      <source>Morphological Operations...</source>
      <translation>Operazioni morfologiche...</translation>
    </message>
    <message>
      <source>Mosaic Master...</source>
      <translation>Mosaic Master...</translation>
    </message>
    <message>
      <source>Multiscale Decomposition...</source>
      <translation>Decomposizione multiscala...</translation>
    </message>
    <message>
      <source>Multiscale detail/residual decomposition with per-layer controls</source>
      <translation>Decomposizione multiscala dettaglio/residuo con controlli per livello</translation>
    </message>
    <message>
      <source>NB-&gt;RGB Stars...</source>
      <translation>NB-&gt;RGB Stelle...</translation>
    </message>
    <message>
      <source>Neutralize background color balance using a sampled region</source>
      <translation>Neutralizza bilanciamento colore sfondo usando una regione campionata</translation>
    </message>
    <message>
      <source>New Project</source>
      <translation>Nuovo progetto</translation>
    </message>
    <message>
      <source>Normal (target 0.30, σ 5)</source>
      <translation>Normale (target 0.30, σ 5)</translation>
    </message>
    <message>
      <source>Open Convolution / Deconvolution</source>
      <translation>Apri Convoluzione / Deconvoluzione</translation>
    </message>
    <message>
      <source>Open SFCC (Pickles + Filters + Sensor QE)</source>
      <translation>Apri SFCC (Pickles + Filtri + QE Sensore)</translation>
    </message>
    <message>
      <source>Open Scripts Folder...</source>
      <translation>Apri cartella script...</translation>
    </message>
    <message>
      <source>Open Scripts Forum (Discord)...</source>
      <translation>Apri forum script (Discord)...</translation>
    </message>
    <message>
      <source>Open User Scripts (GitHub)...</source>
      <translation>Apri script utente (GitHub)...</translation>
    </message>
    <message>
      <source>Open image(s)</source>
      <translation>Apri immagine/i</translation>
    </message>
    <message>
      <source>Open the Curves Editor for the active image</source>
      <translation>Apri l'editor curve per l'immagine attiva</translation>
    </message>
    <message>
      <source>Open the SASpro user scripts folder</source>
      <translation>Apri la cartella script utente SASpro</translation>
    </message>
    <message>
      <source>Open the Seti Astro Suite Pro online documentation</source>
      <translation>Apri la documentazione online di Seti Astro Suite Pro</translation>
    </message>
    <message>
      <source>Open the built-in script editor</source>
      <translation>Apri l'editor script integrato</translation>
    </message>
    <message>
      <source>Open...</source>
      <translation>Apri...</translation>
    </message>
    <message>
      <source>PSF Viewer...</source>
      <translation>Visualizzatore PSF...</translation>
    </message>
    <message>
      <source>Paste View</source>
      <translation>Incolla vista</translation>
    </message>
    <message>
      <source>Perfect Palette Picker...</source>
      <translation>Perfect Palette Picker...</translation>
    </message>
    <message>
      <source>Pick the perfect palette for your image</source>
      <translation>Scegli la palette perfetta per la tua immagine</translation>
    </message>
    <message>
      <source>Pixel Math...</source>
      <translation>Pixel Math...</translation>
    </message>
    <message>
      <source>Plan targets by altitude, transit time, and lunar separation</source>
      <translation>Pianifica target per altitudine, tempo transito e separazione lunare</translation>
    </message>
    <message>
      <source>Plate Solver...</source>
      <translation>Plate Solver...</translation>
    </message>
    <message>
      <source>Presets</source>
      <translation>Preset</translation>
    </message>
    <message>
      <source>RGB Align...</source>
      <translation>Allineamento RGB...</translation>
    </message>
    <message>
      <source>RGB Combination...</source>
      <translation>Combinazione RGB...</translation>
    </message>
    <message>
      <source>RGB Extract</source>
      <translation>Estrai RGB</translation>
    </message>
    <message>
      <source>Recombine Luminance...</source>
      <translation>Ricombina luminanza...</translation>
    </message>
    <message>
      <source>Redo</source>
      <translation>Ripeti</translation>
    </message>
    <message>
      <source>Reload Scripts</source>
      <translation>Ricarica script</translation>
    </message>
    <message>
      <source>Remove Active Mask</source>
      <translation>Rimuovi maschera attiva</translation>
    </message>
    <message>
      <source>Remove Gradient (GraXpert)...</source>
      <translation>Rimuovi gradiente (GraXpert)...</translation>
    </message>
    <message>
      <source>Remove Green...</source>
      <translation>Rimuovi verde...</translation>
    </message>
    <message>
      <source>Remove Pedestal</source>
      <translation>Rimuovi piedistallo</translation>
    </message>
    <message>
      <source>Remove Stars...</source>
      <translation>Rimuovi stelle...</translation>
    </message>
    <message>
      <source>Remove the active mask from the active image</source>
      <translation>Rimuovi la maschera attiva dall'immagine attiva</translation>
    </message>
    <message>
      <source>Remove those pesky halos around your stars</source>
      <translation>Rimuovi quegli aloni fastidiosi intorno alle tue stelle</translation>
    </message>
    <message>
      <source>Replace the active image's luminance from another view</source>
      <translation>Sostituisci la luminanza dell'immagine attiva da un'altra vista</translation>
    </message>
    <message>
      <source>Rescale image by a factor</source>
      <translation>Ridimensiona immagine per un fattore</translation>
    </message>
    <message>
      <source>Rescale...</source>
      <translation>Ridimensiona...</translation>
    </message>
    <message>
      <source>Rescan the scripts folder and reload .py files</source>
      <translation>Riscansiona la cartella script e ricarica file .py</translation>
    </message>
    <message>
      <source>Rotate 180°</source>
      <translation>Ruota 180°</translation>
    </message>
    <message>
      <source>Rotate 90° Clockwise</source>
      <translation>Ruota 90° orario</translation>
    </message>
    <message>
      <source>Rotate 90° Counterclockwise</source>
      <translation>Ruota 90° antiorario</translation>
    </message>
    <message>
      <source>Rotate image 180°</source>
      <translation>Ruota immagine 180°</translation>
    </message>
    <message>
      <source>Rotate image 90° clockwise</source>
      <translation>Ruota immagine 90° in senso orario</translation>
    </message>
    <message>
      <source>Rotate image 90° counterclockwise</source>
      <translation>Ruota immagine 90° in senso antiorario</translation>
    </message>
    <message>
      <source>Run GraXpert background extraction on the active image</source>
      <translation>Esegui estrazione sfondo GraXpert sull'immagine attiva</translation>
    </message>
    <message>
      <source>Run star removal on the active image</source>
      <translation>Esegui rimozione stelle sull'immagine attiva</translation>
    </message>
    <message>
      <source>SCNR-style green channel removal.</source>
      <translation>Rimozione canale verde stile SCNR.</translation>
    </message>
    <message>
      <source>Save As...</source>
      <translation>Salva come...</translation>
    </message>
    <message>
      <source>Save Project...</source>
      <translation>Salva progetto...</translation>
    </message>
    <message>
      <source>Save all views, histories, and shortcuts to a .sas file</source>
      <translation>Salva tutte le viste, cronologie e scorciatoie in un file .sas</translation>
    </message>
    <message>
      <source>Save the active image</source>
      <translation>Salva l'immagine attiva</translation>
    </message>
    <message>
      <source>Script Editor...</source>
      <translation>Editor script...</translation>
    </message>
    <message>
      <source>Selective Color Correction...</source>
      <translation>Correzione colore selettiva...</translation>
    </message>
    <message>
      <source>Set Sigma...</source>
      <translation>Imposta Sigma...</translation>
    </message>
    <message>
      <source>Set Target Median...</source>
      <translation>Imposta mediana target...</translation>
    </message>
    <message>
      <source>Set the sigma for Display-Stretch (e.g., 5.0)</source>
      <translation>Imposta il sigma per Display-Stretch (es. 5.0)</translation>
    </message>
    <message>
      <source>Set the target median for Display-Stretch (e.g., 0.30)</source>
      <translation>Imposta la mediana target per Display-Stretch (es. 0.30)</translation>
    </message>
    <message>
      <source>Show Mask Overlay</source>
      <translation>Mostra overlay maschera</translation>
    </message>
    <message>
      <source>Signature / Insert...</source>
      <translation>Firma / Inserisci...</translation>
    </message>
    <message>
      <source>Smart Grid</source>
      <translation>Griglia intelligente</translation>
    </message>
    <message>
      <source>Solve WCS/SIP for the active image or a file</source>
      <translation>Risolvi WCS/SIP per l'immagine attiva o un file</translation>
    </message>
    <message>
      <source>Spectral Flux Color Calibration...</source>
      <translation>Calibrazione colore flusso spettrale...</translation>
    </message>
    <message>
      <source>Split into LF/HF and enhance HF (scale, wavelet, denoise)</source>
      <translation>Dividi in LF/HF e migliora HF (scala, wavelet, denoise)</translation>
    </message>
    <message>
      <source>Split the workspace into equal horizontal rows</source>
      <translation>Dividi lo spazio di lavoro in righe orizzontali uguali</translation>
    </message>
    <message>
      <source>Split the workspace into equal vertical columns</source>
      <translation>Dividi lo spazio di lavoro in colonne verticali uguali</translation>
    </message>
    <message>
      <source>Stacking Suite...</source>
      <translation>Stacking Suite...</translation>
    </message>
    <message>
      <source>Stacking! Darks, Flats, Lights, Calibration, Drizzle, and more!!</source>
      <translation>Stacking! Dark, Flat, Light, Calibrazione, Drizzle e altro!!</translation>
    </message>
    <message>
      <source>Star Stretch...</source>
      <translation>Star Stretch...</translation>
    </message>
    <message>
      <source>Star Stuff</source>
      <translation>Stelle</translation>
    </message>
    <message>
      <source>Statistical Stretch...</source>
      <translation>Stretch statistico...</translation>
    </message>
    <message>
      <source>Stellar Alignment...</source>
      <translation>Allineamento stellare...</translation>
    </message>
    <message>
      <source>Stellar Register...</source>
      <translation>Registrazione stellare...</translation>
    </message>
    <message>
      <source>Stretch the image using median/SD statistics</source>
      <translation>Stretcha l'immagine usando statistiche mediana/SD</translation>
    </message>
    <message>
      <source>Subtract per-channel minimum.
Click: active view
Alt+Drag: drop onto a view</source>
      <translation>Sottrai minimo per canale.
Click: vista attiva
Alt+Trascina: rilascia su una vista</translation>
    </message>
    <message>
      <source>Supernova / Asteroid Hunter...</source>
      <translation>Cacciatore Supernove / Asteroidi...</translation>
    </message>
    <message>
      <source>Tile Horizontally</source>
      <translation>Affianca orizzontalmente</translation>
    </message>
    <message>
      <source>Tile Vertically</source>
      <translation>Affianca verticalmente</translation>
    </message>
    <message>
      <source>Tile Views</source>
      <translation>Affianca viste</translation>
    </message>
    <message>
      <source>Tile all subwindows</source>
      <translation>Affianca tutte le sottofinestre</translation>
    </message>
    <message>
      <source>Toggle display auto-stretch for the active window</source>
      <translation>Attiva/disattiva auto-stretch per la finestra attiva</translation>
    </message>
    <message>
      <source>Toggle hard profile for Display-Stretch (H)</source>
      <translation>Attiva/disattiva profilo forte per Display-Stretch (H)</translation>
    </message>
    <message>
      <source>Tools</source>
      <translation>Strumenti</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>View Bundles...</source>
      <translation>Visualizza bundle...</translation>
    </message>
    <message>
      <source>View histogram and basic stats for the active image</source>
      <translation>Visualizza istogramma e statistiche base per l'immagine attiva</translation>
    </message>
    <message>
      <source>View/Edit FITS headers</source>
      <translation>Visualizza/Modifica header FITS</translation>
    </message>
    <message>
      <source>Wave-scale HDR with luminance-masked starlet</source>
      <translation>HDR wave-scale con starlet mascherato in luminanza</translation>
    </message>
    <message>
      <source>WaveScale Dark Enhancer...</source>
      <translation>WaveScale Dark Enhancer...</translation>
    </message>
    <message>
      <source>WaveScale HDR...</source>
      <translation>WaveScale HDR...</translation>
    </message>
    <message>
      <source>What's In My Image...</source>
      <translation>What's In My Image...</translation>
    </message>
    <message>
      <source>What's In My Sky...</source>
      <translation>What's In My Sky...</translation>
    </message>
    <message>
      <source>What's In My...</source>
      <translation>What's In My...</translation>
    </message>
    <message>
      <source>White Balance...</source>
      <translation>Bilanciamento bianco...</translation>
    </message>
    <message>
      <source>Write a ready-to-edit sample script into the scripts folder</source>
      <translation>Scrivi uno script di esempio pronto da modificare nella cartella script</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
    <message>
      <source>Zoom in</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom out</source>
      <translation>Riduci</translation>
    </message>
    <message>
      <source>Zoom to 100% (pixel-for-pixel)</source>
      <translation>Zoom al 100% (pixel per pixel)</translation>
    </message>
  </context>
  <context>
    <name>UpdateMixin</name>
    <message>
      <source>A new version ({0}) is available!</source>
      <translation>Una nuova versione ({0}) è disponibile!</translation>
    </message>
    <message>
      <source>A new version is available</source>
      <translation>È disponibile una nuova versione</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Controlla aggiornamenti</translation>
    </message>
    <message>
      <source>Checking for updates...</source>
      <translation>Controllo aggiornamenti...</translation>
    </message>
    <message>
      <source>Could not download update:
{0}</source>
      <translation>Impossibile scaricare aggiornamento:
{0}</translation>
    </message>
    <message>
      <source>Could not extract update zip:
{0}</source>
      <translation>Impossibile estrarre zip aggiornamento:
{0}</translation>
    </message>
    <message>
      <source>Could not save update to disk:
{0}</source>
      <translation>Impossibile salvare aggiornamento su disco:
{0}</translation>
    </message>
    <message>
      <source>Could not start installer:
{0}</source>
      <translation>Impossibile avviare installer:
{0}</translation>
    </message>
    <message>
      <source>Current version</source>
      <translation>Versione corrente</translation>
    </message>
    <message>
      <source>Download</source>
      <translation>Scarica</translation>
    </message>
    <message>
      <source>Download and install</source>
      <translation>Scarica e installa</translation>
    </message>
    <message>
      <source>Download complete</source>
      <translation>Download completato</translation>
    </message>
    <message>
      <source>Download failed</source>
      <translation>Download fallito</translation>
    </message>
    <message>
      <source>Downloaded ZIP did not contain an .exe installer.
Folder: {0}</source>
      <translation>Lo ZIP scaricato non contiene un installer .exe.
Cartella: {0}</translation>
    </message>
    <message>
      <source>Downloading update...</source>
      <translation>Download aggiornamento...</translation>
    </message>
    <message>
      <source>Downloading update... {0:.1f} KB / {1:.1f} KB</source>
      <translation>Download aggiornamento... {0:.1f} KB / {1:.1f} KB</translation>
    </message>
    <message>
      <source>Failed to check for updates</source>
      <translation>Controllo aggiornamenti fallito</translation>
    </message>
    <message>
      <source>Installing update...</source>
      <translation>Installazione aggiornamento...</translation>
    </message>
    <message>
      <source>Invalid response from server</source>
      <translation>Risposta non valida dal server</translation>
    </message>
    <message>
      <source>Network error</source>
      <translation>Errore di rete</translation>
    </message>
    <message>
      <source>New version</source>
      <translation>Nuova versione</translation>
    </message>
    <message>
      <source>No download link available for this platform.</source>
      <translation>Nessun link di download disponibile per questa piattaforma.</translation>
    </message>
    <message>
      <source>No updates available</source>
      <translation>Nessun aggiornamento disponibile</translation>
    </message>
    <message>
      <source>Release Notes:
{0}</source>
      <translation>Note di Rilascio:
{0}</translation>
    </message>
    <message>
      <source>Release notes</source>
      <translation>Note di rilascio</translation>
    </message>
    <message>
      <source>Remind me later</source>
      <translation>Ricordamelo dopo</translation>
    </message>
    <message>
      <source>Restart later</source>
      <translation>Riavvia dopo</translation>
    </message>
    <message>
      <source>Restart now</source>
      <translation>Riavvia ora</translation>
    </message>
    <message>
      <source>Restart required</source>
      <translation>Riavvio richiesto</translation>
    </message>
    <message>
      <source>Run Installer</source>
      <translation>Esegui Installer</translation>
    </message>
    <message>
      <source>Skip this version</source>
      <translation>Salta questa versione</translation>
    </message>
    <message>
      <source>The update has been downloaded.

Run the installer now? (SAS will close.)</source>
      <translation>L'aggiornamento è stato scaricato.

Eseguire l'installer ora? (SAS si chiuderà.)</translation>
    </message>
    <message>
      <source>Unable to check for updates.

{err}</source>
      <translation>Impossibile verificare aggiornamenti.

{err}</translation>
    </message>
    <message>
      <source>Up to Date</source>
      <translation>Aggiornato</translation>
    </message>
    <message>
      <source>Update Available</source>
      <translation>Aggiornamento Disponibile</translation>
    </message>
    <message>
      <source>Update Check Failed</source>
      <translation>Controllo Aggiornamento Fallito</translation>
    </message>
    <message>
      <source>Update Failed</source>
      <translation>Aggiornamento Fallito</translation>
    </message>
    <message>
      <source>Update JSON is invalid.

{je}</source>
      <translation>JSON aggiornamento non valido.

{je}</translation>
    </message>
    <message>
      <source>Update JSON missing the 'version' field.</source>
      <translation>JSON aggiornamento mancante del campo 'version'.</translation>
    </message>
    <message>
      <source>Update available</source>
      <translation>Aggiornamento disponibile</translation>
    </message>
    <message>
      <source>Update available: {0}</source>
      <translation>Aggiornamento disponibile: {0}</translation>
    </message>
    <message>
      <source>Update installed</source>
      <translation>Aggiornamento installato</translation>
    </message>
    <message>
      <source>What's new</source>
      <translation>Novità</translation>
    </message>
    <message>
      <source>You are running the latest version</source>
      <translation>Stai usando l'ultima versione</translation>
    </message>
    <message>
      <source>You're already running the latest version.</source>
      <translation>Stai già eseguendo l'ultima versione.</translation>
    </message>
  </context>
  <context>
    <name>ViewBundleDialog</name>
    <message>
      <source>Add Directory (Recursive)…</source>
      <translation>Aggiungi Cartella (Ricorsivo)…</translation>
    </message>
    <message>
      <source>Add Files…</source>
      <translation>Aggiungi File…</translation>
    </message>
    <message>
      <source>Add from Open…</source>
      <translation>Aggiungi da Aperte…</translation>
    </message>
    <message>
      <source>Clear Views</source>
      <translation>Pulisci Viste</translation>
    </message>
    <message>
      <source>Compress to Chip</source>
      <translation>Comprimi in Chip</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Elimina</translation>
    </message>
    <message>
      <source>Duplicate</source>
      <translation>Duplica</translation>
    </message>
    <message>
      <source>New Bundle</source>
      <translation>Nuovo Pacchetto</translation>
    </message>
    <message>
      <source>Remove Selected</source>
      <translation>Rimuovi Selezionati</translation>
    </message>
    <message>
      <source>View Bundles</source>
      <translation>Visualizza Pacchetti</translation>
    </message>
    <message>
      <source>Choose views to add:</source>
      <translation>Scegli viste da aggiungere:</translation>
    </message>
    <message>
      <source>Select all open views</source>
      <translation>Seleziona tutte le viste aperte</translation>
    </message>
    <message>
      <source>Drop views here to add • Drop shortcuts here to apply to THIS bundle</source>
      <translation>Trascina qui le viste per aggiungere • Trascina qui le scorciatoie per applicare a QUESTO pacchetto</translation>
    </message>
    <message>
      <source>Bundles</source>
      <translation>Pacchetti</translation>
    </message>
    <message>
      <source>Views in Selected Bundle</source>
      <translation>Viste nel Pacchetto Selezionato</translation>
    </message>
    <message>
      <source>Delete Chip</source>
      <translation>Elimina Chip</translation>
    </message>
    <message>
      <source>Drag to move · Ctrl+drag to apply · Drop views/shortcuts here</source>
      <translation>Trascina per spostare · Ctrl+trascina per applicare · Trascina qui viste/scorciatoie</translation>
    </message>
  </context>
  <context>
    <name>WhatsInMyImage</name>
    <message>
      <source>Analyze Image</source>
      <translation>Analizza immagine</translation>
    </message>
    <message>
      <source>Analyzing...</source>
      <translation>Analisi...</translation>
    </message>
    <message>
      <source>Annotation color</source>
      <translation>Colore annotazione</translation>
    </message>
    <message>
      <source>Annotation size</source>
      <translation>Dimensione annotazione</translation>
    </message>
    <message>
      <source>Annotation style</source>
      <translation>Stile annotazione</translation>
    </message>
    <message>
      <source>Arrow</source>
      <translation>Freccia</translation>
    </message>
    <message>
      <source>Asteroids</source>
      <translation>Asteroidi</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Cerchio</translation>
    </message>
    <message>
      <source>Comets</source>
      <translation>Comete</translation>
    </message>
    <message>
      <source>Constellation</source>
      <translation>Costellazione</translation>
    </message>
    <message>
      <source>Crosshair</source>
      <translation>Mirino</translation>
    </message>
    <message>
      <source>Dark nebulae</source>
      <translation>Nebulose oscure</translation>
    </message>
    <message>
      <source>Distance</source>
      <translation>Distanza</translation>
    </message>
    <message>
      <source>Export catalog</source>
      <translation>Esporta catalogo</translation>
    </message>
    <message>
      <source>Found Objects</source>
      <translation>Oggetti trovati</translation>
    </message>
    <message>
      <source>Galaxies</source>
      <translation>Galassie</translation>
    </message>
    <message>
      <source>Globular clusters</source>
      <translation>Ammassi globulari</translation>
    </message>
    <message>
      <source>Hide annotations</source>
      <translation>Nascondi annotazioni</translation>
    </message>
    <message>
      <source>Label</source>
      <translation>Etichetta</translation>
    </message>
    <message>
      <source>Magnitude</source>
      <translation>Magnitudine</translation>
    </message>
    <message>
      <source>Maximum magnitude</source>
      <translation>Magnitudine massima</translation>
    </message>
    <message>
      <source>Minimum magnitude</source>
      <translation>Magnitudine minima</translation>
    </message>
    <message>
      <source>Nebulae</source>
      <translation>Nebulose</translation>
    </message>
    <message>
      <source>No WCS data</source>
      <translation>Nessun dato WCS</translation>
    </message>
    <message>
      <source>No objects found</source>
      <translation>Nessun oggetto trovato</translation>
    </message>
    <message>
      <source>Object Name</source>
      <translation>Nome oggetto</translation>
    </message>
    <message>
      <source>Object types</source>
      <translation>Tipi oggetti</translation>
    </message>
    <message>
      <source>Open clusters</source>
      <translation>Ammassi aperti</translation>
    </message>
    <message>
      <source>Planetary nebulae</source>
      <translation>Nebulose planetarie</translation>
    </message>
    <message>
      <source>Please plate solve the image first</source>
      <translation>Prima effettua il plate solve dell'immagine</translation>
    </message>
    <message>
      <source>Quasars</source>
      <translation>Quasar</translation>
    </message>
    <message>
      <source>RA/Dec</source>
      <translation>AR/Dec</translation>
    </message>
    <message>
      <source>Search radius</source>
      <translation>Raggio ricerca</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Impostazioni</translation>
    </message>
    <message>
      <source>Show annotations</source>
      <translation>Mostra annotazioni</translation>
    </message>
    <message>
      <source>Show distance</source>
      <translation>Mostra distanza</translation>
    </message>
    <message>
      <source>Show magnitude</source>
      <translation>Mostra magnitudine</translation>
    </message>
    <message>
      <source>Show on image</source>
      <translation>Mostra sull'immagine</translation>
    </message>
    <message>
      <source>Show type</source>
      <translation>Mostra tipo</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Dimensione</translation>
    </message>
    <message>
      <source>Star clusters</source>
      <translation>Ammassi stellari</translation>
    </message>
    <message>
      <source>Stars</source>
      <translation>Stelle</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Tipo</translation>
    </message>
    <message>
      <source>What's In My Image</source>
      <translation>What's In My Image</translation>
    </message>
  </context>
  <context>
    <name>WhatsInMySky</name>
    <message>
      <source>Add to imaging plan</source>
      <translation>Aggiungi a piano imaging</translation>
    </message>
    <message>
      <source>Altitude</source>
      <translation>Altitudine</translation>
    </message>
    <message>
      <source>Altitude chart</source>
      <translation>Carta altitudine</translation>
    </message>
    <message>
      <source>Astronomical twilight</source>
      <translation>Crepuscolo astronomico</translation>
    </message>
    <message>
      <source>Azimuth</source>
      <translation>Azimut</translation>
    </message>
    <message>
      <source>Civil twilight</source>
      <translation>Crepuscolo civile</translation>
    </message>
    <message>
      <source>Custom time</source>
      <translation>Ora personalizzata</translation>
    </message>
    <message>
      <source>Dark time</source>
      <translation>Tempo buio</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Data</translation>
    </message>
    <message>
      <source>Date &amp; Time</source>
      <translation>Data e ora</translation>
    </message>
    <message>
      <source>Enter coordinates</source>
      <translation>Inserisci coordinate</translation>
    </message>
    <message>
      <source>Excellent</source>
      <translation>Eccellente</translation>
    </message>
    <message>
      <source>Export list</source>
      <translation>Esporta lista</translation>
    </message>
    <message>
      <source>Fair</source>
      <translation>Discreto</translation>
    </message>
    <message>
      <source>Filter by type</source>
      <translation>Filtra per tipo</translation>
    </message>
    <message>
      <source>First quarter</source>
      <translation>Primo quarto</translation>
    </message>
    <message>
      <source>Full moon</source>
      <translation>Luna piena</translation>
    </message>
    <message>
      <source>Good</source>
      <translation>Buono</translation>
    </message>
    <message>
      <source>Illumination</source>
      <translation>Illuminazione</translation>
    </message>
    <message>
      <source>Imaging time</source>
      <translation>Tempo imaging</translation>
    </message>
    <message>
      <source>Imaging window</source>
      <translation>Finestra imaging</translation>
    </message>
    <message>
      <source>Last quarter</source>
      <translation>Ultimo quarto</translation>
    </message>
    <message>
      <source>Latitude</source>
      <translation>Latitudine</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Posizione</translation>
    </message>
    <message>
      <source>Longitude</source>
      <translation>Longitudine</translation>
    </message>
    <message>
      <source>Maximum moon separation</source>
      <translation>Separazione Luna massima</translation>
    </message>
    <message>
      <source>Minimum altitude</source>
      <translation>Altitudine minima</translation>
    </message>
    <message>
      <source>Minimum transit altitude</source>
      <translation>Altitudine transito minima</translation>
    </message>
    <message>
      <source>Moon Separation</source>
      <translation>Separazione Luna</translation>
    </message>
    <message>
      <source>Moon phase</source>
      <translation>Fase lunare</translation>
    </message>
    <message>
      <source>Moon separation</source>
      <translation>Separazione Luna</translation>
    </message>
    <message>
      <source>Moonrise</source>
      <translation>Sorgere Luna</translation>
    </message>
    <message>
      <source>Moonset</source>
      <translation>Tramonto Luna</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Nome</translation>
    </message>
    <message>
      <source>Nautical twilight</source>
      <translation>Crepuscolo nautico</translation>
    </message>
    <message>
      <source>New moon</source>
      <translation>Luna nuova</translation>
    </message>
    <message>
      <source>Not visible</source>
      <translation>Non visibile</translation>
    </message>
    <message>
      <source>Object Name</source>
      <translation>Nome oggetto</translation>
    </message>
    <message>
      <source>Poor</source>
      <translation>Scarso</translation>
    </message>
    <message>
      <source>Rise Time</source>
      <translation>Ora sorgere</translation>
    </message>
    <message>
      <source>Search</source>
      <translation>Cerca</translation>
    </message>
    <message>
      <source>Search targets</source>
      <translation>Cerca target</translation>
    </message>
    <message>
      <source>Set Time</source>
      <translation>Ora tramonto</translation>
    </message>
    <message>
      <source>Show chart</source>
      <translation>Mostra carta</translation>
    </message>
    <message>
      <source>Sky chart</source>
      <translation>Carta celeste</translation>
    </message>
    <message>
      <source>Sort by</source>
      <translation>Ordina per</translation>
    </message>
    <message>
      <source>Sunset</source>
      <translation>Tramonto</translation>
    </message>
    <message>
      <source>Time</source>
      <translation>Ora</translation>
    </message>
    <message>
      <source>Time Zone</source>
      <translation>Fuso orario</translation>
    </message>
    <message>
      <source>Tomorrow night</source>
      <translation>Domani sera</translation>
    </message>
    <message>
      <source>Tonight</source>
      <translation>Stasera</translation>
    </message>
    <message>
      <source>Transit Time</source>
      <translation>Ora transito</translation>
    </message>
    <message>
      <source>Transit time</source>
      <translation>Ora transito</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Tipo</translation>
    </message>
    <message>
      <source>Use current location</source>
      <translation>Usa posizione corrente</translation>
    </message>
    <message>
      <source>Use current time</source>
      <translation>Usa ora corrente</translation>
    </message>
    <message>
      <source>Visibility</source>
      <translation>Visibilità</translation>
    </message>
    <message>
      <source>Visible Objects</source>
      <translation>Oggetti visibili</translation>
    </message>
    <message>
      <source>Waning</source>
      <translation>Calante</translation>
    </message>
    <message>
      <source>Waxing</source>
      <translation>Crescente</translation>
    </message>
    <message>
      <source>What's In My Sky</source>
      <translation>What's In My Sky</translation>
    </message>
  </context>
  <context>
    <name>WindowShelf</name>
    <message>
      <source>Minimized Views</source>
      <translation>Viste Ridotte a Icona</translation>
    </message>
    <message>
      <source>Untitled</source>
      <translation>Senza titolo</translation>
    </message>
  </context>
  <context>
    <name>_AstrobinIdDelegate</name>
    <message>
      <source>Enter AstroBin ID</source>
      <translation>Inserisci ID AstroBin</translation>
    </message>
    <message>
      <source>Invalid ID format</source>
      <translation>Formato ID non valido</translation>
    </message>
    <message>
      <source>e.g. 4408</source>
      <translation>es. 4408</translation>
    </message>
  </context>
  <context>
    <name>_DragTab</name>
    <message>
      <source>Close all tabs</source>
      <translation>Chiudi tutte le schede</translation>
    </message>
    <message>
      <source>Close other tabs</source>
      <translation>Chiudi altre schede</translation>
    </message>
    <message>
      <source>Close tab</source>
      <translation>Chiudi scheda</translation>
    </message>
    <message>
      <source>Close tabs to the right</source>
      <translation>Chiudi schede a destra</translation>
    </message>
    <message>
      <source>Drag to duplicate/copy view.
Hold Alt while dragging to LINK this view with another (live pan/zoom sync).
Hold Shift while dragging to drop this image as a mask onto another view.
Hold Ctrl while dragging to copy the astrometric solution (WCS) to another view.</source>
      <translation>Trascina per duplicare/copiare vista.
Tieni Alt mentre trascini per COLLEGARE questa vista con un'altra (sincronizzazione pan/zoom live).
Tieni Shift mentre trascini per rilasciare questa immagine come maschera su un'altra vista.
Tieni Ctrl mentre trascini per copiare la soluzione astrometrica (WCS) su un'altra vista.</translation>
    </message>
    <message>
      <source>Drag to reorder</source>
      <translation>Trascina per riordinare</translation>
    </message>
  </context>
  <context>
    <name>_MaskWindow</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Blur</source>
      <translation>Sfoca</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Contract</source>
      <translation>Contrai</translation>
    </message>
    <message>
      <source>Dark Mask</source>
      <translation>Maschera Scura</translation>
    </message>
    <message>
      <source>Expand</source>
      <translation>Espandi</translation>
    </message>
    <message>
      <source>Feather</source>
      <translation>Sfuma</translation>
    </message>
    <message>
      <source>Invert</source>
      <translation>Inverti</translation>
    </message>
    <message>
      <source>Mask</source>
      <translation>Maschera</translation>
    </message>
    <message>
      <source>Mask Preview</source>
      <translation>Anteprima maschera</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Reimposta</translation>
    </message>
  </context>
  <context>
    <name>_Progress</name>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Cancelled</source>
      <translation>Annullato</translation>
    </message>
    <message>
      <source>Completed</source>
      <translation>Completato</translation>
    </message>
    <message>
      <source>Failed</source>
      <translation>Fallito</translation>
    </message>
    <message>
      <source>Please wait...</source>
      <translation>Attendere prego...</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation>Progresso</translation>
    </message>
  </context>
  <context>
    <name>_SimplePickDialog</name>
    <message>
      <source>1:1</source>
      <translation>1:1</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Click the comet center</source>
      <translation>Clicca sul centro della cometa</translation>
    </message>
    <message>
      <source>Disable Autostretch</source>
      <translation>Disabilita Autostretch</translation>
    </message>
    <message>
      <source>Enable Autostretch</source>
      <translation>Abilita Autostretch</translation>
    </message>
    <message>
      <source>Fit</source>
      <translation>Adatta</translation>
    </message>
    <message>
      <source>OK</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Select</source>
      <translation>Seleziona</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
  </context>
  <context>
    <name>_SolveStatusPopup</name>
    <message>
      <source>Apply WCS</source>
      <translation>Applica WCS</translation>
    </message>
    <message>
      <source>Cancelled</source>
      <translation>Annullato</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Copy to clipboard</source>
      <translation>Copia negli appunti</translation>
    </message>
    <message>
      <source>Dec</source>
      <translation>Dec</translation>
    </message>
    <message>
      <source>Failed</source>
      <translation>Fallito</translation>
    </message>
    <message>
      <source>Field size</source>
      <translation>Dimensione campo</translation>
    </message>
    <message>
      <source>Hide</source>
      <translation>Nascondi</translation>
    </message>
    <message>
      <source>Plate Solve Status</source>
      <translation>Stato Plate Solve</translation>
    </message>
    <message>
      <source>Plate Solving</source>
      <translation>Plate Solving</translation>
    </message>
    <message>
      <source>RA</source>
      <translation>AR</translation>
    </message>
    <message>
      <source>RMS error</source>
      <translation>Errore RMS</translation>
    </message>
    <message>
      <source>Rotation</source>
      <translation>Rotazione</translation>
    </message>
    <message>
      <source>Scale</source>
      <translation>Scala</translation>
    </message>
    <message>
      <source>Solving...</source>
      <translation>Risoluzione...</translation>
    </message>
    <message>
      <source>Stars matched</source>
      <translation>Stelle corrispondenti</translation>
    </message>
    <message>
      <source>Starting…</source>
      <translation>Avvio…</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Successo</translation>
    </message>
    <message>
      <source>View in Aladin</source>
      <translation>Visualizza in Aladin</translation>
    </message>
  </context>
  <context>
    <name>StatusLogDock</name>
    <message>
      <source>Stacking Log</source>
      <translation>Log di Stacking</translation>
    </message>
  </context>
  <context>
    <name>WIMIDialog</name>
    <message>
      <source>Add Text</source>
      <translation>Aggiungi Testo</translation>
    </message>
    <message>
      <source>Clear Annotations</source>
      <translation>Cancella Annotazioni</translation>
    </message>
    <message>
      <source>Clear Results</source>
      <translation>Cancella Risultati</translation>
    </message>
    <message>
      <source>Copy Object Information</source>
      <translation>Copia Informazioni Oggetto</translation>
    </message>
    <message>
      <source>Delete Selected Items</source>
      <translation>Elimina Elementi Selezionati</translation>
    </message>
    <message>
      <source>Delete Selected Object(s)</source>
      <translation>Elimina Oggetto Selezionato</translation>
    </message>
    <message>
      <source>Legend</source>
      <translation>Legenda</translation>
    </message>
    <message>
      <source>Open Website</source>
      <translation>Apri Sito Web</translation>
    </message>
    <message>
      <source>Select Annotation Color</source>
      <translation>Seleziona Colore Annotazione</translation>
    </message>
    <message>
      <source>Select Annotation Font</source>
      <translation>Seleziona Font Annotazione</translation>
    </message>
    <message>
      <source>Select Color</source>
      <translation>Seleziona Colore</translation>
    </message>
    <message>
      <source>Select Font</source>
      <translation>Seleziona Font</translation>
    </message>
    <message>
      <source>Show Annotation Tools</source>
      <translation>Mostra Strumenti Annotazione</translation>
    </message>
    <message>
      <source>Show Object Names</source>
      <translation>Mostra Nomi Oggetti</translation>
    </message>
    <message>
      <source>Show Visible Objects Only</source>
      <translation>Mostra Solo Oggetti Visibili</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Zoom to Object</source>
      <translation>Zoom sull'Oggetto</translation>
    </message>
    <message>
      <source>Copy RA/Dec to Clipboard</source>
      <translation>Copia AR/Dec negli appunti</translation>
    </message>
    <message>
      <source>Save Plate Solved Fits</source>
      <translation>Salva FITS risolto</translation>
    </message>
    <message>
      <source>RA: N/A</source>
      <translation>AR: N/D</translation>
    </message>
    <message>
      <source>Dec: N/A</source>
      <translation>Dec: N/D</translation>
    </message>
    <message>
      <source>Orientation: N/A°</source>
      <translation>Orientamento: N/D°</translation>
    </message>
    <message>
      <source>Mini Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Zoom In</source>
      <translation>Ingrandisci</translation>
    </message>
    <message>
      <source>Zoom Out</source>
      <translation>Riduci</translation>
    </message>
    <message>
      <source>Save Annotated Image</source>
      <translation>Salva immagine annotata</translation>
    </message>
    <message>
      <source>Save Collage of Objects</source>
      <translation>Salva collage oggetti</translation>
    </message>
    <message>
      <source>3D Distance Model</source>
      <translation>Modello distanze 3D</translation>
    </message>
    <message>
      <source>H-R Diagram</source>
      <translation>Diagramma H-R</translation>
    </message>
    <message>
      <source>Objects Found: 0</source>
      <translation>Oggetti trovati: 0</translation>
    </message>
    <message>
      <source>Right Click a Row for More Options</source>
      <translation>Tasto destro su una riga per opzioni</translation>
    </message>
    <message>
      <source>Ctrl+Click to add items, Alt+Click to measure distance</source>
      <translation>Ctrl+Click per aggiungere, Alt+Click per misurare</translation>
    </message>
    <message>
      <source>Draw Ellipse</source>
      <translation>Disegna ellisse</translation>
    </message>
    <message>
      <source>Freehand (Lasso)</source>
      <translation>Mano libera (Lasso)</translation>
    </message>
    <message>
      <source>Draw Rectangle</source>
      <translation>Disegna rettangolo</translation>
    </message>
    <message>
      <source>Draw Arrow</source>
      <translation>Disegna freccia</translation>
    </message>
    <message>
      <source>Place Celestial Compass</source>
      <translation>Posiziona bussola celeste</translation>
    </message>
    <message>
      <source>Advanced Search Parameters</source>
      <translation>Parametri ricerca avanzata</translation>
    </message>
    <message>
      <source>Object Type</source>
      <translation>Tipo oggetto</translation>
    </message>
    <message>
      <source>Description</source>
      <translation>Descrizione</translation>
    </message>
    <message>
      <source>Toggle All</source>
      <translation>Seleziona/Deseleziona tutto</translation>
    </message>
    <message>
      <source>Save List…</source>
      <translation>Salva lista…</translation>
    </message>
    <message>
      <source>Load List…</source>
      <translation>Carica lista…</translation>
    </message>
    <message>
      <source>Search Defined Region</source>
      <translation>Cerca regione definita</translation>
    </message>
    <message>
      <source>Search Entire Image</source>
      <translation>Cerca intera immagine</translation>
    </message>
    <message>
      <source>Minor Planets / Comets</source>
      <translation>Pianeti minori / Comete</translation>
    </message>
    <message>
      <source>Database: not downloaded</source>
      <translation>Database: non scaricato</translation>
    </message>
    <message>
      <source>Download Catalog</source>
      <translation>Scarica catalogo</translation>
    </message>
    <message>
      <source>Search Minor Bodies</source>
      <translation>Cerca corpi minori</translation>
    </message>
    <message>
      <source>Search scope:</source>
      <translation>Ambito ricerca:</translation>
    </message>
    <message>
      <source>Defined Region</source>
      <translation>Regione definita</translation>
    </message>
    <message>
      <source>Entire Image</source>
      <translation>Intera immagine</translation>
    </message>
    <message>
      <source>Asteroid H ≤</source>
      <translation>Asteroidi H ≤</translation>
    </message>
    <message>
      <source>Max asteroids:</source>
      <translation>Max asteroidi:</translation>
    </message>
    <message>
      <source>Comet H ≤</source>
      <translation>Comete H ≤</translation>
    </message>
    <message>
      <source>Max comets:</source>
      <translation>Max comete:</translation>
    </message>
    <message>
      <source>Target (optional):</source>
      <translation>Target (opzionale):</translation>
    </message>
    <message>
      <source>Count Objects Brighter Than Limits</source>
      <translation>Conta oggetti più luminosi dei limiti</translation>
    </message>
    <message>
      <source>Time offset (hours):</source>
      <translation>Offset orario (ore):</translation>
    </message>
    <message>
      <source>Caution - Deep Vizier Search</source>
      <translation>Attenzione - Ricerca Deep Vizier</translation>
    </message>
    <message>
      <source>Search M.A.S.T Database</source>
      <translation>Cerca database M.A.S.T</translation>
    </message>
    <message>
      <source>Load Image File</source>
      <translation>Carica File Immagine</translation>
    </message>
    <message>
      <source>Load from View</source>
      <translation>Carica da Vista</translation>
    </message>
    <message>
      <source>AutoStretch</source>
      <translation>AutoStretch</translation>
    </message>
    <message>
      <source>Shift+Click to define a search region</source>
      <translation>Shift+Click per definire regione di ricerca</translation>
    </message>
    <message>
      <source>Query Simbad</source>
      <translation>Interroga Simbad</translation>
    </message>
    <message>
      <source>Save CSV</source>
      <translation>Salva CSV</translation>
    </message>
    <message>
      <source>Advanced Search</source>
      <translation>Ricerca Avanzata</translation>
    </message>
    <message>
      <source>Status: Ready</source>
      <translation>Stato: Pronto</translation>
    </message>
  </context>
  <context>
    <name>WhatsInMySkyDialog</name>
    <message>
      <source>What's In My Sky</source>
      <translation>Cosa c'è nel mio cielo</translation>
    </message>
    <message>
      <source>Latitude:</source>
      <translation>Latitudine:</translation>
    </message>
    <message>
      <source>Longitude (E+, W−):</source>
      <translation>Longitudine (E+, W−):</translation>
    </message>
    <message>
      <source>Date (YYYY-MM-DD):</source>
      <translation>Data (AAAA-MM-GG):</translation>
    </message>
    <message>
      <source>Time (HH:MM):</source>
      <translation>Ora (HH:MM):</translation>
    </message>
    <message>
      <source>Time Zone:</source>
      <translation>Fuso Orario:</translation>
    </message>
    <message>
      <source>Min Altitude (0–90°):</source>
      <translation>Altitudine Min (0–90°):</translation>
    </message>
    <message>
      <source>Catalog Filters:</source>
      <translation>Filtri Catalogo:</translation>
    </message>
    <message>
      <source>Degrees</source>
      <translation>Gradi</translation>
    </message>
    <message>
      <source>H:M:S / D:M:S</source>
      <translation>H:M:S / G:M:S</translation>
    </message>
    <message>
      <source>RA/Dec Format:</source>
      <translation>Formato AR/Dec:</translation>
    </message>
    <message>
      <source>Calculate</source>
      <translation>Calcola</translation>
    </message>
    <message>
      <source>Status: Idle</source>
      <translation>Stato: Inattivo</translation>
    </message>
    <message>
      <source>Local Sidereal Time: 0.000</source>
      <translation>Tempo Siderale Locale: 0.000</translation>
    </message>
    <message>
      <source>Lunar Phase: N/A</source>
      <translation>Fase Lunare: N/D</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Nome</translation>
    </message>
    <message>
      <source>RA</source>
      <translation>AR</translation>
    </message>
    <message>
      <source>Dec</source>
      <translation>Dec</translation>
    </message>
    <message>
      <source>Altitude</source>
      <translation>Altitudine</translation>
    </message>
    <message>
      <source>Azimuth</source>
      <translation>Azimut</translation>
    </message>
    <message>
      <source>Minutes to Transit</source>
      <translation>Minuti al Transito</translation>
    </message>
    <message>
      <source>Before/After Transit</source>
      <translation>Prima/Dopo Transito</translation>
    </message>
    <message>
      <source>Degrees from Moon</source>
      <translation>Gradi dalla Luna</translation>
    </message>
    <message>
      <source>Alt Name</source>
      <translation>Nome Alt</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Tipo</translation>
    </message>
    <message>
      <source>Magnitude</source>
      <translation>Magnitudine</translation>
    </message>
    <message>
      <source>Size (arcmin)</source>
      <translation>Dimensione (arcmin)</translation>
    </message>
    <message>
      <source>Add Custom Object</source>
      <translation>Aggiungi Oggetto Personalizzato</translation>
    </message>
    <message>
      <source>Save to CSV</source>
      <translation>Salva in CSV</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Impostazioni</translation>
    </message>
    <message>
      <source>Enter number of objects to display:</source>
      <translation>Inserisci numero di oggetti da visualizzare:</translation>
    </message>
    <message>
      <source>Enter object name:</source>
      <translation>Inserisci nome oggetto:</translation>
    </message>
    <message>
      <source>Enter RA (deg):</source>
      <translation>Inserisci AR (gradi):</translation>
    </message>
    <message>
      <source>Enter Dec (deg):</source>
      <translation>Inserisci Dec (gradi):</translation>
    </message>
    <message>
      <source>Added custom object: {}</source>
      <translation>Aggiunto oggetto personalizzato: {}</translation>
    </message>
    <message>
      <source>Could not update catalog:
{}</source>
      <translation>Impossibile aggiornare il catalogo:
{}</translation>
    </message>
    <message>
      <source>Save CSV File</source>
      <translation>Salva File CSV</translation>
    </message>
    <message>
      <source>CSV files (*.csv);;All Files (*)</source>
      <translation>File CSV (*.csv);;Tutti i file (*)</translation>
    </message>
    <message>
      <source>Data saved to {}</source>
      <translation>Dati salvati in {}</translation>
    </message>
    <message>
      <source>Invalid input: {}</source>
      <translation>Input non valido: {}</translation>
    </message>
    <message>
      <source> Please verify your longitude/timezone.</source>
      <translation> Verificare longitudine/fuso orario.</translation>
    </message>
    <message>
      <source>Inputs look consistent.</source>
      <translation>Input coerenti.</translation>
    </message>
    <message>
      <source>Calculating…</source>
      <translation>Calcolo in corso…</translation>
    </message>
    <message>
      <source>Lunar Phase: {}% illuminated</source>
      <translation>Fase Lunare: {}% illuminata</translation>
    </message>
    <message>
      <source>Status: {}</source>
      <translation>Stato: {}</translation>
    </message>
  </context>
  <context>
    <name>AberrationCorrectionDialog</name>
    <message>
      <source>Aberration Correction</source>
      <translation>Correzione aberrazione</translation>
    </message>
    <message>
      <source>Analyzing stars...</source>
      <translation>Analisi stelle...</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Applying correction...</source>
      <translation>Applicazione correzione...</translation>
    </message>
    <message>
      <source>Astigmatism Correction</source>
      <translation>Correzione astigmatismo</translation>
    </message>
    <message>
      <source>Chromatic Aberration</source>
      <translation>Aberrazione cromatica</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Coma Correction</source>
      <translation>Correzione coma</translation>
    </message>
    <message>
      <source>Distortion</source>
      <translation>Distorsione</translation>
    </message>
    <message>
      <source>Enable AI Correction</source>
      <translation>Abilita correzione AI</translation>
    </message>
    <message>
      <source>Field Curvature</source>
      <translation>Curvatura di campo</translation>
    </message>
    <message>
      <source>Load Model</source>
      <translation>Carica modello</translation>
    </message>
    <message>
      <source>Model</source>
      <translation>Modello</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Radius</source>
      <translation>Raggio</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Strength</source>
      <translation>Intensità</translation>
    </message>
  </context>
  <context>
    <name>BatchFITSDialog</name>
    <message>
      <source>Action</source>
      <translation>Azione</translation>
    </message>
    <message>
      <source>Add Files...</source>
      <translation>Aggiungi file...</translation>
    </message>
    <message>
      <source>Add Folder...</source>
      <translation>Aggiungi cartella...</translation>
    </message>
    <message>
      <source>Add Keyword</source>
      <translation>Aggiungi parola chiave</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Batch FITS Header Modifier</source>
      <translation>Modificatore header FITS batch</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Clear All</source>
      <translation>Cancella tutto</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Commento</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Elimina</translation>
    </message>
    <message>
      <source>Header Keywords</source>
      <translation>Parole chiave header</translation>
    </message>
    <message>
      <source>Input Files</source>
      <translation>File di input</translation>
    </message>
    <message>
      <source>Keyword</source>
      <translation>Parola chiave</translation>
    </message>
    <message>
      <source>Modified {0} files</source>
      <translation>Modificati {0} file</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Remove Keyword</source>
      <translation>Rimuovi parola chiave</translation>
    </message>
    <message>
      <source>Remove Selected</source>
      <translation>Rimuovi selezionati</translation>
    </message>
    <message>
      <source>Set</source>
      <translation>Imposta</translation>
    </message>
    <message>
      <source>Value</source>
      <translation>Valore</translation>
    </message>
  </context>
  <context>
    <name>BlemishBlasterDialog</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Blemish Blaster</source>
      <translation>Blemish Blaster</translation>
    </message>
    <message>
      <source>Brush Hardness</source>
      <translation>Durezza pennello</translation>
    </message>
    <message>
      <source>Brush Size</source>
      <translation>Dimensione pennello</translation>
    </message>
    <message>
      <source>Clone</source>
      <translation>Clona</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Heal</source>
      <translation>Guarisci</translation>
    </message>
    <message>
      <source>Mode</source>
      <translation>Modo</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation>Opacità</translation>
    </message>
    <message>
      <source>Pan</source>
      <translation>Panoramica</translation>
    </message>
    <message>
      <source>Patch</source>
      <translation>Patch</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Redo</source>
      <translation>Ripeti</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Set Source Point</source>
      <translation>Imposta punto sorgente</translation>
    </message>
    <message>
      <source>Show source overlay</source>
      <translation>Mostra sovrapposizione sorgente</translation>
    </message>
    <message>
      <source>Source</source>
      <translation>Sorgente</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Zoom</source>
      <translation>Zoom</translation>
    </message>
  </context>
  <context>
    <name>BlinkComparatorDialog</name>
    <message>
      <source>Add Images</source>
      <translation>Aggiungi immagini</translation>
    </message>
    <message>
      <source>Align Images</source>
      <translation>Allinea immagini</translation>
    </message>
    <message>
      <source>Blink Comparator</source>
      <translation>Comparatore blink</translation>
    </message>
    <message>
      <source>Clear All</source>
      <translation>Cancella tutto</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Delay (ms)</source>
      <translation>Ritardo (ms)</translation>
    </message>
    <message>
      <source>Loop</source>
      <translation>Ripeti</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Pausa</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Riproduci</translation>
    </message>
    <message>
      <source>Remove Image</source>
      <translation>Rimuovi immagine</translation>
    </message>
    <message>
      <source>Speed</source>
      <translation>Velocità</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Ferma</translation>
    </message>
  </context>
  <context>
    <name>CLAHEDialog</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Apply to Luminance only</source>
      <translation>Applica solo alla luminanza</translation>
    </message>
    <message>
      <source>CLAHE</source>
      <translation>CLAHE</translation>
    </message>
    <message>
      <source>Clip Limit</source>
      <translation>Limite clip</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Grid Size</source>
      <translation>Dimensione griglia</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
  </context>
  <context>
    <name>ContinuumSubtractDialog</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Auto Calculate</source>
      <translation>Calcola automaticamente</translation>
    </message>
    <message>
      <source>Broadband Image</source>
      <translation>Immagine banda larga</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Continuum Subtract</source>
      <translation>Sottrazione continuum</translation>
    </message>
    <message>
      <source>Create new image</source>
      <translation>Crea nuova immagine</translation>
    </message>
    <message>
      <source>Narrowband Image</source>
      <translation>Immagine banda stretta</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Output</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Replace active image</source>
      <translation>Sostituisci immagine attiva</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Scale Factor</source>
      <translation>Fattore scala</translation>
    </message>
    <message>
      <source>Select broadband view</source>
      <translation>Seleziona vista banda larga</translation>
    </message>
    <message>
      <source>Select narrowband view</source>
      <translation>Seleziona vista banda stretta</translation>
    </message>
  </context>
  <context>
    <name>ConvoDialog</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Box</source>
      <translation>Box</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Convolution</source>
      <translation>Convoluzione</translation>
    </message>
    <message>
      <source>Convolution / Deconvolution</source>
      <translation>Convoluzione / Deconvoluzione</translation>
    </message>
    <message>
      <source>Custom</source>
      <translation>Personalizzato</translation>
    </message>
    <message>
      <source>Deconvolution</source>
      <translation>Deconvoluzione</translation>
    </message>
    <message>
      <source>Gaussian</source>
      <translation>Gaussiano</translation>
    </message>
    <message>
      <source>Generate PSF</source>
      <translation>Genera PSF</translation>
    </message>
    <message>
      <source>Iterations</source>
      <translation>Iterazioni</translation>
    </message>
    <message>
      <source>Kernel</source>
      <translation>Kernel</translation>
    </message>
    <message>
      <source>Load PSF</source>
      <translation>Carica PSF</translation>
    </message>
    <message>
      <source>Mode</source>
      <translation>Modo</translation>
    </message>
    <message>
      <source>PSF</source>
      <translation>PSF</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Regularization</source>
      <translation>Regolarizzazione</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Sigma</source>
      <translation>Sigma</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Dimensione</translation>
    </message>
  </context>
  <context>
    <name>CosmicClarityDialog</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Cosmic Clarity</source>
      <translation>Cosmic Clarity</translation>
    </message>
    <message>
      <source>Denoise</source>
      <translation>Riduci rumore</translation>
    </message>
    <message>
      <source>Detail</source>
      <translation>Dettaglio</translation>
    </message>
    <message>
      <source>Detect Trails</source>
      <translation>Rileva scie</translation>
    </message>
    <message>
      <source>GPU Acceleration</source>
      <translation>Accelerazione GPU</translation>
    </message>
    <message>
      <source>Load Model</source>
      <translation>Carica modello</translation>
    </message>
    <message>
      <source>Model</source>
      <translation>Modello</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Remove Trails</source>
      <translation>Rimuovi scie</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Satellite Trail Removal</source>
      <translation>Rimozione scie satellite</translation>
    </message>
    <message>
      <source>Sharpen</source>
      <translation>Nitidezza</translation>
    </message>
    <message>
      <source>Strength</source>
      <translation>Intensità</translation>
    </message>
  </context>
  <context>
    <name>CrashDialog</name>
    <message>
      <source>An error has occurred</source>
      <translation>Si è verificato un errore</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Copy to Clipboard</source>
      <translation>Copia negli appunti</translation>
    </message>
    <message>
      <source>Crash Report</source>
      <translation>Rapporto crash</translation>
    </message>
    <message>
      <source>Don't Send</source>
      <translation>Non inviare</translation>
    </message>
    <message>
      <source>Error Details</source>
      <translation>Dettagli errore</translation>
    </message>
    <message>
      <source>Restart Application</source>
      <translation>Riavvia applicazione</translation>
    </message>
    <message>
      <source>Send Report</source>
      <translation>Invia rapporto</translation>
    </message>
  </context>
  <context>
    <name>CropDialog</name>
    <message>
      <source>16:9</source>
      <translation>16:9</translation>
    </message>
    <message>
      <source>3:2</source>
      <translation>3:2</translation>
    </message>
    <message>
      <source>4:3</source>
      <translation>4:3</translation>
    </message>
    <message>
      <source>Angle</source>
      <translation>Angolo</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Aspect Ratio</source>
      <translation>Proporzioni</translation>
    </message>
    <message>
      <source>Center</source>
      <translation>Centro</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Crop</source>
      <translation>Ritaglia</translation>
    </message>
    <message>
      <source>Custom</source>
      <translation>Personalizzato</translation>
    </message>
    <message>
      <source>Fill</source>
      <translation>Riempi</translation>
    </message>
    <message>
      <source>Fit</source>
      <translation>Adatta</translation>
    </message>
    <message>
      <source>Height</source>
      <translation>Altezza</translation>
    </message>
    <message>
      <source>Lock Aspect Ratio</source>
      <translation>Blocca proporzioni</translation>
    </message>
    <message>
      <source>Original</source>
      <translation>Originale</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Rotation</source>
      <translation>Rotazione</translation>
    </message>
    <message>
      <source>Square (1:1)</source>
      <translation>Quadrato (1:1)</translation>
    </message>
    <message>
      <source>Width</source>
      <translation>Larghezza</translation>
    </message>
    <message>
      <source>X Offset</source>
      <translation>Offset X</translation>
    </message>
    <message>
      <source>Y Offset</source>
      <translation>Offset Y</translation>
    </message>
  </context>
  <context>
    <name>CurveEditorDialog</name>
    <message>
      <source>Add Point</source>
      <translation>Aggiungi punto</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Blu</translation>
    </message>
    <message>
      <source>Channel</source>
      <translation>Canale</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Curve Editor</source>
      <translation>Editor curve</translation>
    </message>
    <message>
      <source>Delete Preset</source>
      <translation>Elimina preset</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Verde</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Input</translation>
    </message>
    <message>
      <source>Linear Interpolation</source>
      <translation>Interpolazione lineare</translation>
    </message>
    <message>
      <source>Load Preset</source>
      <translation>Carica preset</translation>
    </message>
    <message>
      <source>Luminance</source>
      <translation>Luminanza</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Output</translation>
    </message>
    <message>
      <source>Presets</source>
      <translation>Preset</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>RGB</source>
      <translation>RGB</translation>
    </message>
    <message>
      <source>Red</source>
      <translation>Rosso</translation>
    </message>
    <message>
      <source>Remove Point</source>
      <translation>Rimuovi punto</translation>
    </message>
    <message>
      <source>Reset All</source>
      <translation>Ripristina tutto</translation>
    </message>
    <message>
      <source>Reset Channel</source>
      <translation>Ripristina canale</translation>
    </message>
    <message>
      <source>Save Preset</source>
      <translation>Salva preset</translation>
    </message>
    <message>
      <source>Show Histogram</source>
      <translation>Mostra istogramma</translation>
    </message>
    <message>
      <source>Smooth Curve</source>
      <translation>Curva morbida</translation>
    </message>
  </context>
  <context>
    <name>DistortionCorrectionDialog</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Barrel</source>
      <translation>Barilotto</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Distortion Correction</source>
      <translation>Correzione distorsione</translation>
    </message>
    <message>
      <source>Load Profile</source>
      <translation>Carica profilo</translation>
    </message>
    <message>
      <source>Mode</source>
      <translation>Modo</translation>
    </message>
    <message>
      <source>Pincushion</source>
      <translation>Cuscinetto</translation>
    </message>
    <message>
      <source>Polynomial</source>
      <translation>Polinomiale</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Save Profile</source>
      <translation>Salva profilo</translation>
    </message>
    <message>
      <source>Strength</source>
      <translation>Intensità</translation>
    </message>
  </context>
  <context>
    <name>ExoPlanetDialog</name>
    <message>
      <source>Add Files...</source>
      <translation>Aggiungi file...</translation>
    </message>
    <message>
      <source>Add Reference</source>
      <translation>Aggiungi riferimento</translation>
    </message>
    <message>
      <source>Analysis</source>
      <translation>Analisi</translation>
    </message>
    <message>
      <source>Aperture Radius</source>
      <translation>Raggio apertura</translation>
    </message>
    <message>
      <source>Clear All</source>
      <translation>Cancella tutto</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Detect Transit</source>
      <translation>Rileva transito</translation>
    </message>
    <message>
      <source>Exoplanet Detector</source>
      <translation>Rilevatore esopianeti</translation>
    </message>
    <message>
      <source>Export Data</source>
      <translation>Esporta dati</translation>
    </message>
    <message>
      <source>Light Curve</source>
      <translation>Curva di luce</translation>
    </message>
    <message>
      <source>Load Data</source>
      <translation>Carica dati</translation>
    </message>
    <message>
      <source>No transit detected</source>
      <translation>Nessun transito rilevato</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Reference Stars</source>
      <translation>Stelle di riferimento</translation>
    </message>
    <message>
      <source>Remove Reference</source>
      <translation>Rimuovi riferimento</translation>
    </message>
    <message>
      <source>Results</source>
      <translation>Risultati</translation>
    </message>
    <message>
      <source>Save Plot</source>
      <translation>Salva grafico</translation>
    </message>
    <message>
      <source>Select on Image</source>
      <translation>Seleziona su immagine</translation>
    </message>
    <message>
      <source>Target Star</source>
      <translation>Stella target</translation>
    </message>
    <message>
      <source>Transit Depth</source>
      <translation>Profondità transito</translation>
    </message>
    <message>
      <source>Transit Detection</source>
      <translation>Rilevamento transito</translation>
    </message>
    <message>
      <source>Transit Duration</source>
      <translation>Durata transito</translation>
    </message>
    <message>
      <source>Transit detected!</source>
      <translation>Transito rilevato!</translation>
    </message>
  </context>
  <context>
    <name>FITSModifierDialog</name>
    <message>
      <source>Add Keyword</source>
      <translation>Aggiungi parola chiave</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Boolean</source>
      <translation>Booleano</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Commento</translation>
    </message>
    <message>
      <source>FITS Header Modifier</source>
      <translation>Modificatore header FITS</translation>
    </message>
    <message>
      <source>Float</source>
      <translation>Float</translation>
    </message>
    <message>
      <source>Integer</source>
      <translation>Intero</translation>
    </message>
    <message>
      <source>Keyword</source>
      <translation>Parola chiave</translation>
    </message>
    <message>
      <source>Keywords</source>
      <translation>Parole chiave</translation>
    </message>
    <message>
      <source>Modified</source>
      <translation>Modificato</translation>
    </message>
    <message>
      <source>Reload</source>
      <translation>Ricarica</translation>
    </message>
    <message>
      <source>Remove Keyword</source>
      <translation>Rimuovi parola chiave</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Save As...</source>
      <translation>Salva come...</translation>
    </message>
    <message>
      <source>String</source>
      <translation>Stringa</translation>
    </message>
    <message>
      <source>Type</source>
      <translation>Tipo</translation>
    </message>
    <message>
      <source>Value</source>
      <translation>Valore</translation>
    </message>
  </context>
  <context>
    <name>FreqSepDialog</name>
    <message>
      <source>Add</source>
      <translation>Aggiungi</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Apply enhancement</source>
      <translation>Applica miglioramento</translation>
    </message>
    <message>
      <source>Blend Mode</source>
      <translation>Modalità fusione</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Create HF/LF layers</source>
      <translation>Crea livelli AF/BF</translation>
    </message>
    <message>
      <source>Denoise LF</source>
      <translation>Riduz. rumore BF</translation>
    </message>
    <message>
      <source>Frequency Separation</source>
      <translation>Separazione frequenze</translation>
    </message>
    <message>
      <source>HF Scale</source>
      <translation>Scala AF</translation>
    </message>
    <message>
      <source>High Frequency</source>
      <translation>Alta frequenza</translation>
    </message>
    <message>
      <source>Linear Light</source>
      <translation>Luce lineare</translation>
    </message>
    <message>
      <source>Low Frequency</source>
      <translation>Bassa frequenza</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Output</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Radius</source>
      <translation>Raggio</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
  </context>
  <context>
    <name>GHSDialog</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Color Preservation</source>
      <translation>Preservazione colore</translation>
    </message>
    <message>
      <source>GHS</source>
      <translation>GHS</translation>
    </message>
    <message>
      <source>Generalized Hyperbolic Stretch</source>
      <translation>Stretch iperbolico generalizzato</translation>
    </message>
    <message>
      <source>Highlight Protection (HP)</source>
      <translation>Protezione luci (HP)</translation>
    </message>
    <message>
      <source>Inverse</source>
      <translation>Inverso</translation>
    </message>
    <message>
      <source>Load Preset</source>
      <translation>Carica preset</translation>
    </message>
    <message>
      <source>Local Intensity (b)</source>
      <translation>Intensità locale (b)</translation>
    </message>
    <message>
      <source>Luminance Mask</source>
      <translation>Maschera luminanza</translation>
    </message>
    <message>
      <source>Presets</source>
      <translation>Preset</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Save Preset</source>
      <translation>Salva preset</translation>
    </message>
    <message>
      <source>Shadow Protection (LP)</source>
      <translation>Protezione ombre (LP)</translation>
    </message>
    <message>
      <source>Stretch Factor (D)</source>
      <translation>Fattore stretch (D)</translation>
    </message>
    <message>
      <source>Symmetry Point (SP)</source>
      <translation>Punto simmetria (SP)</translation>
    </message>
  </context>
  <context>
    <name>GeometryDialog</name>
    <message>
      <source>Angle</source>
      <translation>Angolo</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Bicubic</source>
      <translation>Bicubica</translation>
    </message>
    <message>
      <source>Bilinear</source>
      <translation>Bilineare</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Flip Horizontal</source>
      <translation>Capovolgi orizzontale</translation>
    </message>
    <message>
      <source>Flip Vertical</source>
      <translation>Capovolgi verticale</translation>
    </message>
    <message>
      <source>Geometry</source>
      <translation>Geometria</translation>
    </message>
    <message>
      <source>Height</source>
      <translation>Altezza</translation>
    </message>
    <message>
      <source>Interpolation</source>
      <translation>Interpolazione</translation>
    </message>
    <message>
      <source>Lanczos</source>
      <translation>Lanczos</translation>
    </message>
    <message>
      <source>Lock Aspect Ratio</source>
      <translation>Blocca proporzioni</translation>
    </message>
    <message>
      <source>Nearest</source>
      <translation>Più vicino</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Resize</source>
      <translation>Ridimensiona</translation>
    </message>
    <message>
      <source>Rotation</source>
      <translation>Rotazione</translation>
    </message>
    <message>
      <source>Scale</source>
      <translation>Scala</translation>
    </message>
    <message>
      <source>Width</source>
      <translation>Larghezza</translation>
    </message>
  </context>
  <context>
    <name>HeaderViewerDialog</name>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Commento</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copia</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Copia tutto</translation>
    </message>
    <message>
      <source>Export...</source>
      <translation>Esporta...</translation>
    </message>
    <message>
      <source>FITS Header Viewer</source>
      <translation>Visualizzatore header FITS</translation>
    </message>
    <message>
      <source>Keyword</source>
      <translation>Parola chiave</translation>
    </message>
    <message>
      <source>Refresh</source>
      <translation>Aggiorna</translation>
    </message>
    <message>
      <source>Search</source>
      <translation>Cerca</translation>
    </message>
    <message>
      <source>Value</source>
      <translation>Valore</translation>
    </message>
  </context>
  <context>
    <name>ImagePeeker</name>
    <message>
      <source>Blue</source>
      <translation>Blu</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Curvature Map</source>
      <translation>Mappa curvatura</translation>
    </message>
    <message>
      <source>FWHM Map</source>
      <translation>Mappa FWHM</translation>
    </message>
    <message>
      <source>Focal Plane Analysis</source>
      <translation>Analisi piano focale</translation>
    </message>
    <message>
      <source>Generate Report</source>
      <translation>Genera rapporto</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Verde</translation>
    </message>
    <message>
      <source>Histogram</source>
      <translation>Istogramma</translation>
    </message>
    <message>
      <source>Image Peeker</source>
      <translation>Image Peeker</translation>
    </message>
    <message>
      <source>Luminance</source>
      <translation>Luminanza</translation>
    </message>
    <message>
      <source>Max</source>
      <translation>Max</translation>
    </message>
    <message>
      <source>Mean</source>
      <translation>Media</translation>
    </message>
    <message>
      <source>Median</source>
      <translation>Mediana</translation>
    </message>
    <message>
      <source>Min</source>
      <translation>Min</translation>
    </message>
    <message>
      <source>Pan</source>
      <translation>Panoramica</translation>
    </message>
    <message>
      <source>Pixel Info</source>
      <translation>Info pixel</translation>
    </message>
    <message>
      <source>Red</source>
      <translation>Rosso</translation>
    </message>
    <message>
      <source>Statistics</source>
      <translation>Statistiche</translation>
    </message>
    <message>
      <source>Std Dev</source>
      <translation>Dev Std</translation>
    </message>
    <message>
      <source>Tilt Analysis</source>
      <translation>Analisi inclinazione</translation>
    </message>
    <message>
      <source>Value</source>
      <translation>Valore</translation>
    </message>
    <message>
      <source>X</source>
      <translation>X</translation>
    </message>
    <message>
      <source>Y</source>
      <translation>Y</translation>
    </message>
    <message>
      <source>Zoom</source>
      <translation>Zoom</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>About</source>
      <translation>Informazioni</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copia</translation>
    </message>
    <message>
      <source>Cut</source>
      <translation>Taglia</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Elimina</translation>
    </message>
    <message>
      <source>Documentation</source>
      <translation>Documentazione</translation>
    </message>
    <message>
      <source>Edit</source>
      <translation>Modifica</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Esci</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Aiuto</translation>
    </message>
    <message>
      <source>Image</source>
      <translation>Immagine</translation>
    </message>
    <message>
      <source>New</source>
      <translation>Nuovo</translation>
    </message>
    <message>
      <source>Open</source>
      <translation>Apri</translation>
    </message>
    <message>
      <source>Paste</source>
      <translation>Incolla</translation>
    </message>
    <message>
      <source>Preferences</source>
      <translation>Preferenze</translation>
    </message>
    <message>
      <source>Process</source>
      <translation>Elabora</translation>
    </message>
    <message>
      <source>Processing</source>
      <translation>Elaborazione</translation>
    </message>
    <message>
      <source>Ready</source>
      <translation>Pronto</translation>
    </message>
    <message>
      <source>Redo</source>
      <translation>Ripeti</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Save As</source>
      <translation>Save As</translation>
    </message>
    <message>
      <source>Select All</source>
      <translation>Seleziona tutto</translation>
    </message>
    <message>
      <source>Tools</source>
      <translation>Strumenti</translation>
    </message>
    <message>
      <source>Undo</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Vista</translation>
    </message>
    <message>
      <source>Welcome to SetiAstro Suite Pro</source>
      <translation>Benvenuto in SetiAstro Suite Pro</translation>
    </message>
    <message>
      <source>Window</source>
      <translation>Finestra</translation>
    </message>
  </context>
  <context>
    <name>MetricsDialog</name>
    <message>
      <source>Bit Depth</source>
      <translation>Profondità bit</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Blu</translation>
    </message>
    <message>
      <source>Channel</source>
      <translation>Canale</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Color Space</source>
      <translation>Spazio colore</translation>
    </message>
    <message>
      <source>Copy</source>
      <translation>Copia</translation>
    </message>
    <message>
      <source>Export...</source>
      <translation>Esporta...</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Verde</translation>
    </message>
    <message>
      <source>Height</source>
      <translation>Altezza</translation>
    </message>
    <message>
      <source>Histogram</source>
      <translation>Istogramma</translation>
    </message>
    <message>
      <source>Image Metrics</source>
      <translation>Metriche immagine</translation>
    </message>
    <message>
      <source>Image Size</source>
      <translation>Dimensione immagine</translation>
    </message>
    <message>
      <source>Luminance</source>
      <translation>Luminanza</translation>
    </message>
    <message>
      <source>MAD</source>
      <translation>MAD</translation>
    </message>
    <message>
      <source>Maximum</source>
      <translation>Massimo</translation>
    </message>
    <message>
      <source>Mean</source>
      <translation>Media</translation>
    </message>
    <message>
      <source>Median</source>
      <translation>Mediana</translation>
    </message>
    <message>
      <source>Minimum</source>
      <translation>Minimo</translation>
    </message>
    <message>
      <source>RGB</source>
      <translation>RGB</translation>
    </message>
    <message>
      <source>Red</source>
      <translation>Rosso</translation>
    </message>
    <message>
      <source>Refresh</source>
      <translation>Aggiorna</translation>
    </message>
    <message>
      <source>Show Histogram</source>
      <translation>Mostra istogramma</translation>
    </message>
    <message>
      <source>Standard Deviation</source>
      <translation>Deviazione standard</translation>
    </message>
    <message>
      <source>Statistics</source>
      <translation>Statistiche</translation>
    </message>
    <message>
      <source>Width</source>
      <translation>Larghezza</translation>
    </message>
  </context>
  <context>
    <name>MinorBodyDialog</name>
    <message>
      <source>Altitude</source>
      <translation>Altitudine</translation>
    </message>
    <message>
      <source>Asteroid</source>
      <translation>Asteroide</translation>
    </message>
    <message>
      <source>Calculate</source>
      <translation>Calcola</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Comet</source>
      <translation>Cometa</translation>
    </message>
    <message>
      <source>Date/Time</source>
      <translation>Data/Ora</translation>
    </message>
    <message>
      <source>Dec</source>
      <translation>Dec</translation>
    </message>
    <message>
      <source>Distance</source>
      <translation>Distanza</translation>
    </message>
    <message>
      <source>Elongation</source>
      <translation>Elongazione</translation>
    </message>
    <message>
      <source>Export Path</source>
      <translation>Esporta percorso</translation>
    </message>
    <message>
      <source>Latitude</source>
      <translation>Latitudine</translation>
    </message>
    <message>
      <source>Location</source>
      <translation>Posizione</translation>
    </message>
    <message>
      <source>Longitude</source>
      <translation>Longitudine</translation>
    </message>
    <message>
      <source>Magnitude</source>
      <translation>Magnitudine</translation>
    </message>
    <message>
      <source>Minor Body Ephemeris</source>
      <translation>Effemeridi corpo minore</translation>
    </message>
    <message>
      <source>Object Name</source>
      <translation>Nome oggetto</translation>
    </message>
    <message>
      <source>Phase Angle</source>
      <translation>Angolo fase</translation>
    </message>
    <message>
      <source>Plot on Image</source>
      <translation>Traccia su immagine</translation>
    </message>
    <message>
      <source>RA</source>
      <translation>AR</translation>
    </message>
    <message>
      <source>Results</source>
      <translation>Risultati</translation>
    </message>
    <message>
      <source>Search</source>
      <translation>Cerca</translation>
    </message>
  </context>
  <context>
    <name>MorphologyDialog</name>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Black Hat</source>
      <translation>Black Hat</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Closing</source>
      <translation>Chiusura</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Croce</translation>
    </message>
    <message>
      <source>Dilation</source>
      <translation>Dilatazione</translation>
    </message>
    <message>
      <source>Ellipse</source>
      <translation>Ellisse</translation>
    </message>
    <message>
      <source>Erosion</source>
      <translation>Erosione</translation>
    </message>
    <message>
      <source>Gradient</source>
      <translation>Gradiente</translation>
    </message>
    <message>
      <source>Iterations</source>
      <translation>Iterazioni</translation>
    </message>
    <message>
      <source>Morphological Operations</source>
      <translation>Operazioni morfologiche</translation>
    </message>
    <message>
      <source>Opening</source>
      <translation>Apertura</translation>
    </message>
    <message>
      <source>Operation</source>
      <translation>Operazione</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>Rectangle</source>
      <translation>Rettangolo</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Dimensione</translation>
    </message>
    <message>
      <source>Structure Element</source>
      <translation>Elemento struttura</translation>
    </message>
    <message>
      <source>Top Hat</source>
      <translation>Top Hat</translation>
    </message>
  </context>
  <context>
    <name>RGBCombineDialog</name>
    <message>
      <source>Add luminance</source>
      <translation>Aggiungi luminanza</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Blue Channel</source>
      <translation>Canale blu</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Create new image</source>
      <translation>Crea nuova immagine</translation>
    </message>
    <message>
      <source>Green Channel</source>
      <translation>Canale verde</translation>
    </message>
    <message>
      <source>Luminance</source>
      <translation>Luminanza</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Output</translation>
    </message>
    <message>
      <source>Preview</source>
      <translation>Anteprima</translation>
    </message>
    <message>
      <source>Processing...</source>
      <translation>Elaborazione...</translation>
    </message>
    <message>
      <source>RGB Combination</source>
      <translation>RGB Combination</translation>
    </message>
    <message>
      <source>Red Channel</source>
      <translation>Canale rosso</translation>
    </message>
    <message>
      <source>Reset</source>
      <translation>Ripristina</translation>
    </message>
    <message>
      <source>Select blue view</source>
      <translation>Select blue view</translation>
    </message>
    <message>
      <source>Select green view</source>
      <translation>Select green view</translation>
    </message>
    <message>
      <source>Select luminance view</source>
      <translation>Select luminance view</translation>
    </message>
    <message>
      <source>Select red view</source>
      <translation>Select red view</translation>
    </message>
  </context>
</TS>