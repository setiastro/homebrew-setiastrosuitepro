# pro/save_options.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Dict, Any

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton,
    QSpinBox, QDoubleSpinBox, QGroupBox, QFormLayout, QCheckBox,
    QRadioButton, QButtonGroup, QWidget, QMessageBox
)
from setiastro.saspro.color_space_manager import (
    COLOR_SPACES,
    DEFAULT_RENDERING_INTENT,
    RENDERING_INTENT_PERCEPTUAL,
    RENDERING_INTENT_RELATIVE,
    get_softproof_black_point_compensation_from_settings,
    get_softproof_rendering_intent_from_settings,
    get_color_space_options,
    get_profile_search_directories,
    get_icc_key_from_color_space_key,
    get_key_from_icc_key,
    get_working_color_space_from_settings,
    is_profile_available,
)

# Allowed bit depths per output format (what your saver actually supports)
_BIT_DEPTHS = {
    "png":  ["8-bit"],
    "jpg":  ["8-bit"],
    "fits": ["8-bit", "16-bit", "32-bit unsigned", "32-bit floating point"],
    "fit":  ["8-bit", "16-bit", "32-bit unsigned", "32-bit floating point"],
    "tif":  ["8-bit", "16-bit", "32-bit unsigned", "32-bit floating point"],
    "xisf": ["16-bit", "32-bit unsigned", "32-bit floating point"],
    "psb":  ["16-bit", "32-bit floating point"], 
    "webp": ["8-bit"],
    # SYQ Core 1: u8 / u16 / f32 (SASpro is f32-internal; no u32 or f64 export).
    "syq":  ["8-bit", "16-bit", "32-bit floating point"],
}

_TIFF_COMP = ["None", "LZW", "ZIP (Deflate)"]


def _norm_ext(target_ext: str) -> str:
    raw_ext = (target_ext or "").lower().strip()
    if "." in raw_ext:
        raw_ext = raw_ext.split(".")[-1]

    if raw_ext in ("fit", "fits", "fz", "fits.gz", "fit.gz"):
        return "fits"
    if raw_ext in ("tif", "tiff"):
        return "tif"
    if raw_ext in ("jpg", "jpeg"):
        return "jpg"
    return raw_ext


class ExportDialog(QDialog):
    """
    "Export"-style options dialog.

    Returns:
      - selected_bit_depth(): str
      - selected_jpeg_quality(): Optional[int]
      - export_options(): dict   (dpi, tiff_compression, resize_mode, etc.)
    """
    def __init__(
        self,
        parent,
        target_ext: str,
        current_bit_depth: str | None,
        current_jpeg_quality: int | None = None,
        *,
        settings=None,   # optional QSettings for persistence
    ):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Export"))
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)

        self._settings = settings
        self._ext = _norm_ext(target_ext)

        allowed_depths = _BIT_DEPTHS.get(self._ext, ["32-bit floating point"])

        # ---- layout root ----
        lay = QVBoxLayout(self)

        # -----------------------------
        # 1) Format summary (nice UX)
        # -----------------------------
        fmt_lbl = QLabel(self.tr(f"Export format: {self._ext.upper()}"))
        fmt_lbl.setWordWrap(True)
        lay.addWidget(fmt_lbl)

        # -----------------------------
        # 2) Core options box
        # -----------------------------
        core_box = QGroupBox(self.tr("Export settings"))
        core_form = QFormLayout(core_box)

        # Bit depth
        self.combo_depth = QComboBox(self)
        self.combo_depth.addItems(allowed_depths)
        if current_bit_depth in allowed_depths:
            self.combo_depth.setCurrentText(current_bit_depth)
        core_form.addRow(self.tr("Bit depth"), self.combo_depth)

        # Embed profile
        self.chk_embed_icc = QCheckBox(self.tr("Embed ICC profile (if available)"))
        self.chk_embed_icc.setChecked(True)
        core_form.addRow(self.tr("Color"), self.chk_embed_icc)

        # Colour space to tag on export. Default to the working display space,
        # while still allowing per-format overrides below.
        self.combo_color_space = QComboBox(self)
        for info in get_color_space_options():
            self.combo_color_space.addItem(self._color_space_label(info.key), info.icc_key)
            idx = self.combo_color_space.count() - 1
            self.combo_color_space.setItemData(idx, self._color_space_description(info.key), Qt.ItemDataRole.ToolTipRole)
        self.combo_color_space.setToolTip(self.tr(
            "Select the ICC profile used to tag exported images. The default "
            "matches the working color space selected in Preferences."))
        self.chk_embed_icc.toggled.connect(self.combo_color_space.setEnabled)
        core_form.addRow(self.tr("Colour space"), self.combo_color_space)

        self.combo_rendering_intent = QComboBox(self)
        self.combo_rendering_intent.addItem(self.tr("Relative Colorimetric"), RENDERING_INTENT_RELATIVE)
        self.combo_rendering_intent.addItem(self.tr("Perceptual"), RENDERING_INTENT_PERCEPTUAL)
        intent_idx = self.combo_rendering_intent.findData(get_softproof_rendering_intent_from_settings(self._settings))
        if intent_idx < 0:
            intent_idx = self.combo_rendering_intent.findData(DEFAULT_RENDERING_INTENT)
        if intent_idx >= 0:
            self.combo_rendering_intent.setCurrentIndex(intent_idx)
        core_form.addRow(self.tr("Rendering intent"), self.combo_rendering_intent)

        self.chk_black_point_compensation = QCheckBox(self.tr("Black-point compensation"))
        self.chk_black_point_compensation.setChecked(get_softproof_black_point_compensation_from_settings(self._settings))
        core_form.addRow("", self.chk_black_point_compensation)

        default_key = get_working_color_space_from_settings(self._settings)
        default_icc = get_icc_key_from_color_space_key(default_key)
        default_idx = self.combo_color_space.findData(default_icc)
        if default_idx >= 0:
            self.combo_color_space.setCurrentIndex(default_idx)

        lay.addWidget(core_box)

        # -----------------------------
        # 3) Format-specific panels
        # -----------------------------
        self.panel_jpg = self._build_jpg_panel(current_jpeg_quality)
        self.panel_tif = self._build_tif_panel()
        lay.addWidget(self.panel_jpg)
        lay.addWidget(self.panel_tif)

        # -----------------------------
        # 4) Resize panel (applies to all; ok if you don't implement yet)
        # -----------------------------
        self.panel_resize = self._build_resize_panel()
        lay.addWidget(self.panel_resize)

        # -----------------------------
        # Buttons
        # -----------------------------
        btn_ok = QPushButton(self.tr("Export"))
        btn_cancel = QPushButton(self.tr("Cancel"))
        btn_ok.clicked.connect(self._on_accept)
        btn_cancel.clicked.connect(self.reject)

        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(btn_ok)
        row.addWidget(btn_cancel)
        lay.addLayout(row)

        # ---- show/hide panels based on format ----
        self._apply_format_visibility()

        # ---- load persisted defaults (optional) ----
        self._load_settings()

    # ------------------------------------------------------------------
    # UI builders
    # ------------------------------------------------------------------
    def _build_jpg_panel(self, current_jpeg_quality: int | None) -> QWidget:
        box = QGroupBox(self.tr("JPEG options"))
        form = QFormLayout(box)

        self.jpeg_quality_spin = QSpinBox(self)
        self.jpeg_quality_spin.setRange(1, 100)
        default_q = int(current_jpeg_quality) if current_jpeg_quality is not None else 95
        self.jpeg_quality_spin.setValue(max(1, min(100, default_q)))
        form.addRow(self.tr("Quality (1–100)"), self.jpeg_quality_spin)

        # future: subsampling toggle etc.
        return box

    def _build_tif_panel(self) -> QWidget:
        box = QGroupBox(self.tr("TIFF options"))
        form = QFormLayout(box)

        self.tiff_dpi_spin = QSpinBox(self)
        self.tiff_dpi_spin.setRange(1, 2400)
        self.tiff_dpi_spin.setValue(300)
        form.addRow(self.tr("DPI"), self.tiff_dpi_spin)

        self.tiff_comp_combo = QComboBox(self)
        self.tiff_comp_combo.addItems(_TIFF_COMP)
        self.tiff_comp_combo.setCurrentText("LZW")
        form.addRow(self.tr("Compression"), self.tiff_comp_combo)

        return box

    def _build_resize_panel(self) -> QWidget:
        box = QGroupBox(self.tr("Resize (optional)"))
        form = QFormLayout(box)

        self.rb_resize_none = QRadioButton(self.tr("No resize"))
        self.rb_resize_percent = QRadioButton(self.tr("Scale by percent"))
        self.rb_resize_long_edge = QRadioButton(self.tr("Set long edge (px)"))
        self.rb_resize_none.setChecked(True)

        self.resize_group = QButtonGroup(self)
        self.resize_group.addButton(self.rb_resize_none, 0)
        self.resize_group.addButton(self.rb_resize_percent, 1)
        self.resize_group.addButton(self.rb_resize_long_edge, 2)

        # percent
        self.resize_percent_spin = QSpinBox(self)
        self.resize_percent_spin.setRange(1, 400)
        self.resize_percent_spin.setValue(100)

        # long edge
        self.resize_long_edge_spin = QSpinBox(self)
        self.resize_long_edge_spin.setRange(16, 200000)
        self.resize_long_edge_spin.setValue(4096)

        # enable/disable inputs based on selection
        self.resize_group.idClicked.connect(self._update_resize_enable)
        self._update_resize_enable()

        form.addRow(self.rb_resize_none)
        rowp = QHBoxLayout()
        rowp.addWidget(self.rb_resize_percent)
        rowp.addStretch(1)
        rowp.addWidget(QLabel(self.tr("Percent:")))
        rowp.addWidget(self.resize_percent_spin)
        w = QWidget()
        w.setLayout(rowp)
        form.addRow(w)

        rowe = QHBoxLayout()
        rowe.addWidget(self.rb_resize_long_edge)
        rowe.addStretch(1)
        rowe.addWidget(QLabel(self.tr("Long edge:")))
        rowe.addWidget(self.resize_long_edge_spin)
        w2 = QWidget()
        w2.setLayout(rowe)
        form.addRow(w2)

        return box

    # ------------------------------------------------------------------
    # Behavior
    # ------------------------------------------------------------------
    def _apply_format_visibility(self):
        self.panel_jpg.setVisible(self._ext == "jpg")
        self.panel_tif.setVisible(self._ext == "tif")

    def _update_resize_enable(self):
        mode = self.resize_group.checkedId()
        self.resize_percent_spin.setEnabled(mode == 1)
        self.resize_long_edge_spin.setEnabled(mode == 2)

    def _color_space_label(self, key: str) -> str:
        if key == "DisplayP3":
            return self.tr("Display P3")
        if key == "AdobeRGB":
            return self.tr("Adobe RGB (1998)")
        if key == "ProPhotoRGB":
            return self.tr("ProPhoto RGB")
        if key == "sRGB":
            return self.tr("sRGB")
        return str(key)

    def _color_space_description(self, key: str) -> str:
        if key == "DisplayP3":
            return self.tr("Wide-gamut color space with D65 white point and P3 primaries.")
        if key == "AdobeRGB":
            return self.tr("Wide-gamut photography color space using Adobe RGB (1998) primaries.")
        if key == "ProPhotoRGB":
            return self.tr("Very wide-gamut color space for professional color workflows.")
        if key == "sRGB":
            return self.tr("Standard RGB color space for web sharing and broad compatibility.")
        return str(key)

    def _missing_profile_message(self, key: str) -> str:
        color_key = get_key_from_icc_key(key)
        info = COLOR_SPACES.get(color_key)
        names = ", ".join(info.profile_names[:4]) if info is not None else str(key)
        dirs = "\n".join(f"- {path}" for path in get_profile_search_directories())
        return self.tr(
            "{profile} ICC profile was not found.\n\n"
            "Expected names include: {names}\n\n"
            "SASpro checks these locations:\n{dirs}\n\n"
            "Display and export tagging will fall back to sRGB until the profile is installed."
        ).format(profile=self._color_space_label(color_key), names=names, dirs=dirs)

    def _on_accept(self):
        if self.chk_embed_icc.isChecked() and not is_profile_available(self.combo_color_space.currentData()):
            QMessageBox.warning(
                self,
                self.tr("Color profile not found"),
                self._missing_profile_message(self.combo_color_space.currentData()),
            )
        # persist settings if present
        self._save_settings()
        self.accept()

    # ------------------------------------------------------------------
    # Settings persistence (optional)
    # ------------------------------------------------------------------
    def _k(self, suffix: str) -> str:
        # per-format persistence
        return f"export/{self._ext}/{suffix}"

    def _load_settings(self):
        s = self._settings
        if s is None:
            return
        try:
            bd = s.value(self._k("bit_depth"), "", type=str) or ""
            if bd:
                idx = self.combo_depth.findText(bd)
                if idx >= 0:
                    self.combo_depth.setCurrentIndex(idx)

            embed = s.value(self._k("embed_icc"), True, type=bool)
            self.chk_embed_icc.setChecked(bool(embed))

            cs = s.value(
                self._k("icc_color_space"),
                get_icc_key_from_color_space_key(get_working_color_space_from_settings(s)),
                type=str,
            ) or "P3"
            cs = get_icc_key_from_color_space_key(get_key_from_icc_key(cs))
            _cs_idx = self.combo_color_space.findData(cs)
            if _cs_idx >= 0:
                self.combo_color_space.setCurrentIndex(_cs_idx)
            self.combo_color_space.setEnabled(self.chk_embed_icc.isChecked())

            intent = s.value(self._k("rendering_intent"), get_softproof_rendering_intent_from_settings(s), type=str)
            intent_idx = self.combo_rendering_intent.findData(intent)
            if intent_idx >= 0:
                self.combo_rendering_intent.setCurrentIndex(intent_idx)

            bpc = s.value(self._k("black_point_compensation"), get_softproof_black_point_compensation_from_settings(s), type=bool)
            self.chk_black_point_compensation.setChecked(bool(bpc))

            if self._ext == "jpg":
                q = s.value(self._k("jpeg_quality"), 95, type=int)
                self.jpeg_quality_spin.setValue(max(1, min(100, int(q))))

            if self._ext == "tif":
                dpi = s.value(self._k("dpi"), 300, type=int)
                self.tiff_dpi_spin.setValue(max(1, int(dpi)))
                comp = s.value(self._k("tiff_comp"), "LZW", type=str)
                idx = self.tiff_comp_combo.findText(comp)
                if idx >= 0:
                    self.tiff_comp_combo.setCurrentIndex(idx)

            rmode = s.value(self._k("resize_mode"), "none", type=str)
            if rmode == "percent":
                self.rb_resize_percent.setChecked(True)
            elif rmode == "long_edge":
                self.rb_resize_long_edge.setChecked(True)
            else:
                self.rb_resize_none.setChecked(True)

            rp = s.value(self._k("resize_percent"), 100, type=int)
            self.resize_percent_spin.setValue(max(1, int(rp)))
            re = s.value(self._k("resize_long_edge"), 4096, type=int)
            self.resize_long_edge_spin.setValue(max(16, int(re)))

            self._update_resize_enable()
        except Exception:
            pass

    def _save_settings(self):
        s = self._settings
        if s is None:
            return
        try:
            s.setValue(self._k("bit_depth"), self.combo_depth.currentText())
            s.setValue(self._k("embed_icc"), bool(self.chk_embed_icc.isChecked()))
            s.setValue(self._k("icc_color_space"), self.combo_color_space.currentData())
            s.setValue(self._k("rendering_intent"), self.combo_rendering_intent.currentData())
            s.setValue(self._k("black_point_compensation"), bool(self.chk_black_point_compensation.isChecked()))

            if self._ext == "jpg":
                s.setValue(self._k("jpeg_quality"), int(self.jpeg_quality_spin.value()))

            if self._ext == "tif":
                s.setValue(self._k("dpi"), int(self.tiff_dpi_spin.value()))
                s.setValue(self._k("tiff_comp"), self.tiff_comp_combo.currentText())

            mode = self.resize_group.checkedId()
            if mode == 1:
                s.setValue(self._k("resize_mode"), "percent")
            elif mode == 2:
                s.setValue(self._k("resize_mode"), "long_edge")
            else:
                s.setValue(self._k("resize_mode"), "none")

            s.setValue(self._k("resize_percent"), int(self.resize_percent_spin.value()))
            s.setValue(self._k("resize_long_edge"), int(self.resize_long_edge_spin.value()))
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def selected_bit_depth(self) -> str:
        return self.combo_depth.currentText()

    def selected_jpeg_quality(self) -> Optional[int]:
        if self._ext != "jpg":
            return None
        return int(self.jpeg_quality_spin.value())

    def export_options(self) -> Dict[str, Any]:
        """
        Options consumed by docman.save_document(..., export_opts=...)
        and then legacy_save_image(..., export_opts=...)
        """
        opts: Dict[str, Any] = {}

        # common
        opts["embed_icc"] = bool(self.chk_embed_icc.isChecked())
        opts["icc_color_space"] = self.combo_color_space.currentData() or "P3"
        opts["rendering_intent"] = self.combo_rendering_intent.currentData() or DEFAULT_RENDERING_INTENT
        opts["black_point_compensation"] = bool(self.chk_black_point_compensation.isChecked())

        # TIFF
        if self._ext == "tif":
            opts["dpi"] = int(self.tiff_dpi_spin.value())
            comp = (self.tiff_comp_combo.currentText() or "").strip().lower()
            if comp.startswith("lzw"):
                opts["tiff_compression"] = "lzw"
            elif comp.startswith("zip") or "deflate" in comp:
                opts["tiff_compression"] = "deflate"
            else:
                opts["tiff_compression"] = None

        # Resize
        mode = self.resize_group.checkedId()
        if mode == 1:
            opts["resize_mode"] = "percent"
            opts["resize_percent"] = int(self.resize_percent_spin.value())
        elif mode == 2:
            opts["resize_mode"] = "long_edge"
            opts["resize_long_edge"] = int(self.resize_long_edge_spin.value())
        else:
            opts["resize_mode"] = "none"

        return opts
