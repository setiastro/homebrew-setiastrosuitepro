# pro/backgroundneutral.py
from __future__ import annotations
import numpy as np

from PyQt6.QtCore import Qt, QPointF, QRectF, QEvent, QTimer
from PyQt6.QtGui import QImage, QPixmap, QPen, QColor, QIcon, QPainter
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QGraphicsView, QGraphicsScene,
    QHBoxLayout, QPushButton, QMessageBox, QGraphicsRectItem
)

# Reuse existing helpers + autostretch
from setiastro.saspro.imageops.stretch import stretch_color_image
# Shared utilities
from setiastro.saspro.widgets.image_utils import extract_mask_from_document as _active_mask_array_from_doc
from setiastro.saspro.widgets.themed_buttons import themed_toolbtn



# ----------------------------
# Core neutralization function
# ----------------------------
def _remove_channel_pedestal(img_rgb01: np.ndarray) -> np.ndarray:
    """
    Remove a per-channel pedestal using the whole image:
        out[...,c] = out[...,c] - min(out[...,c])
    Assumes float32-ish data; returns float32 clipped to [0,1].
    """
    out = img_rgb01.astype(np.float32, copy=True)

    mins = np.nanmin(out.reshape(-1, 3), axis=0).astype(np.float32)  # (3,)
    # If a channel is all-NaN, nanmin returns NaN; guard it:
    mins = np.where(np.isfinite(mins), mins, 0.0).astype(np.float32)

    out -= mins.reshape(1, 1, 3)
    return np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)


def background_neutralize_rgb(
    img: np.ndarray,
    rect_xywh: tuple[int, int, int, int],
    mode: str = "pivot1",
    *,
    remove_pedestal: bool = True,
) -> np.ndarray:
    """
    ...
    Step 0 (optional): whole-image pedestal removal (per-channel)
    """
    if img.ndim != 3 or img.shape[2] != 3:
        raise ValueError("Background Neutralization requires a 3-channel RGB image.")

    # Step 0: pedestal removal on the WHOLE image (optional)
    out = _remove_channel_pedestal(img) if remove_pedestal else img.astype(np.float32, copy=True)

    # Resolve sample rect (use pedestal-free image for medians)
    h, w, _ = out.shape
    x, y, rw, rh = rect_xywh
    x = max(0, min(int(x), w - 1))
    y = max(0, min(int(y), h - 1))
    rw = max(1, min(int(rw), w - x))
    rh = max(1, min(int(rh), h - y))

    sample = out[y:y + rh, x:x + rw, :]
    m = np.median(sample, axis=(0, 1)).astype(np.float32)  # (3,)
    t = float(np.mean(m))

    eps = 1e-8

    if mode == "offset":
        delta = (t - m).reshape(1, 1, 3)

        # cap deltas so we cannot clip
        ch_min = out.reshape(-1, 3).min(axis=0)
        ch_max = out.reshape(-1, 3).max(axis=0)
        delta = np.clip(
            delta,
            (-ch_min + 0.0).reshape(1, 1, 3),
            (1.0 - ch_max).reshape(1, 1, 3)
        )

        return np.clip(out + delta, 0.0, 1.0).astype(np.float32, copy=False)

    # pivot around 1.0 scaling (highlight-protect)
    denom = np.maximum(1.0 - m, eps)         # (3,)
    g = (1.0 - t) / denom                    # (3,)
    g = np.clip(g, 0.0, 10.0)                # sanity cap

    out = 1.0 - (1.0 - out) * g.reshape(1, 1, 3)
    return np.clip(out, 0.0, 1.0).astype(np.float32, copy=False)



# ------------------------------------
# Auto background finder (SASv2 logic)
# ------------------------------------
def _find_best_patch_center(lum: np.ndarray) -> tuple[int, int]:
    """Port of your downhill-walk tile search (works on a luminance plane)."""
    h, w = lum.shape
    th, tw = h // 10, w // 10
    
    # Optimized: compute 10x10 tile medians using strided views where possible
    # This avoids repeated slicing and is cache-friendlier
    meds = np.zeros((10, 10), dtype=np.float32)
    
    # For tiles that fit evenly, use reshape + median (faster than loop)
    crop_h, crop_w = th * 10, tw * 10
    if crop_h <= h and crop_w <= w:
        lum_crop = lum[:crop_h, :crop_w]
        # Reshape to (10, th, 10, tw) and compute medians
        tiles = lum_crop.reshape(10, th, 10, tw).transpose(0, 2, 1, 3).reshape(10, 10, -1)
        meds = np.median(tiles, axis=2).astype(np.float32)
        
        # Handle edge tiles if image doesn't divide evenly
        if h > crop_h or w > crop_w:
            # Bottom row edge
            if h > crop_h:
                for j in range(10):
                    x0, x1 = j * tw, (j + 1) * tw if j < 9 else w
                    meds[9, j] = np.median(lum[9*th:h, x0:x1])
            # Right column edge
            if w > crop_w:
                for i in range(10):
                    y0, y1 = i * th, (i + 1) * th if i < 9 else h
                    meds[i, 9] = np.median(lum[y0:y1, 9*tw:w])
    else:
        # Fallback for very small images
        for i in range(10):
            for j in range(10):
                y0, x0 = i * th, j * tw
                y1 = (i + 1) * th if i < 9 else h
                x1 = (j + 1) * tw if j < 9 else w
                meds[i, j] = np.median(lum[y0:y1, x0:x1])

    idxs = np.argsort(meds.flatten())[:2]

    finals = []
    for idx in idxs:
        ti, tj = divmod(int(idx), 10)
        y0, x0 = ti * th, tj * tw
        y1 = (ti + 1) * th if ti < 9 else h
        x1 = (tj + 1) * tw if tj < 9 else w
        for _ in range(200):
            y = np.random.randint(y0, y1)
            x = np.random.randint(x0, x1)
            while True:
                mv, mpos = lum[y, x], (y, x)
                for dy in (-1, 0, 1):
                    for dx in (-1, 0, 1):
                        if dy == 0 and dx == 0:
                            continue
                        ny, nx = y + dy, x + dx
                        if 0 <= ny < h and 0 <= nx < w and lum[ny, nx] < mv:
                            mv, mpos = lum[ny, nx], (ny, nx)
                if mpos == (y, x):
                    break
                y, x = mpos
            finals.append((y, x))

    best_val = np.inf
    best_pt = (h // 2, w // 2)
    for (y, x) in finals:
        y0 = max(0, y - 25); y1 = min(h, y + 25)
        x0 = max(0, x - 25); x1 = min(w, x + 25)
        m = np.median(lum[y0:y1, x0:x1])
        if m < best_val:
            best_val, best_pt = m, (y, x)
    return best_pt



def auto_rect_box(img_rgb: np.ndarray, box: int = 50, margin: int = 100) -> tuple[int, int, int, int]:
    """
    Find a robust box×box background rectangle (>= margin px margins) in image space.
    Returns (x, y, w, h).

    Notes:
      - img_rgb must be HxWx3 float/uint in any range (we only use relative luminance).
      - box is clamped so it always fits within the image + margins.
    """
    if img_rgb.ndim != 3 or img_rgb.shape[2] != 3:
        raise ValueError("Auto background finder expects a 3-channel RGB image.")

    H, W, _ = img_rgb.shape
    box = int(box)

    # Clamp box so it fits inside the image after margins.
    # Ensure at least 10px and at least 1px interior.
    max_box_w = max(10, W - 2 * margin - 2)
    max_box_h = max(10, H - 2 * margin - 2)
    max_box = max(10, min(max_box_w, max_box_h))
    box = int(np.clip(box, 10, max_box))

    half = box // 2

    # Luminance proxy
    lum = img_rgb.mean(axis=2).astype(np.float32, copy=False)

    # Your existing routine (assumed to return (cy, cx) in image coords)
    cy, cx = _find_best_patch_center(lum)

    # Keep center far enough from edges so the full box fits
    min_cx, max_cx = margin + half, W - (margin + half)
    min_cy, max_cy = margin + half, H - (margin + half)
    cx = int(np.clip(cx, min_cx, max_cx))
    cy = int(np.clip(cy, min_cy, max_cy))

    # Refine around the center.
    # Step scales with box so the search is meaningful at different sizes.
    step = max(4, half // 2)  # e.g. 50->12, 80->20, 30->7
    best_val = np.inf
    ty, tx = cy, cx

    for dy in (-step, 0, +step):
        for dx in (-step, 0, +step):
            y = int(np.clip(cy + dy, min_cy, max_cy))
            x = int(np.clip(cx + dx, min_cx, max_cx))
            y0, y1 = y - half, y - half + box
            x0, x1 = x - half, x - half + box

            # Safety (should already be safe due to clamping, but keep it robust)
            if y0 < 0 or x0 < 0 or y1 > H or x1 > W:
                continue

            m = float(np.median(lum[y0:y1, x0:x1]))
            if m < best_val:
                best_val, ty, tx = m, y, x

    # Top-left anchored rect, exact box size
    x0 = int(tx - half)
    y0 = int(ty - half)

    # Final clamp (again, belt + suspenders)
    x0 = int(np.clip(x0, margin, W - margin - box))
    y0 = int(np.clip(y0, margin, H - margin - box))

    return (x0, y0, box, box)


def auto_rect_50x50(img_rgb: np.ndarray) -> tuple[int, int, int, int]:
    """Backward-compatible wrapper."""
    return auto_rect_box(img_rgb, box=50, margin=100)

# --------------------------------
# Headless apply (doc + preset in)
# --------------------------------
def apply_background_neutral_to_doc(doc, preset: dict | None = None):
    """
    Headless entrypoint (used by DnD shortcuts).
    Preset schema:
      {
        "mode": "auto" | "rect",
        # rect in normalized coords if mode == "rect"
        "rect_norm": [x0, y0, w, h]   # each in 0..1
      }
    Defaults to {"mode": "auto"}.
    """
    import numpy as np

    if preset is None:
        preset = {}
    mode = (preset.get("mode") or "auto").lower()

    base = np.asarray(doc.image).astype(np.float32, copy=False)
    if base.size == 0:
        raise ValueError("Empty image.")

    # Defensive normalization (should already be [0,1] in SASpro)
    maxv = float(np.nanmax(base))
    if maxv > 1.0 and np.isfinite(maxv):
        base = base / maxv

    if base.ndim != 3 or base.shape[2] != 3:
        raise ValueError("Background Neutralization currently supports RGB images.")

    if mode == "rect":
        rn = preset.get("rect_norm", None)

        # IMPORTANT: don't do `if not rn` because rn may be a numpy array
        if rn is None:
            raise ValueError("rect mode requires rect_norm=[x,y,w,h] in normalized coords.")

        # Coerce array-like -> list
        try:
            rn = list(rn)
        except Exception:
            raise ValueError("rect_norm must be an iterable of 4 numbers.")

        if len(rn) != 4:
            raise ValueError("rect mode requires rect_norm=[x,y,w,h] (len==4).")

        H, W, _ = base.shape
        x = int(np.clip(float(rn[0]), 0.0, 1.0) * W)
        y = int(np.clip(float(rn[1]), 0.0, 1.0) * H)
        w = int(np.clip(float(rn[2]), 0.0, 1.0) * W)
        h = int(np.clip(float(rn[3]), 0.0, 1.0) * H)
        rect = (x, y, max(w, 1), max(h, 1))
    else:
        rect = auto_rect_50x50(base)

    out = background_neutralize_rgb(base, rect)

    # Destination-mask blend (mask lives on the destination doc)
    m = _active_mask_array_from_doc(doc)
    if m is not None:
        if out.ndim == 3:
            m3 = np.repeat(m[..., None], 3, axis=2).astype(np.float32, copy=False)
        else:
            m3 = m.astype(np.float32, copy=False)
        base_for_blend = np.asarray(doc.image).astype(np.float32, copy=False)
        bmax = float(np.nanmax(base_for_blend))
        if bmax > 1.0 and np.isfinite(bmax):
            base_for_blend /= bmax
        out = base_for_blend * (1.0 - m3) + out * m3

    doc.apply_edit(
        out.astype(np.float32, copy=False),
        metadata={"step_name": "Background Neutralization", "preset": preset},
        step_name="Background Neutralization",
    )


# -------------------------
# Interactive BN dialog UI
# -------------------------
class BackgroundNeutralizationDialog(QDialog):
    def __init__(self, parent, doc, icon: QIcon | None = None):
        super().__init__(parent)
        self._main = parent
        self.doc = doc
        self._pending_preset = None  # stash for double-click-open seeding (survives reload/clear)

        self._connected_current_doc_changed = False
        if hasattr(self._main, "currentDocumentChanged"):
            try:
                self._main.currentDocumentChanged.connect(self._on_active_doc_changed)
                self._connected_current_doc_changed = True
            except Exception:
                self._connected_current_doc_changed = False

        self.finished.connect(self._cleanup_connections)
        try:
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        except Exception:
            pass  # older PyQt6 versions

        if icon:
            self.setWindowIcon(icon)
        self.setWindowTitle(self.tr("Background Neutralization"))
        self.resize(900, 600)

        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        # Non-modal: allow user to switch between images while dialog is open
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)
        #self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

        self.auto_stretch = False
        self.zoom_factor = 1.0
        self._user_zoomed = False

        # --- scene / view ---
        self.scene = QGraphicsScene(self)
        self.graphics_view = QGraphicsView(self)
        self.graphics_view.setScene(self.scene)
        self.graphics_view.setRenderHints(
            QPainter.RenderHint.Antialiasing |
            QPainter.RenderHint.SmoothPixmapTransform
        )
        self.graphics_view.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.graphics_view.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)

        # --- main layout ---
        layout = QVBoxLayout(self)
        instruction = QLabel("Draw a sample box or click ‘Find Background’ to auto-select.")
        layout.addWidget(instruction)
        layout.addWidget(self.graphics_view, 1)

        # Buttons row
        btn_row = QHBoxLayout()
        self.btn_apply = QPushButton(self.tr("Apply Neutralization"))
        self.btn_cancel = QPushButton(self.tr("Cancel"))
        self.btn_toggle_stretch = QPushButton(self.tr("Enable Auto-Stretch"))
        self.btn_find_bg = QPushButton(self.tr("Find Background"))
        btn_row.addWidget(self.btn_apply)
        btn_row.addWidget(self.btn_cancel)
        btn_row.addWidget(self.btn_toggle_stretch)
        btn_row.addWidget(self.btn_find_bg)
        layout.addLayout(btn_row)

        # Zoom row
        # Zoom row (standardized themed toolbuttons)
        zoom_row = QHBoxLayout()

        self.btn_zoom_out = themed_toolbtn("zoom-out", "Zoom Out")
        self.btn_fit      = themed_toolbtn("zoom-fit-best", "Fit to View")
        self.btn_zoom_in  = themed_toolbtn("zoom-in", "Zoom In")

        zoom_row.addWidget(self.btn_zoom_out)
        zoom_row.addWidget(self.btn_fit)
        zoom_row.addWidget(self.btn_zoom_in)
        zoom_row.addStretch(1)  # optional: keeps them left-aligned

        layout.addLayout(zoom_row)

        # --- preset drag handle (grip) ---
        try:
            from setiastro.saspro.shortcuts import PresetDragHandle
            from setiastro.saspro.help_support import make_help_button
            try:
                from setiastro.saspro.resources import neutral_path
                _grip_icon = QIcon(neutral_path)
            except Exception:
                _grip_icon = QIcon()
            drag_row = QHBoxLayout()
            drag_row.setContentsMargins(0, 0, 0, 0)
            self.preset_drag_handle = PresetDragHandle(
                "background_neutral", self.get_preset, icon=_grip_icon,
                tooltip=self.tr(
                    "Drag to the canvas to create a Background Neutralization "
                    "shortcut with these exact settings.\n"
                    "Drop directly on an image to apply them headlessly."
                ),
                parent=self,
            )
            drag_row.addWidget(self.preset_drag_handle)
            drag_row.addStretch(1)
            self.btn_help = make_help_button("background_neutral", self)
            drag_row.addWidget(self.btn_help)
            layout.addLayout(drag_row)
        except Exception:
            pass

        # Events
        self.btn_apply.clicked.connect(self._on_apply)
        self.btn_cancel.clicked.connect(self.close)
        self.btn_toggle_stretch.clicked.connect(self._toggle_auto_stretch)
        self.btn_find_bg.clicked.connect(self._on_find_background)
        self.btn_zoom_out.clicked.connect(self.zoom_out)
        self.btn_fit.clicked.connect(self.fit_to_view)
        self.btn_zoom_in.clicked.connect(self.zoom_in)        

        self.graphics_view.viewport().installEventFilter(self)
        self.origin_scene = QPointF()
        self.current_rect_scene = QRectF()
        self.selection_item: QGraphicsRectItem | None = None
        self.drawing = False

        self._load_image()

    # ---- active document change ------------------------------------
    def _on_active_doc_changed(self, doc):
        """Called when user clicks a different image window."""
        if doc is None or getattr(doc, "image", None) is None:
            return
        self.doc = doc
        self.selection_item = None
        self._load_image()

    # ---------- image display ----------
    def _doc_image_normalized(self) -> np.ndarray:
        import numpy as np
        img = np.asarray(self.doc.image).astype(np.float32, copy=False)
        if img.size == 0:
            return img
        m = float(np.nanmax(img))
        if m > 1.0 and np.isfinite(m):
            img = img / m
        return img

    def _load_image(self):
        self.scene.clear()
        self.selection_item = None

        img = self._doc_image_normalized()
        if img is None or img.size == 0:
            QMessageBox.warning(self, "No Image", "Open an image first.")
            self.reject()
            return

        disp = img.copy()
        if self.auto_stretch and disp.ndim == 3 and disp.shape[2] == 3:
            disp = stretch_color_image(disp, 0.25, linked=False, normalize=False)

        # Build QImage/QPixmap
        if disp.ndim == 2:
            h, w = disp.shape
            qimg = QImage((disp * 255).astype(np.uint8).tobytes(), w, h, w, QImage.Format.Format_Grayscale8)
        else:
            h, w, _ = disp.shape
            qimg = QImage((disp * 255).astype(np.uint8).tobytes(), w, h, 3 * w, QImage.Format.Format_RGB888)

        pix = QPixmap.fromImage(qimg)

        # Add to scene; force scene rect to native image pixels and place at (0,0)
        self.scene.clear()
        self.selection_item = None
        self.pixmap_item = self.scene.addPixmap(pix)
        self.pixmap_item.setPos(0, 0)
        self.scene.setSceneRect(0, 0, pix.width(), pix.height())

        # Reset and fit (this sets initial view, later showEvent/resizeEvent will refit)
        self.graphics_view.resetTransform()
        self.graphics_view.fitInView(self.pixmap_item, Qt.AspectRatioMode.KeepAspectRatio)
        self.zoom_factor = 1.0
        self._user_zoomed = False

    def _toggle_auto_stretch(self):
        self.auto_stretch = not self.auto_stretch
        self.btn_toggle_stretch.setText("Disable Auto-Stretch" if self.auto_stretch else "Enable Auto-Stretch")
        self._load_image()

    # ---------- zoom ----------
    def eventFilter(self, source, event):
        if source is self.graphics_view.viewport():
            et = event.type()
            if et == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                self.drawing = True
                self.origin_scene = self.graphics_view.mapToScene(event.pos())
                if self.selection_item:
                    self.scene.removeItem(self.selection_item)
                    self.selection_item = None
            elif et == QEvent.Type.MouseMove and self.drawing:
                cur = self.graphics_view.mapToScene(event.pos())
                self.current_rect_scene = QRectF(self.origin_scene, cur).normalized()
                if self.selection_item:
                    self.scene.removeItem(self.selection_item)
                pen = QPen(QColor(0, 255, 0), 2, Qt.PenStyle.DashLine)
                self.selection_item = self.scene.addRect(self.current_rect_scene, pen)
            elif et == QEvent.Type.MouseButtonRelease and event.button() == Qt.MouseButton.LeftButton and self.drawing:
                self.drawing = False
                cur = self.graphics_view.mapToScene(event.pos())
                self.current_rect_scene = QRectF(self.origin_scene, cur).normalized()
                if self.selection_item:
                    self.scene.removeItem(self.selection_item)
                if self.current_rect_scene.width() < 10 or self.current_rect_scene.height() < 10:
                    QMessageBox.warning(self, "Selection Too Small", "Please draw a larger selection box.")
                    self.selection_item = None
                    self.current_rect_scene = QRectF()
                else:
                    pen = QPen(QColor(255, 0, 0), 2, Qt.PenStyle.SolidLine)
                    self.selection_item = self.scene.addRect(self.current_rect_scene, pen)
        return super().eventFilter(source, event)

    def _make_screen_stable_crosshair_group(self, cx: float, cy: float, color: QColor | None = None):
        """
        Create a crosshair marker centered at scene/image coords (cx, cy),
        with approximately constant on-screen size regardless of zoom.
        Returns a QGraphicsItemGroup already added to the scene.
        """
        color = color or QColor(255, 215, 0)  # gold

        # Current zoom scale from the view transform
        t = self.graphics_view.transform()
        sx = abs(t.m11()) if abs(t.m11()) > 1e-12 else 1.0
        sy = abs(t.m22()) if abs(t.m22()) > 1e-12 else 1.0

        # Desired on-screen size in pixels
        arm_px = 16.0
        gap_px = 4.0
        box_px = 8.0

        # Convert screen px -> scene units
        arm_x = arm_px / sx
        arm_y = arm_px / sy
        gap_x = gap_px / sx
        gap_y = gap_px / sy
        box_w = box_px / sx
        box_h = box_px / sy

        pen = QPen(color, 2)
        pen.setCosmetic(True)

        h1 = self.scene.addLine(cx - arm_x, cy, cx - gap_x, cy, pen)
        h2 = self.scene.addLine(cx + gap_x, cy, cx + arm_x, cy, pen)
        v1 = self.scene.addLine(cx, cy - arm_y, cx, cy - gap_y, pen)
        v2 = self.scene.addLine(cx, cy + gap_y, cx, cy + arm_y, pen)
        box = self.scene.addRect(QRectF(cx - box_w/2, cy - box_h/2, box_w, box_h), pen)

        group = self.scene.createItemGroup([h1, h2, v1, v2, box])
        group.setZValue(1e6)
        return group

    def _on_find_background(self):
        img = self._doc_image_normalized()
        if img.ndim != 3 or img.shape[2] != 3:
            QMessageBox.warning(self, "Not RGB", "Background Neutralization supports RGB images.")
            return

        x, y, w, h = auto_rect_50x50(img)

        # Keep the REAL sample rect for the actual math
        rect_scene = QRectF(float(x), float(y), float(w), float(h))
        self.current_rect_scene = rect_scene

        # Remove previous marker
        if self.selection_item:
            self.scene.removeItem(self.selection_item)
            self.selection_item = None

        # Draw a visible crosshair at the center of the true rect
        cx = rect_scene.center().x()
        cy = rect_scene.center().y()

        self.selection_item = self._make_screen_stable_crosshair_group(
            cx, cy, QColor(255, 215, 0)
        )

        self.scene.update()
        self.graphics_view.viewport().update()

    def _scene_rect_to_image_rect(self) -> tuple[int, int, int, int]:
        if not self.current_rect_scene or self.current_rect_scene.isNull():
            raise ValueError("No selection rectangle defined.")

        # Scene == image pixels (because we setSceneRect to pixmap bounds)
        bounds = self.pixmap_item.boundingRect()
        W = int(bounds.width())
        H = int(bounds.height())

        x = int(max(0.0, min(bounds.width(),  self.current_rect_scene.left())))
        y = int(max(0.0, min(bounds.height(), self.current_rect_scene.top())))
        w = int(max(1.0, min(bounds.width()  - x, self.current_rect_scene.width())))
        h = int(max(1.0, min(bounds.height() - y, self.current_rect_scene.height())))
        return (x, y, w, h)

    # -------- preset emit (grip) --------
    def get_preset(self) -> dict:
        """Emit current state as the BN preset schema (inverse of seed_from_preset).
        Box present (drawn or Find Background) -> rect; nothing drawn -> auto.
        Mirrors the normalization _on_apply records for Replay Last."""
        try:
            rect = self._scene_rect_to_image_rect()
        except Exception:
            return {"mode": "auto"}
        try:
            img = self._doc_image_normalized()
            H, W = img.shape[:2]
            if W > 0 and H > 0:
                x, y, w, h = rect
                return {
                    "mode": "rect",
                    "rect_norm": [
                        float(x) / float(W),
                        float(y) / float(H),
                        float(w) / float(W),
                        float(h) / float(H),
                    ],
                }
        except Exception:
            pass
        return {"mode": "auto"}

    # -------- preset seed (double-click open) --------
    def seed_from_preset(self, p: dict | None):
        """Inverse of get_preset. Rect -> draw sample box; Auto -> clear (finder runs on apply)."""
        p = dict(p or {})
        mode = (p.get("mode") or "auto").lower()

        # Clear any existing selection overlay first.
        if self.selection_item is not None:
            try:
                self.scene.removeItem(self.selection_item)
            except Exception:
                pass
            self.selection_item = None

        if mode != "rect":
            self.current_rect_scene = QRectF()
            return

        rn = p.get("rect_norm")
        try:
            rn = list(rn) if rn is not None else None
        except Exception:
            rn = None
        if not rn or len(rn) != 4:
            self.current_rect_scene = QRectF()
            return

        try:
            bounds = self.pixmap_item.boundingRect()
            W = float(bounds.width()); H = float(bounds.height())
        except Exception:
            self.current_rect_scene = QRectF()
            return
        if W <= 0.0 or H <= 0.0:
            self.current_rect_scene = QRectF()
            return

        x = float(np.clip(float(rn[0]), 0.0, 1.0)) * W
        y = float(np.clip(float(rn[1]), 0.0, 1.0)) * H
        w = max(1.0, float(np.clip(float(rn[2]), 0.0, 1.0)) * W)
        h = max(1.0, float(np.clip(float(rn[3]), 0.0, 1.0)) * H)
        self.current_rect_scene = QRectF(x, y, w, h)

        # Draw the sample rectangle; cosmetic pen keeps it visible at any zoom.
        pen = QPen(QColor(255, 0, 0), 2, Qt.PenStyle.SolidLine)
        pen.setCosmetic(True)
        self.selection_item = self.scene.addRect(self.current_rect_scene, pen)

    def _on_apply(self):
        try:
            rect = self._scene_rect_to_image_rect()
        except Exception as e:
            QMessageBox.warning(self, "No Selection", str(e))
            return

        img = self._doc_image_normalized()
        if img.ndim != 3 or img.shape[2] != 3:
            QMessageBox.warning(self, "Not RGB", "Background Neutralization supports RGB images.")
            return

        out = background_neutralize_rgb(img, rect)

        # Destination-mask blend
        m = _active_mask_array_from_doc(self.doc)
        if m is not None:
            if out.ndim == 3:
                m3 = np.repeat(m[..., None], 3, axis=2).astype(np.float32, copy=False)
            else:
                m3 = m.astype(np.float32, copy=False)
            base_for_blend = self._doc_image_normalized()
            out = base_for_blend * (1.0 - m3) + out * m3

        # ---------- Build preset for Replay Last ----------
        preset = None
        try:
            H, W = img.shape[:2]
            x, y, w, h = rect
            if W > 0 and H > 0:
                rect_norm = [
                    float(x) / float(W),
                    float(y) / float(H),
                    float(w) / float(W),
                    float(h) / float(H),
                ]
            else:
                rect_norm = [0.0, 0.0, 1.0, 1.0]

            preset = {"mode": "rect", "rect_norm": rect_norm}

            # Walk up parent chain until we find the main window that carries
            # _last_headless_command
            main = self.parent()
            while main is not None and not hasattr(main, "_last_headless_command"):
                main = main.parent()

            if main is not None:
                try:
                    main._last_headless_command = {
                        "command_id": "background_neutral",
                        "preset": preset,
                    }
                    if hasattr(main, "_log"):
                        main._log(
                            "[Replay] Recorded background_neutral "
                            f"(mode=rect, rect_norm={rect_norm})"
                        )
                except Exception:
                    pass
        except Exception:
            # Fallback: at least record mode
            if preset is None:
                preset = {"mode": "rect"}

        # ---------- Apply edit (include preset in metadata) ----------
        meta = {
            "step_name": "Background Neutralization",
            "rect": rect,
        }
        if preset is not None:
            meta["preset"] = preset

        self.doc.apply_edit(
            out.astype(np.float32, copy=False),
            metadata=meta,
            step_name="Background Neutralization",
        )
        # Dialog stays open so user can apply to other images
        # Refresh to use the now-active document for next operation
        self.close()

    def closeEvent(self, ev):
        self._cleanup_connections()
        super().closeEvent(ev)

    def _cleanup_connections(self):
        # Disconnect active-doc tracking (Fabio hook)
        try:
            if self._connected_current_doc_changed and hasattr(self._main, "currentDocumentChanged"):
                self._main.currentDocumentChanged.disconnect(self._on_active_doc_changed)
        except Exception:
            pass
        self._connected_current_doc_changed = False

        # If you ever add threads/workers later, stop them here too (safe no-ops now)
        try:
            if getattr(self, "_worker", None) is not None:
                try:
                    self._worker.requestInterruption()
                except Exception:
                    pass
            if getattr(self, "_thread", None) is not None:
                self._thread.quit()
                self._thread.wait(500)
        except Exception:
            pass


    def _refresh_document_from_active(self):
        """
        Refresh the dialog's document reference to the currently active document.
        This allows reusing the same dialog on different images.
        """
        try:
            main = self.parent()
            if main and hasattr(main, "_active_doc"):
                new_doc = main._active_doc()
                if new_doc is not None and new_doc is not self.doc:
                    self.doc = new_doc
                    # Refresh the preview image
                    self._load_preview()
        except Exception:
            pass

    def _zoom(self, factor: float):
        self._user_zoomed = True
        cur = self.graphics_view.transform().m11()
        new_scale = cur * factor
        if new_scale < 0.01 or new_scale > 100.0:
            return
        self.graphics_view.scale(factor, factor)

    def zoom_in(self):
        self._zoom(1.25)

    def zoom_out(self):
        self._zoom(0.8)

    def fit_to_view(self):
        self._user_zoomed = False
        self.graphics_view.resetTransform()
        # Fit the pixmap bounds (not a default huge scene)
        if hasattr(self, "pixmap_item") and self.pixmap_item is not None:
            self.graphics_view.fitInView(self.pixmap_item, Qt.AspectRatioMode.KeepAspectRatio)

    def showEvent(self, e):
        super().showEvent(e)
        # fit + (optionally) seed after the widget is visible and laid out
        QTimer.singleShot(0, self._after_show)

    def _after_show(self):
        self.fit_to_view()
        p = getattr(self, "_pending_preset", None)
        if p is not None:
            self._pending_preset = None
            try:
                self.seed_from_preset(p)
            except Exception:
                pass

    def resizeEvent(self, e):
        super().resizeEvent(e)
        # keep it fitted while the user hasn't manually zoomed
        if not self._user_zoomed:
            self.fit_to_view()

from setiastro.saspro.headless_utils import normalize_headless_main, unwrap_docproxy

def run_background_neutral_via_preset(main, preset=None, target_doc=None):
    from PyQt6.QtWidgets import QMessageBox
    from setiastro.saspro.backgroundneutral import apply_background_neutral_to_doc

    p = dict(preset or {})
    main, doc, _dm = normalize_headless_main(main, target_doc)

    if doc is None or getattr(doc, "image", None) is None:
        QMessageBox.warning(main or None, "Background Neutralization", "Load an image first.")
        return

    apply_background_neutral_to_doc(doc, p)


def open_background_neutral_with_preset(main_window, preset: dict | None = None):
    from PyQt6.QtGui import QIcon

    # Resolve doc: active MDI subwindow first, then docman fallback.
    doc = None
    try:
        sw = main_window.mdi.activeSubWindow()
        if sw is not None:
            doc = getattr(sw.widget(), "document", None)
    except Exception:
        doc = None
    if doc is None:
        dm = getattr(main_window, "doc_manager", getattr(main_window, "docman", None))
        if dm is not None:
            doc = (dm.get_active_document() if hasattr(dm, "get_active_document")
                   else getattr(dm, "active_document", None))
    if doc is None or getattr(doc, "image", None) is None:
        return

    try:
        from setiastro.saspro.resources import neutral_path
        _icon = QIcon(neutral_path)
    except Exception:
        _icon = QIcon()

    dlg = BackgroundNeutralizationDialog(main_window, doc, _icon)

    # Stash preset; seeding runs as the last step in _after_show (after fit and
    # after any activation-driven _load_image reload that would clear the scene).
    try:
        dlg._pending_preset = dict(preset) if preset else None
    except Exception:
        dlg._pending_preset = None

    # Retain against GC (dialog has WA_DeleteOnClose).
    try:
        main_window._bn_preset_dialog = dlg
    except Exception:
        pass

    dlg.show(); dlg.raise_(); dlg.activateWindow()
    return dlg