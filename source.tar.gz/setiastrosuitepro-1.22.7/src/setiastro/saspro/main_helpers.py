
# saspro/main_helpers.py
"""
Helper functions extracted from the main module.

Contains utility functions used throughout the main window:
- File path utilities
- Document name/type detection
- Widget safety checks
- WCS/FITS header utilities
- UI responsiveness helpers
"""

import os
import time
from typing import Optional, Tuple

from PyQt6 import sip
from PyQt6.QtWidgets import QApplication

from setiastro.saspro.file_utils import (
    _normalize_ext,
    _sanitize_filename,
    _exts_from_filter,
    REPLACE_SPACES_WITH_UNDERSCORES,
    WIN_RESERVED_NAMES,
)


def non_blocking_sleep(duration_sec: float):
    """
    Sleep for duration_sec seconds while keeping the UI responsive.
    Uses QApplication.processEvents() to process pending events.
    """
    end_time = time.time() + duration_sec
    while time.time() < end_time:
        QApplication.processEvents()
        # Sleep a tiny bit to avoid 100% CPU usage
        sleep_time = min(0.05, end_time - time.time())
        if sleep_time > 0:
            time.sleep(sleep_time)


def safe_join_dir_and_name(directory: str, basename: str) -> str:
    """
    Join directory + sanitized basename. 
    Ensures the directory exists or raises a clear error.
    """
    safe_name = _sanitize_filename(basename)
    final_dir = directory or ""
    if final_dir and not os.path.isdir(final_dir):
        try:
            os.makedirs(final_dir, exist_ok=True)
        except Exception:
            pass
    return os.path.join(final_dir, safe_name)


def normalize_save_path_chosen_filter(path: str, selected_filter: str) -> Tuple[str, str]:
    """
    Returns (final_path, final_ext). Ensures:
      - appends an extension if the user typed none (from the chosen filter)
      - avoids doubled extensions (*.png.png)
      - keeps the user's extension verbatim when it's a valid alias for the
        chosen format, so .tiff/.jpeg/.fits are NOT collapsed to .tif/.jpg/.fit
      - only overrides the extension when it's missing or invalid for the filter
      - sanitizes the basename (spaces, illegal chars, trailing dots, reserved names)
    """
    raw_path = (path or "").strip().rstrip(".")

    # Raw extensions offered by the chosen filter, preserved verbatim and in
    # order, e.g. "TIFF (*.tif *.tiff)" -> ["tif", "tiff"]. We deliberately do
    # NOT push these through _normalize_ext, whose alias-canonicalization is what
    # was turning .tiff into .tif.
    allowed = []
    for tok in (selected_filter or "").replace("(", " ").replace(")", " ").split():
        if tok.startswith("*."):
            e = tok[2:].strip(" ;,").lower()
            if e.isalnum() and e not in allowed:
                allowed.append(e)

    directory, base = os.path.split(raw_path)
    if not base:
        base = "untitled"

    stem, dot_ext = os.path.splitext(base)
    typed = dot_ext[1:].lower() if dot_ext else ""      # raw, unnormalized

    if not allowed:
        # Some platforms return an empty selected_filter (or "All Files (*)").
        # Trust whatever the user typed instead of forcing a format on them.
        allowed = [typed] if typed else ["png"]

    default_ext = allowed[0]

    # Strip a duplicated trailing extension already sitting in the stem
    # (e.g. "foo.tiff" that would otherwise become "foo.tiff.tiff").
    low = stem.lower()
    for a in allowed:
        if low.endswith("." + a):
            stem = stem[: -(len(a) + 1)]
            break

    # The actual fix: keep the typed extension when it's valid for this format;
    # only fall back to the filter default when it's missing or not valid.
    if not typed:
        final_ext = default_ext
    elif typed in allowed:
        final_ext = typed
    else:
        final_ext = default_ext

    # Sanitize only the stem, then re-attach the chosen extension, so the
    # extension is never rewritten by the sanitizer regardless of its internals.
    safe_stem = _sanitize_filename(stem or "untitled",
                                   replace_spaces=REPLACE_SPACES_WITH_UNDERSCORES)

    # Mirror safe_join_dir_and_name's dir-creation, but skip its second sanitize
    # pass (which would otherwise re-touch the full "stem.ext").
    final_dir = directory or ""
    if final_dir and not os.path.isdir(final_dir):
        try:
            os.makedirs(final_dir, exist_ok=True)
        except Exception:
            pass

    return os.path.join(final_dir, f"{safe_stem}.{final_ext}"), final_ext


def display_name(doc) -> str:
    """Best-effort title for any doc-like object."""
    # Prefer a method
    for attr in ("display_name", "title", "name"):
        v = getattr(doc, attr, None)
        if callable(v):
            try:
                s = v()
                if isinstance(s, str) and s.strip():
                    return s
            except Exception:
                pass
        elif isinstance(v, str) and v.strip():
            return v

    # Metadata fallbacks
    md = getattr(doc, "metadata", {}) or {}
    if isinstance(md, dict):
        for k in ("display_name", "title", "name", "filename", "basename"):
            s = md.get(k)
            if isinstance(s, str) and s.strip():
                return s

    # Last resort: id snippet
    return f"Document-{id(doc) & 0xFFFF:04X}"


def best_doc_name(doc) -> str:
    """Get the best available name for a document."""
    # Try common attributes in order
    for attr in ("display_name", "name", "title"):
        v = getattr(doc, attr, None)
        if callable(v):
            try:
                v = v()
            except Exception:
                v = None
        if isinstance(v, str) and v.strip():
            return v.strip()

    # Fallback: derive from original path if we have it
    try:
        meta = getattr(doc, "metadata", {}) or {}
        fp = meta.get("file_path")
        if isinstance(fp, str) and fp:
            return os.path.splitext(os.path.basename(fp))[0]
    except Exception:
        pass

    return "untitled"


def doc_looks_like_table(doc) -> bool:
    """Determine if a document represents tabular data rather than an image."""
    md = getattr(doc, "metadata", {}) or {}

    # Explicit type hints from own pipeline
    if str(md.get("doc_type", "")).lower() in {"table", "catalog", "fits_table"}:
        return True
    if str(md.get("fits_hdu_type", "")).lower().endswith("tablehdu"):
        return True
    if str(md.get("hdu_class", "")).lower().endswith("tablehdu"):
        return True

    # FITS header inspection (common with astropy)
    hdr = md.get("original_header") or md.get("fits_header") or {}
    try:
        xt = str(hdr.get("XTENSION", "")).upper()
        if xt in {"TABLE", "BINTABLE", "ASCIITABLE"}:
            return True
    except Exception:
        pass

    # Structural hints from the doc
    if hasattr(doc, "table"):
        return True
    if hasattr(doc, "columns"):
        return True
    if hasattr(doc, "rows") or hasattr(doc, "headers"):
        return True

    # Last resort: no image but we clearly have column metadata
    if getattr(doc, "image", None) is None and isinstance(md.get("columns"), (list, tuple)):
        return True

    return False


def is_alive(obj) -> bool:
    """True if obj is a live Qt wrapper (not deleted)."""
    if obj is None:
        return False
    if sip is not None:
        try:
            return not sip.isdeleted(obj)
        except Exception:
            pass
    # Touch-test: some cheap attribute access; if wrapper is dead this raises RuntimeError
    try:
        getattr(obj, "objectName", None)
        return True
    except RuntimeError:
        return False


def safe_widget(sw) -> Optional[object]:
    """Returns sw.widget() if both subwindow and its widget are alive; else None."""
    try:
        if not is_alive(sw):
            return None
        w = sw.widget()
        return w if is_alive(w) else None
    except Exception:
        return None
