# src/setiastro/saspro/ser_stack_config.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, Literal, Union, Sequence
import numpy as np


from setiastro.saspro.imageops.serloader import PlanetaryFrameSource

TrackMode = Literal["off", "planetary", "surface"]
PlanetarySource = Union[str, Sequence[str], PlanetaryFrameSource]

@dataclass
class SERStackConfig:
    source: PlanetarySource
    roi: Optional[Tuple[int, int, int, int]] = None
    track_mode: TrackMode = "planetary"
    surface_anchor: Optional[Tuple[int, int, int, int]] = None
    center_on_planet: bool = False
    keep_percent: float = 20.0
    bayer_pattern: Optional[str] = None

    # AP / alignment
    ap_size: int = 64
    ap_spacing: int = 48
    ap_min_mean: float = 0.03
    ap_multiscale: bool = False
    ssd_refine_bruteforce: bool = False
    keep_mask: Optional[np.ndarray] = None
    planet_simple: bool = True
    planet_simple_thresh: float = 0.5
    planet_use_norm: bool = False

    # Field rotation correction
    correct_field_rotation: bool = False
    field_rotation_max_deg: float = 5.0
    field_rotation_step_deg: float = 0.5
    correct_atm_dispersion: bool = False

    # Drizzle
    drizzle_scale: float = 1.0
    drizzle_pixfrac: float = 0.80
    drizzle_kernel: str = "gaussian"
    drizzle_sigma: float = 0.0

    # Derotation
    derotate_enabled: bool = False
    derotate_deg_per_min: float = 0.0
    derotate_center: tuple[float, float] | None = None
    derotate_radius: float | None = None
    derotate_overlay_mode: str = "none"
    derotate_rings: tuple[float, float, float, float] | None = None

    def __init__(self, source: PlanetarySource, **kwargs):
        # Allow deprecated/ignored kwargs without crashing
        kwargs.pop("multipoint", None)
        kwargs.pop("local_warp", None)  # removed — always on now

        self.source = source
        self.roi = kwargs.pop("roi", None)
        self.track_mode = kwargs.pop("track_mode", "planetary")
        self.surface_anchor = kwargs.pop("surface_anchor", None)
        self.keep_percent = float(kwargs.pop("keep_percent", 20.0))
        self.bayer_pattern = kwargs.pop("bayer_pattern", None)
        if isinstance(self.bayer_pattern, str):
            s = self.bayer_pattern.strip().upper()
            self.bayer_pattern = s if s in ("RGGB", "BGGR", "GRBG", "GBRG") else None
        else:
            self.bayer_pattern = None

        self.ap_size = int(kwargs.pop("ap_size", 64))
        self.ap_spacing = int(kwargs.pop("ap_spacing", 48))
        self.ap_min_mean = float(kwargs.pop("ap_min_mean", 0.03))
        self.ap_multiscale = bool(kwargs.pop("ap_multiscale", False))
        self.ssd_refine_bruteforce = bool(kwargs.pop("ssd_refine_bruteforce", False))
        self.keep_mask = kwargs.pop("keep_mask", None)

        # Planetary centroid knobs
        self.planet_smooth_sigma  = float(kwargs.pop("planet_smooth_sigma", 1.5))
        self.planet_simple_thresh = float(kwargs.pop("planet_simple_thresh", 0.5))
        self.planet_use_norm      = bool(kwargs.pop("planet_use_norm", False))
        self.center_on_planet     = bool(kwargs.pop("center_on_planet", False))
        self.planet_smooth_sigma  = max(0.0, self.planet_smooth_sigma)

        # Field rotation correction
        self.correct_field_rotation  = bool(kwargs.pop("correct_field_rotation", False))
        self.field_rotation_max_deg  = float(kwargs.pop("field_rotation_max_deg", 5.0))
        self.field_rotation_step_deg = float(kwargs.pop("field_rotation_step_deg", 0.5))
        self.correct_atm_dispersion  = bool(kwargs.pop("correct_atm_dispersion", False))
        # clamp to sane values
        self.field_rotation_max_deg  = max(0.5, min(45.0, self.field_rotation_max_deg))
        self.field_rotation_step_deg = max(0.1, min(5.0,  self.field_rotation_step_deg))

        # Drizzle params
        self.drizzle_scale = float(kwargs.pop("drizzle_scale", 1.0))
        if self.drizzle_scale not in (1.0, 1.5, 2.0, 3.0, 4.0):
            self.drizzle_scale = 1.0
        self.drizzle_pixfrac = float(kwargs.pop("drizzle_pixfrac", 0.80))
        self.drizzle_kernel  = str(kwargs.pop("drizzle_kernel", "gaussian")).strip().lower()
        self.drizzle_sigma   = float(kwargs.pop("drizzle_sigma", 0.0))
        if self.drizzle_scale < 1.0:
            self.drizzle_scale = 1.0
        if self.drizzle_pixfrac <= 0.0:
            self.drizzle_pixfrac = 0.01
        if self.drizzle_kernel not in ("square", "circle", "gaussian"):
            self.drizzle_kernel = "gaussian"
        if self.drizzle_sigma < 0.0:
            self.drizzle_sigma = 0.0

        # Derotation params
        self.derotate_enabled      = bool(kwargs.pop("derotate_enabled", False))
        self.derotate_deg_per_min  = float(kwargs.pop("derotate_deg_per_min", 0.0))

        dc = kwargs.pop("derotate_center", None)
        self.derotate_center = None if dc is None else (float(dc[0]), float(dc[1]))

        dr = kwargs.pop("derotate_radius", None)
        self.derotate_radius = None if dr is None else float(dr)

        self.derotate_overlay_mode = str(kwargs.pop("derotate_overlay_mode", "none")).strip().lower()

        rings = kwargs.pop("derotate_rings", None)
        if rings is None:
            self.derotate_rings = None
        else:
            try:
                self.derotate_rings = (float(rings[0]), float(rings[1]), float(rings[2]), float(rings[3]))
            except Exception:
                self.derotate_rings = None

        if kwargs:
            raise TypeError(f"Unexpected config keys: {sorted(kwargs.keys())}")