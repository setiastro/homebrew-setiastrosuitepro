# src/setiastro/saspro/denoise_engines/syqon_prism_engine.py
from __future__ import annotations

import os
from typing import Callable, Optional, Tuple, Any
import numpy as np

from setiastro.saspro.runtime_torch import np_to_torch, torch_to_np


ProgressCB = Callable[[int, int, str], None]

_SYQON_PRISM_SESSION = None
_SYQON_PRISM_CKPT = None

def _infer_nafnet_variant_from_sd(sd: dict) -> str:
    keys = set(sd.keys())

    # Prism Deep markers
    if any(k.startswith("skip_convs.") for k in keys):
        return "deep"
    if any(".ca.fc." in k for k in keys):
        return "deep"

    # Prism Free markers
    if any(".sca." in k for k in keys):
        return "free"

    # Safe default for older/current behavior
    return "free"

def _infer_device(torch, *, prefer_cuda: bool = True, prefer_dml: bool = True):
    if prefer_cuda and getattr(torch, "cuda", None) and torch.cuda.is_available():
        return torch.device("cuda")

    if prefer_dml and (os.name == "nt"):
        try:
            import torch_directml
            return torch_directml.device()
        except Exception:
            pass

    # is_available() reports True on Intel Macs with a Metal-capable Radeon, but
    # MPS faults on first use there (surfaces as "Numpy is not available"). Route
    # through the shared gate so this picker can't drift from best_device.
    from setiastro.saspro.runtime_torch import mps_is_usable
    if mps_is_usable(torch):
        return torch.device("mps")

    return torch.device("cpu")


def _torch_load_fallback(torch, ckpt_path: str):
    try:
        with open(ckpt_path, "rb") as f:
            return torch.load(f, map_location="cpu"), {"torch_load_encoding": "default"}
    except UnicodeDecodeError as e0:
        last = e0
    except Exception:
        raise

    for enc in ("latin1", "cp1252", "iso-8859-1"):
        try:
            with open(ckpt_path, "rb") as f:
                return torch.load(f, map_location="cpu", encoding=enc), {"torch_load_encoding": enc}
        except UnicodeDecodeError as e:
            last = e
            continue
        except TypeError:
            break

    raise last


def _load_state_dict(torch, ckpt_path: str):
    ckpt, load_meta = _torch_load_fallback(torch, ckpt_path)

    if isinstance(ckpt, dict):
        if "state_dict" in ckpt and isinstance(ckpt["state_dict"], dict):
            meta = dict(ckpt)
            meta.update(load_meta)
            return ckpt["state_dict"], meta

        if "model" in ckpt and isinstance(ckpt["model"], dict):
            meta = dict(ckpt)
            meta.update(load_meta)
            return ckpt["model"], meta

        if any(
            k.startswith((
                "intro.", "ending.", "encoders.", "downs.", "middle.",
                "decoders.", "ups.", "skip_convs."
            ))
            for k in ckpt.keys()
        ):
            return ckpt, load_meta

    raise RuntimeError("Unsupported checkpoint format (expected state_dict-like dict).")


def _infer_nafnet_cfg_from_sd(sd: dict) -> Tuple[int, int]:
    base_ch = int(sd["intro.weight"].shape[0]) if "intro.weight" in sd else 48

    downs_idx = set()
    for k in sd.keys():
        if k.startswith("downs."):
            parts = k.split(".")
            if len(parts) > 1 and parts[1].isdigit():
                downs_idx.add(int(parts[1]))

    if downs_idx:
        levels = max(downs_idx) + 1
    else:
        enc_idx = set()
        for k in sd.keys():
            if k.startswith("encoders."):
                parts = k.split(".")
                if len(parts) > 1 and parts[1].isdigit():
                    enc_idx.add(int(parts[1]))
        levels = (max(enc_idx) + 1) if enc_idx else 4

    levels = max(1, min(8, int(levels)))
    return base_ch, levels


def load_prism_model(
    ckpt_path: str,
    *,
    use_gpu: bool,
    prefer_dml: bool,
    model_variant: str | None = None,
):
    from setiastro.saspro.runtime_torch import import_torch
    from setiastro.saspro.syqon_prism_model.model import create_model

    torch = import_torch(
        prefer_cuda=use_gpu,
        prefer_xpu=False,
        prefer_dml=prefer_dml,
        status_cb=lambda *_: None,
    )

    sd, meta = _load_state_dict(torch, ckpt_path)
    base_ch, depth = _infer_nafnet_cfg_from_sd(sd)

    inferred_variant = _infer_nafnet_variant_from_sd(sd)
    variant = str(model_variant or inferred_variant).strip().lower()

    model = create_model(
        base_ch=base_ch,
        depth=depth,
        use_sigmoid=False,
        variant=variant,
    )
    model.load_state_dict(sd, strict=False)
    model.eval()

    device = _infer_device(torch, prefer_cuda=use_gpu, prefer_dml=prefer_dml)
    model.to(device)

    info = {
        "base_ch": base_ch,
        "depth": depth,
        "variant": variant,
        "variant_inferred": inferred_variant,
        "device": str(device),
        "torch_version": getattr(torch, "__version__", None),
        "torch_file": getattr(torch, "__file__", None),
    }
    return model, device, info, torch


def _to_torch_chw(img_chw, device, torch):
    x = np.asarray(img_chw, dtype=np.float32)
    if x.ndim != 3:
        raise ValueError("expected CHW float32")
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    return np_to_torch(x[None, ...], device=device, dtype=torch.float32, torch=torch)


def _predict_tile(model, t, *, device, use_amp: bool, amp_dtype: str, info: dict, torch):
    def _to_numpy(pred_t):
        pred_np = torch_to_np(pred_t[0].detach()).transpose(1, 2, 0)
        return pred_np.astype(np.float32, copy=False)

    if use_amp and device.type == "cuda":
        dtype = torch.float16 if amp_dtype == "fp16" else torch.bfloat16
        try:
            with torch.amp.autocast("cuda", dtype=dtype):
                pred_t = model(t)
        except AttributeError:
            # fallback for older torch builds
            with torch.cuda.amp.autocast(dtype=dtype):
                pred_t = model(t)

        pred = _to_numpy(pred_t)
        if not np.isfinite(pred).all():
            info["amp_fallback"] = True
            info["amp_reason"] = "non-finite output detected under CUDA AMP; reran tile in fp32"
            pred_t = model(t)
            pred = _to_numpy(pred_t)
        return pred

    if use_amp and device.type == "mps":
        try:
            with torch.amp.autocast("mps"):
                pred_t = model(t)
            pred = _to_numpy(pred_t)
            if not np.isfinite(pred).all():
                info["amp_fallback"] = True
                info["amp_reason"] = "non-finite output detected under MPS autocast; reran tile in fp32"
                pred_t = model(t)
                pred = _to_numpy(pred_t)
            return pred
        except Exception:
            pred_t = model(t)
            return _to_numpy(pred_t)

    pred_t = model(t)
    pred = _to_numpy(pred_t)

    if not np.isfinite(pred).all():
        raise RuntimeError("Non-finite output detected in fp32 inference.")

    return pred


def prism_denoise_rgb01(
    img_rgb01: np.ndarray,
    ckpt_path: str,
    *,
    tile: int = 512,
    overlap: int = 64,
    use_gpu: bool = True,
    prefer_dml: bool = True,
    use_amp: bool = False,
    amp_dtype: str = "fp16",
    model_variant: str | None = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    tile_cb=None,
):
    x = np.asarray(img_rgb01, dtype=np.float32)
    was_mono = (x.ndim == 2) or (x.ndim == 3 and x.shape[2] == 1)

    if x.ndim == 2:
        x = np.stack([x] * 3, axis=-1)
    elif x.ndim == 3 and x.shape[2] == 1:
        x = np.repeat(x, 3, axis=2)
    else:
        x = x[..., :3]

    H, W = x.shape[:2]
    tile = int(tile)
    overlap = int(overlap)
    stride = max(tile - overlap, 1)

    model, device, info, torch = load_prism_model(
        ckpt_path,
        use_gpu=use_gpu,
        prefer_dml=prefer_dml,
        model_variant=model_variant,
    )

    info = dict(info or {})
    use_amp_requested = bool(use_amp)
    amp_dtype = (amp_dtype or "fp16").lower()
    if amp_dtype not in ("fp16", "bf16"):
        amp_dtype = "fp16"
    use_amp_effective = bool(use_amp_requested) and (device.type in ("cuda", "mps"))

    info["use_amp_requested"] = use_amp_requested
    info["use_amp_effective"] = use_amp_effective
    info["amp_dtype"] = amp_dtype

    out_acc = np.zeros((H, W, 3), dtype=np.float32)
    w_acc = np.zeros((H, W, 1), dtype=np.float32)

    wy = np.hanning(tile).astype(np.float32)
    wx = np.hanning(tile).astype(np.float32)
    w2 = (wy[:, None] * wx[None, :]).astype(np.float32)[..., None]

    ys = list(range(0, H, stride))
    xs = list(range(0, W, stride))
    total = len(ys) * len(xs)
    done = 0

    with torch.no_grad():
        for y0 in ys:
            for x0 in xs:
                y1 = min(y0 + tile, H)
                x1 = min(x0 + tile, W)

                patch = x[y0:y1, x0:x1, :]
                ph, pw = patch.shape[:2]

                if ph != tile or pw != tile:
                    pad = np.zeros((tile, tile, 3), dtype=np.float32)
                    pad[:ph, :pw, :] = patch
                    patch = pad

                chw = patch.transpose(2, 0, 1)
                t = _to_torch_chw(chw, device, torch)

                pred = _predict_tile(
                    model,
                    t,
                    device=device,
                    use_amp=use_amp_effective,
                    amp_dtype=amp_dtype,
                    info=info,
                    torch=torch,
                )

                den_patch = np.clip(pred, 0.0, 1.0).astype(np.float32, copy=False)
                den_patch = den_patch[:ph, :pw, :]
                wlocal = w2[:ph, :pw, :]

                out_acc[y0:y1, x0:x1, :] += den_patch * wlocal
                w_acc[y0:y1, x0:x1, :] += wlocal

                if callable(tile_cb):
                    tile_cb(y0, x0, ph, pw, den_patch)

                done += 1
                if callable(progress_cb):
                    progress_cb(done, total, "SyQon Prism tiles…")

    denoised = out_acc / np.maximum(w_acc, 1e-8)
    denoised = np.clip(denoised, 0.0, 1.0).astype(np.float32, copy=False)

    if was_mono:
        return denoised.mean(axis=2).astype(np.float32, copy=False), info
    return denoised, info

def clear_prism_models_cache(*, aggressive: bool = False, status_cb=print) -> None:
    """
    Clears in-process SyQon Prism model/session caches so RAM/VRAM can be reclaimed.

    - aggressive=False: clears Python references only.
    - aggressive=True : also tries gc.collect() plus torch CUDA/MPS cache flush.
    """
    global _SYQON_PRISM_SESSION, _SYQON_PRISM_CKPT

    try:
        had_session = _SYQON_PRISM_SESSION is not None
        had_ckpt = _SYQON_PRISM_CKPT is not None

        _SYQON_PRISM_SESSION = None
        _SYQON_PRISM_CKPT = None

        status_cb(
            f"[SyQon Prism] Cleared cache "
            f"(session={'yes' if had_session else 'no'}, ckpt={'yes' if had_ckpt else 'no'})"
        )
    except Exception as e:
        try:
            status_cb(f"[SyQon Prism] Cache clear failed: {type(e).__name__}: {e}")
        except Exception:
            pass

    if not aggressive:
        return

    try:
        import gc
        gc.collect()
        status_cb("[SyQon Prism] gc.collect() called")
    except Exception:
        pass

    try:
        from setiastro.saspro.runtime_torch import import_torch
        torch = import_torch(
            prefer_cuda=True,
            prefer_xpu=False,
            prefer_dml=True,
            status_cb=lambda *_: None,
        )

        # CUDA
        try:
            if getattr(torch, "cuda", None) and torch.cuda.is_available():
                torch.cuda.empty_cache()
                if hasattr(torch.cuda, "ipc_collect"):
                    torch.cuda.ipc_collect()
                status_cb("[SyQon Prism] torch.cuda.empty_cache() called")
        except Exception:
            pass

        # MPS
        try:
            if hasattr(torch, "backends") and hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                if hasattr(torch, "mps") and hasattr(torch.mps, "empty_cache"):
                    torch.mps.empty_cache()
                    status_cb("[SyQon Prism] torch.mps.empty_cache() called")
        except Exception:
            pass

    except Exception:
        pass