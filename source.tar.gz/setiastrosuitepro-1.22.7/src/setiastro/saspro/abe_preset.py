# pro/abe_preset.py
from __future__ import annotations
import os
import numpy as np

from .abe import abe_run  # core engine
from .abe_multiscale_gradient import multiscale_gradient_correct

# ---------- mask helpers (match ABEDialog semantics) ----------
def _active_mask_layer(doc):
    mid = getattr(doc, "active_mask_id", None)
    if not mid: return None, None, None
    layer = getattr(doc, "masks", {}).get(mid)
    if layer is None: return None, None, None
    m = np.asarray(getattr(layer, "data", None))
    if m is None or m.size == 0: return None, None, None
    m = m.astype(np.float32, copy=False)
    if m.dtype.kind in "ui":
        m /= float(np.iinfo(m.dtype).max)
    else:
        mx = float(m.max()) if m.size else 1.0
        if mx > 1.0: m /= mx
    return np.clip(m, 0.0, 1.0), mid, getattr(layer, "name", "Mask")

def _resample_mask(mask: np.ndarray, out_hw: tuple[int,int]) -> np.ndarray:
    mh, mw = mask.shape[:2]
    th, tw = out_hw
    if (mh, mw) == (th, tw): return mask
    yi = np.linspace(0, mh - 1, th).astype(np.int32)
    xi = np.linspace(0, mw - 1, tw).astype(np.int32)
    return mask[yi][:, xi]

def _blend_with_mask_float(processed: np.ndarray, src: np.ndarray, doc) -> np.ndarray:
    mask, _mid, _mname = _active_mask_layer(doc)
    if mask is None:
        return processed
    out = processed.astype(np.float32, copy=False)
    s   = src.astype(np.float32, copy=False)

    m = _resample_mask(mask, out.shape[:2])
    # reconcile channels
    if out.ndim == 2 and s.ndim == 3:
        out = out[..., None]
    if s.ndim == 2 and out.ndim == 3:
        s = s[..., None]
    if out.ndim == 3 and out.shape[2] == 3 and m.ndim == 2:
        m = m[..., None]
    blended = (m * out + (1.0 - m) * s).astype(np.float32, copy=False)
    if blended.ndim == 3 and blended.shape[2] == 1:
        blended = blended[..., 0]
    return np.clip(blended, 0.0, 1.0)

# ---------- I/O helpers ----------
def _doc_image_float01(doc) -> np.ndarray | None:
    img = getattr(doc, "image", None)
    if img is None:
        return None
    arr = np.asarray(img)
    if arr.dtype.kind in "ui":
        return (arr.astype(np.float32) / np.iinfo(arr.dtype).max).clip(0.0, 1.0)
    return np.clip(arr.astype(np.float32, copy=False), 0.0, 1.0)


# ---------- multiscale preset parsing ----------
def _parse_multiscale_preset(p: dict) -> dict | None:
    """
    Pull the multiscale config out of a preset dict, sanitized, or None when
    the feature is absent/disabled. Declarative (read straight from the
    preset), so it's available BEFORE abe_run runs — which is what lets us
    record it in the Replay params up front.
    """
    _ms = p.get("multiscale", None)
    if not isinstance(_ms, dict) or not bool(_ms.get("enabled", False)):
        return None
    band_lo = int(np.clip(_ms.get("band_lo", 6), 0, 11))
    band_hi = int(np.clip(_ms.get("band_hi", 8), 0, 11))
    if band_hi < band_lo:
        band_lo, band_hi = band_hi, band_lo
    return {
        "enabled": True,
        "darkstar": bool(_ms.get("darkstar", True)),
        "band_lo": band_lo,
        "band_hi": band_hi,
        "include_residual": bool(_ms.get("include_residual", False)),
        "strength": float(np.clip(_ms.get("strength", 1.0), 0.0, 1.0)),
        "protect_k": float(np.clip(_ms.get("protect_k", 3.0), 1.0, 5.0)),
        "smooth_px": float(np.clip(_ms.get("smooth_px", 2.0), 0.0, 10.0)),
        "feather_pct": float(np.clip(_ms.get("feather_pct", 10.0), 0.0, 50.0)),  # 0 => off
        "sigblur_px": float(np.clip(_ms.get("sigblur_px", 8.0), 0.0, 50.0)),
    }


# ---------- headless apply (NO EXCLUSION AREA) ----------
def apply_abe_via_preset(main_window, doc, preset: dict | None = None):
    """
    Run ABE headlessly (no exclusion polygons; exclusion_mask=None) using preset params.
    Blends with the active mask layer (m*out + (1-m)*src) before committing.

    Optionally runs the multiscale multiplicative-gradient refinement as a
    second stage (mirrors ABEDialog._run_abe). Headless has no exclusion
    polygon, so there is no galaxy-protection composite — a dropped preset
    flattens the whole frame.
    """
    p = dict(preset or {})
    # NOTE: allow degree 0 (RBF-only) to match ABEDialog
    degree      = int(np.clip(p.get("degree",      2), 0, 6))
    num_samples = int(np.clip(p.get("samples",   120), 20, 100000))
    downsample  = int(np.clip(p.get("downsample",  6), 1, 64))
    patch_size  = int(np.clip(p.get("patch",     15), 5, 151))
    use_rbf     = bool(p.get("rbf", True))
    rbf_smooth  = float(p.get("rbf_smooth", 1.0))       # dialog default = 100 × 0.01 = 1.0
    make_bg_doc = bool(p.get("make_background_doc", False))
    seed        = int(p.get("seed", 42))
    correction_mode = str(p.get("correction_mode", "subtract")).lower()
    if correction_mode not in ("subtract", "divide"):
        correction_mode = "subtract"

    # Multiscale config (declarative — known before abe_run so we can store it
    # in the Replay params up front). None when disabled/absent.
    ms_cfg = _parse_multiscale_preset(p)

    src01 = _doc_image_float01(doc)
    if src01 is None:
        return

    # Manual sample points (optional). JSON round-trips as [[x,y],...].
    # abe_run expects FULL-IMAGE pixel coords; None/empty => auto-sample.
    # These are pixel-absolute — meaningful on the same (or same-size) image the
    # points were placed on. Filter to the target's bounds; if that leaves
    # nothing (e.g. dropped on a much smaller image), fall back to auto-sampling.
    manual_points = None
    _mp = p.get("manual_points", None)
    if _mp is not None and len(_mp) > 0:
        mp_arr = np.asarray(_mp, dtype=np.int32)
        if mp_arr.ndim == 2 and mp_arr.shape[1] == 2 and len(mp_arr) > 0:
            H, W = src01.shape[:2]
            keep = (
                (mp_arr[:, 0] >= 0) & (mp_arr[:, 0] < W) &
                (mp_arr[:, 1] >= 0) & (mp_arr[:, 1] < H)
            )
            mp_arr = mp_arr[keep]
            manual_points = mp_arr if len(mp_arr) > 0 else None

    # Sanitize params we actually used (this is what we'll store for Replay)
    params = {
        "degree": degree,
        "samples": num_samples,
        "downsample": downsample,
        "patch": patch_size,
        "rbf": use_rbf,
        "rbf_smooth": rbf_smooth,
        "seed": seed,
        "make_background_doc": make_bg_doc,
        "correction_mode": correction_mode,
        # Replay stores the count only (matches the dialog's _do_apply). The
        # shortcut payload itself carries the full point list via the preset,
        # so shortcut round-trip keeps exact points; "replay last" auto-samples.
        "manual_sample_count": int(len(manual_points)) if manual_points is not None else 0,
    }
    # Carry multiscale config into the Replay record when enabled (keeps legacy
    # presets byte-identical when off).
    if ms_cfg is not None:
        params["multiscale"] = dict(ms_cfg)

    # 🔁 Remember this as the last headless command for Replay
    try:
        remember = getattr(main_window, "remember_last_headless_command", None)
        if remember is None:
            remember = getattr(main_window, "_remember_last_headless_command", None)
        if callable(remember):
            remember("abe", params, description="Automatic Background Extraction")
            try:
                if hasattr(main_window, "_log"):
                    main_window._log(
                        f"[Replay] ABE headless stored: command_id='abe', "
                        f"preset_keys={list(params.keys())}"
                    )
            except Exception:
                pass
    except Exception:
        # Do not block ABE if remembering fails
        pass

    # 🚫 No exclusion polygons in headless mode
    rng = np.random.default_rng(seed if seed >= 0 else None)

    corrected, bg = abe_run(
        src01,
        degree=degree, num_samples=num_samples, downsample=downsample, patch_size=patch_size,
        use_rbf=use_rbf, rbf_smooth=rbf_smooth,
        exclusion_mask=None,
        return_background=True,
        progress_cb=None,
        manual_points=manual_points,
        correction_mode=correction_mode,
        rng=rng,
    )

    # --- Optional multiscale multiplicative-gradient refinement (headless) ---
    # Mirrors ABEDialog._run_abe's Stage 2. Headless has NO exclusion polygon,
    # so there is no protect_blend_mask here — the galaxy-protection composite
    # is a dialog-only feature (a dropped preset flattens the whole frame).
    if ms_cfg is not None and corrected is not None:
        try:
            layers = max(ms_cfg["band_hi"] + 1, 9)

            # Protection mask from the star-inclusive image (see dialog path);
            # gradient band still estimated on the starless copy below.
            mask_from = corrected
            estimate_from = corrected
            if ms_cfg["darkstar"]:
                try:
                    from .remove_stars import darkstar_starless_from_array
                    est_in = np.clip(np.asarray(corrected, dtype=np.float32), 0.0, 1.0)
                    starless, _s, _m = darkstar_starless_from_array(
                        est_in,
                        use_gpu=True,
                        progress_cb=(lambda d, t, s="": True),
                        status_cb=(lambda m: None),
                    )
                    if starless is not None:
                        estimate_from = starless
                except Exception as e:
                    try:
                        if hasattr(main_window, "_log"):
                            main_window._log(f"[ABE/Multiscale] DarkStar unavailable headless ({e}); "
                                             f"estimating on corrected image.")
                    except Exception:
                        pass

            corrected = multiscale_gradient_correct(
                corrected,
                estimate_from=estimate_from,
                mask_from=mask_from,
                layers=layers,
                base_sigma=1.0,
                band_lo=ms_cfg["band_lo"],
                band_hi=ms_cfg["band_hi"],
                include_residual=ms_cfg["include_residual"],
                strength=ms_cfg["strength"],
                protect_k=ms_cfg["protect_k"],
                protect_grow=6,
                gradient_smooth_px=ms_cfg["smooth_px"],
                protect_feather_frac=ms_cfg["feather_pct"] / 100.0,
                protect_blur_px=ms_cfg["sigblur_px"],
                progress_cb=None,
            )
        except Exception as e:
            try:
                if hasattr(main_window, "_log"):
                    main_window._log(f"[ABE/Multiscale] headless refinement failed ({e}); "
                                     f"using base ABE result.")
            except Exception:
                pass

    # Preserve mono vs color wrt original doc
    out = corrected
    if (
        out.ndim == 3 and out.shape[2] == 3
        and (doc.image.ndim == 2 or (doc.image.ndim == 3 and doc.image.shape[2] == 1))
    ):
        out = out[..., 0]

    # mask-aware blend (like dialog)
    out_masked = _blend_with_mask_float(out, src01, doc)

    # Clean mask metadata
    _marr, mid, mname = _active_mask_layer(doc)

    meta = {
        "step_name": "ABE",
        "abe": {
            "degree": degree,
            "samples": num_samples,
            "downsample": downsample,
            "patch": patch_size,
            "rbf": use_rbf,
            "rbf_smooth": rbf_smooth,
            "correction_mode": correction_mode,
            "manual_sample_count": int(len(manual_points)) if manual_points is not None else 0,
            "exclusion": "none",  # explicit marker for audit/history
            "multiscale": params.get("multiscale"),  # None when disabled
        },
        "masked": bool(mid),
        "mask_id": mid,
        "mask_name": mname,
        "mask_blend": "m*out + (1-m)*src",
    }

    step_name = (
        f"ABE (deg={degree}, samples={num_samples}, ds={downsample}, "
        f"patch={patch_size}, rbf={'on' if use_rbf else 'off'}, s={rbf_smooth:.3f})"
    )
    doc.apply_edit(out_masked.astype(np.float32, copy=False),
                   step_name=step_name, metadata=meta)

    if make_bg_doc and bg is not None:
        dm = getattr(main_window, "docman", None)
        if dm is not None:
            base = os.path.splitext(doc.display_name())[0]
            meta_bg = {
                "bit_depth": "32-bit floating point",
                "is_mono": (bg.ndim == 2),
                "source": "ABE background (headless)",
                "from_step": step_name,
            }
            doc_bg = dm.open_array(bg.astype(np.float32, copy=False),
                                   metadata=meta_bg,
                                   title=f"{base}_ABE_BG")
            if hasattr(main_window, "_spawn_subwindow_for"):
                main_window._spawn_subwindow_for(doc_bg)


# ---------- open dialog seeded from preset ----------
def open_abe_with_preset(main_window, preset: dict | None = None):
    dm = getattr(main_window, "doc_manager", getattr(main_window, "docman", None))
    doc = dm.get_active_document() if (dm and hasattr(dm, "get_active_document")) else getattr(dm, "active_document", None)
    if doc is None:
        return
    from .abe import ABEDialog
    dlg = ABEDialog(main_window, doc)
    p = dict(preset or {})
    try:
        dlg.sp_degree.setValue(int(np.clip(p.get("degree", 2), 0, 6)))   # allow 0 (RBF-only)
        dlg.sp_samples.setValue(int(np.clip(p.get("samples", 120), 20, 100000)))
        dlg.sp_seed.setValue(int(np.clip(p.get("seed", 42), -1, 99999)))
        dlg.sp_down.setValue(int(np.clip(p.get("downsample", 6), 1, 64)))
        dlg.sp_patch.setValue(int(np.clip(p.get("patch", 15), 5, 151)))
        dlg.chk_use_rbf.setChecked(bool(p.get("rbf", True)))
        dlg.sp_rbf.setValue(int(np.clip(float(p.get("rbf_smooth", 1.0)) * 100.0, 0, 100000)))

        # correction mode
        _mode = str(p.get("correction_mode", "subtract")).lower()
        dlg.radio_divide.setChecked(_mode == "divide")
        dlg.radio_subtract.setChecked(_mode != "divide")
        # polygons intentionally untouched (== none)

        # Multiscale refinement — seed the widgets if the preset carries them
        # and the dialog has the controls (guards against older builds).
        _ms = p.get("multiscale", None)
        if _ms is not None and hasattr(dlg, "chk_ms_enable"):
            dlg.chk_ms_enable.setChecked(bool(_ms.get("enabled", False)))
            dlg.chk_ms_darkstar.setChecked(bool(_ms.get("darkstar", True)))
            dlg.sp_ms_band_lo.setValue(int(np.clip(_ms.get("band_lo", 6), 0, 11)))
            dlg.sp_ms_band_hi.setValue(int(np.clip(_ms.get("band_hi", 8), 0, 11)))
            dlg.chk_ms_residual.setChecked(bool(_ms.get("include_residual", False)))
            dlg.sp_ms_strength.setValue(int(np.clip(float(_ms.get("strength", 1.0)) * 100.0, 0, 100)))
            dlg.sp_ms_protect.setValue(float(np.clip(_ms.get("protect_k", 3.0), 1.0, 5.0)))
            if hasattr(dlg, "sp_ms_smooth"):
                dlg.sp_ms_smooth.setValue(int(np.clip(_ms.get("smooth_px", 2), 0, 10)))
            if hasattr(dlg, "sp_ms_feather"):
                dlg.sp_ms_feather.setValue(int(np.clip(_ms.get("feather_pct", 10), 0, 50)))
            if hasattr(dlg, "sp_ms_sigblur"):
                dlg.sp_ms_sigblur.setValue(int(np.clip(_ms.get("sigblur_px", 8), 0, 50)))
    except Exception:
        pass

    # Manual sample points — stage as PENDING in its OWN try so a hiccup in the
    # param-setting block above can never skip it. The dialog seeds these as the
    # final step of its deferred showEvent, after the base pixmap is built.
    try:
        _mp = p.get("manual_points", None)
        _log = getattr(main_window, "_log", None)
        if _mp is not None and len(_mp) > 0:
            dlg._pending_manual_points = list(_mp)
            if callable(_log):
                _log(f"[ABE] open_with_preset: staged {len(_mp)} manual point(s) for seeding")
        elif callable(_log):
            _log("[ABE] open_with_preset: preset carried no manual points")
    except Exception:
        pass

    dlg.show(); dlg.raise_(); dlg.activateWindow()