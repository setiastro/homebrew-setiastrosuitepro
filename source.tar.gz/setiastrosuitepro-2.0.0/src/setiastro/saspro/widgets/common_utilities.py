#src/setiastro/saspro/widgets/common_utilities.py
"""
Common UI utilities and shared components.

This module provides centralized implementations of commonly used
UI components and utilities to avoid code duplication across the codebase.

Included:
- AboutDialog: Standard about dialog
- ProjectSaveWorker: Background thread for saving projects
- install_crash_handlers: Global exception/crash handling setup
- UI decoration helpers: DECOR_GLYPHS, strip_ui_decorations
"""

from __future__ import annotations

import sys
import os
import threading
import traceback
import logging
import atexit
import html
from typing import TYPE_CHECKING, Optional, List, Any

from PyQt6.QtCore import QThread, pyqtSignal, QTimer, Qt, QCoreApplication, QSettings, QDate
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                             QMessageBox, QPushButton, QPlainTextEdit,
                             QFormLayout, QLineEdit, QDateEdit, QDialogButtonBox,
                             QCheckBox)

if TYPE_CHECKING:
    from PyQt6.QtWidgets import QApplication, QMdiArea


def _tr(text: str) -> str:
    return QCoreApplication.translate("CommonUtilities", text)


# ---------------------------------------------------------------------------
# Version and Build Info (should be imported from main module)
# ---------------------------------------------------------------------------

def get_version() -> str:
    """Get application version from main module."""
    try:
        from setiastrosuitepro import VERSION
        return VERSION
    except ImportError:
        return "Unknown"


def get_build_timestamp() -> str:
    """Get human-friendly build timestamp from main module."""
    try:
        from setiastrosuitepro import BUILD_TIMESTAMP
    except ImportError:
        return "Unknown"

    if BUILD_TIMESTAMP == "dev":
        # No generated build_info → running from local source checkout
        return _tr("Running locally from source code")
    return BUILD_TIMESTAMP

def supporter_title_suffix() -> str:
    """'  ♥ Name' for the window title, or '' if no credit / hidden."""
    sup = get_supporter()
    if not sup or sup["hidden"]:
        return ""
    return f"  \u2665 {sup['name']}"

# ---------------------------------------------------------------------------
# Licensing
# ---------------------------------------------------------------------------

SOURCE_URL  = "https://github.com/setiastro/setiastrosuitepro"
GPL_URL     = "https://www.gnu.org/licenses/gpl-3.0.html"


def _license_dir():
    """
    Directory holding LICENSE (GPLv3 text) and license.txt (bundled
    third-party licences).

    Frozen build: the installer drops both alongside the executable.
    Source checkout: walk up from this file until LICENSE turns up.
    """
    from pathlib import Path

    if getattr(sys, "frozen", False):
        base = Path(sys.executable).resolve().parent
        if (base / "LICENSE").exists() or (base / "license.txt").exists():
            return base
        mei = getattr(sys, "_MEIPASS", None)      # onefile fallback
        if mei:
            return Path(mei)
        return base

    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "LICENSE").exists():
            return parent
    return here.parent


def find_license_file(name: str) -> Optional[str]:
    """Absolute path to a licence file if it shipped, else None."""
    from pathlib import Path
    try:
        p = Path(_license_dir()) / name
        return str(p) if p.is_file() else None
    except Exception:
        return None


class LicenseViewer(QDialog):
    """
    Plain-text licence viewer.

    Deliberately in-app rather than QDesktopServices.openUrl: LICENSE has no
    file extension, so handing it to the shell prompts "how do you want to
    open this file?" on Windows and does something unpredictable elsewhere.
    """

    def __init__(self, parent, title: str, path: str):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(780, 640)

        lay = QVBoxLayout(self)

        view = QPlainTextEdit(self)
        view.setReadOnly(True)
        view.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        mono = QFont("Courier New")
        mono.setStyleHint(QFont.StyleHint.Monospace)
        mono.setPointSize(9)
        view.setFont(mono)
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                view.setPlainText(fh.read())
        except OSError as e:
            view.setPlainText(self.tr("Could not read {0}\n\n{1}").format(path, e))
        lay.addWidget(view, 1)

        row = QHBoxLayout()
        row.addStretch(1)
        btn = QPushButton(self.tr("Close"))
        btn.clicked.connect(self.accept)
        row.addWidget(btn)
        lay.addLayout(row)

# ---------------------------------------------------------------------------
# Supporter recognition (donationware — recognition only, nothing is gated)
# ---------------------------------------------------------------------------

# Case-insensitive and steal-proof by design: it's freeware, the word is right
# here in the source. Add more entries to hand out different words in different
# donation emails — they all work.
SUPPORTER_CODES = {"firstlight"}


def get_supporter() -> Optional[dict]:
    """Current supporter info from QSettings, or None if nothing was entered.

    Returns the dict even when hidden, so the editor can pre-fill it; the
    About line checks the 'hidden' flag itself before rendering. Keys are
    version-independent so an app update never wipes someone's credit.
    """
    s = QSettings()
    name = str(s.value("supporter/name", "") or "").strip()
    if not name:
        return None
    d0 = QDate.fromString(str(s.value("supporter/since", "")), "yyyy-MM-dd")
    days = d0.daysTo(QDate.currentDate()) if d0.isValid() else None
    hidden = bool(s.value("supporter/hidden", False, type=bool))
    return {"name": name, "since": d0, "days": days, "hidden": hidden}


class SupporterDialog(QDialog):
    """Enter, edit, hide, or show the About-box supporter credit.

    Pure recognition — nothing is unlocked, gated, or expired. Pre-fills from
    QSettings so the same dialog also fixes a typo'd name / wrong date and
    toggles visibility.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Support Seti Astro Suite"))

        existing = get_supporter()
        self._editing = existing is not None

        f = QFormLayout(self)

        self.ed_code = QLineEdit()
        self.ed_code.setPlaceholderText(
            self.tr("(already verified — leave blank)") if self._editing
            else self.tr("code from your donation email"))

        self.ed_name = QLineEdit()
        self.ed_name.setPlaceholderText(self.tr("name or handle to credit"))

        self.dt_since = QDateEdit(QDate.currentDate())
        self.dt_since.setCalendarPopup(True)
        self.dt_since.setDisplayFormat("yyyy-MM-dd")
        self.dt_since.setMaximumDate(QDate.currentDate())

        self.chk_hide = QCheckBox(self.tr("Hide this credit in the About box"))

        if existing:
            self.ed_name.setText(existing["name"])
            if existing["since"].isValid():
                self.dt_since.setDate(existing["since"])
            self.chk_hide.setChecked(existing["hidden"])

        f.addRow(self.tr("Donation code:"),      self.ed_code)
        f.addRow(self.tr("Your name / handle:"), self.ed_name)
        f.addRow(self.tr("First donated:"),      self.dt_since)
        f.addRow("",                             self.chk_hide)

        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                              QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self._accept)
        bb.rejected.connect(self.reject)
        f.addRow(bb)

    def _accept(self):
        code = self.ed_code.text().strip().lower()
        # New supporters must supply a valid code. When editing, a blank code
        # keeps the existing (already-verified) credit; a non-blank one is still
        # checked so a typo there doesn't silently pass.
        if self._editing:
            if code and code not in SUPPORTER_CODES:
                QMessageBox.information(self, self.tr("Support"),
                    self.tr("That code doesn't look right — leave it blank to keep your credit."))
                return
        elif code not in SUPPORTER_CODES:
            QMessageBox.information(self, self.tr("Support"),
                self.tr("That code doesn't look right — check your donation email."))
            return

        name = self.ed_name.text().strip()
        if not name:
            QMessageBox.information(self, self.tr("Support"),
                self.tr("Please enter a name to be credited."))
            return

        s = QSettings()
        s.setValue("supporter/name",   name)
        s.setValue("supporter/since",  self.dt_since.date().toString("yyyy-MM-dd"))
        s.setValue("supporter/hidden", self.chk_hide.isChecked())
        self.accept()


# ---------------------------------------------------------------------------
# About Dialog
# ---------------------------------------------------------------------------

class AboutDialog(QDialog):
    """
    Standard About dialog for Seti Astro Suite.
    """

    def __init__(self, parent: Optional[Any] = None, version: str = "", build_timestamp: str = ""):
        super().__init__(parent)
        self.setWindowTitle(self.tr("About Seti Astro Suite"))

        # Get version info if not provided
        if not version:
            version = get_version()

        # Normalize build_timestamp
        if not build_timestamp:
            build_timestamp = get_build_timestamp()
        else:
            # If someone passed the raw sentinel from the main module
            if build_timestamp == "dev":
                build_timestamp = self.tr("Running locally from source code")

        layout = QVBoxLayout()

        # Stash for _build_about_html() so the supporter credit can be
        # re-rendered in place after the About box is already open.
        self._version = version
        self._build_timestamp = build_timestamp

        label = QLabel(self._build_about_html())
        label.setTextFormat(Qt.TextFormat.RichText)
        label.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        label.setOpenExternalLinks(True)
        label.setWordWrap(True)
        self._about_label = label

        layout.addWidget(label)

        # Buttons for the licence files that shipped with this build. Shown only
        # when the file is actually present, so a source checkout or an install
        # that missed them doesn't offer a dead button.
        btn_row = QHBoxLayout()

        _lic = find_license_file("LICENSE")
        if _lic:
            b_lic = QPushButton(self.tr("License"))
            b_lic.setToolTip(self.tr("GNU General Public License v3"))
            b_lic.clicked.connect(
                lambda _checked=False, p=_lic: LicenseViewer(
                    self, self.tr("License"), p).exec())
            btn_row.addWidget(b_lic)

        _third = find_license_file("license.txt")
        if _third:
            b_third = QPushButton(self.tr("Third-Party Licenses"))
            b_third.setToolTip(self.tr("Licences for the bundled libraries"))
            b_third.clicked.connect(
                lambda _checked=False, p=_third: LicenseViewer(
                    self, self.tr("Third-Party Licenses"), p).exec())
            btn_row.addWidget(b_third)

        # Supporter recognition — button label reflects current state.
        self._btn_support = QPushButton()
        self._btn_support.clicked.connect(self._on_support_clicked)
        self._refresh_support_button()
        btn_row.addWidget(self._btn_support)

        btn_row.addStretch(1)
        b_close = QPushButton(self.tr("Close"))
        b_close.clicked.connect(self.accept)
        btn_row.addWidget(b_close)

        layout.addLayout(btn_row)
        self.setLayout(layout)

    def _build_about_html(self) -> str:
        version = getattr(self, "_version", "") or get_version()
        build_timestamp = getattr(self, "_build_timestamp", "") or ""

        about_lines = [
            f"<h2>Seti Astro's Suite Pro {version}</h2>",
            f"<p>{self.tr('By Franklin Marek')}</p>",
            f"<p>{self.tr('Copyright © 2026 Seti Astro')}</p>",
        ]

        if build_timestamp and build_timestamp != "Unknown":
            about_lines.append(f"<p><b>{self.tr('Build:')}</b> {build_timestamp}</p>")

        # Supporter recognition line — additive and opt-in, shown only when a
        # code has been entered and not hidden. Name is HTML-escaped because
        # this label renders as RichText.
        sup = get_supporter()
        if sup and not sup["hidden"]:
            nm = html.escape(sup["name"])
            since = sup["since"].toString("MMMM yyyy") if sup["since"].isValid() else ""
            if since and sup["days"] is not None:
                tail = f" — {self.tr('supporter since')} {since} ({sup['days']} {self.tr('days')})"
            else:
                tail = ""
            about_lines.append(
                "<p style='color:#d4af37;'>&#9829; "
                f"{self.tr('This build is supported directly by')} <b>{nm}</b>{tail}</p>"
            )

        about_lines.extend([
            f"<p>{self.tr('Website:')} <a href='https://www.setiastro.com'>www.setiastro.com</a></p>",
            f"<p>{self.tr('Source code:')} <a href='{SOURCE_URL}'>{SOURCE_URL}</a></p>",
            f"<p>{self.tr('Donations:')} <a href='https://www.setiastro.com/checkout/donate?donatePageId=65ae7e7bac20370d8c04c1ab'>{self.tr('Click here to donate')}</a></p>",
        ])

        # GPLv3 notice. Kept as the standard wording so it reads as the licence
        # notice it is, not a paraphrase.
        gpl_para = self.tr(
            "Seti Astro Suite Pro is free software: you can redistribute it and/or "
            "modify it under the terms of the GNU General Public License as published "
            "by the Free Software Foundation, version 3 of the License."
        )
        warranty_para = self.tr(
            "This program is distributed in the hope that it will be useful, but "
            "WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY "
            "or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License "
            "for more details."
        )
        gpl_link_text = self.tr("Read the GNU General Public License v3")

        about_lines.extend([
            "<hr>",
            f"<p style='font-size:11px;'>{gpl_para}</p>",
            f"<p style='font-size:11px;'>{warranty_para}</p>",
            f"<p style='font-size:11px;'><a href='{GPL_URL}'>{gpl_link_text}</a></p>",
        ])

        return "".join(about_lines)

    def _refresh_support_button(self):
        sup = get_supporter()
        if sup is None:
            self._btn_support.setText(self.tr("Enter Donation Code…"))
            self._btn_support.setToolTip(
                self.tr("Entered a donation code? Add your name to this build."))
        elif sup["hidden"]:
            self._btn_support.setText(self.tr("Supporter (hidden)…"))
            self._btn_support.setToolTip(
                self.tr("Your credit is hidden — click to edit it or show it again."))
        else:
            self._btn_support.setText(self.tr("♥ Supporter…"))
            self._btn_support.setToolTip(self.tr("Edit or hide your supporter credit."))

    def _on_support_clicked(self):
        if SupporterDialog(self).exec():
            self._about_label.setText(self._build_about_html())
            self._refresh_support_button()



# ---------------------------------------------------------------------------
#sasproject Save Worker
# ---------------------------------------------------------------------------

class ProjectSaveWorker(QThread):
    """
    Background thread for saving projects.
    
    Emits 'ok' signal on success, 'error' signal with message on failure.
    
    Args:
        path: Path to save the project to
        docs: List of documents to save
        shortcuts: Shortcuts configuration
        mdi: MDI area reference
        compress: Whether to compress the project
        window_shelf: Optional window shelf reference
        parent: Parent QObject
        
    Example:
        worker = ProjectSaveWorker(path, docs, shortcuts, mdi, compress=True)
        worker.ok.connect(on_save_complete)
        worker.error.connect(on_save_error)
        worker.start()
    """
    
    ok = pyqtSignal()
    error = pyqtSignal(str)
    
    def __init__(
        self,
        path: str,
        docs: List[Any],
        shortcuts: Any,
        mdi: 'QMdiArea',
        compress: bool,
        window_shelf: Optional[Any] = None,
        parent: Optional[Any] = None
    ):
        super().__init__(parent)
        self.path = path
        self.docs = docs
        self.shortcuts = shortcuts
        self.mdi = mdi
        self.compress = compress
        self.window_shelf = window_shelf
    
    def run(self) -> None:
        """Execute the save operation in background thread."""
        try:
            from setiastro.saspro.project_io import ProjectWriter
            ProjectWriter.write(
                self.path,
                docs=self.docs,
                shortcuts=self.shortcuts,
                mdi=self.mdi,
                compress=self.compress,
                shelf=self.window_shelf,
            )
            self.ok.emit()
        except Exception as e:
            self.error.emit(str(e))


# ---------------------------------------------------------------------------
# UI Decoration Helpers
# ---------------------------------------------------------------------------

DECOR_GLYPHS = "■●◆▲▪▫•◼◻◾◽"

def strip_ui_decorations(s: str) -> str:
    """
    Remove UI decoration glyphs and prefixes from a string.
    
    Strips:
    - Leading glyph characters followed by space
    - "Active View: " prefix
    
    Args:
        s: String to clean
        
    Returns:
        Cleaned string without decorations
        
    Example:
        >>> strip_ui_decorations("● Active View: My Image.fits")
        'My Image.fits'
    """
    s = s or ""
    
    # Strip any number of leading glyph+space
    while len(s) >= 2 and s[1] == " " and s[0] in DECOR_GLYPHS:
        s = s[2:]
    
    # Strip leading Active prefix if present
    ACTIVE = "Active View: "
    if s.startswith(ACTIVE):
        s = s[len(ACTIVE):]
    
    return s


# Alias for backward compatibility
_strip_ui_decorations = strip_ui_decorations


# ---------------------------------------------------------------------------
# Crash/Exception Handlers
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Crash report (the Unhandled Exception box). The report stays in English
# whatever the UI language: it is read by the developer, like the logs.
# ---------------------------------------------------------------------------

REPORT_EMAIL = "frank@setiastro.com"
# Longer mailto: links get cut off or refused by some Windows mail programs;
# the full report always goes to the clipboard as well.
_MAILTO_MAX = 1800


def _app_version_line() -> str:
    try:
        from setiastro.saspro._generated.build_info import APP_VERSION, BUILD_TIMESTAMP
        return f"{APP_VERSION} (built {BUILD_TIMESTAMP})"
    except Exception:
        pass
    return get_version()


def _redact_home(text: str) -> str:
    """The user's home folder as ~, so a pasted report doesn't carry their account name."""
    import re
    home = os.path.expanduser("~")
    if not home or home == "~" or len(home) < 4:
        return text
    variants = {home, home.replace("\\", "/"), home.replace("/", "\\"),
                home.replace("\\", "\\\\")}          # as repr() writes it in messages
    flags = re.IGNORECASE if sys.platform.startswith("win") else 0
    for h in sorted(variants, key=len, reverse=True):
        text = re.sub(re.escape(h), "~", text, flags=flags)
    return text


def _environment_lines() -> list:
    import platform
    lines = [f"SASpro: {_app_version_line()}"]
    try:
        lines.append(f"OS: {platform.platform()} ({platform.machine()})")
    except Exception:
        pass
    lines.append(f"Python: {platform.python_version()}"
                 + (" (installer build)" if getattr(sys, "frozen", False) else ""))
    try:
        from PyQt6.QtCore import QT_VERSION_STR, PYQT_VERSION_STR
        lines.append(f"Qt: {QT_VERSION_STR}, PyQt6 {PYQT_VERSION_STR}")
    except Exception:
        pass
    np_mod = sys.modules.get("numpy")
    if np_mod is not None:
        lines.append(f"numpy: {getattr(np_mod, '__version__', '?')}")
    # Only what is already loaded: importing torch here could take seconds or fail.
    torch = sys.modules.get("torch")
    if torch is not None:
        try:
            parts = [f"torch {torch.__version__}"]
            if getattr(torch.version, "cuda", None):
                parts.append(f"CUDA {torch.version.cuda}"
                             + ("" if torch.cuda.is_available() else " (no GPU found)"))
            elif getattr(torch.version, "hip", None):
                parts.append(f"ROCm {torch.version.hip}")
            if "torch_directml" in sys.modules:
                parts.append("DirectML")
            lines.append("GPU: " + ", ".join(parts))
        except Exception:
            pass
    return lines


def _report_parts(head: str, details: str, thread: str):
    """(versions + the error, traceback), home folder redacted."""
    top = "\n".join(["SASpro crash report", *_environment_lines(),
                     f"Thread: {thread}", "", head])
    return _redact_home(top), _redact_home((details or "").rstrip())


def build_crash_report(head: str, details: str, thread: str = "main") -> str:
    """Versions, the error and its traceback, as one block of text to paste or email."""
    top, tb = _report_parts(head, details, thread)
    return f"{top}\n\n{tb}"


def crash_mailto_url(head: str, details: str, thread: str = "main") -> str:
    """mailto: link with the report as the body, short enough for any mail
    program. If the report is too long the start of the traceback is cut; the
    versions, the error and the innermost frames are kept."""
    from urllib.parse import quote
    top, tb = _report_parts(head, details, thread)
    subject = _redact_home(f"SASpro crash: {head.splitlines()[0] if head else ''}")[:120]
    intro = ("What were you doing when this happened?\n\n\n\n"
             "---- crash report ----\n")
    cut_note = ("(Part of the report was cut to fit an email link. "
                "The full report is on your clipboard: paste it here.)\n")

    def url_for(body: str) -> str:
        body = body.replace("\r\n", "\n").replace("\n", "\r\n")
        return (f"mailto:{REPORT_EMAIL}?subject={quote(subject, safe='')}"
                f"&body={quote(body, safe='')}")

    url = url_for(f"{intro}{top}\n\n{tb}")
    if len(url) <= _MAILTO_MAX:
        return url
    tb_lines = tb.splitlines()
    keep = len(tb_lines)
    while keep > 0:
        keep = keep // 2 if keep > 8 else keep - 1
        url = url_for(f"{intro}{cut_note}{top}\n\n...\n" + "\n".join(tb_lines[-keep:] if keep else []))
        if len(url) <= _MAILTO_MAX:
            return url
    body = intro + cut_note + top          # a huge error message: cut it too
    while len(url_for(body)) > _MAILTO_MAX and len(body) > len(intro) + len(cut_note):
        body = body[: max(len(intro) + len(cut_note), int(len(body) * 0.8))]
    return url_for(body)


def show_crash_box(parent, title: str, head: str, details: str, thread: str = "main") -> None:
    """The Unhandled Exception box: says SASpro is still running and makes the
    error easy to report -- Email Report opens the user's mail program with the
    report filled in, Copy Report puts it on the clipboard. Neither closes the
    box. Nothing is sent by SASpro itself."""
    from PyQt6.QtCore import QUrl
    from PyQt6.QtGui import QDesktopServices, QGuiApplication

    def tr(text):
        return QCoreApplication.translate("CrashHandler", text)

    report = build_crash_report(head, details, thread)
    m = QMessageBox(parent)
    m.setIcon(QMessageBox.Icon.Critical)
    m.setWindowTitle(title)
    m.setText(head)
    m.setInformativeText(tr(
        "SASpro is still running, so you can keep working and save your images.\n\n"
        "To report this, Email Report opens your email program with the report "
        "filled in, addressed to {0}. Copy Report puts it on the clipboard for "
        "webmail or a forum post. The details are below and in saspro.log."
    ).format(REPORT_EMAIL))
    m.setDetailedText(report)

    b_mail = m.addButton(tr("Email Report…"), QMessageBox.ButtonRole.ActionRole)
    b_copy = m.addButton(tr("Copy Report"), QMessageBox.ButtonRole.ActionRole)
    b_close = m.addButton(QMessageBox.StandardButton.Close)
    m.setDefaultButton(b_close)
    m.setEscapeButton(b_close)
    # QMessageBox closes on any button; take these two off its button box so
    # the box stays up (copy, then email, then read the details...).
    for b in (b_mail, b_copy):
        try:
            b.clicked.disconnect()
        except Exception:
            pass
    b_mail.setToolTip(tr(
        "Opens a new email to {0} in your email program, with the report filled in.\n"
        "The full report is also copied to the clipboard. You choose whether to send it."
    ).format(REPORT_EMAIL))
    b_copy.setToolTip(tr("Copy the report (versions, error and traceback) to the clipboard."))

    def _copy():
        QGuiApplication.clipboard().setText(report)
        b_copy.setText(tr("Copied ✓"))

    def _email():
        QGuiApplication.clipboard().setText(report)
        url = QUrl.fromEncoded(crash_mailto_url(head, details, thread).encode("ascii"))
        if QDesktopServices.openUrl(url):
            b_mail.setText(tr("Email Opened ✓"))
        else:
            QMessageBox.information(m, tr("Email Report"), tr(
                "No email program is set up on this computer.\n\n"
                "The report is on your clipboard: paste it into an email to {0}."
            ).format(REPORT_EMAIL))

    b_copy.clicked.connect(_copy)
    b_mail.clicked.connect(_email)
    m.exec()


def install_crash_handlers(app: 'QApplication') -> None:
    import faulthandler
    import tempfile
    from pathlib import Path

    def _get_crash_log_path() -> str:
        try:
            if hasattr(sys, "_MEIPASS"):
                if sys.platform.startswith("win"):
                    log_dir = Path(os.path.expandvars("%APPDATA%")) / "SetiAstroSuitePro" / "logs"
                elif sys.platform.startswith("darwin"):
                    log_dir = Path.home() / "Library" / "Logs" / "SetiAstroSuitePro"
                else:
                    log_dir = Path.home() / ".local" / "share" / "SetiAstroSuitePro" / "logs"
            else:
                # dev fallback
                log_dir = Path("logs")

            log_dir.mkdir(parents=True, exist_ok=True)
            return str(log_dir / "saspro_crash.log")
        except Exception:
            return str(Path(tempfile.gettempdir()) / "saspro_crash.log")

    # 1) Hard crashes → saspro_crash.log
    # faulthandler writes to a raw file fd, so RotatingFileHandler can't manage it.
    # Instead: if the existing crash log has grown past a cap, roll it to .1 and
    # start clean; then append within this session. Bounds the file without
    # losing the most recent prior crash.
    try:
        crash_path = _get_crash_log_path()

        _CRASH_MAX_BYTES = 512_000  # ~0.5 MB cap
        try:
            if os.path.exists(crash_path) and os.path.getsize(crash_path) > _CRASH_MAX_BYTES:
                _prev = crash_path + ".1"
                try:
                    if os.path.exists(_prev):
                        os.remove(_prev)
                    os.replace(crash_path, _prev)  # keep one previous generation
                except Exception:
                    # if the roll fails (locked, perms), fall back to truncation
                    open(crash_path, "w", encoding="utf-8", errors="replace").close()
        except Exception:
            pass

        _crash_log = open(crash_path, "a", encoding="utf-8", errors="replace")
        # Session banner so multiple runs in one file are distinguishable
        try:
            from datetime import datetime as _dt
            _crash_log.write(f"\n===== faulthandler session {_dt.now().isoformat(timespec='seconds')} =====\n")
            _crash_log.flush()
        except Exception:
            pass
        faulthandler.enable(file=_crash_log, all_threads=True)
        atexit.register(_crash_log.close)
        logging.info("Faulthandler crash log: %s", crash_path)
    except Exception:
        logging.exception("Failed to enable faulthandler")

    
    _open_heads: set = set()

    def _show_dialog(title: str, head: str, details: str, thread: str = "main") -> None:
        """Show the error box -- GUI-thread errors only."""
        # Background errors stay with the code that runs them (already logged
        # by the caller). Without this, a slot raising in a moveToThread worker
        # would build the box on that worker thread.
        if threading.current_thread() is not threading.main_thread():
            return

        def _ui():
            # One box per error: an error raised while painting would
            # otherwise stack a new box on every repaint.
            if head in _open_heads:
                return
            _open_heads.add(head)
            try:
                show_crash_box(app.activeWindow(), title, head, details, thread)
            finally:
                _open_heads.discard(head)
        QTimer.singleShot(0, _ui)

    # 2) Any uncaught exception on the main thread
    def _excepthook(exc_type, exc_value, exc_tb):
        tb = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        logging.error("Uncaught exception:\n%s", tb)
        _show_dialog(
            QCoreApplication.translate("CrashHandler", "Unhandled Exception"),
            f"{exc_type.__name__}: {exc_value}",
            tb
        )
    
    sys.excepthook = _excepthook
    
    # 3) Any uncaught exception in background threads (Py3.8+): log only.
    # The code running the thread owns its errors and fallbacks; no box.
    def _threadhook(args: threading.ExceptHookArgs):
        tb = "".join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback))
        logging.error("Uncaught thread exception (%s):\n%s", args.thread.name, tb)
    
    try:
        threading.excepthook = _threadhook  # type: ignore[attr-defined]
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Module exports
# ---------------------------------------------------------------------------

__all__ = [
    'AboutDialog',
    'SupporterDialog',
    'get_supporter',
    'LicenseViewer',
    'find_license_file',
    'SOURCE_URL',
    'GPL_URL',
    'ProjectSaveWorker',
    'DECOR_GLYPHS',
    'strip_ui_decorations',
    '_strip_ui_decorations',  # Backward compatibility
    'install_crash_handlers',
    'get_version',
    'get_build_timestamp',
]
