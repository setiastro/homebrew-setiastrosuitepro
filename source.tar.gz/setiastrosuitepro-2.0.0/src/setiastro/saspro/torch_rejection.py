# src/setiastro/saspro/torch_rejection.py
from __future__ import annotations
import contextlib
import math
import os
import sys
import threading
import numpy as np

# Reduce CUDA caching-allocator fragmentation so VRAM freed by the cosmetic
# pass can be reused by the satellite-removal CNN. Must be set before the first
# CUDA allocation — also set it in the launcher env in case Torch initialises
# CUDA from another module first.
# SASPRO_ALLOC_CONF_PLATFORM_V1
# Linux CUDA only. The option does not exist on Windows, and setting it there
# makes torch warn on EVERY allocation — one line per frame per worker during
# registration, which buries the status pane. Nothing is lost by skipping it:
# the fragmentation this avoids is a Linux problem precisely because WDDM can
# page GPU memory to host and Linux cannot.
if sys.platform.startswith("linux"):
    os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

# One device-wide lock shared by every GPU stage. Calibration cosmetic
# correction (GPU main loop) and satellite trail removal (save/consumer thread)
# run from different threads on the same card; serialising them keeps a single
# large working set resident at a time instead of summing both. Summing both is
# what OOMs a small card on Linux/CUDA, where — unlike Windows WDDM — GPU memory
# cannot page to host.
_GPU_LOCK = threading.RLock()

# Always route through our runtime shim so ALL GPU users share the same backend.
# Nothing heavy happens at import; we only resolve Torch when needed.
from .runtime_torch import import_torch, add_runtime_to_sys_path, best_device

# Algorithms supported by the GPU path here (names match your UI/CPU counterparts)
_SUPPORTED = {
    "Comet Median",
    "Simple Median (No Rejection)",
    "Comet High-Clip Percentile",
    "Comet Lower-Trim (30%)",
    "Comet Percentile (40th)",
    "Simple Average (No Rejection)",
    "Weighted Winsorized Sigma Clipping",
    "Winsorized Sigma Clipping",   # <<< NEW (unweighted)
    "Kappa-Sigma Clipping",
    "Trimmed Mean",
    "Extreme Studentized Deviate (ESD)",
    "Biweight Estimator",
    "Modified Z-Score Clipping",
    "Max Value",
}

# ---------------------------------------------------------------------------
# Lazy Torch resolution (so PyInstaller bootstrap and non-GPU users don’t break)
# ---------------------------------------------------------------------------
_TORCH = None
_DEVICE = None

import warnings

_DML_REDUCE_WARNED = False

def _is_directml_privateuse(dev) -> bool:
    """
    torch-directml uses a PrivateUse backend and the device string usually contains:
      'privateuseone:0'
    The reporter typo'd it as 'privateuserone:0' so we accept both.
    """
    try:
        s = str(dev).lower()
    except Exception:
        return False
    return ("privateuseone" in s) or ("privateuserone" in s)

def _warn_dml_reduce_once():
    global _DML_REDUCE_WARNED
    if _DML_REDUCE_WARNED:
        return
    _DML_REDUCE_WARNED = True
    warnings.warn(
        "DirectML detected (privateuseone). Using device-side sort/sum nan reducers "
        "to avoid a known torch-directml fallback bug (can return empty tensors).",
        RuntimeWarning
    )

_FALLBACK_WARNED: set = set()

def _warn_reduce_fallback_once(op: str, exc: BaseException):
    """
    Announce, once per op per process, that a native nan reducer failed and we
    are on the sort-based fallback.

    Device-side fallbacks avoid host round-trips, but can be slower than native
    reductions. Quantiles retain linear interpolation and medians retain the
    lower-middle convention, including all-NaN output behavior.
    """
    if op in _FALLBACK_WARNED:
        return
    _FALLBACK_WARNED.add(op)
    warnings.warn(
        f"torch.{op} failed on this backend ({type(exc).__name__}: {exc}); "
        f"using the device-side fallback. Results stay "
        f"correct, but this may be slower than a native reduction.",
        RuntimeWarning,
    )


def _get_torch(prefer_cuda: bool = True, prefer_dml: bool = False):
    global _TORCH, _DEVICE
    if _TORCH is not None:
        return _TORCH

    try:
        add_runtime_to_sys_path(lambda *_: None)
    except Exception:
        pass

    # Let runtime_torch install/resolve the right torch stack
    torch = import_torch(prefer_cuda=prefer_cuda, prefer_dml=prefer_dml, status_cb=lambda *_: None)

    # IMPORTANT: honor best_device() (it may return DirectML / privateuseone)
    try:
        _DEVICE = best_device(torch, prefer_cuda=prefer_cuda, prefer_dml=prefer_dml)
    except Exception:
        _DEVICE = None

    _TORCH = torch
    _force_fp32_policy(torch)

    # If best_device failed, fall back conservatively
    if _DEVICE is None:
        try:
            if hasattr(torch, "cuda") and torch.cuda.is_available():
                _DEVICE = torch.device("cuda")
            elif getattr(getattr(torch, "backends", None), "mps", None) and torch.backends.mps.is_available():
                _DEVICE = torch.device("mps")
            else:
                _DEVICE = torch.device("cpu")
        except Exception:
            _DEVICE = torch.device("cpu")

    return _TORCH



def _device():
    if _DEVICE is not None:
        return _DEVICE
    # Default to CPU if torch is not yet resolved; the first GPU call resolves it.
    return None

def torch_available() -> bool:
    """Return True iff we can import/resolve torch via the runtime shim."""
    try:
        _get_torch(prefer_cuda=True)
        return True
    except Exception:
        return False

def gpu_algo_supported(algo_name: str) -> bool:
    return algo_name in _SUPPORTED

# ---------------------------------------------------------------------------
# Helpers (nan-safe reducers) – assume torch is available *inside* callers
# ---------------------------------------------------------------------------
# The transpose costs one extra copy of the stack at peak. Require this many
# multiples of it to be free before paying that, so a card already near its
# limit keeps the old (slower, allocation-free) strided reduction instead of
# being pushed into WDDM paging -- which presents as an indefinite hang, not as
# an error we could catch and retry.
_FRAME_LAST_HEADROOM = 3.0


def _frame_last_affordable(torch, x) -> bool:
    try:
        if getattr(x, "device", None) is None or x.device.type != "cuda":
            return True            # no query available; CUDA is the tight case
        free_b, _total = torch.cuda.mem_get_info()
        return float(free_b) > x.numel() * x.element_size() * _FRAME_LAST_HEADROOM
    except Exception:
        return False


def _to_frame_last(torch, x, dim: int):
    """Return x with `dim` moved last and contiguous, plus the moved dim index.

    Reductions over the FRAME axis are the hot path in every rejection branch,
    and the frame axis is dim 0 -- the slowest-varying one. Each lane of such a
    reduction therefore strides H*W*C*4 bytes between samples, which is why
    torch.nanmedian(x, dim=0) measured 9.2 GB/s on a card that does ~600:
    uncoalesced, not compute-limited.

    Paying one contiguous transpose first and reducing along the fastest axis
    measured 2.5x (mono) to 3.4x (colour) end to end INCLUDING the transpose,
    and is bit-identical -- moving an axis cannot change which sample is the
    median. Already-last-and-contiguous input is passed straight through.
    """
    last = x.dim() - 1
    if dim == last and x.is_contiguous():
        return x, last
    if not _frame_last_affordable(torch, x):
        # Not enough headroom for the copy: reduce along the original axis.
        # Same result, just the slow strided path the caller had before.
        return x, dim
    return x.movedim(dim, -1).contiguous(), last


def _sorted_nanquantile(torch, x, q, dim, *, median=False):
    """Device-only reduction; median uses Torch's lower-middle convention."""
    # Keep each pixel's frame samples adjacent and select only the prefix
    # needed for the requested rank, rather than storing every order statistic.
    x = x.movedim(dim, -1).contiguous()
    dim = x.dim() - 1
    present = ~torch.isnan(x)
    count = present.sum(dim=dim)
    limit = ((x.shape[dim] - 1) // 2 if median else
             int(math.ceil((x.shape[dim] - 1) * float(q)))) + 1
    values = x.masked_fill(~present, float("inf")).topk(
        limit, dim=dim, largest=False, sorted=True).values
    rank = (count.clamp_min(1) - 1) * float(q)
    lower = rank.floor().long()
    a = values.gather(dim, lower.unsqueeze(dim)).squeeze(dim)
    if median:
        result = a
    else:
        upper = rank.ceil().long()
        b = values.gather(dim, upper.unsqueeze(dim)).squeeze(dim)
        result = torch.lerp(a, b, rank - lower)
        result = torch.where(lower == upper, a, result)
    return result.masked_fill(count == 0, float("nan"))


def _nanmedian(torch, x, dim: int):
    if _is_directml_privateuse(getattr(x, "device", None)):
        _warn_dml_reduce_once()
        return _sorted_nanquantile(torch, x, 0.5, dim, median=True)
    try:
        xl, ld = _to_frame_last(torch, x, dim)
        y = torch.nanmedian(xl, dim=ld).values
        if y.numel() == 0:
            raise RuntimeError("nanmedian returned empty tensor")
        return y
    except Exception as exc:
        _warn_reduce_fallback_once("nanmedian", exc)
        return _sorted_nanquantile(torch, x, 0.5, dim, median=True)


def _nan_to_num(torch, x, nan=0.0):
    """Equivalent finite replacement without DirectML's nan_to_num CPU fallback."""
    limits = torch.finfo(x.dtype)
    return torch.where(torch.isnan(x), float(nan), x.clamp(limits.min, limits.max))


def _nanstd_sums(torch, x, dim):
    present = ~torch.isnan(x)
    count = present.sum(dim=dim)
    mean = torch.where(present, x, 0.0).sum(dim=dim) / count.clamp_min(1)
    residual = torch.where(present, x - mean.unsqueeze(dim), 0.0)
    var = (residual * residual).sum(dim=dim) / count.clamp_min(1)
    return var.clamp_min(0).sqrt().masked_fill(count == 0, float("nan"))


def _nanstd(torch, x, dim: int):
    if _is_directml_privateuse(getattr(x, "device", None)):
        _warn_dml_reduce_once()
        return _nanstd_sums(torch, x, dim)
    try:
        xl, ld = _to_frame_last(torch, x, dim)
        y = torch.nanstd(xl, dim=ld, unbiased=False)
        if y.numel() == 0:
            raise RuntimeError("nanstd returned empty tensor")
        return y
    except Exception as exc:
        _warn_reduce_fallback_once("nanstd", exc)
        return _nanstd_sums(torch, x, dim)


def _nanquantile(torch, x, q: float, dim: int):
    if _is_directml_privateuse(getattr(x, "device", None)):
        _warn_dml_reduce_once()
        return _sorted_nanquantile(torch, x, q, dim)
    try:
        xl, ld = _to_frame_last(torch, x, dim)
        y = torch.nanquantile(xl, float(q), dim=ld)
        if y.numel() == 0:
            raise RuntimeError("nanquantile returned empty tensor")
        return y
    except Exception as exc:
        # torch.nanquantile also refuses inputs past ~16M elements on some
        # builds, which a full band exceeds -- that lands here and takes the
        # sorted path, same as a backend failure would.
        _warn_reduce_fallback_once("nanquantile", exc)
        return _sorted_nanquantile(torch, x, q, dim)


def _no_amp_ctx(torch, dev):
    """
    Return a context that disables autocast on this thread for the current device.
    Works across torch 1.13–2.x and CUDA/CPU/MPS. No-ops if unsupported.
    """
    import contextlib
    # PyTorch 2.x unified API
    try:
        ac = getattr(torch, "autocast", None)
        if ac is not None:
            dt = "cuda" if getattr(dev, "type", "") == "cuda" else \
                 "mps"  if getattr(dev, "type", "") == "mps"  else "cpu"
            return ac(device_type=dt, enabled=False)
    except Exception:
        pass
    # Older CUDA AMP API
    try:
        amp = getattr(getattr(torch, "cuda", None), "amp", None)
        if amp and hasattr(amp, "autocast"):
            return amp.autocast(enabled=False)
    except Exception:
        pass
    return contextlib.nullcontext()


# --- add near the top (after imports) ---
def _safe_inference_ctx(torch):
    """
    Return a context manager for inference that won't explode on older or
    backend-variant Torch builds (DirectML/MPS/CPU-only).
    """
    # DirectML views/indexing can request a version counter even for tensors
    # created under inference_mode. no_grad avoids that backend limitation.
    if _is_directml_privateuse(_device()):
        return torch.no_grad()
    try:
        # Prefer inference_mode if both the API and C++ backend support it
        if getattr(torch, "inference_mode", None) is not None:
            _C = getattr(torch, "_C", None)
            if _C is not None and hasattr(_C, "_InferenceMode"):
                return torch.inference_mode()
    except Exception:
        pass
    # Fallbacks
    if getattr(torch, "no_grad", None) is not None:
        return torch.no_grad()
    import contextlib
    return contextlib.nullcontext()

def _force_fp32_policy(torch):
    try:
        # default dtype for new tensors (does not upcast existing)
        torch.set_default_dtype(torch.float32)
    except Exception:
        pass
    # disable “helpful” lower-precision math
    try:
        if hasattr(torch.backends, "cudnn"):
            torch.backends.cudnn.allow_tf32 = False
        if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
            torch.backends.cuda.matmul.allow_tf32 = False
    except Exception:
        pass
    try:
        # prefer strict fp32 matmul kernels where supported
        if hasattr(torch, "set_float32_matmul_precision"):
            torch.set_float32_matmul_precision("highest")
    except Exception:
        pass

# ---------------------------------------------------------------------------
# Rosner Generalized ESD critical values.
# Shared by the GPU reducer here and the numpy reducer in stacking_suite so the
# two paths cannot drift apart (the _rejection_gpu_ok() self-test compares them
# element for element).
# ---------------------------------------------------------------------------

def _norm_ppf(p: float) -> float:
    """
    Inverse standard normal CDF: Acklam's rational approximation plus one Halley
    refinement against erfc, good to ~1e-15 relative. Only used when scipy is
    unavailable (portable builds ship without it).
    """
    if not (0.0 < p < 1.0):
        return float("-inf") if p <= 0.0 else float("inf")

    a = (-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
          1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00)
    b = (-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
          6.680131188771972e+01, -1.328068155288572e+01)
    c = (-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00)
    d = (7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00)

    p_low = 0.02425
    if p < p_low:
        q = math.sqrt(-2.0 * math.log(p))
        x = ((((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5])
             / (((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0)))
    elif p <= 1.0 - p_low:
        q = p - 0.5
        r = q * q
        x = ((((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q
             / ((((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1.0)))
    else:
        q = math.sqrt(-2.0 * math.log(1.0 - p))
        x = -((((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5])
              / (((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0)))

    try:
        e = 0.5 * math.erfc(-x / math.sqrt(2.0)) - p
        u = e * math.sqrt(2.0 * math.pi) * math.exp(0.5 * x * x)
        x = x - u / (1.0 + 0.5 * x * u)
    except (OverflowError, ValueError):
        pass
    return x


def _betacf(a: float, b: float, x: float, itmax: int = 400, eps: float = 3e-16) -> float:
    """Continued fraction for the incomplete beta function (modified Lentz)."""
    tiny = 1e-300
    qab = a + b
    qap = a + 1.0
    qam = a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < tiny:
        d = tiny
    d = 1.0 / d
    h = d
    for m in range(1, itmax + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + aa / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + aa / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < eps:
            break
    return h


def _betainc_reg(a: float, b: float, x: float) -> float:
    """Regularized incomplete beta I_x(a, b), double precision."""
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbt = (math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
           + a * math.log(x) + b * math.log1p(-x))
    bt = math.exp(lbt)
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


def _t_sf(t: float, df: float) -> float:
    """Upper-tail probability P(T_df > t) for t >= 0. Exact to ~1e-14."""
    if t <= 0.0:
        return 0.5
    v = float(df)
    return 0.5 * _betainc_reg(0.5 * v, 0.5, v / (v + t * t))


def _t_ppf(p: float, df: float) -> float:
    """
    Student-t quantile, scipy-free. Inverts the exact survival function by
    bracketing and bisection, seeded from the normal quantile.

    Cornish-Fisher was the obvious cheap choice here and is wrong where it
    matters most: at df = 1 (a 3-frame stack) it understates the 0.00135 cutoff
    by 59%, and it errs LOW, so small stacks would reject far more than the
    nominal threshold. This is exact at every df instead, and the result is
    memoised per integration run, so the cost is irrelevant.
    """
    if not (0.0 < p < 1.0):
        return float("-inf") if p <= 0.0 else float("inf")
    if p == 0.5:
        return 0.0
    if p < 0.5:
        return -_t_ppf(1.0 - p, df)

    v = float(df)
    if v <= 0.0:
        return float("nan")
    if v > 1e7:                       # numerically indistinguishable from normal
        return _norm_ppf(p)

    target = 1.0 - p                  # desired upper-tail probability
    hi = max(_norm_ppf(p), 1.0)
    for _ in range(200):              # grow until the tail is thinner than target
        if _t_sf(hi, v) <= target:
            break
        hi *= 2.0
    else:
        return hi
    lo = 0.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if mid <= lo or mid >= hi:    # exhausted double precision
            break
        if _t_sf(mid, v) > target:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


_ESD_CRIT_CACHE: dict = {}
_ESD_CRIT_LOCK = threading.Lock()


def esd_critical_values(F: int, threshold: float, *, bonferroni: bool = True,
                        legacy: bool = False) -> np.ndarray:
    """
    Critical values lambda_n for Rosner's Generalized ESD, indexed by the number
    of still-active samples n (0..F). Entries for n < 3 are +inf, which disables
    the test: a two-point sample has no leave-one-out scale estimate.

    The statistic these are compared against is the EXTERNALLY studentized
    extreme deviate,

        t = (x_c - mean_loo) / (s_loo * sqrt(1 + 1/(n-1)))   ~  t_{n-2}

    where x_c is the active sample furthest from the active mean and mean_loo /
    s_loo are computed with x_c held out. Under the null that is an exact
    Student-t, so the critical value is just a t quantile -- no need for the
    internally studentized form and its (n-1)/sqrt(n(n-2+t^2)) conversion.

    `threshold` is the UI "sigma" control, converted to a per-PIXEL
    false-rejection rate: alpha = P(Z > threshold) is the chance that ANY
    frame at a given pixel is falsely clipped on clean data. Since the
    statistic is the absolute maximum over nn candidates, the tail
    probability actually passed to the t quantile is alpha / (2*nn).
    `bonferroni` is retained for call compatibility but no longer selects
    behaviour; `legacy=True` restores the pre-fix formula for reproducing
    historical stacks.

    (superseded) threshold was previously a one-sided normal tail
    probability alpha = P(Z > threshold), so threshold=3 gives alpha ~ 1.35e-3 --
    what a user reading the control as "3 sigma" expects for one observation.

    bonferroni chooses WHICH error rate that alpha controls, and the two answers
    are both valid tests of different hypotheses:

      False (default) -- alpha is the PER-FRAME false-rejection rate. A clean
        frame has ~alpha chance of being clipped, independent of stack depth,
        which is what the "sigma" label on the control promises.

      True -- Rosner's published GESD. alpha is spread over the n candidates
        being maximised at this step (p_eff = alpha / n), so it becomes the
        FAMILY-WISE rate: the chance that ANY frame at that pixel is falsely
        flagged. Formally the stricter test -- the deviate under test really is
        the largest of n, not a pre-chosen one.

    The default is False because the power cost of True is severe on exactly the
    stacks SASpro users build. Measured on synthetic 10-sigma-noise stacks with
    one injected outlier, detection rate for a 4-sigma outlier:

        F=16   69% -> 14%      F=64   99.6% -> 16%      F=245   100% -> 1.2%

    i.e. with the correction on, marginal cosmic hits and faint trails on a deep
    stack stop being rejected at all, while the per-frame false-rejection rate
    collapses to 0.001% -- far stricter than the 0.27% the control advertises.
    Set stacking/esd_bonferroni = true if you want the literature test.

    Results are memoised: F and the threshold are constant for a whole
    integration run, so this would otherwise re-run F scipy t.ppf calls for
    every tile.
    """
    F = int(F)
    thr = float(threshold)
    _key = (F, thr, bool(bonferroni), bool(legacy))
    with _ESD_CRIT_LOCK:
        _hit = _ESD_CRIT_CACHE.get(_key)
    if _hit is not None:
        return _hit.copy()

    crit = np.full(max(F + 1, 1), float("inf"), dtype=np.float32)

    try:
        from scipy import stats as _sstats
        p_one = float(_sstats.norm.sf(thr))
        _tppf = lambda q, df: float(_sstats.t.ppf(q, df))
    except Exception:
        p_one = 0.5 * math.erfc(thr / math.sqrt(2.0))
        _tppf = _t_ppf

    # keep the tail probability representable; thr beyond ~7 sigma underflows
    p_one = min(max(p_one, 1e-12), 0.49)

    # SASPRO_ESD_CRIT_FIX_V1
    # R in the ESD branch is the ABSOLUTE externally studentized deviate of
    # the MOST EXTREME of nn active samples. Two corrections are therefore
    # mandatory, and neither is a conservatism knob:
    #   |t| rather than t      -> halve the tail probability
    #   max over nn candidates -> divide it by nn
    # Without them the test runs ~2*nn hot (a factor of 40 at nn=20). Because
    # jstar takes the LARGEST passing step, one spurious late pass discards
    # every earlier removal, so on clean data the rejection count piles up at
    # max_out = F/2 and those pixels come out sqrt(2) noisier than their
    # neighbours -- the sparse speckle that looks like cross-hatch on smooth
    # backgrounds. With the correction the cascade stops on its own.
    for nn in range(3, F + 1):
        if legacy:
            p_eff = max((p_one / nn) if bonferroni else p_one, 1e-15)
        else:
            p_eff = max(p_one / (2.0 * nn), 1e-15)
        lam = _tppf(1.0 - p_eff, nn - 2)
        if lam is not None and np.isfinite(lam) and lam > 0.0:
            crit[nn] = np.float32(lam)

    with _ESD_CRIT_LOCK:
        if len(_ESD_CRIT_CACHE) > 64:
            _ESD_CRIT_CACHE.clear()
        _ESD_CRIT_CACHE[_key] = crit
    return crit.copy()

# Default cross-colour star-protection ratio.
#
# A star is an OPTICAL event: it illuminates every photosite under the PSF
# regardless of which filter sits on top, so a star core's immediately
# adjacent (differently-coloured) photosites are elevated in proportion to
# the PSF shape.  Measured on synthetic RGGB: 0.17-0.52 of the core's own
# excess, and near-constant (0.27-0.30 at fixed FWHM) across a 16x range of
# star brightness, because the ratio is set by PSF shape and not by flux.
#
# A hot pixel is ELECTRICAL: one photosite, no optical footprint.  Measured
# cross-colour support 0.004 and below.
#
# Measured trade curve (synthetic RGGB, hot_sigma = 5):
#
#   ratio | faintest star colour kept   | hot pixels lost on nebulosity
#         | (off-colour phase response) | brighter than
#   ------+-----------------------------+------------------------------
#    0.02 | 0.05 at FWHM 2.0            |  6 sigma   <- too costly
#    0.05 | 0.12 at FWHM 2.0            | 14 sigma
#    0.10 | 0.30 at FWHM 2.0            | 14 sigma   <- strictly worse
#    0.20 | 0.50 at FWHM 2.0            | 29 sigma
#
# 0.05 is chosen because it dominates 0.10: identical hot-pixel cost, but it
# keeps much redder/narrower stars.  Dropping to 0.02 starts losing real
# defects across any nebula, which is the worse trade.
#
# Isolated hot-pixel detection is INDEPENDENT of this knob (their support is
# ~0.00, so every threshold above ~0.01 catches them) and so is the
# false-protection rate on pure noise -- both measured flat from 0.02 to 0.40.
# The knob only arbitrates candidates that sit on real signal.
#
# The error asymmetry favours protection: a false protect leaves one noise
# pixel alone, a false correct eats a star core.
#
# KNOWN LIMITS (synthetic; see the stress runs in the session notes):
#   * below ~FWHM 1.2 px in the MOSAIC grid a star core is spatially
#     indistinguishable from a hot pixel by any neighbour test -- an
#     information limit, not a tuning problem.
#   * OSC behind a narrowband filter weakens the premise, because the
#     off-colour phases genuinely do not see the line.  Below ~0.12
#     off-colour response, lower this or disable the hot pass.
#   * a 3x3-or-larger contiguous hot block self-protects at its centre
#     (corners still correct).  Clusters that big belong in a bad-pixel map.
CFA_STAR_PROTECT_RATIO = 0.05


# ---------------------------------------------------------------------------
# GPU Calibration Pipeline — dark sub, flat div, cosmetic correction
# All operate on tensors already on device to avoid round-trips
# ---------------------------------------------------------------------------

def _upload_calibration_frame(torch, dev, arr: np.ndarray):
    """Upload a numpy calibration frame (dark or flat) to GPU as float32 tensor.
    Handles 2D (mono), 3D CHW, and 3D HWC layouts — always returns (C, H, W)."""
    a = np.asarray(arr, dtype=np.float32)
    if a.ndim == 2:
        a = a[np.newaxis, :, :]          # (1, H, W)
    elif a.ndim == 3 and a.shape[-1] in (1, 3):
        a = a.transpose(2, 0, 1)          # HWC → CHW
    return torch.from_numpy(a).to(dev, dtype=torch.float32, non_blocking=True)


# ---------------------------------------------------------------------------
# Flat-build GPU calibration prep
# ---------------------------------------------------------------------------
# The stacking suite's master-flat tile loop used to do three big CPU passes
# over the (N, th, tw, C) stack right before uploading it to the GPU reducer:
#   1. dark subtract (in-place)
#   2. clip at 0
#   3. per-frame scale multiply (one scalar per frame, or 4 per frame for Bayer)
#
# All three run perfectly well on the device while ts is resident. The hook
# below lets the caller push a group-level dark + per-frame scales ONCE, keyed
# by `group_key`; subsequent tiles pass the same key and skip the CPU prep.
# The device-side prep runs inline in _torch_reduce_tile_impl right after the
# ts upload, so the reducer never sees the "raw" stack — it sees the fully
# calibrated one.
# ---------------------------------------------------------------------------

_FLAT_GROUP_CTX: dict = {}   # group_key -> {"dark_t", "scales_t", "bayer_pattern", "p2i"}
_FLAT_GROUP_LOCK = threading.RLock()


def _bayer_p2i(pat: str):
    """CFA parity → index into the (R, G1, G2, B) scales lane.
    Matches _apply_bayer_scales_stack_inplace in stacking_suite.py."""
    pat = (pat or "RGGB").strip().upper()
    if pat == "RGGB":
        return [[0, 1], [2, 3]]
    if pat == "BGGR":
        return [[3, 1], [2, 0]]
    if pat == "GRBG":
        return [[1, 0], [3, 2]]
    return [[1, 3], [0, 2]]   # GBRG


def _build_flat_group_ctx(torch, dev, dark_full_np, scales_np, bayer_pattern):
    """Upload per-group calibration data once; each tile call then slices
    the dark on-device and multiplies by the per-frame scale."""
    ctx = {}
    if dark_full_np is not None:
        # Reuse _upload_calibration_frame's layout handling: it always
        # returns a (C, H_full, W_full) float32 device tensor.
        ctx["dark_t"] = _upload_calibration_frame(torch, dev, dark_full_np)
    if scales_np is not None:
        s = np.ascontiguousarray(np.asarray(scales_np, dtype=np.float32))
        ctx["scales_t"] = torch.from_numpy(s).to(dev, dtype=torch.float32, non_blocking=False)
    pat = None
    if bayer_pattern:
        pat = (bayer_pattern or "").strip().upper()
        if pat not in ("RGGB", "BGGR", "GRBG", "GBRG"):
            pat = "RGGB"
    ctx["bayer_pattern"] = pat
    if pat:
        ctx["p2i"] = _bayer_p2i(pat)
    return ctx


def release_flat_group_ctx(group_key):
    """Drop a group's cached device tensors. The stacking suite calls this
    once after a flat group's final tile so the next group's dark can slot
    in without the previous one holding onto VRAM. A follow-up
    torch.cuda.empty_cache() is cheap and keeps the small-card headroom
    the integrator and cosmetic pass both depend on."""
    if group_key is None:
        return
    with _FLAT_GROUP_LOCK:
        _FLAT_GROUP_CTX.pop(group_key, None)
    try:
        torch = _TORCH
        if torch is not None and hasattr(torch, "cuda") and torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


def calibration_pipeline_gpu(
    light_np: np.ndarray,
    dark_t,                          # (C,H,W) tensor on GPU or None
    flat_t,                          # (C,H,W) tensor on GPU or None
    pedestal: float = 0.0,
    hot_sigma: float = 3.0,
    cold_sigma: float = 3.0,
    apply_cosmetic: bool = True,
    bayer_pattern: str | None = None,
    protect_sigma: float = 5.0,
    star_ratio: float = CFA_STAR_PROTECT_RATIO,
) -> np.ndarray:
    """
    Full per-frame calibration pipeline on GPU:
      1. dark subtraction (with pedestal offset)
      2. flat division
      3. cosmetic correction (two-pass)

    light_np: (H,W) mono or (H,W,C) HWC or (C,H,W) CHW float32
    Returns: same layout as input, float32
    """
    torch = _get_torch(prefer_cuda=True)
    dev   = _device() or (
        torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    )

    light_np = np.asarray(light_np, dtype=np.float32)

    # remember input layout so we can restore it on output
    was_2d  = (light_np.ndim == 2)
    was_hwc = (light_np.ndim == 3 and light_np.shape[-1] in (1, 3))

    # normalise to CHW for GPU ops
    if was_2d:
        t = torch.from_numpy(light_np[np.newaxis]).to(dev, non_blocking=True)  # (1,H,W)
    elif was_hwc:
        t = torch.from_numpy(
            light_np.transpose(2, 0, 1)
        ).to(dev, non_blocking=True)                                              # (C,H,W)
    else:
        t = torch.from_numpy(light_np).to(dev, non_blocking=True)               # (C,H,W)

    C, H, W = t.shape

    with _safe_inference_ctx(torch), _no_amp_ctx(torch, dev):

        # ── 1. dark subtraction ──────────────────────────────────────
        if dark_t is not None:
            d = dark_t
            if d.shape[0] == 1 and C > 1:
                d = d.expand(C, H, W)
            t = t - d
            if pedestal != 0.0:
                t = t + pedestal
            t = t.clamp(min=0.0)

        # ── 2. flat division ─────────────────────────────────────────
        if flat_t is not None:
            f = flat_t
            if f.shape[0] == 1 and C > 1:
                f = f.expand(C, H, W)
            # flat already normalised (median=1) by caller
            t = t / f.clamp(min=1e-6)

        # ── 3. cosmetic correction ───────────────────────────────────
        if apply_cosmetic:
            t = _cosmetic_correction_tensor(
                torch, dev, t,
                hot_sigma=hot_sigma,
                cold_sigma=cold_sigma,
                bayer_pattern=bayer_pattern,
                protect_sigma=protect_sigma,
                star_ratio=star_ratio,
            )

    # ── back to CPU, restore original layout ─────────────────────────
    out = t.cpu().numpy()               # (C, H, W)
    if was_2d:
        return out[0]                   # (H, W)
    elif was_hwc:
        return out.transpose(1, 2, 0)  # (H, W, C)
    return out                          # (C, H, W)


# Module-level buffer cache — keyed by (device_str, H, W)
_CC_BUFFERS: dict = {}

def _clear_cc_buffers():
    """No-op — retained for callers from the persistent-buffer era.
    The tiled cosmetic pass allocates scratch locally and frees it by
    refcount per frame, so there is nothing to clear."""
    pass

# ---------------------------------------------------------------------------
# CFA (Bayer) cosmetic correction: cross-colour star protection
# ---------------------------------------------------------------------------
def _cfa_phase_stats(plane, torch):
    """Per-CFA-phase background statistics for a 2-D mosaic plane.

    Returns three 2x2 nested lists indexed [y & 1][x & 1]:
      med      - phase median (that phase's background level)
      avg_dev  - mean |x - med| within the phase.  This is the SAME scale the
                 mono path uses for hot/cold sigma, just measured inside one
                 CFA phase, so `hot_sigma=5` means the same thing on a mosaic
                 as it does on mono.
      mad_sig  - 1.4826 * MAD, the robust sigma the star gate normalises by.

    Four phases, not three colours: G1/G2 imbalance is real on most sensors.

    Measuring per phase also fixes two calibration bugs in the whole-frame
    stats this replaces for CFA data:
      * a global MAD-sigma is inflated (~4.5x on a typical OSC sky) by the
        R/G/B background OFFSETS being measured as noise, so `hot_sigma=3`
        behaved like ~10 sigma on a mosaic;
      * the old strided sample hit either one phase or all four depending on
        whether `min(H, W) // 100` happened to be even or odd, i.e. on the
        sensor's dimensions.  Phase-pure sampling makes stride parity moot.
    """
    med = [[0.0, 0.0], [0.0, 0.0]]
    avg = [[0.0, 0.0], [0.0, 0.0]]
    mad = [[0.0, 0.0], [0.0, 0.0]]
    for a in (0, 1):
        for b in (0, 1):
            sub = plane[a::2, b::2]
            sh, sw = int(sub.shape[0]), int(sub.shape[1])
            if sh == 0 or sw == 0:
                med[a][b], avg[a][b], mad[a][b] = 0.0, 1e-8, 1e-8
                continue
            k = max(1, min(sh, sw) // 100)
            smp = sub[::k, ::k].reshape(-1).to('cpu', dtype=torch.float32).numpy()
            if smp.size == 0:
                med[a][b], avg[a][b], mad[a][b] = 0.0, 1e-8, 1e-8
                continue
            m = float(np.median(smp))
            ad = np.abs(smp - m)
            med[a][b] = m
            avg[a][b] = max(float(ad.mean()), 1e-8)
            mad[a][b] = max(1.4826 * float(np.median(ad)), 1e-8)
    return med, avg, mad


def _cfa_flag_map(torch, plane, p, m5, pad, stats,
                  hot_sigma, cold_sigma, star_ratio):
    """Hot/cold flag map for a CFA mosaic plane, with star protection.

    `p` is `plane` reflect-padded by `pad` (must be >= 2) and `m5` is the
    stride-2 same-colour cross median.  Reflect padding preserves CFA phase
    parity at every edge (it mirrors about the edge element, so an odd
    offset lands on an odd-offset phase), which is what makes the stride-1
    cross-colour lookups below colour-correct right up to the border.

    The old structure gate (`m5 > background + protect_sigma * sigma`) is
    degenerate on CFA data: at stride 2 a star core's same-colour neighbours
    are 2 px away, outside the PSF, so a star core cannot move m5 any more
    than a lone hot pixel can.  Measured on synthetic RGGB, m5 reads 2.2
    sigma for a tight star core and 0.9 sigma for a hot pixel -- there is no
    information there to threshold on, at any protect_sigma.

    So split the two questions the old code conflated:

      * REPLACEMENT VALUE stays same-colour / stride-2 (the caller's job).
        Mixing colours there would inject colour artefacts.
      * THE DECISION TO REPLACE uses every colour available, at stride 1.

    Per phase (a, b):
      detection - stride-2 same-colour vs a PER-PHASE scale, so hot_sigma /
                  cold_sigma keep their mono meaning.
      star gate - stride-1 CROSS-COLOUR support, as a ratio of the
                  candidate's own excess, split by axis.

    Expressing support as a RATIO rather than an absolute threshold is what
    makes it brightness-independent: the PSF fixes the neighbour-to-core
    ratio regardless of how bright the star is.

    Splitting by axis and taking the min is what stops a defective column or
    any 1-D cluster from protecting itself -- a star is isotropic and shows
    support on both axes, a column shows it only vertically (measured 84.3
    sigma vertical vs -2.6 sigma cross-axis).
    """
    med, avg, mad = stats
    H, W = int(plane.shape[0]), int(plane.shape[1])
    flagged = torch.zeros((H, W), dtype=torch.bool, device=plane.device)

    for a in (0, 1):
        for b in (0, 1):
            # strided views into the padded plane; original (y, x) -> p[y+pad, x+pad]
            ctr = p[pad + a    : pad + H    : 2, pad + b    : pad + W    : 2]
            n_n = p[pad + a - 1: pad + H - 1: 2, pad + b    : pad + W    : 2]
            n_s = p[pad + a + 1: pad + H + 1: 2, pad + b    : pad + W    : 2]
            n_w = p[pad + a    : pad + H    : 2, pad + b - 1: pad + W - 1: 2]
            n_e = p[pad + a    : pad + H    : 2, pad + b + 1: pad + W + 1: 2]
            m5p = m5[a::2, b::2]

            m_c, ad_c, sg_c = med[a][b], avg[a][b], mad[a][b]
            # N/S always sit in phase (1-a, b); W/E always in phase (a, 1-b)
            m_v, sg_v = med[1 - a][b], mad[1 - a][b]
            m_h, sg_h = med[a][1 - b], mad[a][1 - b]

            # ---- detection: per-phase scale == mono semantics ----------
            scale = max(ad_c * float(hot_sigma), ad_c)
            hot_c = ctr > (m5p + scale)
            cold  = ctr < (m5p - ad_c * float(cold_sigma))

            # ---- cross-colour star gate --------------------------------
            # Taking min() in raw units before normalising is exact: both
            # members of each pair share a phase, so they share (med, sigma).
            z_c = (ctr - m_c) / sg_c
            z_v = (torch.minimum(n_n, n_s) - m_v) / sg_v
            z_h = (torch.minimum(n_w, n_e) - m_h) / sg_h
            sup = torch.minimum(z_v, z_h)
            # sup / z_c > star_ratio, as a multiply (no divide, and a
            # non-positive z_c can't be a hot candidate anyway)
            protect = sup > (float(star_ratio) * z_c.clamp(min=1e-6))

            flagged[a::2, b::2] = (hot_c & (~protect)) | cold
            del ctr, n_n, n_s, n_w, n_e, m5p, z_c, z_v, z_h, sup, protect
            del hot_c, cold

    return flagged


def _cosmetic_correction_tensor(torch, dev, t, hot_sigma, cold_sigma,
                                bayer_pattern=None, protect_sigma=5.0,
                                star_ratio=CFA_STAR_PROTECT_RATIO):
    """
    Two-pass cosmetic correction on a (C,H,W) tensor already on device.
    Detection is whole-frame; the neighbour-median sort is tiled over row
    strips so peak VRAM tracks strip size, not frame size (a 61 MP frame
    otherwise needs ~15-20 GB of transient scratch for the sort alone).
    Stride = 2 for Bayer (same-colour neighbours), 1 otherwise.
    """
    import torch.nn.functional as F
    from setiastro.saspro.cosmetic_metal import median5_along_dim0, sort8_along_dim0

    s = 2 if bayer_pattern else 1
    pad_amt = s
    C, H, W = t.shape
    result = torch.empty_like(t)

    _stride = max(1, min(H, W) // 100)   # 1% sample for background stats

    # ── pick a row-strip height that bounds the sort scratch ──────────
    # the strip's neighbour trio dominates: stacked(f32) + sorted(f32) +
    # a transient int64 sort index = 8*(4+4+8) = 128 B/px; add slack for
    # the int64 gather temporaries → budget at ~200 B/px.
    bytes_per_row = W * 200
    if dev.type == "cuda":
        free_b, _tot = torch.cuda.mem_get_info()
        budget = min(int(free_b * 0.4), 2 * 1024**3)
    else:
        budget = 768 * 1024**2
    strip_h = int(max(64, min(H, budget // max(bytes_per_row, 1))))

    # strip-sized neighbour buffers, reused across strips (last strip
    # slices a [:sh] view). NOTE: no int64 sort_idx buffer — torch.sort's
    # index is taken functionally and freed immediately each strip.
    stacked  = torch.empty((8, strip_h, W), device=dev, dtype=torch.float32)
    sorted_s = torch.empty((8, strip_h, W), device=dev, dtype=torch.float32)

    offsets = [
        (-s, -s), (-s,  0), (-s, +s),
        ( 0, -s),           ( 0, +s),
        (+s, -s), (+s,  0), (+s, +s),
    ]

    for ci in range(C):
        plane = t[ci]

        # ── background stats (strided sample) ─────────────────────────
        sample     = plane[::_stride, ::_stride]
        # background stats on the strided sample, on the HOST: it's ~1e-4 of
        # the frame and this avoids torch.median (slow / CPU-fallback on MPS).
        _s        = sample.reshape(-1).to('cpu', dtype=torch.float32).numpy()
        med_f     = float(np.median(_s))
        _absdev   = np.abs(_s - med_f)
        avg_dev_f = float(_absdev.mean())
        robust_sig= max(1.4826 * float(np.median(_absdev)), 1e-8)
        del _s, _absdev
        del sample

        # CFA: per-phase background stats drive both the detection scale
        # (so sigma keeps its mono meaning) and the star gate's z-scores.
        _cfa_stats = _cfa_phase_stats(plane, torch) if bayer_pattern else None

        # ── reflect-pad the plane once (whole frame) ──────────────────
        p = F.pad(plane.unsqueeze(0).unsqueeze(0),
                  (pad_amt, pad_amt, pad_amt, pad_amt),
                  mode="reflect").squeeze(0).squeeze(0)          # (H+2s, W+2s)

        # ── m5: cross-median of {N,S,E,W,center} (whole frame) ────────
        five = torch.stack((
            p[0:H,                   pad_amt:W+pad_amt],          # N
            p[2*pad_amt:H+2*pad_amt, pad_amt:W+pad_amt],          # S
            p[pad_amt:H+pad_amt,     0:W],                        # W
            p[pad_amt:H+pad_amt,     2*pad_amt:W+2*pad_amt],      # E
            plane,                                                # center
        ), dim=0)
        m5 = median5_along_dim0(five, torch)  # 5-elt median, min/max only
        del five

        # ── detection + star protection (whole frame) ─────────────────
        if bayer_pattern:
            # CFA: per-phase detection scale + cross-colour star gate.
            # protect_sigma is deliberately unused here -- the stride-2
            # structure gate it drives carries no information on a mosaic.
            flagged = _cfa_flag_map(
                torch, plane, p, m5, pad_amt, _cfa_stats,
                hot_sigma=hot_sigma, cold_sigma=cold_sigma,
                star_ratio=star_ratio,
            )
        else:
            scale_f     = max(avg_dev_f * float(hot_sigma), avg_dev_f)
            hot_thresh  = m5 + scale_f
            cold_thresh = m5 - avg_dev_f * float(cold_sigma)

            hot_candidates = plane > hot_thresh
            cold_map       = plane < cold_thresh
            #sasprotect resolved signal: a lone hot pixel can't move m5, a
            # star core can.
            protect_thr = med_f + float(protect_sigma) * robust_sig
            structure   = m5 > protect_thr
            flagged     = (hot_candidates & (~structure)) | cold_map
            del hot_candidates, cold_map, structure, hot_thresh, cold_thresh

        # padded flagged mask for neighbour lookups (whole frame)
        fp = F.pad(flagged.float().unsqueeze(0).unsqueeze(0),
                   (pad_amt, pad_amt, pad_amt, pad_amt),
                   mode="reflect").squeeze(0).squeeze(0)

        # ── replacement, tiled over row strips ────────────────────────
        for y0 in range(0, H, strip_h):
            y1 = min(H, y0 + strip_h)
            sh = y1 - y0
            st = stacked[:, :sh]          # views (contiguous last strip is short)
            so = sorted_s[:, :sh]

            p_strip  = p[y0 : y1 + 2 * pad_amt]     # (sh+2s, W+2s)
            fp_strip = fp[y0 : y1 + 2 * pad_amt]

            for i, (dy, dx) in enumerate(offsets):
                r0, c0 = dy + pad_amt, dx + pad_amt
                nbr_vals    = p_strip[r0:r0 + sh, c0:c0 + W]
                nbr_flagged = fp_strip[r0:r0 + sh, c0:c0 + W] > 0.5
                torch.where(nbr_flagged,
                            nbr_vals.new_full((), float("inf")),
                            nbr_vals, out=st[i])

            # flagged neighbours are +inf and sort to the top; index is
            # transient and freed here (strip-sized, not frame-sized)
            so.copy_(st)
            sort8_along_dim0(so, torch)   # 8-elt sort, min/max only (no torch.sort)

            raw_count = (st < float("inf")).sum(dim=0)   # clean neighbours
            vc        = raw_count.clamp(min=1)
            mid_lo    = ((vc - 1) // 2).unsqueeze(0)
            mid_hi    = (vc // 2).unsqueeze(0)
            rep = 0.5 * (so.gather(0, mid_lo).squeeze(0) +
                         so.gather(0, mid_hi).squeeze(0))
            # all 8 neighbours flagged → fall back to the cross median
            rep = torch.where(raw_count == 0, m5[y0:y1], rep)

            torch.where(flagged[y0:y1], rep, plane[y0:y1], out=result[ci][y0:y1])

        del p, fp, m5, flagged

    return result

def prepare_calibration_frame(
    arr: np.ndarray,
    frame_type: str,          # "dark" or "flat"
    normalize_flat: bool = True,
) -> np.ndarray:
    """
    Prepare a master dark or flat for upload:
    - ensures float32
    - for flat: normalises each channel to median=1, guards zeros
    Returns (C, H, W) float32 numpy array ready for _upload_calibration_frame.
    """
    a = np.asarray(arr, dtype=np.float32)

    # normalise layout to CHW
    if a.ndim == 2:
        a = a[np.newaxis]
    elif a.ndim == 3 and a.shape[-1] in (1, 3):
        a = a.transpose(2, 0, 1)

    if frame_type == "flat" and normalize_flat:
        for ci in range(a.shape[0]):
            band  = a[ci]
            v     = band[np.isfinite(band) & (band > 0)]
            denom = float(np.median(v)) if v.size else 1.0
            denom = denom if (np.isfinite(denom) and denom > 0) else 1.0
            a[ci] = band / denom
        a = np.nan_to_num(a, nan=1.0, posinf=1.0, neginf=1.0)
        a[a == 0] = 1.0

    return a

# ---------------------------------------------------------------------------
# GPU Cosmetic Correction
# ---------------------------------------------------------------------------
def cosmetic_correction_gpu(
    image: np.ndarray,
    hot_sigma: float = 3.0,
    cold_sigma: float = 3.0,
    bayer_pattern: str | None = None,
    protect_sigma: float = 5.0,
    star_ratio: float = CFA_STAR_PROTECT_RATIO,
) -> np.ndarray:
    """
    Two-pass cosmetic correction on GPU.
    bayer_pattern: if set (e.g. "RGGB"), uses stride-2 neighbors so only
                   same-color CFA pixels are compared. Otherwise uses stride-1
                   for debayered/mono images.

    With a bayer_pattern set, detection is calibrated PER CFA PHASE (so
    hot_sigma / cold_sigma mean the same thing as on mono) and star cores
    are protected by cross-colour neighbour support rather than by the
    stride-2 structure gate, which carries no information on a mosaic.
    `protect_sigma` applies to the mono/debayered path only; `star_ratio`
    applies to the CFA path only.  See _cfa_flag_map.
    """
    torch = _get_torch(prefer_cuda=True)
    dev = _device() or (torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu"))

    img = np.asarray(image, dtype=np.float32)
    was_gray = (img.ndim == 2)
    if was_gray:
        img = img[:, :, None]

    H, W, C = img.shape
    t = torch.from_numpy(img.transpose(2, 0, 1)).to(dev, dtype=torch.float32)
    result = torch.empty_like(t)

    # stride-2 for Bayer (same-color neighbors), stride-1 for mono/debayered
    s = 2 if bayer_pattern else 1

    with _safe_inference_ctx(torch), _no_amp_ctx(torch, dev):
        for ci in range(C):
            plane = t[ci]  # (H, W)

            med_val = plane.median()
            avg_dev = (plane - med_val).abs().mean()
            # robust background sigma for the structure gate (sampled — a
            # full MAD on 40M+ px is wasteful; 1% is plenty for a threshold)
            _gs = max(1, min(H, W) // 100)
            robust_sigma = torch.clamp(
                1.4826 * (plane[::_gs, ::_gs] - med_val).abs().median(),
                min=1e-8,
            )

            # CFA: per-phase background stats (see _cfa_phase_stats)
            _cfa_stats = _cfa_phase_stats(plane, torch) if bayer_pattern else None

            # pad by stride amount so border pixels are handled cleanly
            p = torch.nn.functional.pad(
                plane.unsqueeze(0).unsqueeze(0),
                (s, s, s, s), mode='reflect'
            ).squeeze(0).squeeze(0)
            # p: (H+2s, W+2s)

            north  = p[0:H,       s:W+s  ]
            south  = p[2*s:H+2*s, s:W+s  ]
            west   = p[s:H+s,     0:W    ]
            east   = p[s:H+s,     2*s:W+2*s]
            center = plane

            five = torch.stack([north, south, west, east, center], dim=0)
            m5 = five.median(dim=0).values

            if bayer_pattern:
                # ── CFA: per-phase detection + cross-colour star gate ──
                # The stride-2 structure gate below is degenerate on a
                # mosaic (a star core can't move m5 either), so replace it
                # outright rather than stacking another threshold on it.
                flagged = _cfa_flag_map(
                    torch, plane, p, m5, s, _cfa_stats,
                    hot_sigma=hot_sigma, cold_sigma=cold_sigma,
                    star_ratio=star_ratio,
                )
            else:
                scale       = torch.clamp(avg_dev * hot_sigma, min=float(avg_dev))
                hot_thresh  = m5 + scale
                cold_thresh = m5 - avg_dev * cold_sigma

                hot_candidates = plane > hot_thresh
                cold_map       = plane < cold_thresh

                # ── structure gate: protect resolved signal (stars / nebula) ──
                # A hot pixel is a lone spike and cannot move a local median; a
                # star or nebula core has spatial extent, so its local median is
                # genuinely elevated. Gate the hot pass on m5 (the 5-px cross
                # median, already robust to an isolated hot centre) vs a global
                # robust background: patches whose median clears protect_sigma
                # sigmas above background are real signal and are left untouched.
                protect_thr = med_val + float(protect_sigma) * robust_sigma
                structure   = m5 > protect_thr
                hot_map     = hot_candidates & (~structure)

                flagged = hot_map | cold_map

            # --- START OPTIMIZED SPARSE PROCESSING ---
            # 1. Find the 1D coordinates of the bad pixels
            fy, fx = torch.where(flagged)

            # Default state is the original uncorrected plane
            result[ci] = plane.clone()

            # Only do the heavy math if we actually found bad pixels
            if len(fy) > 0:
                # 8 neighbors at stride s
                offsets = [
                    (-s, -s), (-s,  0), (-s, +s),
                    ( 0, -s),           ( 0, +s),
                    (+s, -s), (+s,  0), (+s, +s),
                ]

                flagged_pad = torch.nn.functional.pad(
                    flagged.float().unsqueeze(0).unsqueeze(0),
                    (s, s, s, s), mode='reflect'
                ).squeeze().bool()

                plane_pad2 = torch.nn.functional.pad(
                    plane.unsqueeze(0).unsqueeze(0),
                    (s, s, s, s), mode='reflect'
                ).squeeze()

                # Shift coordinates into the padded array space
                fy_pad = fy + s
                fx_pad = fx + s

                neighbor_stack = []
                for dy, dx in offsets:
                    # Gather ONLY the neighbors for the flagged pixels (returns a 1D tensor of size N)
                    nbr_vals = plane_pad2[fy_pad + dy, fx_pad + dx]
                    nbr_flagged = flagged_pad[fy_pad + dy, fx_pad + dx]

                    nbr_clean = torch.where(
                        nbr_flagged,
                        torch.full_like(nbr_vals, float('nan')),
                        nbr_vals
                    )
                    neighbor_stack.append(nbr_clean)

                # Stack is now (8, N) instead of (8, H, W). Massive memory savings.
                stacked = torch.stack(neighbor_stack, dim=0)

                stacked_inf = torch.where(torch.isnan(stacked),
                                          torch.full_like(stacked, float('inf')), stacked)
                sorted_s, _ = stacked_inf.sort(dim=0)

                valid_count = (~torch.isnan(stacked)).sum(dim=0).clamp(min=1)
                mid_lo = ((valid_count - 1) // 2).long()
                mid_hi = (valid_count       // 2).long()

                rep_lo      = sorted_s.gather(0, mid_lo.unsqueeze(0)).squeeze(0)
                rep_hi      = sorted_s.gather(0, mid_hi.unsqueeze(0)).squeeze(0)
                replacement = (rep_lo + rep_hi) * 0.5

                # If all 8 neighbors were bad (inf), fall back to the local median m5
                m5_bad = m5[fy, fx]
                replacement = torch.where(torch.isinf(replacement), m5_bad, replacement)

                # Patch only the bad pixels in the result
                result[ci][fy, fx] = replacement
            # --- END OPTIMIZED SPARSE PROCESSING ---

    out = result.cpu().numpy().transpose(1, 2, 0)
    if was_gray:
        return out[:, :, 0]
    return out

# ---------------------------------------------------------------------------
# Robust reduction helpers (shared by the rejection branches below)
# ---------------------------------------------------------------------------
def _scalar_like(torch, x, value: float):
    """A 0-d tensor matching x's dtype/device, for broadcasting into where().

    torch.where(cond, x, zeros_like(x)) allocates and memsets a buffer the size
    of the whole stack purely to hand one constant to one kernel. A 0-d tensor
    broadcasts to the same result, allocates nothing measurable, and is
    bit-identical. Measured 1.47x on the sum path at 70 MB; the bigger win is
    the allocation that never happens, on a card where exceeding VRAM means
    paging rather than an error.
    """
    return torch.zeros((), dtype=x.dtype, device=x.device) if value == 0.0 \
        else torch.full((), value, dtype=x.dtype, device=x.device)


def _masked_sum(torch, x, mask, dim: int):
    """Sum of x over `mask`. NaN-safe: masked-out lanes are replaced by 0
    *before* any arithmetic, so NaN/Inf in invalid lanes can never poison
    the result (NaN * 0 == NaN, which the old `ts.mul(w_eff)` pattern hit).

    The zero comes from a 0-d tensor that BROADCASTS rather than from
    zeros_like(x): the latter allocated and memset a full stack-sized buffer
    on every call purely to be read once and discarded. Measured 1.47x on a
    70 MB stack, bit-identical.
    """
    zero = torch.zeros((), dtype=x.dtype, device=x.device)
    return torch.where(mask, x, zero).sum(dim=dim)


def _mad_sigma(torch, x_nan, med, dim: int):
    """Robust per-pixel scale: 1.4826 * MAD (consistent with Gaussian sigma).
    Unlike a plain standard deviation, this is immune to satellite trails /
    plane trails / cosmic rays inflating the scale estimate."""
    mad = _nanmedian(torch, (x_nan - med.unsqueeze(dim)).abs(), dim=dim)
    return (1.4826 * mad).clamp_min(1e-10)


# Shared convergence policy for the iterative reducers. Exported so the numpy
# mirrors in stacking_suite use exactly the same rule — if the two paths
# disagree on when to stop iterating, _rejection_gpu_ok() can see a mismatch on
# a borderline pixel and silently drop the whole integration to CPU.
_CONVERGENCE_MIN_ITERS = 5     # below this, the device sync costs more than it saves
_WINSOR_CONV_TOL = 5e-4        # relative change in sigma, PixInsight's threshold


def _winsorized_center_scale(torch, ts, valid, iterations: int = 3, winsor_k: float = 1.5):
    """
    Huber-style Winsorized estimate of per-pixel center and scale — the same
    scheme PixInsight and APP use for 'Winsorized Sigma Clipping'.

    Why: measuring sigma on the raw stack lets a bright outlier inflate sigma
    so much that it can never be clipped (a single outlier among N frames is
    bounded at z = sqrt(N), so with N=8 and kappa=3 a trail is mathematically
    un-rejectable). Instead we:
      1. seed with median and 1.4826*MAD (both robust),
      2. clamp ('winsorize') the stack to med +/- winsor_k * sigma,
      3. re-measure std on the winsorized stack, undoing the
         winsorization-induced shrinkage with Huber's 1.134 correction
         (exact for winsor_k = 1.5),
      4. iterate to convergence.
    Sigma therefore converges to the sigma of the *uncontaminated* pixel
    distribution, and the subsequent sigma_low/sigma_high rejection pass
    behaves like APP/PI at the same settings.
    """
    x = ts.masked_fill(~valid, float("nan"))
    med = _nanmedian(torch, x, dim=0)
    sigma = _mad_sigma(torch, x, med, dim=0)
    cnt = valid.sum(dim=0).clamp_min(1).to(ts.dtype)
    n_it = max(1, int(iterations))
    # Convergence exit (PixInsight's rule: stop once sigma moves by less than
    # 0.05% relative). Only armed for deep iteration counts: the check needs a
    # device->host sync, which drains the queue and breaks the overlap between
    # this tile's compute and the next tile's upload. At the default of 3 that
    # sync cannot pay for itself, so the loop just runs out; at 8 or 10 it
    # typically exits after 3 and saves most of the pass. The numpy reducer in
    # stacking_suite applies this identical rule so the two paths stay in
    # lockstep for _rejection_gpu_ok().
    check_conv = n_it >= _CONVERGENCE_MIN_ITERS
    for it in range(n_it):
        lo = (med - winsor_k * sigma).unsqueeze(0)
        hi = (med + winsor_k * sigma).unsqueeze(0)
        # torch.minimum/maximum propagate NaN, so invalid lanes stay NaN
        xw = torch.minimum(torch.maximum(x, lo), hi)
        # Clamping around the median cannot change that order statistic.
        # Recomputing it here sorted the same frame samples every iteration.
        mean_w = _masked_sum(torch, xw, valid, dim=0) / cnt
        var = _masked_sum(torch, (xw - mean_w.unsqueeze(0)) ** 2, valid, dim=0) / cnt
        sigma_new = (1.134 * var.clamp_min(0.0).sqrt()).clamp_min(1e-10)

        if check_conv and it + 1 < n_it:
            rel = ((sigma_new - sigma).abs() / sigma.clamp_min(1e-10)).max()
            sigma = sigma_new
            try:
                if float(rel) < _WINSOR_CONV_TOL:
                    break
            except Exception:
                pass
        else:
            sigma = sigma_new
    return med, sigma


def _weighted_mean_or(torch, ts, keep, w, fallback):
    """Weighted mean of `ts` over `keep`; `fallback` where nothing survives.
    NaN-safe: rejected/invalid lanes never enter the arithmetic."""
    w_eff = w * keep.to(ts.dtype)
    _zero = torch.zeros((), dtype=ts.dtype, device=ts.device)
    num = (torch.where(keep, ts, _zero) * w_eff).sum(dim=0)
    den = w_eff.sum(dim=0)
    return torch.where(den > 1e-20, num / den.clamp_min(1e-20), fallback)



# ---------------------------------------------------------------------------
# ESD: sorted peel + optional CUDA-graph replay
# ---------------------------------------------------------------------------
# The shipping loop ran max_out = F/2 iterations, each doing ~17 reductions
# over the whole (F,H,W,C) stack, so its cost was O(F^2). Profiled on a
# 3070 Ti at 16x8488x128 that was 6765 CUDA kernels and 321 ms a band, with
# `where` alone 18% of device time -- against 41 ms for Winsorized.
#
# THE OBSERVATION THAT FIXES IT
#   Each Rosner step removes the active sample FARTHEST FROM THE ACTIVE MEAN.
#   |x - mean| is convex in x, so over a finite set it is maximised at an
#   endpoint: the active minimum or the active maximum, never anything in
#   between. The procedure therefore only ever peels from the two ends, which
#   means the active set is always a CONTIGUOUS SLICE of the sorted sample.
#
#   So: sort once, then each step reads two values per pixel instead of F, and
#   the running sum / sum-of-squares update in O(1). Every per-step tensor
#   drops from (F,H,W,C) to (H,W,C).
#
#   Nothing needs a per-frame removal-step array either. The rejected set is
#   just "the lowest keep_lo and the highest keep_hi order statistics", so two
#   threshold VALUES rebuild the whole mask in one pass at the end.
#
# WHY THE GRAPH
#   What remains is ~64 steps of tiny tensors, and tiny is the problem: a bare
#   elementwise op costs ~35 us of CPU dispatch on Windows whether the tensor
#   holds 64 elements or 135,808. Measured, the peel loop is 100%
#   CPU-dispatch-bound -- CPU queue time equals wall time, the GPU idles. A
#   CUDA graph replays the whole loop as one launch. torch.compile is not an
#   alternative on the primary target: no Triton on Windows.
#
# Measured end to end at 16x8488, F=128: 315 -> 46 ms (6.9x), mono; 929 -> 161
# ms colour. Below ~16 frames the sort stops paying for itself, so the old
# branch is kept for shallow stacks (see _ESD_PEEL_MIN_FRAMES).

# Measured at 16x8488 on a 3070 Ti, patched vs pre-patch:
#   F=128  5.3x    F=64  3.1x    F=32  2.0x    F=24  1.8x
#   F=16   0.9x with the peel but WITHOUT the graph  <- hence one threshold
# The peel on its own only reaches ~1.5x, so below the depth where capture is
# allowed the original loop is still the better branch. One constant, not two,
# so there is no window where half the optimisation runs.
_ESD_PEEL_MIN_FRAMES = 16
_ESD_GRAPH_MIN_FRAMES = _ESD_PEEL_MIN_FRAMES
_ESD_GRAPH_CACHE = {}          # (shape, F, max_out) -> captured graph + buffers
# Two entries: a run has one band shape plus a shorter final band, and evicting
# between them would re-capture on every group.
_ESD_GRAPH_CACHE_MAX = 2
_ESD_GRAPH_LOCK = threading.RLock()
# Capture pins a stack-sized buffer per entry. Windows does not OOM when VRAM
# runs out -- WDDM pages it to host over PCIe, which presents as the GPU
# thrashing indefinitely rather than as an error we could catch. So require
# real headroom before capturing, and fall back to the eager peel (which still
# beats the original and holds nothing) when it is not there.
_ESD_GRAPH_HEADROOM = 6.0      # multiples of the stack that must be free


def _esd_graph_affordable(torch, dev, stack_bytes: int) -> bool:
    """True when capturing a graph for this band will not crowd the card."""
    try:
        if dev.type != "cuda":
            return False
        free_b, _total = torch.cuda.mem_get_info()
        need = float(stack_bytes) * _ESD_GRAPH_HEADROOM
        with _ESD_GRAPH_LOCK:
            cached = len(_ESD_GRAPH_CACHE)
        # An entry we already hold is paid for; only a NEW capture adds cost.
        return float(free_b) > need or cached >= 1
    except Exception:
        return False


def _esd_peel_step(torch, vals, lo, hi, n, S, Q, cum_lo, cum_hi,
                   keep_lo, keep_hi, crit, F):
    """One Rosner step on the sorted sample. Every tensor here is (H,W,C).

    Must stay free of host syncs (no .item(), no bool(), no printing): the
    whole loop is captured into a CUDA graph, and a sync inside the captured
    region makes capture fail.
    """
    nf = n.to(torch.float64)
    can = n >= 3
    mean = S / nf.clamp_min(1.0)
    a = vals.gather(0, lo.unsqueeze(0)).squeeze(0).double()
    b = vals.gather(0, hi.unsqueeze(0)).squeeze(0).double()
    a = torch.where(torch.isfinite(a), a, torch.zeros_like(a))
    b = torch.where(torch.isfinite(b), b, torch.zeros_like(b))
    da = (a - mean).abs()
    db = (b - mean).abs()
    take_lo = da >= db
    dmax = torch.maximum(da, db)
    xc = torch.where(take_lo, a, b)

    # ss about the active mean, from centred running sums. Centring (done by
    # the caller) is what keeps Q - S^2/n away from catastrophic cancellation:
    # raw sky values are ~0.05 with sigma ~0.004, so uncentred sums would lose
    # most of the variance to rounding. The accumulators are float64 but only
    # (H,W,C) -- about 1 MB -- so the precision is free.
    ss_all = (Q - S * S / nf.clamp_min(1.0)).clamp_min(0.0)
    n_loo = (nf - 1.0).clamp_min(1.0)
    ss_loo = (ss_all - dmax * dmax * (nf / n_loo)).clamp_min(0.0)
    std_loo = (ss_loo / (n_loo - 1.0).clamp_min(1.0)).sqrt().clamp_min(1e-12)
    R = dmax * (nf / n_loo).sqrt() / std_loo
    pass_j = can & (R > crit[n.clamp(0, F)])

    took_lo = take_lo & can
    took_hi = (~take_lo) & can
    cum_lo = cum_lo + took_lo.long()
    cum_hi = cum_hi + took_hi.long()
    # jstar is the LARGEST passing step, so simply overwriting on every pass
    # leaves the last one standing -- no (max_out,H,W,C) `passed` array.
    keep_lo = torch.where(pass_j, cum_lo, keep_lo)
    keep_hi = torch.where(pass_j, cum_hi, keep_hi)

    S = torch.where(can, S - xc, S)
    Q = torch.where(can, Q - xc * xc, Q)
    n = torch.where(can, n - 1, n)
    lo = torch.where(took_lo, lo + 1, lo)
    hi = torch.where(took_hi, hi - 1, hi)
    return lo, hi, n, S, Q, cum_lo, cum_hi, keep_lo, keep_hi


def _esd_run_peel(torch, dev, vals_c, state, crit, F, max_out, use_graph):
    """Run max_out peel steps, via a captured CUDA graph when that is safe.

    Falls back to the eager loop on any capture failure -- a graph is a pure
    optimisation and must never be the reason an integration dies.
    """
    if not use_graph:
        out = state
        for _ in range(max_out):
            out = _esd_peel_step(torch, vals_c, *out, crit, F)
        return out[7], out[8]

    key = (tuple(state[0].shape), int(F), int(max_out))
    try:
        with _ESD_GRAPH_LOCK:
            entry = _ESD_GRAPH_CACHE.get(key)
            if entry is None:
                vals_buf = vals_c.clone()
                crit_buf = crit.clone()
                st_in = tuple(v.clone() for v in state)
                # Warm up on a side stream first; capturing a cold allocator
                # records allocations that will not exist on replay.
                s = torch.cuda.Stream()
                s.wait_stream(torch.cuda.current_stream())
                with torch.cuda.stream(s):
                    tmp = tuple(v.clone() for v in st_in)
                    for _ in range(3):
                        tmp = _esd_peel_step(torch, vals_buf, *tmp, crit_buf, F)
                torch.cuda.current_stream().wait_stream(s)
                g = torch.cuda.CUDAGraph()
                with torch.cuda.graph(g):
                    out = tuple(st_in)
                    for _ in range(max_out):
                        out = _esd_peel_step(torch, vals_buf, *out, crit_buf, F)
                    st_out = out
                if len(_ESD_GRAPH_CACHE) >= _ESD_GRAPH_CACHE_MAX:
                    _ESD_GRAPH_CACHE.clear()
                entry = (g, st_in, st_out, vals_buf, crit_buf)
                _ESD_GRAPH_CACHE[key] = entry

            g, st_in, st_out, vals_buf, crit_buf = entry
            vals_buf.copy_(vals_c)
            crit_buf.copy_(crit)
            for dst, src in zip(st_in, state):
                dst.copy_(src)
            g.replay()
            return st_out[7].clone(), st_out[8].clone()
    except Exception:
        # Capture is unsupported on plenty of configurations. Drop the cache so
        # a half-built entry can't be replayed, and take the eager path.
        try:
            with _ESD_GRAPH_LOCK:
                _ESD_GRAPH_CACHE.pop(key, None)
        except Exception:
            pass
        out = state
        for _ in range(max_out):
            out = _esd_peel_step(torch, vals_c, *out, crit, F)
        return out[7], out[8]


def release_esd_graphs():
    """Drop captured ESD graphs and their pinned buffers.

    Each entry holds a stack-sized device buffer, so this is worth calling at
    the end of a group for the same reason release_flat_group_ctx exists.
    """
    with _ESD_GRAPH_LOCK:
        _ESD_GRAPH_CACHE.clear()
    try:
        torch = _TORCH
        if torch is not None and hasattr(torch, "cuda") and torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Public GPU reducer – lazy-loads Torch, never decorates at import time
# ---------------------------------------------------------------------------
def _finalize(torch, out, rej, reduce_rej_maps, *, return_device=False,
              collapse_rej_channels=False):
    """Reduce maps before downloading; optionally leave transfers to a session."""
    out = out.to(dtype=torch.float32).contiguous()
    if reduce_rej_maps or collapse_rej_channels:
        rej = rej.any(dim=-1) if rej.dim() == 4 else rej
    if reduce_rej_maps:
        maps = (rej.any(dim=0), rej.sum(dim=0).to(torch.int32))
    else:
        maps = rej
    if return_device:
        return out, maps
    if isinstance(maps, tuple):
        return out.cpu().numpy(), tuple(m.cpu().numpy() for m in maps)
    return out.cpu().numpy(), maps.cpu().numpy()


DEBUG_INTEGRATION_ONLY = False   # <-- set True: reducer returns a ZEROED rejection map (out left untouched)


def torch_reduce_tile(*args, **kwargs):
    """Public entry point for the tile reducer.

    When DEBUG_INTEGRATION_ONLY is True, the integrated tile is returned exactly
    as computed, but the rejection map is replaced with an all-False array of the
    same shape. This severs every downstream use of the per-tile rejection data
    (accumulation, compositing, MEF layers) so we can tell whether the trail
    contamination rides the rejection array (trails vanish) or is already baked
    into the integrated result itself (trails persist)."""
    out, rej = _torch_reduce_tile_impl(*args, **kwargs)
    if DEBUG_INTEGRATION_ONLY:
        import numpy as _np
        # Leave the GPU self-test (_rejection_gpu_ok) alone: it feeds a tiny
        # 5x1x1x1 probe and asserts the outlier IS rejected. If we zero that
        # map the self-test 'fails' and integration silently drops to CPU.
        # Only neuter the rejection map for real integration tiles (spatial
        # area > 1); the 1x1 probe keeps its true map so GPU stays selected.
        _ts0 = args[0] if args else kwargs.get("ts_np")
        _is_selftest = False
        try:
            _shp = _np.asarray(_ts0).shape
            if len(_shp) >= 3 and int(_shp[1]) * int(_shp[2]) <= 1:
                _is_selftest = True
        except Exception:
            _is_selftest = False
        if not _is_selftest:
            def zero_map(m):
                return m.new_zeros(m.shape) if hasattr(m, "new_zeros") else _np.zeros_like(m)
            if isinstance(rej, tuple):
                _ra, _rc = rej
                rej = (zero_map(_ra), zero_map(_rc))
            elif hasattr(rej, "new_zeros"):
                rej = zero_map(rej)
            else:
                rej = _np.zeros_like(_np.asarray(rej), dtype=bool)
    return out, rej


def _torch_reduce_tile_impl(
    ts_np: np.ndarray,
    weights_np: np.ndarray,
    *,
    algo_name: str,
    kappa: float = 2.5,
    iterations: int = 3,
    sigma_low: float = 2.5,
    sigma_high: float = 2.5,
    trim_fraction: float = 0.1,
    esd_threshold: float = 3.0,
    # False (default): the threshold is the per-frame false-rejection rate, which
    # is what the UI's "sigma" control advertises. True: Rosner's published
    # family-wise correction, which is formally stricter but loses most of its
    # power against marginal outliers on deep stacks. See esd_critical_values.
    esd_bonferroni: bool = False,
    biweight_constant: float = 6.0,
    modz_threshold: float = 3.5,
    comet_hclip_k: float = 1.30,
    comet_hclip_p: float = 25.0,
    ignore_zero_pixels: bool = True,
    forced_reject_mask_np: np.ndarray | None = None,
    reduce_rej_maps: bool = False,
    # ─── Optional GPU calibration pre-steps (master-flat build) ───────────
    # When these are supplied, the reducer runs:
    #   ts = ((ts - dark[y0:y0+H, x0:x0+W]) + pedestal).clamp_min(0) * scales
    # on the DEVICE copy of ts, fusing the three CPU passes the master-flat
    # tile loop used to do into one device-side pass. All five kwargs are
    # ignored unless group_key is also set — that key names a per-group
    # cache, so the dark + scales upload happens exactly once per group.
    # Callers that don't need calibration (master dark build, image
    # integration) pass nothing and get the original behaviour.
    dark_full_np: np.ndarray | None = None,
    pedestal: float = 0.0,
    scales_np: np.ndarray | None = None,
    bayer_pattern: str | None = None,
    tile_origin: tuple = (0, 0),
    group_key=None,
    device_tile=None,
    device_weights=None,
    return_device: bool = False,
    collapse_rej_channels: bool = False,
) -> tuple[np.ndarray, np.ndarray]:

    torch = _get_torch(prefer_cuda=True)
    dev = _device() or (torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu"))

    ts_np = np.asarray(ts_np, dtype=np.float32)
    if ts_np.ndim == 3:
        ts_np = ts_np[..., None]
    F, H, W, C = ts_np.shape

    if H == 0 or W == 0 or C < 1:
        raise ValueError(
            f"torch_reduce_tile received degenerate tile shape={ts_np.shape}. "
            "This usually means a bad edge tile or corrupted frame; "
            "try disabling GPU rejection or reducing chunk size."
        )

    # ── multi-channel: process each plane separately then recombine ──────
    # Avoids the 9x tile/memory overhead of the 4D (F,H,W,3) path — each
    # channel is reduced independently as (F,H,W,1) and stacked at the end.
    #if C > 1:
    #    results  = []
    #    rej_maps = []
    #    for ci in range(C):
    #        r, rj = torch_reduce_tile(
    #            ts_np[:, :, :, ci:ci+1],   # (F, H, W, 1) — zero-copy slice
    #            weights_np,
    #            algo_name=algo_name,
    #            kappa=kappa,
    #            iterations=iterations,
    #            sigma_low=sigma_low,
    #            sigma_high=sigma_high,
    #            trim_fraction=trim_fraction,
    #            esd_threshold=esd_threshold,
    #            biweight_constant=biweight_constant,
    #            modz_threshold=modz_threshold,
    #            comet_hclip_k=comet_hclip_k,
    #            comet_hclip_p=comet_hclip_p,
    #            ignore_zero_pixels=ignore_zero_pixels,
    ##            forced_reject_mask_np=(
    #                forced_reject_mask_np[:, :, :, ci:ci+1]
    #                if forced_reject_mask_np is not None
    #                and forced_reject_mask_np.ndim == 4
    #                else forced_reject_mask_np
    #            ),
    #        )
    #        results.append(r)    # (H, W, 1)
    #        rej_maps.append(rj)  # (F, H, W, 1)

    #    return (
    #        np.concatenate(results,  axis=-1),   # (H, W, C)
    #        np.concatenate(rej_maps, axis=-1),   # (F, H, W, C)
    #    )
    if C < 1:
        raise ValueError(f"torch_reduce_tile received input with C={C} channels (shape={ts_np.shape}). Expected C >= 1.")

    ts = device_tile
    if ts is None:
        ts = torch.from_numpy(ts_np).to(dev, dtype=torch.float32, non_blocking=True)
    elif (tuple(ts.shape) != tuple(ts_np.shape) or ts.device.type != dev.type
          or (dev.index is not None and ts.device.index != dev.index)):
        raise ValueError("Prepared device tile does not match the input tile")

    # ─────────────────────────────────────────────────────────────────────
    # Optional: on-device calibration prep (dark-sub + clip + per-frame
    # scale). Caller passes dark_full_np + scales_np + group_key the FIRST
    # time it hits this group; subsequent tiles can keep passing them (the
    # cache ignores them if ctx is already built) or pass None — the ctx
    # keyed by group_key is what matters. release_flat_group_ctx(group_key)
    # frees the device tensors after the group's final tile.
    # ─────────────────────────────────────────────────────────────────────
    if group_key is not None:
        with _FLAT_GROUP_LOCK:
            ctx = _FLAT_GROUP_CTX.get(group_key)
            if ctx is None and (dark_full_np is not None or scales_np is not None):
                ctx = _build_flat_group_ctx(torch, dev, dark_full_np, scales_np, bayer_pattern)
                _FLAT_GROUP_CTX[group_key] = ctx
        if ctx is not None:
            y0_g = int(tile_origin[0])
            x0_g = int(tile_origin[1])
            with _safe_inference_ctx(torch), _no_amp_ctx(torch, dev):
                dark_t = ctx.get("dark_t")
                if dark_t is not None:
                    # dark_t: (Cd, H_full, W_full); slice the tile view, no copy.
                    d_slice = dark_t[:, y0_g:y0_g + H, x0_g:x0_g + W]
                    if d_slice.shape[0] == 1 and C == 3:
                        d_slice = d_slice.expand(3, H, W)
                    # Reshape to (1, H, W, Cd) so it broadcasts over the F axis of ts.
                    # In-place subtract keeps peak VRAM at 1× the stack size — a
                    # non-in-place `ts = ts - d_bcast` would briefly hold two
                    # copies, which OOMs the small cards the cosmetic pass also
                    # has to share VRAM with.
                    d_bcast = d_slice.permute(1, 2, 0).unsqueeze(0)
                    ts.sub_(d_bcast)
                    if pedestal != 0.0:
                        ts.add_(float(pedestal))
                    ts.clamp_min_(0.0)

                st = ctx.get("scales_t")
                if st is not None:
                    if ctx.get("bayer_pattern"):
                        # Bayer: one scale per CFA plane. Apply as 4 strided
                        # in-place multiplies on the (F,H,W,1) stack — cheaper
                        # than building a per-pixel scale tensor (which would
                        # cost F*H*W*4 bytes of extra VRAM per tile).
                        p2i = ctx["p2i"]
                        ry = y0_g & 1
                        rx = x0_g & 1
                        # st shape: (F, 4)  ← one lane per [R, G1, G2, B]
                        for py in (0, 1):
                            for px in (0, 1):
                                lane = p2i[(py + ry) & 1][(px + rx) & 1]
                                ts[:, py::2, px::2, 0].mul_(st[:, lane].view(F, 1, 1))
                    else:
                        # non-Bayer: scales shape (F,) — per-frame scalar.
                        ts.mul_(st.view(F, 1, 1, 1))

    weights_np = np.asarray(weights_np, dtype=np.float32)
    if weights_np.ndim == 0:
        weights_np = np.full((F,), float(weights_np), dtype=np.float32)

    if weights_np.ndim == 1:
        if weights_np.shape[0] != F:
            raise ValueError(f"weights shape {weights_np.shape} does not match F={F}")
        w_np = weights_np.reshape(F, 1, 1, 1)

    elif weights_np.ndim == 2:
        if weights_np.shape == (F, C):
            w_np = weights_np.reshape(F, 1, 1, C)
        else:
            raise ValueError(
                f"Unsupported 2D weights shape {weights_np.shape}. "
                f"Expected (F,C)=({F},{C}) for per-channel weights."
            )

    elif weights_np.ndim == 3:
        if weights_np.shape == (F, H, W):
            w_np = weights_np[..., None]
        else:
            raise ValueError(
                f"Unsupported 3D weights shape {weights_np.shape}. Expected (F,H,W)=({F},{H},{W})."
            )

    elif weights_np.ndim == 4:
        if weights_np.shape == (F, H, W, 1) or weights_np.shape == (F, H, W, C):
            w_np = weights_np
        else:
            raise ValueError(
                f"Unsupported 4D weights shape {weights_np.shape}. "
                f"Expected (F,H,W,1) or (F,H,W,C)=({F},{H},{W},{C})."
            )
    else:
        raise ValueError(f"Unsupported weights ndim={weights_np.ndim} shape={weights_np.shape}")

    w = device_weights
    if w is None:
        w = torch.from_numpy(w_np).to(dev, dtype=torch.float32, non_blocking=False)
    elif (tuple(w.shape) != tuple(w_np.shape) or w.device.type != dev.type
          or (dev.index is not None and w.device.index != dev.index)):
        raise ValueError("Prepared device weights do not match the frame weights")

    # ---------- NEW: normalize optional forced reject mask ----------
    forced_reject = None
    if forced_reject_mask_np is not None:
        frm = np.asarray(forced_reject_mask_np, dtype=bool)

        if frm.ndim == 2:
            if frm.shape != (H, W):
                raise ValueError(
                    f"forced_reject_mask_np shape {frm.shape} does not match tile (H,W)=({H},{W})"
                )
            frm = frm[None, :, :, None]

        elif frm.ndim == 3:
            if frm.shape != (F, H, W):
                raise ValueError(
                    f"forced_reject_mask_np shape {frm.shape} does not match (F,H,W)=({F},{H},{W})"
                )
            frm = frm[:, :, :, None]

        elif frm.ndim == 4:
            if frm.shape not in ((F, H, W, 1), (F, H, W, C)):
                raise ValueError(
                    f"forced_reject_mask_np shape {frm.shape} does not match "
                    f"(F,H,W,1) or (F,H,W,C)=({F},{H},{W},{C})"
                )
        else:
            raise ValueError(
                f"Unsupported forced_reject_mask_np ndim={frm.ndim} shape={frm.shape}"
            )

        # Upload the mask at its own size: `valid & ~forced_reject` below
        # broadcasts it on the device. Broadcasting on the host first cost
        # F*H*W*C bytes per tile (186 MiB at 3766 frames x 16 x 1080 x 3).
        forced_reject = torch.from_numpy(np.ascontiguousarray(frm)).to(dev, dtype=torch.bool, non_blocking=False)

    algo = algo_name

    # ---------- central validity mask ----------
    valid = torch.isfinite(ts)
    if ignore_zero_pixels:
        valid = valid & (ts != 0.0)
    if forced_reject is not None:
        valid = valid & (~forced_reject)

    # Base forced rejection bookkeeping
    forced_rej_map = (~valid)

    with _safe_inference_ctx(torch), _no_amp_ctx(torch, dev):
        if algo in ("Comet Median", "Simple Median (No Rejection)"):
            x = ts.masked_fill(~valid, float("nan"))
            out = _nanmedian(torch, x, dim=0)
            rej = forced_rej_map
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        if algo == "Comet Percentile (40th)":
            x = ts.masked_fill(~valid, float("nan"))
            out = _nanquantile(torch, x, 0.40, dim=0)
            rej = forced_rej_map
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        if algo_name == "Winsorized Sigma Clipping":
            # True Winsorized sigma clipping (APP/PI-parity):
            # robust winsorized center/scale, one rejection pass, then average
            # of the SURVIVORS only (rejected pixels are excluded, not
            # median-substituted, so a partly-rejected trail can't leak back).
            med, sigma = _winsorized_center_scale(torch, ts, valid, iterations=int(iterations))
            lo = (med - float(sigma_low) * sigma).unsqueeze(0)
            hi = (med + float(sigma_high) * sigma).unsqueeze(0)
            keep = valid & (ts >= lo) & (ts <= hi)

            ones_w = torch.ones((F, 1, 1, 1), device=dev, dtype=ts.dtype)
            fallback = _nan_to_num(torch, med, nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, ones_w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)


        if algo == "Comet Lower-Trim (30%)":
            # One-sided order-statistic trim: keep the lowest floor(0.7*n).
            # Note this floors the count KEPT, so the trim rounds UP (n=5 drops
            # 2, i.e. 40%) -- unlike "Trimmed Mean", which floors the count
            # trimmed. That is deliberate for this preset: the point is to
            # suppress stars and background riding over the comet, and erring
            # toward trimming more is the safer side for that. Left as-is so
            # existing comet stacks stay reproducible.
            x = ts.masked_fill(~valid, float("inf"))
            vals, idx = x.sort(dim=0, stable=True)

            n = valid.sum(dim=0)
            k_keep = torch.floor(n.to(torch.float32) * (1.0 - 0.30)).to(torch.long)
            k_keep = k_keep.clamp(min=1)

            arangeF = torch.arange(F, device=dev).view(F, 1, 1, 1).expand_as(vals)
            keep_sorted = arangeF < k_keep.unsqueeze(0).expand_as(vals)
            keep_sorted = keep_sorted & torch.isfinite(vals)

            den = keep_sorted.sum(dim=0)
            num = torch.where(keep_sorted, vals, _scalar_like(torch, vals, 0.0)).sum(dim=0)

            fallback = _nanmedian(torch, ts.masked_fill(~valid, float("nan")), dim=0)
            out = torch.where(den > 0, num / den.clamp_min(1).to(vals.dtype), fallback)

            keep_orig = torch.zeros_like(keep_sorted)
            keep_orig.scatter_(0, idx, keep_sorted)
            rej = ~keep_orig
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        if algo == "Comet High-Clip Percentile":
            x = ts.masked_fill(~valid, float("nan"))
            med = _nanmedian(torch, x, dim=0)
            mad = _nanmedian(torch, (x - med.unsqueeze(0)).abs(), dim=0) + 1e-6
            hi = med + (float(comet_hclip_k) * 1.4826 * mad)
            clipped = torch.where(valid, torch.minimum(ts, hi.unsqueeze(0)),
                                  _scalar_like(torch, ts, float("nan")))
            out = _nanquantile(torch, clipped, float(comet_hclip_p) / 100.0, dim=0)
            rej = forced_rej_map
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        if algo == "Simple Average (No Rejection)":
            w_eff = torch.where(valid, w, _scalar_like(torch, w, 0.0))
            ts_eff = torch.where(valid, ts, _scalar_like(torch, ts, 0.0))
            den = w_eff.sum(dim=0)
            num = (ts_eff * w_eff).sum(dim=0)

            # With strictly positive finite weights, zero denominator means
            # no valid samples; their nanmedian would be NaN anyway.
            if np.all(np.isfinite(weights_np) & (weights_np > 0)):
                fallback = torch.full_like(den, float("nan"))
            else:
                x = ts.masked_fill(~valid, float("nan"))
                fallback = _nanmedian(torch, x, dim=0)
            out = torch.where(den > 0, num / den.clamp_min(1e-20), fallback)

            rej = forced_rej_map
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        if algo == "Max Value":
            x = ts.masked_fill(~valid, float("-inf"))
            out = x.max(dim=0).values
            out = torch.where(torch.isfinite(out), out, torch.zeros_like(out))
            rej = forced_rej_map
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)


        if algo == "Weighted Winsorized Sigma Clipping":
            # True Winsorized sigma clipping (APP/PI-parity), weighted average.
            # See _winsorized_center_scale for why sigma must be measured on
            # the winsorized stack: the old code measured std on raw data, so
            # a satellite trail inflated sigma and was never rejected.
            #
            # "Weighted" applies to the AVERAGE only -- the per-frame weights
            # deliberately do not enter the center/scale estimate. The weights
            # encode frame quality (SNR, FWHM, transparency), not the likelihood
            # that a given pixel is an outlier, and letting them tilt the
            # median/sigma would make the rejection threshold depend on which
            # frames happened to score well. APP and PixInsight both do it this
            # way: robust statistics to decide what to reject, weights to decide
            # how much each survivor contributes.
            med, sigma = _winsorized_center_scale(torch, ts, valid, iterations=int(iterations))
            lo = (med - float(sigma_low) * sigma).unsqueeze(0)
            hi = (med + float(sigma_high) * sigma).unsqueeze(0)
            keep = valid & (ts >= lo) & (ts <= hi)

            fallback = _nan_to_num(torch, med, nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        if algo == "Extreme Studentized Deviate (ESD)":
            # Generalized ESD (Rosner) done properly, vectorized per pixel.
            #
            # The old implementation was an iterative z-clip whose std was
            # measured on data still containing the outliers ("masking"):
            # one strong outlier among N frames is bounded at z = sqrt(N),
            # so with few frames it could never exceed the threshold.
            #
            # Rosner's procedure defeats masking by construction:
            #   for j = 1..max_out:
            #     find the single most extreme remaining value,
            #     test it against the mean/std of the remaining sample
            #     WITH THAT VALUE EXCLUDED (external studentization),
            #     record pass/fail, remove it, continue (no early stop).
            #   The number of outliers is the LARGEST j whose test passed;
            #   the outliers are exactly the first j values removed.
            #
            # External studentization matters: the internally studentized
            # deviate is capped at (n-1)/sqrt(n) (~2.47 for n=8), so a fixed
            # user threshold of 3.0 was unreachable on small stacks. Testing
            # against the leave-one-out sample removes the cap and makes the
            # threshold mean "sigmas above the clean data", which is what
            # users expect the setting to do.
            thr = float(esd_threshold)
            # Rosner needs an upper bound on the outlier count: test up to half
            # the stack, leaving at least 2 frames so the leave-one-out scale
            # exists. Runtime is strictly linear in this bound and every step is
            # a full reduction over the tile, so lowering it is the single
            # biggest ESD speedup available -- but it was measured to bind on
            # heavily contaminated pixels (a 0.3*F cap saturates at F=8 and
            # F=16, i.e. it starts refusing to reject outliers it can see), so
            # it stays at 0.5 rather than trading rejections for throughput.
            max_out = int(max(1, min(F - 2, round(0.5 * F))))

            # Per-step critical values. A FIXED cutoff cascades on clean
            # stacks: each removal shrinks the remaining std, inflating the
            # next R, so later steps pass spuriously. Rosner's remedy is an
            # n-dependent critical value, and because the statistic below is
            # externally studentized it is exactly a t quantile at df = n - 2
            # with the multiplicity correction folded into the tail
            # probability. Shared with the numpy reducer in stacking_suite so
            # the two paths cannot drift (see _rejection_gpu_ok).
            crit_by_n = esd_critical_values(F, thr, bonferroni=bool(esd_bonferroni))
            crit_t = torch.from_numpy(crit_by_n).to(dev)

            # ── sorted peel (see _esd_peel_step for why this is equivalent) ──
            # Deep stacks only: below _ESD_PEEL_MIN_FRAMES the sort costs more
            # than the 2-3 steps it would save, so the original loop below is
            # still the faster branch there.
            if F >= _ESD_PEEL_MIN_FRAMES:
                # Sort the RAW values. Centring before the sort perturbs ties
                # and was measured to change the mask on shallow stacks.
                vals = torch.sort(ts.masked_fill(~valid, float("inf")), dim=0).values
                n0 = valid.sum(dim=0)
                c = (torch.where(valid, ts, torch.zeros((), device=dev, dtype=ts.dtype))
                     .sum(dim=0) / n0.clamp_min(1).to(ts.dtype))
                vals_c = vals - c.unsqueeze(0)
                vz = torch.where(torch.isfinite(vals_c), vals_c,
                                 torch.zeros((), device=dev, dtype=vals_c.dtype)).double()
                S0 = vz.sum(dim=0)
                Q0 = (vz * vz).sum(dim=0)
                del vz

                state = (torch.zeros_like(n0), (n0 - 1).clamp_min(0), n0.clone(),
                         S0, Q0, torch.zeros_like(n0), torch.zeros_like(n0),
                         torch.zeros_like(n0), torch.zeros_like(n0))
                use_graph = (dev.type == "cuda" and F >= _ESD_GRAPH_MIN_FRAMES
                             and not _is_directml_privateuse(dev)
                             and _esd_graph_affordable(
                                 torch, dev, ts.numel() * ts.element_size()))
                keep_lo, keep_hi = _esd_run_peel(
                    torch, dev, vals_c, state, crit_t.double(), F,
                    int(max(1, min(F - 2, round(0.5 * F)))), use_graph)

                # Rejected == the lowest keep_lo and highest keep_hi order
                # statistics, so two threshold values rebuild the mask.
                v_low = vals.gather(0, keep_lo.clamp(0, F - 1).unsqueeze(0)).squeeze(0)
                v_high = vals.gather(
                    0, (n0 - 1 - keep_hi).clamp(0, F - 1).unsqueeze(0)).squeeze(0)
                keep = valid & (ts >= v_low.unsqueeze(0)) & (ts <= v_high.unsqueeze(0))
                del vals, vals_c

                x = ts.masked_fill(~valid, float("nan"))
                fallback = _nan_to_num(torch, _nanmedian(torch, x, dim=0), nan=0.0)
                out = _weighted_mean_or(torch, ts, keep, w, fallback)
                return _finalize(torch, out, ~keep, reduce_rej_maps,
                                 return_device=return_device,
                                 collapse_rej_channels=collapse_rej_channels)

            active = valid.clone()
            # int16: step indices run to max_out-1 <= F/2, so overflow needs a
            # 65k-frame stack. This array is F*H*W*C, so halving it is real VRAM
            # on a deep stack -- the one free win in this branch.
            removed_step = torch.full((F, H, W, C), -1, dtype=torch.int16, device=dev)
            passed = torch.zeros((max_out, H, W, C), dtype=torch.bool, device=dev)
            neg = torch.full_like(ts, float("-inf"))

            for j in range(max_out):
                n = active.sum(dim=0).to(ts.dtype)
                can = n >= 3.0  # need >= 2 samples left after leave-one-out
                mean = _masked_sum(torch, ts, active, dim=0) / n.clamp_min(1.0)
                dv = ts - mean.unsqueeze(0)
                ss_all = _masked_sum(torch, dv * dv, active, dim=0)

                # candidate = most extreme remaining value
                zabs = torch.where(active, dv.abs(), neg)
                dmax, idx = zabs.max(dim=0)
                # all-inactive pixels come back -inf; zero them so no inf/NaN
                # enters the arithmetic below (`can` already gates the test, but
                # this keeps the numpy mirror statement-for-statement identical)
                dmax = torch.where(torch.isfinite(dmax), dmax, torch.zeros_like(dmax))

                # Leave-one-out mean/std via exact identities (no cancellation):
                #   ss_loo = ss_all - dev_c^2 * n/(n-1)
                # The candidate's deviation from the LOO mean is dev_c*n/(n-1),
                # and its standard error is s_loo*sqrt(1 + 1/(n-1)), so the
                # externally studentized deviate is
                #   t = dev_c * sqrt(n/(n-1)) / s_loo   ~  t_{n-2}
                # The sqrt is what makes this an exact t: the old code used the
                # raw n/(n-1) ratio, i.e. t inflated by sqrt(n/(n-1)), so every
                # test ran slightly hot (≈ +22% on 3 frames, +0.2% on 245).
                n_loo = (n - 1.0).clamp_min(1.0)
                ss_loo = (ss_all - dmax * dmax * (n / n_loo)).clamp_min(0.0)
                var_loo = ss_loo / (n_loo - 1.0).clamp_min(1.0)
                std_loo = var_loo.sqrt().clamp_min(1e-12)
                R = dmax * (n / n_loo).sqrt() / std_loo

                # crit_by_n is indexed by the PRE-removal active count, which is
                # exactly `n` here (active is updated below, after this read).
                lam = crit_t[n.to(torch.long).clamp(0, F)]
                passed[j] = can & (R > lam)

                # remove the single most extreme remaining value (where possible)
                hit = torch.zeros_like(active)
                hit.scatter_(0, idx.unsqueeze(0), can.unsqueeze(0))
                active = active & ~hit
                removed_step = torch.where(hit, torch.full_like(removed_step, j), removed_step)

            # per pixel: largest step index whose test passed (else -1)
            steps = torch.arange(max_out, device=dev, dtype=torch.int16).view(max_out, 1, 1, 1)
            jstar = torch.where(
                passed,
                steps.expand(max_out, H, W, C),
                torch.full((max_out, H, W, C), -1, dtype=torch.int16, device=dev),
            ).max(dim=0).values

            # reject exactly the removals up to and including step jstar
            keep = valid & ((removed_step < 0) | (removed_step > jstar.unsqueeze(0)))

            x = ts.masked_fill(~valid, float("nan"))
            fallback = _nan_to_num(torch, _nanmedian(torch, x, dim=0), nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        if algo == "Kappa-Sigma Clipping":
            # Classic kappa-sigma: median center, std of the KEPT sample,
            # monotone shrink (a rejected pixel stays rejected — the old
            # `keep = valid & bounds` let outliers re-enter after the bounds
            # re-widened). Average of survivors only; no median blending.
            # NOTE ON CONVENTION: `var` below is measured about the MEDIAN, not
            # about the mean of the kept sample. That is deliberate and matches
            # PixInsight's sigma-clipping: it keeps the center and the scale
            # anchored to the same robust statistic, so one surviving outlier
            # cannot drag the center and shrink the apparent spread at the same
            # time. It does mean this is not the textbook sample variance, and
            # the number it reports will run slightly high on skewed pixels.
            # Changed here would change every existing kappa-sigma stack, so it
            # stays.
            n_it = max(1, int(iterations))
            check_conv = n_it >= _CONVERGENCE_MIN_ITERS
            keep = valid.clone()
            for it in range(n_it):
                x_iter = ts.masked_fill(~keep, float("nan"))
                med = _nanmedian(torch, x_iter, dim=0)
                n_kept = keep.sum(dim=0).clamp_min(1).to(ts.dtype)
                var = _masked_sum(torch, (ts - med.unsqueeze(0)) ** 2, keep, dim=0) / n_kept
                std = var.clamp_min(0.0).sqrt().clamp_min(1e-12)
                lo = (med - float(kappa) * std).unsqueeze(0)
                hi = (med + float(kappa) * std).unsqueeze(0)
                keep_new = keep & (ts >= lo) & (ts <= hi)

                # Fixed-point exit. If this pass rejected nothing, the kept set
                # is unchanged, so med/std and therefore the bounds are
                # unchanged, and every later pass would also reject nothing --
                # the exit is exact, not an approximation. Gated on the
                # iteration count for the same reason as the winsorized loop
                # (the .any() needs a device sync that stalls the tile
                # pipeline), and mirrored in the numpy reducer.
                if check_conv and it + 1 < n_it:
                    changed = (keep_new != keep).any()
                    keep = keep_new
                    try:
                        if not bool(changed):
                            break
                    except Exception:
                        pass
                else:
                    keep = keep_new

            x_valid = ts.masked_fill(~valid, float("nan"))
            fallback = _nan_to_num(torch, _nanmedian(torch, x_valid, dim=0), nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        if algo == "Trimmed Mean":
            # True symmetric order-statistic trim: drop exactly floor(f*n) from
            # each end of the sorted sample, which is the textbook (and
            # scipy.stats.trim_mean) definition.
            #
            # The old implementation thresholded on interpolated quantiles
            # instead -- keep = (ts >= q_f) & (ts <= q_{1-f}) -- which is not the
            # same estimator:
            #   * on small stacks it over-trims. n=5, f=0.1: a true trim drops
            #     floor(0.5)=0 frames, but q_0.1 interpolates strictly above the
            #     minimum, so the min AND the max were discarded -- a 40% trim
            #     dressed up as 10%.
            #   * with ties at the cut it under-trims, because every tied value
            #     satisfies the inequality and all of them survive.
            #   * the count kept drifted with the pixel's value distribution
            #     rather than being fixed by n, so the effective trim varied
            #     across the frame.
            x_sort = ts.masked_fill(~valid, float("inf"))
            vals, idx = x_sort.sort(dim=0, stable=True)

            n = valid.sum(dim=0)                                  # (H,W,C) long
            f = min(max(float(trim_fraction), 0.0), 0.5)
            k = torch.floor(n.to(torch.float32) * f).to(torch.long)
            if f > 0.0:
                # Minimum one per tail. This is the ONE deliberate departure
                # from scipy.stats.trim_mean's exact floor: at f=0.1 a strict
                # floor trims nothing at all for any stack under 10 frames, so
                # a user who explicitly picked a trimming rejection method would
                # silently get a plain weighted average. Trimming nothing is
                # never the intent of choosing this method. For n >= 1/f the
                # guard never fires and the result is the exact trimmed mean.
                k = k.clamp_min(1)
            # never trim away the whole sample: leave at least one survivor
            k = torch.minimum(k, ((n - 1) // 2).clamp_min(0)).clamp_min(0)

            rank = torch.arange(F, device=dev, dtype=torch.long).view(F, 1, 1, 1)
            lo_r = k.unsqueeze(0)
            hi_r = (n - k).unsqueeze(0)                           # exclusive
            keep_sorted = (rank >= lo_r) & (rank < hi_r) & torch.isfinite(vals)

            # back to original frame order so weights and the rejection map line up
            keep = torch.zeros_like(keep_sorted)
            keep.scatter_(0, idx, keep_sorted)
            keep = keep & valid

            fallback = _nan_to_num(torch,
                _nanmedian(torch, ts.masked_fill(~valid, float("nan")), dim=0), nan=0.0
            )
            out = _weighted_mean_or(torch, ts, keep, w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        if algo == "Biweight Estimator":
            x = ts.masked_fill(~valid, float("nan"))
            m = _nanmedian(torch, x, dim=0)
            mad = (_nanmedian(torch, (x - m.unsqueeze(0)).abs(), dim=0)).clamp_min(1e-12)

            # NaN-safe residuals: invalid lanes contribute exactly 0
            d = torch.where(valid, ts - m.unsqueeze(0), _scalar_like(torch, ts, 0.0))
            u = d / (float(biweight_constant) * mad.unsqueeze(0))
            mask = valid & (u.abs() < 1.0)

            omu2 = torch.where(mask, 1.0 - u * u, _scalar_like(torch, u, 0.0))
            k_w = omu2 * omu2 * w  # broadcasts weights over the stack
            num = (d * k_w).sum(dim=0)
            den = k_w.sum(dim=0)

            out = torch.where(den > 1e-20, m + num / den.clamp_min(1e-20), m)
            out = _nan_to_num(torch, out, nan=0.0)

            rej = ~mask
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        if algo == "Modified Z-Score Clipping":
            x = ts.masked_fill(~valid, float("nan"))
            med = _nanmedian(torch, x, dim=0)
            mad = (_nanmedian(torch, (x - med.unsqueeze(0)).abs(), dim=0)).clamp_min(1e-12)

            mz = torch.where(
                valid,
                0.6745 * (ts - med.unsqueeze(0)) / mad.unsqueeze(0),
                _scalar_like(torch, ts, float("inf")),
            )
            keep = valid & (mz.abs() < float(modz_threshold))

            fallback = _nan_to_num(torch, med, nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps,
                             return_device=return_device,
                             collapse_rej_channels=collapse_rej_channels)

        raise NotImplementedError(f"GPU path not implemented for: {algo_name}")