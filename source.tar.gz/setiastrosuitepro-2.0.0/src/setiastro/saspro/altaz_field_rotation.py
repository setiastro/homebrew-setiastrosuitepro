# ============================================================
#  SASpro — Alt/Az Field Rotation Calculator
#  Copyright (c) 2025 Franklin Marek / Seti Astro
#  www.setiastro.com
#
#    ___      _   _   _       _
#   / __| ___| |_(_) /_\  ___| |_ _ _ ___
#   \__ \/ -_)  _| |/ _ \(_-<|  _| '_/ _ \
#   |___/\___|\__|_/_/ \_/__/ \__|_| \___/
#
#  Alt/Az Field Rotation Calculator — standalone dialog
#  for use inside the What's In My Sky (WIMS) module.
#
#  Drop-in usage:
#    from setiastro.saspro.altaz_field_rotation import AltAzFieldRotationDialog
#    dlg = AltAzFieldRotationDialog(lat, lon, alt_deg, az_deg,
#                                   ra_deg, dec_deg,
#                                   date_str, tz_name,
#                                   settings, parent=self)
#    dlg.show()
# ============================================================

from __future__ import annotations

import math
import numpy as np

from PyQt6.QtCore import Qt, QSettings, QCoreApplication
from PyQt6.QtWidgets import (
    QDialog, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QGridLayout,
    QGroupBox, QFrame, QWidget, QTabWidget,
)
from PyQt6.QtGui import QFont

try:
    import pyqtgraph as pg
    _HAS_PG = True
except ImportError:
    _HAS_PG = False


def _tr(text: str) -> str:
    return QCoreApplication.translate("AltazFieldRotation", text)


# ── Math core ────────────────────────────────────────────────────────────────

def field_rotation_rate_arcsec_per_sec(lat_deg: float, az_deg: float,
                                        alt_deg: float) -> float:
    """
    Field rotation rate in arcsec/sec for an Alt/Az mount.
    Formula: R = 15.04 * cos(lat) * cos(az) / cos(alt)
    Returns the signed rate. Returns inf near zenith (alt >= 89.99).
    """
    cos_alt = math.cos(math.radians(alt_deg))
    if abs(cos_alt) < 1e-9:
        return float("inf")
    return (15.04
            * math.cos(math.radians(lat_deg))
            * math.cos(math.radians(az_deg))
            / cos_alt)


def max_exposure_seconds(lat_deg: float, az_deg: float, alt_deg: float,
                          sensor_w_mm: float, sensor_h_mm: float,
                          pixel_pitch_um: float,
                          max_corner_pixels: float = 1.0) -> dict:
    """
    Maximum exposure before corner pixel motion exceeds max_corner_pixels.
    Returns dict with all intermediate values for display.
    """
    half_diag_mm = math.sqrt((sensor_w_mm / 2) ** 2 + (sensor_h_mm / 2) ** 2)
    half_diag_um = half_diag_mm * 1000.0

    rate_asec_sec = field_rotation_rate_arcsec_per_sec(lat_deg, az_deg, alt_deg)
    rate_mag      = abs(rate_asec_sec)
    rate_deg_sec  = rate_mag / 3600.0

    # t = max_pixels / ( (2pi/360) * (d/s) * rate_deg_sec )
    two_pi_over_360 = 2.0 * math.pi / 360.0
    d_over_s        = half_diag_um / pixel_pitch_um

    if rate_deg_sec < 1e-12:
        t_max = float("inf")
    else:
        t_max = max_corner_pixels / (two_pi_over_360 * d_over_s * rate_deg_sec)

    return {
        "rate_arcsec_per_sec": rate_asec_sec,
        "rate_arcsec_per_min": rate_asec_sec * 60.0,
        "rate_mag_asec_sec":   rate_mag,
        "half_diag_mm":        half_diag_mm,
        "half_diag_um":        half_diag_um,
        "pixel_pitch_um":      pixel_pitch_um,
        "d_over_s":            d_over_s,
        "max_corner_pixels":   max_corner_pixels,
        "t_max_sec":           t_max,
    }


def severity_badge(t_sec: float) -> str:
    if t_sec == float("inf"):
        return _tr("⭐ No limit (E/W)")
    if t_sec >= 60:
        return _tr("⭐ Excellent  (≥ 60 s)")
    if t_sec >= 20:
        return _tr("🟢 Good  (20–60 s)")
    if t_sec >= 10:
        return _tr("🟡 Marginal  (10–20 s)")
    if t_sec >= 5:
        return _tr("🔴 Poor  (5–10 s)")
    return _tr("❌ Very limited  (< 5 s)")


# ── Dialog ────────────────────────────────────────────────────────────────────

class AltAzFieldRotationDialog(QDialog):
    """
    Alt/Az Field Rotation Calculator.

    Parameters
    ----------
    lat         : float        Observer latitude  (degrees, north positive)
    lon         : float        Observer longitude (degrees, east positive)
    alt         : float|None   Target altitude at current time — pre-fill only
    az          : float|None   Target azimuth  at current time — pre-fill only
    ra_deg      : float|None   Target RA  (degrees) — drives the night curve
    dec_deg     : float|None   Target Dec (degrees) — drives the night curve
    date_str    : str|None     Observation date "YYYY-MM-DD" — drives the night curve
    tz_name     : str|None     Timezone name e.g. "US/Central"
    target_name : str|None     Display name shown in header and plot title
    settings    : QSettings
    parent      : QWidget
    """

    _SETTINGS_PREFIX = "wims/field_rotation/"

    def __init__(self, lat: float, lon: float,
                 alt:         float | None = None,
                 az:          float | None = None,
                 ra_deg:      float | None = None,
                 dec_deg:     float | None = None,
                 date_str:    str   | None = None,
                 tz_name:     str   | None = None,
                 target_name: str   | None = None,
                 settings:    QSettings | None = None,
                 parent=None):
        super().__init__(parent)
        name_part = f" — {target_name}" if target_name else ""
        self.setWindowTitle(self.tr("Alt/Az Field Rotation Calculator{0}").format(name_part))
        self.resize(720, 600)

        self._lat         = lat
        self._lon         = lon
        self._ra_deg      = ra_deg
        self._dec_deg     = dec_deg
        self._date_str    = date_str
        self._tz_name     = tz_name
        self._target_name = target_name or ""
        self._settings    = settings or QSettings()

        self._build_ui()
        self._load_persisted()

        if alt is not None:
            self._alt_edit.setText(f"{alt:.1f}")
        if az is not None:
            self._az_edit.setText(f"{az:.1f}")

        if alt is not None and az is not None:
            self._calculate()

    # ── UI ────────────────────────────────────────────────────────────────

    def _build_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 10)
        outer.setSpacing(8)

        name_part = f"  —  <b>{self._target_name}</b>" if self._target_name else ""
        hdr = QLabel(
            self.tr("<b>Alt/Az Field Rotation Calculator</b>{0}"
                    "<br><small>Observer latitude: <b>{1:+.4f}°</b>  "
                    "longitude: <b>{2:+.4f}°</b></small>").format(name_part, self._lat, self._lon)
        )
        hdr.setWordWrap(True)
        outer.addWidget(hdr)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)
        outer.addWidget(sep)

        input_box = QGroupBox(self.tr("Target && Equipment"))
        grid = QGridLayout(input_box)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(3, 1)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(6)

        def _le(placeholder="", width=90):
            e = QLineEdit()
            e.setPlaceholderText(placeholder)
            e.setFixedWidth(width)
            e.returnPressed.connect(self._calculate)
            return e

        grid.addWidget(QLabel(self.tr("Altitude (°):")),  0, 0, Qt.AlignmentFlag.AlignRight)
        self._alt_edit = _le(self.tr("e.g. 45.0"))
        grid.addWidget(self._alt_edit, 0, 1)

        grid.addWidget(QLabel(self.tr("Azimuth (°):")),   0, 2, Qt.AlignmentFlag.AlignRight)
        self._az_edit = _le("0–360")
        grid.addWidget(self._az_edit, 0, 3)

        az_hint = QLabel(self.tr("<small>0=N  90=E  180=S  270=W</small>"))
        az_hint.setStyleSheet("color: palette(placeholderText);")
        grid.addWidget(az_hint, 0, 4)

        grid.addWidget(QLabel(self.tr("Focal length (mm):")), 1, 0, Qt.AlignmentFlag.AlignRight)
        self._fl_edit = _le(self.tr("e.g. 600"))
        grid.addWidget(self._fl_edit, 1, 1)

        grid.addWidget(QLabel(self.tr("Pixel pitch (µm):")),  1, 2, Qt.AlignmentFlag.AlignRight)
        self._px_edit = _le(self.tr("e.g. 3.76"))
        grid.addWidget(self._px_edit, 1, 3)

        grid.addWidget(QLabel(self.tr("Sensor width (mm):")),  2, 0, Qt.AlignmentFlag.AlignRight)
        self._sw_edit = _le(self.tr("e.g. 23.5"))
        grid.addWidget(self._sw_edit, 2, 1)

        grid.addWidget(QLabel(self.tr("Sensor height (mm):")), 2, 2, Qt.AlignmentFlag.AlignRight)
        self._sh_edit = _le(self.tr("e.g. 15.6"))
        grid.addWidget(self._sh_edit, 2, 3)

        grid.addWidget(QLabel(self.tr("Max corner pixels:")),  3, 0, Qt.AlignmentFlag.AlignRight)
        self._tol_edit = _le(self.tr("default: 1"))
        self._tol_edit.setText("1")
        grid.addWidget(self._tol_edit, 3, 1)

        tol_hint = QLabel(
            self.tr("<small>Corner pixel movement before trailing is objectionable. "
                    "1 = tightest, 5–10 = relaxed.</small>"))
        tol_hint.setWordWrap(True)
        tol_hint.setStyleSheet("color: palette(placeholderText);")
        grid.addWidget(tol_hint, 3, 2, 1, 3)

        outer.addWidget(input_box)

        btn_row = QHBoxLayout()
        calc_btn = QPushButton(self.tr("Calculate"))
        calc_btn.setFixedHeight(32)
        calc_btn.setDefault(True)
        calc_btn.clicked.connect(self._calculate)
        btn_row.addStretch()
        btn_row.addWidget(calc_btn)
        btn_row.addStretch()
        outer.addLayout(btn_row)

        self._tabs = QTabWidget()
        outer.addWidget(self._tabs, 1)

        # ── Tab 1: Results ────────────────────────────────────────────────
        summary_tab = QWidget()
        st_lay = QVBoxLayout(summary_tab)
        st_lay.setContentsMargins(8, 8, 8, 8)
        st_lay.setSpacing(6)

        self._result_badge = QLabel("")
        font = QFont()
        font.setPointSize(14)
        font.setBold(True)
        self._result_badge.setFont(font)
        self._result_badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        st_lay.addWidget(self._result_badge)

        self._result_grid = QGridLayout()
        self._result_grid.setHorizontalSpacing(16)
        self._result_grid.setVerticalSpacing(4)
        st_lay.addLayout(self._result_grid)
        st_lay.addStretch(1)

        note = QLabel(self.tr(
            "<small><b>How it works:</b> Stars rotate around the sensor center on an Alt/Az "
            "mount. The corner sweeps the largest arc. "
            "Rate = 15.04 × cos(lat) × cos(az) / cos(alt)  arcsec/sec. "
            "Max exposure = (tolerance × pixel pitch) / (2π/360 × corner half-diagonal × rate). "
            "Field rotation is zero due East/West and maximum due North/South.</small>"
        ))
        note.setWordWrap(True)
        note.setStyleSheet(
            "color: palette(placeholderText); font-size: 10px; padding-top: 6px;")
        st_lay.addWidget(note)

        self._tabs.addTab(summary_tab, self.tr("Results"))

        # ── Tab 2: Exposure Over Night ────────────────────────────────────
        if _HAS_PG:
            plot_tab = QWidget()
            pt_lay = QVBoxLayout(plot_tab)
            pt_lay.setContentsMargins(4, 4, 4, 4)

            self._night_plot = pg.PlotWidget()
            self._night_plot.setBackground(pg.mkColor(40, 55, 120, 255))
            self._night_plot.showGrid(x=True, y=True, alpha=0.3)
            self._night_plot.setXRange(12, 36, padding=0)
            ticks = [(h, str(h if h <= 23 else h - 24)) for h in range(12, 37, 2)]
            self._night_plot.getAxis("bottom").setTicks([ticks])
            self._night_plot.setLabel("bottom", self.tr("Local Time (h)"))
            self._night_plot.setLabel("left",   self.tr("Max Exposure (s)"))
            pt_lay.addWidget(self._night_plot, 1)

            self._night_plot_hint = QLabel(
                self.tr("Run Calculate to generate the exposure curve over the night."))
            self._night_plot_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self._night_plot_hint.setWordWrap(True)
            self._night_plot_hint.setStyleSheet(
                "color: palette(placeholderText); font-size: 11px; padding: 4px;")
            pt_lay.addWidget(self._night_plot_hint, 0)

            self._tabs.addTab(plot_tab, self.tr("Exposure Over Night"))
        else:
            self._night_plot = None

        close_row = QHBoxLayout()
        close_row.addStretch()
        close_btn = QPushButton(self.tr("Close"))
        close_btn.clicked.connect(self.close)
        close_row.addWidget(close_btn)
        outer.addLayout(close_row)

    # ── Persistence ───────────────────────────────────────────────────────

    def _load_persisted(self):
        s, p = self._settings, self._SETTINGS_PREFIX
        for edit, key, default in [
            (self._fl_edit,  "focal_length", ""),
            (self._px_edit,  "pixel_pitch",  ""),
            (self._sw_edit,  "sensor_w",     ""),
            (self._sh_edit,  "sensor_h",     ""),
            (self._tol_edit, "tolerance",    "1"),
        ]:
            val = s.value(p + key, default, str)
            if val:
                edit.setText(val)

    def _save_persisted(self):
        s, p = self._settings, self._SETTINGS_PREFIX
        for edit, key in [
            (self._fl_edit,  "focal_length"),
            (self._px_edit,  "pixel_pitch"),
            (self._sw_edit,  "sensor_w"),
            (self._sh_edit,  "sensor_h"),
            (self._tol_edit, "tolerance"),
        ]:
            s.setValue(p + key, edit.text().strip())

    # ── Calculate ─────────────────────────────────────────────────────────

    def _parse_float(self, edit: QLineEdit, name: str) -> float:
        txt = edit.text().strip()
        if not txt:
            raise ValueError(f"{name} is empty")
        try:
            return float(txt)
        except ValueError:
            raise ValueError(f"'{txt}' is not a valid number for {name}")

    def _calculate(self):
        while self._result_grid.count():
            item = self._result_grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        try:
            alt = self._parse_float(self._alt_edit, "Altitude")
            az  = self._parse_float(self._az_edit,  "Azimuth")
            fl  = self._parse_float(self._fl_edit,  "Focal length")   # noqa: F841
            px  = self._parse_float(self._px_edit,  "Pixel pitch")
            sw  = self._parse_float(self._sw_edit,  "Sensor width")
            sh  = self._parse_float(self._sh_edit,  "Sensor height")
            tol = self._parse_float(self._tol_edit, "Max corner pixels")

            if not (0.0 <= alt < 90.0):
                raise ValueError("Altitude must be 0°–89.9° (zenith singularity at 90°)")
            if not (0.0 <= az <= 360.0):
                raise ValueError("Azimuth must be 0°–360°")
            if px <= 0 or sw <= 0 or sh <= 0 or fl <= 0:
                raise ValueError("Focal length, sensor dimensions and pixel pitch must be > 0")
            if tol <= 0:
                raise ValueError("Tolerance must be > 0")

        except ValueError as e:
            self._result_badge.setText(f"⚠  {e}")
            self._result_badge.setStyleSheet("color: orange;")
            return

        self._save_persisted()

        def _row(label, value, row, bold=False):
            lbl = QLabel(label)
            lbl.setStyleSheet("font-size: 11px; color: palette(placeholderText);")
            val = QLabel(str(value))
            weight = "700" if bold else "500"
            val.setStyleSheet(f"font-size: 12px; font-weight: {weight};")
            self._result_grid.addWidget(lbl, row, 0, Qt.AlignmentFlag.AlignRight)
            self._result_grid.addWidget(val, row, 1)

        def _t_str(t):
            return "∞" if t == float("inf") else f"{t:.1f} s"

        # ── Equipment summary (always shown) ──────────────────────────────
        res_now = max_exposure_seconds(self._lat, az, alt, sw, sh, px,
                                        max_corner_pixels=tol)
        _row(self.tr("Corner half-diagonal:"),
             f"{res_now['half_diag_mm']:.2f} mm  "
             f"({res_now['half_diag_um']:.0f} µm)", 0)
        _row(self.tr("Diagonal / pixel ratio:"),
             self.tr("{0:.1f} pixels").format(res_now['d_over_s']), 1)
        _row(self.tr("Tolerance:"),
             (self.tr("{0:.1f} corner pixels") if tol != 1
              else self.tr("{0:.1f} corner pixel")).format(tol), 2)

        # ── Nightly stats — sample every 10 min during astronomical night ─
        # Uses RA/Dec + date if available; falls back to single-point otherwise.
        night_samples = self._sample_night_exposures(sw, sh, px, tol)

        row_offset = 3
        if night_samples is not None and len(night_samples) > 0:
            arr = np.array(night_samples, dtype=float)
            # Cap at 120 s for stats consistency with the plot
            arr = np.minimum(arr, 120.0)
            t_max    = float(np.max(arr))
            t_min    = float(np.min(arr))
            t_median = float(np.median(arr))

            self._result_badge.setStyleSheet("")
            self._result_badge.setText(
                self.tr("Nightly median  {0}   {1}").format(_t_str(t_median), severity_badge(t_median)))

            sep_lbl = QLabel(self.tr("── Nightly stats (astro night, sampled every 10 min) ──"))
            sep_lbl.setStyleSheet(
                "font-size: 10px; color: palette(placeholderText); padding-top: 8px;")
            self._result_grid.addWidget(sep_lbl, row_offset, 0, 1, 2)
            row_offset += 1

            _row(self.tr("Best exposure (max):"),
                 f"{_t_str(t_max)}   {severity_badge(t_max)}", row_offset, bold=True)
            row_offset += 1
            _row(self.tr("Median exposure:"),
                 f"{_t_str(t_median)}   {severity_badge(t_median)}", row_offset, bold=True)
            row_offset += 1
            _row(self.tr("Worst exposure (min):"),
                 f"{_t_str(t_min)}   {severity_badge(t_min)}", row_offset, bold=True)
            row_offset += 1
            _row(self.tr("Samples during astro night:"),
                 f"{len(arr)}", row_offset)
            row_offset += 1

            # Per-tolerance comparison table
            sep2 = QLabel(self.tr("── Median at other tolerances ──"))
            sep2.setStyleSheet(
                "font-size: 10px; color: palette(placeholderText); padding-top: 6px;")
            self._result_grid.addWidget(sep2, row_offset, 0, 1, 2)
            row_offset += 1

            for ref_tol in (1, 3, 5, 10):
                if abs(ref_tol - tol) < 0.01:
                    continue   # skip the one we already showed above
                other_samples = self._sample_night_exposures(sw, sh, px,
                                                              float(ref_tol))
                if other_samples:
                    other_arr = np.minimum(np.array(other_samples, dtype=float), 300.0)
                    t_med2 = float(np.median(other_arr))
                    _row(self.tr("  @ {0} px tolerance (median):").format(ref_tol),
                         f"{_t_str(t_med2)}   {severity_badge(t_med2)}", row_offset)
                    row_offset += 1

        else:
            # Fallback: no ephemeris — show single-point result
            t     = res_now["t_max_sec"]
            rate_sign = "+" if res_now["rate_arcsec_per_sec"] >= 0 else "−"
            self._result_badge.setStyleSheet("")
            self._result_badge.setText(
                f"{_t_str(t)}   {severity_badge(t)}")
            _row(self.tr("Field rotation rate:"),
                 f"{res_now['rate_mag_asec_sec']:.4f} arcsec/sec  "
                 f"({res_now['rate_mag_asec_sec']*60:.2f} arcsec/min, {rate_sign}ve)",
                 row_offset)
            row_offset += 1
            _row(self.tr("Max exposure at entered Alt/Az:"), _t_str(t), row_offset, bold=True)
            row_offset += 1
            note = QLabel(self.tr(
                "<small><i>No target RA/Dec available — showing single-point result at "
                "entered Alt/Az.  Select an object in WIMS to get nightly stats.</i></small>"))
            note.setWordWrap(True)
            note.setStyleSheet("color: palette(placeholderText); font-size: 10px;")
            self._result_grid.addWidget(note, row_offset, 0, 1, 2)

        self._tabs.setCurrentIndex(0)

        if _HAS_PG and self._night_plot is not None:
            self._build_night_curve(sw, sh, px, tol)

    def _sample_night_exposures(self, sw: float, sh: float,
                                 px: float, tol: float) -> list | None:
        """
        Sample max exposure every 10 minutes during astronomical night
        using the stored RA/Dec + date ephemeris.

        Returns a list of exposure values (seconds, uncapped) during the
        astronomical night window, or None if ephemeris data is unavailable.
        """
        if None in (self._ra_deg, self._dec_deg,
                    self._date_str, self._tz_name):
            return None

        try:
            import pytz
            from datetime import datetime
            from astropy import units as u
            from astropy.coordinates import (SkyCoord, EarthLocation,
                                              AltAz, get_sun)
            from astropy.time import Time

            local_tz = pytz.timezone(self._tz_name)
            naive    = datetime.strptime(self._date_str, "%Y-%m-%d")
            t_start  = Time(local_tz.localize(
                datetime(naive.year, naive.month, naive.day, 12, 0)))
            loc      = EarthLocation(lat=self._lat * u.deg,
                                     lon=self._lon * u.deg,
                                     height=0 * u.m)

            # 144 samples = one every 10 minutes over 24 hours
            n     = 144
            times = t_start + np.linspace(0, 24, n) * u.hour
            frame = AltAz(obstime=times, location=loc)

            obj_coord = SkyCoord(ra=self._ra_deg * u.deg,
                                 dec=self._dec_deg * u.deg)
            altaz_arr = obj_coord.transform_to(frame)
            obj_alts  = altaz_arr.alt.deg
            obj_azs   = altaz_arr.az.deg
            sun_alts  = get_sun(times).transform_to(frame).alt.deg

            samples = []
            for i in range(n):
                # Only sample during astronomical night while target is up
                if sun_alts[i] >= -18.0 or obj_alts[i] < 0.0:
                    continue
                alt_i = min(float(obj_alts[i]), 89.9)
                az_i  = float(obj_azs[i])
                r     = max_exposure_seconds(self._lat, az_i, alt_i,
                                              sw, sh, px,
                                              max_corner_pixels=tol)
                samples.append(r["t_max_sec"])

            return samples if samples else None

        except Exception:
            return None

    # ── Night exposure curve ───────────────────────────────────────────────

    def _build_night_curve(self, sw: float, sh: float,
                            px: float, tol: float):
        """
        Plot max exposure vs. local time across a full noon-to-noon window.

        Uses the same _compute_alt_curve approach as ObjectVisibilityDialog:
          - n=288 samples (5-minute resolution)
          - x-axis: cumulative hours from noon (12 to 36)
          - twilight band shading: civil / nautical / astronomical
          - same dark blue background as all other WIMS plots
        """
        pw = self._night_plot
        pw.clear()

        ra_deg   = self._ra_deg
        dec_deg  = self._dec_deg
        date_str = self._date_str
        tz_name  = self._tz_name

        if None in (ra_deg, dec_deg, date_str, tz_name):
            self._night_plot_hint.setText(self.tr(
                "No target RA/Dec or date available — "
                "open via the WIMS object list for a full night curve."))
            return

        # ── Build ephemeris — lifted directly from _compute_alt_curve ─────
        try:
            import pytz
            from datetime import datetime
            from astropy import units as u
            from astropy.coordinates import (SkyCoord, EarthLocation,
                                              AltAz, get_sun)
            from astropy.time import Time

            local_tz = pytz.timezone(tz_name)
            naive    = datetime.strptime(date_str, "%Y-%m-%d")
            # Start at noon on the observing date — same as _compute_alt_curve
            t_start  = Time(local_tz.localize(
                datetime(naive.year, naive.month, naive.day, 12, 0)))
            loc      = EarthLocation(lat=self._lat * u.deg,
                                     lon=self._lon * u.deg,
                                     height=0 * u.m)

            n     = 288   # 5-minute resolution, same as _compute_alt_curve
            times = t_start + np.linspace(0, 24, n) * u.hour
            frame = AltAz(obstime=times, location=loc)

            obj_coord = SkyCoord(ra=ra_deg * u.deg, dec=dec_deg * u.deg)
            altaz_arr = obj_coord.transform_to(frame)
            obj_alts  = altaz_arr.alt.deg
            obj_azs   = altaz_arr.az.deg
            sun_alts  = get_sun(times).transform_to(frame).alt.deg

            # Cumulative hours from noon: 12, 12.08, ..., 36
            hrs = 12.0 + np.linspace(0, 24, n)

        except Exception as e:
            self._night_plot_hint.setText(self.tr("Could not compute night curve: {0}").format(e))
            return

        # ── Compute max exposure at each timestep — hard cap 120 s ───────────
        # 120 s is the practical ceiling: "no rotation" at due E/W is
        # instantaneous — after 2 minutes the azimuth has drifted enough
        # that rotation has accumulated significantly on a large chip.
        HARD_CAP  = 120.0
        exp_curve = np.zeros(n, dtype=float)
        above     = obj_alts >= 0.0

        for i in range(n):
            if not above[i]:
                continue
            alt_i = float(obj_alts[i])
            az_i  = float(obj_azs[i])
            if alt_i >= 89.9:
                alt_i = 89.9
            r = max_exposure_seconds(self._lat, az_i, alt_i, sw, sh, px,
                                      max_corner_pixels=tol)
            exp_curve[i] = min(r["t_max_sec"], HARD_CAP)

        # ── Dynamic Y ceiling: night peak rounded up to a clean number ───────
        # Always <= 120 s.
        astro_mask  = sun_alts < -18
        night_valid = astro_mask & above
        if np.any(night_valid):
            night_peak = float(np.max(exp_curve[night_valid]))
        elif np.any(above):
            night_peak = float(np.max(exp_curve[above]))
        else:
            night_peak = 10.0   # fallback — target never rises

        raw_ceil = night_peak * 1.25
        nice_levels = [5, 10, 15, 20, 30, 45, 60, 90, 120]
        CAP = next((v for v in nice_levels if v >= raw_ceil), 120)

        # ── Twilight shading — same logic as ObjectVisibilityDialog ───────
        def _sun_x_at_threshold(threshold):
            crossings = []
            for i in range(len(sun_alts) - 1):
                if (sun_alts[i] - threshold) * (sun_alts[i+1] - threshold) < 0:
                    frac = ((threshold - sun_alts[i])
                            / (sun_alts[i+1] - sun_alts[i]))
                    crossings.append(float(hrs[i] + frac * (hrs[i+1] - hrs[i])))
            return crossings

        def _fill_region(x0, x1, color, alpha):
            pw.addItem(pg.LinearRegionItem(
                values=(x0, x1),
                orientation="vertical",
                brush=pg.mkBrush(*color, alpha),
                pen=pg.mkPen(None),
                movable=False,
            ))

        civil_x    = _sun_x_at_threshold(-6)
        nautical_x = _sun_x_at_threshold(-12)
        astro_x    = _sun_x_at_threshold(-18)

        # Astronomical night (darkest)
        if len(astro_x) >= 2:
            _fill_region(astro_x[0],    astro_x[1],    (0,   0,  15), 200)
        elif len(astro_x) == 1:
            _fill_region(astro_x[0],    float(hrs[-1]), (0,   0,  15), 200)

        # Nautical twilight bands
        if len(nautical_x) >= 2 and len(astro_x) >= 2:
            _fill_region(nautical_x[0], astro_x[0],    (10, 20,  60), 160)
            _fill_region(astro_x[1],    nautical_x[1], (10, 20,  60), 160)

        # Civil twilight bands
        if len(civil_x) >= 2 and len(nautical_x) >= 2:
            _fill_region(civil_x[0],    nautical_x[0], (20, 35,  90), 120)
            _fill_region(nautical_x[1], civil_x[1],    (20, 35,  90), 120)

        # ── Severity threshold lines — only draw ones inside visible range ──
        for y_val, color, label in [
            (60, (80,  200,  80), "60 s"),
            (20, (180, 180,  40), "20 s"),
            (10, (200, 120,  40), "10 s"),
            ( 5, (200,  40,  40),  "5 s"),
        ]:
            if y_val > CAP:
                continue
            pw.addLine(y=y_val,
                       pen=pg.mkPen(color, width=1, style=Qt.PenStyle.DotLine))
            lbl = pg.TextItem(label, anchor=(0, 0.5), color=color)
            lbl.setPos(12.1, y_val)
            pw.addItem(lbl)

        # ── Main exposure curve ───────────────────────────────────────────
        masked = np.where(above, exp_curve, np.nan)
        pw.plot(hrs, masked,
                pen=pg.mkPen((100, 200, 255), width=2.5),
                name=self.tr("Max exp ({0:.0f} px tol)").format(tol))

        # ── Object altitude overlay — thin dashed yellow, scaled to CAP ──
        alt_scaled = np.where(above, obj_alts * (CAP / 90.0), np.nan)
        pw.plot(hrs, alt_scaled,
                pen=pg.mkPen((255, 220, 80, 120), width=1.2,
                             style=Qt.PenStyle.DashLine),
                name=self.tr("Altitude (scaled)"))

        # Horizon line and 30°-equivalent guide line
        pw.addLine(y=0,                  pen=pg.mkPen("w", width=1,
                                         style=Qt.PenStyle.DashLine))
        pw.addLine(y=30.0 * CAP / 90.0, pen=pg.mkPen("g", width=1,
                                         style=Qt.PenStyle.DotLine))

        # ── Axis ranges and tick labels ───────────────────────────────────
        pw.setXRange(12, 36, padding=0)
        pw.setYRange(0, CAP * 1.08, padding=0)   # small breathing room above cap
        ticks = [(h, str(h if h <= 23 else h - 24)) for h in range(12, 37, 2)]
        pw.getAxis("bottom").setTicks([ticks])
        pw.setLabel("bottom", self.tr("Local Time (h)"))

        cap_str = f"{int(CAP)} s" if CAP < 120 else self.tr("120 s (max)")
        pw.setLabel("left",
                    self.tr("Max Exposure (s)  [{0:.0f} px tolerance, cap {1}]").format(tol, cap_str))

        pw.addLegend()

        # ── Best-night annotation — peak exposure during astro night ──────
        night_exp  = np.where(night_valid, exp_curve, 0.0)
        if np.any(night_exp > 0):
            best_idx = int(np.argmax(night_exp))
            best_val = float(night_exp[best_idx])
            best_hr  = float(hrs[best_idx])
            pw.addLine(x=best_hr,
                       pen=pg.mkPen("r", width=1.5, style=Qt.PenStyle.DashLine))
            ann = pg.TextItem(self.tr("Best {0:.1f} s").format(best_val), color="r", anchor=(0, 1))
            ann.setPos(best_hr, best_val + CAP * 0.03)   # offset scales with axis
            pw.addItem(ann)

        name_part = f"{self._target_name}  —  " if self._target_name else ""
        self._night_plot_hint.setText(
            self.tr("{0}{1}  —  "
                    "Blue = max exposure vs. time  •  "
                    "Yellow dashed = target altitude (scaled)  •  "
                    "Red dashed = best exposure during astronomical night  •  "
                    "Curve is zero while target is below horizon.").format(name_part, date_str)
        )


# ── Convenience launcher ──────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    from PyQt6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    dlg = AltAzFieldRotationDialog(
        lat=30.4, lon=-90.2,
        alt=45.0, az=180.0,
        ra_deg=83.82, dec_deg=-5.39,   # Orion Nebula
        date_str="2025-12-15",
        tz_name="US/Central",
    )
    dlg.show()
    sys.exit(app.exec())