#saspro/copyastro.py
#saspro/m_header.py
from __future__ import annotations
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox,
    QPushButton, QMessageBox, QCheckBox, QMdiSubWindow
)

class CopyAstrometryDialog(QDialog):
    """
    Modeless picker that copies the WCS/SIP solution from a source doc
    into the target doc (explicitly passed active view).
    """
    def __init__(self, parent=None, target=None):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Copy Astrometric Solution"))
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)
        self.setMinimumWidth(420)

        self._mw = parent
        self._dm = getattr(parent, "doc_manager", None) or getattr(parent, "docman", None)

        # --- resolve target doc from the passed-in active subwindow/view/doc
        self._tgt = self._doc_from_target(target)
        if self._tgt is None:
            # fallback to active doc helpers, just in case
            try:
                self._tgt = self._dm.get_active_document() if self._dm else None
            except Exception:
                self._tgt = None
            if self._tgt is None and hasattr(parent, "_active_doc"):
                try:
                    self._tgt = parent._active_doc()
                except Exception:
                    pass

        lay = QVBoxLayout(self)

        tgt_name = getattr(self._tgt, "display_name", lambda: None)() or self.tr("Active View")
        lay.addWidget(QLabel(self.tr("Target: <b>{0}</b>").format(tgt_name)))

        lay.addWidget(QLabel(self.tr("Choose a source image that already has a WCS/SIP solution:")))
        self.combo = QComboBox(self)
        lay.addWidget(self.combo)

        self.chk_ignore_sip = QCheckBox(self.tr("Ignore SIP terms (copy TAN only)"))
        self.chk_ignore_sip.setChecked(False)
        lay.addWidget(self.chk_ignore_sip)

        row = QHBoxLayout(); row.addStretch(1)
        self.btn_copy = QPushButton(self.tr("Copy"))
        self.btn_close = QPushButton(self.tr("Close"))
        row.addWidget(self.btn_copy); row.addWidget(self.btn_close)
        lay.addLayout(row)

        self.btn_copy.clicked.connect(self._do_copy)
        self.btn_close.clicked.connect(self.close)

        self._candidates = []  # list[(doc, name, wcs_dict)]
        self._load_sources()

    # --- helpers --------------------------------------------------------
    def _doc_from_target(self, target):
        """Accept QMdiSubWindow, ImageSubWindow, or ImageDocument."""
        try:
            if target is None:
                return None
            # QMdiSubWindow → widget() → .document
            if isinstance(target, QMdiSubWindow):
                w = target.widget()
                return getattr(w, "document", None)
            # ImageSubWindow-like
            if hasattr(target, "document"):
                return getattr(target, "document", None)
            # Already a document
            if hasattr(target, "image") and hasattr(target, "metadata"):
                return target
        except Exception:
            pass
        return None

    def _extract_wcs_dict_for(self, doc):
        import sys
        _h = (getattr(doc, "metadata", {}) or {}).get("original_header")
        print(f"[copyastro] original_header type={type(_h).__name__} "
            f"repr={repr(_h)[:120]}", file=sys.stderr)
        # Prefer the MW helper you already have (returns a flat dict of FITS cards)
        from astropy.io import fits

        # Prefer the MW helper if it exists (returns a flat dict of FITS cards)
        if hasattr(self._mw, "_extract_wcs_dict"):
            try:
                d = self._mw._extract_wcs_dict(doc)
                if d:
                    return dict(d)
            except Exception:
                pass

        meta = getattr(doc, "metadata", {}) or {}
        raw = meta.get("wcs_header") or meta.get("original_header")
        if raw is None:
            return {}

        # Coerce whatever original_header is into a real fits.Header WITHOUT
        # ever indexing a string/blob by guessed keyword (that returns column
        # slices → the ' = 3473...' leak).
        hdr = None
        if isinstance(raw, fits.Header):
            hdr = raw
        elif isinstance(raw, str):
            # flattened 80-col blob → parse by CARD, never by fixed offset
            try:
                hdr = fits.Header.fromstring(raw)
                if len(hdr) == 0:
                    hdr = fits.Header.fromstring(raw, sep="\n")
            except Exception:
                hdr = None
        elif isinstance(raw, dict):
            fmt = raw.get("format")
            if fmt == "fits-cards" and isinstance(raw.get("cards"), list):
                hdr = fits.Header()
                for card in raw["cards"]:
                    try:
                        k = str(card[0]).strip()
                        if k:
                            hdr[k] = (card[1], str(card[2]) if len(card) > 2 else "")
                    except Exception:
                        continue
            elif fmt == "dict" and isinstance(raw.get("items"), dict):
                hdr = fits.Header()
                for k, v in raw["items"].items():
                    try:
                        hdr[str(k)] = v
                    except Exception:
                        continue
            else:
                # plain flat dict of keyword→value
                hdr = fits.Header()
                for k, v in raw.items():
                    if k in ("format", "items", "cards", "text"):
                        continue
                    try:
                        hdr[str(k)] = v
                    except Exception:
                        continue

        if not isinstance(hdr, fits.Header):
            return {}

        keys = {str(k).upper() for k in hdr.keys()}
        if "CRVAL1" not in keys or "CRVAL2" not in keys:
            return {}

        # Build the dict by iterating real cards — keyword/value/comment come
        # from astropy, never from column arithmetic.
        out = {}
        for card in hdr.cards:
            kw = card.keyword
            if kw in ("COMMENT", "HISTORY", ""):
                continue
            out[kw] = card.value
        return out
    def _load_sources(self):
        self.combo.clear()
        self._candidates.clear()

        if not self._dm or not self._tgt:
            self.combo.addItem(self.tr("No target image."))
            self.btn_copy.setEnabled(False)
            return

        try:
            docs = self._dm.all_documents()
        except Exception:
            docs = []

        found_any = False
        for d in docs:
            if d is self._tgt:
                continue
            w = self._extract_wcs_dict_for(d)
            if not w:
                continue
            name = getattr(d, "display_name", lambda: None)() or (getattr(d, "metadata", {}).get("file_path") or self.tr("Untitled"))
            # hint text (RA/Dec)
            ra, dec = w.get("CRVAL1"), w.get("CRVAL2")
            hint = f"  (RA={ra:.5f}, Dec={dec:.5f})" if isinstance(ra, (int, float)) and isinstance(dec, (int, float)) else ""
            self.combo.addItem(name + hint)
            self._candidates.append((d, name, w))
            found_any = True

        if not found_any:
            self.combo.addItem(self.tr("No other images with WCS found"))
            self.btn_copy.setEnabled(False)

    # --- action ---------------------------------------------------------
    def _do_copy(self):
        if self._tgt is None:
            QMessageBox.information(self, self.tr("Copy Astrometry"), self.tr("No target image."))
            return

        idx = self.combo.currentIndex()
        if idx < 0 or idx >= len(self._candidates):
            return

        _, src_name, wcs = self._candidates[idx]

        # Optionally strip SIP → TAN only
        if self.chk_ignore_sip.isChecked():
            wcs = {
                k: v for k, v in wcs.items()
                if not str(k).upper().startswith(("A_", "B_", "AP_", "BP_"))
                and str(k).upper() not in {"A_ORDER", "B_ORDER", "AP_ORDER", "BP_ORDER"}
            }
            # enforce TAN
            c1 = str(wcs.get("CTYPE1", "RA---TAN"))
            c2 = str(wcs.get("CTYPE2", "DEC--TAN"))
            if c1.endswith("-SIP"): wcs["CTYPE1"] = "RA---TAN"
            if c2.endswith("-SIP"): wcs["CTYPE2"] = "DEC--TAN"

        ok = False
        if hasattr(self._mw, "_apply_wcs_dict_to_doc"):
            try:
                ok = bool(self._mw._apply_wcs_dict_to_doc(self._tgt, dict(wcs)))
            except Exception:
                ok = False

        if not ok:
            QMessageBox.warning(self, self.tr("Copy Astrometry"), self.tr("Failed to apply astrometric solution."))
            return

        # refresh header dock + listeners immediately
        try:
            if hasattr(self._mw, "_refresh_header_viewer"):
                self._mw._refresh_header_viewer(self._tgt)
            if hasattr(self._mw, "currentDocumentChanged"):
                self._mw.currentDocumentChanged.emit(self._tgt)
        except Exception:
            pass

        try:
            tgt_name = getattr(self._tgt, "display_name", lambda: None)() or self.tr("Target")
            QMessageBox.information(self, self.tr("Copy Astrometry"),
                                    self.tr("Copied solution from “{0}” to “{1}”.").format(src_name, tgt_name))
        except Exception:
            pass

        self.close()
