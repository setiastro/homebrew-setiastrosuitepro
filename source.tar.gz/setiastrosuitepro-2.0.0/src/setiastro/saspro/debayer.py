#saspro/debayer.py
from __future__ import annotations
import numpy as np
from typing import Optional, Tuple
import cv2
import os
import threading as _threading

from PyQt6.QtCore import QCoreApplication, Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QDialogButtonBox,
    QGroupBox, QMessageBox, QProgressBar
)


def _tr(text: str) -> str:
    return QCoreApplication.translate("Debayer", text)

# Methods with a GPU implementation. Anything else resolves to the numba
# kernel, so the dialog says so rather than letting the user pick GPU and
# silently get the CPU.
try:
    from setiastro.saspro.torch_calibration import GPU_DEBAYER_METHODS
except Exception:
    # Only reached when torch_calibration will not import at all, in which
    # case nothing runs on the GPU anyway and this list just drives the
    # dialog's wording.
    GPU_DEBAYER_METHODS = ("rcd", "ahd")

def _gpu_methods_label() -> str:
    """"RCD and AHD run" -- for dialog text, derived from GPU_DEBAYER_METHODS
    so the wording cannot drift from what is actually implemented.

    Carries its own verb so the sentence still agrees in number when the list
    is one method long, or empty.
    """
    names = [str(m).upper() for m in GPU_DEBAYER_METHODS]
    if not names:
        return "No method runs"
    if len(names) == 1:
        return f"Only {names[0]} runs"
    return ", ".join(names[:-1]) + " and " + names[-1] + " run"


# fast kernels you already have
try:
    from setiastro.saspro.legacy.numba_utils import debayer_fits_fast
except Exception as e:  # very unlikely in your env
    debayer_fits_fast = None
from setiastro.saspro.bayer_utils import (
    VALID_BAYER_PATTERNS,
    detect_bayer_offsets_and_roworder as _detect_bayer_offsets_and_roworder_from_meta,
    detect_bayer_pattern,
    normalize_bayer_token as _normalize_bayer_token,
    roworder_is_bottom_up as _roworder_is_bottom_up,
)
from setiastro.saspro.help_support import make_help_button

_RAW_EXTS = (".raf", ".raw", ".rw2", ".arw", ".nef", ".cr2", ".cr3", ".dng", ".orf", ".pef")

# ── GPU demosaic preference ─────────────────────────────────────────────────
# Resolved once, lazily, under a lock. debayer_array runs inside the
# normalization worker threads, so the alternative -- reading QSettings on
# every call from every thread -- is both wasteful and the sort of cross-thread
# Qt access that only works by accident. The value cannot change mid-run.
_GPU_PREF_LOCK = _threading.Lock()
_GPU_PREF: Optional[bool] = None


def set_gpu_debayer_pref(value) -> None:
    """Pin the GPU-demosaic preference for this run, or pass None to go back to
    reading it from settings. Call this from the main thread."""
    global _GPU_PREF
    with _GPU_PREF_LOCK:
        _GPU_PREF = None if value is None else bool(value)


def _gpu_debayer_pref() -> bool:
    """Whether the optimizer measured the GPU demosaic as the winner here."""
    global _GPU_PREF
    with _GPU_PREF_LOCK:
        if _GPU_PREF is not None:
            return _GPU_PREF
    try:
        from setiastro.saspro.stacking_worker_tune import debayer_gpu_enabled
        v = bool(debayer_gpu_enabled())
    except Exception:
        v = False
    with _GPU_PREF_LOCK:
        if _GPU_PREF is None:
            _GPU_PREF = v
        return _GPU_PREF

def _find_raw_sibling(path: Optional[str]) -> Optional[str]:
    """
    If we only have a derived FITS/XISF path, try to locate a plausible RAW
    with the same stem in the same folder.
    """
    if not path:
        return None
    base, _ = os.path.splitext(os.path.basename(path))
    folder = os.path.dirname(path)
    if not folder or not base:
        return None
    try:
        for ext in _RAW_EXTS:
            cand = os.path.join(folder, base + ext)
            if os.path.exists(cand):
                return cand
    except Exception:
        pass
    return None

# -------- helpers ------------------------------------------------------------
_BAYER_METHODS = [
    # RCD is first because it's the best general choice for OSC astro work
    # — ratio-corrected demosaic preserves saturation on faint narrowband
    # color and uses second-order gradients that don't speckle under noise
    # the way VNG does on dim data. AHD is a close second and tends to win
    # on fine-detail subjects (planetary, lunar, dense star fields,
    # daylight) by reconstructing both H and V candidates and picking per
    # pixel which one is more homogeneous in CIELab. VNG stays available
    # for daylight subjects where its gradient response is still useful;
    # edge-aware and bilinear are fallbacks; strict_cfa is for drizzle prep.
    ("RCD (Ratio-Corrected)",                      "rcd"),
    ("Edge-aware (Selective Gradient)",            "edge"),    
    ("AHD (Adaptive Homogeneity-Directed)",        "ahd"),
    ("VNG (Variable Number of Gradients)",         "vng"),
    ("Bilinear (Traditional Debayer)",             "bilinear"),
    ("Strict CFA (no interpolation)",              "strict_cfa"),
]
_XTRANS_METHODS = [
    ("AHD (rawpy)", "AHD"),
    ("DHT (rawpy)", "DHT"),
]
_VALID = set(VALID_BAYER_PATTERNS)

# --- Bayer offset / roworder helpers ---------------------------------------

def _detect_bayer_offsets_and_roworder(doc) -> tuple[int, int, str]:
    """
    Returns (xoff, yoff, roworder_str). Missing values default to 0.
    """
    hdr, meta, _ = _extract_doc_info(doc)
    return _detect_bayer_offsets_and_roworder_from_meta(hdr, meta)

def _detect_bayer_from_header(doc) -> Optional[str]:
    """
    Best-effort read of a Bayer pattern from the document header/metadata.
    Returns 'RGGB'/'BGGR'/'GRBG'/'GBRG' or None if not found.
    """
    hdr, meta, _ = _extract_doc_info(doc)
    image_shape = None
    try:
        img = getattr(doc, "image", None)
        if img is not None:
            image_shape = np.asarray(img).shape
    except Exception:
        image_shape = None
    return detect_bayer_pattern(hdr, meta, image_shape=image_shape)


def _detect_cfa_family(doc) -> Optional[str]:
    """
    Returns 'BAYER', 'XTRANS', or None.
    Uses header/meta hints; if a RAW path exists, asks rawpy for ground truth.
    """
    hdr, meta, src_path = _extract_doc_info(doc)

    # Build a searchable blob of header + meta
    def _safe_blob(x) -> str:
        try:
            return str(x)
        except Exception:
            return ""
    blob = (_safe_blob(hdr) + " " + _safe_blob(meta)).upper()

    # Direct tokens first
    if any(k in blob for k in ("X-TRANS", "XTRANS", "FUJIFILM X-TRANS", "X TRANS")):
        return "XTRANS"
    if any(k in blob for k in ("BAYER", "RGGB", "BGGR", "GRBG", "GBRG")):
        return "BAYER"

    # Camera model hint
    model = (str(meta.get("MODEL")
              or meta.get("CameraModel")
              or (hdr.get("MODEL") if hasattr(hdr, "get") else None)
              or "")).upper()
    make  = (str(meta.get("MAKE")
              or (hdr.get("MAKE") if hasattr(hdr, "get") else None)
              or "")).upper()
    if "FUJIFILM" in make and any(tag in model for tag in (
        "X-T1","X-T2","X-T3","X-T4","X-T5",
        "X-E2","X-E2S","X-E3","X-PRO1","X-PRO2","X-PRO3",
        "X-H1","X-H2S","X-S10","X-S20","X100","X70","X30"
    )):
        return "XTRANS"

    # If we have a source path, ask rawpy
    if src_path:
        try:
            import rawpy  # type: ignore
            with rawpy.imread(src_path) as rp:
                if getattr(rp, "xtrans_pattern", None) is not None:
                    return "XTRANS"
                pat = getattr(rp, "raw_pattern", None)
                if pat is not None:
                    pat = np.array(pat)
                    if getattr(pat, "shape", None) == (2, 2):
                        return "BAYER"
        except Exception:
            pass

    return None


def _score_rgb(rgb: np.ndarray) -> float:
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    def grad_energy(x):
        gx = cv2.Sobel(x, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(x, cv2.CV_32F, 0, 1, ksize=3)
        return float(np.mean(gx*gx + gy*gy))
    e_rg = grad_energy(r - g)
    e_bg = grad_energy(b - g)
    return e_rg + e_bg

def _autodetect_bayer_by_scoring(mono: np.ndarray) -> str:
    candidates = ["RGGB", "BGGR", "GRBG", "GBRG"]
    best_pat, best_score = None, float("inf")
    for pat in candidates:
        try:
            rgb = debayer_fits_fast(mono, pat, cfa_drizzle=False)
            rgb32 = rgb.astype(np.float32, copy=False)
            s = _score_rgb(rgb32)
            if s < best_score:
                best_score, best_pat = s, pat
        except Exception:
            continue
    return best_pat or "RGGB"

def _debayer_xtrans_via_rawpy(src_path: str,
                              use_cam_wb: bool = True,
                              output_bps: int = 16,
                              alg: str = "AHD") -> np.ndarray:
    """
    X-Trans demosaic via rawpy with selectable algorithm: 'AHD' or 'DHT'.
    Returns float32 RGB in [0,1].
    """
    import rawpy  # type: ignore
    alg_map = {
        "AHD": rawpy.DemosaicAlgorithm.AHD,
        "DHT": rawpy.DemosaicAlgorithm.DHT,
    }
    dem = alg_map.get((alg or "AHD").upper(), rawpy.DemosaicAlgorithm.AHD)
    with rawpy.imread(src_path) as rp:
        rgb16 = rp.postprocess(
            demosaic_algorithm=dem,
            no_auto_bright=True,
            gamma=(1.0, 1.0),
            output_bps=output_bps,
            use_camera_wb=use_cam_wb,
            fbdd_noise_reduction=rawpy.FBDDNoiseReductionMode.Off,
            four_color_rgb=False,
            half_size=False,
            bright=1.0,
            highlight_mode=rawpy.HighlightMode.Clip
        )
    return (rgb16.astype(np.float32) / (65535.0 if output_bps == 16 else 255.0))

def _doc_is_managed(dm, doc) -> bool:
    """Best-effort: is this document tracked by DocManager?"""
    if dm is None or doc is None:
        return False
    # Explicit API if you have it
    fn = getattr(dm, "is_managed_document", None)
    if callable(fn):
        try:
            return bool(fn(doc))
        except Exception:
            pass
    # Common internal collections
    for attr in ("_docs", "documents", "open_documents", "all_docs"):
        coll = getattr(dm, attr, None)
        if isinstance(coll, (list, tuple)):
            try:
                return any(d is doc for d in coll)
            except Exception:
                continue
    return False

def _apply_result_to_doc(dm, doc, rgb: np.ndarray, step_name: str = "Debayer"):
    """
    Always apply to the specific 'doc' (never assume 'active' view).
    """

    # --- A) Best: the document can commit its own undoable edit ---
    if hasattr(doc, "apply_edit") and callable(doc.apply_edit):
        meta = dict(getattr(doc, "metadata", {}) or {})
        meta["is_mono"] = False
        meta.setdefault("bit_depth", "32-bit floating point")
        try:
            doc.apply_edit(rgb.copy(), metadata=meta, step_name=step_name)
        except TypeError:
            # older signature: (image, metadata) or (image,)
            try: doc.apply_edit(rgb.copy(), metadata=meta)
            except Exception: doc.apply_edit(rgb.copy())
        _refresh_view_for_doc(dm, doc)
        return

    # --- B) Next best: mutate the doc directly, then refresh its view ---
    try:
        doc.image = rgb
        meta = getattr(doc, "metadata", None)
        if isinstance(meta, dict):
            meta["is_mono"] = False
            meta.setdefault("bit_depth", "32-bit floating point")
    except Exception:
        pass
    _refresh_view_for_doc(dm, doc)
    return

def _refresh_view_for_doc(dm, doc):
    """
    Find the subwindow that displays 'doc' and ask it to repaint,
    without switching the active view.
    """
    try:
        # Try a dedicated API if your app exposes it
        fn = getattr(dm, "refresh_subwindow_for_document", None)
        if callable(fn):
            fn(doc); return
    except Exception:
        pass

    # Generic fallback: walk MDI subwindows and update the one bound to 'doc'
    try:
        mw = getattr(dm, "main_window", None) or getattr(dm, "mw", None)
        if mw is None: return
        mdi = getattr(mw, "mdi", None)
        if mdi is None: return
        for sw in mdi.subWindowList():
            w = getattr(sw, "widget", lambda: None)()
            if getattr(w, "document", None) is doc:
                # Common update hooks
                upd = getattr(w, "refresh_pixmap_from_document", None) \
                      or getattr(w, "refresh_view", None) \
                      or getattr(w, "update_from_doc", None)
                if callable(upd):
                    upd(); return
                # Absolute fallback: force a repaint
                try:
                    w.update(); sw.update()
                except Exception:
                    pass
                return
    except Exception:
        pass


# -------- worker -------------------------------------------------------------

class _DebayerWorker(QThread):
    progress = pyqtSignal(int, str)
    failed = pyqtSignal(str)
    finished = pyqtSignal(np.ndarray, str)  # (rgb, used_pattern)

    def __init__(self, mono: np.ndarray, pattern: str, method: str = "vng",
                 use_gpu: Optional[bool] = None):
        super().__init__()
        self.mono = mono
        self.pattern = pattern
        self.method = (method or "vng")
        self.use_gpu = use_gpu

    def run(self):
        try:
            if debayer_fits_fast is None:
                raise RuntimeError("Numba debayer kernels not available.")

            # enforce kernel-friendly layout/dtype
            img = _mono_as_float32_contig(self.mono)

            if img.ndim != 2:
                raise ValueError("Debayer expects a single-channel (mosaic) image.")
            if self.pattern not in _VALID:
                raise ValueError(f"Unsupported pattern: {self.pattern}")

            self.progress.emit(5, self.tr("Debayering ({0}, {1}) …").format(
                self.pattern, self.method))
            # Through debayer_array, not debayer_fits_fast. This used to call
            # the numba kernel directly, which meant the interactive tool could
            # never use the GPU however stacking/debayer_gpu was set -- and it
            # was a second copy of the dispatch that debayer_array's own
            # docstring claims to be the only one.
            #
            # roworder="" on purpose: DebayerDialog has already flipped the
            # mosaic to top-down in its constructor and flips the RGB back in
            # _on_done, so letting debayer_array flip as well would double it.
            rgb = debayer_array(
                img, pattern=self.pattern, roworder="", method=self.method,
                cfa_drizzle=False, use_gpu=self.use_gpu,
                status_cb=lambda s: self.progress.emit(
                    60, self.tr("Using {0} …").format(s)),
            )
            self.progress.emit(96, self.tr("Finalizing …"))
            self.finished.emit(rgb, self.pattern)
        except Exception as e:
            self.failed.emit(str(e))

def _extract_doc_info(doc) -> tuple[dict | None, dict, Optional[str]]:
    meta = getattr(doc, "metadata", {}) or {}
    hdr = (meta.get("original_header")
           or meta.get("fits_header")
           or meta.get("header")
           or getattr(doc, "header", None))

    # try multiple fields for a source path
    def _first_nonempty(*vals):
        for v in vals:
            if v:
                return v
        return None

    # header cards that might store original RAW path
    hdr_raw = None
    try:
        if hdr is not None:
            for k in ("RAW_PATH","RAWFILE","ORIGFILE","ORIGINAL","ORIGPATH","RAWORIG","SOURCE","SRCFILE"):
                v = hdr.get(k) if hasattr(hdr, "get") else hdr[k]  # may raise → caught
                if v:
                    hdr_raw = str(v)
                    break
    except Exception:
        pass

    path = _first_nonempty(
        meta.get("raw_source_path"),
        hdr_raw,
        meta.get("file_path"),
        getattr(doc, "path", None),
        getattr(doc, "file_path", None),
    )
    return hdr, meta, path

def _mono_as_float32_contig(arr: np.ndarray) -> np.ndarray:
    """
    Ensure mono mosaic is 2D, C-contiguous, float32 in [0,1] for numba kernels.
    Scales integer inputs by their max (8/16/32 bits).
    """
    a = np.asarray(arr)
    if a.ndim != 2:
        raise RuntimeError("Debayer expects a single-channel (mosaic) image.")
    if np.issubdtype(a.dtype, np.integer):
        # pick a sensible scale based on dtype
        info = np.iinfo(a.dtype)
        a = a.astype(np.float32, copy=False) / float(info.max if info.max > 0 else 1.0)
    else:
        a = a.astype(np.float32, copy=False)
        # Only rescale genuine 16-bit ADU stored as float (max approaches
        # thousands/65535). Flat-divided linear astro data legitimately exceeds
        # 1.0 — even 2–3× — and must NOT be crushed by /65535.
        if a.max() > 256.0:
            a = a / 65535.0
    return np.ascontiguousarray(a)


# -------- dialog -------------------------------------------------------------

class DebayerDialog(QDialog):
    """
    One-shot debayer UI for the active view. Uses your numba kernels.
    If the image is already RGB, will warn and exit.
    """
    def __init__(self, parent, doc_manager, active_doc):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Debayer"))
        self.setWindowFlag(Qt.WindowType.Window, True)
        import platform
        if platform.system() == "Darwin":
            self.setWindowFlag(Qt.WindowType.Tool, True)  
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setModal(False)
        self.dm = doc_manager
        self.doc = active_doc
        self.worker: Optional[_DebayerWorker] = None

        img = getattr(active_doc, "image", None)
        if img is None:
            raise RuntimeError("No image in active document.")
        arr = np.asarray(img)

        # Reject non-mosaic early
        if arr.ndim == 3 and arr.shape[2] >= 3:
            QMessageBox.information(self, self.tr("Debayer"), self.tr("Image already has 3 channels."))
            self.setEnabled(False)
            self.close()
            return
        if arr.ndim != 2:
            QMessageBox.warning(self, self.tr("Debayer"), self.tr("Only single-channel mosaics can be debayered."))
            self.setEnabled(False)
            self.close()
            return

        # ✅ normalize for numba kernels
        self._src = _mono_as_float32_contig(arr)
        # --- ROWORDER handling (NINA / FITS) ---
        xoff, yoff, roworder = _detect_bayer_offsets_and_roworder(active_doc)
        self._roworder = roworder
        self._xoff = xoff
        self._yoff = yoff

        # ROWORDER=BOTTOM-UP means the on-disk array is stored bottom-to-top
        # relative to the Bayer pattern in the header. Flip once to top-down so
        # the header pattern (e.g. RGGB) applies as-written. This is the ONLY
        # orientation correction — detect_bayer_pattern no longer bumps yoff by
        # height parity, so the two can't stack into a wrong pattern.
        if _roworder_is_bottom_up(roworder):
            self._src = np.ascontiguousarray(np.flipud(self._src))
        # detect CFA family (BAYER/XTRANS/None)
        self._cfa_family = _detect_cfa_family(active_doc)

        v = QVBoxLayout(self)

        # pattern selection
        detected = _detect_bayer_from_header(active_doc)
        self._detected_pattern = detected  # store for later

        gb = QGroupBox(self.tr("Bayer pattern"), self)
        h = QHBoxLayout(gb)
        self.combo_pattern = QComboBox(self)
        self.combo_pattern.addItems([
            "Auto (from header)",
            "RGGB", "BGGR", "GRBG", "GBRG",
        ])
        self.combo_pattern.setCurrentIndex(0)
        self.lbl_detect = QLabel(self.tr("Detected: {0}  "
                                         "(XBAYROFF={1}, YBAYROFF={2}, ROWORDER={3})").format(
                                             detected or self.tr("(unknown)"),
                                             xoff, yoff, roworder or 'n/a'))
        h.addWidget(self.combo_pattern, 1)
        h.addWidget(self.lbl_detect)
        v.addWidget(gb)

        if self._cfa_family == 'XTRANS':
            self.combo_pattern.setEnabled(False)
            self.lbl_detect.setText(self.tr("Detected: X-Trans (rawpy)"))
        else:
            norm = _normalize_bayer_token(self._detected_pattern or "")
            self.lbl_detect.setText(self.tr("Detected: {0}").format(
                norm or self.tr("(unknown)")))

        self.method_group = QGroupBox(self.tr("Method"), self)
        hm = QHBoxLayout(self.method_group)
        self.combo_method = QComboBox(self)

        if self._cfa_family == 'XTRANS':
            for label, _tok in _XTRANS_METHODS:
                self.combo_method.addItem(label)
        else:
            for label, _tok in _BAYER_METHODS:
                self.combo_method.addItem(label)

        print(f"[Debayer] CFA family auto-detect → {self._cfa_family}  "
            f"path={_extract_doc_info(active_doc)[2]}  "
            f"model={getattr(active_doc, 'metadata', {}).get('MODEL')}")

        self.combo_method.setCurrentIndex(0)
        hm.addWidget(self.combo_method)
        hm.addStretch(1)
        hm.addWidget(make_help_button("debayer", self))
        v.addWidget(self.method_group)

        # ── Processing: CPU or GPU, plus a way to measure which is faster ──
        # The combo is a per-run override, initialised from what the optimizer
        # measured (stacking/debayer_gpu). It deliberately does NOT write that
        # key: a choice made in a one-shot tool should not quietly change what
        # the stacking pipeline does. Optimize… is how the stored default
        # changes, and it re-reads this combo when it closes.
        self.backend_group = QGroupBox(self.tr("Processing"), self)
        hb = QHBoxLayout(self.backend_group)
        self.combo_backend = QComboBox(self)
        self.combo_backend.addItem(self.tr("CPU (numba)"), False)
        self.combo_backend.addItem(self.tr("GPU (torch)"), True)
        self.combo_backend.setToolTip(self.tr(
            "Where the demosaic runs, for this run only.\n\n"
            "Starts on whatever the optimizer measured as faster on this "
            "machine. Changing it here does not change that stored setting — "
            "use Optimize… for that.\n\n"
            "%s on the GPU; every other method falls back to the "
            "numba kernel automatically, and the status line will say so when "
            "it does."
        ) % _gpu_methods_label())
        self.lbl_backend = QLabel("")
        self.lbl_backend.setEnabled(False)
        hb.addWidget(self.combo_backend)
        hb.addWidget(self.lbl_backend, 1)

        try:
            from setiastro.saspro.stacking_tune_dialog import (
                install_optimize_button as _install_tune_btn,
            )

            def _shape_for_tuner():
                try:
                    s = np.asarray(self._src).shape
                    return int(s[0]), int(s[1])
                except Exception:
                    return 3000, 4000

            _install_tune_btn(self, hb,
                              frame_shape_provider=_shape_for_tuner,
                              on_finished=self._reload_backend_pref)
        except Exception:
            pass   # a missing tuner must not stop the Debayer tool opening

        v.addWidget(self.backend_group)
        self.combo_method.currentIndexChanged.connect(self._backend_changed)
        self.combo_backend.currentIndexChanged.connect(self._backend_changed)
        self._reload_backend_pref()

        #sasprogress + buttons
        self.status = QLabel("")
        self.bar = QProgressBar(self); self.bar.setRange(0, 100)
        v.addWidget(self.status)
        v.addWidget(self.bar)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self._go)
        btns.rejected.connect(self.reject)
        v.addWidget(btns)


    def _current_method_token(self) -> str:
        """The method token for whatever is selected, Bayer or X-Trans."""
        label = self.combo_method.currentText()
        table = (_XTRANS_METHODS if self._cfa_family == "XTRANS"
                 else _BAYER_METHODS)
        return next((tok for (lbl, tok) in table if lbl == label), "rcd")

    def _reload_backend_pref(self):
        """Set the combo from what the optimizer measured. Also called after
        Optimize… closes, since that writes the setting behind our back."""
        want = False
        try:
            from setiastro.saspro.stacking_worker_tune import debayer_gpu_enabled
            want = bool(debayer_gpu_enabled())
        except Exception:
            want = False
        try:
            self.combo_backend.blockSignals(True)
            self.combo_backend.setCurrentIndex(1 if want else 0)
        finally:
            self.combo_backend.blockSignals(False)
        self._backend_changed()

    def _backend_changed(self):
        """Keep the note beside the combo honest about what will actually run."""
        if self._cfa_family == "XTRANS":
            self.combo_backend.setEnabled(False)
            self.lbl_backend.setText(
                self.tr("X-Trans demosaics through rawpy (CPU only)"))
            return
        self.combo_backend.setEnabled(True)
        if not bool(self.combo_backend.currentData()):
            self.lbl_backend.setText("")
            return
        meth = self._current_method_token()
        if meth not in GPU_DEBAYER_METHODS:
            self.lbl_backend.setText(self.tr(
                "{0} has no GPU path — it will run on the CPU"
            ).format(meth.upper()))
            return
        try:
            from setiastro.saspro.torch_calibration import (
                debayer_backend_note, debayer_gpu_available)
            if debayer_gpu_available():
                self.lbl_backend.setText(debayer_backend_note())
            else:
                self.lbl_backend.setText(self.tr(
                    "no GPU device available — it will run on the CPU"))
        except Exception:
            self.lbl_backend.setText("")

    def _chosen_pattern(self) -> str:
        if self._cfa_family == 'XTRANS':
            return "XTRANS"
        txt = self.combo_pattern.currentText()
        if txt.startswith("Auto"):
            norm = _normalize_bayer_token(self._detected_pattern or "")
            return norm or _autodetect_bayer_by_scoring(self._src)
        return txt

    def _go(self):
        # A second OK/Enter while debayering started a second run, and both
        # applied their result to the document.
        if self.worker is not None and self.worker.isRunning():
            return
        pat = self._chosen_pattern()
        method_label = self.combo_method.currentText()

        # X-Trans path
        if pat == "XTRANS":
            src_path = (getattr(self.doc, "file_path", None) or getattr(self.doc, "path", None)
                        or (getattr(self.doc, "metadata", {}) or {}).get("file_path"))
            if not src_path or not str(src_path).lower().endswith(_RAW_EXTS):
                # try sibling RAW next to this file
                sib = _find_raw_sibling(getattr(self.doc, "file_path", None) or (getattr(self.doc, "metadata", {}) or {}).get("file_path"))
                if sib:
                    src_path = sib
                else:
                    QMessageBox.warning(self, self.tr("Debayer"),
                        self.tr("X-Trans detected, but original RAW path was not found.\n"
                                "Open the RAF directly, or embed RAW_PATH in the header, or place the RAW next to the file."))
                    return
            # map label → rawpy alg token
            alg = next((tok for (label, tok) in _XTRANS_METHODS if label == method_label), "AHD")
            try:
                self.status.setText(self.tr("Demosaicing X-Trans via rawpy ({0}) …").format(alg))
                self.bar.setValue(10)
                rgb = _debayer_xtrans_via_rawpy(src_path, use_cam_wb=True, output_bps=16, alg=alg)
                self.bar.setValue(96)
                _apply_result_to_doc(self.dm, self.doc, rgb.astype(np.float32, copy=False),
                                    step_name=f"Debayer (X-Trans/{alg})")
                self.status.setText(self.tr("Done."))
                self.accept()
            except Exception as e:
                QMessageBox.critical(self, self.tr("Debayer"),
                                     self.tr("X-Trans demosaic failed:\n{0}").format(e))
                self.status.setText(self.tr("Failed."))
            return

        # Bayer path (Numba) with method
        if pat not in _VALID:
            QMessageBox.warning(self, self.tr("Debayer"), self.tr("Unknown pattern (auto-detect failed). Choose a pattern explicitly."))
            return

        bayer_method = next((tok for (label, tok) in _BAYER_METHODS if label == method_label), "vng")
        _use_gpu = bool(self.combo_backend.currentData())
        self.status.setText(
            self.tr("Debayering as {0} ({1}) on {2} …").format(
                pat, bayer_method, 'GPU' if _use_gpu else 'CPU'))
        self.bar.setValue(0)
        self.worker = _DebayerWorker(self._src, pat, method=bayer_method,
                                     use_gpu=_use_gpu)
        self.worker.progress.connect(self._on_prog)
        self.worker.failed.connect(self._on_fail)
        self.worker.finished.connect(self._on_done)
        self.worker.start()


    def _on_prog(self, p: int, msg: str):
        self.bar.setValue(p); self.status.setText(msg)

    def _on_fail(self, err: str):
        QMessageBox.critical(self, self.tr("Debayer"), err)
        self.status.setText(self.tr("Failed."))

    def _on_done(self, rgb: np.ndarray, used_pattern: str):
        # We flipped the mosaic to top-down before debayering so the Bayer phase
        # was correct. Flip the RGB result back so the output matches the
        # original display orientation.
        if _roworder_is_bottom_up(self._roworder):
            rgb = np.ascontiguousarray(np.flipud(rgb))
        _apply_result_to_doc(self.dm, self.doc, rgb, step_name=f"Debayer ({used_pattern})")
        self.status.setText(self.tr("Done."))
        self.accept()


# -------- headless (shortcut / DnD) -----------------------------------------

def debayer_array(
    mono: np.ndarray,
    *,
    pattern: str,
    roworder: str = "",
    method: str = "vng",
    cfa_drizzle: bool = False,
    use_gpu: Optional[bool] = None,
    status_cb=None,
) -> np.ndarray:
    """
    Pure Bayer demosaic: mono mosaic array in -> RGB array out. No doc, no Qt,
    no side effects. This is the single source of truth for the flip-in /
    debayer / flip-out orientation handling, shared by the interactive dialog
    and the stacking pipeline.

    `pattern` must already be a resolved RGGB/BGGR/GRBG/GBRG token — this
    function does NOT re-detect. Callers own detection so each can apply its
    own header-reading rules.

    `use_gpu` overrides the measured preference for THIS call only: True to
    try the card, False to force numba, None (the default) to follow
    stacking/debayer_gpu. The interactive dialog passes an explicit value so a
    choice made there cannot leak into the stacking pipeline's setting.

    `status_cb` is called once with a short description of the backend that
    actually ran. Worth wiring up: a GPU request that falls back to numba --
    unported method, no VRAM headroom -- is otherwise invisible.
    """
    if debayer_fits_fast is None:
        raise RuntimeError("Numba debayer kernels not available.")

    pat = (pattern or "").upper()
    if pat not in _VALID:
        raise ValueError(f"Unsupported Bayer pattern: {pat!r}")

    m = _mono_as_float32_contig(np.asarray(mono))

    # Bottom-up: flip to top-down so the Bayer phase matches `pattern`,
    # debayer, then flip the RGB back so output orientation matches input.
    flipped = _roworder_is_bottom_up(roworder)
    if flipped:
        m = np.ascontiguousarray(np.flipud(m))

    meth = method if method in ("edge", "bilinear", "strict_cfa", "vng", "rcd", "ahd") else "rcd"

    # GPU demosaic when the optimizer measured it faster on this machine
    # (stacking/debayer_gpu). debayer_gpu returns None for anything it does not
    # implement, for a device without the VRAM headroom, and on any exception,
    # so the numba kernel below stays the single fallback for every such case
    # and this is strictly additive.
    rgb = None
    _want_gpu = _gpu_debayer_pref() if use_gpu is None else bool(use_gpu)
    _why = []
    if _want_gpu:
        try:
            from setiastro.saspro.torch_calibration import debayer_gpu
            rgb = debayer_gpu(m, pat, cfa_drizzle=cfa_drizzle, method=meth,
                              status_cb=_why.append)
        except Exception as e:
            _why.append(f"{type(e).__name__}: {e}")
            rgb = None
    if rgb is None:
        rgb = debayer_fits_fast(m, pat, cfa_drizzle=cfa_drizzle, method=meth)
        if status_cb:
            try:
                if _want_gpu:
                    status_cb(f"CPU (numba {meth.upper()}) — the GPU path "
                              f"declined: {_why[-1] if _why else 'no reason given'}")
                else:
                    status_cb(f"CPU (numba {meth.upper()})")
            except Exception:
                pass
    elif status_cb:
        try:
            status_cb(f"GPU (torch {meth.upper()})")
        except Exception:
            pass

    if flipped:
        rgb = np.ascontiguousarray(np.flipud(rgb))
    return rgb

def apply_debayer_preset_to_doc(dm, doc, preset: dict) -> Tuple[str, np.ndarray]:
    """
    preset = {
        "pattern": "auto|RGGB|BGGR|GRBG|GBRG",
        "method":  "auto|rcd|ahd|vng|edge|bilinear|strict_cfa|AHD|DHT"
                   (lowercase 'ahd' is the Numba Bayer AHD; uppercase 'AHD'
                   routes to rawpy for X-Trans only.)
    }
    Returns (used_pattern, rgb_array).
    """
    if getattr(doc, "image", None) is None:
        raise RuntimeError("No image in document.")

    # ✅ normalize for numba kernels & ensure 2D
    mono_in = np.asarray(doc.image)
    if mono_in.ndim != 2:
        raise RuntimeError("Debayer expects a single-channel (mosaic) image.")
    mono = _mono_as_float32_contig(mono_in)
    xoff, yoff, roworder = _detect_bayer_offsets_and_roworder(doc)
    # Match DebayerDialog: single flip to top-down when ROWORDER is bottom-up.
    if _roworder_is_bottom_up(roworder):
        mono = np.ascontiguousarray(np.flipud(mono))
    family = _detect_cfa_family(doc)
    want_method = str(preset.get("method", "auto"))

    # X-Trans → rawpy path
    if family == "XTRANS":
        src_path = (getattr(doc, "file_path", None) or getattr(doc, "path", None)
                    or (getattr(doc, "metadata", {}) or {}).get("file_path"))

        if not src_path or not str(src_path).lower().endswith(_RAW_EXTS):
            hdr, meta, _ = _extract_doc_info(doc)
            src_path = (meta.get("raw_source_path") or
                        (hdr.get("RAW_PATH") if hasattr(hdr, "get") else None) or
                        _find_raw_sibling(meta.get("file_path") or getattr(doc, "file_path", None)))
        if not src_path or not str(src_path).lower().endswith(_RAW_EXTS):
            raise RuntimeError("X-Trans detected, but no RAW found. "
                               "Embed RAW_PATH/raw_source_path or place the RAW next to the file.")
        alg = want_method if want_method in ("AHD", "DHT") else "AHD"
        rgb = _debayer_xtrans_via_rawpy(src_path, use_cam_wb=True, output_bps=16, alg=alg)
        _apply_result_to_doc(dm, doc, rgb, step_name=f"Debayer (X-Trans/{alg})")
        return "XTRANS", rgb

    # Bayer → Numba path
    want = str(preset.get("pattern", "auto")).upper()
    if want == "AUTO":
        pat = _normalize_bayer_token(_detect_bayer_from_header(doc) or "")
        if pat not in _VALID:
            pat = _autodetect_bayer_by_scoring(mono)
    else:
        pat = want
    if pat not in _VALID:
        raise ValueError(f"Unsupported Bayer pattern: {pat}")

    method_tok = (want_method.lower() if want_method.lower() in ("edge", "bilinear", "vng", "strict_cfa", "rcd", "ahd") else "rcd")

    if debayer_fits_fast is None:
        raise RuntimeError("Numba debayer kernels not available.")

    # Through debayer_array for the same reason as the dialog's worker: this
    # was a direct numba call, so Scripts / Presets / Replay never used the
    # card either. roworder="" because `mono` was already flipped above.
    rgb = debayer_array(mono, pattern=pat, roworder="", method=method_tok,
                        cfa_drizzle=False)
    # Flip back to match original orientation (see DebayerDialog._on_done).
    if _roworder_is_bottom_up(roworder):
        rgb = np.ascontiguousarray(np.flipud(rgb))
    _apply_result_to_doc(dm, doc, rgb, step_name=f"Debayer ({pat}/{method_tok})")
    return pat, rgb

# -------- headless command runner (Scripts / Presets / Replay) ---------------

def run_debayer_via_preset(main, preset: dict | None = None, *, doc=None):
    """
    Headless Debayer runner.

    preset keys:
      - pattern: "auto" | "RGGB" | "BGGR" | "GRBG" | "GBRG"
      - method:  "auto" | "rcd" | "ahd" | "vng" | "edge" | "bilinear"
                 | "strict_cfa" | "AHD" | "DHT"
                 (lowercase 'ahd' is the Numba Bayer AHD; uppercase 'AHD'
                 routes to rawpy for X-Trans only.)
    """
    p = dict(preset or {})

    # ---- Register for Replay Last Action ----
    try:
        remember = getattr(main, "remember_last_headless_command", None) \
                   or getattr(main, "_remember_last_headless_command", None)
        if callable(remember):
            remember("debayer", p, description="Debayer")
        else:
            setattr(main, "_last_headless_command", {
                "command_id": "debayer",
                "preset": dict(p),
            })
    except Exception:
        pass
    # ----------------------------------------

    dm = getattr(main, "doc_manager", None) or getattr(main, "dm", None)
    if dm is None:
        QMessageBox.warning(main, _tr("Debayer"), _tr("DocManager not available."))
        return

    if doc is None:
        d = getattr(main, "_active_doc", None)
        doc = d() if callable(d) else d

    if doc is None or getattr(doc, "image", None) is None:
        QMessageBox.warning(main, _tr("Debayer"), _tr("Load an image first."))
        return

    try:
        used_pat, _rgb = apply_debayer_preset_to_doc(dm, doc, p)
        if hasattr(main, "_log"):
            main._log(f"✅ Debayer (headless) pattern={used_pat}, preset={p}")
    except Exception as e:
        QMessageBox.critical(main, _tr("Debayer"), str(e))
        if hasattr(main, "_log"):
            main._log(f"❌ Debayer failed: {e}")