# src/setiastro/saspro/torch_rejection.py
from __future__ import annotations
import contextlib
import os
import threading
import numpy as np

# Reduce CUDA caching-allocator fragmentation so VRAM freed by the cosmetic
# pass can be reused by the satellite-removal CNN. Must be set before the first
# CUDA allocation — also set it in the launcher env in case Torch initialises
# CUDA from another module first.
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

# One device-wide lock shared by every GPU stage. Calibration cosmetic
# correction (GPU main loop) and satellite trail removal (save/consumer thread)
# run from different threads on the same card; serialising them keeps a single
# large working set resident at a time instead of summing both. Summing both is
# what OOMs a small card on Linux/CUDA, where — unlike Windows WDDM — GPU memory
# cannot page to host.
_GPU_LOCK = threading.RLock()

# Always route through our runtime shim so ALL GPU users share the same backend.
# Nothing heavy happens at import; we only resolve Torch when needed.
from .runtime_torch import import_torch, add_runtime_to_sys_path, best_device

# Algorithms supported by the GPU path here (names match your UI/CPU counterparts)
_SUPPORTED = {
    "Comet Median",
    "Simple Median (No Rejection)",
    "Comet High-Clip Percentile",
    "Comet Lower-Trim (30%)",
    "Comet Percentile (40th)",
    "Simple Average (No Rejection)",
    "Weighted Windsorized Sigma Clipping",
    "Windsorized Sigma Clipping",   # <<< NEW (unweighted)
    "Kappa-Sigma Clipping",
    "Trimmed Mean",
    "Extreme Studentized Deviate (ESD)",
    "Biweight Estimator",
    "Modified Z-Score Clipping",
    "Max Value",
}

# ---------------------------------------------------------------------------
# Lazy Torch resolution (so PyInstaller bootstrap and non-GPU users don’t break)
# ---------------------------------------------------------------------------
_TORCH = None
_DEVICE = None

import warnings

_DML_REDUCE_WARNED = False

def _is_directml_privateuse(dev) -> bool:
    """
    torch-directml uses a PrivateUse backend and the device string usually contains:
      'privateuseone:0'
    The reporter typo'd it as 'privateuserone:0' so we accept both.
    """
    try:
        s = str(dev).lower()
    except Exception:
        return False
    return ("privateuseone" in s) or ("privateuserone" in s)

def _warn_dml_reduce_once():
    global _DML_REDUCE_WARNED
    if _DML_REDUCE_WARNED:
        return
    _DML_REDUCE_WARNED = True
    warnings.warn(
        "DirectML detected (privateuseone). Forcing nan reducers (nanmedian/nanquantile/nanstd) to CPU "
        "to avoid a known torch-directml fallback bug (can return empty tensors).",
        RuntimeWarning
    )

def _cpu_reduce_then_back(torch, x, dim: int, op: str, q: float | None = None):
    """
    Force a reduction to run on CPU (workaround for DirectML broken fallbacks),
    then move the result back to x.device.
    """
    x_cpu = x.detach().to("cpu")

    if op == "nanmedian":
        y = torch.nanmedian(x_cpu, dim=dim).values
    elif op == "nanquantile":
        y = torch.nanquantile(x_cpu, float(q), dim=dim)
    elif op == "nanstd":
        y = torch.nanstd(x_cpu, dim=dim, unbiased=False)
    else:
        raise ValueError(f"Unknown op: {op}")

    return y.to(x.device)



def _get_torch(prefer_cuda: bool = True, prefer_dml: bool = False):
    global _TORCH, _DEVICE
    if _TORCH is not None:
        return _TORCH

    try:
        add_runtime_to_sys_path(lambda *_: None)
    except Exception:
        pass

    # Let runtime_torch install/resolve the right torch stack
    torch = import_torch(prefer_cuda=prefer_cuda, prefer_dml=prefer_dml, status_cb=lambda *_: None)

    # IMPORTANT: honor best_device() (it may return DirectML / privateuseone)
    try:
        _DEVICE = best_device(torch, prefer_cuda=prefer_cuda, prefer_dml=prefer_dml)
    except Exception:
        _DEVICE = None

    _TORCH = torch
    _force_fp32_policy(torch)

    # If best_device failed, fall back conservatively
    if _DEVICE is None:
        try:
            if hasattr(torch, "cuda") and torch.cuda.is_available():
                _DEVICE = torch.device("cuda")
            elif getattr(getattr(torch, "backends", None), "mps", None) and torch.backends.mps.is_available():
                _DEVICE = torch.device("mps")
            else:
                _DEVICE = torch.device("cpu")
        except Exception:
            _DEVICE = torch.device("cpu")

    return _TORCH



def _device():
    if _DEVICE is not None:
        return _DEVICE
    # Default to CPU if torch is not yet resolved; the first GPU call resolves it.
    return None

def torch_available() -> bool:
    """Return True iff we can import/resolve torch via the runtime shim."""
    try:
        _get_torch(prefer_cuda=True)
        return True
    except Exception:
        return False

def gpu_algo_supported(algo_name: str) -> bool:
    return algo_name in _SUPPORTED

# ---------------------------------------------------------------------------
# Helpers (nan-safe reducers) – assume torch is available *inside* callers
# ---------------------------------------------------------------------------
def _nanmedian(torch, x, dim: int):
    # DirectML workaround: force CPU reducer (avoids broken fallback returning empty tensor)
    if _is_directml_privateuse(getattr(x, "device", None)):
        _warn_dml_reduce_once()
        try:
            y = _cpu_reduce_then_back(torch, x, dim, op="nanmedian")
            if getattr(y, "numel", lambda: 1)() == 0:
                raise RuntimeError("nanmedian returned empty tensor on DirectML")
            return y
        except Exception:
            # fall through to generic fallback below
            pass

    try:
        y = torch.nanmedian(x, dim=dim).values
        # Guard: some broken backends return empty tensor instead of real result
        if getattr(y, "numel", lambda: 1)() == 0:
            raise RuntimeError("nanmedian returned empty tensor")
        return y
    except Exception:
        # Generic safe fallback (sort-based)
        m = torch.isfinite(x)
        x2 = x.clone()
        x2[~m] = float("inf")
        idx = x2.argsort(dim=dim)
        cnt = m.sum(dim=dim).clamp_min(1)
        mid = (cnt - 1) // 2
        gather_idx = idx.gather(dim, mid.unsqueeze(dim))
        return x.gather(dim, gather_idx).squeeze(dim)

def _nanstd(torch, x, dim: int):
    if _is_directml_privateuse(getattr(x, "device", None)):
        _warn_dml_reduce_once()
        try:
            y = _cpu_reduce_then_back(torch, x, dim, op="nanstd")
            if getattr(y, "numel", lambda: 1)() == 0:
                raise RuntimeError("nanstd returned empty tensor on DirectML")
            return y
        except Exception:
            pass

    try:
        y = torch.nanstd(x, dim=dim, unbiased=False)
        if getattr(y, "numel", lambda: 1)() == 0:
            raise RuntimeError("nanstd returned empty tensor")
        return y
    except Exception:
        # Fallback: compute nan-safe variance from sums
        m = torch.isfinite(x)
        cnt = m.sum(dim=dim).clamp_min(1)
        s1 = torch.where(m, x, torch.zeros_like(x)).sum(dim=dim)
        s2 = torch.where(m, x * x, torch.zeros_like(x)).sum(dim=dim)
        mean = s1 / cnt
        var = (s2 / cnt) - mean * mean
        return var.clamp_min(0).sqrt()

def _nanquantile(torch, x, q: float, dim: int):
    if _is_directml_privateuse(getattr(x, "device", None)):
        _warn_dml_reduce_once()
        try:
            y = _cpu_reduce_then_back(torch, x, dim, op="nanquantile", q=float(q))
            if getattr(y, "numel", lambda: 1)() == 0:
                raise RuntimeError("nanquantile returned empty tensor on DirectML")
            return y
        except Exception:
            pass

    try:
        y = torch.nanquantile(x, float(q), dim=dim)
        if getattr(y, "numel", lambda: 1)() == 0:
            raise RuntimeError("nanquantile returned empty tensor")
        return y
    except Exception:
        # Fallback: argsort finite values and take kth
        m = torch.isfinite(x)
        x2 = x.clone()
        x2[~m] = float("inf")
        idx = x2.argsort(dim=dim)
        n = m.sum(dim=dim).clamp_min(1)
        kth = (float(q) * (n - 1)).round().to(torch.long).clamp(min=0)
        gather_idx = idx.gather(dim, kth.unsqueeze(dim))
        return x.gather(dim, gather_idx).squeeze(dim)


def _no_amp_ctx(torch, dev):
    """
    Return a context that disables autocast on this thread for the current device.
    Works across torch 1.13–2.x and CUDA/CPU/MPS. No-ops if unsupported.
    """
    import contextlib
    # PyTorch 2.x unified API
    try:
        ac = getattr(torch, "autocast", None)
        if ac is not None:
            dt = "cuda" if getattr(dev, "type", "") == "cuda" else \
                 "mps"  if getattr(dev, "type", "") == "mps"  else "cpu"
            return ac(device_type=dt, enabled=False)
    except Exception:
        pass
    # Older CUDA AMP API
    try:
        amp = getattr(getattr(torch, "cuda", None), "amp", None)
        if amp and hasattr(amp, "autocast"):
            return amp.autocast(enabled=False)
    except Exception:
        pass
    return contextlib.nullcontext()


# --- add near the top (after imports) ---
def _safe_inference_ctx(torch):
    """
    Return a context manager for inference that won't explode on older or
    backend-variant Torch builds (DirectML/MPS/CPU-only).
    """
    try:
        # Prefer inference_mode if both the API and C++ backend support it
        if getattr(torch, "inference_mode", None) is not None:
            _C = getattr(torch, "_C", None)
            if _C is not None and hasattr(_C, "_InferenceMode"):
                return torch.inference_mode()
    except Exception:
        pass
    # Fallbacks
    if getattr(torch, "no_grad", None) is not None:
        return torch.no_grad()
    import contextlib
    return contextlib.nullcontext()

def _force_fp32_policy(torch):
    try:
        # default dtype for new tensors (does not upcast existing)
        torch.set_default_dtype(torch.float32)
    except Exception:
        pass
    # disable “helpful” lower-precision math
    try:
        if hasattr(torch.backends, "cudnn"):
            torch.backends.cudnn.allow_tf32 = False
        if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
            torch.backends.cuda.matmul.allow_tf32 = False
    except Exception:
        pass
    try:
        # prefer strict fp32 matmul kernels where supported
        if hasattr(torch, "set_float32_matmul_precision"):
            torch.set_float32_matmul_precision("highest")
    except Exception:
        pass

def _soft_outlier_weight(torch, z, threshold: float, mode: str = "quartic"):
    """
    Convert absolute z-score into a soft weight in [0,1].

    z:
      absolute standardized residuals
    threshold:
      values >= threshold get weight 0
    mode:
      "linear"  -> 1 - z/t
      "quartic" -> (1 - (z/t)^2)^2
    """
    t = max(float(threshold), 1e-12)
    u = (z / t).clamp_min(0.0)

    if mode == "linear":
        w = 1.0 - u
    else:
        # smoother falloff, less harsh near center
        w = (1.0 - u * u).clamp_min(0.0)
        w = w * w

    return torch.where(u < 1.0, w, torch.zeros_like(u))

# ---------------------------------------------------------------------------
# GPU Calibration Pipeline — dark sub, flat div, cosmetic correction
# All operate on tensors already on device to avoid round-trips
# ---------------------------------------------------------------------------

def _upload_calibration_frame(torch, dev, arr: np.ndarray):
    """Upload a numpy calibration frame (dark or flat) to GPU as float32 tensor.
    Handles 2D (mono), 3D CHW, and 3D HWC layouts — always returns (C, H, W)."""
    a = np.asarray(arr, dtype=np.float32)
    if a.ndim == 2:
        a = a[np.newaxis, :, :]          # (1, H, W)
    elif a.ndim == 3 and a.shape[-1] in (1, 3):
        a = a.transpose(2, 0, 1)          # HWC → CHW
    return torch.from_numpy(a).to(dev, dtype=torch.float32, non_blocking=True)


def calibration_pipeline_gpu(
    light_np: np.ndarray,
    dark_t,                          # (C,H,W) tensor on GPU or None
    flat_t,                          # (C,H,W) tensor on GPU or None
    pedestal: float = 0.0,
    hot_sigma: float = 3.0,
    cold_sigma: float = 3.0,
    apply_cosmetic: bool = True,
    bayer_pattern: str | None = None,
    protect_sigma: float = 5.0,
) -> np.ndarray:
    """
    Full per-frame calibration pipeline on GPU:
      1. dark subtraction (with pedestal offset)
      2. flat division
      3. cosmetic correction (two-pass)

    light_np: (H,W) mono or (H,W,C) HWC or (C,H,W) CHW float32
    Returns: same layout as input, float32
    """
    torch = _get_torch(prefer_cuda=True)
    dev   = _device() or (
        torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    )

    light_np = np.asarray(light_np, dtype=np.float32)

    # remember input layout so we can restore it on output
    was_2d  = (light_np.ndim == 2)
    was_hwc = (light_np.ndim == 3 and light_np.shape[-1] in (1, 3))

    # normalise to CHW for GPU ops
    if was_2d:
        t = torch.from_numpy(light_np[np.newaxis]).to(dev, non_blocking=True)  # (1,H,W)
    elif was_hwc:
        t = torch.from_numpy(
            light_np.transpose(2, 0, 1)
        ).to(dev, non_blocking=True)                                              # (C,H,W)
    else:
        t = torch.from_numpy(light_np).to(dev, non_blocking=True)               # (C,H,W)

    C, H, W = t.shape

    with _safe_inference_ctx(torch), _no_amp_ctx(torch, dev):

        # ── 1. dark subtraction ──────────────────────────────────────
        if dark_t is not None:
            d = dark_t
            if d.shape[0] == 1 and C > 1:
                d = d.expand(C, H, W)
            t = t - d
            if pedestal != 0.0:
                t = t + pedestal
            t = t.clamp(min=0.0)

        # ── 2. flat division ─────────────────────────────────────────
        if flat_t is not None:
            f = flat_t
            if f.shape[0] == 1 and C > 1:
                f = f.expand(C, H, W)
            # flat already normalised (median=1) by caller
            t = t / f.clamp(min=1e-6)

        # ── 3. cosmetic correction ───────────────────────────────────
        if apply_cosmetic:
            t = _cosmetic_correction_tensor(
                torch, dev, t,
                hot_sigma=hot_sigma,
                cold_sigma=cold_sigma,
                bayer_pattern=bayer_pattern,
                protect_sigma=protect_sigma,
            )

    # ── back to CPU, restore original layout ─────────────────────────
    out = t.cpu().numpy()               # (C, H, W)
    if was_2d:
        return out[0]                   # (H, W)
    elif was_hwc:
        return out.transpose(1, 2, 0)  # (H, W, C)
    return out                          # (C, H, W)


# Module-level buffer cache — keyed by (device_str, H, W)
_CC_BUFFERS: dict = {}

def _clear_cc_buffers():
    """No-op — retained for callers from the persistent-buffer era.
    The tiled cosmetic pass allocates scratch locally and frees it by
    refcount per frame, so there is nothing to clear."""
    pass

def _cosmetic_correction_tensor(torch, dev, t, hot_sigma, cold_sigma,
                                bayer_pattern=None, protect_sigma=5.0):
    """
    Two-pass cosmetic correction on a (C,H,W) tensor already on device.
    Detection is whole-frame; the neighbour-median sort is tiled over row
    strips so peak VRAM tracks strip size, not frame size (a 61 MP frame
    otherwise needs ~15-20 GB of transient scratch for the sort alone).
    Stride = 2 for Bayer (same-colour neighbours), 1 otherwise.
    """
    import torch.nn.functional as F
    from setiastro.saspro.cosmetic_metal import median5_along_dim0, sort8_along_dim0

    s = 2 if bayer_pattern else 1
    pad_amt = s
    C, H, W = t.shape
    result = torch.empty_like(t)

    _stride = max(1, min(H, W) // 100)   # 1% sample for background stats

    # ── pick a row-strip height that bounds the sort scratch ──────────
    # the strip's neighbour trio dominates: stacked(f32) + sorted(f32) +
    # a transient int64 sort index = 8*(4+4+8) = 128 B/px; add slack for
    # the int64 gather temporaries → budget at ~200 B/px.
    bytes_per_row = W * 200
    if dev.type == "cuda":
        free_b, _tot = torch.cuda.mem_get_info()
        budget = min(int(free_b * 0.4), 2 * 1024**3)
    else:
        budget = 768 * 1024**2
    strip_h = int(max(64, min(H, budget // max(bytes_per_row, 1))))

    # strip-sized neighbour buffers, reused across strips (last strip
    # slices a [:sh] view). NOTE: no int64 sort_idx buffer — torch.sort's
    # index is taken functionally and freed immediately each strip.
    stacked  = torch.empty((8, strip_h, W), device=dev, dtype=torch.float32)
    sorted_s = torch.empty((8, strip_h, W), device=dev, dtype=torch.float32)

    offsets = [
        (-s, -s), (-s,  0), (-s, +s),
        ( 0, -s),           ( 0, +s),
        (+s, -s), (+s,  0), (+s, +s),
    ]

    for ci in range(C):
        plane = t[ci]

        # ── background stats (strided sample) ─────────────────────────
        sample     = plane[::_stride, ::_stride]
        # background stats on the strided sample, on the HOST: it's ~1e-4 of
        # the frame and this avoids torch.median (slow / CPU-fallback on MPS).
        _s        = sample.reshape(-1).to('cpu', dtype=torch.float32).numpy()
        med_f     = float(np.median(_s))
        _absdev   = np.abs(_s - med_f)
        avg_dev_f = float(_absdev.mean())
        robust_sig= max(1.4826 * float(np.median(_absdev)), 1e-8)
        del _s, _absdev
        del sample

        # ── reflect-pad the plane once (whole frame) ──────────────────
        p = F.pad(plane.unsqueeze(0).unsqueeze(0),
                  (pad_amt, pad_amt, pad_amt, pad_amt),
                  mode="reflect").squeeze(0).squeeze(0)          # (H+2s, W+2s)

        # ── m5: cross-median of {N,S,E,W,center} (whole frame) ────────
        five = torch.stack((
            p[0:H,                   pad_amt:W+pad_amt],          # N
            p[2*pad_amt:H+2*pad_amt, pad_amt:W+pad_amt],          # S
            p[pad_amt:H+pad_amt,     0:W],                        # W
            p[pad_amt:H+pad_amt,     2*pad_amt:W+2*pad_amt],      # E
            plane,                                                # center
        ), dim=0)
        m5 = median5_along_dim0(five, torch)  # 5-elt median, min/max only
        del five

        # ── detection + structure gate (whole frame) ──────────────────
        scale_f     = max(avg_dev_f * float(hot_sigma), avg_dev_f)
        hot_thresh  = m5 + scale_f
        cold_thresh = m5 - avg_dev_f * float(cold_sigma)

        hot_candidates = plane > hot_thresh
        cold_map       = plane < cold_thresh
        # protect resolved signal: a lone hot pixel can't move m5, a star
        # core can. m5 is stride-s so this stays same-colour for Bayer.
        protect_thr = med_f + float(protect_sigma) * robust_sig
        structure   = m5 > protect_thr
        flagged     = (hot_candidates & (~structure)) | cold_map
        del hot_candidates, cold_map, structure, hot_thresh, cold_thresh

        # padded flagged mask for neighbour lookups (whole frame)
        fp = F.pad(flagged.float().unsqueeze(0).unsqueeze(0),
                   (pad_amt, pad_amt, pad_amt, pad_amt),
                   mode="reflect").squeeze(0).squeeze(0)

        # ── replacement, tiled over row strips ────────────────────────
        for y0 in range(0, H, strip_h):
            y1 = min(H, y0 + strip_h)
            sh = y1 - y0
            st = stacked[:, :sh]          # views (contiguous last strip is short)
            so = sorted_s[:, :sh]

            p_strip  = p[y0 : y1 + 2 * pad_amt]     # (sh+2s, W+2s)
            fp_strip = fp[y0 : y1 + 2 * pad_amt]

            for i, (dy, dx) in enumerate(offsets):
                r0, c0 = dy + pad_amt, dx + pad_amt
                nbr_vals    = p_strip[r0:r0 + sh, c0:c0 + W]
                nbr_flagged = fp_strip[r0:r0 + sh, c0:c0 + W] > 0.5
                torch.where(nbr_flagged,
                            nbr_vals.new_full((), float("inf")),
                            nbr_vals, out=st[i])

            # flagged neighbours are +inf and sort to the top; index is
            # transient and freed here (strip-sized, not frame-sized)
            so.copy_(st)
            sort8_along_dim0(so, torch)   # 8-elt sort, min/max only (no torch.sort)

            raw_count = (st < float("inf")).sum(dim=0)   # clean neighbours
            vc        = raw_count.clamp(min=1)
            mid_lo    = ((vc - 1) // 2).unsqueeze(0)
            mid_hi    = (vc // 2).unsqueeze(0)
            rep = 0.5 * (so.gather(0, mid_lo).squeeze(0) +
                         so.gather(0, mid_hi).squeeze(0))
            # all 8 neighbours flagged → fall back to the cross median
            rep = torch.where(raw_count == 0, m5[y0:y1], rep)

            torch.where(flagged[y0:y1], rep, plane[y0:y1], out=result[ci][y0:y1])

        del p, fp, m5, flagged

    return result

def prepare_calibration_frame(
    arr: np.ndarray,
    frame_type: str,          # "dark" or "flat"
    normalize_flat: bool = True,
) -> np.ndarray:
    """
    Prepare a master dark or flat for upload:
    - ensures float32
    - for flat: normalises each channel to median=1, guards zeros
    Returns (C, H, W) float32 numpy array ready for _upload_calibration_frame.
    """
    a = np.asarray(arr, dtype=np.float32)

    # normalise layout to CHW
    if a.ndim == 2:
        a = a[np.newaxis]
    elif a.ndim == 3 and a.shape[-1] in (1, 3):
        a = a.transpose(2, 0, 1)

    if frame_type == "flat" and normalize_flat:
        for ci in range(a.shape[0]):
            band  = a[ci]
            v     = band[np.isfinite(band) & (band > 0)]
            denom = float(np.median(v)) if v.size else 1.0
            denom = denom if (np.isfinite(denom) and denom > 0) else 1.0
            a[ci] = band / denom
        a = np.nan_to_num(a, nan=1.0, posinf=1.0, neginf=1.0)
        a[a == 0] = 1.0

    return a

# ---------------------------------------------------------------------------
# GPU Cosmetic Correction
# ---------------------------------------------------------------------------
def cosmetic_correction_gpu(
    image: np.ndarray,
    hot_sigma: float = 3.0,
    cold_sigma: float = 3.0,
    bayer_pattern: str | None = None,
    protect_sigma: float = 5.0,
) -> np.ndarray:
    """
    Two-pass cosmetic correction on GPU.
    bayer_pattern: if set (e.g. "RGGB"), uses stride-2 neighbors so only
                   same-color CFA pixels are compared. Otherwise uses stride-1
                   for debayered/mono images.
    """
    torch = _get_torch(prefer_cuda=True)
    dev = _device() or (torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu"))

    img = np.asarray(image, dtype=np.float32)
    was_gray = (img.ndim == 2)
    if was_gray:
        img = img[:, :, None]

    H, W, C = img.shape
    t = torch.from_numpy(img.transpose(2, 0, 1)).to(dev, dtype=torch.float32)
    result = torch.empty_like(t)

    # stride-2 for Bayer (same-color neighbors), stride-1 for mono/debayered
    s = 2 if bayer_pattern else 1

    with _safe_inference_ctx(torch), _no_amp_ctx(torch, dev):
        for ci in range(C):
            plane = t[ci]  # (H, W)

            med_val = plane.median()
            avg_dev = (plane - med_val).abs().mean()
            # robust background sigma for the structure gate (sampled — a
            # full MAD on 40M+ px is wasteful; 1% is plenty for a threshold)
            _gs = max(1, min(H, W) // 100)
            robust_sigma = torch.clamp(
                1.4826 * (plane[::_gs, ::_gs] - med_val).abs().median(),
                min=1e-8,
            )

            # pad by stride amount so border pixels are handled cleanly
            p = torch.nn.functional.pad(
                plane.unsqueeze(0).unsqueeze(0),
                (s, s, s, s), mode='reflect'
            ).squeeze(0).squeeze(0)
            # p: (H+2s, W+2s)

            north  = p[0:H,       s:W+s  ]
            south  = p[2*s:H+2*s, s:W+s  ]
            west   = p[s:H+s,     0:W    ]
            east   = p[s:H+s,     2*s:W+2*s]
            center = plane

            five = torch.stack([north, south, west, east, center], dim=0)
            m5 = five.median(dim=0).values

            scale       = torch.clamp(avg_dev * hot_sigma, min=float(avg_dev))
            hot_thresh  = m5 + scale
            cold_thresh = m5 - avg_dev * cold_sigma

            hot_candidates = plane > hot_thresh
            cold_map       = plane < cold_thresh

            # ── structure gate: protect resolved signal (stars / nebula) ──
            # A hot pixel is a lone spike and cannot move a local median; a
            # star or nebula core has spatial extent, so its local median is
            # genuinely elevated. Gate the hot pass on m5 (the 5-px cross
            # median, already robust to an isolated hot centre) vs a global
            # robust background: patches whose median clears protect_sigma
            # sigmas above background are real signal and are left untouched.
            # NB: m5 uses stride-s neighbours, so this stays same-colour for
            # Bayer automatically — unlike the old stride-1 3x3 mean, which
            # averaged across CFA colours.
            protect_thr = med_val + float(protect_sigma) * robust_sigma
            structure   = m5 > protect_thr
            hot_map     = hot_candidates & (~structure)

            flagged = hot_map | cold_map

            # --- START OPTIMIZED SPARSE PROCESSING ---
            # 1. Find the 1D coordinates of the bad pixels
            fy, fx = torch.where(flagged)
            
            # Default state is the original uncorrected plane
            result[ci] = plane.clone()

            # Only do the heavy math if we actually found bad pixels
            if len(fy) > 0:
                # 8 neighbors at stride s
                offsets = [
                    (-s, -s), (-s,  0), (-s, +s),
                    ( 0, -s),           ( 0, +s),
                    (+s, -s), (+s,  0), (+s, +s),
                ]

                flagged_pad = torch.nn.functional.pad(
                    flagged.float().unsqueeze(0).unsqueeze(0),
                    (s, s, s, s), mode='reflect'
                ).squeeze().bool()

                plane_pad2 = torch.nn.functional.pad(
                    plane.unsqueeze(0).unsqueeze(0),
                    (s, s, s, s), mode='reflect'
                ).squeeze()

                # Shift coordinates into the padded array space
                fy_pad = fy + s
                fx_pad = fx + s

                neighbor_stack = []
                for dy, dx in offsets:
                    # Gather ONLY the neighbors for the flagged pixels (returns a 1D tensor of size N)
                    nbr_vals = plane_pad2[fy_pad + dy, fx_pad + dx]
                    nbr_flagged = flagged_pad[fy_pad + dy, fx_pad + dx]
                    
                    nbr_clean = torch.where(
                        nbr_flagged,
                        torch.full_like(nbr_vals, float('nan')),
                        nbr_vals
                    )
                    neighbor_stack.append(nbr_clean)

                # Stack is now (8, N) instead of (8, H, W). Massive memory savings.
                stacked = torch.stack(neighbor_stack, dim=0)
                
                stacked_inf = torch.where(torch.isnan(stacked),
                                          torch.full_like(stacked, float('inf')), stacked)
                sorted_s, _ = stacked_inf.sort(dim=0)

                valid_count = (~torch.isnan(stacked)).sum(dim=0).clamp(min=1)
                mid_lo = ((valid_count - 1) // 2).long()
                mid_hi = (valid_count       // 2).long()

                rep_lo      = sorted_s.gather(0, mid_lo.unsqueeze(0)).squeeze(0)
                rep_hi      = sorted_s.gather(0, mid_hi.unsqueeze(0)).squeeze(0)
                replacement = (rep_lo + rep_hi) * 0.5
                
                # If all 8 neighbors were bad (inf), fall back to the local median m5
                m5_bad = m5[fy, fx]
                replacement = torch.where(torch.isinf(replacement), m5_bad, replacement)

                # Patch only the bad pixels in the result
                result[ci][fy, fx] = replacement
            # --- END OPTIMIZED SPARSE PROCESSING ---

    out = result.cpu().numpy().transpose(1, 2, 0)
    if was_gray:
        return out[:, :, 0]
    return out

# ---------------------------------------------------------------------------
# Robust reduction helpers (shared by the rejection branches below)
# ---------------------------------------------------------------------------
def _masked_sum(torch, x, mask, dim: int):
    """Sum of x over `mask`. NaN-safe: masked-out lanes are replaced by 0
    *before* any arithmetic, so NaN/Inf in invalid lanes can never poison
    the result (NaN * 0 == NaN, which the old `ts.mul(w_eff)` pattern hit)."""
    return torch.where(mask, x, torch.zeros_like(x)).sum(dim=dim)


def _mad_sigma(torch, x_nan, med, dim: int):
    """Robust per-pixel scale: 1.4826 * MAD (consistent with Gaussian sigma).
    Unlike a plain standard deviation, this is immune to satellite trails /
    plane trails / cosmic rays inflating the scale estimate."""
    mad = _nanmedian(torch, (x_nan - med.unsqueeze(dim)).abs(), dim=dim)
    return (1.4826 * mad).clamp_min(1e-10)


def _winsorized_center_scale(torch, ts, valid, iterations: int = 3, winsor_k: float = 1.5):
    """
    Huber-style Winsorized estimate of per-pixel center and scale — the same
    scheme PixInsight and APP use for 'Winsorized Sigma Clipping'.

    Why: measuring sigma on the raw stack lets a bright outlier inflate sigma
    so much that it can never be clipped (a single outlier among N frames is
    bounded at z = sqrt(N), so with N=8 and kappa=3 a trail is mathematically
    un-rejectable). Instead we:
      1. seed with median and 1.4826*MAD (both robust),
      2. clamp ('winsorize') the stack to med +/- winsor_k * sigma,
      3. re-measure median and std on the winsorized stack, undoing the
         winsorization-induced shrinkage with Huber's 1.134 correction
         (exact for winsor_k = 1.5),
      4. iterate to convergence.
    Sigma therefore converges to the sigma of the *uncontaminated* pixel
    distribution, and the subsequent sigma_low/sigma_high rejection pass
    behaves like APP/PI at the same settings.
    """
    x = ts.masked_fill(~valid, float("nan"))
    med = _nanmedian(torch, x, dim=0)
    sigma = _mad_sigma(torch, x, med, dim=0)
    cnt = valid.sum(dim=0).clamp_min(1).to(ts.dtype)
    for _ in range(max(1, int(iterations))):
        lo = (med - winsor_k * sigma).unsqueeze(0)
        hi = (med + winsor_k * sigma).unsqueeze(0)
        # torch.minimum/maximum propagate NaN, so invalid lanes stay NaN
        xw = torch.minimum(torch.maximum(x, lo), hi)
        med = _nanmedian(torch, xw, dim=0)
        mean_w = _masked_sum(torch, xw, valid, dim=0) / cnt
        var = _masked_sum(torch, (xw - mean_w.unsqueeze(0)) ** 2, valid, dim=0) / cnt
        sigma = (1.134 * var.clamp_min(0.0).sqrt()).clamp_min(1e-10)
    return med, sigma


def _weighted_mean_or(torch, ts, keep, w, fallback):
    """Weighted mean of `ts` over `keep`; `fallback` where nothing survives.
    NaN-safe: rejected/invalid lanes never enter the arithmetic."""
    w_eff = w * keep.to(ts.dtype)
    num = (torch.where(keep, ts, torch.zeros_like(ts)) * w_eff).sum(dim=0)
    den = w_eff.sum(dim=0)
    return torch.where(den > 1e-20, num / den.clamp_min(1e-20), fallback)


# ---------------------------------------------------------------------------
# Public GPU reducer – lazy-loads Torch, never decorates at import time
# ---------------------------------------------------------------------------
def _finalize(torch, out, rej, reduce_rej_maps):
    """Move a reducer result to the host.

    Default (reduce_rej_maps=False): return (out_np, full_rej_np) exactly as
    before — the full (F,H,W,C) or (F,H,W) boolean rejection map.

    reduce_rej_maps=True: collapse the rejection map ON THE GPU to the only two
    things the integrator actually accumulates — a per-pixel "any frame
    rejected" mask and a per-pixel rejected-frame count — and copy back just
    those two (H,W) arrays. That turns the per-band device->host transfer from
    N*H*W*C bytes down to ~2*H*W, and moves the any()/sum() reduction off the
    CPU's critical path. Use it whenever per-file rejection maps are NOT being
    collected (the common case)."""
    out_np = out.to(dtype=torch.float32).contiguous().cpu().numpy()
    if not reduce_rej_maps:
        return out_np, rej.cpu().numpy()
    # collapse channels, then reduce over the frame axis, all on-device
    rej_fhw = rej.any(dim=-1) if rej.dim() == 4 else rej          # (F,H,W)
    rej_any = rej_fhw.any(dim=0).cpu().numpy()                    # (H,W) bool
    rej_cnt = rej_fhw.sum(dim=0).to(torch.int32).cpu().numpy()    # (H,W) int32
    return out_np, (rej_any, rej_cnt)


DEBUG_INTEGRATION_ONLY = False   # <-- set True: reducer returns a ZEROED rejection map (out left untouched)


def torch_reduce_tile(*args, **kwargs):
    """Public entry point for the tile reducer.

    When DEBUG_INTEGRATION_ONLY is True, the integrated tile is returned exactly
    as computed, but the rejection map is replaced with an all-False array of the
    same shape. This severs every downstream use of the per-tile rejection data
    (accumulation, compositing, MEF layers) so we can tell whether the trail
    contamination rides the rejection array (trails vanish) or is already baked
    into the integrated result itself (trails persist)."""
    out, rej = _torch_reduce_tile_impl(*args, **kwargs)
    if DEBUG_INTEGRATION_ONLY:
        import numpy as _np
        # Leave the GPU self-test (_rejection_gpu_ok) alone: it feeds a tiny
        # 5x1x1x1 probe and asserts the outlier IS rejected. If we zero that
        # map the self-test 'fails' and integration silently drops to CPU.
        # Only neuter the rejection map for real integration tiles (spatial
        # area > 1); the 1x1 probe keeps its true map so GPU stays selected.
        _ts0 = args[0] if args else kwargs.get("ts_np")
        _is_selftest = False
        try:
            _shp = _np.asarray(_ts0).shape
            if len(_shp) >= 3 and int(_shp[1]) * int(_shp[2]) <= 1:
                _is_selftest = True
        except Exception:
            _is_selftest = False
        if not _is_selftest:
            if isinstance(rej, tuple):
                _ra, _rc = rej
                rej = (_np.zeros_like(_ra, dtype=bool), _np.zeros_like(_rc))
            else:
                rej = _np.zeros_like(_np.asarray(rej), dtype=bool)
    return out, rej


def _torch_reduce_tile_impl(
    ts_np: np.ndarray,
    weights_np: np.ndarray,
    *,
    algo_name: str,
    kappa: float = 2.5,
    iterations: int = 3,
    sigma_low: float = 2.5,
    sigma_high: float = 2.5,
    trim_fraction: float = 0.1,
    esd_threshold: float = 3.0,
    biweight_constant: float = 6.0,
    modz_threshold: float = 3.5,
    comet_hclip_k: float = 1.30,
    comet_hclip_p: float = 25.0,
    ignore_zero_pixels: bool = True,
    forced_reject_mask_np: np.ndarray | None = None,
    reduce_rej_maps: bool = False,
) -> tuple[np.ndarray, np.ndarray]:

    torch = _get_torch(prefer_cuda=True)
    dev = _device() or (torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu"))

    ts_np = np.asarray(ts_np, dtype=np.float32)
    if ts_np.ndim == 3:
        ts_np = ts_np[..., None]
    F, H, W, C = ts_np.shape

    if H == 0 or W == 0 or C < 1:
        raise ValueError(
            f"torch_reduce_tile received degenerate tile shape={ts_np.shape}. "
            "This usually means a bad edge tile or corrupted frame; "
            "try disabling GPU rejection or reducing chunk size."
        )

    # ── multi-channel: process each plane separately then recombine ──────
    # Avoids the 9x tile/memory overhead of the 4D (F,H,W,3) path — each
    # channel is reduced independently as (F,H,W,1) and stacked at the end.
    #if C > 1:
    #    results  = []
    #    rej_maps = []
    #    for ci in range(C):
    #        r, rj = torch_reduce_tile(
    #            ts_np[:, :, :, ci:ci+1],   # (F, H, W, 1) — zero-copy slice
    #            weights_np,
    #            algo_name=algo_name,
    #            kappa=kappa,
    #            iterations=iterations,
    #            sigma_low=sigma_low,
    #            sigma_high=sigma_high,
    #            trim_fraction=trim_fraction,
    #            esd_threshold=esd_threshold,
    #            biweight_constant=biweight_constant,
    #            modz_threshold=modz_threshold,
    #            comet_hclip_k=comet_hclip_k,
    #            comet_hclip_p=comet_hclip_p,
    #            ignore_zero_pixels=ignore_zero_pixels,
    ##            forced_reject_mask_np=(
    #                forced_reject_mask_np[:, :, :, ci:ci+1]
    #                if forced_reject_mask_np is not None
    #                and forced_reject_mask_np.ndim == 4
    #                else forced_reject_mask_np
    #            ),
    #        )
    #        results.append(r)    # (H, W, 1)
    #        rej_maps.append(rj)  # (F, H, W, 1)

    #    return (
    #        np.concatenate(results,  axis=-1),   # (H, W, C)
    #        np.concatenate(rej_maps, axis=-1),   # (F, H, W, C)
    #    )
    if C < 1:
        raise ValueError(f"torch_reduce_tile received input with C={C} channels (shape={ts_np.shape}). Expected C >= 1.")

    ts = torch.from_numpy(ts_np).to(dev, dtype=torch.float32, non_blocking=True)

    weights_np = np.asarray(weights_np, dtype=np.float32)
    if weights_np.ndim == 0:
        weights_np = np.full((F,), float(weights_np), dtype=np.float32)

    if weights_np.ndim == 1:
        if weights_np.shape[0] != F:
            raise ValueError(f"weights shape {weights_np.shape} does not match F={F}")
        w_np = weights_np.reshape(F, 1, 1, 1)

    elif weights_np.ndim == 2:
        if weights_np.shape == (F, C):
            w_np = weights_np.reshape(F, 1, 1, C)
        else:
            raise ValueError(
                f"Unsupported 2D weights shape {weights_np.shape}. "
                f"Expected (F,C)=({F},{C}) for per-channel weights."
            )

    elif weights_np.ndim == 3:
        if weights_np.shape == (F, H, W):
            w_np = weights_np[..., None]
        else:
            raise ValueError(
                f"Unsupported 3D weights shape {weights_np.shape}. Expected (F,H,W)=({F},{H},{W})."
            )

    elif weights_np.ndim == 4:
        if weights_np.shape == (F, H, W, 1) or weights_np.shape == (F, H, W, C):
            w_np = weights_np
        else:
            raise ValueError(
                f"Unsupported 4D weights shape {weights_np.shape}. "
                f"Expected (F,H,W,1) or (F,H,W,C)=({F},{H},{W},{C})."
            )
    else:
        raise ValueError(f"Unsupported weights ndim={weights_np.ndim} shape={weights_np.shape}")

    w = torch.from_numpy(w_np).to(dev, dtype=torch.float32, non_blocking=False)

    # ---------- NEW: normalize optional forced reject mask ----------
    forced_reject = None
    if forced_reject_mask_np is not None:
        frm = np.asarray(forced_reject_mask_np, dtype=bool)

        if frm.ndim == 2:
            if frm.shape != (H, W):
                raise ValueError(
                    f"forced_reject_mask_np shape {frm.shape} does not match tile (H,W)=({H},{W})"
                )
            frm = frm[None, :, :, None]

        elif frm.ndim == 3:
            if frm.shape != (F, H, W):
                raise ValueError(
                    f"forced_reject_mask_np shape {frm.shape} does not match (F,H,W)=({F},{H},{W})"
                )
            frm = frm[:, :, :, None]

        elif frm.ndim == 4:
            if frm.shape not in ((F, H, W, 1), (F, H, W, C)):
                raise ValueError(
                    f"forced_reject_mask_np shape {frm.shape} does not match "
                    f"(F,H,W,1) or (F,H,W,C)=({F},{H},{W},{C})"
                )
        else:
            raise ValueError(
                f"Unsupported forced_reject_mask_np ndim={frm.ndim} shape={frm.shape}"
            )

        # Upload the mask at its own size: `valid & ~forced_reject` below
        # broadcasts it on the device. Broadcasting on the host first cost
        # F*H*W*C bytes per tile (186 MiB at 3766 frames x 16 x 1080 x 3).
        forced_reject = torch.from_numpy(np.ascontiguousarray(frm)).to(dev, dtype=torch.bool, non_blocking=False)

    algo = algo_name

    # ---------- central validity mask ----------
    valid = torch.isfinite(ts)
    if ignore_zero_pixels:
        valid = valid & (ts != 0.0)
    if forced_reject is not None:
        valid = valid & (~forced_reject)

    # Base forced rejection bookkeeping
    forced_rej_map = (~valid)

    with _safe_inference_ctx(torch), _no_amp_ctx(torch, dev):
        if algo in ("Comet Median", "Simple Median (No Rejection)"):
            x = ts.masked_fill(~valid, float("nan"))
            out = _nanmedian(torch, x, dim=0)
            rej = forced_rej_map
            return _finalize(torch, out, rej, reduce_rej_maps)

        if algo == "Comet Percentile (40th)":
            x = ts.masked_fill(~valid, float("nan"))
            out = _nanquantile(torch, x, 0.40, dim=0)
            rej = forced_rej_map
            return _finalize(torch, out, rej, reduce_rej_maps)

        if algo_name == "Windsorized Sigma Clipping":
            # True Winsorized sigma clipping (APP/PI-parity):
            # robust winsorized center/scale, one rejection pass, then average
            # of the SURVIVORS only (rejected pixels are excluded, not
            # median-substituted, so a partly-rejected trail can't leak back).
            med, sigma = _winsorized_center_scale(torch, ts, valid, iterations=int(iterations))
            lo = (med - float(sigma_low) * sigma).unsqueeze(0)
            hi = (med + float(sigma_high) * sigma).unsqueeze(0)
            keep = valid & (ts >= lo) & (ts <= hi)

            ones_w = torch.ones((F, 1, 1, 1), device=dev, dtype=ts.dtype)
            fallback = torch.nan_to_num(med, nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, ones_w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps)


        if algo == "Comet Lower-Trim (30%)":
            x = ts.masked_fill(~valid, float("inf"))
            vals, idx = x.sort(dim=0, stable=True)

            n = valid.sum(dim=0)
            k_keep = torch.floor(n.to(torch.float32) * (1.0 - 0.30)).to(torch.long)
            k_keep = k_keep.clamp(min=1)

            arangeF = torch.arange(F, device=dev).view(F, 1, 1, 1).expand_as(vals)
            keep_sorted = arangeF < k_keep.unsqueeze(0).expand_as(vals)
            keep_sorted = keep_sorted & torch.isfinite(vals)

            den = keep_sorted.sum(dim=0)
            num = torch.where(keep_sorted, vals, torch.zeros_like(vals)).sum(dim=0)

            fallback = _nanmedian(torch, ts.masked_fill(~valid, float("nan")), dim=0)
            out = torch.where(den > 0, num / den.clamp_min(1).to(vals.dtype), fallback)

            keep_orig = torch.zeros_like(keep_sorted)
            keep_orig.scatter_(0, idx, keep_sorted)
            rej = ~keep_orig
            return _finalize(torch, out, rej, reduce_rej_maps)

        if algo == "Comet High-Clip Percentile":
            x = ts.masked_fill(~valid, float("nan"))
            med = _nanmedian(torch, x, dim=0)
            mad = _nanmedian(torch, (x - med.unsqueeze(0)).abs(), dim=0) + 1e-6
            hi = med + (float(comet_hclip_k) * 1.4826 * mad)
            clipped = torch.where(valid, torch.minimum(ts, hi.unsqueeze(0)), torch.full_like(ts, float("nan")))
            out = _nanquantile(torch, clipped, float(comet_hclip_p) / 100.0, dim=0)
            rej = forced_rej_map
            return _finalize(torch, out, rej, reduce_rej_maps)

        if algo == "Simple Average (No Rejection)":
            w_eff = torch.where(valid, w, torch.zeros_like(w))
            ts_eff = torch.where(valid, ts, torch.zeros_like(ts))
            den = w_eff.sum(dim=0)
            num = (ts_eff * w_eff).sum(dim=0)

            x = ts.masked_fill(~valid, float("nan"))
            fallback = _nanmedian(torch, x, dim=0)
            out = torch.where(den > 0, num / den.clamp_min(1e-20), fallback)

            rej = forced_rej_map
            return _finalize(torch, out, rej, reduce_rej_maps)

        if algo == "Max Value":
            x = ts.masked_fill(~valid, float("-inf"))
            out = x.max(dim=0).values
            out = torch.where(torch.isfinite(out), out, torch.zeros_like(out))
            rej = forced_rej_map
            return _finalize(torch, out, rej, reduce_rej_maps)


        if algo == "Weighted Windsorized Sigma Clipping":
            # True Winsorized sigma clipping (APP/PI-parity), weighted average.
            # See _winsorized_center_scale for why sigma must be measured on
            # the winsorized stack: the old code measured std on raw data, so
            # a satellite trail inflated sigma and was never rejected.
            med, sigma = _winsorized_center_scale(torch, ts, valid, iterations=int(iterations))
            lo = (med - float(sigma_low) * sigma).unsqueeze(0)
            hi = (med + float(sigma_high) * sigma).unsqueeze(0)
            keep = valid & (ts >= lo) & (ts <= hi)

            fallback = torch.nan_to_num(med, nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps)

        if algo == "Extreme Studentized Deviate (ESD)":
            # Generalized ESD (Rosner) done properly, vectorized per pixel.
            #
            # The old implementation was an iterative z-clip whose std was
            # measured on data still containing the outliers ("masking"):
            # one strong outlier among N frames is bounded at z = sqrt(N),
            # so with few frames it could never exceed the threshold.
            #
            # Rosner's procedure defeats masking by construction:
            #   for j = 1..max_out:
            #     find the single most extreme remaining value,
            #     test it against the mean/std of the remaining sample
            #     WITH THAT VALUE EXCLUDED (external studentization),
            #     record pass/fail, remove it, continue (no early stop).
            #   The number of outliers is the LARGEST j whose test passed;
            #   the outliers are exactly the first j values removed.
            #
            # External studentization matters: the internally studentized
            # deviate is capped at (n-1)/sqrt(n) (~2.47 for n=8), so a fixed
            # user threshold of 3.0 was unreachable on small stacks. Testing
            # against the leave-one-out sample removes the cap and makes the
            # threshold mean "sigmas above the clean data", which is what
            # users expect the setting to do.
            thr = float(esd_threshold)
            # Rosner needs an upper bound on the outlier count; test up to
            # half the stack (and leave at least 2 frames untested).
            max_out = int(max(1, min(F - 2, round(0.5 * F))))

            # Per-step critical values. A FIXED cutoff cascades on clean
            # stacks: each removal shrinks the remaining std, inflating the
            # next R, so later steps pass spuriously. Rosner's remedy is an
            # n-dependent critical value. The externally studentized deviate
            # is t-distributed with df = n - 2, so we map the user's z-style
            # threshold to its two-sided normal tail probability and take the
            # matching t quantile at each step's df. For large stacks
            # t -> normal, so 'threshold' keeps its literal 'sigmas' meaning;
            # for small stacks the cutoff inflates automatically, which is
            # exactly what controls the false-rejection cascade.
            crit_by_n = np.full(F + 1, float("inf"), dtype=np.float32)
            try:
                from scipy import stats as _sstats
                p_two = float(_sstats.norm.sf(thr))          # one-sided tail
                for nn in range(3, F + 1):
                    crit_by_n[nn] = float(_sstats.t.ppf(1.0 - p_two, nn - 2))
            except Exception:
                # scipy-free fallback: inflate by the t-distribution's std,
                # sqrt(df / (df - 2)), a good first-order approximation.
                for nn in range(3, F + 1):
                    df = nn - 2
                    infl = (df / (df - 2.0)) ** 0.5 if df > 2 else 3.0
                    crit_by_n[nn] = thr * infl
            crit_t = torch.from_numpy(crit_by_n).to(dev)

            active = valid.clone()
            removed_step = torch.full((F, H, W, C), -1, dtype=torch.int32, device=dev)
            passed = torch.zeros((max_out, H, W, C), dtype=torch.bool, device=dev)
            neg = torch.full_like(ts, float("-inf"))

            for j in range(max_out):
                n = active.sum(dim=0).to(ts.dtype)
                can = n >= 3.0  # need >= 2 samples left after leave-one-out
                mean = _masked_sum(torch, ts, active, dim=0) / n.clamp_min(1.0)
                dv = ts - mean.unsqueeze(0)
                ss_all = _masked_sum(torch, dv * dv, active, dim=0)

                # candidate = most extreme remaining value
                zabs = torch.where(active, dv.abs(), neg)
                dmax, idx = zabs.max(dim=0)

                # leave-one-out mean/std via exact identities (no cancellation):
                #   ss_loo = ss_all - dev_c^2 * n/(n-1)
                #   R      = |x_c - mean_loo| / s_loo = dev_c * n/(n-1) / s_loo
                n_loo = (n - 1.0).clamp_min(1.0)
                ss_loo = (ss_all - dmax * dmax * (n / n_loo)).clamp_min(0.0)
                var_loo = ss_loo / (n_loo - 1.0).clamp_min(1.0)
                std_loo = var_loo.sqrt().clamp_min(1e-12)
                R = dmax * (n / n_loo) / std_loo

                lam = crit_t[active.sum(dim=0).clamp(0, F)]
                passed[j] = can & (R > lam)

                # remove the single most extreme remaining value (where possible)
                hit = torch.zeros_like(active)
                hit.scatter_(0, idx.unsqueeze(0), can.unsqueeze(0))
                active = active & ~hit
                removed_step = torch.where(hit, torch.full_like(removed_step, j), removed_step)

            # per pixel: largest step index whose test passed (else -1)
            steps = torch.arange(max_out, device=dev, dtype=torch.int32).view(max_out, 1, 1, 1)
            jstar = torch.where(
                passed,
                steps.expand(max_out, H, W, C),
                torch.full((max_out, H, W, C), -1, dtype=torch.int32, device=dev),
            ).max(dim=0).values

            # reject exactly the removals up to and including step jstar
            keep = valid & ((removed_step < 0) | (removed_step > jstar.unsqueeze(0)))

            x = ts.masked_fill(~valid, float("nan"))
            fallback = torch.nan_to_num(_nanmedian(torch, x, dim=0), nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps)

        if algo == "Kappa-Sigma Clipping":
            # Classic kappa-sigma: median center, std of the KEPT sample,
            # monotone shrink (a rejected pixel stays rejected — the old
            # `keep = valid & bounds` let outliers re-enter after the bounds
            # re-widened). Average of survivors only; no median blending.
            keep = valid.clone()
            for _ in range(max(1, int(iterations))):
                x_iter = ts.masked_fill(~keep, float("nan"))
                med = _nanmedian(torch, x_iter, dim=0)
                n_kept = keep.sum(dim=0).clamp_min(1).to(ts.dtype)
                var = _masked_sum(torch, (ts - med.unsqueeze(0)) ** 2, keep, dim=0) / n_kept
                std = var.clamp_min(0.0).sqrt().clamp_min(1e-12)
                lo = (med - float(kappa) * std).unsqueeze(0)
                hi = (med + float(kappa) * std).unsqueeze(0)
                keep = keep & (ts >= lo) & (ts <= hi)

            x_valid = ts.masked_fill(~valid, float("nan"))
            fallback = torch.nan_to_num(_nanmedian(torch, x_valid, dim=0), nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps)

        if algo == "Trimmed Mean":
            x = ts.masked_fill(~valid, float("nan"))
            qlo = _nanquantile(torch, x, float(trim_fraction), dim=0)
            qhi = _nanquantile(torch, x, 1.0 - float(trim_fraction), dim=0)
            keep = valid & (ts >= qlo.unsqueeze(0)) & (ts <= qhi.unsqueeze(0))

            fallback = torch.nan_to_num(_nanmedian(torch, x, dim=0), nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps)

        if algo == "Biweight Estimator":
            x = ts.masked_fill(~valid, float("nan"))
            m = _nanmedian(torch, x, dim=0)
            mad = (_nanmedian(torch, (x - m.unsqueeze(0)).abs(), dim=0)).clamp_min(1e-12)

            # NaN-safe residuals: invalid lanes contribute exactly 0
            d = torch.where(valid, ts - m.unsqueeze(0), torch.zeros_like(ts))
            u = d / (float(biweight_constant) * mad.unsqueeze(0))
            mask = valid & (u.abs() < 1.0)

            omu2 = torch.where(mask, 1.0 - u * u, torch.zeros_like(u))
            k_w = omu2 * omu2 * w  # broadcasts weights over the stack
            num = (d * k_w).sum(dim=0)
            den = k_w.sum(dim=0)

            out = torch.where(den > 1e-20, m + num / den.clamp_min(1e-20), m)
            out = torch.nan_to_num(out, nan=0.0)

            rej = ~mask
            return _finalize(torch, out, rej, reduce_rej_maps)

        if algo == "Modified Z-Score Clipping":
            x = ts.masked_fill(~valid, float("nan"))
            med = _nanmedian(torch, x, dim=0)
            mad = (_nanmedian(torch, (x - med.unsqueeze(0)).abs(), dim=0)).clamp_min(1e-12)

            mz = torch.where(
                valid,
                0.6745 * (ts - med.unsqueeze(0)) / mad.unsqueeze(0),
                torch.full_like(ts, float("inf")),
            )
            keep = valid & (mz.abs() < float(modz_threshold))

            fallback = torch.nan_to_num(med, nan=0.0)
            out = _weighted_mean_or(torch, ts, keep, w, fallback)

            rej = ~keep
            return _finalize(torch, out, rej, reduce_rej_maps)

        raise NotImplementedError(f"GPU path not implemented for: {algo_name}")