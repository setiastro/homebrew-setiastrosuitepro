from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Tuple, TYPE_CHECKING
import io
import numpy as np
import csv
import re
from pathlib import Path
from typing import List, Dict, Any
from PyQt6.QtCore import Qt, QTimer, QCoreApplication
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QCheckBox, QFileDialog, QMessageBox, QSpinBox, QSlider, QApplication, QDoubleSpinBox,
    QStackedWidget, QWidget,
)
from astropy.io.fits import Header
from astropy.wcs import WCS
from astropy.io import fits
from astropy.coordinates import SkyCoord
from astropy.wcs.utils import proj_plane_pixel_scales
from matplotlib import patheffects as pe
from pathlib import Path
from setiastro.saspro.resources import get_data_path
from setiastro.saspro.bright_stars import BRIGHT_STARS
from setiastro.saspro.help_support import make_help_button
from setiastro.saspro.widgets.factory_reset import (
    make_reset_button, snapshot_controls, restore_controls)
if TYPE_CHECKING:
    from astropy.wcs import WCS as AstropyWCS
    from astropy.coordinates import SkyCoord as AstropySkyCoord
else:
    AstropyWCS = object
    AstropySkyCoord = object


def _tr(text: str) -> str:
    return QCoreApplication.translate("FinderChart", text)


_NONFITS_META_KEYS = {
    "FILE_PATH",
    "FITS_HEADER",
    "BIT_DEPTH",
    "WCS_HEADER",
    "__HEADER_SNAPSHOT__",
    "ORIGINAL_HEADER",
    "PRE_SOLVE_HEADER",
}

def _strip_nonfits_meta_keys_from_header(h: Header | None) -> Header:
    if not isinstance(h, Header):
        return Header()
    out = h.copy()
    for k in list(out.keys()):
        if k.upper() in _NONFITS_META_KEYS:
            try:
                out.remove(k)
            except Exception:
                pass
    return out


_FITS_PREFIXES = (
    "FITS Header.",   # what your CSV shows
    "FITS_HEADER.",   # sometimes people normalize this way
)

def _header_from_prefixed_meta(meta: dict) -> Header | None:
    """
    Rebuild a proper astropy Header from flattened keys like:
      "FITS Header.CTYPE1": "RA---TAN-SIP"
    """
    if not isinstance(meta, dict):
        return None

    items = []

    # 1) Flattened "FITS Header.KEY" style
    for k, v in meta.items():
        if not isinstance(k, str):
            continue
        for p in _FITS_PREFIXES:
            if k.startswith(p):
                card = k[len(p):].strip()
                if card:
                    items.append((card, v))
                break

    if not items:
        return None

    h = Header()
    for k, v in items:
        try:
            kk = str(k).upper()
            # skip things that are clearly not FITS cards
            if not kk or len(kk) > 32:
                continue
            h[kk] = v
        except Exception:
            pass
    return h if len(h) else None


def _header_from_nested_meta(meta: dict) -> Header | None:
    """
    Rebuild Header if metadata stores a nested mapping under something like:
      meta["FITS Header"] = {...} or meta["FITS_HEADER"] = {...}
    """
    for key in ("original_header", "fits_header", "header", "FITS Header", "FITS_HEADER"):
        obj = meta.get(key)
        if obj is None:
            continue
        # already a fits.Header?
        if isinstance(obj, Header):
            return obj

        # mapping -> Header
        if hasattr(obj, "items"):
            h = Header()
            for k, v in obj.items():
                try:
                    h[str(k).upper()] = v
                except Exception:
                    pass
            if len(h):
                return h
    return None


def _best_header_from_meta(meta: dict) -> Header | None:
    # 1) normal keys / nested header objects
    h = _header_from_nested_meta(meta)
    if isinstance(h, Header) and len(h):
        return h

    # 2) flattened "FITS Header.KEY" export style
    h = _header_from_prefixed_meta(meta)
    if isinstance(h, Header) and len(h):
        return h

    return None

def _as_header(hdr_like) -> Header | None:
    if hdr_like is None:
        return None
    if isinstance(hdr_like, Header):
        return hdr_like
    try:
        d = dict(hdr_like)
        h = Header()
        for k, v in d.items():
            try:
                h[str(k).upper()] = v
            except Exception:
                pass
        return h
    except Exception:
        return None

def get_doc_wcs_from_metadata(meta: dict) -> WCS | None:
    if not isinstance(meta, dict):
        return None

    # 1) Prefer prebuilt WCS object stored by platesolve flow
    w = meta.get("wcs", None)
    if w is not None and hasattr(w, "pixel_to_world") and hasattr(w, "wcs"):
        try:
            return w.celestial if getattr(w, "celestial", None) is not None else w
        except Exception:
            return w

    # 2) Build from *best* header representation in metadata
    hdr = _best_header_from_meta(meta)
    if not isinstance(hdr, Header) or len(hdr) == 0:
        return None

    hdr = _strip_nonfits_meta_keys_from_header(hdr)

    try:
        w2 = WCS(hdr, relax=True)
        return w2.celestial if getattr(w2, "celestial", None) is not None else w2
    except Exception:
        return None

@dataclass
class FinderChartRequest:
    survey: str
    scale_mult: int
    show_grid: bool

    show_star_names: bool = False
    star_mag_limit: float = 2.0
    star_max_labels: int = 30

    show_dso: bool = False
    dso_catalog: str = "Messier"
    dso_mag_limit: float = 10.0
    dso_max_labels: int = 30

    show_compass: bool = True
    show_scale_bar: bool = True

    out_px: int = 900
    overlay_opacity: float = 0.35

    # Imaging train FOV overlay
    show_fov_box: bool = False
    focal_length_mm: float = 500.0
    pixel_pitch_um: float = 3.76
    sensor_w_px: int = 6248
    sensor_h_px: int = 4176
    rotation_deg: float = 0.0      # clockwise from north

    # Sky chart overlay (skychart_engine): constellations, deep-sky shapes to
    # scale, star names, drawn on the survey image's own WCS
    show_skychart: bool = False
    skychart_layers: Optional[dict] = None

# ---------------- Catalog loading (cached) ----------------

_CATALOG_CACHE: Dict[str, List[Dict[str, Any]]] = {}

def _catalog_path(name: str) -> Path:
    # everything now comes from celestial_catalog.csv
    return Path(get_data_path("data/catalogs/celestial_catalog.csv"))



def _safe_float(v, default=None):
    try:
        if v is None:
            return default
        s = str(v).strip()
        if not s:
            return default
        return float(s)
    except Exception:
        return default


_size_re = re.compile(r"(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)")

def _parse_size_arcmin(info: str) -> Optional[tuple]:
    """
    Parse sizes like " 6.0x4.0" or "90x40" from Info field.
    Returns (w_arcmin, h_arcmin) or None.
    """
    if not info:
        return None
    m = _size_re.search(str(info))
    if not m:
        return None
    w = _safe_float(m.group(1), None)
    h = _safe_float(m.group(2), None)
    if w is None or h is None:
        return None
    # Assume arcminutes (matches your Messier examples)
    return (float(w), float(h))

def _open_catalog_csv(path: Path):
    """
    Catalogs may be saved as UTF-8, UTF-8 with BOM, or Windows-1252 / latin-1.
    IMPORTANT: we must *force a decode* here (open() alone doesn't decode until read).
    Returns a *text* file-like object suitable for csv.DictReader.
    """
    data = path.read_bytes()

    last = None
    for enc in ("latin-1", "utf-8-sig", "utf-8", "cp1252"):
        try:
            text = data.decode(enc)  # <-- force decode NOW
            # newline="" behavior like open(..., newline="") for csv module
            return io.StringIO(text, newline="")
        except UnicodeDecodeError as e:
            last = e

    # If we get here, decoding failed for all options
    raise last or UnicodeDecodeError("utf-8", b"", 0, 1, "Unknown decode error")

def _canon_catalog_code(name: str, catalog: str) -> str:
    n = (name or "").strip().upper()
    c = (catalog or "").strip().upper()

    # --- Sharpless (SH2) ---
    if c in {"SHARPLESS", "SH2", "SH-2", "SH 2", "SH_2"}:
        return "SH2"
    if n.startswith(("SH2-", "SH2 ", "SH-2", "SH 2", "SH_2")):
        return "SH2"

    # --- Planetary Nebula Galactic (PN-G / PNG) ---
    if c in {"PNG", "PN-G", "PN G", "PN_G"}:
        return "PN-G"
    if n.startswith(("PN-G", "PN G", "PN_G", "PNG ")):
        return "PN-G"

    # Keep the catalog column as-is for everything else (NGC/IC/Abell/etc.)
    return c


def _load_catalog_rows(kind: str) -> List[Dict[str, Any]]:
    if kind in _CATALOG_CACHE:
        return _CATALOG_CACHE[kind]

    path = _catalog_path(kind)
    rows: List[Dict[str, Any]] = []

    if not path.exists():
        print(f"[DSO] catalog path missing: {path}")
        _CATALOG_CACHE[kind] = rows
        return rows

    try:
        with _open_catalog_csv(path) as f:
            reader = csv.DictReader(f)
            for r in reader:
                def getk(*keys):
                    for k in keys:
                        if k in r and r[k] is not None:
                            return r[k]
                        kb = "\ufeff" + k
                        if kb in r and r[kb] is not None:
                            return r[kb]
                    return None

                name = str(getk("Name", "NAME") or "").strip()
                ra   = _safe_float(getk("RA", "Ra", "ra"), None)
                dec  = _safe_float(getk("Dec", "DEC", "dec"), None)
                if not name or ra is None or dec is None:
                    continue

                mag  = _safe_float(getk("Magnitude", "MAG", "mag"), None)
                info = str(getk("Info", "Diameter") or "").strip()
                typ  = str(getk("Type", "LongType") or "").strip()
                cat  = str(getk("Catalog") or "").strip()
                name = str(getk("Name", "NAME") or "").strip()
                canon = _canon_catalog_code(name, cat)

                rows.append({
                    "name": name,
                    "ra": float(ra),
                    "dec": float(dec),
                    "mag": mag,
                    "info": info,
                    "catalog": cat,          # raw
                    "catalog_code": canon,   # canonical (used for filtering)
                    "type": typ,
                })

    except Exception as e:
        print(f"[DSO] catalog read failed: {path} ({type(e).__name__}: {e})")
        _CATALOG_CACHE[kind] = []
        return []

    # per-kind filtering (based on Catalog column in celestial_catalog.csv)
    k = (kind or "").strip().upper()

    # Map UI label -> allowed catalog codes (also uppercase)
    allowed_map = {
        "M": {"M", "MESSIER"},
        "NGC": {"NGC"},
        "IC": {"IC"},
        "ABELL": {"ABELL"},
        "SH2": {"SH2"},
        "LBN": {"LBN"},
        "LDN": {"LDN"},
        "PN-G": {"PN-G"},
        "ALL (DSO)": None,
    }

    allowed = allowed_map.get(k, None)

    def _catcode(row) -> str:
        return (row.get("catalog_code") or row.get("catalog") or "").strip().upper()


    if allowed is not None:
        rows = [r for r in rows if _catcode(r) in allowed]

    _CATALOG_CACHE[kind] = rows
    return rows

def _pixel_scale_arcsec(bg_wcs: "WCS") -> Optional[float]:
    """
    Approx arcsec/pixel using astropy helper. Works for TAN-ish WCS.
    """
    if bg_wcs is None:
        return None
    try:
        # returns degrees/pixel per axis
        sc = proj_plane_pixel_scales(bg_wcs)  # deg/pix
        deg_per_pix = float(np.nanmedian(sc))
        if not np.isfinite(deg_per_pix) or deg_per_pix <= 0:
            return None
        return deg_per_pix * 3600.0
    except Exception:
        return None

def _draw_dso_overlay(ax, bg_wcs: "WCS", center: "SkyCoord", fov_deg: float, req: FinderChartRequest, renderer):
    """
    Plot catalog objects within ~0.75*fov radius; declutter via coarse grid.
    """
    if bg_wcs is None or center is None:
        return

    import astropy.units as u
    from astropy.coordinates import SkyCoord

    rows = _load_catalog_rows(req.dso_catalog)
 
    if not rows:
        return
    out_px = int(getattr(ax.figure, "_sas_out_px", 0) or 0)
    if out_px <= 0:
        out_px = int(ax.figure.get_figwidth() * ax.figure.dpi)
    ra0 = float(center.ra.deg)
    dec0 = float(center.dec.deg)
    radius = float(fov_deg) * 0.75

    c0 = SkyCoord(ra0*u.deg, dec0*u.deg, frame="icrs")

    # filter by radius + mag
    cand = []
    for r in rows:
        if abs(r["dec"] - dec0) > radius + 2.0:
            continue
        c1 = SkyCoord(r["ra"]*u.deg, r["dec"]*u.deg, frame="icrs")
        if c0.separation(c1).deg > radius:
            continue

        mag = r.get("mag", None)
        if mag is not None and mag > float(req.dso_mag_limit):
            continue

        # score: brighter first; unknown mag goes later
        score = (mag if mag is not None else 99.0)
        cand.append((score, r))

    if not cand:
        return

    cand.sort(key=lambda t: t[0])
    cand = cand[:max(1, int(req.dso_max_labels) * 4)]  # keep a bit extra before declutter

    #sasproject
    coords = SkyCoord([t[1]["ra"] for t in cand]*u.deg, [t[1]["dec"] for t in cand]*u.deg, frame="icrs")
    xs, ys = bg_wcs.world_to_pixel(coords)
    out_px = int(getattr(ax.figure, "_sas_out_px", 0) or 0)
    if out_px <= 0:
        out_px = int(ax.figure.get_figwidth() * ax.figure.dpi)
    # declutter: one label per coarse cell
    kept = []
    cell = 34  # px
    used = set()

    for (t, x, y) in zip(cand, xs, ys):
        x = float(x); y = float(y)
        if not _inside_px(x, y, out_px, pad=0):
            continue        
        if not (np.isfinite(x) and np.isfinite(y)):
            continue
        gx = int(x // cell)
        gy = int(y // cell)
        key = (gx, gy)
        if key in used:
            continue
        used.add(key)
        kept.append((t[1], float(x), float(y)))
        if len(kept) >= int(req.dso_max_labels):
            break

    if not kept:
        return

    # optional size ellipse (Info field, arcmin)
    arcsec_per_pix = _pixel_scale_arcsec(bg_wcs)

    for (r, x, y) in kept:
        name = r["name"]

        # marker
        ax.plot(
            [x], [y],
            marker="s",
            markersize=3.5,
            alpha=0.9,
            color="#66ccff",  # light cyan (optional)
            transform=ax.get_transform("pixel"),
        )

        # size circle if we can parse it (Info field, arcmin)
        if arcsec_per_pix is not None:
            sz = _parse_size_arcmin(r.get("info", ""))
            if sz is not None:
                w_arcmin, h_arcmin = sz

                # Use the MAJOR axis only (honest; no PA info)
                major_arcmin = float(max(w_arcmin, h_arcmin))

                # convert major-axis diameter arcmin -> pixel radius
                diam_px = (major_arcmin * 60.0) / arcsec_per_pix
                rad_px = 0.5 * diam_px

                if np.isfinite(rad_px) and rad_px > 2:
                    try:
                        from matplotlib.patches import Circle
                        c = Circle(
                            (x, y),
                            radius=rad_px,
                            fill=False,
                            linewidth=1,
                            alpha=0.75,
                            edgecolor="#5145ff",   # cyan outline (NOT black)
                            transform=ax.get_transform("pixel"),
                        )
                        ax.add_patch(c)
                    except Exception:
                        pass

        # label
        _place_label_inside(
            ax, x, y, name,
            dx=7, dy=5, fontsize=9,
            color="white", alpha=0.95, outline=True,
            out_px=out_px, pad=4, renderer=renderer
        )

def _draw_compass_NE(ax, bg_wcs: "WCS", out_px: int, fov_deg: float):
    """
    Draw N/E arrows in the bottom-right using image pixel/data coordinates.
    Works reliably with WCSAxes.
    """
    if bg_wcs is None:
        return

    import astropy.units as u
    from astropy.coordinates import SkyCoord

    # place near bottom-right in IMAGE pixel coords
    cx = out_px * 0.86
    cy = out_px * 0.12
    base_len = out_px * 0.09  # pixels

    # choose a small sky step relative to FOV (avoid huge jumps on big FOV)
    step_deg = max(0.01, min(0.15, float(fov_deg) * 0.08)) * u.deg

    try:
        csky = bg_wcs.pixel_to_world(out_px * 0.5, out_px * 0.5)
        ra = csky.ra.to(u.deg)
        dec = csky.dec.to(u.deg)

        # North: +Dec
        cn = SkyCoord(ra, dec + step_deg, frame="icrs")

        # East: +RA (compensate a bit for cos(dec))
        cosd = max(0.15, float(np.cos(dec.to_value(u.rad))))
        ce = SkyCoord(ra + (step_deg / cosd), dec, frame="icrs")

        x0, y0 = bg_wcs.world_to_pixel(SkyCoord(ra, dec, frame="icrs"))
        xn, yn = bg_wcs.world_to_pixel(cn)
        xe, ye = bg_wcs.world_to_pixel(ce)

        vn = np.array([float(xn - x0), float(yn - y0)], dtype=np.float64)
        ve = np.array([float(xe - x0), float(ye - y0)], dtype=np.float64)

        def _n(v):
            n = float(np.hypot(v[0], v[1])) or 1.0
            return v / n

        vn = _n(vn) * base_len
        ve = _n(ve) * base_len

    except Exception:
        # fallback: at least show something
        vn = np.array([0.0, base_len])
        ve = np.array([base_len, 0.0])

    # Draw in DATA coords (image pixels) — this is the big fix
    tx = ax.transData

    ax.annotate(
        "", xy=(cx + ve[0], cy + ve[1]), xytext=(cx, cy),
        xycoords=tx, textcoords=tx,
        arrowprops=dict(arrowstyle="->", linewidth=2.2, color="white", alpha=0.95)
    )
    ax.annotate(
        "", xy=(cx + vn[0], cy + vn[1]), xytext=(cx, cy),
        xycoords=tx, textcoords=tx,
        arrowprops=dict(arrowstyle="->", linewidth=2.2, color="white", alpha=0.95)
    )

    bbox = dict(boxstyle="round,pad=0.15", facecolor=(0, 0, 0, 0.55), edgecolor=(1, 1, 1, 0.15))

    ax.text(cx + ve[0] + 6, cy + ve[1] + 2, "E",
            transform=tx, fontsize=10, color="white", alpha=0.98, bbox=bbox)
    ax.text(cx + vn[0] + 6, cy + vn[1] + 2, "N",
            transform=tx, fontsize=10, color="white", alpha=0.98, bbox=bbox)


def _draw_scale_bar(ax, bg_wcs: "WCS", out_px: int, fov_deg: float):
    """
    Draw a scale bar bottom-left with units + arcsec/pixel.
    """
    if bg_wcs is None:
        return

    arcsec_per_pix = _pixel_scale_arcsec(bg_wcs)
    if arcsec_per_pix is None:
        return

    fov_arcmin = float(fov_deg) * 60.0
    if fov_arcmin >= 240:
        bar_arcmin = 30
    elif fov_arcmin >= 120:
        bar_arcmin = 20
    elif fov_arcmin >= 60:
        bar_arcmin = 10
    else:
        bar_arcmin = 5

    bar_px = (bar_arcmin * 60.0) / arcsec_per_pix
    if not np.isfinite(bar_px) or bar_px < 30:
        return

    x0 = out_px * 0.08
    y0 = out_px * 0.10
    x1 = x0 + bar_px

    tx = ax.transData  # BIG FIX

    ax.plot([x0, x1], [y0, y0], linewidth=3, color="white", alpha=0.95, transform=tx)
    ax.plot([x0, x0], [y0 - 5, y0 + 5], linewidth=2, color="white", alpha=0.95, transform=tx)
    ax.plot([x1, x1], [y0 - 5, y0 + 5], linewidth=2, color="white", alpha=0.95, transform=tx)

    bbox = dict(boxstyle="round,pad=0.2", facecolor=(0, 0, 0, 0.55), edgecolor=(1, 1, 1, 0.12))
    ax.text(
        x0, y0 + 14,
        f"{bar_arcmin}′  ({arcsec_per_pix:.2f}″/px)",
        transform=tx,
        fontsize=10,
        color="white",
        alpha=0.98,
        bbox=bbox
    )

def _as_fits_header(hdr_like) -> Optional["fits.Header"]:
    if hdr_like is None or fits is None:
        return None
    if isinstance(hdr_like, fits.Header):
        return hdr_like

    # Some parts of SASpro store header as dict-like; normalize it
    try:
        h2 = fits.Header()
        if hasattr(hdr_like, "items"):
            items = hdr_like.items()
        else:
            items = dict(hdr_like).items()

        for k, v in items:
            try:
                # FITS keys must be str, <= 8 chars, etc. Let astropy reject bad ones.
                h2[str(k)] = v
            except Exception:
                pass
        return h2
    except Exception:
        return None


def _ensure_tan_sip_if_needed(hdr: "fits.Header") -> "fits.Header":
    """
    If SIP distortion terms exist, make sure CTYPE has '-SIP' so WCS behaves like your platesolve path.
    Best-effort and harmless if already correct.
    """
    try:
        # SIP keywords commonly present: A_ORDER/B_ORDER or SIP-related cards
        has_sip = any(k in hdr for k in ("A_ORDER", "B_ORDER", "AP_ORDER", "BP_ORDER"))
        if not has_sip:
            return hdr

        for ax in (1, 2):
            k = f"CTYPE{ax}"
            c = str(hdr.get(k, "")).upper()
            if c and ("-SIP" not in c):
                # If it’s TAN-ish, append SIP; otherwise still append to be explicit.
                hdr[k] = c + "-SIP"
        return hdr
    except Exception:
        return hdr


def get_doc_wcs(meta: dict) -> WCS | None:
    return get_doc_wcs_from_metadata(meta)


def image_footprint_sky(wcs: "WCS", w: int, h: int):
    """Return (corners SkyCoord[4], center SkyCoord)."""
    wc = wcs
    try:
        if hasattr(wcs, "celestial") and wcs.celestial is not None:
            wc = wcs.celestial
    except Exception:
        pass

    xs = np.array([0.5, w - 0.5, w - 0.5, 0.5], dtype=np.float64)
    ys = np.array([0.5, 0.5, h - 0.5, h - 0.5], dtype=np.float64)

    corners = wc.pixel_to_world(xs, ys)
    center = wc.pixel_to_world(np.array([w / 2.0]), np.array([h / 2.0]))
    return corners, center


def _ang_sep_deg(a1, d1, a2, d2) -> float:
    """Small helper; inputs degrees."""
    ra1 = math.radians(a1); dec1 = math.radians(d1)
    ra2 = math.radians(a2); dec2 = math.radians(d2)
    return math.degrees(math.acos(
        max(-1.0, min(1.0, math.sin(dec1)*math.sin(dec2)
                      + math.cos(dec1)*math.cos(dec2)*math.cos(ra1-ra2)))
    ))


def estimate_fov_deg(corners: "AstropySkyCoord") -> Tuple[float, float]:
    """Approx FOV width/height in degrees using corner separations."""
    ra = corners.ra.deg
    dec = corners.dec.deg

    w1 = _ang_sep_deg(ra[0], dec[0], ra[1], dec[1])
    w2 = _ang_sep_deg(ra[3], dec[3], ra[2], dec[2])
    width = 0.5 * (w1 + w2)

    h1 = _ang_sep_deg(ra[0], dec[0], ra[3], dec[3])
    h2 = _ang_sep_deg(ra[1], dec[1], ra[2], dec[2])
    height = 0.5 * (h1 + h2)

    return float(width), float(height)

def _wcs_shift_for_crop(w: WCS, x0: int, y0: int) -> WCS:
    """
    Return a copy of WCS adjusted for cropping (x0,y0) pixels off left/bottom.
    Array pixels are 0-based; FITS WCS CRPIX is 1-based, but the shift is the same in pixels.
    """
    if w is None:
        return None
    try:
        wc = w.deepcopy()
        # CRPIX is in pixel units; subtract crop origin
        wc.wcs.crpix = np.array(wc.wcs.crpix, dtype=float) - np.array([float(x0), float(y0)], dtype=float)
        return wc
    except Exception:
        return w


def _crop_center(bg_rgb01: np.ndarray, bg_wcs: Optional[WCS], out_px: int):
    """
    Center-crop bg to (out_px,out_px). Returns (cropped_bg, cropped_wcs, (x0,y0)).
    """
    H, W = bg_rgb01.shape[:2]
    out_px = int(out_px)
    if out_px <= 0 or out_px > min(H, W):
        return bg_rgb01, bg_wcs, (0, 0)

    x0 = int((W - out_px) // 2)
    y0 = int((H - out_px) // 2)

    crop = bg_rgb01[y0:y0 + out_px, x0:x0 + out_px, :]
    wc = _wcs_shift_for_crop(bg_wcs, x0, y0) if bg_wcs is not None else None
    return crop, wc, (x0, y0)

def _inside_px(x: float, y: float, out_px: int, pad: int = 0) -> bool:
    if not (np.isfinite(x) and np.isfinite(y)):
        return False
    return (-pad) <= x <= (out_px - 1 + pad) and (-pad) <= y <= (out_px - 1 + pad)

def _place_label_inside(ax, x, y, text, *, dx=6, dy=4, fontsize=9,
                        color="white", alpha=0.95, outline=True,
                        out_px=900, pad=3, renderer=None):
    """
    Place a label near (x,y) but ensure its bounding box stays inside [0,out_px).
    Requires a renderer (create once per chart render).
    """
    if renderer is None:
        # best-effort fallback (still avoids draw); may be None on some backends until first draw
        renderer = getattr(ax.figure.canvas, "get_renderer", lambda: None)()
        if renderer is None:
            # can't measure; just place it and clip
            t = ax.text(x + dx, y + dy, text, fontsize=fontsize, color=color, alpha=alpha,
                        transform=ax.get_transform("pixel"), clip_on=True)
            if outline:
                t.set_path_effects([pe.Stroke(linewidth=2.0, foreground=(0, 0, 0, 0.85)), pe.Normal()])
            return t

    t = ax.text(x + dx, y + dy, text, fontsize=fontsize, color=color, alpha=alpha,
                transform=ax.get_transform("pixel"), clip_on=True)
    if outline:
        t.set_path_effects([pe.Stroke(linewidth=2.0, foreground=(0, 0, 0, 0.85)), pe.Normal()])

    bb = t.get_window_extent(renderer=renderer)
    inv = ax.get_transform("pixel").inverted()

    (x0, y0) = inv.transform((bb.x0, bb.y0))
    (x1, y1) = inv.transform((bb.x1, bb.y1))

    shift_x = 0.0
    shift_y = 0.0

    if x0 < pad:
        shift_x += (pad - x0)
    if x1 > (out_px - pad):
        shift_x -= (x1 - (out_px - pad))
    if y0 < pad:
        shift_y += (pad - y0)
    if y1 > (out_px - pad):
        shift_y -= (y1 - (out_px - pad))

    if shift_x or shift_y:
        t.set_position((x + dx + shift_x, y + dy + shift_y))

        # Re-check once (no draw needed)
        bb2 = t.get_window_extent(renderer=renderer)
        (xx0, yy0) = inv.transform((bb2.x0, bb2.y0))
        (xx1, yy1) = inv.transform((bb2.x1, bb2.y1))
        if (xx0 < 0) or (yy0 < 0) or (xx1 > out_px) or (yy1 > out_px):
            t.remove()
            return None

    return t

# Survey ids are the CDS registry's own (MocServer). Two were wrong and could
# never have resolved, outage or not: "CDS/P/DSS2/IR" (the tree is NIR) and
# "CDS/P/PanSTARRS/DR1/color" (the composites are color-i-r-g and
# color-z-zg-g; i-r-g is the one with a mirror outside CDS). Checked
# 2026-11-18. The labels are unchanged, so a saved survey choice still loads.
SURVEY_HIPS = {
    # Optical
    "DSS2 (Color)":               "CDS/P/DSS2/color",
    "DSS2 (Red)":                 "CDS/P/DSS2/red",
    "DSS2 (Blue)":                "CDS/P/DSS2/blue",
    "DSS2 (IR)":                  "CDS/P/DSS2/NIR",
    "Pan-STARRS DR1 (Color)":     "CDS/P/PanSTARRS/DR1/color-i-r-g",
    "SDSS9 (Color Alt)":          "CDS/P/SDSS9/color-alt",
    "DESI Legacy DR10 (Color)":   "CDS/P/DESI-Legacy-Surveys/DR10/color",

    # Infrared
    "2MASS (J)":                  "CDS/P/2MASS/J",
    "2MASS (H)":                  "CDS/P/2MASS/H",

    # Gaia
    "Gaia DR3 (Flux Color)":      "CDS/P/Gaia/DR3/flux-color",

    # Northern Sky Narrowband Survey (8-bit display trees)
    "NSNS DR0.1 (True Color)":    "simg.de/P/NSNS/DR0_1/tc8",
    "NSNS DR0.1 (Hα)":            "simg.de/P/NSNS/DR0_1/halpha8",
    "NSNS DR0.2 (Hα)":            "simg.de/P/NSNS/DR0_2/halpha8",
    "NSNS DR0.2 ([OIII])":        "simg.de/P/NSNS/DR0_2/oiii8",
    "NSNS DR0.2 ([SII])":         "simg.de/P/NSNS/DR0_2/sii8",
}

def _survey_to_hips_id(label: str) -> str:
    return SURVEY_HIPS.get(label, "CDS/P/DSS2/color")


def _cds_trees(path: str) -> list:
    """The two CDS static-tree hosts for one path, backup host first."""
    return [f"https://alaskybis.cds.unistra.fr/{path}",
            f"https://alasky.cds.unistra.fr/{path}"]


def _nsns_trees(release: str, layer: str) -> list:
    rel = release.lower()          # "DR0_2" -> dr0_2 on simg.de
    return ([f"http://www.simg.de/nebulae3/{rel}/{layer}"]
            + _cds_trees(f"simg.de/simg.de_P_NSNS_{release}_{layer}"))


# Direct HiPS tile trees for the surveys SRGC does not already register
# (DSS2 colour, red and blue come from survey_gradient's own measured lists).
# MEASURED 2026-11-18, during a CDS outage: alasky answered 404 for every
# static tree and for hips2fits, alaskybis timed out. Every non-CDS URL here
# returned a /properties file that day; the CDS paths are the ones the CDS
# registry lists, kept so the tile route works again the moment CDS does.
# DSS2 NIR, SDSS9 color-alt and DESI DR10 have NO mirror outside CDS -- probed
# at IRSA, CASDA and ESA, all 404 -- and Gaia DR3 flux-color could not be
# found in the registry at all, so it relies on hips2fits by id.
_FINDER_TILE_MIRRORS = {
    "CDS/P/DSS2/NIR": _cds_trees("DSS/DSS2-NIR"),
    "CDS/P/PanSTARRS/DR1/color-i-r-g": (
        ["https://stpubdata.s3.us-east-1.amazonaws.com/mast/skybackgrounds/PanSTARRS"]
        + _cds_trees("Pan-STARRS/DR1/color-i-r-g")),
    "CDS/P/SDSS9/color-alt": _cds_trees("SDSS/DR9/color-alt"),
    "CDS/P/DESI-Legacy-Surveys/DR10/color": _cds_trees(
        "DESI-legacy-surveys/DR10/CDS_P_DESI-Legacy-Surveys_DR10_color"),
    "CDS/P/2MASS/J": (["https://irsa.ipac.caltech.edu/data/hips/CDS/2MASS/J"]
                      + _cds_trees("2MASS/J")),
    "CDS/P/2MASS/H": (["https://irsa.ipac.caltech.edu/data/hips/CDS/2MASS/H"]
                      + _cds_trees("2MASS/H")),
    "CDS/P/Gaia/DR3/flux-color": [],
    "simg.de/P/NSNS/DR0_1/tc8":     _nsns_trees("DR0_1", "tc8"),
    "simg.de/P/NSNS/DR0_1/halpha8": _nsns_trees("DR0_1", "halpha8"),
    "simg.de/P/NSNS/DR0_2/halpha8": _nsns_trees("DR0_2", "halpha8"),
    "simg.de/P/NSNS/DR0_2/oiii8":   _nsns_trees("DR0_2", "oiii8"),
    "simg.de/P/NSNS/DR0_2/sii8":    _nsns_trees("DR0_2", "sii8"),
}


def _finder_query_wcs(center: "SkyCoord", fov_deg: float, out_px: int) -> WCS:
    """
    The grid hips2fits used to be asked for: TAN, square, `fov_deg` across,
    north up and east left. Built here because the tile route reprojects
    locally and needs the WCS up front, and so both routes land on the same
    grid -- the chart's overlays are drawn with this WCS either way.
    """
    s = float(fov_deg) / float(out_px)
    w = WCS(naxis=2)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    w.wcs.crval = [float(center.ra.deg), float(center.dec.deg)]
    w.wcs.crpix = [(out_px + 1) / 2.0, (out_px + 1) / 2.0]
    w.wcs.cdelt = [-s, s]
    w.wcs.radesys = "ICRS"
    w.wcs.set()
    try:
        w.pixel_shape = (int(out_px), int(out_px))
    except Exception:
        pass
    return w


def try_fetch_hips_cutout(center: "SkyCoord", fov_deg: float, out_px: int, survey_label: str):
    """
    Background cutout for the finder chart -> (rgb01, wcs, error).

    Goes through SRGC's fetch_reference, so it gets the same failover the
    rest of SASpro has: the survey's direct tile trees on every registered
    mirror (non-CDS hosts first), then hips2fits on both CDS endpoints, with
    the per-session dead-host memory and TCP pre-flight. This used to call
    hips2fits on alasky and nothing else, so a CDS outage took every survey
    down at once while IRSA, CASDA, ESA, MAST and simg.de were all serving.
    """
    try:
        from setiastro.saspro import survey_gradient as sg
    except Exception as e:
        return None, None, f"{type(e).__name__}: {e}"

    hips_id = _survey_to_hips_id(survey_label)
    px = int(out_px)
    mirrors = _FINDER_TILE_MIRRORS.get(hips_id)
    if mirrors is None:
        mirrors = sg.mirrors_for(hips_id)

    try:
        qw = _finder_query_wcs(center, fov_deg, px)
        data = sg.fetch_reference(qw, (px, px), hips_id, mirrors=mirrors,
                                  keep_bands=True)
    except Exception as e:
        full = str(e)
        print(f"[FinderChart] {survey_label} ({hips_id}): {full}")
        # The full report lists every route with its timing; the chart has
        # room for which routes were tried, not why each one failed.
        routes = [ln.strip().lstrip("\u2022").strip().split(" (", 1)[0].split(":", 1)[0]
                  for ln in full.splitlines() if ln.strip().startswith("\u2022")]
        if routes:
            return None, None, _tr("Every survey route failed:\n{0}").format(
                "\n".join(routes[:8]))
        return None, None, f"{type(e).__name__}: {e}"

    data = np.asarray(data, dtype=np.float32)
    if data.ndim == 2:
        data = np.repeat(data[..., None], 3, axis=2)
    elif data.ndim == 3 and data.shape[2] == 1:
        data = np.repeat(data, 3, axis=2)
    elif data.ndim == 3:
        data = data[..., :3]

    # Stretch on real pixels only. The tile route marks out-of-footprint as
    # NaN; letting those in as zeros would pin the black point to the void.
    fin = np.isfinite(data)
    if fin.any():
        lo, hi = np.percentile(data[fin], [1.0, 99.5])
        if hi > lo:
            data = (data - lo) / (hi - lo)
    data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0)
    return np.clip(data, 0.0, 1.0).astype(np.float32), qw, None


def render_finder_chart(doc_image: np.ndarray, meta: dict, req: FinderChartRequest) -> Optional[np.ndarray]:
    if WCS is None:
        return None

    doc_wcs = get_doc_wcs(meta)
    if doc_wcs is None:
        return None

    H, Wimg = doc_image.shape[:2]
    corners, center = image_footprint_sky(doc_wcs, Wimg, H)
    fov_w, fov_h = estimate_fov_deg(corners)
    fov = max(fov_w, fov_h) * float(req.scale_mult)

    # Fetch background (+ WCS + error string)
    bg, bg_wcs, err = try_fetch_hips_cutout(center[0], fov_deg=fov, out_px=req.out_px, survey_label=req.survey)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(req.out_px / 100.0, req.out_px / 100.0), dpi=100)
    ax = fig.add_axes([0, 0, 1, 1])

    # --- Draw background OR error message ---
    if bg is None:
        ax.set_facecolor((0, 0, 0))
        msg = _tr("No HiPS background.\n{0}").format(err or _tr("Unknown error"))
        ax.text(0.5, 0.5, msg, ha="center", va="center", transform=ax.transAxes)
    else:
        # If you want doc overlay, do it here
        if bg_wcs is not None and doc_wcs is not None:
            try:
                overlay_u8 = _overlay_doc_on_bg(bg, bg_wcs, doc_image, doc_wcs, alpha=req.overlay_opacity)
                ax.imshow(overlay_u8, origin="lower")
            except Exception:
                # fallback to plain bg if overlay fails
                ax.imshow(bg, origin="lower")
        else:
            ax.imshow(bg, origin="lower")

        # Optional: draw WCS-correct footprint polygon
        if bg_wcs is not None:
            try:
                xs, ys = bg_wcs.world_to_pixel(corners)
                ax.plot(
                    [xs[0], xs[1], xs[2], xs[3], xs[0]],
                    [ys[0], ys[1], ys[2], ys[3], ys[0]],
                    linewidth=2
                )
            except Exception:
                pass

    # center crosshair (axes coords)
    ax.plot([0.5], [0.5], marker="+", markersize=20, transform=ax.transAxes)

    # labels
    ra = float(center[0].ra.deg)
    dec = float(center[0].dec.deg)
    ax.text(
        0.02, 0.98,
        f"{req.survey}  |  {req.scale_mult}×FOV\nRA {ra:.6f}°  Dec {dec:.6f}°\nFOV ~ {fov*60:.1f}′",
        transform=ax.transAxes, va="top",
        color="white",
        bbox=dict(boxstyle="round,pad=0.25", facecolor=(0, 0, 0, 0.45), edgecolor=(1, 1, 1, 0.12))
    )

    if req.show_grid:
        # keep axis ON so grid can render
        ax.set_axis_on()
        ax.set_xticks(np.linspace(0, req.out_px, 7))
        ax.set_yticks(np.linspace(0, req.out_px, 7))
        ax.grid(True, alpha=0.35)
        # optionally hide tick labels but keep grid
        ax.set_xticklabels([])
        ax.set_yticklabels([])
    else:
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_axis_off()

    fig.canvas.draw()

    w, h = fig.canvas.get_width_height()
    rgba = np.asarray(fig.canvas.buffer_rgba(), dtype=np.uint8).reshape(h, w, 4)
    rgb = rgba[..., :3].copy()

    plt.close(fig)
    return rgb

def _to_u8_rgb(img: np.ndarray) -> np.ndarray:
    a = np.asarray(img)
    if a.ndim == 2:
        a = np.repeat(a[..., None], 3, axis=2)
    if a.shape[2] > 3:
        a = a[..., :3]
    a = a.astype(np.float32)
    # simple robust normalize for display
    lo, hi = np.percentile(a, [1.0, 99.5])
    if hi > lo:
        a = (a - lo) / (hi - lo)
    a = np.clip(a, 0.0, 1.0)
    return (a * 255.0 + 0.5).astype(np.uint8)

def _overlay_doc_on_bg(bg_rgb01: np.ndarray, bg_wcs: "WCS", doc_img: np.ndarray, doc_wcs: "WCS", alpha=0.35) -> np.ndarray:
    import cv2

    Hbg, Wbg = bg_rgb01.shape[:2]
    bg_u8 = (np.clip(bg_rgb01, 0, 1) * 255.0 + 0.5).astype(np.uint8)

    doc_u8 = _to_u8_rgb(doc_img)
    H, W = doc_u8.shape[:2]

    # doc pixel corners -> sky -> bg pixels
    src = np.array([[0,0], [W-1,0], [W-1,H-1], [0,H-1]], dtype=np.float32)
    sky = doc_wcs.pixel_to_world(src[:,0], src[:,1])   # SkyCoord
    xbg, ybg = bg_wcs.world_to_pixel(sky)
    dst = np.stack([xbg, ybg], axis=1).astype(np.float32)

    M = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(doc_u8, M, (Wbg, Hbg), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_TRANSPARENT)

    # alpha blend where warped has content
    mask = (warped.sum(axis=2) > 0).astype(np.float32)[..., None]
    out = bg_u8.astype(np.float32) * (1 - alpha*mask) + warped.astype(np.float32) * (alpha*mask)
    return np.clip(out, 0, 255).astype(np.uint8)


def _rgb_u8_to_qimage(rgb_u8: np.ndarray) -> QImage:
    rgb_u8 = np.ascontiguousarray(rgb_u8)
    h, w, _ = rgb_u8.shape
    bpl = rgb_u8.strides[0]
    # QImage uses the buffer; to be safe, copy via .copy() when making pixmap
    return QImage(rgb_u8.data, w, h, bpl, QImage.Format.Format_RGB888)

def _draw_star_names(ax, bg_wcs: "WCS", center: "SkyCoord", fov_deg: float, *,
                     mag_limit: float = 2.0, max_labels: int = 30, renderer=None):
    if bg_wcs is None:
        return

    import astropy.units as u
    from astropy.coordinates import SkyCoord

    ra0 = float(center.ra.deg)
    dec0 = float(center.dec.deg)
    radius = float(fov_deg) * 0.75

    c0 = SkyCoord(ra0*u.deg, dec0*u.deg, frame="icrs")  # <-- MOVE OUTSIDE LOOP

    rows = []
    for (name, ra, dec, vmag) in BRIGHT_STARS:
        if float(vmag) > float(mag_limit):
            continue
        if abs(dec - dec0) > radius + 2.0:
            continue
        c1 = SkyCoord(float(ra)*u.deg, float(dec)*u.deg, frame="icrs")
        if c0.separation(c1).deg <= radius:
            rows.append((name, float(ra), float(dec), float(vmag)))

    if not rows:
        return

    rows.sort(key=lambda r: r[3])
    rows = rows[:max_labels]

    coords = SkyCoord([r[1] for r in rows]*u.deg, [r[2] for r in rows]*u.deg, frame="icrs")
    xs, ys = bg_wcs.world_to_pixel(coords)

    out_px = int(getattr(ax.figure, "_sas_out_px", 0) or 0)
    if out_px <= 0:
        out_px = int(ax.figure.get_figwidth() * ax.figure.dpi)

    kept = []
    cell = 28
    used = set()

    for (row, x, y) in zip(rows, xs, ys):
        x = float(x); y = float(y)
        if not _inside_px(x, y, out_px, pad=0):
            continue
        gx = int(x // cell)
        gy = int(y // cell)
        key = (gx, gy)
        if key in used:
            continue
        used.add(key)
        kept.append((row[0], x, y))
        if len(kept) >= int(max_labels):
            break

    for (name, x, y) in kept:
        ax.plot([x], [y],
                marker="o", markersize=2.5, alpha=0.85,
                color="#ffb000",
                transform=ax.get_transform("pixel"),
                clip_on=True)

        _place_label_inside(
            ax, x, y, name,
            dx=6, dy=4, fontsize=9,
            color="#ffb000", alpha=0.95, outline=True,
            out_px=out_px, pad=4,
            renderer=renderer,          # <-- PASS IT
        )


_SKYCHART_OVERLAY_CACHE: dict = {}


def _skychart_overlay_rgba(bg_wcs: "WCS", w: int, h: int, layers: Optional[dict]):
    """RGBA overlay of the sky chart layers on a survey cutout, FITS row order.
    Cached on the cutout's WCS, size and layer choice, so toggling the compass or
    the grid does not redraw it."""
    from setiastro.saspro import skychart_engine as E
    lay = dict(layers or {})
    key = (bg_wcs.to_header_string(), int(w), int(h), tuple(sorted((k, bool(v)) for k, v in lay.items())))
    hit = _SKYCHART_OVERLAY_CACHE.get(key)
    if hit is not None:
        return hit
    data = E.get_data(log=print)
    # The chart is drawn at 900-2400 px and then shown inside matplotlib axes
    # that take ~70% of the figure, so print-sized labels end up unreadable:
    # half again as large, and lines a little heavier, read well on a photo.
    ov = E.render_overlay(E.overlay_params(lay, text_scale=1.5, graphics_scale=1.4),
                          data, bg_wcs, int(w), int(h), log=print)
    _SKYCHART_OVERLAY_CACHE.clear()
    _SKYCHART_OVERLAY_CACHE[key] = ov
    return ov


def render_finder_chart_cached(
    *,
    doc_image: np.ndarray,
    doc_wcs: WCS,
    corners: SkyCoord,
    center: SkyCoord,
    fov_deg: float,
    req: FinderChartRequest,
    bg: Optional[np.ndarray],
    bg_wcs: Optional[WCS],
    err: Optional[str],
    base_u8: Optional[np.ndarray] = None,   # <-- NEW
) -> np.ndarray:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(req.out_px / 100.0, req.out_px / 100.0), dpi=100)
    fig._sas_out_px = int(req.out_px)

    # Use WCSAxes when we have bg_wcs so we can draw RA/Dec labels & grid properly
    if bg_wcs is not None:
        ax = fig.add_subplot(111, projection=bg_wcs)
    else:
        ax = fig.add_axes([0, 0, 1, 1])

    # ---- background (or error) ----
    if bg is None:
        ax.set_facecolor((0, 0, 0))
        msg = _tr("No HiPS background.\n{0}").format(err or _tr("Unknown error"))
        ax.text(0.5, 0.5, msg, ha="center", va="center", transform=ax.transAxes)
    else:
        # If provided, base_u8 already includes hips + optional warped doc overlay.
        if base_u8 is not None:
            ax.imshow(base_u8, origin="lower")
        else:
            # fallback (old path)
            if bg_wcs is not None and doc_wcs is not None and req.overlay_opacity > 0.0:
                try:
                    overlay_u8 = _overlay_doc_on_bg(bg, bg_wcs, doc_image, doc_wcs, alpha=req.overlay_opacity)
                    ax.imshow(overlay_u8, origin="lower")
                except Exception:
                    ax.imshow(bg, origin="lower")
            else:
                ax.imshow(bg, origin="lower")

        # ---- sky chart overlay: constellations, deep-sky shapes, star names ----
        if getattr(req, "show_skychart", False) and bg_wcs is not None:
            try:
                ov = _skychart_overlay_rgba(bg_wcs, int(bg.shape[1]), int(bg.shape[0]),
                                            getattr(req, "skychart_layers", None))
                if ov is not None:
                    ax.imshow(ov, origin="lower")
            except Exception as e:
                print(f"[FinderChart] sky chart overlay failed: {type(e).__name__}: {e}")

        # footprint polygon in pixel coords
        if bg_wcs is not None:
            try:
                xs, ys = bg_wcs.world_to_pixel(corners)
                ax.plot(
                    [xs[0], xs[1], xs[2], xs[3], xs[0]],
                    [ys[0], ys[1], ys[2], ys[3], ys[0]],
                    linewidth=2,
                    transform=ax.get_transform("pixel"),
                )
            except Exception:
                pass

    # center crosshair
    ax.plot([0.5], [0.5], marker="+", markersize=20, transform=ax.transAxes)

    # top-left info text
    ra = float(center[0].ra.deg)
    dec = float(center[0].dec.deg)
    ax.text(
        0.02, 0.98,
        f"{req.survey}  |  {req.scale_mult}×FOV\nRA {ra:.6f}°  Dec {dec:.6f}°\nFOV ~ {fov_deg*60:.1f}′",
        transform=ax.transAxes, va="top"
    )

    # ---- grid + RA/Dec labels ----
    if bg_wcs is not None:
        # RA/Dec edge labels
        try:
            ax.coords[0].set_axislabel("RA")
            ax.coords[1].set_axislabel("Dec")
        except Exception:
            pass

        # toggle grid lines
        try:
            ax.coords.grid(bool(req.show_grid), alpha=0.35)
        except Exception:
            pass

        # If grid is off, you may still want edge tick labels; keep axis visible.
        # WCSAxes handles ticks/labels automatically.
    else:
        # fallback: pixel grid only
        if req.show_grid:
            ax.set_axis_on()
            ax.set_xticks(np.linspace(0, req.out_px, 7))
            ax.set_yticks(np.linspace(0, req.out_px, 7))
            ax.grid(True, alpha=0.35)
            ax.set_xticklabels([])
            ax.set_yticklabels([])
        else:
            ax.set_xticks([])
            ax.set_yticks([])
            ax.set_axis_off()

    # After background + grid setup (before overlays that need bbox measurements)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()

    # ---- star names overlay ----
    if getattr(req, "show_star_names", False) and (bg_wcs is not None):
        try:
            _draw_star_names(
                ax, bg_wcs, center[0], fov_deg,
                mag_limit=float(getattr(req, "star_mag_limit", 2.0)),
                max_labels=int(getattr(req, "star_max_labels", 30)), renderer=renderer
            )
        except Exception:
            pass

    # ---- deep-sky overlay ----
    if getattr(req, "show_dso", False):

        if bg_wcs is not None:
            try:
                _draw_dso_overlay(ax, bg_wcs, center[0], fov_deg, req, renderer=renderer)
            except Exception as e:
                print(f"[DSO] overlay error: {type(e).__name__}: {e}")

    # ---- compass + scale bar ----
    if bg_wcs is not None and getattr(req, "show_compass", True):
        try:
            _draw_compass_NE(ax, bg_wcs, int(req.out_px), float(fov_deg))
        except Exception:
            pass

    if bg_wcs is not None and getattr(req, "show_scale_bar", True):
        try:
            _draw_scale_bar(ax, bg_wcs, int(req.out_px), float(fov_deg))
        except Exception:
            pass

    # ---- FOV box overlay ----
    if bg_wcs is not None and getattr(req, "show_fov_box", False):
        try:
            _draw_fov_box(ax, bg_wcs, center[0], req, int(req.out_px))
        except Exception:
            pass


    fig.canvas.draw()
    w, h = fig.canvas.get_width_height()
    rgba = np.asarray(fig.canvas.buffer_rgba(), dtype=np.uint8).reshape(h, w, 4)
    rgb = rgba[..., :3].copy()
    plt.close(fig)
    return rgb

def _draw_fov_box(ax, bg_wcs: "WCS", center: "SkyCoord", req: "FinderChartRequest", out_px: int):
    """
    Draw the imaging sensor FOV rectangle centerd on the field center.
    Rotation is clockwise from North (positive = CW in sky coords).
    """
    if not getattr(req, "show_fov_box", False):
        return
    if bg_wcs is None:
        return

    import astropy.units as u
    from astropy.coordinates import SkyCoord

    fl   = float(req.focal_length_mm)
    pitch = float(req.pixel_pitch_um)
    sw   = int(req.sensor_w_px)
    sh   = int(req.sensor_h_px)
    rot  = float(req.rotation_deg)   # degrees CW from North

    if fl <= 0 or pitch <= 0 or sw <= 0 or sh <= 0:
        return

    try:
        # Sensor angular half-sizes in degrees
        half_w_deg = math.degrees(math.atan((pitch * sw) / (2000.0 * fl)))
        half_h_deg = math.degrees(math.atan((pitch * sh) / (2000.0 * fl)))

        ra0  = float(center.ra.deg)
        dec0 = float(center.dec.deg)

        # Build the 4 corners in sky coords.
        # Start with unrotated corners in (dRA, dDec) offset space,
        # then rotate CW by rot degrees.
        rot_rad = math.radians(-rot)
        cos_r = math.cos(rot_rad)
        sin_r = math.sin(rot_rad)
        cosd  = max(0.01, math.cos(math.radians(dec0)))

        # Unrotated corners: (±half_w, ±half_h) in (E, N) offset space
        # E is along RA (positive = east = decreasing RA), N is along Dec
        corners_en = [
            (-half_w_deg,  half_h_deg),   # NW
            ( half_w_deg,  half_h_deg),   # NE
            ( half_w_deg, -half_h_deg),   # SE
            (-half_w_deg, -half_h_deg),   # SW
        ]

        sky_corners = []
        for (de, dn) in corners_en:
            # Rotate CW: new_E =  de*cos - dn*sin, new_N = de*sin + dn*cos
            re =  de * cos_r - dn * sin_r
            rn =  de * sin_r + dn * cos_r
            # Convert offset to RA/Dec (small angle, compensate for cos(dec) in RA)
            ra_c  = ra0  - re / cosd   # E offset = decreasing RA
            dec_c = dec0 + rn
            sky_corners.append(SkyCoord(ra_c * u.deg, dec_c * u.deg, frame="icrs"))

        xs, ys = bg_wcs.world_to_pixel(
            SkyCoord([c.ra for c in sky_corners], [c.dec for c in sky_corners])
        )

        # Close the rectangle
        xs_plot = list(xs) + [xs[0]]
        ys_plot = list(ys) + [ys[0]]

        tx = ax.transData
        ax.plot(xs_plot, ys_plot,
                linewidth=1.5, color="#00ff88", alpha=0.9,
                transform=tx, zorder=10)

        # Label with FOV dimensions
        fov_w_arcmin = half_w_deg * 2 * 60.0
        fov_h_arcmin = half_h_deg * 2 * 60.0
        cx_px = float(np.mean(xs))
        cy_px = float(np.mean(ys))
        ax.text(
            cx_px, cy_px + (ys[1] - ys[2]) * 0.55,
            f"{fov_w_arcmin:.1f}′ × {fov_h_arcmin:.1f}′",
            transform=tx,
            fontsize=8, color="#00ff88", alpha=0.95,
            ha="center", va="bottom",
        )

    except Exception as e:
        print(f"[FOV box] draw failed: {e}")

class _SkyChartHostMixin:
    """
    What both Finder Chart dialogs share for the sky chart:

      * a Style switch -- "Survey image" (the dialog as it always was) or
        "Drawn chart" (skychart_ui.SkyChartPanel, created on first use);
      * on the survey page, a "Sky chart overlay" toggle with a Layers... picker.

    The dialog builds its survey controls into self._survey_page instead of
    itself, then calls _install_sky_chart_host() at the end of __init__.
    """

    _STYLE_KEY = "finder_chart/style"
    _OVERLAY_KEY = "finder_chart/skychart_overlay"
    _LAYERS_KEY = "finder_chart/skychart_layers"

    def _install_sky_chart_host(self):
        import json as _json
        self._sky_panel = None
        try:
            self._skychart_layers = _json.loads(self._settings.value(self._LAYERS_KEY, "", type=str) or "{}")
        except Exception:
            self._skychart_layers = {}

        # overlay row, under the survey page's first two rows
        row = QHBoxLayout()
        self.chk_skychart = QCheckBox(_tr("Sky chart overlay"))
        self.chk_skychart.setToolTip(_tr("Draw constellations, deep-sky objects to scale and star names "
                                         "over the survey image"))
        self.chk_skychart.setChecked(self._settings.value(self._OVERLAY_KEY, False, type=bool))
        self.btn_skychart_layers = QPushButton(_tr("Layers…"))
        self.btn_skychart_layers.setToolTip(_tr("Choose which sky chart layers the overlay draws"))
        row.addWidget(self.chk_skychart)
        row.addWidget(self.btn_skychart_layers)
        row.addStretch(1)
        self._survey_page.layout().insertLayout(2, row)
        self.chk_skychart.toggled.connect(self._on_skychart_overlay_toggled)
        self.btn_skychart_layers.clicked.connect(self._pick_skychart_layers)

        outer = QVBoxLayout(self)
        top = QHBoxLayout()
        top.addWidget(QLabel(_tr("Style:")))
        self.cmb_style = QComboBox()
        self.cmb_style.addItems(["Survey image", "Drawn chart"])
        self.cmb_style.setToolTip(_tr("Survey image: a sky survey photograph with overlays.\n"
                                      "Drawn chart: a vector star chart (SVG / PDF / PNG / new image)."))
        top.addWidget(self.cmb_style)
        top.addStretch(1)
        outer.addLayout(top)
        self._stack = QStackedWidget()
        self._stack.addWidget(self._survey_page)
        outer.addWidget(self._stack, 1)
        self.cmb_style.currentIndexChanged.connect(self._on_style_changed)
        # finished fires for Close, the title-bar X and Escape alike
        self.finished.connect(lambda _r=0: self._shutdown_sky_panel())
        if self._settings.value(self._STYLE_KEY, "Survey image", type=str) == "Drawn chart":
            QTimer.singleShot(0, lambda: self.cmb_style.setCurrentIndex(1))

    def _on_skychart_overlay_toggled(self, on: bool):
        self._settings.setValue(self._OVERLAY_KEY, bool(on))
        self._schedule_render(force_refetch=False, delay_ms=150)

    def _pick_skychart_layers(self):
        import json as _json
        from setiastro.saspro.skychart_ui import OverlayLayersDialog
        dlg = OverlayLayersDialog(self._skychart_layers, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self._skychart_layers = dlg.layers()
            self._settings.setValue(self._LAYERS_KEY, _json.dumps(self._skychart_layers))
            if not self.chk_skychart.isChecked():
                self.chk_skychart.setChecked(True)      # renders via the toggle
            else:
                self._schedule_render(force_refetch=False, delay_ms=50)

    def _skychart_req_fields(self) -> dict:
        return dict(show_skychart=bool(getattr(self, "chk_skychart", None) is not None
                                       and self.chk_skychart.isChecked()),
                    skychart_layers=dict(getattr(self, "_skychart_layers", {}) or {}))

    def _on_style_changed(self, idx: int):
        self._settings.setValue(self._STYLE_KEY, self.cmb_style.currentText())
        if idx != 1:
            self._stack.setCurrentIndex(0)
            return
        first = self._sky_panel is None
        if first:
            from setiastro.saspro.skychart_ui import SkyChartPanel, AppContext, find_main_window
            mw = find_main_window(self.parent()) or find_main_window(self)
            self._sky_panel = SkyChartPanel(AppContext(mw), parent=self._stack)
            self._stack.addWidget(self._sky_panel)
        self._stack.setCurrentWidget(self._sky_panel)
        if self.width() < 1300 or self.height() < 880:
            self.resize(max(self.width(), 1380), max(self.height(), 920))
        if first:
            QTimer.singleShot(0, self._seed_sky_panel)

    def _seed_sky_panel(self):
        """Point a new drawn chart at what this Finder Chart shows."""
        raise NotImplementedError

    def _shutdown_sky_panel(self):
        if getattr(self, "_sky_panel", None) is not None:
            try:
                self._sky_panel.shutdown()
            except Exception:
                pass

    def _reset_to_factory(self):
        """Survey-page settings back to what a new user gets (self._factory is
        the survey page as built). The Drawn chart page has its own Reset, and
        Style is which page is showing, so neither is touched here."""
        import json as _json
        if not self.btn_render.isEnabled():         # a render is in progress
            return
        # survey, field and size refetch the survey synchronously on every
        # change: restore them quietly and render once at the end
        quiet = [w for w in (self.cmb_survey, getattr(self, "cmb_fov", None),
                             getattr(self, "cmb_size", None), self.sb_px) if w is not None]
        for w in quiet:
            w.blockSignals(True)
        try:
            restore_controls(self._factory)
        finally:
            for w in quiet:
                w.blockSignals(False)
        # sky chart overlay: off, default layers
        self._skychart_layers = {}
        self._settings.setValue(self._LAYERS_KEY, _json.dumps(self._skychart_layers))
        self.chk_skychart.setChecked(False)         # saves via its toggle
        # one render; it refetches only if survey / field / size changed
        self._render_now(force_refetch=False)


class FinderChartFromCoordDialog(_SkyChartHostMixin, QDialog):
    """
    Finder chart driven directly from RA/Dec + user-chosen FOV.
    No document WCS needed — used by WIMS object search.
    """
    def __init__(self, name: str, ra_deg: float, dec_deg: float, settings, parent=None):
        super().__init__(parent)
        try:
            from setiastro.saspro.survey_gradient import reset_dead_hosts
            reset_dead_hosts()
        except Exception:
            pass
        self._name    = name
        self._ra_deg  = float(ra_deg)
        self._dec_deg = float(dec_deg)
        self._settings = settings
        self._last_rgb_u8 = None
        self._hips_cache_key = None
        self._hips_bg  = None
        self._hips_wcs = None
        self._hips_err = None
        self._base_cache_key = None
        self._base_u8  = None
        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.timeout.connect(self._render_debounced_fire)
        self._pending_force_refetch = False

        self.setWindowTitle(self.tr("Finder Chart — {0}").format(name))
        self.setModal(False)
        self.resize(920, 980)

        self._survey_page = QWidget()
        root = QVBoxLayout(self._survey_page)
        root.setContentsMargins(0, 0, 0, 0)

        # Row 1: survey + FOV radius + grid
        row1 = QHBoxLayout()
        row1.addWidget(QLabel(self.tr("Survey:")))
        self.cmb_survey = QComboBox()
        self.cmb_survey.addItems(list(SURVEY_HIPS.keys()))
        row1.addWidget(self.cmb_survey)

        row1.addSpacing(12)
        row1.addWidget(QLabel("FOV:"))
        self.cmb_fov = QComboBox()
        self.cmb_fov.addItems([
            "0.25°", "0.5°", "1°", "1.5°", "2°", "3°", "4°", "6°", "8°", "10°"
        ])
        self.cmb_fov.setCurrentIndex(6)  # default 1°
        row1.addWidget(self.cmb_fov)

        row1.addSpacing(12)
        self.chk_grid = QCheckBox(self.tr("Show grid"))
        row1.addWidget(self.chk_grid)

        row1.addSpacing(12)
        row1.addWidget(QLabel(self.tr("Output px:")))
        self.sb_px = QSpinBox()
        self.sb_px.setRange(300, 2400)
        self.sb_px.setSingleStep(100)
        self.sb_px.setValue(900)
        row1.addWidget(self.sb_px)

        row1.addStretch(1)
        row1.addWidget(make_help_button("finder_chart", self))
        self.btn_render = QPushButton(self.tr("Render"))
        row1.addWidget(self.btn_render)
        root.addLayout(row1)

        # Row 2: overlays
        row2 = QHBoxLayout()
        self.chk_stars = QCheckBox(self.tr("Star names"))
        row2.addWidget(self.chk_stars)
        row2.addWidget(QLabel(self.tr("Mag ≤")))
        self.sb_star_mag = QDoubleSpinBox()
        self.sb_star_mag.setRange(-2.0, 8.0)
        self.sb_star_mag.setSingleStep(0.5)
        self.sb_star_mag.setValue(5.0)
        self.sb_star_mag.setFixedWidth(70)
        row2.addWidget(self.sb_star_mag)

        row2.addSpacing(12)
        self.chk_dso = QCheckBox(self.tr("Deep-sky"))
        row2.addWidget(self.chk_dso)
        self.cmb_dso = QComboBox()
        self.cmb_dso.addItems(["All (DSO)", "M", "NGC", "IC", "Abell", "SH2", "LBN", "LDN", "PN-G"])
        self.cmb_dso.setFixedWidth(140)
        row2.addWidget(self.cmb_dso)
        row2.addWidget(QLabel(self.tr("Mag ≤")))
        self.sb_dso_mag = QDoubleSpinBox()
        self.sb_dso_mag.setRange(-2.0, 30.0)
        self.sb_dso_mag.setSingleStep(0.5)
        self.sb_dso_mag.setValue(12.0)
        self.sb_dso_mag.setFixedWidth(70)
        row2.addWidget(self.sb_dso_mag)

        row2.addSpacing(12)
        self.chk_compass = QCheckBox(self.tr("Compass"))
        self.chk_compass.setChecked(True)
        row2.addWidget(self.chk_compass)
        self.chk_scale = QCheckBox(self.tr("Scale bar"))
        self.chk_scale.setChecked(True)
        row2.addWidget(self.chk_scale)
        row2.addStretch(1)
        root.addLayout(row2)

        # Row 3: Imaging train FOV overlay
        row3 = QHBoxLayout()
        self.chk_fov_box = QCheckBox(self.tr("Show FOV box"))
        row3.addWidget(self.chk_fov_box)

        row3.addSpacing(8)
        row3.addWidget(QLabel(self.tr("Focal length (mm):")))
        self.sb_focal = QDoubleSpinBox()
        self.sb_focal.setRange(1.0, 20000.0)
        self.sb_focal.setDecimals(1)
        self.sb_focal.setSingleStep(50.0)
        self.sb_focal.setValue(500.0)
        self.sb_focal.setFixedWidth(80)
        row3.addWidget(self.sb_focal)

        row3.addSpacing(8)
        row3.addWidget(QLabel(self.tr("Pixel pitch (μm):")))
        self.sb_pitch = QDoubleSpinBox()
        self.sb_pitch.setRange(0.5, 30.0)
        self.sb_pitch.setDecimals(2)
        self.sb_pitch.setSingleStep(0.5)
        self.sb_pitch.setValue(3.76)
        self.sb_pitch.setFixedWidth(70)
        row3.addWidget(self.sb_pitch)

        row3.addSpacing(8)
        row3.addWidget(QLabel(self.tr("Sensor (px W×H):")))
        self.sb_sensor_w = QSpinBox()
        self.sb_sensor_w.setRange(1, 100000)
        self.sb_sensor_w.setValue(6248)
        self.sb_sensor_w.setFixedWidth(70)
        row3.addWidget(self.sb_sensor_w)
        row3.addWidget(QLabel("×"))
        self.sb_sensor_h = QSpinBox()
        self.sb_sensor_h.setRange(1, 100000)
        self.sb_sensor_h.setValue(4176)
        self.sb_sensor_h.setFixedWidth(70)
        row3.addWidget(self.sb_sensor_h)

        row3.addSpacing(8)
        row3.addWidget(QLabel(self.tr("Rotation (°CW):")))
        self.sb_rotation = QDoubleSpinBox()
        self.sb_rotation.setRange(-360.0, 360.0)
        self.sb_rotation.setDecimals(1)
        self.sb_rotation.setSingleStep(1.0)
        self.sb_rotation.setValue(0.0)
        self.sb_rotation.setFixedWidth(65)
        row3.addWidget(self.sb_rotation)

        # Live FOV readout label
        self.lbl_fov_readout = QLabel("")
        self.lbl_fov_readout.setStyleSheet("color:#aaa; font-size:10px;")
        row3.addWidget(self.lbl_fov_readout)

        row3.addStretch(1)
        root.addLayout(row3)

        # Preview
        self.lbl = QLabel()
        self.lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl.setMinimumHeight(700)
        self.lbl.setStyleSheet("QLabel { background:#111; border:1px solid #333; }")
        root.addWidget(self.lbl, 1)

        # Bottom
        brow = QHBoxLayout()
        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("color:#bbb;")
        brow.addWidget(self.lbl_status)
        brow.addStretch(1)
        self.btn_save  = QPushButton(self.tr("Save PNG…"))
        self.btn_reset = make_reset_button(self)
        self.btn_close = QPushButton(self.tr("Close"))
        brow.addWidget(self.btn_save)
        brow.addWidget(self.btn_reset)
        brow.addWidget(self.btn_close)
        root.addLayout(brow)

        # Wiring
        self.btn_render.clicked.connect(lambda: self._render_now(force_refetch=True))
        self.btn_save.clicked.connect(self._save_png)
        self.btn_reset.clicked.connect(self._reset_to_factory)
        self.btn_close.clicked.connect(self.close)
        self.cmb_survey.currentIndexChanged.connect(lambda _=0: self._render_now(force_refetch=True))
        self.cmb_fov.currentIndexChanged.connect(lambda _=0: self._render_now(force_refetch=True))
        self.sb_px.valueChanged.connect(lambda _=0: self._render_now(force_refetch=True))
        self.chk_grid.toggled.connect(lambda _=False: self._schedule_render(force_refetch=False, delay_ms=150))
        self.chk_stars.toggled.connect(lambda _=False: self._schedule_render(force_refetch=False, delay_ms=150))
        self.chk_dso.toggled.connect(lambda _=False: self._schedule_render(force_refetch=False, delay_ms=150))
        self.cmb_dso.currentIndexChanged.connect(lambda _=0: self._schedule_render(force_refetch=False, delay_ms=150))
        self.sb_star_mag.valueChanged.connect(lambda _=0: self._schedule_render(force_refetch=False, delay_ms=150))
        self.sb_dso_mag.valueChanged.connect(lambda _=0: self._schedule_render(force_refetch=False, delay_ms=150))
        self.chk_compass.toggled.connect(lambda _=False: self._schedule_render(force_refetch=False, delay_ms=150))
        self.chk_scale.toggled.connect(lambda _=False: self._schedule_render(force_refetch=False, delay_ms=150))
        self.chk_fov_box.toggled.connect(lambda _=False: self._on_imaging_train_changed())
        self.sb_focal.valueChanged.connect(lambda _=0: self._on_imaging_train_changed())
        self.sb_pitch.valueChanged.connect(lambda _=0: self._on_imaging_train_changed())
        self.sb_sensor_w.valueChanged.connect(lambda _=0: self._on_imaging_train_changed())
        self.sb_sensor_h.valueChanged.connect(lambda _=0: self._on_imaging_train_changed())
        self.sb_rotation.valueChanged.connect(lambda _=0: self._on_imaging_train_changed())

        # focal length, pixel pitch and sensor size are the user's equipment
        self._factory = snapshot_controls(self._survey_page, exclude=(
            self.sb_focal, self.sb_pitch, self.sb_sensor_w, self.sb_sensor_h))
        self._load_imaging_settings()
        self._on_imaging_train_changed()  # update the FOV readout label
        self.lbl.setText(self.tr("Fetching survey background…"))
        self.lbl.setStyleSheet("QLabel { background:#111; border:1px solid #333; color:#ccc; }")
        self._install_sky_chart_host()
        QTimer.singleShot(0, lambda: self._render_now(force_refetch=True))

    def _seed_sky_panel(self):
        p = self._sky_panel
        if p is None or not p._ensure_data():
            return
        p._loading = True
        try:
            p._set_center(self._ra_deg, self._dec_deg)
            p.sp_rot.setValue(0.0)
            p.sp_fov.setValue(round(max(self._fov_deg(), 0.05), 3))
            p.ed_title.setText(str(self._name or ""))
        finally:
            p._loading = False
        p.preview()

    def _load_imaging_settings(self):
        # Load quietly. A change signal renders (survey / FOV / size fetch the
        # survey right away), and _render saves every control, so the saved
        # values not loaded yet would be overwritten with the built-in
        # defaults. __init__ renders once after the load.
        quiet = (self.cmb_survey, self.cmb_fov, self.sb_px, self.chk_grid,
                 self.chk_stars, self.sb_star_mag, self.chk_dso, self.cmb_dso,
                 self.sb_dso_mag, self.chk_compass, self.chk_scale,
                 self.chk_fov_box, self.sb_focal, self.sb_pitch,
                 self.sb_sensor_w, self.sb_sensor_h, self.sb_rotation)
        for w in quiet:
            w.blockSignals(True)
        try:
            self._apply_imaging_settings()
        finally:
            for w in quiet:
                w.blockSignals(False)

    def _apply_imaging_settings(self):
        s = self._settings
        self.cmb_survey.setCurrentText(s.value("finder_coord/survey", "DSS2 (Color)", type=str))
        fov_txt = s.value("finder_coord/fov", "4°", type=str)
        idx = self.cmb_fov.findText(fov_txt)
        self.cmb_fov.setCurrentIndex(idx if idx >= 0 else 6)
        self.sb_px.setValue(s.value("finder_coord/out_px", 900, type=int))
        self.chk_grid.setChecked(s.value("finder_coord/show_grid", False, type=bool))
        self.chk_stars.setChecked(s.value("finder_coord/show_stars", False, type=bool))
        self.sb_star_mag.setValue(s.value("finder_coord/star_mag", 5.0, type=float))
        self.chk_dso.setChecked(s.value("finder_coord/show_dso", False, type=bool))
        idx = self.cmb_dso.findText(s.value("finder_coord/dso_catalog", "All (DSO)", type=str))
        self.cmb_dso.setCurrentIndex(idx if idx >= 0 else 0)
        self.sb_dso_mag.setValue(s.value("finder_coord/dso_mag", 12.0, type=float))
        self.chk_compass.setChecked(s.value("finder_coord/show_compass", True, type=bool))
        self.chk_scale.setChecked(s.value("finder_coord/show_scale", True, type=bool))
        self.chk_fov_box.setChecked(s.value("finder_coord/show_fov_box", False, type=bool))
        self.sb_focal.setValue(s.value("finder_coord/focal_mm", 500.0, type=float))
        self.sb_pitch.setValue(s.value("finder_coord/pixel_pitch", 3.76, type=float))
        self.sb_sensor_w.setValue(s.value("finder_coord/sensor_w", 6248, type=int))
        self.sb_sensor_h.setValue(s.value("finder_coord/sensor_h", 4176, type=int))
        self.sb_rotation.setValue(s.value("finder_coord/rotation", 0.0, type=float))

    def _save_imaging_settings(self):
        s = self._settings
        s.setValue("finder_coord/survey", self.cmb_survey.currentText())
        s.setValue("finder_coord/fov", self.cmb_fov.currentText())
        s.setValue("finder_coord/out_px", self.sb_px.value())
        s.setValue("finder_coord/show_grid", self.chk_grid.isChecked())
        s.setValue("finder_coord/show_stars", self.chk_stars.isChecked())
        s.setValue("finder_coord/star_mag", self.sb_star_mag.value())
        s.setValue("finder_coord/show_dso", self.chk_dso.isChecked())
        s.setValue("finder_coord/dso_catalog", self.cmb_dso.currentText())
        s.setValue("finder_coord/dso_mag", self.sb_dso_mag.value())
        s.setValue("finder_coord/show_compass", self.chk_compass.isChecked())
        s.setValue("finder_coord/show_scale", self.chk_scale.isChecked())
        s.setValue("finder_coord/show_fov_box", self.chk_fov_box.isChecked())
        s.setValue("finder_coord/focal_mm", self.sb_focal.value())
        s.setValue("finder_coord/pixel_pitch", self.sb_pitch.value())
        s.setValue("finder_coord/sensor_w", self.sb_sensor_w.value())
        s.setValue("finder_coord/sensor_h", self.sb_sensor_h.value())
        s.setValue("finder_coord/rotation", self.sb_rotation.value())

    def _fov_deg(self) -> float:
        txt = self.cmb_fov.currentText().replace("°", "").strip()
        try:
            return float(txt)
        except Exception:
            return 1.0

    def _req(self) -> FinderChartRequest:
        return FinderChartRequest(
            survey=str(self.cmb_survey.currentText()),
            scale_mult=1,
            show_grid=bool(self.chk_grid.isChecked()),
            show_star_names=bool(self.chk_stars.isChecked()),
            star_mag_limit=float(self.sb_star_mag.value()),
            star_max_labels=50,
            show_dso=bool(self.chk_dso.isChecked()),
            dso_catalog=str(self.cmb_dso.currentText()),
            dso_mag_limit=float(self.sb_dso_mag.value()),
            dso_max_labels=50,
            show_compass=bool(self.chk_compass.isChecked()),
            show_scale_bar=bool(self.chk_scale.isChecked()),
            out_px=int(self.sb_px.value()),
            overlay_opacity=0.0,
            show_fov_box=bool(self.chk_fov_box.isChecked()),
            focal_length_mm=float(self.sb_focal.value()),
            pixel_pitch_um=float(self.sb_pitch.value()),
            sensor_w_px=int(self.sb_sensor_w.value()),
            sensor_h_px=int(self.sb_sensor_h.value()),
            rotation_deg=float(self.sb_rotation.value()),
            **self._skychart_req_fields(),
        )

    def _on_imaging_train_changed(self):
        """Update the FOV readout label and schedule a re-render."""
        fl = float(self.sb_focal.value())
        pitch = float(self.sb_pitch.value())
        sw = int(self.sb_sensor_w.value())
        sh = int(self.sb_sensor_h.value())
        if fl > 0 and pitch > 0 and sw > 0 and sh > 0:
            fov_w_deg = math.degrees(2 * math.atan((pitch * sw) / (2000.0 * fl)))
            fov_h_deg = math.degrees(2 * math.atan((pitch * sh) / (2000.0 * fl)))
            fov_w_arcmin = fov_w_deg * 60.0
            fov_h_arcmin = fov_h_deg * 60.0
            self.lbl_fov_readout.setText(
                f"  →  {fov_w_arcmin:.1f}′ × {fov_h_arcmin:.1f}′"
            )
        else:
            self.lbl_fov_readout.setText("")
        # No refetch needed — just re-render overlays
        self._schedule_render(force_refetch=False, delay_ms=150)

    def _schedule_render(self, *, force_refetch=False, delay_ms=200):
        if hasattr(self, "lbl_status"):
            self.lbl_status.setText(self.tr("Rendering…"))
            QApplication.processEvents()
        self._pending_force_refetch = self._pending_force_refetch or bool(force_refetch)
        self._render_timer.stop()
        self._render_timer.start(int(delay_ms))

    def _render_debounced_fire(self):
        force = bool(self._pending_force_refetch)
        self._pending_force_refetch = False
        self._render(force_refetch=force)

    def _render_now(self, *, force_refetch=False):
        self._render_timer.stop()
        self._pending_force_refetch = False
        self._render(force_refetch=force_refetch)

    def _set_busy(self, busy: bool, msg: str = "Rendering…"):
        self.btn_render.setEnabled(not busy)
        self.btn_save.setEnabled((not busy) and (self._last_rgb_u8 is not None))
        if hasattr(self, "lbl_status"):
            self.lbl_status.setText(msg if busy else "")
        QApplication.processEvents()

    def _render(self, *, force_refetch=False):
        import math as _math
        from astropy.coordinates import SkyCoord as _SkyCoord
        import astropy.units as _u

        self._save_imaging_settings()

        self._set_busy(True, self.tr("Fetching survey background…"))
        try:
            req    = self._req()
            fov    = self._fov_deg()
            out_px = int(req.out_px)
            center = _SkyCoord(self._ra_deg * _u.deg, self._dec_deg * _u.deg, frame="icrs")

            # Fetch with overscan so crop doesn't cut the edges
            s          = float(_math.sqrt(2.0) * 1.02)
            fetch_px   = int(_math.ceil(out_px * s))
            fetch_fov  = fov * s

            cache_key = (
                str(req.survey), fetch_px,
                round(self._ra_deg, 8), round(self._dec_deg, 8),
                round(fetch_fov, 8),
            )

            if force_refetch or self._hips_cache_key != cache_key or self._hips_bg is None:
                bg_big, wcs_big, err = try_fetch_hips_cutout(
                    center, fov_deg=fetch_fov,
                    out_px=fetch_px, survey_label=req.survey
                )
                if bg_big is not None:
                    bg, wcs_c, _ = _crop_center(bg_big, wcs_big, out_px)
                else:
                    bg, wcs_c = None, None
                self._hips_cache_key = cache_key
                self._hips_bg  = bg
                self._hips_wcs = wcs_c
                self._hips_err = err
                # invalidate base raster
                self._base_cache_key = None
                self._base_u8 = None

            # Build base raster (no doc overlay — just the background)
            base_key = (self._hips_cache_key,)
            if self._base_cache_key != base_key:
                if self._hips_bg is not None:
                    self._base_u8 = (
                        np.clip(self._hips_bg, 0, 1) * 255.0 + 0.5
                    ).astype(np.uint8)
                else:
                    self._base_u8 = None
                self._base_cache_key = base_key

            # Synthesize corners from center + fov for render_finder_chart_cached
            # (footprint polygon won't draw but everything else works)
            half = fov / 2.0
            import astropy.units as au
            from astropy.coordinates import SkyCoord as SC
            corners = SC(
                ra =[self._ra_deg - half, self._ra_deg + half,
                     self._ra_deg + half, self._ra_deg - half] * au.deg,
                dec=[self._dec_deg - half, self._dec_deg - half,
                     self._dec_deg + half, self._dec_deg + half] * au.deg,
                frame="icrs"
            )
            center_arr = SC(self._ra_deg * au.deg, self._dec_deg * au.deg, frame="icrs")

            # Dummy doc_image / doc_wcs (not used when overlay_opacity=0)
            dummy_img = np.zeros((3, 3, 3), dtype=np.float32)

            rgb = render_finder_chart_cached(
                doc_image=dummy_img,
                doc_wcs=None,
                corners=corners,
                center=[center_arr],
                fov_deg=fov,
                req=req,
                bg=self._hips_bg,
                bg_wcs=self._hips_wcs,
                err=self._hips_err,
                base_u8=self._base_u8,
            )

            self._last_rgb_u8 = rgb
            qimg = _rgb_u8_to_qimage(rgb).copy()
            self.lbl.setPixmap(QPixmap.fromImage(qimg))

        except Exception as e:
            QMessageBox.critical(self, self.tr("Finder Chart"), str(e))
        finally:
            self._set_busy(False)

    def _save_png(self):
        if self._last_rgb_u8 is None:
            return
        start = ""
        try:
            start = self._settings.value("finder_chart/last_dir", "", type=str) or ""
        except Exception:
            pass
        fn, _ = QFileDialog.getSaveFileName(self, self.tr("Save Finder Chart"), start, "PNG Image (*.png)")
        if not fn:
            return
        if not fn.lower().endswith(".png"):
            fn += ".png"
        qimg = _rgb_u8_to_qimage(self._last_rgb_u8).copy()
        if qimg.save(fn, "PNG"):
            try:
                self._settings.setValue("finder_chart/last_dir", fn)
            except Exception:
                pass

class FinderChartDialog(_SkyChartHostMixin, QDialog):
    """
    Minimal v1 Finder Chart dialog:
    - Survey dropdown
    - Size multiplier dropdown
    - Show grid checkbox
    - Render preview
    - Save PNG
    - Send to New Document (push into SASpro)
    """
    def __init__(self, doc, settings, parent=None):
        super().__init__(parent)
        try:
            from setiastro.saspro.survey_gradient import reset_dead_hosts
            reset_dead_hosts()
        except Exception:
            pass
        self._doc = doc
        self._settings = settings
        self._last_rgb_u8: Optional[np.ndarray] = None
        # ---- HiPS cache (avoid refetching for UI-only changes) ----
        self._hips_cache_key = None
        self._hips_bg = None          # float01 RGB background
        self._hips_wcs = None         # celestial WCS for background
        self._hips_err = None
        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.timeout.connect(self._render_debounced_fire)
        self._pending_force_refetch = False
        self._base_cache_key = None
        self._base_u8 = None        
        # Cached geometry derived from the current doc WCS (used for overlays/labels)
        self._doc_wcs_cached = None
        self._corners_cached = None
        self._center_cached = None
        self._fov_deg_cached = None
        self.setWindowTitle(self.tr("Finder Chart…"))
        self.setModal(False)
        self.resize(920, 980)

        self._survey_page = QWidget()
        root = QVBoxLayout(self._survey_page)
        root.setContentsMargins(0, 0, 0, 0)

        # controls row 1 (primary)
        row1 = QHBoxLayout()

        row1.addWidget(QLabel(self.tr("Survey:")))
        self.cmb_survey = QComboBox()
        self.cmb_survey.clear()
        self.cmb_survey.addItems(list(SURVEY_HIPS.keys()))
        row1.addWidget(self.cmb_survey)

        row1.addSpacing(12)
        row1.addWidget(QLabel(self.tr("Size:")))
        self.cmb_size = QComboBox()
        self.cmb_size.addItems([self.tr("2× FOV"), self.tr("4× FOV"), self.tr("8× FOV")])
        row1.addWidget(self.cmb_size)

        row1.addSpacing(12)
        self.chk_grid = QCheckBox(self.tr("Show grid"))
        row1.addWidget(self.chk_grid)

        row1.addSpacing(12)
        row1.addWidget(QLabel(self.tr("Output px:")))
        self.sb_px = QSpinBox()
        self.sb_px.setRange(300, 2400)
        self.sb_px.setSingleStep(100)
        self.sb_px.setValue(900)
        row1.addWidget(self.sb_px)
        row1.addSpacing(12)
        row1.addWidget(QLabel(self.tr("Image opacity:")))
        self.sld_opacity = QSlider(Qt.Orientation.Horizontal)
        self.sld_opacity.setRange(0, 100)
        self.sld_opacity.setValue(35)
        self.sld_opacity.setFixedWidth(140)
        row1.addWidget(self.sld_opacity)

        self.lbl_opacity = QLabel("35%")
        self.lbl_opacity.setFixedWidth(40)
        row1.addWidget(self.lbl_opacity)
        row1.addStretch(1)
        row1.addWidget(make_help_button("finder_chart", self))
        self.btn_render = QPushButton(self.tr("Render"))
        row1.addWidget(self.btn_render)


        root.addLayout(row1)

        # controls row 2 (overlays)
        row2 = QHBoxLayout()

        self.chk_stars = QCheckBox(self.tr("Star names"))
        row2.addWidget(self.chk_stars)

        row2.addSpacing(8)
        row2.addWidget(QLabel(self.tr("Star ≤")))
        self.sb_star_mag = QDoubleSpinBox()
        self.sb_star_mag.setRange(-2.0, 8.0)
        self.sb_star_mag.setSingleStep(0.5)
        self.sb_star_mag.setValue(5.0)
        self.sb_star_mag.setFixedWidth(70)
        row2.addWidget(self.sb_star_mag)

        row2.addWidget(QLabel(self.tr("Max")))
        self.sb_star_max = QSpinBox()
        self.sb_star_max.setRange(5, 200)
        self.sb_star_max.setValue(30)
        self.sb_star_max.setFixedWidth(60)
        row2.addWidget(self.sb_star_max)

        row2.addSpacing(12)
        self.chk_dso = QCheckBox(self.tr("Deep-sky"))
        row2.addWidget(self.chk_dso)

        self.cmb_dso = QComboBox()
        self.cmb_dso.addItems(["All (DSO)", "M", "NGC", "IC", "Abell", "SH2", "LBN", "LDN", "PN-G"])
        self.cmb_dso.setFixedWidth(170)
        row2.addWidget(self.cmb_dso)

        row2.addWidget(QLabel(self.tr("Mag ≤")))
        self.sb_dso_mag = QDoubleSpinBox()
        self.sb_dso_mag.setRange(-2.0, 30.0)
        self.sb_dso_mag.setSingleStep(0.5)
        self.sb_dso_mag.setValue(12.0)
        self.sb_dso_mag.setFixedWidth(70)
        row2.addWidget(self.sb_dso_mag)

        row2.addWidget(QLabel(self.tr("Max")))
        self.sb_dso_max = QSpinBox()
        self.sb_dso_max.setRange(5, 300)
        self.sb_dso_max.setValue(30)
        self.sb_dso_max.setFixedWidth(60)
        row2.addWidget(self.sb_dso_max)

        row2.addSpacing(12)
        self.chk_compass = QCheckBox(self.tr("Compass"))
        self.chk_compass.setChecked(True)
        row2.addWidget(self.chk_compass)

        self.chk_scale = QCheckBox(self.tr("Scale bar"))
        self.chk_scale.setChecked(True)
        row2.addWidget(self.chk_scale)



        row2.addStretch(1)
        root.addLayout(row2)

        # preview
        self.lbl = QLabel()
        self.lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl.setMinimumHeight(700)
        self.lbl.setStyleSheet("QLabel { background:#111; border:1px solid #333; }")
        root.addWidget(self.lbl, 1)

        # buttons
        brow = QHBoxLayout()

        self.lbl_status = QLabel("")                 # <-- NEW
        self.lbl_status.setStyleSheet("color:#bbb;") # subtle
        self.lbl_status.setMinimumWidth(160)
        brow.addWidget(self.lbl_status)              # <-- NEW

        brow.addStretch(1)

        self.btn_send = QPushButton(self.tr("Send to New Document"))
        self.btn_save = QPushButton(self.tr("Save PNG…"))
        self.btn_reset = make_reset_button(self)
        self.btn_close = QPushButton(self.tr("Close"))
        brow.addWidget(self.btn_send)
        brow.addWidget(self.btn_save)
        brow.addWidget(self.btn_reset)
        brow.addWidget(self.btn_close)
        root.addLayout(brow)

        self.btn_render.clicked.connect(lambda: self._render_now(force_refetch=True))
        self.btn_save.clicked.connect(self._save_png)
        self.btn_send.clicked.connect(self._send_to_new_doc)
        self.btn_reset.clicked.connect(self._reset_to_factory)
        self.btn_close.clicked.connect(self.close)

        # grid: debounced (no refetch)
        self.chk_grid.toggled.connect(lambda _=False: self._schedule_render(force_refetch=False, delay_ms=150))

        # survey/size/px: immediate refetch (or debounce if you want, but refetch is required)
        self.cmb_survey.currentIndexChanged.connect(lambda _=0: self._render_now(force_refetch=True))
        self.cmb_size.currentIndexChanged.connect(lambda _=0: self._render_now(force_refetch=True))
        self.sb_px.valueChanged.connect(lambda _=0: self._render_now(force_refetch=True))

        # opacity: update label + debounce render (no refetch)
        self.sld_opacity.valueChanged.connect(self._on_opacity_changed)
        self.sld_opacity.sliderReleased.connect(lambda: self._render_now(force_refetch=False))
        # auto render once
        # placeholder so the user sees *something* immediately
        self.lbl.setText(self.tr("Fetching survey background…"))
        self.lbl.setStyleSheet("QLabel { background:#111; border:1px solid #333; color:#ccc; }")
        # --- overlay enable/disable: update enabled state + one refresh ---
        self.chk_stars.toggled.connect(lambda _=False: (self._set_overlay_controls_enabled(),
                                                       self._schedule_render(force_refetch=False, delay_ms=150)))

        self.chk_dso.toggled.connect(lambda _=False: (self._set_overlay_controls_enabled(),
                                                     self._schedule_render(force_refetch=False, delay_ms=150)))

        # --- star params: ONLY refresh if Star names is ON ---
        self.sb_star_mag.valueChanged.connect(lambda _=0: self._maybe_schedule_stars(150))
        self.sb_star_max.valueChanged.connect(lambda _=0: self._maybe_schedule_stars(150))

        # --- dso params: ONLY refresh if Deep-sky is ON ---
        self.cmb_dso.currentIndexChanged.connect(lambda _=0: self._maybe_schedule_dso(150))
        self.sb_dso_mag.valueChanged.connect(lambda _=0: self._maybe_schedule_dso(150))
        self.sb_dso_max.valueChanged.connect(lambda _=0: self._maybe_schedule_dso(150))

        self.chk_compass.toggled.connect(lambda _=False: self._schedule_render(force_refetch=False, delay_ms=150))
        self.chk_scale.toggled.connect(lambda _=False: self._schedule_render(force_refetch=False, delay_ms=150))

        self._set_overlay_controls_enabled()
        self._factory = snapshot_controls(self._survey_page)     # before the saved overlay state
        self._install_sky_chart_host()
        # kick initial render AFTER the dialog has had a chance to show/paint
        QTimer.singleShot(0, self._initial_render)

    def _seed_sky_panel(self):
        # centre, field, rotation, mirroring and outline from this image's own WCS
        p = self._sky_panel
        if p is None:
            return
        title = ""
        try:
            dn = getattr(self._doc, "display_name", None)
            title = str(dn() if callable(dn) else (dn or ""))
        except Exception:
            title = ""
        p.from_image(doc=self._doc, title=title)

    def _maybe_schedule_stars(self, delay_ms: int = 150):
        # Only auto-refresh if the overlay is enabled
        if not self.chk_stars.isChecked():
            return
        self._schedule_render(force_refetch=False, delay_ms=delay_ms)

    def _maybe_schedule_dso(self, delay_ms: int = 150):
        # Only auto-refresh if the overlay is enabled
        if not self.chk_dso.isChecked():
            return
        self._schedule_render(force_refetch=False, delay_ms=delay_ms)

    def _set_overlay_controls_enabled(self):
        stars_on = self.chk_stars.isChecked()
        self.sb_star_mag.setEnabled(stars_on)
        self.sb_star_max.setEnabled(stars_on)

        dso_on = self.chk_dso.isChecked()
        self.cmb_dso.setEnabled(dso_on)
        self.sb_dso_mag.setEnabled(dso_on)
        self.sb_dso_max.setEnabled(dso_on)


    def _set_busy(self, busy: bool, msg: str = "Rendering…"):
        self.btn_render.setEnabled(not busy)
        self.btn_send.setEnabled((not busy) and (self._last_rgb_u8 is not None))
        self.btn_save.setEnabled((not busy) and (self._last_rgb_u8 is not None))

        if hasattr(self, "lbl_status") and self.lbl_status is not None:
            self.lbl_status.setText(msg if busy else "")
            self.lbl_status.setVisible(True)

        # ensures the label paints immediately before heavy work
        QApplication.processEvents()


    def _initial_render(self):
        self._set_busy(True, self.tr("Fetching survey background…"))
        # schedule again so the UI paints the busy message + cursor first
        QTimer.singleShot(0, lambda: self._render_now(force_refetch=True))


    def _schedule_render(self, *, force_refetch: bool = False, delay_ms: int = 200):
        # show immediate feedback during debounce
        if hasattr(self, "lbl_status") and self.lbl_status is not None:
            self.lbl_status.setText(self.tr("Rendering…"))
            QApplication.processEvents()

        self._pending_force_refetch = self._pending_force_refetch or bool(force_refetch)
        self._render_timer.stop()
        self._render_timer.start(int(delay_ms))

    def _render_debounced_fire(self):
        force = bool(self._pending_force_refetch)
        self._pending_force_refetch = False
        self._render(force_refetch=force)

    def _render_now(self, *, force_refetch: bool = False):
        # Cancel any pending debounced render and render immediately
        self._render_timer.stop()
        self._pending_force_refetch = False
        self._render(force_refetch=force_refetch)


    def _compute_doc_geometry(self, img: np.ndarray, meta: dict, req: FinderChartRequest):
        doc_wcs = get_doc_wcs(meta)
        if doc_wcs is None:
            return None, None, None, None

        H, Wimg = img.shape[:2]
        corners, center = image_footprint_sky(doc_wcs, Wimg, H)
        fov_w, fov_h = estimate_fov_deg(corners)
        fov = max(fov_w, fov_h) * float(req.scale_mult)
        return doc_wcs, corners, center, float(fov)

    def _ensure_hips_background(self, req: FinderChartRequest, center: SkyCoord, fov_deg: float, *, force: bool = False):
        # Overscan factor: enough to cover the half-diagonal circle of the final square
        # sqrt(2) covers exactly; add a hair for safety near edges.
        s = float(math.sqrt(2.0) * 1.02)

        out_px = int(req.out_px)
        fetch_px = int(math.ceil(out_px * s))

        # IMPORTANT: scale FOV by the same factor so arcsec/px stays the same
        fetch_fov = float(fov_deg) * s

        # Cache key must reflect the *fetch* parameters, not just final output
        key = (
            str(req.survey),
            int(fetch_px),
            round(float(center.ra.deg), 8),
            round(float(center.dec.deg), 8),
            round(float(fetch_fov), 8),
        )

        if (not force) and (self._hips_cache_key == key) and (self._hips_bg is not None):
            return

        bg_big, wcs_big, err = try_fetch_hips_cutout(
            center,
            fov_deg=fetch_fov,
            out_px=fetch_px,
            survey_label=req.survey,
        )

        if bg_big is not None:
            # Crop back down to the user-requested size, and shift WCS accordingly
            bg, wcs_cropped, _ = _crop_center(bg_big, wcs_big, out_px)
        else:
            bg, wcs_cropped = None, None

        self._hips_cache_key = key
        self._hips_bg = bg
        self._hips_wcs = wcs_cropped
        self._hips_err = err


    def _doc_key(self, img: np.ndarray, meta: dict) -> tuple:
        # cheap-ish: shape + metadata wcs fingerprint (or header checksum if you have one)
        w = meta.get("wcs")
        w_id = id(w) if w is not None else id(meta.get("original_header") or meta.get("fits_header") or meta.get("header"))
        return (img.shape, w_id, int(self.cmb_size.currentIndex()))  # size affects scale_mult

    def _compute_doc_geometry_cached(self, img, meta, req):
        key = self._doc_key(img, meta)
        if getattr(self, "_geom_cache_key", None) == key and self._doc_wcs_cached is not None:
            return self._doc_wcs_cached, self._corners_cached, self._center_cached, self._fov_deg_cached

        doc_wcs, corners, center, fov_deg = self._compute_doc_geometry(img, meta, req)
        self._geom_cache_key = key
        self._doc_wcs_cached, self._corners_cached, self._center_cached, self._fov_deg_cached = doc_wcs, corners, center, fov_deg
        return doc_wcs, corners, center, fov_deg


    def _req(self) -> FinderChartRequest:
        survey = str(self.cmb_survey.currentText())
        mult = {0: 2, 1: 4, 2: 8}.get(int(self.cmb_size.currentIndex()), 2)
        show_grid = bool(self.chk_grid.isChecked())
        out_px = int(self.sb_px.value())
        overlay_opacity = float(self.sld_opacity.value()) / 100.0

        return FinderChartRequest(
            survey=survey,
            scale_mult=mult,
            show_grid=show_grid,

            show_star_names=bool(self.chk_stars.isChecked()),
            star_mag_limit=float(self.sb_star_mag.value()),
            star_max_labels=int(self.sb_star_max.value()),

            show_dso=bool(self.chk_dso.isChecked()),
            dso_catalog=str(self.cmb_dso.currentText()),
            dso_mag_limit=float(self.sb_dso_mag.value()),
            dso_max_labels=int(self.sb_dso_max.value()),

            show_compass=bool(self.chk_compass.isChecked()),
            show_scale_bar=bool(self.chk_scale.isChecked()),

            out_px=out_px,
            overlay_opacity=overlay_opacity,
            **self._skychart_req_fields(),
        )


    def _render(self, *, force_refetch: bool = False):
        self._set_busy(True, self.tr("Rendering finder chart…"))
        try:
            img = np.asarray(self._doc.image)
            meta = dict(getattr(self._doc, "metadata", None) or {})
            req = self._req()

            # 1) compute geometry from doc WCS
            doc_wcs, corners, center, fov_deg = self._compute_doc_geometry_cached(img, meta, req)
            if doc_wcs is None:
                hdr = _best_header_from_meta(meta)
                print("[FinderChart] header cards:", 0 if hdr is None else len(hdr))
                print("[FinderChart] has CTYPE1:", False if hdr is None else ("CTYPE1" in hdr))
                print("[FinderChart] meta keys sample:", list(meta.keys())[:20])                
                QMessageBox.warning(self, self.tr("Finder Chart"), self.tr("Could not render finder chart (missing WCS)."))
                return

            # cache these for reuse (overlay / footprint / labels)
            self._doc_wcs_cached = doc_wcs
            self._corners_cached = corners
            self._center_cached = center
            self._fov_deg_cached = fov_deg

            # 2) fetch background only if needed
            self._ensure_hips_background(req, center[0], fov_deg, force=force_refetch)
            # 2.5) build/cache base raster (NO re-warp on overlay toggles)
            self._ensure_base_raster(req, img, doc_wcs, corners, center, fov_deg)
            # 3) render using cached background (NO network)


            rgb = render_finder_chart_cached(
                doc_image=img,
                doc_wcs=doc_wcs,
                corners=corners,
                center=center,
                fov_deg=fov_deg,
                req=req,
                bg=self._hips_bg,
                bg_wcs=self._hips_wcs,
                err=self._hips_err,
                base_u8=self._base_u8,
            )

            self._last_rgb_u8 = rgb
            qimg = _rgb_u8_to_qimage(rgb).copy()
            self.lbl.setPixmap(QPixmap.fromImage(qimg))

        except Exception as e:
            QMessageBox.critical(self, self.tr("Finder Chart"), str(e))
        finally:
            self._set_busy(False)

    def _ensure_base_raster(self, req, img, doc_wcs, corners, center, fov_deg):
        doc_sig = (img.shape, str(type(self._doc)), id(self._doc))
        base_key = (
            self._hips_cache_key,                 # ties to survey/out_px/center/fov
            round(req.overlay_opacity, 4),
            id(doc_wcs),
            doc_sig,
        )
        if getattr(self, "_base_cache_key", None) == base_key:
            return

        if self._hips_bg is None:
            self._base_u8 = None
            self._base_cache_key = base_key
            return

        if self._hips_wcs is not None and req.overlay_opacity > 0:
            self._base_u8 = _overlay_doc_on_bg(self._hips_bg, self._hips_wcs, img, doc_wcs, alpha=req.overlay_opacity)
        else:
            self._base_u8 = (np.clip(self._hips_bg, 0, 1) * 255.0 + 0.5).astype(np.uint8)

        self._base_cache_key = base_key


    def _on_opacity_changed(self, v: int):
        self.lbl_opacity.setText(f"{int(v)}%")
        self._schedule_render(delay_ms=200)  # no force refetch


    def _save_png(self):
        if self._last_rgb_u8 is None:
            QMessageBox.information(self, self.tr("Finder Chart"), self.tr("Nothing rendered yet."))
            return

        start_dir = ""
        try:
            start_dir = self._settings.value("finder_chart/last_dir", "", type=str) or ""
        except Exception:
            start_dir = ""

        fn, _ = QFileDialog.getSaveFileName(self, self.tr("Save Finder Chart"), start_dir, "PNG Image (*.png)")
        if not fn:
            return

        try:
            if not fn.lower().endswith(".png"):
                fn += ".png"
            qimg = _rgb_u8_to_qimage(self._last_rgb_u8).copy()
            ok = qimg.save(fn, "PNG")
            if not ok:
                raise RuntimeError("QImage.save() failed.")
            try:
                self._settings.setValue("finder_chart/last_dir", fn)
                self._settings.sync()
            except Exception:
                pass
        except Exception as e:
            QMessageBox.critical(self, self.tr("Finder Chart"), str(e))

    def _send_to_new_doc(self):
        if self._last_rgb_u8 is None:
            QMessageBox.information(self, self.tr("Finder Chart"), self.tr("Nothing rendered yet."))
            return

        img01 = self._last_rgb_u8.astype(np.float32) / 255.0

        req = self._req()
        meta = {
            "step_name": "Finder Chart",
            "finder_chart": {
                "survey": req.survey,
                "scale_mult": req.scale_mult,
                "show_grid": req.show_grid,
                "out_px": req.out_px,
                "overlay_opacity": req.overlay_opacity,
            },
        }

        dm = self._get_doc_manager()
        if dm is None:
            QMessageBox.warning(self, self.tr("Finder Chart"), self.tr("DocManager not found."))
            return

        title = f"Finder Chart ({req.survey})"

        try:
            if hasattr(dm, "open_array"):
                # matches PerfectPalettePicker
                dm.open_array(img01, metadata=meta, title=title)
                return

            if hasattr(dm, "create_document"):
                # PPP fallback
                doc = dm.create_document(image=img01, metadata=meta, name=title)
                if hasattr(dm, "add_document"):
                    dm.add_document(doc)
                return

            raise RuntimeError("DocManager lacks open_array/create_document")

        except Exception as e:
            QMessageBox.critical(self, self.tr("Finder Chart"), self.tr("Failed to open new view:\n{0}").format(e))


    def _get_doc_manager(self):
        mw = self.parent()
        if mw is None:
            return None
        return getattr(mw, "docman", None) or getattr(mw, "doc_manager", None)

    