# src/setiastro/saspro/start_panel.py
# SetiAstro Suite Pro  ·  Franklin Marek  ·  www.setiastro.com
"""
The start panel: what an empty workspace offers. Open, process, blink, plan, a
stacker for each kind of imaging (deep sky, smart telescope, planetary), and the
last twelve images as thumbnails in a row that scrolls sideways (or, with none
yet, a way in for someone new). It goes when an image opens and comes back when
the last one closes.

The tiles are those until someone changes them: Customize… (the dashed tile,
while there is room for another, else the link at the bottom, or a tile's
right-click) puts any tool on, up to eight, in any order. Saved as command ids;
never changed, it follows SASpro's own choice, so a later version's new default
tile reaches everyone who kept theirs.

It never covers a desktop shortcut, the setup reminder or the First Steps card:
it moves aside, then drops its second half, then stays away. The ✕ closes it for
the rest of the session and View > Start Panel brings it back. With "Show on
startup" off (here or in Preferences) it only comes when asked for, that one time.
With images open, View > Start Panel puts it up over them until something is
chosen from it, the workspace is clicked, Esc, or an image opens or closes.

Thumbnails are small JPEGs in the SASpro data folder, one per recent image,
made from the open image. One with no open image to take it from (never open
in this version, or a saved copy) is read from its file: FITS and XISF through
Blink's downsampled reader, PNG/JPEG/WebP through Qt, a camera RAW's own
preview, and anything else SASpro opens (TIFF, PSD, compressed FITS) through
its loader at full size, once per change to the file. All of that, down to
asking whether a file exists, is on a worker thread: a recent image can be on a
drive that isn't there.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import queue
import threading
from pathlib import Path

import numpy as np
from PyQt6.QtCore import (QCoreApplication, QEvent, QObject, QPoint, QPointF, QRect,
                          QRectF, QSize, QStandardPaths, Qt, QTimer, QUrl, pyqtSignal)
from PyQt6.QtGui import (QColor, QDesktopServices, QFontMetrics, QIcon, QImage,
                         QImageReader, QKeySequence, QPainter, QPainterPath, QPen, QPixmap)
from PyQt6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QDialog,
                             QDialogButtonBox, QFrame, QGridLayout, QHBoxLayout, QLabel,
                             QLineEdit, QListWidget, QListWidgetItem, QMenu, QPushButton,
                             QScrollArea, QVBoxLayout, QWidget)

from setiastro.saspro.widgets.theme_colors import (CARD_RADIUS, CONTROL_RADIUS, PALETTE_EVENTS,
                                                   restyle, theme_colors)

STARTUP_KEY = "ui/start_panel"                   # show on startup
RELEASES_URL = "https://github.com/setiastro/setiastrosuitepro/releases/latest"
TUTORIAL_URL = "https://youtu.be/zBUOZl2OgaY"     # the welcome window's beginner video

RECENTS = 12                     # shown, in a row that scrolls sideways
PROJECTS = 10                    # in the popup; File > Open Recent Projects has the rest
THUMB = QSize(184, 112)          # logical size; the files hold twice that
WIDTH = 1020                     # four tiles across, the English text whole
COLUMNS = 4
FOUR_ACROSS = 880                # narrower than this, three across
GAP = 10                         # kept clear around shortcuts and cards
TILES_KEY = "ui/start_panel_tiles"   # JSON list of tile ids; not there = DEFAULT_TILES
MAX_TILES = 8
# Command ids (ToolbarMixin's reg(...)), and "sp." for the two tiles that ask
# which tool first.
DEFAULT_TILES = ("open", "workflows", "blink", "whats_in_my_sky",
                 "sp.deep_sky", "sp.mosaics", "planetary_stacker")
LINEAR_MEDIAN = 0.08             # as first_steps_tour: below this, unstretched


def _t(text: str) -> str:
    return QCoreApplication.translate("StartPanel", text)


def _style() -> str:
    """The panel and its popups. Sizes here, colours from the theme
    (widgets/theme_colors.py), so it is built again when the theme changes.
    The first tile, the one to start with, is in the selection colour. The
    check box has no background rule: one blanks Fusion's box, leaving a bare tick."""
    c = {k: v.name() for k, v in vars(theme_colors()).items() if isinstance(v, QColor)}
    r = CONTROL_RADIUS
    return f"""
#StartPanel {{ background-color: {c['window']}; border: 1px solid {c['border']}; border-radius: {CARD_RADIUS}px; }}
#sp_h {{ color: {c['text']}; font-size: 20px; font-weight: 700; background: transparent; }}
#sp_k {{ color: {c['soft']}; font-size: 11px; font-weight: 700; background: transparent; }}
#sp_s {{ color: {c['soft']}; font-size: 12px; background: transparent; }}
#sp_tile_t {{ color: {c['text']}; font-size: 13px; font-weight: 600; background: transparent; }}
#sp_tile_s {{ color: {c['soft']}; font-size: 11px; background: transparent; }}
#sp_tile_more {{ color: {c['soft']}; font-size: 12px; background: transparent; }}
QPushButton#sp_tile {{ background-color: {c['raised']}; border: 1px solid {c['line']}; border-radius: {r}px; }}
QPushButton#sp_tile:hover, QPushButton#sp_tile:focus {{ background-color: {c['hover']}; border-color: {c['accent']}; }}
QPushButton#sp_tile[main="true"] {{ background-color: {c['accent']}; border-color: {c['accent']}; }}
QPushButton#sp_tile[main="true"]:hover, QPushButton#sp_tile[main="true"]:focus {{
    background-color: {c['accent_hover']}; border-color: {c['on_accent_soft']}; }}
QPushButton#sp_tile[main="true"] #sp_tile_t {{ color: {c['on_accent']}; }}
QPushButton#sp_tile[main="true"] #sp_tile_s {{ color: {c['on_accent_soft']}; }}
QPushButton#sp_tile:disabled {{ background-color: {c['window']}; border-color: {c['line']}; }}
#sp_tile_t:disabled, #sp_tile_s:disabled {{ color: {c['muted']}; }}
QPushButton#sp_tile_add {{ background: transparent; border: none; border-radius: {r}px; }}
QPushButton#sp_tile_add:hover, QPushButton#sp_tile_add:focus {{ background-color: {c['raised']}; }}
QPushButton#sp_tile_add #sp_tile_t {{ color: {c['soft']}; }}
QPushButton#sp_proj {{ background: transparent; border: none; border-radius: {r}px; }}
QPushButton#sp_proj:hover, QPushButton#sp_proj:focus {{ background-color: {c['hover']}; }}
#sp_proj_more {{ color: {c['link']}; font-size: 13px; background: transparent; }}
#sp_rule {{ background-color: {c['line']}; border: none; }}
QScrollArea#sp_strip {{ background: transparent; border: none; }}
#sp_strip_row {{ background: transparent; }}
QScrollArea#sp_strip QScrollBar:horizontal {{ height: 10px; margin: 4px 6px 0 6px;
    background: transparent; border: none; }}
QScrollArea#sp_strip QScrollBar::handle:horizontal {{ background: {c['border']}; border-radius: 3px;
    min-width: 40px; }}
QScrollArea#sp_strip QScrollBar::handle:horizontal:hover {{ background: {c['soft']}; }}
QScrollArea#sp_strip QScrollBar::add-line:horizontal, QScrollArea#sp_strip QScrollBar::sub-line:horizontal {{
    width: 0; height: 0; border: none; background: none; }}
QScrollArea#sp_strip QScrollBar::add-page:horizontal, QScrollArea#sp_strip QScrollBar::sub-page:horizontal {{
    background: transparent; }}
QPushButton#sp_recent {{ background: transparent; border: none; border-radius: {r}px; }}
QPushButton#sp_recent:hover, QPushButton#sp_recent:focus {{ background-color: {c['hover']}; }}
QPushButton#sp_link {{ background: transparent; border: none; color: {c['link']}; font-size: 12px; padding: 2px; }}
QPushButton#sp_link:hover, QPushButton#sp_link:focus {{ text-decoration: underline; }}
QPushButton#sp_x {{ background: transparent; border: none; border-radius: {r}px; color: {c['muted']}; font-size: 14px; }}
QPushButton#sp_x:hover, QPushButton#sp_x:focus {{ color: {c['text']}; background-color: {c['hover']}; }}
QCheckBox#sp_startup {{ color: {c['soft']}; font-size: 12px; spacing: 6px; }}
QCheckBox#sp_startup:hover, QCheckBox#sp_startup:focus {{ color: {c['text']}; }}
"""


# ── thumbnails ──────────────────────────────────────────────────────────────

def thumbnails_dir() -> Path:
    from setiastro.saspro import settings_sandbox
    box = settings_sandbox.active()
    if box:
        return Path(box) / "recent_thumbnails"
    base = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.GenericDataLocation)
    return Path(base) / "SASpro" / "recent_thumbnails"


def thumbnail_file(path: str) -> Path:
    name = os.path.normcase(os.path.abspath(path))
    return thumbnails_dir() / (hashlib.sha1(name.encode("utf-8", "replace")).hexdigest() + ".jpg")


def render_thumbnail(image) -> QImage | None:
    """A cover-cropped, display-stretched thumbnail of an image array."""
    import cv2
    a = np.asarray(image)
    if a.ndim == 3 and a.shape[2] not in (3, 4):
        a = a[..., 0]
    if a.ndim == 3:
        a = a[..., :3]
    if a.ndim != 2 and a.ndim != 3 or min(a.shape[:2]) < 8:
        return None
    w, h = THUMB.width() * 2, THUMB.height() * 2
    # Strided first, leaving four times the pixels for the averaging below.
    step = max(1, min(a.shape[0] // (2 * h), a.shape[1] // (2 * w)))
    kind = a.dtype
    a = np.array(a[::step, ::step], dtype=np.float32)
    np.nan_to_num(a, copy=False, nan=0.0, posinf=1.0, neginf=0.0)
    if np.issubdtype(kind, np.integer):
        a /= float(np.iinfo(kind).max)
    else:
        top = float(a.max())
        if top > 1.0:
            a /= top
    np.clip(a, 0.0, 1.0, out=a)
    scale = max(w / a.shape[1], h / a.shape[0])
    size = (max(w, round(a.shape[1] * scale)), max(h, round(a.shape[0] * scale)))
    a = cv2.resize(a, size, interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR)
    y, x = (a.shape[0] - h) // 2, (a.shape[1] - w) // 2
    a = a[y:y + h, x:x + w]
    if float(np.median(a)) < LINEAR_MEDIAN:
        from setiastro.saspro.autostretch import autostretch
        a = np.asarray(autostretch(np.ascontiguousarray(a), 0.25), dtype=np.float32)
        if a.max() > 1.0:
            a = a / 255.0
    u = np.ascontiguousarray((np.clip(a, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8))
    if u.ndim == 2:
        return QImage(u.data, w, h, w, QImage.Format.Format_Grayscale8).copy()
    return QImage(u.data, w, h, 3 * w, QImage.Format.Format_RGB888).copy()


def _cover(img: QImage) -> QImage | None:
    """Scaled and centre-cropped to fill the thumbnail file's size."""
    if img.isNull():
        return None
    box = QSize(THUMB.width() * 2, THUMB.height() * 2)
    img = img.scaled(box, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                     Qt.TransformationMode.SmoothTransformation)
    return img.copy((img.width() - box.width()) // 2, (img.height() - box.height()) // 2,
                    box.width(), box.height())


def _raw_preview(path: str) -> QImage | None:
    """The preview a camera stores in its RAW file. SASpro's own decode of a
    RAW is the Bayer mosaic, which comes out grey, and takes far longer."""
    import rawpy
    with rawpy.imread(path) as raw:
        th = raw.extract_thumb()
    if th.format == rawpy.ThumbFormat.JPEG:
        return _cover(QImage.fromData(bytes(th.data)))
    a = np.ascontiguousarray(th.data, dtype=np.uint8)
    if a.ndim == 3 and a.shape[2] == 3:
        h, w = a.shape[:2]
        return _cover(QImage(a.data, w, h, 3 * w, QImage.Format.Format_RGB888).copy())
    return None


def _thumbnail_from_file(path: str) -> QImage | None:
    """For a recent image with no open image to take it from. Cheap readers
    first; None leaves the placeholder."""
    from setiastro.saspro.legacy.image_manager import RAW_EXTS, load_image
    low = path.lower()
    if low.endswith(".pdf"):
        return None                              # opens as pages, not one image
    if low.endswith((".png", ".jpg", ".jpeg", ".webp")):
        r = QImageReader(path)
        r.setAutoTransform(True)
        size = r.size()
        if size.isValid():
            box = QSize(THUMB.width() * 2, THUMB.height() * 2)
            r.setScaledSize(size.scaled(box, Qt.AspectRatioMode.KeepAspectRatioByExpanding))
            img = r.read()
            if not img.isNull():
                return img.copy((img.width() - box.width()) // 2,
                                (img.height() - box.height()) // 2, box.width(), box.height())
    elif low.endswith(RAW_EXTS):
        try:
            img = _raw_preview(path)
        except Exception:
            img = None                           # none in the file: decoded below
        if img is not None:
            return img
    else:
        from setiastro.saspro.blink_fast_read import read_downsampled
        for step in (16, 8, 4):
            try:
                got = read_downsampled(path, step, cfa_mode="luminance")
            except Exception:
                break                            # a bad file: the loader decides
            if got is None:
                continue
            # Twice what the file will hold, or there is nothing left to average and
            # a star field comes out as hard white dots.
            if step > 4 and min(got[0].shape[0] / THUMB.height(), got[0].shape[1] / THUMB.width()) < 4:
                continue
            return render_thumbnail(got[0])
    # Anything else SASpro opens (TIFF, PSD, compressed FITS, a FITS the reader
    # above declines), and whatever Qt could not read: the whole image, through
    # the loader File > Open uses.
    image = load_image(path, max_retries=0)[0]
    return None if image is None else render_thumbnail(image)


class Thumbnails(QObject):
    """Makes and keeps the thumbnails, on one worker thread."""

    made = pyqtSignal(str)                       # path

    def __init__(self, parent=None):
        super().__init__(parent)
        self._jobs: queue.Queue = queue.Queue()
        self._thread = None
        self._stopped = False
        self._read = {}                          # path: file time read at (worker only)

    def pixmap(self, path: str) -> QPixmap:
        return QPixmap(str(thumbnail_file(path)))

    def from_image(self, path: str, image):
        self._put(("image", path, image))

    def from_file(self, path: str):
        """Does nothing if the thumbnail is up to date, or this version of the
        file was read before (one that can't be read stays a placeholder)."""
        self._put(("file", path, None))

    def keep_only(self, paths):
        self._put(("prune", list(paths), None))

    def stop(self):
        self._stopped = True
        self._jobs.put(None)

    def _put(self, job):
        if self._stopped:
            return
        self._jobs.put(job)
        if self._thread is None:
            self._thread = threading.Thread(target=self._run, name="recent-thumbnails", daemon=True)
            self._thread.start()

    def _run(self):
        while not self._stopped:
            job = self._jobs.get()
            if job is None or self._stopped:
                return
            kind, what, image = job
            try:
                if kind == "prune":
                    self._prune(what)
                elif self._make(kind, what, image) and not self._stopped:
                    try:
                        self.made.emit(what)
                    except RuntimeError:
                        return                   # the window is gone
            except OSError:
                pass                             # the file is gone, or its drive
            except Exception as e:
                print(f"[start panel] no thumbnail for {os.path.basename(str(what))}: {e!r}")
            del job, image

    def _make(self, kind, path, image) -> bool:
        out = thumbnail_file(path)
        taken = os.stat(path).st_mtime           # raises when the file is gone
        if out.exists() and out.stat().st_mtime >= taken:
            return False
        if kind == "file":
            if self._read.get(path) == taken:
                return False
            self._read[path] = taken
        img = render_thumbnail(image) if kind == "image" else _thumbnail_from_file(path)
        if img is None:
            return False
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = out.with_suffix(f".{os.getpid()}.tmp")
        if not img.save(str(tmp), "JPG", 88):
            return False
        os.replace(tmp, out)
        return True

    @staticmethod
    def _prune(paths):
        keep = {thumbnail_file(p).name for p in paths}
        try:
            names = os.listdir(thumbnails_dir())
        except OSError:
            return                               # none made yet
        for n in names:
            if n not in keep:
                try:
                    os.remove(thumbnails_dir() / n)
                except OSError:
                    pass


# ── pieces ──────────────────────────────────────────────────────────────────

def _label(text, name) -> QLabel:
    lab = QLabel(text)
    lab.setObjectName(name)
    lab.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
    return lab


def _link(text, slot) -> QPushButton:
    b = QPushButton(text)
    b.setObjectName("sp_link")
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setFocusPolicy(Qt.FocusPolicy.TabFocus)
    b.clicked.connect(lambda: slot())
    return b


def _plain(text: str) -> str:
    """A menu entry's text as a tile's title: no mnemonic, no trailing dots."""
    t = (text or "").replace("&&", "\x00").replace("&", "").replace("\x00", "&").strip()
    for end in ("...", "…"):
        if t.endswith(end):
            t = t[:-len(end)].rstrip()
    return t


def _plus_icon() -> QIcon:
    pm = QPixmap(112, 112)                       # drawn at 28, four times finer
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QPen(theme_colors().soft, 9, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
    p.drawLine(56, 24, 56, 88)
    p.drawLine(24, 56, 88, 56)
    p.end()
    return QIcon(pm)


def _card_icon(path) -> QIcon:
    """The picture on one of Mosaic Master's mode cards, with a light edge:
    its outlines (and the robotic one's tripod) are near black, and so is a
    tile in the Gray and Dark themes. On a light tile the edge doesn't show."""
    pic = QPixmap(path)
    if pic.isNull():
        return QIcon()
    size, edge = 112, 5                          # drawn at 28, four times finer
    pic = pic.scaled(size - 2 * edge, size - 2 * edge, Qt.AspectRatioMode.KeepAspectRatio,
                     Qt.TransformationMode.SmoothTransformation)
    shape = QPixmap(pic)
    p = QPainter(shape)
    p.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceIn)
    p.fillRect(shape.rect(), QColor("#e4e4e4"))
    p.end()
    out = QPixmap(size, size)
    out.fill(Qt.GlobalColor.transparent)
    x, y = (size - pic.width()) / 2, (size - pic.height()) / 2
    p = QPainter(out)
    for i in range(24):
        a = 2 * math.pi * i / 24
        p.drawPixmap(QPointF(x + edge * math.cos(a), y + edge * math.sin(a)), shape)
    p.drawPixmap(QPointF(x, y), pic)
    p.end()
    return QIcon(out)


class _Tile(QPushButton):
    """Icon, what it does, and the name of the tool that does it. `more` marks
    one that asks which tool first."""

    def __init__(self, icon, title, sub, slot, main=False, more=False):
        super().__init__()
        self.setObjectName("sp_tile")
        self.setProperty("main", "true" if main else "false")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.TabFocus)
        self.setAccessibleName(f"{title}. {sub}")
        self.setMinimumSize(170, 60)
        self._texts = []                         # (label, its full text)
        row = QHBoxLayout(self)
        row.setContentsMargins(14, 8, 10, 8)
        row.setSpacing(12)
        pic = QLabel()
        pic.setFixedSize(28, 28)
        pic.setStyleSheet("background: transparent;")
        pic.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        if icon is not None and not icon.isNull():
            pic.setPixmap(icon.pixmap(QSize(28, 28)))
        row.addWidget(pic)
        col = QVBoxLayout()
        col.setSpacing(1)
        col.addStretch(1)
        for text, name in ((title, "sp_tile_t"), (sub, "sp_tile_s")):
            if not text:                         # a tool with no status tip
                continue
            lab = _label(text, name)
            lab.setMinimumWidth(1)               # the tile's width decides
            self._texts.append((lab, text))
            col.addWidget(lab)
        col.addStretch(1)
        row.addLayout(col, 1)
        self._room = 14 + 28 + 12 + 10           # margins, icon and spacing above
        if more:
            chev = _label("▾", "sp_tile_more")
            chev.setFixedWidth(14)
            row.addWidget(chev)
            self._room += 14 + 12
        self.clicked.connect(lambda: slot())
        self._action = None

    def follow(self, action):
        """Enabled while `action` is."""
        self._action = action
        action.changed.connect(self._follow)
        self._follow()

    def _follow(self):
        try:
            on = self._action.isEnabled()
        except RuntimeError:                     # deleted (a script reloaded)
            return
        if on != self.isEnabled():
            self.setEnabled(on)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        room = self.width() - self._room
        cut = False
        for lab, text in self._texts:
            lab.ensurePolished()
            shown = QFontMetrics(lab.font()).elidedText(
                text, Qt.TextElideMode.ElideRight, max(1, room))
            lab.setText(shown)
            cut = cut or shown != text
        # Translated, some don't fit: the whole of it on hover.
        self.setToolTip("\n".join(t for _lab, t in self._texts) if cut else "")


class _AddTile(_Tile):
    """In the first empty place: a dashed outline and Customize…."""

    def __init__(self, slot):
        super().__init__(_plus_icon(), _t("Customize…"), _t("Add or remove tiles"), slot)
        self.setObjectName("sp_tile_add")

    def paintEvent(self, ev):
        super().paintEvent(ev)
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        lit = self.underMouse() or self.hasFocus()
        c = theme_colors()
        pen = QPen(c.accent if lit else c.border, 1.3)
        pen.setDashPattern([4.0, 3.0])
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(QRectF(self.rect()).adjusted(0.65, 0.65, -0.65, -0.65),
                          CONTROL_RADIUS, CONTROL_RADIUS)
        p.end()


class _Popup(QFrame):
    """A small popup by a tile or link. Closes on a choice, a click anywhere
    else, or Esc; the arrow keys go up and down it."""

    def __init__(self, parent):
        super().__init__(parent, Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint
                         | Qt.WindowType.NoDropShadowWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)   # round corners
        # The click that closes it stops there: on the tile, it would reopen.
        self.setAttribute(Qt.WidgetAttribute.WA_NoMouseReplay, True)
        self.setStyleSheet(_style())
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(8, 8, 8, 8)
        self.lay.setSpacing(8)
        self.tiles = []                          # the first has the focus

    def _show_by(self, anchor, width, right=False):
        """Under `anchor`, or over it without the room. `right`: their right
        edges line up (a link near the panel's edge)."""
        self.setFixedWidth(width)
        self.adjustSize()
        x = anchor.width() - width if right else 0
        under = anchor.mapToGlobal(QPoint(x, anchor.height() + 6))
        screen = anchor.screen().availableGeometry()
        if under.y() + self.height() > screen.bottom():
            under = anchor.mapToGlobal(QPoint(x, -self.height() - 6))
        under.setX(max(screen.left(), min(under.x(), screen.right() - self.width())))
        under.setY(max(screen.top(), under.y()))     # a short screen: over the anchor
        self.move(under)

    def keyPressEvent(self, ev):
        # A button leaves Up and Down to its parent.
        if ev.key() in (Qt.Key.Key_Up, Qt.Key.Key_Down):
            self.focusNextPrevChild(ev.key() == Qt.Key.Key_Down)
            return
        super().keyPressEvent(ev)

    def paintEvent(self, _ev):
        # Not in the style sheet: Qt leaves the background of a translucent
        # window out, and the choices would float over the panel's text.
        c = theme_colors()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(c.border)
        p.setBrush(c.window)
        p.drawRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5),
                          CARD_RADIUS, CARD_RADIUS)
        p.end()

    def showEvent(self, ev):
        super().showEvent(ev)
        self.tiles[0].setFocus(Qt.FocusReason.PopupFocusReason)

    def _choose(self, slot):
        self.close()
        QTimer.singleShot(0, slot)               # once the popup is gone


class _Choices(_Popup):
    """Under a tile: one tile for each way to do it."""

    def __init__(self, anchor, choices, parent):
        super().__init__(parent)
        for icon, title, sub, slot in choices:
            t = _Tile(icon, title, sub, lambda s=slot: self._choose(s))
            t.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
            t.setAutoDefault(True)               # Enter as well as Space
            self.lay.addWidget(t)
            self.tiles.append(t)
        self._show_by(anchor, max(250, anchor.width()))


class _ProjectRow(QPushButton):
    """One recent project: its name, and the folder it is in."""

    def __init__(self, text, sub, slot, name="sp_tile_t"):
        super().__init__()
        self.setObjectName("sp_proj")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setAutoDefault(True)                # Enter as well as Space
        self.setAccessibleName(f"{text}. {sub}" if sub else text)
        col = QVBoxLayout(self)
        col.setContentsMargins(12, 6, 12, 6)
        col.setSpacing(1)
        self._texts = []                         # (label, its full text, where it's cut)
        for t, obj, cut in ((text, name, Qt.TextElideMode.ElideRight),
                            (sub, "sp_tile_s", Qt.TextElideMode.ElideMiddle)):
            if t:
                lab = _label(t, obj)
                lab.setMinimumWidth(1)           # the popup's width decides
                col.addWidget(lab)
                self._texts.append((lab, t, cut))
        self.clicked.connect(lambda: slot())

    def sizeHint(self):
        # A button's own is for its text, and this one has none: the labels'.
        lay = self.layout()
        return QSize(lay.totalMinimumSize().width(), lay.totalSizeHint().height())

    def minimumSizeHint(self):
        return self.sizeHint()

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        room = self.width() - 24
        for lab, text, cut in self._texts:
            lab.ensurePolished()
            lab.setText(QFontMetrics(lab.font()).elidedText(text, cut, max(1, room)))


class _Projects(_Popup):
    """By "Open a project…": the recent projects, as File > Open Recent
    Projects lists them, then a way to look for any other. Nothing here asks
    whether a file is there (a drive that isn't would hang the window): opening
    one that is gone offers to take it off the list."""

    def __init__(self, anchor, paths, open_one, browse, parent):
        super().__init__(parent)
        self.lay.setSpacing(2)
        head = _label(_t("RECENT PROJECTS"), "sp_k")
        head.setContentsMargins(12, 4, 12, 4)
        self.lay.addWidget(head)
        for p in paths:
            name = os.path.splitext(os.path.basename(p))[0] or p
            row = _ProjectRow(name, os.path.dirname(p),
                              lambda p=p: self._choose(lambda: open_one(p)))
            row.setToolTip(p)
            self.lay.addWidget(row)
            self.tiles.append(row)
        rule = QFrame()
        rule.setObjectName("sp_rule")
        rule.setFixedHeight(1)
        self.lay.addSpacing(4)
        self.lay.addWidget(rule)
        self.lay.addSpacing(4)
        more = _ProjectRow(_t("Browse for a project…"), "", lambda: self._choose(browse),
                           name="sp_proj_more")
        self.lay.addWidget(more)
        self.tiles.append(more)
        self._show_by(anchor, 380, right=True)


class _Recent(QPushButton):
    """One recent image: its thumbnail and file name."""

    def __init__(self, path, pixmap, slot):
        super().__init__()
        self.setObjectName("sp_recent")
        self.path = path
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.TabFocus)
        self.setToolTip(path)
        name = os.path.basename(path) or path
        self.setAccessibleName(_t("Open {0}").format(name))
        self.setFixedSize(THUMB.width() + 12, THUMB.height() + 36)
        col = QVBoxLayout(self)
        col.setContentsMargins(6, 6, 6, 4)
        col.setSpacing(4)
        self._pic = QLabel()
        self._pic.setFixedSize(THUMB)
        self._pic.setStyleSheet("background: transparent;")
        self._pic.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        col.addWidget(self._pic)
        text = _label("", "sp_s")
        text.ensurePolished()
        text.setText(QFontMetrics(text.font()).elidedText(
            name, Qt.TextElideMode.ElideMiddle, THUMB.width() - 4))
        col.addWidget(text)
        self.set_picture(pixmap)
        self.clicked.connect(lambda: slot(path))

    def set_picture(self, pixmap: QPixmap):
        self._source = pixmap                    # drawn again on a theme change
        c = theme_colors()
        dpr = self.devicePixelRatioF()
        pm = QPixmap(round(THUMB.width() * dpr), round(THUMB.height() * dpr))
        pm.setDevicePixelRatio(dpr)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        box = QRectF(0, 0, THUMB.width(), THUMB.height())
        path = QPainterPath()
        path.addRoundedRect(box, 8, 8)
        p.setClipPath(path)
        if pixmap.isNull():
            p.fillRect(box, c.raised)
            p.setPen(c.muted)
            font = p.font()
            font.setPointSize(13)
            font.setBold(True)
            p.setFont(font)
            ext = os.path.splitext(self.path)[1].lstrip(".").upper()
            p.drawText(box, Qt.AlignmentFlag.AlignCenter, ext or "?")
        else:
            p.drawPixmap(box, pixmap, QRectF(pixmap.rect()))
        # A dark sky would otherwise run into a dark panel.
        p.setClipping(False)
        edge = QColor(c.text)
        edge.setAlpha(40)
        p.setPen(edge)
        p.drawRoundedRect(box.adjusted(0.5, 0.5, -0.5, -0.5), 8, 8)
        p.end()
        self._pic.setPixmap(pm)


class _RecentStrip(QScrollArea):
    """The recent images in one row that scrolls sideways: the mouse wheel
    (a notch an image), the bar under them, or Tab to one off the end. The bar
    only when they don't all fit."""

    def __init__(self, buttons):
        super().__init__()
        self.setObjectName("sp_strip")
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setWidgetResizable(True)
        self.buttons = list(buttons)
        row = QWidget()
        row.setObjectName("sp_strip_row")
        lay = QHBoxLayout(row)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        for b in self.buttons:
            lay.addWidget(b)
        lay.addStretch(1)
        self.setWidget(row)
        row.setAutoFillBackground(False)         # setWidget turned it on
        self.viewport().setAutoFillBackground(False)
        self.fit(10 ** 6)

    def fit(self, room):
        """`room` pixels across: the bar if they don't all fit, and its height."""
        need = sum(b.width() for b in self.buttons) > room
        bar = self.horizontalScrollBar()
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn if need
                                          else Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        bar.ensurePolished()
        self.setFixedHeight(self.buttons[0].height() + (bar.sizeHint().height() if need else 0))

    def wheelEvent(self, ev):
        bar = self.horizontalScrollBar()
        d = ev.angleDelta()
        if bar.maximum() <= 0:
            ev.ignore()                          # nothing to scroll
            return
        if abs(d.x()) > abs(d.y()):
            super().wheelEvent(ev)               # sideways already (a touchpad)
            return
        # The wheel turns up and down: sideways here, a notch an image.
        bar.setValue(bar.value() - round(d.y() * self.buttons[0].width() / 120))
        ev.accept()


class _CustomizeDialog(QDialog):
    """Start panel > Customize…: which tools have tiles, in what order, up to
    MAX_TILES. `choices`: (id, icon, title, subtitle) for every tool there can
    be a tile for, A to Z."""

    def __init__(self, current, choices, parent):
        super().__init__(parent)
        self.setWindowTitle(_t("Customize Start Panel"))
        self._choices = {cid: (icon, title, sub) for cid, icon, title, sub in choices}
        self._az = [c[0] for c in choices]
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(_t("Choose up to {0} tools for the Start Panel. "
                                "Drag them into the order you want.").format(MAX_TILES)))
        cols = QHBoxLayout()
        cols.setSpacing(16)
        lay.addLayout(cols, 1)

        left = QVBoxLayout()
        left.addWidget(QLabel(_t("All tools")))
        self.search = QLineEdit()
        self.search.setPlaceholderText(_t("Search"))
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._fill_all)
        left.addWidget(self.search)
        self.all = self._list()
        self.all.itemDoubleClicked.connect(lambda _it: self._add())
        left.addWidget(self.all, 1)
        self.add_btn = QPushButton(_t("Add"))
        self.add_btn.clicked.connect(self._add)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(self.add_btn)
        left.addLayout(row)
        cols.addLayout(left, 1)

        right = QVBoxLayout()
        head = QHBoxLayout()
        head.addWidget(QLabel(_t("On the Start Panel")))
        head.addStretch(1)
        self.count = QLabel()
        head.addWidget(self.count)
        right.addLayout(head)
        self.on = self._list()
        self.on.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.on.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.on.itemDoubleClicked.connect(lambda _it: self._remove())
        self.on.model().rowsMoved.connect(lambda *_a: self._sync())
        right.addWidget(self.on, 1)
        self.full = QLabel(_t("The Start Panel is full. Remove a tool to add another."))
        self.full.setWordWrap(True)
        right.addWidget(self.full)
        row = QHBoxLayout()
        self.up_btn = QPushButton(_t("Move Up"))
        self.up_btn.clicked.connect(lambda: self._move(-1))
        self.down_btn = QPushButton(_t("Move Down"))
        self.down_btn.clicked.connect(lambda: self._move(1))
        self.remove_btn = QPushButton(_t("Remove"))
        self.remove_btn.clicked.connect(self._remove)
        for b in (self.up_btn, self.down_btn):
            row.addWidget(b)
        row.addStretch(1)
        row.addWidget(self.remove_btn)
        right.addLayout(row)
        cols.addLayout(right, 1)

        box = QDialogButtonBox(QDialogButtonBox.StandardButton.RestoreDefaults
                               | QDialogButtonBox.StandardButton.Ok
                               | QDialogButtonBox.StandardButton.Cancel)
        # Qt's own words for these are never translated in SASpro.
        for which, text in ((QDialogButtonBox.StandardButton.RestoreDefaults, _t("Reset to Defaults")),
                            (QDialogButtonBox.StandardButton.Ok, _t("OK")),
                            (QDialogButtonBox.StandardButton.Cancel, _t("Cancel"))):
            box.button(which).setText(text)
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        box.button(QDialogButtonBox.StandardButton.RestoreDefaults).clicked.connect(self._defaults)
        lay.addWidget(box)

        for cid in current:
            self._append(cid)
        self.all.currentRowChanged.connect(lambda _r: self._sync())
        self.on.currentRowChanged.connect(lambda _r: self._sync())
        self._fill_all()
        self.resize(760, 500)

    @staticmethod
    def _list() -> QListWidget:
        w = QListWidget()
        w.setIconSize(QSize(20, 20))
        w.setUniformItemSizes(True)
        return w

    def _item(self, cid) -> QListWidgetItem:
        icon, title, sub = self._choices[cid]
        it = QListWidgetItem(icon, title)
        it.setData(Qt.ItemDataRole.UserRole, cid)
        if sub:
            it.setToolTip(sub)
        return it

    def _append(self, cid):
        if cid in self._choices and cid not in self.ids() and self.on.count() < MAX_TILES:
            self.on.addItem(self._item(cid))

    def ids(self) -> list:
        return [self.on.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.on.count())]

    def _fill_all(self):
        """Every tool not on the panel whose name or description has the search text."""
        keep = self.all.currentItem().data(Qt.ItemDataRole.UserRole) if self.all.currentItem() else None
        words = self.search.text().casefold().split()
        on = set(self.ids())
        self.all.clear()
        for cid in self._az:
            if cid in on:
                continue
            _icon, title, sub = self._choices[cid]
            hay = f"{title} {sub} {cid}".casefold()
            if all(w in hay for w in words):
                it = self._item(cid)
                self.all.addItem(it)
                if cid == keep:
                    self.all.setCurrentItem(it)
        if self.all.currentItem() is None and self.all.count():
            self.all.setCurrentRow(0)
        self._sync()

    def _sync(self):
        n = self.on.count()
        room = n < MAX_TILES
        self.count.setText(_t("{0} of {1}").format(n, MAX_TILES))
        self.full.setVisible(not room)
        self.add_btn.setEnabled(room and self.all.currentItem() is not None)
        r = self.on.currentRow()
        self.remove_btn.setEnabled(r >= 0)
        self.up_btn.setEnabled(r > 0)
        self.down_btn.setEnabled(0 <= r < n - 1)

    def _add(self):
        it = self.all.currentItem()
        if it is None or self.on.count() >= MAX_TILES:
            return
        self._append(it.data(Qt.ItemDataRole.UserRole))
        self.on.setCurrentRow(self.on.count() - 1)
        self._fill_all()

    def _remove(self):
        r = self.on.currentRow()
        if r < 0:
            return
        self.on.takeItem(r)
        self.on.setCurrentRow(min(r, self.on.count() - 1))
        self._fill_all()

    def _move(self, step):
        r = self.on.currentRow()
        if not (0 <= r + step < self.on.count()):
            return
        it = self.on.takeItem(r)
        self.on.insertItem(r + step, it)
        self.on.setCurrentRow(r + step)

    def _defaults(self):
        self.on.clear()
        for cid in DEFAULT_TILES:
            self._append(cid)
        self._fill_all()


# ── the panel ───────────────────────────────────────────────────────────────

class StartPanel(QFrame):
    def __init__(self, main_window):
        self._mw = main_window
        self._vp = main_window.mdi.viewport()
        super().__init__(self._vp)
        self.setObjectName("StartPanel")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet(_style())
        self.setAcceptDrops(True)                # handed to the workspace below
        self.hide()
        self._placed_for = None
        self._shown_recents = None
        self._recent_buttons = []
        self._strip = None                       # the row of them, when there are any
        self._summoned = None                   # the views it was put up over
        self.on = self.on_startup()              # for this session

        self.thumbs = Thumbnails(self)
        self.thumbs.made.connect(self._thumb_made)
        self._build()

        self._vp.installEventFilter(self)
        self._settle = QTimer(self)              # one placement per burst of changes
        self._settle.setSingleShot(True)
        self._settle.setInterval(0)
        self._settle.timeout.connect(self.sync)
        self._watch = QTimer(self)               # shortcuts and cards come and go
        self._watch.setInterval(700)
        self._watch.timeout.connect(self.sync)
        self._capture = QTimer(self)             # after the open has settled
        self._capture.setSingleShot(True)
        self._capture.setInterval(1500)
        self._capture.timeout.connect(self._capture_open_images)
        self._settle.start()

    def changeEvent(self, ev):
        # The theme changed: its colours, and the pictures drawn in them.
        if ev.type() in PALETTE_EVENTS and restyle(self, _style()) and hasattr(self, "_tiles"):
            self._build_tiles()
            for b in self._recent_buttons:
                b.set_picture(b._source)
        super().changeEvent(ev)

    # ---- contents -----------------------------------------------------------
    def _build(self):
        mw = self._mw
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 18, 26, 16)
        root.setSpacing(12)
        head = QHBoxLayout()
        head.addWidget(_label(_t("What would you like to do?"), "sp_h"))
        head.addStretch(1)
        self._startup = QCheckBox(_t("Show on startup"))
        self._startup.setObjectName("sp_startup")
        self._startup.setCursor(Qt.CursorShape.PointingHandCursor)
        self._startup.setFocusPolicy(Qt.FocusPolicy.TabFocus)
        self._startup.setAccessibleName(_t("Show the start panel on startup"))
        self._startup.setToolTip(_t(
            "Unticked, this panel only comes up from View > Start Panel. "
            "Also in Settings > Preferences."))
        self._startup.setChecked(self.on_startup())
        self._startup.clicked.connect(lambda on: mw._set_start_panel_on_startup(on))
        head.addWidget(self._startup)
        head.addSpacing(8)
        x = QPushButton("✕")
        x.setObjectName("sp_x")
        x.setFixedSize(26, 26)
        x.setCursor(Qt.CursorShape.PointingHandCursor)
        x.setFocusPolicy(Qt.FocusPolicy.TabFocus)
        x.setAccessibleName(_t("Close the start panel"))
        x.setToolTip(_t("Close for now. View > Start Panel brings it back."))
        x.clicked.connect(lambda: mw._set_start_panel(False))
        head.addWidget(x)
        root.addLayout(head)

        # The tiles, filled by _build_tiles: four across, three on a narrow
        # workspace (_place decides).
        self._grid_box = QWidget()
        self._grid_box.setObjectName("sp_grid")
        self._grid_box.setStyleSheet("#sp_grid { background: transparent; }")
        self._grid = QGridLayout(self._grid_box)
        self._grid.setContentsMargins(0, 0, 0, 0)
        self._grid.setSpacing(10)
        self._cols = COLUMNS
        self._tile_widgets = []                  # in order, the dashed one last
        self._tiles = []                         # (QAction or None, its tile)
        self._tile_ids = []                      # the tools shown, in order
        self._deep_sky = self._mosaics = None    # the popups' anchors
        root.addWidget(self._grid_box)

        self._more = QWidget()                   # the half that goes when space is short
        self._more.setObjectName("sp_more")
        self._more.setStyleSheet("#sp_more { background: transparent; }")
        self._more_lay = QVBoxLayout(self._more)
        self._more_lay.setContentsMargins(0, 4, 0, 0)
        self._more_lay.setSpacing(8)
        root.addWidget(self._more)

        foot = QHBoxLayout()
        find = QKeySequence("Ctrl+Shift+P").toString(QKeySequence.SequenceFormat.NativeText)
        foot.addWidget(_label(_t("Drop files anywhere here. {0} finds any tool by name.").format(find),
                              "sp_s"))
        foot.addStretch(1)
        foot.setSpacing(16)
        # With all eight places taken there is no dashed tile: Customize… is here.
        self._customize_link = _link(_t("Customize…"), self._customize)
        foot.addWidget(self._customize_link)
        self._project_link = _link(_t("Open a project…"), self._open_project)
        foot.addWidget(self._project_link)
        foot.addWidget(_link(_t("What's new"), self._runs(
            lambda: QDesktopServices.openUrl(QUrl(RELEASES_URL)))))
        root.addLayout(foot)
        self._build_tiles()
        self._fill_more()

    # ---- the tiles ----------------------------------------------------------
    @staticmethod
    def _named(cid):
        """(title, subtitle) for the tiles SASpro starts with: what it does,
        then the tool that does it. None for any other tool: that one shows its
        own name and status tip."""
        return {
            "open": (_t("Open images…"), _t("FITS, XISF, TIFF, RAW, PNG, JPEG")),
            "workflows": (_t("Process step by step"), _t("Workflow Assistant")),
            "blink": (_t("Blink frames"), "Blink Comparator"),    # tool names stay English
            "whats_in_my_sky": (_t("Plan tonight"), _t("What's In My Sky")),
            "sp.deep_sky": (_t("Deep-Sky Stacking"), _t("Quick Stack or Stacking Suite")),
            "sp.mosaics": (_t("Deep-Sky Mosaics"), _t("Traditional Panels or Robotic")),
            "planetary_stacker": (_t("Planetary Stacking"),
                                  _t("Moon, Sun and planets from video")),
        }.get(cid)

    def _action_for(self, cid):
        mw = self._mw
        a = (getattr(getattr(mw, "shortcuts", None), "registry", None) or {}).get(cid)
        if a is None:
            try:
                a = mw._find_action_by_cid(cid)
            except Exception:
                a = None
        try:
            if a is not None:
                a.text()
        except RuntimeError:                     # deleted (a script reloaded)
            return None
        return a

    def _tile_spec(self, cid, a=None):
        """(action or None, icon, title, subtitle, slot, asks first) for a tile
        id; None if this SASpro has no such tool (a script since deleted)."""
        mw = self._mw
        named = self._named(cid)
        if cid == "sp.deep_sky":                 # asks which of the two
            return None, mw.act_stacking_suite.icon(), *named, self._choose_deep_sky, True
        if cid == "sp.mosaics":                  # asks which mode of Mosaic Master
            from setiastro.saspro.resources import mosaic_robotic_path
            return None, _card_icon(mosaic_robotic_path), *named, self._choose_mosaic, True
        a = a or self._action_for(cid)
        if a is None or a is getattr(mw, "act_start_panel", None):
            return None
        icon = a.icon()
        if icon.isNull() and cid == "workflows":     # Workflow Assistant has none
            icon = mw.act_function_bundles.icon()
        if named:
            title, sub = named
        else:
            title, sub = _plain(a.text()), (a.statusTip() or "").strip()
            if sub == title:
                sub = ""
        slot = self._process_step_by_step if cid == "workflows" else a.trigger
        return a, icon, title, sub, self._runs(slot), False

    def _saved_tiles(self) -> list:
        raw = self._mw.settings.value(TILES_KEY, None)
        if raw is None or raw == "":
            return list(DEFAULT_TILES)
        try:
            ids = json.loads(raw) if isinstance(raw, str) else list(raw)
        except Exception:
            return list(DEFAULT_TILES)
        out = []
        for cid in ids:
            if isinstance(cid, str) and cid and cid not in out:
                out.append(cid)
        return out

    def set_tiles(self, ids):
        """Save the tiles chosen (command ids, in order) and show them. The
        default list saves as nothing, so it keeps following SASpro's."""
        out = []
        for cid in ids:
            if cid and cid not in out:
                out.append(str(cid))
        out = out[:MAX_TILES]
        s = self._mw.settings
        if out == list(DEFAULT_TILES):
            s.remove(TILES_KEY)
        else:
            s.setValue(TILES_KEY, json.dumps(out))
        self._build_tiles()
        self._placed_for = None                  # the size can differ
        self._settle.start()

    def _build_tiles(self):
        for w in self._tile_widgets:
            w.hide()
            w.deleteLater()
        self._tile_widgets, self._tiles, self._tile_ids = [], [], []
        self._deep_sky = self._mosaics = None
        for cid in self._saved_tiles():
            if len(self._tile_ids) >= MAX_TILES:
                break
            spec = self._tile_spec(cid)
            if spec is None:
                continue
            a, icon, title, sub, slot, more = spec
            tile = _Tile(icon, title, sub, slot, main=not self._tile_ids, more=more)
            if a is not None:
                tile.follow(a)
            if cid == "sp.deep_sky":
                self._deep_sky = tile
            elif cid == "sp.mosaics":
                self._mosaics = tile
            self._menu_on(tile, cid)
            self._tile_ids.append(cid)
            self._tiles.append((a, tile))
            self._tile_widgets.append(tile)
        room = len(self._tile_ids) < MAX_TILES
        if room:
            add = _AddTile(self._customize)
            self._menu_on(add, None)
            self._tile_widgets.append(add)
        self._customize_link.setVisible(not room)
        self._lay_out_tiles(self._cols)
        # Added to a visible panel, they stay hidden until the next event loop
        # pass, and a layout measures hidden widgets as nothing.
        for w in self._tile_widgets:
            w.show()

    def _lay_out_tiles(self, cols):
        self._cols = cols
        g = self._grid
        while g.count():
            g.takeAt(0)
        for i, w in enumerate(self._tile_widgets):
            g.addWidget(w, i // cols, i % cols)
        for c in range(COLUMNS):
            g.setColumnStretch(c, 1 if c < cols else 0)

    def _menu_on(self, tile, cid):
        tile.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        tile.customContextMenuRequested.connect(
            lambda pos, t=tile, c=cid: self._tile_menu(t, c, pos))

    def _tile_menu(self, tile, cid, pos):
        """A tile's right-click: Remove from Start Panel, Customize…."""
        menu = QMenu(self._mw)
        menu.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        if cid is not None:
            menu.addAction(_t("Remove from Start Panel")).triggered.connect(
                lambda: self.set_tiles([c for c in self._tile_ids if c != cid]))
        menu.addAction(_t("Customize…")).triggered.connect(self._customize)
        menu.popup(tile.mapToGlobal(pos))

    def _tool_choices(self) -> list:
        """(id, icon, title, subtitle), A to Z, for every tool there can be a
        tile for: the two that ask first, every registered command and every
        other menu or toolbar entry with an id. Not switches (Display-Stretch,
        the docks): a tile runs something."""
        mw = self._mw
        found = {}
        for cid, a in (getattr(getattr(mw, "shortcuts", None), "registry", None) or {}).items():
            found.setdefault(str(cid), a)
        try:
            listed = mw._collect_all_qactions()
        except Exception:
            listed = []
        for a in listed:
            cid = a.property("command_id") or a.objectName()
            if cid:
                found.setdefault(str(cid), a)
        out, seen = [], set()
        for cid in ("sp.deep_sky", "sp.mosaics"):
            spec = self._tile_spec(cid)
            out.append((cid, spec[1], spec[2], spec[3]))
        for cid, a in found.items():
            try:
                if (id(a) in seen or a.isSeparator() or a.isCheckable()
                        or a.menu() is not None or a.property("cmdp_exclude")):
                    continue
            except RuntimeError:
                continue
            spec = self._tile_spec(cid, a)
            if spec is None or not spec[2]:
                continue
            seen.add(id(a))
            out.append((cid, spec[1], spec[2], spec[3]))
        out.sort(key=lambda c: c[2].casefold())
        return out

    def _customize(self):
        """Customize…: which tools, in what order. The panel stays up."""
        dlg = _CustomizeDialog(self._tile_ids, self._tool_choices(), self._mw)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        dlg.accepted.connect(lambda: self.set_tiles(dlg.ids()))
        dlg.open()

    def _run(self, slot):
        """Something chosen here. Put up over open images, the panel has done
        its job and goes first."""
        if self._summoned is not None:
            self._dismiss()
        slot()

    def _runs(self, slot):
        return lambda: self._run(slot)

    def _process_step_by_step(self):
        """Images first, then the Workflow Assistant; opening one takes this
        panel away, and the assistant works on the open images. Cancelled, the
        assistant still opens, to look around in. With an image already open
        (the panel put up over it from View > Start Panel or the Essentials
        button),
        straight to the assistant: a file prompt then read as if SASpro
        didn't know about the image."""
        mw = self._mw
        if mw.mdi.subWindowList():
            mw.act_workflows.trigger()
            return
        try:
            mw.open_files()
        finally:
            mw.act_workflows.trigger()

    def _choose_deep_sky(self):
        """Quick Stack or the Stacking Suite, in a popup under the tile."""
        choices = []
        for act, title, sub in (
                ("act_quick_stack", _t("Quick Stack"), _t("Fast and easy to start with")),
                ("act_stacking_suite", _t("Stacking Suite"), _t("The full pipeline, in depth"))):
            a = getattr(self._mw, act, None)
            if a is not None:
                choices.append((a.icon(), title, sub, a.trigger))
        if len(choices) == 1:
            self._run(choices[0][3])
            return
        self._show_choices(self._deep_sky, choices)

    def _choose_mosaic(self):
        """Mosaic Master's two modes, Traditional Panels or Robotic Mosaic, in a
        popup under the tile. Each opens Mosaic Master with that card chosen."""
        from setiastro.saspro.resources import mosaic_panels_path, mosaic_robotic_path
        mw = self._mw
        self._show_choices(self._mosaics, [
            (_card_icon(mosaic_panels_path), _t("Traditional Panels"),
             _t("A few plate-solved panels"), mw._open_panel_mosaic),
            (_card_icon(mosaic_robotic_path), _t("Robotic Mosaic"),
             _t("Seestar and smart telescopes"), mw._open_robotic_mosaic)])

    def _show_choices(self, anchor, choices):
        choices = [(icon, title, sub, self._runs(slot)) for icon, title, sub, slot in choices]
        pop = _Choices(anchor, choices, self)
        pop.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        pop.show()

    def _open_project(self):
        """The recent projects in a popup by the link; with none yet, straight
        to the file prompt."""
        mw = self._mw
        paths = list(getattr(mw, "_recent_project_paths", []) or [])[:PROJECTS]
        if not paths:
            self._run(mw.act_project_load.trigger)
            return
        pop = _Projects(self._project_link, paths,
                        lambda p: self._run(lambda: mw._open_recent_project(p)),
                        self._runs(mw.act_project_load.trigger), self)
        pop.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        pop.show()

    def tile_for(self, action):
        """The tile that runs `action`, if it is on screen (First Steps rings it)."""
        for a, tile in self._tiles:
            if a is action and tile.isVisible():
                return tile
        return None

    def _recent_paths(self) -> list:
        return list(getattr(self._mw, "_recent_image_paths", []) or [])

    def _fill_more(self):
        """Recent images; without any, where to start."""
        paths = self._recent_paths()[:RECENTS]
        if self._shown_recents == paths:
            return
        self._shown_recents = paths
        self._placed_for = None                  # the size can differ
        while self._more_lay.count():
            it = self._more_lay.takeAt(0)
            w = it.widget()
            if w is not None:
                w.hide()
                w.deleteLater()
        self._recent_buttons = []
        self._strip = None
        self._tour_link = None
        head = _label(_t("RECENT IMAGES") if paths else _t("NEW TO SASPRO?"), "sp_k")
        self._more_lay.addWidget(head)
        head.show()
        if paths:
            self._recent_buttons = [_Recent(p, self.thumbs.pixmap(p), self._open_recent)
                                    for p in paths]
            box = self._strip = _RecentStrip(self._recent_buttons)
            # Not all its children: the scroll bars are the strip's to show.
            shown = [box, box.viewport(), box.widget(), *box.widget().findChildren(QWidget)]
        else:
            from setiastro.saspro.first_steps_tour import sample_image_path
            box = QWidget()
            box.setStyleSheet("background: transparent;")
            row = QHBoxLayout(box)
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(18)
            if sample_image_path() is not None:
                row.addWidget(_link(_t("Open the sample image"), self._runs(self._open_sample)))
            self._tour_link = _link(_t("First Steps tour"),
                                    self._runs(lambda: self._mw.act_first_steps.trigger()))
            row.addWidget(self._tour_link)
            row.addWidget(_link(_t("Beginner video"), self._runs(
                lambda: QDesktopServices.openUrl(QUrl(TUTORIAL_URL)))))
            row.addWidget(_link(_t("Documentation"),
                                self._runs(lambda: self._mw.act_docs.trigger())))
            row.addStretch(1)
            shown = [box, *box.findChildren(QWidget)]
        self._more_lay.addWidget(box)
        # Added to a visible panel, children stay hidden until the next event
        # loop pass, and a layout measures hidden children as nothing.
        for w in shown:
            w.show()
        self._sync_tour_link()

    def _sync_tour_link(self):
        """Not offered while the tour is already running."""
        tour = getattr(self._mw, "_first_steps_tour", None)
        try:
            running = tour is not None and tour.isVisible()
        except RuntimeError:
            running = False
        if self._tour_link is not None and self._tour_link.isHidden() != running:
            self._tour_link.setVisible(not running)

    def _open_sample(self):
        from setiastro.saspro.first_steps_tour import open_sample_image
        open_sample_image(self._mw)

    def _open_recent(self, path):
        self._run(lambda: self._mw._open_recent_image(path))

    # ---- recent images ------------------------------------------------------
    def recents_changed(self):
        """The recent list changed: an image was opened, saved or the list cleared."""
        self._fill_more()
        self._settle.start()
        self._capture.start()

    def _capture_open_images(self):
        paths = self._recent_paths()
        self.thumbs.keep_only(paths)
        wanted = {os.path.normcase(p): p for p in paths[:2 * RECENTS]}
        for doc in list(getattr(self._mw.docman, "_docs", []) or []):
            try:
                meta = getattr(doc, "metadata", None) or {}
                # "file.xisf::XISF[0]": one image of several in a file
                path = str(meta.get("file_path") or "").split("::")[0]
                image = getattr(doc, "image", None)
                if not path or image is None:
                    continue
                # pop: one image per file, the first one opened from it
                p = wanted.pop(os.path.normcase(os.path.abspath(path)), None)
                if p is not None:
                    self.thumbs.from_image(p, image)
            except Exception:
                continue
        # The rest from their files. A saved copy has no open image of its own,
        # and startup's pass only read what was on the list then.
        for p in (self._shown_recents or []):
            if os.path.normcase(p) in wanted:
                self.thumbs.from_file(p)

    def read_missing(self):
        """Thumbnails for recents never opened in this version, where cheap."""
        for p in (self._shown_recents or []):
            self.thumbs.from_file(p)             # does nothing if one is there

    def _thumb_made(self, path):
        for b in self._recent_buttons:
            if b.path == path:
                b.set_picture(self.thumbs.pixmap(path))

    # ---- showing ------------------------------------------------------------
    def on_startup(self) -> bool:
        return self._mw.settings.value(STARTUP_KEY, True, type=bool)

    def startup_changed(self):
        self._startup.setChecked(self.on_startup())

    def sync(self):
        """Show, place or hide, for the workspace as it is now."""
        mw = self._mw
        closing = getattr(mw, "_shutting_down", False)
        views = mw.mdi.subWindowList()
        if self._summoned is not None and frozenset(views) != self._summoned:
            self._unsummon()                     # an image opened or closed
        if closing or (views and self._summoned is None) or not self.on:
            was_up = not self.isHidden()
            self._unsummon()
            self._watch.stop()
            self._placed_for = None
            self.hide()
            if views and was_up and not closing and not self.on_startup():
                mw._set_start_panel(False)       # it was up for that one time
            return
        if not self._watch.isActive():
            self._watch.start()
        self._sync_tour_link()
        self._place()
        if self._summoned is not None:
            self.raise_()                        # an image activated since

    # ---- over open images ---------------------------------------------------
    def summon(self):
        """View > Start Panel with images open: over them, until something is
        chosen here, the workspace is clicked, Esc, or an image opens or
        closes. Turning the panel on, as the menu does next, shows it."""
        self._summoned = frozenset(self._mw.mdi.subWindowList())
        QApplication.instance().installEventFilter(self)

    def _unsummon(self):
        if self._summoned is None:
            return
        self._summoned = None
        app = QApplication.instance()
        if app is not None:
            app.removeEventFilter(self)

    def _dismiss(self):
        self._unsummon()
        self.sync()                              # images are open: it goes

    def _in_the_way(self) -> list:
        """Desktop shortcuts and corner cards, in workspace coordinates."""
        out = []
        mgr = getattr(self._mw, "shortcuts", None)
        for w in list(getattr(mgr, "widgets", {}).values()):
            try:
                if w.isVisible():
                    out.append(QRect(w.mapTo(self._vp, QPoint(0, 0)), w.size()))
            except RuntimeError:
                continue
        for name in ("_setup_pill", "_first_steps_tour"):
            w = getattr(self._mw, name, None)
            try:
                if w is not None and w.isVisible():
                    top = self._vp.mapFrom(self._mw, w.pos())
                    out.append(QRect(top, w.size()))
            except RuntimeError:
                continue
        return out

    def _place(self):
        area = self._vp.size()
        blocks = [(r.left() - GAP, r.top() - GAP, r.right() + GAP, r.bottom() + GAP)
                  for r in self._in_the_way()]
        key = (area.width(), area.height(), tuple(blocks))
        if key == self._placed_for:
            return                               # nothing moved (or still no room)
        width = min(WIDTH, area.width() - 40)
        spot = None
        if width >= 600:
            # A layout keeps each widget's size until that widget says it
            # changed, and only a visible panel's layouts do the saying. Refilled
            # while hidden behind images ("New to SASpro?" became a row of
            # thumbnails, or back), the panel came up at its old height with
            # its rows run together.
            cols = COLUMNS if width >= FOUR_ACROSS else COLUMNS - 1
            if cols != self._cols:
                self._lay_out_tiles(cols)
            for box in (self._grid_box, self._more):
                for w in (box, *box.findChildren(QWidget)):
                    w.updateGeometry()
            for full in (True, False):
                self._more.setVisible(full)
                if full and self._strip is not None:
                    self._strip.fit(width - 52)  # inside the panel's margins
                self._more_lay.invalidate()      # refilled while hidden, the
                self.layout().invalidate()       # old size would still be cached
                size = QSize(width, self.layout().totalSizeHint().height())
                spot = _free_spot(area, size, blocks)
                if spot is not None:
                    self.setGeometry(QRect(spot, size))
                    break
        self._placed_for = key
        if spot is None:
            self.hide()
            return
        if not self.isVisible():
            self.show()
            self.raise_()

    # ---- the workspace underneath -------------------------------------------
    def eventFilter(self, obj, ev):
        if obj is self._vp:
            if ev.type() == QEvent.Type.Resize:
                self._settle.start()
            elif ev.type() in (QEvent.Type.ChildAdded, QEvent.Type.ChildRemoved):
                # A view came or went. subWindowActivated doesn't always say so
                # for the last one to close, and documentRemoved comes before
                # its window is gone.
                self._mw._views_sync_timer.start()
        elif self._summoned is not None and isinstance(obj, QWidget):
            # Put up over images, this filter is on the whole application.
            kind = ev.type()
            if kind == QEvent.Type.MouseButtonPress:
                if (self._mw.mdi.isAncestorOf(obj)
                        and not (obj is self or self.isAncestorOf(obj))):
                    self._dismiss()              # the click still reaches the image
            elif (kind == QEvent.Type.KeyPress and ev.key() == Qt.Key.Key_Escape
                  and obj.window() is self._mw):
                self._dismiss()
                return True
        return False

    def mousePressEvent(self, ev):
        ev.accept()                              # not a click on the workspace

    def mouseReleaseEvent(self, ev):
        ev.accept()

    def mouseDoubleClickEvent(self, ev):
        ev.accept()

    def dragEnterEvent(self, ev):
        """Whatever the workspace takes can be dropped here: its shortcut layer
        comes up above the panel for the rest of the drag."""
        layer = getattr(getattr(self._mw, "shortcuts", None), "canvas", None)
        if layer is None:
            ev.ignore()
            return
        layer.dragEnterEvent(ev)

    def dropEvent(self, ev):
        layer = getattr(getattr(self._mw, "shortcuts", None), "canvas", None)
        if layer is None:
            ev.ignore()
            return
        layer.dropEvent(ev)

    def stop(self):
        """SASpro is closing."""
        self._unsummon()
        for t in (self._watch, self._capture, self._settle):
            t.stop()
        self.thumbs.stop()


def _free_spot(area: QSize, size: QSize, blocks):
    """Where `size` fits without touching `blocks`, as near as possible to the
    middle (a little above it); None if nowhere."""
    max_x, max_y = area.width() - size.width() - GAP, area.height() - size.height() - GAP
    if max_x < GAP or max_y < GAP:
        return None
    cx, cy = (area.width() - size.width()) // 2, round((area.height() - size.height()) * 0.45)

    def clear(x, y):
        r, b = x + size.width(), y + size.height()
        return all(x > right or r < left or y > bottom or b < top
                   for left, top, right, bottom in blocks)

    if clear(cx, cy):
        return QPoint(cx, cy)
    xs = sorted({GAP, max_x, *range(cx % 24 or GAP, max_x, 24)} - {0})
    ys = sorted({GAP, max_y, *range(cy % 24 or GAP, max_y, 24)} - {0})
    spots = [(abs(x - cx) + abs(y - cy), x, y) for x in xs for y in ys
             if GAP <= x <= max_x and GAP <= y <= max_y]
    for _d, x, y in sorted(spots):
        if clear(x, y):
            return QPoint(x, y)
    return None


def install(main_window):
    """Create the panel. Called at the end of the main window's __init__."""
    panel = StartPanel(main_window)
    main_window._start_panel = panel
    # Once startup is out of the way: thumbnails for what is already on the list.
    QTimer.singleShot(4000, panel.read_missing)
    return panel
