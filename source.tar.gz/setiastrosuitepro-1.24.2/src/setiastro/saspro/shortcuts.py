# saspro/shortcuts.py
from __future__ import annotations
import json
import time
from dataclasses import dataclass
from typing import Dict, Optional
import uuid
import numpy as np

from PyQt6.QtCore import (Qt, QPoint, QRect, QMimeData, QSettings, QByteArray,
                          QDataStream, QIODevice, QEvent, QSize)
from PyQt6.QtGui import (QAction, QDrag, QIcon, QMouseEvent, QPixmap, QKeyEvent, QKeyEvent, QCursor, QKeySequence)
from PyQt6.QtWidgets import (QToolBar, QWidget, QToolButton, QMenu, QApplication, QVBoxLayout, QHBoxLayout, QComboBox, QGroupBox, QGridLayout, QDoubleSpinBox, QSpinBox,
                             QInputDialog, QMessageBox, QDialog, QSlider,
    QFormLayout, QDialogButtonBox, QDoubleSpinBox, QCheckBox, QLabel, QRubberBand, QRadioButton, QPlainTextEdit, QTabWidget, QLineEdit, QPushButton, QFileDialog)

from PyQt6.QtWidgets import QMdiArea, QMdiSubWindow
# _LinearFitPresetDialog loaded on demand (see line ~334)



try:
    from PyQt6 import sip
except Exception:
    sip = None
    
from setiastro.saspro.dnd_mime import (MIME_VIEWSTATE, MIME_CMD, MIME_MASK,
                                       MIME_ACTION, MIME_SHORTCUT_MOVE)

from pathlib import Path
import os  # ← NEW

SASS_KIND   = "sas.shortcuts"
SASS_VER    = 1

TOOLBAR_REORDER_MIME = "application/x-saspro-toolbar-reorder"
# Accept these endings (case-insensitive)
OPENABLE_ENDINGS = (
    ".png", ".jpg", ".jpeg", ".webp",
    ".tif", ".tiff",
    ".fits", ".fit", ".fts",
    ".fits.gz", ".fit.gz", ".fz",
    ".xisf",
    ".psb", ".psd",
    ".syq",
    ".cr2", ".cr3", ".nef", ".arw", ".dng", ".raf", ".orf", ".rw2", ".pef",
)

_ICONS = None

def _get_icons():
    """Lazy-load icons so shortcuts.py can be imported early without circular deps."""
    global _ICONS
    if _ICONS is not None:
        return _ICONS

    # Find where get_icons() lives in your project and import it here.
    # Try a couple common locations; keep the first that exists in your tree.
    try:
        from setiastro.saspro.resources import get_icons as _gi
    except Exception:
        _gi = None
        
    _ICONS = _gi() if _gi else None
    return _ICONS


def _is_dead(w) -> bool:
    """True if widget is None or its C++ has been destroyed."""
    if w is None:
        return True
    if sip is not None:
        try:
            return sip.isdeleted(w)
        except Exception:
            return False
    # sip not available: best-effort heuristic
    try:
        _ = w.parent()  # will raise on dead wrappers
        return False
    except RuntimeError:
        return True

# ---------- constants / helpers ----------

SET_KEY_V1 = "Shortcuts/v1"   # legacy (id-less)
SET_KEY_V2 = "Shortcuts/v2"   # new: stores id, label, etc.
SET_KEY = SET_KEY_V2
KEYBINDS_KEY = "Keybinds/v1"   # JSON dict: {command_id: "Ctrl+Alt+S"}

# Used when dragging a DESKTOP shortcut onto a view for headless run


def _pack_cmd_payload(command_id: str, preset: dict | None = None,
                      name: str | None = None) -> bytes:
    payload = {"command_id": command_id, "preset": preset or {}}
    if name:
        payload["name"] = str(name)
    return json.dumps(payload).encode("utf-8")

def _unpack_cmd_payload(b: bytes) -> dict:
    return json.loads(b.decode("utf-8"))


@dataclass
class ShortcutEntry:
    shortcut_id: str
    command_id: str
    x: int
    y: int
    label: str

# ---------- a QToolBar that supports Alt+drag to create shortcuts ----------
class DraggableToolBar(QToolBar):
    """
    Alt/Ctrl/Shift + Left-drag a toolbar button to create a desktop shortcut.
    We hook QToolButton children (not the toolbar itself), because
    mouse events go to the buttons.
    """
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self._press_pos: dict[QToolButton, QPoint] = {}
        self._dragging_from: QToolButton | None = None
        self._press_had_mod: dict[QToolButton, bool] = {}
        self._suppress_release: set[QToolButton] = set()
        self._settings_key: str | None = None
        self.setAcceptDrops(True)

    def window(self):
        """Always return the main window, even when this toolbar is floating.

        QToolBar.window() returns self when floating (because a floating
        toolbar is its own top-level widget).  Every method that calls
        self.window() expecting the main window — settings, hide/unhide,
        shortcut creation, toolbar reset — silently breaks or crashes
        in that state.  parent() always points to the main window
        regardless of dock/float state.
        """
        p = self.parent()
        return p if p is not None else super().window()

    def _mods_ok(self, mods: Qt.KeyboardModifiers) -> bool:
        return bool(mods & (
            Qt.KeyboardModifier.AltModifier |
            Qt.KeyboardModifier.ControlModifier |
            Qt.KeyboardModifier.ShiftModifier
        ))

    # NEW: called by main window / mixin
    def setSettingsKey(self, key: str):
        self._settings_key = str(key)

    def _settings(self):
        mw = self.window()
        s = getattr(mw, "settings", None)
        if s is None:
            from PyQt6.QtCore import QSettings
            s = QSettings()
        return s

    def _action_id(self, act: QAction) -> str | None:
        cid = act.property("command_id") or act.objectName()
        return str(cid) if cid else None

    def _hidden_key(self) -> str | None:
        if not self._settings_key:
            return None
        return f"{self._settings_key}/Hidden"

    def _load_hidden_set(self) -> set[str]:
        k = self._hidden_key()
        if not k:
            return set()
        s = self._settings()
        raw = s.value(k, [], type=list)
        # QSettings sometimes returns strings instead of list depending on backend
        if isinstance(raw, str):
            return {raw}
        return {str(x) for x in (raw or [])}

    def _save_hidden_set(self, hidden: set[str]):
        k = self._hidden_key()
        if not k:
            return
        s = self._settings()
        s.setValue(k, sorted(hidden))

    def _set_action_hidden(self, act: QAction, hide: bool):
        cid = self._action_id(act)
        if not cid:
            return
        hidden = self._load_hidden_set()
        if hide:
            hidden.add(cid)
            act.setVisible(False)
        else:
            hidden.discard(cid)
            act.setVisible(True)
        self._save_hidden_set(hidden)

    def apply_hidden_state(self):
        """Call after toolbar is populated / order restored."""
        hidden = self._load_hidden_set()
        if not hidden:
            return
        for act in self.actions():
            cid = self._action_id(act)
            if cid and cid in hidden:
                act.setVisible(False)


    def _persist_order(self):
        """Persist current action order (by command_id/objectName) to QSettings."""
        if not self._settings_key:
            return

        # Prefer main-window settings if available
        mw = self.window()
        s = getattr(mw, "settings", None)
        if s is None:
            from PyQt6.QtCore import QSettings
            s = QSettings()

        ids: list[str] = []
        for act in self.actions():
            cid = act.property("command_id") or act.objectName()
            if cid:
                ids.append(str(cid))

        s.setValue(self._settings_key, ids)


    def _is_locked(self) -> bool:
        """Check if toolbar icon movement is locked globally."""
        s = self._settings()
        # Default to False (unlocked)
        return s.value("UI/ToolbarLocked", False, type=bool)

    def _set_locked(self, locked: bool):
        """Set the global lock state."""
        s = self._settings()
        s.setValue("UI/ToolbarLocked", locked)

    # install/remove our event filter when actions are added/removed
    def actionEvent(self, e):
        super().actionEvent(e)
        t = e.type()
        if t == QEvent.Type.ActionAdded:
            act = e.action()
            btn = self.widgetForAction(act)
            if isinstance(btn, QToolButton):
                btn.installEventFilter(self)
        elif t == QEvent.Type.ActionRemoved:
            act = e.action()
            btn = self.widgetForAction(act)
            if isinstance(btn, QToolButton):
                try:
                    btn.removeEventFilter(self)
                except Exception:
                    pass

    def eventFilter(self, obj, ev):
        if isinstance(obj, QToolButton):
            # RIGHT CLICK → show "Create Desktop Shortcut"
            if ev.type() == QEvent.Type.MouseButtonPress and ev.button() == Qt.MouseButton.RightButton:
                act = self._find_action_for_button(obj)
                if act:
                    self._show_toolbutton_context_menu(obj, act, ev.globalPosition().toPoint())
                    return True  # consume
                return False

            # Keyboard/trackpad context menu event
            if ev.type() == QEvent.Type.ContextMenu:
                act = self._find_action_for_button(obj)
                if act:
                    self._show_toolbutton_context_menu(obj, act, ev.globalPos())
                    return True
                return False            

            # L-press: remember start + whether a drag-modifier was held
            if ev.type() == QEvent.Type.MouseButtonPress and ev.button() == Qt.MouseButton.LeftButton:
                self._press_pos[obj] = ev.globalPosition().toPoint()
                self._press_had_mod[obj] = self._mods_ok(QApplication.keyboardModifiers())
                return False  # allow normal press visuals

            # Move with L held → start ONE unified drag. No modifier required.
            #
            # The drag carries every payload the possible drop targets know how
            # to read, and the TARGET decides what happens on drop:
            #   • dropped on a View           → runs the command      (MIME_CMD)
            #   • dropped on the empty canvas → creates a shortcut     (MIME_ACTION)
            #   • dropped back on a toolbar   → reorders the button    (TOOLBAR_REORDER_MIME)
            #
            # Alt/Ctrl/Shift are no longer needed. The only thing the lock still
            # changes is whether the reorder payload is offered.
            if ev.type() == QEvent.Type.MouseMove and (ev.buttons() & Qt.MouseButton.LeftButton):
                start = self._press_pos.get(obj)
                if start is not None:
                    delta = ev.globalPosition().toPoint() - start
                    if delta.manhattanLength() > QApplication.startDragDistance():
                        act = self._find_action_for_button(obj)
                        if act is not None:
                            self._start_unified_drag_for_button(
                                obj, act, allow_reorder=not self._is_locked()
                            )
                            self._suppress_release.add(obj)
                        self._press_pos.pop(obj, None)
                        self._press_had_mod.pop(obj, None)
                        return True  # consume
                return False

            # Release: if we started any drag, swallow the release so click won't fire
            if ev.type() == QEvent.Type.MouseButtonRelease and ev.button() == Qt.MouseButton.LeftButton:
                self._press_pos.pop(obj, None)
                self._press_had_mod.pop(obj, None)
                if obj in self._suppress_release:
                    self._suppress_release.discard(obj)
                    return True   # eat release → no click
                return False

        return super().eventFilter(obj, ev)

    def _start_unified_drag_for_button(self, btn: QToolButton, act: QAction,
                                       allow_reorder: bool = True):
        act_id = act.property("command_id") or act.objectName()
        if not act_id:
            return
        act_id = str(act_id)

        md = QMimeData()

        # 1) run-on-view payload (carries per-command preset if one is stored)
        s = QSettings()
        raw = s.value(f"presets/{act_id}", "", type=str) or ""
        try:
            preset = json.loads(raw) if raw else {}
        except Exception:
            preset = {}
        md.setData(MIME_CMD, _pack_cmd_payload(act_id, preset, name=act.text() or None))

        # 2) create-shortcut-on-canvas payload
        md.setData(MIME_ACTION, act_id.encode("utf-8"))

        # 3) reorder handshake — only when the toolbar is unlocked
        if allow_reorder:
            md.setData(TOOLBAR_REORDER_MIME, b"1")

        drag = QDrag(btn)  # source MUST be the button for reorder drops
        drag.setMimeData(md)
        pm = act.icon().pixmap(32, 32) if not act.icon().isNull() else QPixmap(32, 32)
        if pm.isNull():
            pm = QPixmap(32, 32); pm.fill(Qt.GlobalColor.darkGray)
        drag.setPixmap(pm)
        drag.setHotSpot(pm.rect().center())
        drag.exec(Qt.DropAction.CopyAction | Qt.DropAction.MoveAction,
                  Qt.DropAction.CopyAction)

    def _start_drag_for_action(self, act: QAction):
        act_id = act.property("command_id") or act.objectName()
        if not act_id:
            return

        mods = QApplication.keyboardModifiers()
        alt = bool(mods & Qt.KeyboardModifier.AltModifier)

        md = QMimeData()
        if alt:
            # Put BOTH payloads on the drag:
            # 1) MIME_CMD → lets you drop directly on a View or Function Bundle chip
            #    (use per-command preset if available, else empty dict)
            s = QSettings()
            raw = s.value(f"presets/{act_id}", "", type=str) or ""
            try:
                preset = json.loads(raw) if raw else {}
            except Exception:
                preset = {}
            md.setData(MIME_CMD, _pack_cmd_payload(act_id, preset))

            # 2) MIME_ACTION → canvas still interprets this to create a desktop shortcut
            md.setData(MIME_ACTION, act_id.encode("utf-8"))
        else:
            # Ctrl/Shift (legacy): only create a desktop shortcut
            md.setData(MIME_ACTION, act_id.encode("utf-8"))

        drag = QDrag(self)
        drag.setMimeData(md)
        pm = act.icon().pixmap(32, 32) if not act.icon().isNull() else QPixmap(32, 32)
        if pm.isNull():
            pm = QPixmap(32, 32); pm.fill(Qt.GlobalColor.darkGray)
        drag.setPixmap(pm)
        drag.setHotSpot(pm.rect().center())
        drag.exec(Qt.DropAction.CopyAction)

    def _start_reorder_drag_for_button(self, btn: QToolButton):
        """
        Start a drag whose only purpose is to reorder actions within THIS toolbar.
        No presets, no desktop shortcuts.
        """
        act = self._find_action_for_button(btn)
        if act is None:
            return

        md = QMimeData()
        # Tag this as an internal toolbar-reorder drag
        md.setData(TOOLBAR_REORDER_MIME, b"1")

        drag = QDrag(btn)
        drag.setMimeData(md)

        pm = act.icon().pixmap(32, 32) if not act.icon().isNull() else QPixmap(32, 32)
        if pm.isNull():
            pm = QPixmap(32, 32)
            pm.fill(Qt.GlobalColor.darkGray)
        drag.setPixmap(pm)
        drag.setHotSpot(pm.rect().center())
        drag.exec(Qt.DropAction.MoveAction)


    def _find_action_for_button(self, btn: QToolButton) -> QAction | None:
        # Find the QAction that owns this toolbutton
        for a in self.actions():
            if self.widgetForAction(a) is btn:
                return a
        return None

    def dragEnterEvent(self, e):
        # Accept toolbar-reorder drags from any DraggableToolBar
        if e.mimeData().hasFormat(TOOLBAR_REORDER_MIME):
            src = e.source()
            if isinstance(src, QToolButton) and isinstance(src.parent(), DraggableToolBar):
                e.acceptProposedAction()
                return
        super().dragEnterEvent(e)

    def dragMoveEvent(self, e):
        if e.mimeData().hasFormat(TOOLBAR_REORDER_MIME):
            src = e.source()
            if isinstance(src, QToolButton) and isinstance(src.parent(), DraggableToolBar):
                e.acceptProposedAction()
                return
        super().dragMoveEvent(e)

    def dropEvent(self, e):
        if e.mimeData().hasFormat(TOOLBAR_REORDER_MIME):
            src_btn = e.source()
            if isinstance(src_btn, QToolButton):
                src_tb = src_btn.parent()
                if isinstance(src_tb, DraggableToolBar):
                    # Find the QAction that belongs to the dragged button
                    src_act = src_tb._find_action_for_button(src_btn)
                    if src_act is None:
                        e.ignore()
                        return

                    pos = e.position().toPoint()
                    target_act = self.actionAt(pos)

                    # Remove from source toolbar and insert into this one
                    src_tb.removeAction(src_act)
                    if target_act is None:
                        self.addAction(src_act)
                    else:
                        self.insertAction(target_act, src_act)

                    # Persist order for both toolbars
                    self._persist_order()
                    if src_tb is not self:
                        src_tb._persist_order()
                        # Also persist the cross-toolbar assignment
                        self._update_assignment_for_action(src_act)

                    e.acceptProposedAction()
                    return

        super().dropEvent(e)


    def _update_assignment_for_action(self, act: QAction):
        """
        Persist that this action now belongs to this toolbar (cross-toolbar move).
        Stored as: Toolbar/Assignments → JSON {command_id: settings_key}.
        """
        if not self._settings_key:
            return

        cid = act.property("command_id") or act.objectName()
        if not cid:
            return

        mw = self.window()
        s = getattr(mw, "settings", None)
        if s is None:
            s = QSettings()

        raw = s.value("Toolbar/Assignments", "", type=str) or ""
        try:
            mapping = json.loads(raw) if raw else {}
        except Exception:
            mapping = {}

        mapping[str(cid)] = self._settings_key
        s.setValue("Toolbar/Assignments", json.dumps(mapping))


    def _add_shortcut_for_action(self, act: QAction):
        # Resolve command id
        act_id = act.property("command_id") or act.objectName()
        if not act_id:
            return
        # Find ShortcutManager on the main window
        mw = self.window()
        mgr = getattr(mw, "shortcuts", None)
        mdi = getattr(mw, "mdi", None)
        if mgr is None or mdi is None:
            return
        # Map current cursor pos (global) into the viewport
        gpos = QCursor.pos()
        vp   = mdi.viewport()
        pos  = vp.mapFromGlobal(gpos)
        # Clamp into viewport rect (center if way out of bounds)
        rect = vp.rect()
        if not rect.contains(pos):
            pos = rect.center()
        mgr.add_shortcut(str(act_id), pos)

    def _show_toolbutton_context_menu(self, btn: QToolButton, act: QAction, gpos: QPoint):
        m = QMenu(btn)

        m.addAction(self.tr("Create Desktop Shortcut"), lambda: self._add_shortcut_for_action(act))

        # Hide this icon
        cid = self._action_id(act)
        if cid:
            m.addSeparator()
            m.addAction(self.tr("Hide this icon"), lambda: self.parent()._hide_action_to_hidden_toolbar(act))


        # (Optional) teach users about Alt+Drag:
        m.addSeparator()
        tip = m.addAction(self.tr("Tip: Alt+Drag to create"))
        tip.setEnabled(False)

        m.exec(gpos)

    def contextMenuEvent(self, ev):
        # Right-click on empty toolbar area
        m = QMenu(self)

        # 1. Lock/Unlock Action
        is_locked = self._is_locked()
        act_lock = m.addAction(self.tr("Lock Toolbar Icons"))
        act_lock.setCheckable(True)
        act_lock.setChecked(is_locked)

        def _toggle_lock(checked):
            self._set_locked(checked)

        act_lock.triggered.connect(_toggle_lock)

        m.addSeparator()

        # Submenu listing hidden actions for this toolbar
        sub = m.addMenu(self.tr("Show hidden…"))

        mw = self.window()
        tb_hidden = getattr(mw, "_hidden_toolbar", lambda: None)()
        any_hidden = False
        if tb_hidden:
            for act in tb_hidden.actions():
                if act.isSeparator():
                    continue
                any_hidden = True
                sub.addAction(
                    act.text() or (act.property("command_id") or act.objectName() or "item"),
                    lambda a=act: mw._unhide_action_from_hidden_toolbar(a)
                )

        if not any_hidden:
            sub.setEnabled(False)

        m.addSeparator()
        m.addAction(self.tr("Reset hidden icons"), self._reset_hidden_icons)

        # ✅ NEW: Factory reset for all toolbars
        m.addSeparator()
        reset_all = m.addAction(self.tr("Reset ALL Toolbars (Factory Layout)"))
        reset_all.setStatusTip(self.tr("Clears saved toolbar positions/orders/hidden state and restores defaults"))
        reset_all.triggered.connect(lambda: getattr(self.window(), "_reset_all_toolbars_to_factory", lambda: None)())

        m.exec(ev.globalPos())


    def _reset_hidden_icons(self):
        mw = self.window()
        tb_hidden = getattr(mw, "_hidden_toolbar", lambda: None)()
        if not tb_hidden:
            return
        # copy list because we'll mutate
        acts = [a for a in tb_hidden.actions() if not a.isSeparator()]
        for a in acts:
            mw._unhide_action_from_hidden_toolbar(a)



_PRESET_UI_IDS = {
    "stat_stretch","star_stretch","crop","curves","ghs","abe","graxpert",
    "remove_stars","cosmic_clarity","cosmic","cosmicclarity","histogram_transform","levels",
    "convo","convolution","deconvolution","convo_deconvo",
    "linear_fit","wavescale_hdr","wavescale_dark_enhance","wavescale_dark_enhancer",
    "remove_green","star_align","background_neutral","white_balance","clahe",
    "morphology","pixel_math","rgb_align","signature_insert","signature_adder",
    "signature","halo_b_gon","geom_rescale","rescale","debayer","image_combine","geom_resize_canvas",
    "resize_canvas","canvas_resize","texture_clarity","aberrationai",
    "star_spikes","diffraction_spikes", "multiscale_decomp","geom_rotate_any","syqontools","rcastro",
    "satchroma","fx","unwarp","pedestal","cosmetic_correction",
    "export_fits","plate_solve","create_mask","srgc",
}

def _has_preset_editor_for_command(command_id: str) -> bool:
    """Return True if we have a bespoke UI for this command_id."""
    return command_id in _PRESET_UI_IDS

def _preset_opener_for_command(command_id: str):
    """
    Map a command_id → a callable(main_window, preset) that opens the LIVE tool
    dialog seeded from the preset. Distinct from _open_preset_editor_for_command
    (which opens a small preset-editing form). Returns None if none exists, in
    which case callers fall back to a plain QAction trigger.
    """
    if command_id == "crop":
        from setiastro.saspro.crop_dialog_pro import open_crop_with_preset
        return open_crop_with_preset    
    if command_id == "abe":
        from setiastro.saspro.abe_preset import open_abe_with_preset
        return open_abe_with_preset
    if command_id == "srgc":
        from setiastro.saspro.srgc_preset import open_srgc_with_preset
        return open_srgc_with_preset
    if command_id == "stat_stretch":
        from setiastro.saspro.stat_stretch import open_stat_stretch_with_preset
        return open_stat_stretch_with_preset
    if command_id == "star_stretch":
        from setiastro.saspro.star_stretch import open_star_stretch_with_preset
        return open_star_stretch_with_preset
    if command_id == "linear_fit":
        from setiastro.saspro.linear_fit import open_linear_fit_with_preset
        return open_linear_fit_with_preset
    if command_id in ("levels", "histogram_transform"):
        from setiastro.saspro.histogram_transform_pro import open_levels_with_preset
        return open_levels_with_preset
    if command_id == "curves":
        from setiastro.saspro.curves_preset import open_curves_with_preset
        return open_curves_with_preset
    if command_id == "ghs":
        from setiastro.saspro.ghs_preset import open_ghs_with_preset
        return open_ghs_with_preset
    if command_id == "satchroma":
        from setiastro.saspro.satchroma_preset import open_satchroma_with_preset
        return open_satchroma_with_preset
    if command_id == "graxpert":
        from setiastro.saspro.graxpert_preset import open_graxpert_with_preset
        return open_graxpert_with_preset
    if command_id == "background_neutral":
        from setiastro.saspro.backgroundneutral import open_background_neutral_with_preset
        return open_background_neutral_with_preset 
    if command_id == "white_balance":
        from setiastro.saspro.whitebalance import open_white_balance_with_preset
        return open_white_balance_with_preset      
    if command_id == "remove_stars":
        from setiastro.saspro.remove_stars_preset import open_remove_stars_with_preset
        return open_remove_stars_with_preset   
    if command_id == "remove_green":
        from setiastro.saspro.remove_green import open_remove_green_with_preset
        return open_remove_green_with_preset  
    if command_id == "convo":
        from setiastro.saspro.convo_preset import open_convo_with_preset
        return open_convo_with_preset  
    if command_id == "wavescale_hdr":
        from setiastro.saspro.wavescale_hdr import open_wavescale_hdr_with_preset
        return open_wavescale_hdr_with_preset
    if command_id == "wavescale_dark_enhance":
        from setiastro.saspro.wavescalede import open_wavescalede_with_preset
        return open_wavescalede_with_preset   
    if command_id == "clahe":
        from setiastro.saspro.clahe import open_clahe_with_preset
        return open_clahe_with_preset    
    if command_id == "texture_clarity":
        from setiastro.saspro.texture_clarity import open_texture_clarity_with_preset
        return open_texture_clarity_with_preset    
    if command_id == "fx":
        from setiastro.saspro.fx_module import open_fx_with_preset
        return open_fx_with_preset      
    if command_id == "morphology":
        from setiastro.saspro.morphology import open_morphology_with_preset
        return open_morphology_with_preset  
    if command_id == "halo_b_gon":
        from setiastro.saspro.halobgon import open_halo_b_gon_with_preset
        return open_halo_b_gon_with_preset    
    if command_id == "aberrationai":
        from setiastro.saspro.aberration_ai import open_aberration_ai_with_preset
        return open_aberration_ai_with_preset  
    if command_id in ("cosmic_clarity", "cosmic", "cosmicclarity"):
        from setiastro.saspro.cosmicclarity import open_cosmic_clarity_with_preset
        return open_cosmic_clarity_with_preset   
    if command_id == "rcastro":
        from setiastro.saspro.rcastro import open_rcastro_with_preset
        return open_rcastro_with_preset 
    if command_id == "syqontools":
        from setiastro.saspro.syqon_tools import open_syqontools_with_preset
        return open_syqontools_with_preset   
    if command_id == "multiscale_decomp":
        from setiastro.saspro.multiscale_decomp import open_multiscale_decomp_with_preset
        return open_multiscale_decomp_with_preset
    if command_id == "unwarp":
        from setiastro.saspro.unwarp import open_unwarp_with_preset
        return open_unwarp_with_preset
    if command_id == "pedestal":
        from setiastro.saspro.pedestal import open_remove_pedestal_with_preset
        return open_remove_pedestal_with_preset 
    if command_id == "cosmetic_correction":
        from setiastro.saspro.cosmetic_correction import open_cosmetic_correction_with_preset
        return open_cosmetic_correction_with_preset
    if command_id == "export_fits":
        from setiastro.saspro.export_fits import open_export_fits_with_preset
        return open_export_fits_with_preset
    if command_id == "plate_solve":
        from setiastro.saspro.plate_solver import open_plate_solver_with_preset
        return open_plate_solver_with_preset
    if command_id == "create_mask":
        # Toolbar id is "create_mask" (toolbar_mixin.reg("create_mask", …)),
        # not "mask_creation". ShortcutManager.trigger_with_preset looks the
        # opener up by the id a shortcut carries, so the branch must match
        # that registration — otherwise double-clicking a mask shortcut
        # falls back to the bare QAction and ignores the stored preset.
        from setiastro.saspro.mask_creation import open_mask_creation_with_preset
        return open_mask_creation_with_preset
    return None

# ---- Shared preset editor helper for other modules (e.g. Function Bundles) ----
def _open_preset_editor_for_command(parent, command_id: str, initial: dict | None):
    """
    Open the same command-specific preset editor UIs used by ShortcutButton.
    Returns a dict on success (OK), or None if cancelled / no editor available.
    """
    cur = initial or {}

    # Keep each branch self-contained with local imports to avoid heavy module churn.
    if command_id == "stat_stretch":
        dlg = _StatStretchPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "star_stretch":
        dlg = _StarStretchPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "crop":
        from setiastro.saspro.shortcuts import _CropPresetDialog
        dlg = _CropPresetDialog(parent, initial=cur or {
            "mode": "margins",
            "margins": {"top": 0, "right": 0, "bottom": 0, "left": 0},
            "create_new_view": False
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "geom_rotate_any":
        dlg = _GeomRotateAnyPresetDialog(parent, initial=cur or {
            "angle_deg": 0.0,
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    if command_id == "pedestal":
        dlg = _RemovePedestalPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    if command_id == "srgc":
        dlg = _SRGCPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    if command_id == "curves":
        dlg = _CurvesPresetDialog(parent, initial=cur or {"shape":"linear","amount":0.5,"mode":"K (Brightness)"})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id in ("levels", "histogram_transform"):
        dlg = _LevelsPresetDialog(parent, initial=cur or {
            "black": 0.0,
            "mid": 0.5,
            "white": 1.0,
            "channel": "L",              # "L","R","G","B"
            "live_preview": True,        # optional; UI-only but harmless
            "apply_mode": "inplace",     # "inplace" or "new_view"
            "new_view_title": "Levels",
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "satchroma":
        from setiastro.saspro.shortcuts import _SatChromaPresetDialog
        dlg = _SatChromaPresetDialog(parent, initial=cur or {
            "mode":     0,
            "strength": 1.0,
            "points":   [
                (0.0, 1.0), (1/6, 1.0), (2/6, 1.0),
                (3/6, 1.0), (4/6, 1.0), (5/6, 1.0), (1.0, 1.0),
            ],
            "use_mask": True,
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "fx":
        from setiastro.saspro.shortcuts import _FXPresetDialog
        dlg = _FXPresetDialog(parent, initial=cur or {"effect": "orton_glow"})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    if command_id == "unwarp":
        from setiastro.saspro.unwarp import _UnwarpPresetDialog
        dlg = _UnwarpPresetDialog(parent, initial=cur or {"expand": True, "order": 3, "fill_nan": False})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    if command_id == "export_fits":
        from setiastro.saspro.export_fits import ExportFitsPresetDialog
        dlg = ExportFitsPresetDialog(parent, initial=cur or {"out_dir": "", "overwrite": True})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    if command_id == "plate_solve":
        from setiastro.saspro.plate_solver import PlateSolverPresetDialog
        dlg = PlateSolverPresetDialog(parent, initial=cur or {})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    if command_id == "create_mask":
        # Same note as _preset_opener_for_command: must match the id the
        # action was registered under (toolbar_mixin: "create_mask"), not
        # the Python module name. Right-clicking a mask shortcut → Edit
        # Preset routes through here, so a mismatched id was giving the
        # user an empty dialog with no fields.
        dlg = _MaskCreationPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    if command_id == "syqontools":
        dlg = _SyQonToolsPresetDialog(parent, initial=cur or {})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "ghs":
        dlg = _GHSPresetDialog(parent, initial=cur or {
            "alpha":1.0,"beta":1.0,"gamma":1.0,"pivot":0.5,"lp":0.0,"hp":0.0,"channel":"K (Brightness)"
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "abe":
        dlg = _ABEPresetDialog(parent, initial=cur or {
            "degree":2, "samples":120, "downsample":6, "patch":15, "rbf":True, "rbf_smooth":1.0, "make_background_doc":False
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "graxpert":
        from setiastro.saspro.graxpert_preset import GraXpertPresetDialog
        dlg = GraXpertPresetDialog(parent, initial=cur or {"smoothing":0.10,"gpu":True})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "remove_stars":
        from setiastro.saspro.remove_stars_preset import RemoveStarsPresetDialog
        dlg = RemoveStarsPresetDialog(parent, initial=cur or {"tool":"starnet","linear":True})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id in ("cosmic_clarity","cosmic","cosmicclarity"):
        from setiastro.saspro.cosmicclarity_preset import _CosmicClarityPresetDialog
        dlg = _CosmicClarityPresetDialog(parent, initial=cur or {
            "mode":"sharpen","gpu":True,"create_new_view":False,"sharpening_mode":"Both",
            "auto_psf":True,"nonstellar_psf":3.0,"stellar_amount":0.50,"nonstellar_amount":0.50,
            "denoise_luma":0.50,"denoise_color":0.50,"denoise_mode":"full","separate_channels":False,"scale":2
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "texture_clarity":
        dlg = _TextureClarityPresetDialog(parent, initial=cur or {
            "t_amt": 0.0, "t_rad": 1.0,
            "u_amt": 0.0, "u_rad": 2.0, "u_thr": 0.0,
            "c_amt": 0.0, "c_rad": 3.0,
            "mask_str": 1.0,
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "rcastro":
        from setiastro.saspro.rcastro import RCAstroPresetDialog
        dlg = RCAstroPresetDialog(parent, initial=cur or {
            "product": "bxt", "engine": "auto",
            "sharpen_stars": 0.0, "auto_nsr": True,
            "sharpen_nonstellar": 0.0,
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id in ("convo","convolution","deconvolution","convo_deconvo"):
        from setiastro.saspro.convo_preset import ConvoPresetDialog
        dlg = ConvoPresetDialog(parent, initial=cur or {
            "op":"convolution","radius":5.0,"kurtosis":2.0,"aspect":1.0,"rotation":0.0,"strength":1.0
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "linear_fit":
        from setiastro.saspro.linear_fit import _LinearFitPresetDialog
        dlg = _LinearFitPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "wavescale_hdr":
        from setiastro.saspro.wavescale_hdr_preset import WaveScaleHDRPresetDialog
        dlg = WaveScaleHDRPresetDialog(parent, initial=cur or {"n_scales":5,"compression_factor":1.5,"mask_gamma":5.0})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id in ("wavescale_dark_enhance","wavescale_dark_enhancer"):
        from setiastro.saspro.wavescalede_preset import WaveScaleDSEPresetDialog
        dlg = WaveScaleDSEPresetDialog(parent, initial=cur or {
            "n_scales":6,"boost_factor":5.0,"mask_gamma":1.0,"iterations":2
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "multiscale_decomp":
        from setiastro.saspro.multiscale_decomp import _MultiScaleDecompPresetDialog
        dlg = _MultiScaleDecompPresetDialog(parent, initial=cur or {
            "layers": 4,
            "base_sigma": 1.0,
            "linked_rgb": True,
            "layers_cfg": [],
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "remove_green":
        dlg = _RemoveGreenPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "star_align":
        from setiastro.saspro.star_alignment_preset import StarAlignmentPresetDialog
        dlg = StarAlignmentPresetDialog(parent, initial=cur or {"ref_mode":"active","overwrite":False,"downsample":2})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "background_neutral":
        dlg = _BackgroundNeutralPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "white_balance":
        dlg = _WhiteBalancePresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "clahe":
        dlg = _CLAHEPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "morphology":
        dlg = _MorphologyPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "pixel_math":
        dlg = _PixelMathPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "cosmetic_correction":
        dlg = _CosmeticCorrectionPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "rgb_align":
        dlg = _RGBAlignPresetDialog(parent, initial=cur or {"model":"homography","new_doc":True})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id in ("signature_insert","signature_adder","signature"):
        dlg = _SignatureInsertPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "halo_b_gon":
        dlg = _HaloBGonPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    if command_id == "aberrationai":
        from setiastro.saspro.aberration_ai_preset import AberrationAIPresetDialog
        dlg = AberrationAIPresetDialog(parent, initial=cur or {
            "patch": 512, "overlap": 64, "border_px": 10, "auto_gpu": True,
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    if command_id in ("geom_rescale","rescale"):
        dlg = _RescalePresetDialog(parent, initial=cur or {"factor":1.0})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    
    if command_id in ("geom_resize_canvas", "resize_canvas", "canvas_resize"):
        from setiastro.saspro.shortcuts import _ResizeCanvasPresetDialog
        dlg = _ResizeCanvasPresetDialog(parent, initial=cur or {
            "width": 0,
            "height": 0,
            "anchor": "center",
            "fill_value": 0.0,
            "update_wcs": True,
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None
    
    if command_id == "debayer":
        dlg = _DebayerPresetDialog(parent, initial=cur or {"pattern":"auto"})
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id == "image_combine":
        dlg = _ImageCombinePresetDialog(parent, initial=cur or {
            "mode":"Blend","opacity":1.0,"luma_only":False,"output":"replace","docB_title":""
        })
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    if command_id in ("star_spikes","diffraction_spikes"):
        dlg = _StarSpikesPresetDialog(parent, initial=cur)
        return dlg.result_dict() if dlg.exec() == QDialog.DialogCode.Accepted else None

    # Unknown / no bespoke UI
    return None

# ---------- live-tool "drag me to the canvas" grip ----------
class PresetDragHandle(QToolButton):
    """
    PI-style grip for a live tool dialog. Dragging it emits a MIME_CMD-only
    payload whose preset is captured from the tool's CURRENT UI via get_preset().
    Dropped on empty canvas → ShortcutCanvas creates a shortcut carrying those
    live settings; dropped on an image view → runs the tool headlessly with them.
    """
    def __init__(self, command_id: str, get_preset, *, icon: QIcon | None = None,
                 tooltip: str | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self._command_id = str(command_id)
        self._get_preset = get_preset
        self._press_pos: QPoint | None = None
        if icon is not None and not icon.isNull():
            self.setIcon(icon)
            self.setIconSize(QSize(20, 20))
        else:
            self.setText("\u283f")
        self.setAutoRaise(True)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.setToolTip(tooltip or self.tr(
            "Drag to the canvas to create a shortcut with the current settings"))

    def mousePressEvent(self, e: QMouseEvent):
        if e.button() == Qt.MouseButton.LeftButton:
            self._press_pos = e.position().toPoint()
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e: QMouseEvent):
        if (self._press_pos is not None
                and (e.buttons() & Qt.MouseButton.LeftButton)
                and (e.position().toPoint() - self._press_pos).manhattanLength()
                    >= QApplication.startDragDistance()):
            self._press_pos = None
            self._start_drag()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e: QMouseEvent):
        self._press_pos = None
        super().mouseReleaseEvent(e)

    def _build_preset(self) -> dict:
        try:
            p = self._get_preset() or {}
            return p if isinstance(p, dict) else dict(p)
        except Exception:
            return {}

    def _start_drag(self):
        preset = self._build_preset()
        try:
            packed = _pack_cmd_payload(self._command_id, preset)
        except Exception as ex:
            import traceback
            print(f"[GRIP] _pack_cmd_payload RAISED: {type(ex).__name__}: {ex}", flush=True)
            traceback.print_exc()
            return
        md = QMimeData()
        md.setData(MIME_CMD, packed)
        drag = QDrag(self)
        drag.setMimeData(md)
        pm = self.icon().pixmap(32, 32) if not self.icon().isNull() else QPixmap(32, 32)
        if pm.isNull():
            pm = QPixmap(32, 32)
            pm.fill(Qt.GlobalColor.darkGray)
        drag.setPixmap(pm)
        drag.setHotSpot(pm.rect().center())
        drag.exec(Qt.DropAction.CopyAction)

# ---------- the button that sits on the MDI desktop ----------
class ShortcutButton(QToolButton):
    def __init__(self,
                 manager: "ShortcutManager",
                 sid: str,                 # NEW
                 command_id: str,
                 icon: QIcon,
                 label: str,               # NEW (display text)
                 parent: QWidget):
        super().__init__(parent)
        self._mgr = manager
        self.sid = sid                    # NEW
        self.command_id = command_id
        self.setIcon(icon)
        self.setText(label)               # use label instead of action text
        self.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self.setIconSize(QPixmap(32, 32).size())
        self.setAutoRaise(True)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._context_menu)
        self._dragging = False
        self._press_pos = None
        self._start_geom = None
        self._did_command_drag = False
        self._moved = False
        self.setToolTip(
            f"{label}\n• Double-click: open\n• Drag onto a view: headless apply\n• Drag on empty canvas: move"
        )

    # --- Preset helpers (QSettings) -------------------------------------
    def _preset_key(self) -> str:
        # per-instance key
        return f"presets/shortcuts/{self.sid}"

    def _load_preset(self) -> Optional[dict]:
        s = getattr(self._mgr, "settings", QSettings())
        raw = s.value(self._preset_key(), "", type=str) or ""
        if raw:
            try:
                return json.loads(raw)
            except Exception:
                pass
        # fallback: legacy per-command preset if instance hasn’t been saved yet
        legacy = s.value(f"presets/{self.command_id}", "", type=str) or ""
        if legacy:
            try:
                return json.loads(legacy)
            except Exception:
                pass
        return None

    def _save_preset(self, preset: Optional[dict]):
        s = getattr(self._mgr, "settings", QSettings())
        if preset is None:
            s.remove(self._preset_key())
        else:
            s.setValue(self._preset_key(), json.dumps(preset))
        s.sync()

    # --- Context menu (run / preset / delete) ----------------------------
    def _context_menu(self, pos):
        m = QMenu(self)
        m.addAction(self.tr("Run"), lambda: self._mgr.trigger(self.command_id))
        m.addSeparator()
        m.addAction(self.tr("Edit Preset…"), self._edit_preset_ui)
        m.addAction(self.tr("Clear Preset"), lambda: self._save_preset(None))
        m.addAction(self.tr("Rename…"), self._rename)                    # ← NEW
        m.addSeparator()
        m.addAction(self.tr("Delete"), self._delete)
        m.exec(self.mapToGlobal(pos))

    def _rename(self):
        current = self.text()
        new_name, ok = QInputDialog.getText(self, self.tr("Rename Shortcut"), self.tr("Name:"), text=current)
        if not ok or not new_name.strip():
            return
        self.setText(new_name.strip())
        self._mgr.update_label(self.sid, new_name.strip())   # ← was self.shortcut_id

    def _edit_preset_ui(self):
        cid = self.command_id
        cur = self._load_preset() or {}
        result = _open_preset_editor_for_command(self, cid, cur)
        if result is not None:
            self._save_preset(result)
            QMessageBox.information(self, self.tr("Preset saved"), self.tr("Preset stored on shortcut."))
            return

        # Fallback: JSON editor
        raw = json.dumps(cur or {}, indent=2)
        text, ok = QInputDialog.getMultiLineText(self, self.tr("Edit Preset (JSON)"), self.tr("Preset:"), raw)
        if ok:
            try:
                preset = json.loads(text or "{}")
                if not isinstance(preset, dict):
                    raise ValueError(self.tr("Preset must be a JSON object"))
                self._save_preset(preset)
                QMessageBox.information(self, self.tr("Preset saved"), self.tr("Preset stored on shortcut."))
            except Exception as e:
                QMessageBox.warning(self, self.tr("Invalid JSON"), str(e))


    def _start_command_drag(self):
        md = QMimeData()
     
        md.setData(MIME_CMD, _pack_cmd_payload(
            self.command_id, self._load_preset() or {}, name=self.text()))
        drag = QDrag(self)
        drag.setMimeData(md)
        pm = self.icon().pixmap(32, 32)
        if pm.isNull():
            pm = QPixmap(32, 32); pm.fill(Qt.GlobalColor.darkGray)
        drag.setPixmap(pm)
        drag.setHotSpot(pm.rect().center())
        drag.exec(Qt.DropAction.CopyAction)
        self._did_command_drag = True

    # --- Mouse handlers --------------------------------------------------
    def mousePressEvent(self, e: QMouseEvent):
        if e.button() == Qt.MouseButton.LeftButton:
            mods = QApplication.keyboardModifiers()

            if mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier):
                self._mgr.toggle_select(self.sid)
                return

            if self.sid not in self._mgr.selected:
                self._mgr.select_only(self.sid)

            self._dragging = True
            self._press_pos = e.globalPosition().toPoint()

        super().mousePressEvent(e)

    def mouseMoveEvent(self, e: QMouseEvent):
        if (self._dragging
                and self._press_pos is not None
                and (e.buttons() & Qt.MouseButton.LeftButton)
                and (e.globalPosition().toPoint() - self._press_pos).manhattanLength()
                    >= QApplication.startDragDistance()):
            self._dragging = False
            self._press_pos = None
            self._start_shortcut_drag()          # ONE real QDrag; the target decides
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e: QMouseEvent):
        self._dragging = False
        self._press_pos = None
        super().mouseReleaseEvent(e)

    def _start_shortcut_drag(self):
        """
        Start ONE real drag from this canvas shortcut. No modifier required.

        The payload is understood by every existing MIME_CMD drop target:
          - a View                -> runs the command (ImageSubWindow.dropEvent)
          - a Function Bundle chip -> appends the step
          - the Workflow Assistant -> adds the step to a lane
        Plus MIME_SHORTCUT_MOVE (the sid), so dropping back on the empty canvas
        MOVES this icon instead of creating a duplicate.

        Multi-selection is a pure group MOVE: we omit MIME_CMD so a stray drop
        on a view/chip can't fire one command out of many - only the canvas,
        which reads MIME_SHORTCUT_MOVE, accepts it and shifts the whole group.
        """
        md = QMimeData()
        multi = len(self._mgr.selected) > 1

        if not multi:
            md.setData(MIME_CMD, _pack_cmd_payload(
                self.command_id, self._load_preset() or {}, name=self.text()))

        # Canvas reposition handshake (records which icon initiated the drag)
        md.setData(MIME_SHORTCUT_MOVE, self.sid.encode("utf-8"))

        drag = QDrag(self)
        drag.setMimeData(md)
        pm = self.icon().pixmap(32, 32)
        if pm.isNull():
            pm = QPixmap(32, 32); pm.fill(Qt.GlobalColor.darkGray)
        drag.setPixmap(pm)
        drag.setHotSpot(pm.rect().center())
        drag.exec(Qt.DropAction.CopyAction | Qt.DropAction.MoveAction,
                  Qt.DropAction.CopyAction)

    def mouseDoubleClickEvent(self, e: QMouseEvent):
        # Double-click opens the tool. If this shortcut carries a preset, route
        # through the preset-aware opener so the dialog is seeded (manual points,
        # correction mode, etc.); otherwise plain-trigger the QAction as before.
        preset = None
        try:
            preset = self._load_preset()
        except Exception:
            preset = None
        self._mgr.trigger_with_preset(self.command_id, preset)

    def _delete(self):
        self._mgr.delete_by_id(self.sid, persist=True)       # ← was command_id


def _open_view_bundles_from_canvas(w):
    try:
        from setiastro.saspro.view_bundle import show_view_bundles
        mw = _find_main_window(w)
        show_view_bundles(mw)
    except Exception:
        pass

def _open_function_bundles_from_canvas(w):
    try:
        from setiastro.saspro.function_bundle import show_function_bundles
        mw = _find_main_window(w)
        show_function_bundles(mw)
    except Exception:
        pass

def _find_main_window(w):
    p = w.parent()
    while p is not None and not (hasattr(p, "doc_manager") or hasattr(p, "docman")):
        p = p.parent()
    return p

# ---------- overlay canvas that sits on top of QMdiArea.viewport() ----------
class ShortcutCanvas(QWidget):
    def __init__(self, mgr: "ShortcutManager", parent: QWidget):
        super().__init__(parent)
        self._mgr = mgr
        self.setAcceptDrops(True)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet("background: transparent;")        
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, False)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self.setGeometry(parent.rect())
        parent.installEventFilter(self)   # keep in sync with viewport size
        
        # NEW: rubber-band selection
        self._rubber = QRubberBand(QRubberBand.Shape.Rectangle, self)
        self._rubber_origin = None
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)  # to receive Delete/Ctrl+A  
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.DefaultContextMenu)      

    def eventFilter(self, obj, ev):
        # keep sized with the viewport -- unless a canvas owns our
        # geometry, in which case we are the size of the whole workspace
        # and it decides where we sit.
        if obj is self.parent() and ev.type() == ev.Type.Resize:
            canvas = getattr(getattr(self._mgr, "mdi", None), "canvas", None)
            if canvas is None:
                self.setGeometry(self.parent().rect())
            else:
                canvas.schedule_refresh()
            try:
                self._mgr.reflow_into_view()
            except Exception:
                pass
        return super().eventFilter(obj, ev)

    # --- rubber-band selection on empty space ---
    def mousePressEvent(self, e: QMouseEvent):
        if e.button() == Qt.MouseButton.LeftButton:
            local = e.position().toPoint()
            # If click hits no child (shortcut), start rubber-band
            if self.childAt(local) is None:
                self._rubber_origin = local
                self._rubber.setGeometry(QRect(self._rubber_origin, self._rubber_origin))
                self._rubber.show()
                # if no add/toggle mods, clear selection first
                if not (QApplication.keyboardModifiers() & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier)):
                    self._mgr.clear_selection()
                self.setFocus()
                e.accept()
                return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e: QMouseEvent):
        if self._rubber.isVisible() and self._rubber_origin is not None:
            rect = QRect(self._rubber_origin, e.position().toPoint()).normalized()
            self._rubber.setGeometry(rect)
            e.accept()
            return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e: QMouseEvent):
        if self._rubber.isVisible() and self._rubber_origin is not None:
            rect = QRect(self._rubber_origin, e.position().toPoint()).normalized()
            mode = "add" if (QApplication.keyboardModifiers() & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.ShiftModifier)) else "replace"
            self._rubber.hide()
            self._rubber_origin = None
            self._mgr.select_in_rect(rect, mode=mode)
            e.accept()
            return
        super().mouseReleaseEvent(e)

    # --- keyboard: Delete / Backspace / Ctrl+A ---
    def keyPressEvent(self, e: QKeyEvent):
        if e.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self._mgr.delete_selected()
            e.accept(); return
        if e.key() == Qt.Key.Key_A and (e.modifiers() & Qt.KeyboardModifier.ControlModifier):
            self._mgr.select_in_rect(self.rect(), mode="replace")
            e.accept(); return
        super().keyPressEvent(e)

    def dragEnterEvent(self, e):
        md = e.mimeData()
        if (md.hasFormat(MIME_ACTION) or md.hasFormat(MIME_CMD)
                or md.hasFormat(MIME_SHORTCUT_MOVE) or self._md_has_openable_urls(md)):
            self.raise_()
            e.acceptProposedAction()
        else:
            e.ignore()

    def _top_subwindow_at(self, vp_pos: QPoint) -> QMdiSubWindow | None:
        # Use the correct enum for PyQt6, fall back gracefully if unavailable
        try:
            order_enum = QMdiArea.WindowOrder  # PyQt6
            swlist = self._mgr.mdi.subWindowList(order_enum.StackingOrder)
        except Exception:
            # Fallback for older bindings
            swlist = self._mgr.mdi.subWindowList()

        # Iterate from front-most to back-most (StackingOrder is typically back->front)
        for sw in reversed(swlist):
            if not sw.isVisible():
                continue
            # QMdiSubWindow geometry is in the viewport's coordinate space
            if sw.geometry().contains(vp_pos):
                return sw
        return None

    def _forward_command_drop(self, e) -> bool:
        from PyQt6.QtWidgets import QApplication
        md = e.mimeData()
        if not md.hasFormat(MIME_CMD):
            return False
        sw = self._top_subwindow_at(e.position().toPoint())
        if sw is None:

            return False
        try:
            raw = bytes(md.data(MIME_CMD))
            payload = _unpack_cmd_payload(raw)  # your existing helper

        except Exception as ex:

            return False
        self._mgr.apply_command_to_subwindow(sw, payload)
        e.acceptProposedAction()
        return True


    def dragMoveEvent(self, e):
        md = e.mimeData()
        if (md.hasFormat(MIME_ACTION) or md.hasFormat(MIME_CMD)
                or md.hasFormat(MIME_SHORTCUT_MOVE) or self._md_has_openable_urls(md)):
            e.acceptProposedAction()
        else:
            e.ignore()

    def dragLeaveEvent(self, e):
        self.lower()                           # restore
        super().dragLeaveEvent(e)

    def dropEvent(self, e):
        md = e.mimeData()

        # 1) route function/preset drops to the front-most subwindow under cursor
        if self._forward_command_drop(e):
            self.lower()
            return

        # 1.5) an EXISTING canvas shortcut dropped on empty canvas → MOVE it
        #      (don't fall through to the create-shortcut path, which would
        #      duplicate it). We only reach here when 1) found no view under
        #      the cursor, i.e. this really is an empty-canvas drop.
        if md.hasFormat(MIME_SHORTCUT_MOVE):
            try:
                sid = bytes(md.data(MIME_SHORTCUT_MOVE)).decode("utf-8")
            except Exception:
                sid = ""
            if sid:
                self._mgr.move_shortcut_group_to(sid, e.position().toPoint())
                e.acceptProposedAction()
                self.lower()
                return

        # 2) command-only drops (no MIME_ACTION) → create a shortcut with preset
        #    This is used by History Explorer Alt+drag.
        if md.hasFormat(MIME_CMD) and not md.hasFormat(MIME_ACTION):
            try:
                raw = bytes(md.data(MIME_CMD))
                payload = _unpack_cmd_payload(raw)
            except Exception:
                payload = None

            if isinstance(payload, dict) and payload.get("command_id"):
                self._mgr.add_shortcut_from_payload(payload, e.position().toPoint())
                e.acceptProposedAction()
                self.lower()
                return

        # 3) desktop shortcut creation (MIME_ACTION) → create a button (no preset)
        if md.hasFormat(MIME_ACTION):
            act_id = bytes(md.data(MIME_ACTION)).decode("utf-8")
            self._mgr.add_shortcut(act_id, e.position().toPoint())
            e.acceptProposedAction()
            self.lower()
            return

        # 4) File / folder open (unchanged)
        if self._md_has_openable_urls(md):
            paths = self._collect_openable_files_from_urls(md)
            if paths:
                opener = getattr(self._mgr.mw, "_handle_external_file_drop", None)
                if callable(opener):
                    opener(paths)
                else:
                    dm = getattr(self._mgr.mw, "docman", None)
                    if dm and hasattr(dm, "open_files") and callable(dm.open_files):
                        docs = dm.open_files(paths)
                        try:
                            for d in (docs or []):
                                self._mgr.mw._spawn_subwindow_for(d)
                        except Exception:
                            pass
                    elif dm and hasattr(dm, "open_path") and callable(dm.open_path):
                        for p in paths:
                            doc = dm.open_path(p)
                            if doc is not None:
                                self._mgr.mw._spawn_subwindow_for(doc)
            e.acceptProposedAction()
            self.lower() 
            return
        self.lower()
        e.ignore()  

    def contextMenuEvent(self, e):
        menu = QMenu(self)
        sel_count = len(self._mgr.selected)
        has_sel = sel_count > 0
        has_multi = sel_count > 1
        has_three = sel_count > 2

        a_del = menu.addAction(self.tr("Delete Selected"), self._mgr.delete_selected)
        a_del.setEnabled(has_sel)

        a_clr = menu.addAction(self.tr("Clear Selection"), self._mgr.clear_selection)
        a_clr.setEnabled(has_sel)

        if has_multi:
            menu.addSeparator()

            layout_menu = menu.addMenu(self.tr("Organize Selected"))
            layout_menu.addAction(self.tr("Make Neat Row"), lambda: self._mgr.make_neat_row(16))
            layout_menu.addAction(self.tr("Make Neat Column"), lambda: self._mgr.make_neat_column(16))

            menu.addSeparator()

            align_menu = menu.addMenu(self.tr("Align Selected"))
            align_menu.addAction(self.tr("Align Left"), self._mgr.align_selected_left)
            align_menu.addAction(self.tr("Align Right"), self._mgr.align_selected_right)
            align_menu.addAction(self.tr("Align Top"), self._mgr.align_selected_top)
            align_menu.addAction(self.tr("Align Bottom"), self._mgr.align_selected_bottom)

            # Keep these if you still want them, but they're less useful
            align_menu.addSeparator()
            align_menu.addAction(self.tr("Align Centers Vertically"), self._mgr.align_selected_vcenter)
            align_menu.addAction(self.tr("Align Centers Horizontally"), self._mgr.align_selected_hcenter)

            distribute_menu = menu.addMenu(self.tr("Distribute Selected"))
            a_dist_h = distribute_menu.addAction(
                self.tr("Distribute Horizontally"),
                self._mgr.distribute_selected_horizontally
            )
            a_dist_v = distribute_menu.addAction(
                self.tr("Distribute Vertically"),
                self._mgr.distribute_selected_vertically
            )
            a_dist_h.setEnabled(has_three)
            a_dist_v.setEnabled(has_three)

        menu.addSeparator()
        menu.addAction(self.tr("View Bundles…"), lambda: _open_view_bundles_from_canvas(self))
        menu.addAction(self.tr("Function Bundles…"), lambda: _open_function_bundles_from_canvas(self))
        menu.exec(e.globalPos())


    def mouseDoubleClickEvent(self, e):
        # If user double-clicks empty canvas area, forward to MDI's handler
        if e.button() == Qt.MouseButton.LeftButton:
            local = e.position().toPoint()
            if self.childAt(local) is None:
                try:
                    # Reuse your existing connection: mdi.backgroundDoubleClicked -> open_files
                    self._mgr.mdi.backgroundDoubleClicked.emit()
                except Exception:
                    pass
                e.accept()
                return
        super().mouseDoubleClickEvent(e)

    def _is_openable_path(self, path: str) -> bool:
        return path.lower().endswith(OPENABLE_ENDINGS)

    def _md_has_openable_urls(self, md) -> bool:
        if not md.hasUrls():
            return False
        for u in md.urls():
            if not u.isLocalFile():
                continue
            p = u.toLocalFile()
            if os.path.isdir(p):
                return True  # we'll scan it on drop
            if self._is_openable_path(p):
                return True
        return False

    def _collect_openable_files_from_urls(self, md) -> list[str]:
        files: list[str] = []
        if not md.hasUrls():
            return files
        for u in md.urls():
            if not u.isLocalFile():
                continue
            p = u.toLocalFile()
            if os.path.isdir(p):
                # recurse folder for matching files
                for root, _, names in os.walk(p):
                    for name in names:
                        fp = os.path.join(root, name)
                        if self._is_openable_path(fp):
                            files.append(fp)
            else:
                if self._is_openable_path(p):
                    files.append(p)
        return files


class ShortcutManager:
    def __init__(self, mdi_area, main_window):
        # mdi_area should be your QMdiArea; we attach to its viewport
        self.mdi = mdi_area
        self.mw = main_window
        self.registry: Dict[str, QAction] = {}
        self.canvas = ShortcutCanvas(self, self.mdi.viewport())
        self.canvas.lower()  # keep below subwindows (raise() if you want pinned-on-top)
        self.canvas.show()
        self.widgets: Dict[str, ShortcutButton] = {}
        self.settings = QSettings()  # shared settings store for positions + presets
        self.selected: set[str] = set()  # ← set of shortcut_ids

        # --- persistence safety flags ---
        self._loading = False           # True while load_shortcuts() runs (suppresses saves)
        self._allow_empty_save = False  # True only for intentional clear / delete-all

    # ---- registry ----
    def register_action(self, command_id: str, action: QAction):
        action.setProperty("command_id", command_id)
        if not action.objectName():
            action.setObjectName(command_id)

        # Ensure action shortcuts work even if focus is in child widgets / MDI
        action.setShortcutContext(Qt.ShortcutContext.ApplicationShortcut)

        self.registry[command_id] = action

        # Apply saved keybind if present
        kb = self._load_keybinds().get(command_id)
        if kb:
            action.setShortcut(QKeySequence(kb))

    def find_keybind_conflicts(self) -> dict[str, list[str]]:
        # returns {"Ctrl+Alt+K": ["script:...", "stat_stretch"], ...}
        conflicts = {}
        for cid, act in self.registry.items():
            ks = act.shortcut().toString()
            if not ks:
                continue
            conflicts.setdefault(ks, []).append(cid)
        return {k:v for k,v in conflicts.items() if len(v) > 1}

    def trigger(self, command_id: str):
        act = self.registry.get(command_id)
        if act:
            act.trigger()

    def trigger_with_preset(self, command_id: str, preset: dict | None):
        """
        Like trigger(), but if a preset is present AND the command has a
        preset-aware opener, route through the opener so the tool dialog is
        seeded (settings, correction mode, manual points, etc.). Falls back
        to a plain QAction trigger when there's no preset or no opener.

        This is what makes double-clicking a desktop shortcut honor the preset
        it carries — the plain QAction (e.g. _open_abe_tool) builds a bare
        dialog and never sees the preset.
        """
        if not preset:
            return self.trigger(command_id)

        opener = _preset_opener_for_command(command_id)
        if opener is None:
            return self.trigger(command_id)

        try:
            opener(self.mw, preset)
            return
        except Exception as ex:
            self._debug(f"trigger_with_preset({command_id!r}) opener failed: {ex!r}; falling back to plain trigger")
            return self.trigger(command_id)

    def _on_widget_destroyed(self, sid: str):
        # Called from QObject.destroyed — never touch the widget, just clean maps.
        #
        # Defensive sid-identity guard: pop ONLY if the widget currently
        # tracked at `sid` is the one actually being destroyed. Qt's
        # destroyed signal fires from the widget being destroyed, so
        # self.sender() points at it (even though its C++ side is going
        # away); comparing by identity to the current dict entry means a
        # stale deferred-destroy call can never accidentally evict a
        # newer widget that happens to share the sid.
        #
        # The main clear() path disconnects these signals before scheduling
        # deletion, so this guard is normally redundant. It's here as a
        # catch-all for any future deferred-delete site that forgets.
        current = self.widgets.get(sid)
        try:
            sender = self.sender()
        except Exception:
            sender = None
        if current is None or sender is None or current is sender:
            self.widgets.pop(sid, None)
            self.selected.discard(sid)
        else:
            # Stale callback for a sid that's since been reassigned. Leave
            # the current entry alone.
            try:
                self._debug(f"_on_widget_destroyed: stale callback for sid={sid}, "
                            f"current widget is a different object; ignoring.")
            except Exception:
                pass

    def _home_offset(self) -> QPoint:
        """Room the canvas has inserted at its home corner.

        A view dragged left of the workspace's top-left corner makes the
        canvas grow there, and because chips are stored in canvas
        coordinates, every chip's number goes up by the same amount
        (mdi_canvas.CanvasController.home_shift). It is bookkeeping, not a
        placement anyone made, so it comes back out before a position is
        written anywhere.
        """
        try:
            canvas = getattr(self.mdi, "canvas", None)
            if canvas is not None:
                return canvas.home_shift()
        except Exception:
            pass
        return QPoint(0, 0)

    def _collect_live_items(self) -> list[dict]:
        """
        Collect visible shortcut widgets into a serializable list.

        For each shortcut we also try to inline its preset (if any) so that
        function bundles and other per-instance presets can be exported.
        """
        shift = self._home_offset()
        data = []
        for sid, w in list(self.widgets.items()):
            if _is_dead(w):
                self.widgets.pop(sid, None)
                self.selected.discard(sid)
                continue
            try:
                if not w.isVisible():
                    continue

                # Persist the user's intended position, not a temporarily
                # clamped one, so saving while the window is shrunk doesn't bake
                # the squashed layout in. Same for room inserted at the
                # canvas's home corner.
                p = getattr(w, "_desired_pos", None) or w.pos()
                item = {
                    "id": sid,
                    "command_id": getattr(w, "command_id", None),
                    "label": w.text(),
                    "x": max(0, int(p.x()) - shift.x()),
                    "y": max(0, int(p.y()) - shift.y()),
                }

                # Try to inline per-instance preset
                preset = None
                try:
                    if hasattr(w, "_load_preset"):
                        preset = w._load_preset()
                except Exception:
                    preset = None

                if isinstance(preset, dict) and preset:
                    item["preset"] = preset

                data.append(item)
            except RuntimeError:
                self.widgets.pop(sid, None)
                self.selected.discard(sid)

        # Debug: summarize what we collected
        try:
            summary = []
            for it in data:
                cid = it.get("command_id")
                has_preset = "preset" in it
                summary.append(f"{cid!r} preset={has_preset}")
            self._debug(f"_collect_live_items: {len(data)} item(s): " + ", ".join(summary))
        except Exception:
            pass

        return data

    def _export_function_bundles_for_shortcuts(self) -> dict | None:
        """
        Ask pro.function_bundle for function bundle defs + chip layout
        so we can embed them into the .sass export.
        """
        try:
            from setiastro.saspro.function_bundle import export_function_bundles_payload
        except Exception:
            return None
        try:
            fb = export_function_bundles_payload()
            if isinstance(fb, dict):
                return fb
        except Exception:
            pass
        return None

    def _import_function_bundles_for_shortcuts(self, payload: dict | None, replace_existing: bool):
        """
        Restore function bundle defs + chips after a .sass import.
        """
        if not isinstance(payload, dict):
            return
        try:
            from setiastro.saspro.function_bundle import import_function_bundles_payload
        except Exception:
            return
        try:
            mw = getattr(self, "mw", None)
            import_function_bundles_payload(payload, mw, replace_existing=replace_existing)
        except Exception:
            pass


    def _debug(self, msg: str):
        """Best-effort debug logging for shortcuts."""
        try:
            # Prefer main window log if available
            if hasattr(self.mw, "_log") and callable(self.mw._log):
                self.mw._log(f"[Shortcuts] {msg}")
                return
        except Exception:
            pass
        # Fallback to stdout
        try:
            print(f"[Shortcuts] {msg}")
        except Exception:
            pass


    # ---------- New: export/import ----------
    def export_to_file(self, file_path: str) -> tuple[bool, str]:
        try:
            fp = self._ensure_ext(file_path, ".sass")

            items = self._collect_live_items()
            payload = {
                "kind": SASS_KIND,
                "version": SASS_VER,
                "exported_at": int(time.time()),
                "items": items,
            }

            # NEW: include function bundles + chip layout if available
            fb_payload = self._export_function_bundles_for_shortcuts()
            if fb_payload is not None:
                payload["function_bundles"] = fb_payload

            Path(fp).write_text(json.dumps(payload, indent=2), encoding="utf-8")

            # optional debug
            try:
                self._debug(f"export_to_file → {fp}, shortcuts={len(items)}, "
                            f"fb_bundles={len((fb_payload or {}).get('bundles', []))}")
            except Exception:
                pass

            return True, fp
        except Exception as e:
            try:
                self._debug(f"export_to_file FAILED: {e}")
            except Exception:
                pass
            return False, str(e)

    def import_from_file(self, file_path: str, *, replace_existing: bool = False) -> tuple[bool, str]:
        try:
            txt = Path(file_path).read_text(encoding="utf-8")
            obj = json.loads(txt)

            fb_payload = None

            # Basic validation (accepts legacy raw arrays too)
            if isinstance(obj, dict) and obj.get("kind") == SASS_KIND:
                items = obj.get("items", [])
                fb_payload = obj.get("function_bundles")
            elif isinstance(obj, list):
                # legacy: straight array of items (no function bundle info)
                items = obj
            else:
                return False, "File is not a SAS shortcuts file."

            # optional debug
            try:
                self._debug(
                    f"import_from_file ← {file_path}, items={len(items)}, "
                    f"has_fb={isinstance(fb_payload, dict)}, replace_existing={replace_existing}"
                )
            except Exception:
                pass

            if replace_existing:
                self.clear()  # clears both UI + settings keys, keeps manager ready

            # Suppress intermediate saves while we build the shortcut set.
            # Without this guard, add_shortcut() calls save_shortcuts() after
            # every single item, and each of those saves reads w.pos(). If
            # anything triggers reflow_into_view() between items (a file-
            # dialog teardown, a transient resize), already-added widgets
            # end up at clamped positions and get persisted that way. By
            # flipping _loading we route all persistence to the single
            # save_shortcuts() call at the end, which now uses _desired_pos.
            self._loading = True
            try:
                for it in items:
                    cid = it.get("command_id")
                    if not cid:
                        continue
                    sid    = it.get("id") or uuid.uuid4().hex
                    x      = int(it.get("x", 10))
                    y      = int(it.get("y", 10))
                    label  = it.get("label") or self._default_label_for(cid)

                    # add_shortcut may hand us a fresh sid if the file's sid
                    # was already live on the canvas (merge-mode collision);
                    # use the returned sid for the preset lookup so it lands
                    # on the shortcut we actually just created.
                    actual_sid = self.add_shortcut(
                        cid, QPoint(x, y), label=label, shortcut_id=sid
                    ) or sid

                    # Restore the inlined per-instance preset (written by
                    # _collect_live_items on export) so a .sass round-trip keeps it.
                    pr = it.get("preset")
                    if isinstance(pr, dict) and pr:
                        w = self.widgets.get(actual_sid)
                        if w and not _is_dead(w):
                            try:
                                w._save_preset(pr)
                            except Exception:
                                pass
            finally:
                self._loading = False

            # If the file was exported from a larger canvas than the current
            # one, some shortcuts were just placed off-screen. Clamp them
            # into the viewport for display, keeping _desired_pos untouched
            # so they spring back when the window is enlarged again.
            try:
                self.reflow_into_view()
            except Exception:
                pass

            # Persist shortcuts to QSettings (single write, using _desired_pos)
            self.save_shortcuts()

            # NEW: Restore function bundle definitions + chips
            self._import_function_bundles_for_shortcuts(fb_payload, replace_existing=replace_existing)

            return True, "OK"
        except Exception as e:
            try:
                self._debug(f"import_from_file FAILED: {e}")
            except Exception:
                pass
            return False, str(e)

    def _icon_for_command(self, command_id: str, act: QAction | None) -> QIcon:
        # 1) Prefer the QAction icon (works for built-in tools and scripts if set)
        if act is not None:
            try:
                ico = act.icon()
                if ico is not None and not ico.isNull():
                    return ico
            except Exception:
                pass

            # 2) Optional: if the action carries a script_icon_path property, use it
            try:
                p = act.property("script_icon_path")
                if isinstance(p, str) and p.strip() and Path(p).exists():
                    return QIcon(p.strip())
            except Exception:
                pass

        # 3) Fallback for scripts: use the generic SCRIPT icon
        if isinstance(command_id, str) and command_id.startswith("script:"):
            try:
                ic = _get_icons()
                if ic is not None and hasattr(ic, "SCRIPT"):
                    v = ic.SCRIPT
                    return v if isinstance(v, QIcon) else QIcon(str(v))
            except Exception:
                pass

        return QIcon()


    # ---------- utils ----------
    def _ensure_ext(self, path: str, ext: str) -> str:
        p = Path(path)
        if p.suffix.lower() != ext.lower():
            p = p.with_suffix(ext)
        return str(p)

    # ---- CRUD for shortcuts --------------------------------------------
    def _default_label_for(self, command_id: str) -> str:
        act = self.registry.get(command_id)
        if not act:
            return command_id
        return (act.text() or act.toolTip() or command_id).strip() or command_id

    def _find_free_position(self, w: QWidget, pos: QPoint) -> QPoint:
        """Return a point near `pos` where a widget of w's size will not
        overlap any existing shortcut. If `pos` is already free the point
        is returned unchanged; otherwise we cascade outward (diagonally
        first, then axis-aligned, then anti-diagonal) in widget-sized
        steps, keeping candidates inside the viewport when it's realized.
        Falls back to `pos` after a bounded search so we never spin."""
        size = w.size()
        others = [o.geometry() for sid, o in self.widgets.items()
                  if not _is_dead(o) and o is not w]

        def collides(r: QRect) -> bool:
            return any(r.intersects(g) for g in others)

        if not collides(QRect(pos, size)):
            return QPoint(pos)

        step = max(24, max(size.width(), size.height()) // 2 + 8)
        vp = self._viewport_rect()
        has_vp = vp.width() > 0 and vp.height() > 0

        for i in range(1, 60):
            for dx, dy in (
                ( step * i,  step * i),  # down-right (classic cascade)
                ( step * i,         0),  # right
                (        0,  step * i),  # down
                (-step * i,  step * i),  # down-left
                ( step * i, -step * i),  # up-right
                (-step * i,         0),  # left
                (        0, -step * i),  # up
                (-step * i, -step * i),  # up-left
            ):
                cand = QPoint(pos.x() + dx, pos.y() + dy)
                if has_vp:
                    if (cand.x() < 0 or cand.y() < 0 or
                        cand.x() + size.width()  > vp.width() or
                        cand.y() + size.height() > vp.height()):
                        continue
                if not collides(QRect(cand, size)):
                    return cand

        # Give up gracefully. reflow_into_view() may still clamp this later.
        return QPoint(pos)

    def add_shortcut(self,
                     command_id: str,
                     pos: QPoint,
                     *,
                     label: Optional[str] = None,
                     shortcut_id: Optional[str] = None) -> Optional[str]:
        """
        Always creates a NEW instance (multiple per command_id allowed).

        Returns the sid actually used, or None if the command is unknown.
        Callers that need to look the new widget back up (to attach a
        per-instance preset, for example) must use the returned sid, not
        the one they passed in — see the collision guard below.
        """
        act = self.registry.get(command_id)
        if not act:
            return None

        sid = shortcut_id or uuid.uuid4().hex
        # Never let a caller-supplied id silently overwrite a live entry.
        # Doing so would leave the old QToolButton on the canvas as an
        # un-tracked child: still visible, still on top of the hit-test
        # stack, still eating mouse events — but gone from self.widgets,
        # which also hides it from _find_free_position's overlap check so
        # the replacement lands exactly on top of it. This is what makes
        # merged imports "swallow" clicks for the pre-existing shortcuts.
        while sid in self.widgets:
            sid = uuid.uuid4().hex
        lbl = (label or self._default_label_for(command_id)).strip() or command_id

        ico = self._icon_for_command(command_id, act)
        w = ShortcutButton(self, sid, command_id, ico, lbl, self.canvas)
        w.adjustSize()
        # Nudge off any existing shortcut this would land on top of (import
        # merge, repeated toolbar drops on the same spot, history drag onto
        # an occupied cell). User-initiated drags go through move_selected_by
        # and are left alone — if the user drops on top of another chip,
        # that's their call.
        free_pos = self._find_free_position(w, pos)
        w.move(free_pos)
        w._desired_pos = QPoint(free_pos)   # remember intended spot for reflow/persist
        w.show()

        # when the C++ object dies, clean maps using the SID
        w.destroyed.connect(lambda _=None, sid=sid: self._on_widget_destroyed(sid))

        self.widgets[sid] = w
        self.save_shortcuts()
        return sid

    def add_shortcut_from_payload(self, payload: dict, pos: QPoint):
        """
        Create desktop shortcut(s) from a command payload dropped on the canvas.

        - Normal payload {command_id, preset} → one shortcut.
        - Bundle payload {command_id:"function_bundle", steps:[...]} (a multi-row
          drag from History Explorer) → one shortcut PER step, cascaded from the
          drop point so they don't stack. Order = step order.
        """
        if not isinstance(payload, dict):
            return

        cid = payload.get("command_id") or payload.get("cid")

        # Multi: explode a function_bundle into one shortcut per step
        if cid == "function_bundle":
            steps = payload.get("steps")
            if isinstance(steps, list) and steps:
                self._add_shortcuts_from_steps(steps, pos)
            return

        if not isinstance(cid, str) or not cid:
            return

        preset = payload.get("preset") or {}
        if not isinstance(preset, dict):
            try:
                preset = dict(preset)
            except Exception:
                preset = {}

        # Normal single-shortcut creation
        sid = uuid.uuid4().hex
        label = self._default_label_for(cid)
        actual_sid = self.add_shortcut(cid, pos, label=label, shortcut_id=sid) or sid

        w = self.widgets.get(actual_sid)
        if w and not _is_dead(w):
            try:
                w._save_preset(preset)
            except Exception:
                pass

        self.save_shortcuts()

    def _add_shortcuts_from_steps(self, steps: list[dict], pos: QPoint):
        """One shortcut per bundle step, cascaded diagonally from the drop point."""
        dx = dy = 28  # cascade offset per shortcut, in px
        made = 0
        for st in steps:
            if not isinstance(st, dict):
                continue
            scid = st.get("command_id") or st.get("cid")
            # skip empties and a nested bundle (shouldn't happen, but be safe)
            if not isinstance(scid, str) or not scid or scid == "function_bundle":
                continue
            # only create if the command actually exists in the registry
            if self.registry.get(scid) is None:
                continue

            spreset = st.get("preset") or {}
            if not isinstance(spreset, dict):
                try:
                    spreset = dict(spreset)
                except Exception:
                    spreset = {}

            sid = uuid.uuid4().hex
            label = self._default_label_for(scid)
            step_pos = QPoint(pos.x() + dx * made, pos.y() + dy * made)
            actual_sid = self.add_shortcut(
                scid, step_pos, label=label, shortcut_id=sid
            ) or sid

            w = self.widgets.get(actual_sid)
            if w and not _is_dead(w):
                try:
                    w._save_preset(spreset)
                except Exception:
                    pass
            made += 1

        if made:
            self.save_shortcuts()


    def update_label(self, shortcut_id: str, new_label: str):
        w = self.widgets.get(shortcut_id)
        if w and not _is_dead(w):
            w.setText(new_label.strip())  # in case caller didn't already
        self.save_shortcuts()

    def get_action(self, command_id: str):
        return self.registry.get(command_id)

    # ---- persistence (QSettings JSON blob) ----
    def save_shortcuts(self):
        # GUARD 1: never persist while a load is in progress. During load,
        # add_shortcut() fires this repeatedly while self.widgets is still being
        # rebuilt — a save here could write a half-built (or empty) set.
        if self._loading:
            return

        # Store positions as they were placed, not as a workspace that
        # has grown at its home corner currently numbers them.
        shift = self._home_offset()

        data = []
        for sid, w in list(self.widgets.items()):
            if _is_dead(w):
                self.widgets.pop(sid, None)
                self.selected.discard(sid)
                continue
            try:
                # Do NOT filter on isVisible(): a freshly created shortcut whose
                # top-level window hasn't been shown yet reports not-visible and
                # would be silently dropped, persisting an empty/partial set.
                #
                # Persist the USER'S INTENDED position (_desired_pos), not the
                # live w.pos(). After a reflow clamp (viewport shrink), w.pos()
                # is the on-screen clamped position while _desired_pos still
                # holds the real placement. Saving w.pos() here slowly bakes
                # clamped positions into QSettings, which then leak into every
                # subsequent export and show up as "garbled" positions when
                # the file is re-imported into a differently-sized canvas.
                desired = getattr(w, "_desired_pos", None) or w.pos()
                data.append({
                    "id": sid,
                    "command_id": w.command_id,
                    "label": w.text(),
                    "x": max(0, int(desired.x()) - shift.x()),
                    "y": max(0, int(desired.y()) - shift.y()),
                })
            except RuntimeError:
                self.widgets.pop(sid, None)
                self.selected.discard(sid)

        # GUARD 2 (safety net): refuse to overwrite a non-empty stored set with an
        # empty one unless this empty state is an explicit clear/delete-all. This
        # is what actually prevents a transient startup race from wiping shortcuts.
        if not data and not self._allow_empty_save:
            try:
                existing = self.settings.value(SET_KEY_V2, "", type=str) or ""
                had_existing = bool(json.loads(existing)) if existing else False
            except Exception:
                had_existing = False
            if had_existing:
                self._debug("save_shortcuts: refusing to overwrite stored shortcuts with an empty set")
                return

        # Save new format and remove legacy
        self.settings.setValue(SET_KEY_V2, json.dumps(data))
        self.settings.remove(SET_KEY_V1)
        self.settings.sync()

    def load_shortcuts(self):
        self._loading = True
        migrated_v1 = False
        try:
            # try v2 first
            raw_v2 = self.settings.value(SET_KEY_V2, "", type=str) or ""
            if raw_v2:
                try:
                    arr = json.loads(raw_v2)
                    for entry in arr:
                        sid = entry.get("id") or uuid.uuid4().hex
                        cid = entry.get("command_id")
                        x = int(entry.get("x", 10))
                        y = int(entry.get("y", 10))
                        label = entry.get("label") or self._default_label_for(cid)
                        self.add_shortcut(cid, QPoint(x, y), label=label, shortcut_id=sid)
                    return
                except Exception as e:
                    try:
                        self.mw._log(f"Shortcuts v2: failed to load ({e})")
                    except Exception:
                        pass

            # migrate v1 (positions only)
            raw_v1 = self.settings.value(SET_KEY_V1, "", type=str) or ""
            if not raw_v1:
                return
            try:
                arr = json.loads(raw_v1)
                for entry in arr:
                    cid = entry.get("id") or entry.get("command_id")  # old key was "id" = command_id
                    x = int(entry.get("x", 10))
                    y = int(entry.get("y", 10))
                    # each old entry becomes its own instance
                    sid = uuid.uuid4().hex
                    label = self._default_label_for(cid)
                    self.add_shortcut(cid, QPoint(x, y), label=label, shortcut_id=sid)
                migrated_v1 = True
            except Exception as e:
                try:
                    self.mw._log(f"Shortcuts v1: failed to migrate ({e})")
                except Exception:
                    pass
        finally:
            self._loading = False
            # Persist the v1→v2 migration now that saving is re-enabled.
            if migrated_v1:
                self.save_shortcuts()


    def _load_keybinds(self) -> dict:
        raw = self.settings.value(KEYBINDS_KEY, "", type=str) or ""
        if not raw:
            return {}
        try:
            obj = json.loads(raw)
            return obj if isinstance(obj, dict) else {}
        except Exception:
            return {}

    def _save_keybinds(self, d: dict):
        self.settings.setValue(KEYBINDS_KEY, json.dumps(d))
        self.settings.sync()

    def set_keybind(self, command_id: str, keyseq: str | None):
        """
        keyseq: e.g. "Ctrl+Alt+K". If None/empty => clear binding.
        Applies immediately if action is registered.
        """
        d = self._load_keybinds()
        if keyseq and keyseq.strip():
            d[command_id] = keyseq.strip()
        else:
            d.pop(command_id, None)
        self._save_keybinds(d)

        act = self.registry.get(command_id)
        if act is not None:
            if keyseq and keyseq.strip():
                act.setShortcut(QKeySequence(keyseq.strip()))
                act.setShortcutContext(Qt.ShortcutContext.ApplicationShortcut)
            else:
                act.setShortcut(QKeySequence())

    def apply_command_to_subwindow(self, subwin, payload):
        """Apply a dragged command (or bundle) to the specific subwindow."""
        from PyQt6.QtWidgets import QApplication

        # --- normalize payload to a dict ---
        if isinstance(payload, (bytes, bytearray)):
            try:
                payload = json.loads(payload.decode("utf-8"))
            except Exception:
                print("[Shortcuts] apply_command_to_subwindow: invalid bytes payload", flush=True)
                QApplication.processEvents()
                return
        if not isinstance(payload, dict):
            print(f"[Shortcuts] apply_command_to_subwindow: non-dict payload {type(payload)}", flush=True)
            QApplication.processEvents()
            return

        print(f"[Shortcuts] apply_command_to_subwindow: subwin={subwin}, payload={payload!r}", flush=True)
        QApplication.processEvents()

        # --- flatten accidental nesting:
        cid = payload.get("command_id")
        if isinstance(cid, dict):
            payload = cid
            cid = payload.get("command_id")

        if not isinstance(cid, str) and isinstance(payload.get("command_id"), dict):
            payload = payload["command_id"]
            cid = payload.get("command_id")

        if not isinstance(cid, str) or not cid:
            print("[Shortcuts] apply_command_to_subwindow: no valid command_id", flush=True)
            QApplication.processEvents()
            return

        # --- function bundle handling ---
        if cid == "function_bundle":
            steps = payload.get("steps")
            inherit_target = bool(payload.get("inherit_target", True))
            print(f"[Shortcuts] function_bundle: {len(steps or [])} step(s), inherit_target={inherit_target}", flush=True)
            QApplication.processEvents()

            # If explicit steps are present (chip DnD / history replay payload),
            # run them INLINE via the normal command path (same as FunctionBundleDialog).
            if isinstance(steps, list) and steps:
                for i, st in enumerate(steps, start=1):
                    try:
                        scid = st.get("command_id")
                    except Exception:
                        scid = None
                    print(f"[Shortcuts]   inline step {i}/{len(steps)} → {scid!r}", flush=True)
                    QApplication.processEvents()
                    # Reuse the same target subwindow for each step
                    self.apply_command_to_subwindow(subwin, st)
                return

            # No inline steps → this is a true 'function_bundle' command (e.g. from Scripts),
            # so delegate to the central executor.
            try:
                from setiastro.saspro.function_bundle import run_function_bundle_command
                print("[Shortcuts] function_bundle: using run_function_bundle_command (no inline steps)", flush=True)
                QApplication.processEvents()

                try:
                    self.mdi.setActiveSubWindow(subwin)
                except Exception:
                    pass

                # Pass the whole payload as cfg so things like bundle_key, etc., are available.
                cfg = dict(payload)
                try:
                    run_function_bundle_command(self.mw, preset=payload.get("preset") or None, cfg=cfg)
                except TypeError:
                    # older signature: (ctx, cfg)
                    run_function_bundle_command(self.mw, cfg)
                print("[Shortcuts] function_bundle: run_function_bundle_command finished", flush=True)
                QApplication.processEvents()
                return
            except Exception as ex:
                print(f"[Shortcuts] function_bundle: FAILED in central executor: {ex!r}", flush=True)
                QApplication.processEvents()
                return

        # --- primary path (unchanged) ---
        mw = self.mw
        try:
            if hasattr(mw, "_handle_command_drop"):
                print(f"[Shortcuts] forwarding cid={cid!r} to _handle_command_drop", flush=True)
                QApplication.processEvents()
                mw._handle_command_drop(payload, target_sw=subwin)
                return
        except Exception as ex:
            print(f"[Shortcuts] _handle_command_drop raised: {ex!r}, falling through", flush=True)
            QApplication.processEvents()

        # --- secondary paths (unchanged) ---
        w = getattr(subwin, "widget", None)
        target = w() if callable(w) else w
        preset = payload.get("preset") or {}

        if hasattr(target, "apply_command"):
            print(f"[Shortcuts] target.apply_command for cid={cid!r}", flush=True)
            QApplication.processEvents()
            target.apply_command(cid, preset)
            return
        if hasattr(mw, "apply_command_to_view"):
            print(f"[Shortcuts] mw.apply_command_to_view for cid={cid!r}", flush=True)
            QApplication.processEvents()
            mw.apply_command_to_view(target, cid, preset)
            return
        if hasattr(mw, "run_command"):
            print(f"[Shortcuts] mw.run_command for cid={cid!r}", flush=True)
            QApplication.processEvents()
            mw.run_command(cid, preset, view=target)
            return

        print(f"[Shortcuts] fallback QAction trigger for cid={cid!r}", flush=True)
        QApplication.processEvents()
        self.mdi.setActiveSubWindow(subwin)
        act = self.registry.get(cid if isinstance(cid, str) else str(cid))
        if act:
            act.trigger()


    # ---------- selection ----------
    def _apply_sel_visual(self, sid: str, on: bool):
        w = self.widgets.get(sid)
        if _is_dead(w):
            # Clean up any stale references
            self.widgets.pop(sid, None)
            self.selected.discard(sid)
            return
        try:
            if on:
                w.setStyleSheet("QToolButton { border: 2px solid #4da3ff; border-radius: 6px; padding: 2px; }")
            else:
                w.setStyleSheet("")
        except RuntimeError:
            # C++ object died between get() and call
            self.widgets.pop(sid, None)
            self.selected.discard(sid)

    def select_only(self, sid: str):
        self.clear_selection()
        self.selected.add(sid)
        self._apply_sel_visual(sid, True)

    def toggle_select(self, sid: str):
        if sid in self.selected:
            self.selected.remove(sid)
            self._apply_sel_visual(sid, False)
        else:
            self.selected.add(sid)
            self._apply_sel_visual(sid, True)

    def select_in_rect(self, rect: QRect, *, mode: str = "replace"):
        if mode == "replace":
            self.clear_selection()
        for sid, w in list(self.widgets.items()):
            if _is_dead(w):
                self.widgets.pop(sid, None)
                self.selected.discard(sid)
                continue
            if rect.intersects(w.geometry()):
                if sid not in self.selected:
                    self.selected.add(sid)
                    self._apply_sel_visual(sid, True)

    def _viewport_rect(self) -> QRect:
        try:
            return self.canvas.rect()
        except Exception:
            return QRect()

    def _clamp_point_for_widget(self, w: QWidget, x: int, y: int) -> QPoint:
        rect = self._viewport_rect()
        max_x = max(0, rect.width() - w.width())
        max_y = max(0, rect.height() - w.height())
        return QPoint(max(0, min(int(x), max_x)), max(0, min(int(y), max_y)))

    def _move_widget_clamped(self, w: QWidget, x: int, y: int):
        if _is_dead(w):
            return
        try:
            w.move(self._clamp_point_for_widget(w, x, y))
            # an explicit (align/distribute) move is a fresh user placement
            w._desired_pos = QPoint(int(x), int(y))
        except RuntimeError:
            pass

    def reflow_into_view(self):
        """Keep every shortcut reachable when the viewport shrinks.

        Each chip remembers the position the user placed it at (``_desired_pos``);
        here we display it clamped to the current canvas bounds. Growing the
        viewport again restores the original spot, because clamping is a no-op
        once the desired position fits — so shrinking never permanently loses a
        chip's placement.
        """
        if getattr(self, "_loading", False):
            return
        rect = self._viewport_rect()
        if rect.width() <= 0 or rect.height() <= 0:
            return  # viewport not realized yet; a later resize will reflow
        for sid, w in list(self.widgets.items()):
            if _is_dead(w):
                continue
            desired = getattr(w, "_desired_pos", None)
            if desired is None:
                desired = w.pos()
                w._desired_pos = QPoint(desired)
            try:
                w.move(self._clamp_point_for_widget(w, desired.x(), desired.y()))
            except RuntimeError:
                pass

    def make_neat_row(self, spacing: int = 16):
        ws = self.selected_widgets()
        if len(ws) < 2:
            return

        # Keep visual left-to-right order
        ws = sorted(ws, key=lambda w: (w.x(), w.y()))

        # Use the top-most item as the row baseline
        top = min(w.y() for w in ws)
        x = min(w.x() for w in ws)

        for w in ws:
            self._move_widget_clamped(w, x, top)
            x += w.width() + int(spacing)

        self.save_shortcuts()
        self.canvas.update()

    def make_neat_column(self, spacing: int = 16):
        ws = self.selected_widgets()
        if len(ws) < 2:
            return

        # Keep visual top-to-bottom order
        ws = sorted(ws, key=lambda w: (w.y(), w.x()))

        # Use the left-most item as the column baseline
        left = min(w.x() for w in ws)
        y = min(w.y() for w in ws)

        for w in ws:
            self._move_widget_clamped(w, left, y)
            y += w.height() + int(spacing)

        self.save_shortcuts()
        self.canvas.update()

    def align_selected_left(self):
        ws = self.selected_widgets()
        if len(ws) < 2:
            return
        target = min(w.x() for w in ws)
        for w in ws:
            self._move_widget_clamped(w, target, w.y())
        self.save_shortcuts()
        self.canvas.update()

    def align_selected_right(self):
        ws = self.selected_widgets()
        if len(ws) < 2:
            return
        target = max(w.x() + w.width() for w in ws)
        for w in ws:
            self._move_widget_clamped(w, target - w.width(), w.y())
        self.save_shortcuts()
        self.canvas.update()

    def align_selected_top(self):
        ws = self.selected_widgets()
        if len(ws) < 2:
            return
        target = min(w.y() for w in ws)
        for w in ws:
            self._move_widget_clamped(w, w.x(), target)
        self.save_shortcuts()
        self.canvas.update()

    def align_selected_bottom(self):
        ws = self.selected_widgets()
        if len(ws) < 2:
            return
        target = max(w.y() + w.height() for w in ws)
        for w in ws:
            self._move_widget_clamped(w, w.x(), target - w.height())
        self.save_shortcuts()
        self.canvas.update()

    def align_selected_hcenter(self):
        ws = self.selected_widgets()
        if len(ws) < 2:
            return
        centers = [w.x() + (w.width() // 2) for w in ws]
        target = int(round(sum(centers) / len(centers)))
        for w in ws:
            self._move_widget_clamped(w, target - (w.width() // 2), w.y())
        self.save_shortcuts()
        self.canvas.update()

    def align_selected_vcenter(self):
        ws = self.selected_widgets()
        if len(ws) < 2:
            return
        centers = [w.y() + (w.height() // 2) for w in ws]
        target = int(round(sum(centers) / len(centers)))
        for w in ws:
            self._move_widget_clamped(w, w.x(), target - (w.height() // 2))
        self.save_shortcuts()
        self.canvas.update()

    def distribute_selected_horizontally(self):
        ws = self.selected_widgets()
        if len(ws) < 3:
            return

        ws = sorted(ws, key=lambda w: w.x())
        left = ws[0].x()
        right = ws[-1].x()
        span = right - left
        if span <= 0:
            return

        step = span / (len(ws) - 1)
        for i, w in enumerate(ws):
            self._move_widget_clamped(w, int(round(left + i * step)), w.y())

        self.save_shortcuts()
        self.canvas.update()

    def distribute_selected_vertically(self):
        ws = self.selected_widgets()
        if len(ws) < 3:
            return

        ws = sorted(ws, key=lambda w: w.y())
        top = ws[0].y()
        bottom = ws[-1].y()
        span = bottom - top
        if span <= 0:
            return

        step = span / (len(ws) - 1)
        for i, w in enumerate(ws):
            self._move_widget_clamped(w, w.x(), int(round(top + i * step)))

        self.save_shortcuts()
        self.canvas.update()

    def selected_widgets(self):
        out = []
        for sid in list(self.selected):
            w = self.widgets.get(sid)
            if _is_dead(w):
                self.widgets.pop(sid, None)
                self.selected.discard(sid)
                continue
            out.append(w)
        return out

    def clear_selection(self):
        """Clear current selection highlight without deleting shortcuts."""
        # Remove highlight from all currently selected items
        for sid in list(self.selected):
            try:
                self._apply_sel_visual(sid, False)
            except Exception:
                pass
        self.selected.clear()

        # Nudge repaint (optional but helps)
        try:
            self.canvas.update()
        except Exception:
            pass


    def clear(self):
        for sid, w in list(self.widgets.items()):
            try:
                if not _is_dead(w):
                    # CRITICAL: disconnect destroyed BEFORE scheduling the
                    # delete. deleteLater() is deferred — the actual Qt
                    # destruction fires one event-loop tick later and emits
                    # 'destroyed', which runs _on_widget_destroyed(sid) and
                    # pops that sid from self.widgets.
                    #
                    # If a REPLACE import follows clear() (same transaction,
                    # before the event loop runs), the import loop re-adds
                    # widgets AT THE SAME SIDS the .sass file carries — and
                    # a .sass file that was previously exported from this
                    # install carries exactly the sids we just scheduled
                    # for deletion. So the stale destroyed signals fire
                    # with sids that now point to BRAND-NEW widgets, pop
                    # them from self.widgets, and leave them as orphan
                    # QToolButtons: still parented to the canvas, still
                    # visible, still on top of the hit-test stack — but
                    # untracked. Hence the "corrupted icons, can't click,
                    # can't select" bug on import+Replace.
                    #
                    # Disconnecting here is the surgical fix: when the
                    # deferred destruction finally runs, no slot is attached,
                    # so no dict mutation happens. Individual deletions
                    # (delete_by_id) and normal widget lifecycle are
                    # unaffected — they pop by sid BEFORE deleteLater(),
                    # so a late destroyed call is a harmless no-op.
                    try:
                        w.destroyed.disconnect()
                    except Exception:
                        pass
                    w.hide()
                    try:
                        w.setParent(None)   # ← detach from canvas immediately
                    except Exception:
                        pass
                    w.deleteLater()
            except RuntimeError:
                pass
        self.widgets.clear()
        self.selected.clear()
        self.settings.setValue(SET_KEY_V2, "[]")
        self.settings.remove(SET_KEY_V1)
        self.settings.remove("presets/shortcuts")   # whole per-instance subtree
        self.settings.sync()
        try:
            self.canvas.update()  # nudge repaint
        except Exception:
            pass


    # ---------- group move / delete ----------
    def _group_bounds(self) -> QRect:
        rect = None
        for w in self.selected_widgets():
            rect = w.geometry() if rect is None else rect.united(w.geometry())
        return rect if rect is not None else QRect()

    def move_selected_by(self, dx: int, dy: int):
        if not self.selected:
            return
        # clamp whole group to canvas bounds so relative spacing stays intact
        group = self._group_bounds()
        vp = self.canvas.rect()
        min_dx = vp.left()  - group.left()
        max_dx = vp.right() - group.right()
        min_dy = vp.top()   - group.top()
        max_dy = vp.bottom()- group.bottom()
        dx = max(min_dx, min(dx, max_dx))
        dy = max(min_dy, min(dy, max_dy))
        if dx == 0 and dy == 0:
            return
        for w in self.selected_widgets():
            g = w.geometry()
            g.translate(dx, dy)
            w.setGeometry(g)
            w._desired_pos = QPoint(g.topLeft())   # user drag = new intended spot

    def move_shortcut_group_to(self, sid: str, pos: QPoint):
        """Reposition the dragged shortcut (and, if multi-selected, its whole
        group) so the initiating icon's center lands at `pos` (canvas coords).
        Called from ShortcutCanvas.dropEvent for an empty-canvas drop."""
        w = self.widgets.get(sid)
        if _is_dead(w):
            return
        if sid not in self.selected:
            self.select_only(sid)   # a bare drag of an unselected icon moves just it
        old_center = w.geometry().center()
        self.move_selected_by(pos.x() - old_center.x(), pos.y() - old_center.y())
        self.save_shortcuts()

    def delete_by_id(self, sid: str, *, persist: bool = True):
        self.selected.discard(sid)
        w = self.widgets.pop(sid, None)
        if not _is_dead(w):
            try:
                w.hide()
            except RuntimeError:
                pass
            try:
                w.deleteLater()
            except RuntimeError:
                pass
        # drop the per-instance preset so it doesn't linger in QSettings forever
        try:
            self.settings.remove(f"presets/shortcuts/{sid}")
        except Exception:
            pass
        if persist:
            self._allow_empty_save = True
            try:
                self.save_shortcuts()
            finally:
                self._allow_empty_save = False

    def delete_selected(self):
        # bulk delete, then persist once
        for sid in list(self.selected):
            self.delete_by_id(sid, persist=False)
        self.selected.clear()
        self._allow_empty_save = True
        try:
            self.save_shortcuts()
        finally:
            self._allow_empty_save = False

    def remove(self, sid: str):
        # legacy single-remove (kept for callers)
        self.delete_by_id(sid, persist=True)

class _LevelsPresetDialog(QDialog):
    """
    Preset editor for Levels (Histogram Transform).
    Keys:
      black: float [0..1]
      mid:   float [0..1]
      white: float [0..1]
      channel: "L"|"K"|"R"|"G"|"B"
      apply_mode: "inplace"|"new_view"
      new_view_title: str
    """
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Levels — Preset")
        init = dict(initial or {})

        self.sp_black = QDoubleSpinBox(self)
        self.sp_black.setRange(0.0, 1.0)
        self.sp_black.setDecimals(6)
        self.sp_black.setSingleStep(0.001)
        self.sp_black.setValue(float(init.get("black", 0.0)))

        self.sp_mid = QDoubleSpinBox(self)
        self.sp_mid.setRange(0.0, 1.0)
        self.sp_mid.setDecimals(6)
        self.sp_mid.setSingleStep(0.001)
        self.sp_mid.setValue(float(init.get("mid", 0.5)))

        self.sp_white = QDoubleSpinBox(self)
        self.sp_white.setRange(0.0, 1.0)
        self.sp_white.setDecimals(6)
        self.sp_white.setSingleStep(0.001)
        self.sp_white.setValue(float(init.get("white", 1.0)))

        self.cmb_channel = QComboBox(self)
        self.cmb_channel.addItem("L (Luminance)", "L")
        self.cmb_channel.addItem("K (Brightness / RGB linked)", "K")
        self.cmb_channel.addItem("R", "R")
        self.cmb_channel.addItem("G", "G")
        self.cmb_channel.addItem("B", "B")

        ch0 = str(init.get("channel", "K") or "K").upper().strip()
        idx = self.cmb_channel.findData(ch0)
        if idx < 0:
            idx = self.cmb_channel.findData("K")
        if idx >= 0:
            self.cmb_channel.setCurrentIndex(idx)

        self.cmb_apply = QComboBox(self)
        self.cmb_apply.addItem("Apply in place (overwrite target)", "inplace")
        self.cmb_apply.addItem("Apply as new view", "new_view")
        am0 = str(init.get("apply_mode", "inplace") or "inplace")
        j = self.cmb_apply.findData(am0)
        if j >= 0:
            self.cmb_apply.setCurrentIndex(j)

        self.ed_title = QLineEdit(self)
        self.ed_title.setText(str(init.get("new_view_title", "Levels") or "Levels"))
        self.ed_title.setEnabled(self.cmb_apply.currentData() == "new_view")
        self.cmb_apply.currentIndexChanged.connect(
            lambda *_: self.ed_title.setEnabled(self.cmb_apply.currentData() == "new_view")
        )

        form = QFormLayout(self)
        form.addRow("Black point:", self.sp_black)
        form.addRow("Midtones:", self.sp_mid)
        form.addRow("White point:", self.sp_white)
        form.addRow("Channel:", self.cmb_channel)
        form.addRow("Apply mode:", self.cmb_apply)
        form.addRow("New view title:", self.ed_title)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        black = float(self.sp_black.value())
        mid   = float(self.sp_mid.value())
        white = float(self.sp_white.value())

        if white <= black + 1e-6:
            white = min(1.0, black + 1e-6)

        return {
            "black": black,
            "mid": float(np.clip(mid, 0.0, 1.0)),
            "white": white,
            "channel": str(self.cmb_channel.currentData() or "K"),
            "apply_mode": str(self.cmb_apply.currentData() or "inplace"),
            "new_view_title": self.ed_title.text().strip() or "Levels",
        }

class _FXPresetDialog(QDialog):
    """
    Preset editor for FX (Orton Glow, Soft Focus, Bloom, Vignette, Film Grain,
    Split Tone) — shown when editing an FX shortcut/command-drop entry.

    Builds its controls dynamically from the selected effect's ParamSpec
    list — same source of truth as the live FXDialog — but without any
    preview/worker machinery, since this only needs to produce a preset dict.
    """

    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("FX Preset")
        self.setModal(True)
        self.resize(420, 420)

        from setiastro.saspro.fx_module import EFFECTS
        self._effects = EFFECTS
        self._effects_by_key = {e["key"]: e for e in EFFECTS}

        cur = dict(initial or {})
        initial_key = cur.get("effect", self._effects[0]["key"])
        self._current_effect = self._effects_by_key.get(initial_key, self._effects[0])
        self._seed_values = {k: v for k, v in cur.items() if k != "effect"}

        root = QVBoxLayout(self)
        root.setSpacing(6)

        effect_row = QHBoxLayout()
        effect_row.addWidget(QLabel("Effect:"))
        self._combo_effect = QComboBox(self)
        self._combo_effect.addItems([e["name"] for e in self._effects])
        idx0 = next((i for i, e in enumerate(self._effects)
                    if e["key"] == self._current_effect["key"]), 0)
        self._combo_effect.setCurrentIndex(idx0)
        self._combo_effect.currentIndexChanged.connect(self._on_effect_changed)
        effect_row.addWidget(self._combo_effect, 1)
        root.addLayout(effect_row)

        self._lbl_desc = QLabel("", self)
        self._lbl_desc.setWordWrap(True)
        self._lbl_desc.setStyleSheet("font-size: 10px; color: #999;")
        root.addWidget(self._lbl_desc)

        self._params_grp = QGroupBox("Parameters", self)
        self._controls_lay = QVBoxLayout(self._params_grp)
        root.addWidget(self._params_grp, 1)

        btn_reset = QPushButton("Reset to Defaults", self)
        btn_reset.clicked.connect(self._reset_current)
        root.addWidget(btn_reset)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        root.addWidget(btns)

        self._param_widgets: dict = {}
        self._rebuild_controls(self._current_effect, seed=self._seed_values)

    def _clear_layout(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()
            elif item.layout() is not None:
                self._clear_layout(item.layout())

    def _rebuild_controls(self, eff: dict, seed: dict | None = None):
        self._lbl_desc.setText(eff["description"])
        self._clear_layout(self._controls_lay)
        self._param_widgets = {}
        seed = seed or {}

        for spec in eff["params"]:
            if spec.kind == "slider":
                if spec.key in seed:
                    try:
                        raw_default = int(round(float(seed[spec.key]) * spec.scale))
                        raw_default = max(spec.slider_lo, min(spec.slider_hi, raw_default))
                    except Exception:
                        raw_default = spec.slider_default
                else:
                    raw_default = spec.slider_default

                real_default = raw_default / spec.scale
                lbl = QLabel(f"{spec.label}: {spec.fmt(real_default)}")
                sld = QSlider(Qt.Orientation.Horizontal, self)
                sld.setRange(spec.slider_lo, spec.slider_hi)
                sld.setValue(raw_default)
                sld.setToolTip(spec.tooltip)
                sld.valueChanged.connect(
                    lambda v, s=spec, l=lbl: l.setText(f"{s.label}: {s.fmt(v / s.scale)}"))
                self._controls_lay.addWidget(lbl)
                self._controls_lay.addWidget(sld)
                self._param_widgets[spec.key] = ("slider", sld, spec)
            else:
                row = QHBoxLayout()
                row.addWidget(QLabel(f"{spec.label}:"))
                combo = QComboBox(self)
                combo.addItems(spec.choices or [])
                default_choice = seed.get(spec.key, spec.default_choice)
                if default_choice and default_choice in (spec.choices or []):
                    combo.setCurrentText(default_choice)
                elif spec.default_choice:
                    combo.setCurrentText(spec.default_choice)
                combo.setToolTip(spec.tooltip)
                row.addWidget(combo, 1)
                self._controls_lay.addLayout(row)
                self._param_widgets[spec.key] = ("combo", combo, spec)

    def _on_effect_changed(self, idx: int):
        if 0 <= idx < len(self._effects):
            self._current_effect = self._effects[idx]
            # cross-effect params rarely share keys; harmless if seed doesn't match
            self._rebuild_controls(self._current_effect, seed=self._seed_values)

    def _reset_current(self):
        self._rebuild_controls(self._current_effect, seed={})

    def result_dict(self) -> dict:
        params = {}
        for key, (kind, widget, spec) in self._param_widgets.items():
            if kind == "slider":
                params[key] = widget.value() / spec.scale
            else:
                params[key] = widget.currentText()
        return {
            "command_id": "fx",
            "effect": self._current_effect["key"],
            **params,
        }
    
class _SatChromaPresetDialog(QDialog):
    """
    Preset editor for SatChroma — shown when the user edits a SatChroma
    shortcut/command-drop entry in the preset editor.
 
    Embeds the full HueCurveCanvas so the user can see and edit the
    hue curve directly, plus mode and strength controls.
    """
 
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("SatChroma Preset")
        self.setModal(True)
        self.resize(560, 460)
 
        cur = initial or {}
        root = QVBoxLayout(self)
        root.setSpacing(6)
 
        # Mode
        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Mode:"))
        self._combo_mode = QComboBox(self)
        self._combo_mode.addItems(["Saturation  (HSV)", "Chroma  (CIE Lab)"])
        self._combo_mode.setCurrentIndex(int(cur.get("mode", 0)))
        mode_row.addWidget(self._combo_mode, 1)
        root.addLayout(mode_row)
 
        # Curve canvas
        from setiastro.saspro.satchroma_tool import HueCurveCanvas
        self._canvas = HueCurveCanvas(self)
        pts = cur.get("points")
        if pts:
            self._canvas.set_points([(float(x), float(y)) for x, y in pts])
        root.addWidget(self._canvas, 1)
 
        # Strength
        str_row = QHBoxLayout()
        str_row.addWidget(QLabel("Global strength:"))
        self._sld = QSlider(Qt.Orientation.Horizontal, self)
        self._sld.setRange(0, 300)
        self._spin = QDoubleSpinBox(self)
        self._spin.setRange(0.0, 3.0)
        self._spin.setSingleStep(0.05)
        self._spin.setDecimals(2)
        self._spin.setFixedWidth(64)
        val = float(cur.get("strength", 1.0))
        self._spin.setValue(val)
        self._sld.setValue(int(val * 100))
        self._sld.valueChanged.connect(lambda v: self._spin.setValue(v / 100.0))
        self._spin.valueChanged.connect(lambda v: self._sld.setValue(int(v * 100)))
        str_row.addWidget(self._sld, 1)
        str_row.addWidget(self._spin)
 
        btn_reset = QPushButton("Reset Curve")
        btn_reset.setFixedWidth(84)
        btn_reset.clicked.connect(self._canvas.reset_points)
        str_row.addWidget(btn_reset)
        root.addLayout(str_row)
 
        # Mask
        self._chk_mask = QCheckBox("Respect active mask", self)
        self._chk_mask.setChecked(bool(cur.get("use_mask", True)))
        root.addWidget(self._chk_mask)
 
        # OK / Cancel
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        root.addWidget(btns)
 
    def result_dict(self) -> dict:
        return {
            "command_id": "satchroma",
            "mode":       self._combo_mode.currentIndex(),
            "strength":   self._spin.value(),
            "points":     self._canvas.get_points(),
            "use_mask":   self._chk_mask.isChecked(),
        }


class _MaskCreationPresetDialog(QDialog):
    """
    Preset editor for command_id="create_mask".

    Mirrors mask_creation.py's _mask_params / seed_from_preset schema.
    Canvas shapes are NOT part of the preset — the headless replay
    defaults to a full-image base, which is the behavior that matches
    the common UX this tool is used for (drop a 'Color: Green' shortcut
    on an image → whole-frame green mask).
    """

    _MASK_TYPES = [
        "Binary", "Range Selection", "Diffuse Structure",
        "Lightness", "Chrominance", "Star Mask",
        "Color: Red", "Color: Orange", "Color: Yellow",
        "Color: Green", "Color: Cyan", "Color: Blue", "Color: Magenta",
    ]
    _DIFFUSE_PROFILES = [
        ("Extended structure", "extended"),
        ("Brightness weighted", "brightness_weighted"),
    ]
    _DIFFUSE_QUALITY = [
        ("Low",    700),
        ("Medium", 1400),
        ("Ultra",  0),
    ]
    _APPLY_MODES = [
        # Order sets the default (first entry). apply_mask_creation_via_preset
        # routes between these; see its docstring for the full semantics.
        #   push_only   — create a new mask document only
        #   attach_only — create a new mask document AND apply it to the
        #                 dropped-on view, same code path as shift+click+drag
        #                 of the mask doc onto a view (via
        #                 main_window._handle_mask_drop in subwindow.py).
        #                 Requires Block 2 of _handle_command_drop to pass
        #                 target_sw through to apply_mask_creation_via_preset.
        #   both        — synonym for attach_only, kept for backward-compat
        ("Push as new document",             "push_only"),
        ("Push and apply to the dropped view", "attach_only"),
        ("Both (same as 'Push and apply')",  "both"),
    ]

    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Mask Creation — Preset")
        init = dict(initial or {})

        root = QVBoxLayout(self)

        # ── Core: mask type, blur, name, apply mode ────────────────────────
        form_core = QFormLayout()

        self.cmb_type = QComboBox()
        self.cmb_type.addItems(self._MASK_TYPES)
        want_type = str(init.get("mask_type", "Binary"))
        i = self.cmb_type.findText(want_type)
        self.cmb_type.setCurrentIndex(max(0, i))
        form_core.addRow("Mask type:", self.cmb_type)

        self.sp_blur = QSpinBox()
        self.sp_blur.setRange(0, 300)
        self.sp_blur.setValue(int(init.get("blur_amount", 0)))
        form_core.addRow("Edge blur (px):", self.sp_blur)

        # Default name is derived from the current mask type (e.g. a Color:
        # Green preset lands as "ColorMaskGreen", a Diffuse Structure preset
        # as "DiffuseMask"). We also auto-sync when the user flips the type
        # combo, but only when the current value in the name box is one of
        # the derived names — anything else means the user typed a custom
        # name and we leave it alone.
        try:
            from setiastro.saspro.mask_creation import (
                _derive_mask_name as _mc_derive_name,
                KNOWN_MASK_NAMES as _mc_known_names,
            )
        except Exception:
            # Fallback if mask_creation is unavailable at import time.
            def _mc_derive_name(t: str) -> str:
                return "Mask"
            _mc_known_names = {"Mask"}
        self._derive_mask_name = _mc_derive_name
        self._known_mask_names = _mc_known_names

        # Pick the field's initial value: an explicit mask_name in the
        # preset wins; otherwise derive from the type the preset carries.
        _init_name = str(init.get("mask_name") or "").strip()
        if not _init_name or _init_name == "Mask":
            _init_name = self._derive_mask_name(want_type)
        self.ed_name = QLineEdit()
        self.ed_name.setText(_init_name)
        form_core.addRow("Mask name:", self.ed_name)

        # Auto-sync when the mask type changes, unless the user customized.
        def _on_type_change_update_name(new_type: str):
            current = self.ed_name.text().strip()
            if current in self._known_mask_names or current == "":
                self.ed_name.blockSignals(True)
                try:
                    self.ed_name.setText(self._derive_mask_name(new_type))
                finally:
                    self.ed_name.blockSignals(False)
        self.cmb_type.currentTextChanged.connect(_on_type_change_update_name)

        self.cmb_apply = QComboBox()
        for label, key in self._APPLY_MODES:
            self.cmb_apply.addItem(label, userData=key)
        _am = str(init.get("apply_mode", "push_only"))
        j = self.cmb_apply.findData(_am)
        self.cmb_apply.setCurrentIndex(max(0, j))
        form_core.addRow("On apply:", self.cmb_apply)

        # Apply-only knobs — only meaningful when apply_mode is attach_only
        # or both. Keys are "apply_invert" / "apply_feather" (NOT plain
        # "invert" / "feather") because the Range Selection group below
        # already owns those names in the preset dict for its own mask-
        # inversion / blur controls. Confusing them was a real bug.
        self.chk_apply_invert = QCheckBox("Invert mask when applied to view")
        self.chk_apply_invert.setChecked(bool(init.get("apply_invert", False)))
        form_core.addRow("", self.chk_apply_invert)

        self.sp_apply_feather = QDoubleSpinBox()
        self.sp_apply_feather.setRange(0.0, 100.0)
        self.sp_apply_feather.setDecimals(1)
        self.sp_apply_feather.setSingleStep(0.5)
        self.sp_apply_feather.setSuffix(" px")
        self.sp_apply_feather.setValue(float(init.get("apply_feather", 0.0)))
        form_core.addRow("Feather on apply:", self.sp_apply_feather)

        root.addLayout(form_core)

        # ── Range Selection group ──────────────────────────────────────────
        self.grp_range = QGroupBox("Range Selection")
        fr = QGridLayout(self.grp_range)
        self.sp_lower = QDoubleSpinBox(); self.sp_lower.setRange(0.0, 1.0)
        self.sp_lower.setDecimals(3); self.sp_lower.setSingleStep(0.01)
        self.sp_lower.setValue(float(init.get("lower", 0.0)))
        self.sp_upper = QDoubleSpinBox(); self.sp_upper.setRange(0.0, 1.0)
        self.sp_upper.setDecimals(3); self.sp_upper.setSingleStep(0.01)
        self.sp_upper.setValue(float(init.get("upper", 1.0)))
        self.sp_fuzz = QDoubleSpinBox(); self.sp_fuzz.setRange(0.0, 1.0)
        self.sp_fuzz.setDecimals(3); self.sp_fuzz.setSingleStep(0.01)
        self.sp_fuzz.setValue(float(init.get("fuzz", 0.0)))
        self.sp_smooth = QDoubleSpinBox(); self.sp_smooth.setRange(0.0, 200.0)
        self.sp_smooth.setDecimals(2); self.sp_smooth.setSingleStep(0.5)
        self.sp_smooth.setValue(float(init.get("smooth", 3.0)))
        self.chk_screen = QCheckBox("Screening"); self.chk_screen.setChecked(bool(init.get("screen", False)))
        self.chk_light  = QCheckBox("Lightness"); self.chk_light.setChecked(bool(init.get("lightness", False)))
        self.chk_invert = QCheckBox("Invert");    self.chk_invert.setChecked(bool(init.get("invert", False)))
        self.chk_link   = QCheckBox("Link limits"); self.chk_link.setChecked(bool(init.get("link", False)))
        fr.addWidget(QLabel("Lower:"), 0, 0); fr.addWidget(self.sp_lower, 0, 1)
        fr.addWidget(QLabel("Upper:"), 1, 0); fr.addWidget(self.sp_upper, 1, 1)
        fr.addWidget(QLabel("Fuzz:"),  2, 0); fr.addWidget(self.sp_fuzz,  2, 1)
        fr.addWidget(QLabel("Blur σ (px):"), 3, 0); fr.addWidget(self.sp_smooth, 3, 1)
        fr.addWidget(self.chk_screen, 0, 2); fr.addWidget(self.chk_light, 1, 2)
        fr.addWidget(self.chk_invert, 2, 2); fr.addWidget(self.chk_link,  3, 2)
        root.addWidget(self.grp_range)

        # ── Diffuse Structure group ────────────────────────────────────────
        self.grp_diffuse = QGroupBox("Diffuse Structure")
        fd = QFormLayout(self.grp_diffuse)
        self.cmb_profile = QComboBox()
        for label, key in self._DIFFUSE_PROFILES:
            self.cmb_profile.addItem(label, userData=key)
        _dp = str(init.get("diffuse_profile", "extended"))
        pi = self.cmb_profile.findData(_dp)
        self.cmb_profile.setCurrentIndex(max(0, pi))
        fd.addRow("Profile:", self.cmb_profile)

        self.sp_sens = QDoubleSpinBox(); self.sp_sens.setRange(0.5, 20.0)
        self.sp_sens.setDecimals(2); self.sp_sens.setSingleStep(0.05)
        self.sp_sens.setValue(float(init.get("diffuse_sensitivity", 1.0)))
        fd.addRow("Sensitivity:", self.sp_sens)

        self.sp_feather = QDoubleSpinBox(); self.sp_feather.setRange(0.0, 10.0)
        self.sp_feather.setDecimals(3); self.sp_feather.setSingleStep(0.1)
        self.sp_feather.setSuffix(" %")
        self.sp_feather.setValue(float(init.get("diffuse_feather_frac", 0.0075)) * 100.0)
        fd.addRow("Feather (% of short side):", self.sp_feather)

        self.sp_minarea = QDoubleSpinBox(); self.sp_minarea.setRange(0.0, 5.0)
        self.sp_minarea.setDecimals(3); self.sp_minarea.setSingleStep(0.05)
        self.sp_minarea.setSuffix(" %")
        self.sp_minarea.setValue(float(init.get("diffuse_min_area_frac", 0.001)) * 100.0)
        fd.addRow("Minimum object area:", self.sp_minarea)

        self.sp_envelope = QDoubleSpinBox(); self.sp_envelope.setRange(0.0, 25.0)
        self.sp_envelope.setDecimals(3); self.sp_envelope.setSingleStep(0.1)
        self.sp_envelope.setSuffix(" %")
        self.sp_envelope.setValue(float(init.get("diffuse_envelope_frac", 0.0)) * 100.0)
        fd.addRow("Envelope fill:", self.sp_envelope)

        self.chk_reject_stars = QCheckBox("Suppress compact stars")
        self.chk_reject_stars.setChecked(bool(init.get("diffuse_reject_stars", False)))
        fd.addRow("", self.chk_reject_stars)

        self.cmb_quality = QComboBox()
        for label, key in self._DIFFUSE_QUALITY:
            self.cmb_quality.addItem(label, userData=key)
        _q = int(init.get("diffuse_quality", 1400))
        qi = self.cmb_quality.findData(_q)
        self.cmb_quality.setCurrentIndex(max(0, qi))
        fd.addRow("Quality:", self.cmb_quality)

        self.chk_diff_invert = QCheckBox("Invert (protect background)")
        self.chk_diff_invert.setChecked(bool(init.get("diffuse_invert", False)))
        fd.addRow("", self.chk_diff_invert)

        root.addWidget(self.grp_diffuse)

        # ── Star Mask group ────────────────────────────────────────────────
        self.grp_star = QGroupBox("Star Mask")
        fs = QFormLayout(self.grp_star)
        self.sp_star_thresh = QDoubleSpinBox()
        self.sp_star_thresh.setRange(0.5, 50.0); self.sp_star_thresh.setDecimals(1)
        self.sp_star_thresh.setSingleStep(0.5)
        self.sp_star_thresh.setValue(float(init.get("star_threshold", 3.0)))
        fs.addRow("Detection threshold (σ):", self.sp_star_thresh)

        self.chk_gaia = QCheckBox("Augment with Gaia Local DB (requires plate-solved WCS)")
        self.chk_gaia.setChecked(bool(init.get("gaia_augment", False)))
        fs.addRow("", self.chk_gaia)

        self.sp_gaia_g = QDoubleSpinBox()
        self.sp_gaia_g.setRange(6.0, 20.0); self.sp_gaia_g.setDecimals(1)
        self.sp_gaia_g.setSingleStep(0.5)
        self.sp_gaia_g.setValue(float(init.get("gaia_max_g", 17.0)))
        fs.addRow("Max Gaia G mag:", self.sp_gaia_g)

        root.addWidget(self.grp_star)

        # ── Visibility: hide the groups that don't apply to the chosen type
        self.cmb_type.currentTextChanged.connect(self._sync_visibility)
        self._sync_visibility(self.cmb_type.currentText())

        # ── OK / Cancel ────────────────────────────────────────────────────
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        root.addWidget(btns)

    def _sync_visibility(self, mask_type: str):
        self.grp_range.setVisible(mask_type == "Range Selection")
        self.grp_diffuse.setVisible(mask_type == "Diffuse Structure")
        self.grp_star.setVisible(mask_type == "Star Mask")

    def result_dict(self) -> dict:
        return {
            "mask_type":  self.cmb_type.currentText(),
            "blur_amount": int(self.sp_blur.value()),
            "mask_name":   self.ed_name.text().strip() or "Mask",
            "apply_mode":    str(self.cmb_apply.currentData() or "push_only"),
            # Apply-side knobs — distinct keys so they can't be shadowed
            # by Range Selection's "invert" / Diffuse Structure's feather.
            "apply_invert":  bool(self.chk_apply_invert.isChecked()),
            "apply_feather": float(self.sp_apply_feather.value()),

            # Range Selection
            "lower":     float(self.sp_lower.value()),
            "upper":     float(self.sp_upper.value()),
            "fuzz":      float(self.sp_fuzz.value()),
            "smooth":    float(self.sp_smooth.value()),
            "screen":    bool(self.chk_screen.isChecked()),
            "lightness": bool(self.chk_light.isChecked()),
            "invert":    bool(self.chk_invert.isChecked()),
            "link":      bool(self.chk_link.isChecked()),

            # Diffuse Structure (preset stores fractions, UI shows percent)
            "diffuse_profile":       str(self.cmb_profile.currentData() or "extended"),
            "diffuse_sensitivity":   float(self.sp_sens.value()),
            "diffuse_feather_frac":  float(self.sp_feather.value()) / 100.0,
            "diffuse_min_area_frac": float(self.sp_minarea.value()) / 100.0,
            "diffuse_envelope_frac": float(self.sp_envelope.value()) / 100.0,
            "diffuse_reject_stars":  bool(self.chk_reject_stars.isChecked()),
            "diffuse_quality":       int(self.cmb_quality.currentData() or 0),
            "diffuse_invert":        bool(self.chk_diff_invert.isChecked()),

            # Star Mask
            "star_threshold": float(self.sp_star_thresh.value()),
            "gaia_augment":   bool(self.chk_gaia.isChecked()),
            "gaia_max_g":     float(self.sp_gaia_g.value()),
        }


class _StatStretchPresetDialog(QDialog):
    """
    Preset editor for headless replay: command_id="stat_stretch"

    Keys supported:
      target_median: float
      linked: bool
      normalize: bool
      apply_curves: bool
      curves_boost: float            # 0..1
      blackpoint_sigma: float        # 0..1 (matches your slider/100)
      no_black_clip: bool
      hdr_compress: bool
      hdr_amount: float              # 0..1
      hdr_knee: float                # 0..1
      luma_only: bool
      luma_mode: str                 # e.g. "rec709"
      luma_blend: float              #0..1 (0=normal linked, 1=pure luma-only)
    """
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Statistical Stretch — Preset")
        init = dict(initial or {})

        # --- Target median ---
        self.spin_target = QDoubleSpinBox()
        self.spin_target.setRange(0.0, 1.0)
        self.spin_target.setDecimals(3)
        self.spin_target.setSingleStep(0.01)
        self.spin_target.setValue(float(init.get("target_median", 0.25)))

        # --- Linked / Normalize ---
        self.chk_linked = QCheckBox("Linked RGB channels")
        self.chk_linked.setChecked(bool(init.get("linked", False)))

        self.chk_normalize = QCheckBox("Normalize to [0..1]")
        self.chk_normalize.setChecked(bool(init.get("normalize", False)))

        # --- Curves ---
        self.chk_curves = QCheckBox("Apply Curves")
        self.chk_curves.setChecked(bool(init.get("apply_curves", False)))

        self.spin_curves = QDoubleSpinBox()
        self.spin_curves.setRange(0.0, 1.0)
        self.spin_curves.setDecimals(2)
        self.spin_curves.setSingleStep(0.05)
        self.spin_curves.setValue(float(init.get("curves_boost", 0.0)))
        self.spin_curves.setEnabled(self.chk_curves.isChecked())
        self.chk_curves.toggled.connect(self.spin_curves.setEnabled)

        # --- Blackpoint sigma ---
        self.spin_bp = QDoubleSpinBox()
        self.spin_bp.setRange(0.0, 1.0)
        self.spin_bp.setDecimals(2)
        self.spin_bp.setSingleStep(0.05)
        self.spin_bp.setValue(float(init.get("blackpoint_sigma", 0.0)))

        self.chk_no_black_clip = QCheckBox("No black clip")
        self.chk_no_black_clip.setChecked(bool(init.get("no_black_clip", False)))

        # --- HDR compress ---
        self.chk_hdr = QCheckBox("HDR compression")
        self.chk_hdr.setChecked(bool(init.get("hdr_compress", False)))

        self.spin_hdr_amt = QDoubleSpinBox()
        self.spin_hdr_amt.setRange(0.0, 1.0)
        self.spin_hdr_amt.setDecimals(2)
        self.spin_hdr_amt.setSingleStep(0.05)
        self.spin_hdr_amt.setValue(float(init.get("hdr_amount", 0.0)))

        self.spin_hdr_knee = QDoubleSpinBox()
        self.spin_hdr_knee.setRange(0.0, 1.0)
        self.spin_hdr_knee.setDecimals(2)
        self.spin_hdr_knee.setSingleStep(0.05)
        self.spin_hdr_knee.setValue(float(init.get("hdr_knee", 0.5)))

        def _set_hdr_enabled(on: bool):
            on = bool(on)
            self.spin_hdr_amt.setEnabled(on)
            self.spin_hdr_knee.setEnabled(on)

        _set_hdr_enabled(self.chk_hdr.isChecked())
        self.chk_hdr.toggled.connect(_set_hdr_enabled)

        # --- Luma only ---
        self.chk_luma_only = QCheckBox("Luma-only mode")
        self.chk_luma_only.setChecked(bool(init.get("luma_only", False)))

        self.cmb_luma = QComboBox()
        # keep in sync with your tool’s supported modes
        self.cmb_luma.addItems(["rec709", "avg", "hsp", "max"])
        init_mode = str(init.get("luma_mode", "rec709") or "rec709")
        idx = self.cmb_luma.findText(init_mode)
        if idx >= 0:
            self.cmb_luma.setCurrentIndex(idx)

        self.spin_luma_blend = QDoubleSpinBox()
        self.spin_luma_blend.setRange(0.0, 1.0)
        self.spin_luma_blend.setDecimals(2)
        self.spin_luma_blend.setSingleStep(0.05)
        self.spin_luma_blend.setValue(float(init.get("luma_blend", 0.70)))

        def _set_luma_enabled(on: bool):
            on = bool(on)
            self.cmb_luma.setEnabled(on)
            self.spin_luma_blend.setEnabled(on)

        _set_luma_enabled(self.chk_luma_only.isChecked())
        self.chk_luma_only.toggled.connect(_set_luma_enabled)

        # --- Layout ---
        form = QFormLayout()

        form.addRow("Target median:", self.spin_target)
        form.addRow("", self.chk_linked)
        form.addRow("", self.chk_normalize)

        form.addRow("", QLabel("— Tone shaping —"))
        form.addRow("", self.chk_curves)
        form.addRow("Curves boost (0–1):", self.spin_curves)

        form.addRow("", QLabel("— Blackpoint / HDR —"))
        form.addRow("Blackpoint σ (0–1):", self.spin_bp)
        form.addRow("", self.chk_no_black_clip)

        form.addRow("", self.chk_hdr)
        form.addRow("HDR amount (0–1):", self.spin_hdr_amt)
        form.addRow("HDR knee (0–1):", self.spin_hdr_knee)

        form.addRow("", QLabel("— Luma mode —"))
        form.addRow("", self.chk_luma_only)
        form.addRow("Luma mode:", self.cmb_luma)
        form.addRow("Luma blend (0–1):", self.spin_luma_blend)
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)

        self.setLayout(form)

    def result_dict(self) -> dict:
        hdr_on = bool(self.chk_hdr.isChecked())
        curves_on = bool(self.chk_curves.isChecked())
        luma_on = bool(self.chk_luma_only.isChecked())

        return {
            "target_median": float(self.spin_target.value()),
            "linked": bool(self.chk_linked.isChecked()),
            "normalize": bool(self.chk_normalize.isChecked()),

            "apply_curves": curves_on,
            "curves_boost": float(self.spin_curves.value()) if curves_on else 0.0,

            "blackpoint_sigma": float(self.spin_bp.value()),
            "no_black_clip": bool(self.chk_no_black_clip.isChecked()),

            "hdr_compress": hdr_on,
            "hdr_amount": float(self.spin_hdr_amt.value()) if hdr_on else 0.0,
            "hdr_knee": float(self.spin_hdr_knee.value()) if hdr_on else 0.0,

            "luma_only": luma_on,
            "luma_mode": str(self.cmb_luma.currentText()) if luma_on else "rec709",
            "luma_blend": float(self.spin_luma_blend.value()) if luma_on else 0.0,
        }

class _StarStretchPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Star Stretch — Preset")
        init = dict(initial or {})

        self.spin_amount = QDoubleSpinBox()
        self.spin_amount.setRange(0.0, 8.0); self.spin_amount.setDecimals(2)
        self.spin_amount.setSingleStep(0.05)
        self.spin_amount.setValue(float(init.get("stretch_factor", 5.00)))

        self.spin_sat = QDoubleSpinBox()
        self.spin_sat.setRange(0.0, 2.0); self.spin_sat.setDecimals(2)
        self.spin_sat.setSingleStep(0.05)
        self.spin_sat.setValue(float(init.get("color_boost", 1.00)))

        self.chk_scnr = QCheckBox("Remove Green via SCNR")
        self.chk_scnr.setChecked(bool(init.get("scnr_green", False)))

        form = QFormLayout(self)
        form.addRow("Stretch amount (0–8):", self.spin_amount)
        form.addRow("Color boost (0–2):", self.spin_sat)
        form.addRow("", self.chk_scnr)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        return {
            "stretch_factor": float(self.spin_amount.value()),   # 0..8
            "color_boost":    float(self.spin_sat.value()),      # 0..2
            "scnr_green":     bool(self.chk_scnr.isChecked()),
        }

class _CosmeticCorrectionPresetDialog(QDialog):
    """
    Preset editor for headless replay: command_id="cosmetic_correction"

    Keys supported:
      hot_sigma:     float 0.5..10.0  (default 3.0)
      cold_sigma:    float 0.5..10.0  (default 3.0)
      correct_hot:   bool             (default True)
      correct_cold:  bool             (default True)
      bayer_pattern: str              ("" = auto-detect, "__none__" = force off,
                                       or "RGGB"/"BGGR"/"GRBG"/"GBRG")
    """
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Cosmetic Correction — Preset")
        init = dict(initial or {})

        self.spin_hot = QDoubleSpinBox()
        self.spin_hot.setRange(0.5, 10.0)
        self.spin_hot.setDecimals(2)
        self.spin_hot.setSingleStep(0.1)
        self.spin_hot.setValue(float(init.get("hot_sigma", 3.0)))

        self.spin_cold = QDoubleSpinBox()
        self.spin_cold.setRange(0.5, 10.0)
        self.spin_cold.setDecimals(2)
        self.spin_cold.setSingleStep(0.1)
        self.spin_cold.setValue(float(init.get("cold_sigma", 3.0)))

        self.chk_hot = QCheckBox("Correct hot pixels")
        self.chk_hot.setChecked(bool(init.get("correct_hot", True)))
        self.spin_hot.setEnabled(self.chk_hot.isChecked())
        self.chk_hot.toggled.connect(self.spin_hot.setEnabled)

        self.chk_cold = QCheckBox("Correct cold pixels")
        self.chk_cold.setChecked(bool(init.get("correct_cold", True)))
        self.spin_cold.setEnabled(self.chk_cold.isChecked())
        self.chk_cold.toggled.connect(self.spin_cold.setEnabled)

        self.cmb_bayer = QComboBox()
        self.cmb_bayer.addItem("Auto-detect", userData="")
        self.cmb_bayer.addItem("None (mono / debayered)", userData="__none__")
        for pat in ("RGGB", "BGGR", "GRBG", "GBRG"):
            self.cmb_bayer.addItem(pat, userData=pat)
        bp = str(init.get("bayer_pattern", "") or "")
        if bp == "__none__":
            idx = 1
        elif bp.upper() in ("RGGB", "BGGR", "GRBG", "GBRG"):
            idx = self.cmb_bayer.findData(bp.upper())
            if idx < 0: idx = 0
        else:
            idx = 0
        self.cmb_bayer.setCurrentIndex(idx)

        form = QFormLayout(self)
        form.addRow("Hot pixels σ (0.5–10):", self.spin_hot)
        form.addRow("Cold pixels σ (0.5–10):", self.spin_cold)
        form.addRow("", self.chk_hot)
        form.addRow("", self.chk_cold)
        form.addRow("Bayer pattern:", self.cmb_bayer)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        return {
            "hot_sigma": float(self.spin_hot.value()),
            "cold_sigma": float(self.spin_cold.value()),
            "correct_hot": bool(self.chk_hot.isChecked()),
            "correct_cold": bool(self.chk_cold.isChecked()),
            "bayer_pattern": str(self.cmb_bayer.currentData() or ""),
        }

class _TextureClarityPresetDialog(QDialog):
    """Preset editor for Texture & Clarity. Matches parameter set of
    texture_clarity_headless() / TextureClarityDialog sliders."""

    def __init__(self, parent, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Texture & Clarity — Preset")
        self.setModal(True)
        cur = dict(initial or {})

        v = QVBoxLayout(self)
        v.setSpacing(6)

        def _spin(minv, maxv, step, decimals, val):
            sp = QDoubleSpinBox(self)
            sp.setRange(float(minv), float(maxv))
            sp.setSingleStep(float(step))
            sp.setDecimals(int(decimals))
            sp.setValue(float(val))
            sp.setFixedWidth(90)
            return sp

        def _row(parent_layout, label_text, spin):
            row = QHBoxLayout()
            lbl = QLabel(label_text, self)
            lbl.setMinimumWidth(150)
            row.addWidget(lbl)
            row.addWidget(spin)
            row.addStretch(1)
            parent_layout.addLayout(row)

        # Texture
        tex_grp = QGroupBox("Texture", self)
        tg = QVBoxLayout(tex_grp)
        self.t_amt = _spin(-1.0, 1.0, 0.05, 2, cur.get("t_amt", 0.0))
        self.t_rad = _spin( 0.1, 10.0, 0.1, 1, cur.get("t_rad", 1.0))
        _row(tg, "Amount (−1.00 to 1.00):", self.t_amt)
        _row(tg, "Radius (0.1 – 10.0 px):",  self.t_rad)
        v.addWidget(tex_grp)

        # Unsharp Mask
        usm_grp = QGroupBox("Unsharp Mask", self)
        ug = QVBoxLayout(usm_grp)
        self.u_amt = _spin(0.0, 2.0,  0.05, 2, cur.get("u_amt", 0.0))
        self.u_rad = _spin(0.1, 10.0, 0.1,  1, cur.get("u_rad", 2.0))
        self.u_thr = _spin(0.0, 0.1,  0.001, 3, cur.get("u_thr", 0.0))
        _row(ug, "Amount (0.00 – 2.00):",     self.u_amt)
        _row(ug, "Radius (0.1 – 10.0 px):",   self.u_rad)
        _row(ug, "Threshold (0.000 – 0.100):", self.u_thr)
        v.addWidget(usm_grp)

        # Clarity
        clar_grp = QGroupBox("Clarity", self)
        cg = QVBoxLayout(clar_grp)
        self.c_amt = _spin(-1.0, 1.0, 0.05, 2, cur.get("c_amt", 0.0))
        self.c_rad = _spin( 0.1, 10.0, 0.1, 1, cur.get("c_rad", 3.0))
        _row(cg, "Amount (−1.00 to 1.00):", self.c_amt)
        _row(cg, "Radius (0.1 – 10.0 px):",  self.c_rad)
        v.addWidget(clar_grp)

        # Clarity midtone mask
        mask_grp = QGroupBox("Clarity Mask", self)
        mg = QVBoxLayout(mask_grp)
        self.mask_str = _spin(0.0, 1.0, 0.05, 2, cur.get("mask_str", 1.0))
        _row(mg, "Midtone strength (1=midtones, 0=everywhere):", self.mask_str)
        v.addWidget(mask_grp)

        # OK / Cancel
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        v.addWidget(btns)

    def result_dict(self) -> dict:
        return {
            "t_amt":    self.t_amt.value(),
            "t_rad":    self.t_rad.value(),
            "u_amt":    self.u_amt.value(),
            "u_rad":    self.u_rad.value(),
            "u_thr":    self.u_thr.value(),
            "c_amt":    self.c_amt.value(),
            "c_rad":    self.c_rad.value(),
            "mask_str": self.mask_str.value(),
        }

class _SyQonToolsPresetDialog(QDialog):
    """
    Preset editor for command_id="syqontools"

    Families:
      studio     — SyQon Studio neural CLI (all models: Prism / Parallax /
                   Axiom / Deep Gradient) — the consolidated path
      starless   — (legacy) model kind + temp stretch
      denoise    — (legacy) Prism Mini/Deep + all Prism settings
      sharpening — (legacy) Parallax: correction, star reduction, sharpen strength
    """
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("SyQon Tools — Preset")
        init = dict(initial or {})
 
        lay = QVBoxLayout(self)
        form = QFormLayout()
 
        # ── Family ──
        self.cmb_family = QComboBox(self)
        self.cmb_family.addItem("Studio (all models)",   "studio")
        self.cmb_family.addItem("Starless (legacy)",     "starless")
        self.cmb_family.addItem("Denoise (legacy)",      "denoise")
        self.cmb_family.addItem("Sharpening (legacy)",   "sharpening")
 
        fam0 = str(init.get("family", "studio") or "studio").strip().lower()
        idx  = self.cmb_family.findData(fam0)
        if idx < 0: idx = 0
        self.cmb_family.setCurrentIndex(idx)
        form.addRow("Tool family:", self.cmb_family)
 
        lay.addLayout(form)

        # ── Studio group (SyQon Studio neural CLI) ──
        # Single source of truth for the model list; fall back to a static copy
        # if the module can't be imported at editor-open time.
        try:
            from setiastro.saspro.syqon_studio import STUDIO_MODELS as _SM, studio_family_for as _sff
            self._studio_fam = {m[0]: m[3] for m in _SM}
            _studio_choices = [(m[0], m[1]) for m in _SM]
        except Exception:
            _studio_choices = [
                ("prism-essential", "Prism Essential — Denoise"),
                ("prism-advanced",  "Prism Deep Advanced — Denoise"),
                ("prism-ultra",     "Prism Deep Ultra — Denoise"),
                ("prism-max",       "Prism Deep Max — Denoise"),
                ("prism-legacy-v1", "Prism Legacy V1 — Denoise"),
                ("prism-legacy-v2", "Prism Legacy V2 — Denoise"),
                ("parallax",        "Parallax — Correct / Reduce / Deblur"),
                ("axiom",           "Axiom V3 — Starless"),
                ("deep-gradient",   "Deep Gradient — Gradient removal"),
            ]
            self._studio_fam = {
                "prism-essential": "prism", "prism-advanced": "prism", "prism-ultra": "prism",
                "prism-max": "prism", "prism-legacy-v1": "prism", "prism-legacy-v2": "prism",
                "parallax": "parallax", "axiom": "axiom", "deep-gradient": "deep-gradient",
            }

        self.grp_studio = QGroupBox("SyQon Studio Preset", self)
        fst = QFormLayout(self.grp_studio)

        self.cmb_studio_model = QComboBox(self)
        for _mid, _label in _studio_choices:
            self.cmb_studio_model.addItem(_label, userData=_mid)
        _sm0 = str(init.get("studio_model", "prism-essential") or "prism-essential").strip()
        _smi = self.cmb_studio_model.findData(_sm0)
        self.cmb_studio_model.setCurrentIndex(max(0, _smi))
        fst.addRow("Model:", self.cmb_studio_model)

        self.cmb_studio_domain = QComboBox(self)
        self.cmb_studio_domain.addItem("Auto (read metadata)", userData="auto")
        self.cmb_studio_domain.addItem("Linear", userData="linear")
        self.cmb_studio_domain.addItem("Non-linear", userData="nonlinear")
        _sd = self.cmb_studio_domain.findData(str(init.get("studio_domain", "auto") or "auto").lower())
        self.cmb_studio_domain.setCurrentIndex(max(0, _sd))
        fst.addRow("Input domain:", self.cmb_studio_domain)

        self.spin_studio_tile = QSpinBox(self)
        self.spin_studio_tile.setRange(256, 2048); self.spin_studio_tile.setSingleStep(64)
        self.spin_studio_tile.setValue(int(init.get("studio_tile", 512)))
        fst.addRow("Tile size:", self.spin_studio_tile)

        self.spin_studio_overlap = QSpinBox(self)
        self.spin_studio_overlap.setRange(0, 512)
        self.spin_studio_overlap.setValue(int(init.get("studio_overlap", 64)))
        fst.addRow("Overlap:", self.spin_studio_overlap)

        self.spin_studio_app = QDoubleSpinBox(self)
        self.spin_studio_app.setRange(0.0, 1.0); self.spin_studio_app.setDecimals(2)
        self.spin_studio_app.setSingleStep(0.05)
        self.spin_studio_app.setValue(float(init.get("studio_application", 1.0)))
        self.spin_studio_app.setToolTip("Prism only: blends the inferred result with the original (0..1).")
        self.lbl_studio_app = QLabel("Application (blend):", self)
        fst.addRow(self.lbl_studio_app, self.spin_studio_app)

        # Parallax sub-controls
        self.cmb_studio_px_family = QComboBox(self)
        self.cmb_studio_px_family.addItem("Aesthetics", userData="aesthetics")
        self.cmb_studio_px_family.addItem("Classic", userData="classic")
        _pf = self.cmb_studio_px_family.findData(str(init.get("studio_px_family", "aesthetics") or "aesthetics").lower())
        self.cmb_studio_px_family.setCurrentIndex(max(0, _pf))
        self.row_studio_px_family_lbl = QLabel("Parallax family:", self)
        fst.addRow(self.row_studio_px_family_lbl, self.cmb_studio_px_family)

        self.chk_studio_px_correct = QCheckBox("Stellar correction / defect repair", self)
        self.chk_studio_px_correct.setChecked(bool(init.get("studio_px_correct", True)))
        fst.addRow("", self.chk_studio_px_correct)

        _red = QWidget(self); _redl = QHBoxLayout(_red); _redl.setContentsMargins(0, 0, 0, 0)
        self.chk_studio_px_reduce = QCheckBox("Star reduction", self)
        self.chk_studio_px_reduce.setChecked(bool(init.get("studio_px_reduce", True)))
        self.spin_studio_px_reduce = QSpinBox(self); self.spin_studio_px_reduce.setRange(0, 10)
        self.spin_studio_px_reduce.setValue(int(init.get("studio_px_reduce_level", 5)))
        self.spin_studio_px_reduce.setFixedWidth(56)
        _redl.addWidget(self.chk_studio_px_reduce); _redl.addWidget(QLabel("level:", self))
        _redl.addWidget(self.spin_studio_px_reduce); _redl.addStretch(1)
        fst.addRow("", _red)

        _deb = QWidget(self); _debl = QHBoxLayout(_deb); _debl.setContentsMargins(0, 0, 0, 0)
        self.chk_studio_px_deblur = QCheckBox("Deblur (deconvolution)", self)
        self.chk_studio_px_deblur.setChecked(bool(init.get("studio_px_deblur", True)))
        self.spin_studio_px_deblur = QDoubleSpinBox(self); self.spin_studio_px_deblur.setRange(0.0, 1.0)
        self.spin_studio_px_deblur.setDecimals(2); self.spin_studio_px_deblur.setSingleStep(0.05)
        self.spin_studio_px_deblur.setValue(float(init.get("studio_px_deblur_strength", 0.5)))
        self.spin_studio_px_deblur.setFixedWidth(64)
        _debl.addWidget(self.chk_studio_px_deblur); _debl.addWidget(QLabel("strength:", self))
        _debl.addWidget(self.spin_studio_px_deblur); _debl.addStretch(1)
        fst.addRow("", _deb)

        # Axiom sub-controls
        self.cmb_studio_ax_stretch = QComboBox(self)
        self.cmb_studio_ax_stretch.addItem("Auto", userData="auto")
        self.cmb_studio_ax_stretch.addItem("Identity (already stretched)", userData="identity")
        self.cmb_studio_ax_stretch.addItem("Custom", userData="custom")
        _ax = self.cmb_studio_ax_stretch.findData(str(init.get("studio_ax_stretch", "auto") or "auto").lower())
        self.cmb_studio_ax_stretch.setCurrentIndex(max(0, _ax))
        self.row_studio_ax_stretch_lbl = QLabel("Axiom stretch:", self)
        fst.addRow(self.row_studio_ax_stretch_lbl, self.cmb_studio_ax_stretch)

        _axc = QWidget(self); _axcl = QHBoxLayout(_axc); _axcl.setContentsMargins(0, 0, 0, 0)
        self.spin_studio_ax_black = QDoubleSpinBox(self); self.spin_studio_ax_black.setRange(0.0, 1.0)
        self.spin_studio_ax_black.setDecimals(4); self.spin_studio_ax_black.setSingleStep(0.001)
        self.spin_studio_ax_black.setValue(float(init.get("studio_ax_black", 0.0)))
        self.spin_studio_ax_mid = QDoubleSpinBox(self); self.spin_studio_ax_mid.setRange(0.0, 1.0)
        self.spin_studio_ax_mid.setDecimals(4); self.spin_studio_ax_mid.setSingleStep(0.001)
        self.spin_studio_ax_mid.setValue(float(init.get("studio_ax_mid", 0.25)))
        self.spin_studio_ax_white = QDoubleSpinBox(self); self.spin_studio_ax_white.setRange(0.0, 1.0)
        self.spin_studio_ax_white.setDecimals(4); self.spin_studio_ax_white.setSingleStep(0.001)
        self.spin_studio_ax_white.setValue(float(init.get("studio_ax_white", 1.0)))
        for _cap, _sp in (("black", self.spin_studio_ax_black), ("mid", self.spin_studio_ax_mid), ("white", self.spin_studio_ax_white)):
            _axcl.addWidget(QLabel(_cap, self)); _axcl.addWidget(_sp)
        _axcl.addStretch(1)
        self.row_studio_ax_custom = _axc
        self.row_studio_ax_custom_lbl = QLabel("Custom points:", self)
        fst.addRow(self.row_studio_ax_custom_lbl, _axc)

        self.chk_studio_ax_stars = QCheckBox("Also create a Stars-Only document", self)
        self.chk_studio_ax_stars.setChecked(bool(init.get("studio_ax_make_stars", True)))
        fst.addRow("", self.chk_studio_ax_stars)

        # Deep Gradient sub-control
        self.chk_studio_dg_gradient = QCheckBox("Also create the extracted-gradient document", self)
        self.chk_studio_dg_gradient.setChecked(bool(init.get("studio_dg_make_gradient", False)))
        fst.addRow("", self.chk_studio_dg_gradient)

        lay.addWidget(self.grp_studio)

        # keep a list of every studio widget so we can toggle the whole group
        self._studio_widgets = [
            self.cmb_studio_model, self.cmb_studio_domain, self.spin_studio_tile,
            self.spin_studio_overlap, self.spin_studio_app, self.lbl_studio_app,
            self.cmb_studio_px_family, self.row_studio_px_family_lbl,
            self.chk_studio_px_correct, self.chk_studio_px_reduce, self.spin_studio_px_reduce,
            self.chk_studio_px_deblur, self.spin_studio_px_deblur,
            self.cmb_studio_ax_stretch, self.row_studio_ax_stretch_lbl,
            self.row_studio_ax_custom, self.row_studio_ax_custom_lbl,
            self.chk_studio_ax_stars, self.chk_studio_dg_gradient,
        ]
        self.cmb_studio_model.currentIndexChanged.connect(self._studio_sync)
        self.cmb_studio_ax_stretch.currentIndexChanged.connect(self._studio_sync)
        self.chk_studio_px_reduce.toggled.connect(lambda on: self.spin_studio_px_reduce.setEnabled(on))
        self.chk_studio_px_deblur.toggled.connect(lambda on: self.spin_studio_px_deblur.setEnabled(on))

        # ── Starless group ──
        self.grp_starless = QGroupBox("Starless Preset", self)
        fs = QFormLayout(self.grp_starless)
 
        self.cmb_starless_model = QComboBox(self)
        self.cmb_starless_model.addItem("Nadir",     "nadir")
        self.cmb_starless_model.addItem("AxiomV2",   "axiomv2")
        self.cmb_starless_model.addItem("AxiomV2.1", "axiomv2.1")
        self.cmb_starless_model.addItem("AxiomV2.2", "axiomv2.2")
        sm0 = str(init.get("starless_model_kind", "nadir") or "nadir").strip().lower()
        idx = self.cmb_starless_model.findData(sm0)
        self.cmb_starless_model.setCurrentIndex(max(0, idx))
        fs.addRow("Model:", self.cmb_starless_model)
 
        self.chk_starless_mtf = QCheckBox("Apply temporary stretch (recommended for linear data)", self)
        self.chk_starless_mtf.setChecked(bool(init.get("starless_use_mtf", True)))
        fs.addRow("", self.chk_starless_mtf)
 
        self.spin_starless_mtf = QDoubleSpinBox(self)
        self.spin_starless_mtf.setRange(0.01, 0.50); self.spin_starless_mtf.setDecimals(3)
        self.spin_starless_mtf.setSingleStep(0.01)
        self.spin_starless_mtf.setValue(float(init.get("starless_mtf_target_median", 0.25)))
        self.spin_starless_mtf.setEnabled(self.chk_starless_mtf.isChecked())
        self.chk_starless_mtf.toggled.connect(self.spin_starless_mtf.setEnabled)
        fs.addRow("Stretch target median:", self.spin_starless_mtf)
 
        lay.addWidget(self.grp_starless)
 
        # ── Prism group ──
        self.grp_prism = QGroupBox("Prism Preset", self)
        fp = QFormLayout(self.grp_prism)
 
        self.cmb_prism_model = QComboBox(self)
        self.cmb_prism_model.addItem("Prism Mini (free)", "prism_mini")
        self.cmb_prism_model.addItem("Prism Deep (paid)", "prism_deep")
        pm0 = str(init.get("prism_model_kind", "prism_mini") or "prism_mini").strip().lower()
        idx = self.cmb_prism_model.findData(pm0)
        self.cmb_prism_model.setCurrentIndex(max(0, idx))
        fp.addRow("Model:", self.cmb_prism_model)
 
        self.spin_prism_tile = QSpinBox(self)
        self.spin_prism_tile.setRange(128, 2048)
        self.spin_prism_tile.setValue(int(init.get("prism_tile_size", 512)))
        fp.addRow("Tile size:", self.spin_prism_tile)
 
        self.spin_prism_overlap = QSpinBox(self)
        self.spin_prism_overlap.setRange(16, 512)
        self.spin_prism_overlap.setValue(int(init.get("prism_overlap", 64)))
        fp.addRow("Overlap:", self.spin_prism_overlap)
 
        self.spin_prism_pad = QSpinBox(self)
        self.spin_prism_pad.setRange(0, 2048)
        self.spin_prism_pad.setValue(int(init.get("prism_pad", 64)))
        fp.addRow("Edge pad:", self.spin_prism_pad)
 
        self.spin_prism_strength = QDoubleSpinBox(self)
        self.spin_prism_strength.setRange(0.0, 1.0); self.spin_prism_strength.setDecimals(2)
        self.spin_prism_strength.setSingleStep(0.01)
        self.spin_prism_strength.setValue(float(init.get("prism_strength", 0.85)))
        fp.addRow("Strength:", self.spin_prism_strength)
 
        self.chk_prism_mtf = QCheckBox("Apply temporary stretch for model", self)
        self.chk_prism_mtf.setChecked(bool(init.get("prism_use_mtf", True)))
        fp.addRow("", self.chk_prism_mtf)
 
        self.spin_prism_mtf = QDoubleSpinBox(self)
        self.spin_prism_mtf.setRange(0.01, 0.50); self.spin_prism_mtf.setDecimals(3)
        self.spin_prism_mtf.setSingleStep(0.01)
        self.spin_prism_mtf.setValue(float(init.get("prism_mtf_target_median", 0.10)))
        self.spin_prism_mtf.setEnabled(self.chk_prism_mtf.isChecked())
        self.chk_prism_mtf.toggled.connect(self.spin_prism_mtf.setEnabled)
        fp.addRow("MTF target median:", self.spin_prism_mtf)
 
        self.chk_prism_amp = QCheckBox("Use AMP (mixed precision)", self)
        self.chk_prism_amp.setChecked(bool(init.get("prism_use_amp", False)))
        fp.addRow("", self.chk_prism_amp)
 
        lay.addWidget(self.grp_prism)
 
        # ── Parallax group ──
        self.grp_parallax = QGroupBox("Parallax Preset", self)
        fpar = QFormLayout(self.grp_parallax)

        self.cmb_par_mode = QComboBox(self)
        self.cmb_par_mode.addItem("Natural", userData="classic")
        self.cmb_par_mode.addItem("Defined", userData="aesthetics")
        _pm = str(init.get("parallax_mode", "classic") or "classic").strip().lower()
        _pmi = self.cmb_par_mode.findData(_pm)
        self.cmb_par_mode.setCurrentIndex(max(0, _pmi))
        self.cmb_par_mode.setToolTip(
            "Model set used for all Parallax stages.\n"
            "Natural — classic models.\n"
            "Defined — aesthetics models.")
        fpar.addRow("Mode:", self.cmb_par_mode)

        self.chk_par_correct = QCheckBox("Aberration correction", self)
        self.chk_par_correct.setChecked(bool(init.get("parallax_correct", True)))
        fpar.addRow("", self.chk_par_correct)
 
        # Star reduction + correction on same row
        star_row = QWidget(self)
        star_lay = QHBoxLayout(star_row)
        star_lay.setContentsMargins(0, 0, 0, 0); star_lay.setSpacing(12)
        star_lbl = QLabel("Star reduction (0=off, 1–10):", self)
        self.spin_par_star = QSpinBox(self)
        self.spin_par_star.setRange(0, 10)
        self.spin_par_star.setValue(int(init.get("parallax_star_level", 3)))
        self.spin_par_star.setFixedWidth(52)
        star_lay.addWidget(star_lbl)
        star_lay.addWidget(self.spin_par_star)
        star_lay.addStretch(1)
        fpar.addRow(star_row)
 
        self.spin_par_sharpen = QDoubleSpinBox(self)
        self.spin_par_sharpen.setRange(0.0, 1.0); self.spin_par_sharpen.setDecimals(2)
        self.spin_par_sharpen.setSingleStep(0.05)
        self.spin_par_sharpen.setValue(float(init.get("parallax_sharpen_alpha", 0.7)))
        self.spin_par_sharpen.setToolTip("0.0 = off, 1.0 = full sharpen")
        fpar.addRow("Sharpen strength:", self.spin_par_sharpen)
 
        self.spin_par_tile = QSpinBox(self)
        self.spin_par_tile.setRange(128, 2048)
        self.spin_par_tile.setValue(int(init.get("parallax_tile_size", 512)))
        fpar.addRow("Tile size:", self.spin_par_tile)
 
        self.spin_par_overlap = QSpinBox(self)
        self.spin_par_overlap.setRange(8, 512)
        self.spin_par_overlap.setValue(int(init.get("parallax_overlap", 64)))
        fpar.addRow("Overlap:", self.spin_par_overlap)
 
        self.spin_par_pad = QSpinBox(self)
        self.spin_par_pad.setRange(0, 2048)
        self.spin_par_pad.setValue(int(init.get("parallax_pad", 96)))
        fpar.addRow("Edge pad:", self.spin_par_pad)

        self.cmb_par_batch = QComboBox(self)
        for _l in ("Auto", "1", "2", "4", "8"):
            self.cmb_par_batch.addItem(_l, userData=_l)
        _b = str(init.get("parallax_batch_size", "Auto") or "Auto")
        _bi = self.cmb_par_batch.findData(_b)
        self.cmb_par_batch.setCurrentIndex(max(0, _bi))
        fpar.addRow("Batch size:", self.cmb_par_batch)
 
        self.chk_par_mtf = QCheckBox("Apply temporary stretch (recommended for linear data)", self)
        self.chk_par_mtf.setChecked(bool(init.get("parallax_use_mtf", True)))
        fpar.addRow("", self.chk_par_mtf)
 
        self.spin_par_mtf = QDoubleSpinBox(self)
        self.spin_par_mtf.setRange(0.01, 0.50); self.spin_par_mtf.setDecimals(3)
        self.spin_par_mtf.setSingleStep(0.01)
        self.spin_par_mtf.setValue(float(init.get("parallax_mtf_target", 0.15)))
        self.spin_par_mtf.setEnabled(self.chk_par_mtf.isChecked())
        fpar.addRow("MTF target median:", self.spin_par_mtf)

        self.chk_par_mtf_linked = QCheckBox("Linked stretch (preserves star colors)", self)
        self.chk_par_mtf_linked.setChecked(bool(init.get("parallax_mtf_linked", False)))
        self.chk_par_mtf_linked.setEnabled(self.chk_par_mtf.isChecked())
        fpar.addRow("", self.chk_par_mtf_linked)
        self.chk_par_mtf.toggled.connect(self.spin_par_mtf.setEnabled)
        self.chk_par_mtf.toggled.connect(self.chk_par_mtf_linked.setEnabled)
 
        lay.addWidget(self.grp_parallax)
 
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)
 
        self.cmb_family.currentIndexChanged.connect(self._sync_visibility)
        self._sync_visibility()
 
    def _sync_visibility(self):
        fam = str(self.cmb_family.currentData() or "studio")
        self.grp_studio.setVisible(fam == "studio")
        self.grp_starless.setVisible(fam == "starless")
        self.grp_prism.setVisible(fam == "denoise")
        self.grp_parallax.setVisible(fam == "sharpening")
        if fam == "studio":
            self._studio_sync()

    def _studio_sync(self):
        """Enable only the sub-controls relevant to the selected Studio model."""
        mid = str(self.cmb_studio_model.currentData() or "prism-essential")
        fam = self._studio_fam.get(mid, "prism")

        is_prism = (fam == "prism")
        is_parallax = (fam == "parallax")
        is_axiom = (fam == "axiom")
        is_gradient = (fam == "deep-gradient")

        # Application: Prism only. Tile/overlap: Prism + Parallax.
        self.lbl_studio_app.setVisible(is_prism)
        self.spin_studio_app.setVisible(is_prism)
        self.spin_studio_tile.setEnabled(is_prism or is_parallax)
        self.spin_studio_overlap.setEnabled(is_prism or is_parallax)

        for w in (self.cmb_studio_px_family, self.row_studio_px_family_lbl,
                  self.chk_studio_px_correct, self.chk_studio_px_reduce,
                  self.spin_studio_px_reduce, self.chk_studio_px_deblur,
                  self.spin_studio_px_deblur):
            w.setVisible(is_parallax)
        # keep the reduction/deblur amount enable-state honest even when shown
        self.spin_studio_px_reduce.setEnabled(is_parallax and self.chk_studio_px_reduce.isChecked())
        self.spin_studio_px_deblur.setEnabled(is_parallax and self.chk_studio_px_deblur.isChecked())

        for w in (self.cmb_studio_ax_stretch, self.row_studio_ax_stretch_lbl,
                  self.row_studio_ax_custom, self.row_studio_ax_custom_lbl,
                  self.chk_studio_ax_stars):
            w.setVisible(is_axiom)
        self.row_studio_ax_custom.setEnabled(
            is_axiom and self.cmb_studio_ax_stretch.currentData() == "custom"
        )

        self.chk_studio_dg_gradient.setVisible(is_gradient)
 
    def result_dict(self) -> dict:
        return {
            "family":   str(self.cmb_family.currentData() or "studio"),
            "auto_run": True,

            # Studio (SyQon neural CLI)
            "studio_model":             str(self.cmb_studio_model.currentData() or "prism-essential"),
            "studio_domain":            str(self.cmb_studio_domain.currentData() or "auto"),
            "studio_tile":              int(self.spin_studio_tile.value()),
            "studio_overlap":           int(self.spin_studio_overlap.value()),
            "studio_application":       float(self.spin_studio_app.value()),
            "studio_px_family":         str(self.cmb_studio_px_family.currentData() or "aesthetics"),
            "studio_px_correct":        bool(self.chk_studio_px_correct.isChecked()),
            "studio_px_reduce":         bool(self.chk_studio_px_reduce.isChecked()),
            "studio_px_reduce_level":   int(self.spin_studio_px_reduce.value()),
            "studio_px_deblur":         bool(self.chk_studio_px_deblur.isChecked()),
            "studio_px_deblur_strength": float(self.spin_studio_px_deblur.value()),
            "studio_ax_stretch":        str(self.cmb_studio_ax_stretch.currentData() or "auto"),
            "studio_ax_black":          float(self.spin_studio_ax_black.value()),
            "studio_ax_mid":            float(self.spin_studio_ax_mid.value()),
            "studio_ax_white":          float(self.spin_studio_ax_white.value()),
            "studio_ax_make_stars":     bool(self.chk_studio_ax_stars.isChecked()),
            "studio_dg_make_gradient":  bool(self.chk_studio_dg_gradient.isChecked()),

            # Starless
            "starless_model_kind":        str(self.cmb_starless_model.currentData() or "nadir"),
            "starless_use_mtf":           bool(self.chk_starless_mtf.isChecked()),
            "starless_mtf_target_median": float(self.spin_starless_mtf.value()),
 
            # Prism
            "prism_model_kind":        str(self.cmb_prism_model.currentData() or "prism_mini"),
            "prism_tile_size":         int(self.spin_prism_tile.value()),
            "prism_overlap":           int(self.spin_prism_overlap.value()),
            "prism_pad":               int(self.spin_prism_pad.value()),
            "prism_strength":          float(self.spin_prism_strength.value()),
            "prism_use_mtf":           bool(self.chk_prism_mtf.isChecked()),
            "prism_mtf_target_median": float(self.spin_prism_mtf.value()),
            "prism_use_amp":           bool(self.chk_prism_amp.isChecked()),
 
            # Parallax
            "parallax_mode":          str(self.cmb_par_mode.currentData() or "classic"),
            "parallax_correct":       bool(self.chk_par_correct.isChecked()),
            "parallax_star_level":    int(self.spin_par_star.value()),
            "parallax_sharpen_alpha": float(self.spin_par_sharpen.value()),
            "parallax_tile_size":     int(self.spin_par_tile.value()),
            "parallax_overlap":       int(self.spin_par_overlap.value()),
            "parallax_pad":           int(self.spin_par_pad.value()),
            "parallax_use_mtf":       bool(self.chk_par_mtf.isChecked()),
            "parallax_mtf_target":    float(self.spin_par_mtf.value()),
            "parallax_mtf_linked":    bool(self.chk_par_mtf_linked.isChecked()),
            "parallax_batch_size":    str(self.cmb_par_batch.currentData() or "Auto"),
        }

class _SRGCPresetDialog(QDialog):
    """
    Small preset form for Survey Reference Gradient Correction.

    Every control mirrors a key of srgc_params_from_preset() and carries the
    same bounds, so a preset edited here can never ask for something the
    live dialog would refuse.

    The survey list is imported LAZILY. shortcuts.py is pulled in early and
    by a lot of modules; survey_gradient drags in abe, astropy.wcs and the
    reproject stack, and making every SASpro start pay for that so a
    right-click menu can be populated would be a poor trade. If the import
    fails the combo stays editable with whatever name the preset carried, so
    an existing shortcut is never silently rewritten to a different survey.
    """

    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Survey Gradient — Preset")
        init = dict(initial or {})

        self.combo_survey = QComboBox()
        self.combo_survey.setEditable(True)
        _default = ""
        try:
            from setiastro.saspro.survey_gradient import (
                SURVEYS as _SURVEYS, DEFAULT_SURVEY as _DEF, _AVAILABILITY)
            _default = _DEF
            for _n, _i in _SURVEYS.items():
                self.combo_survey.addItem(_n, userData=_n)
                tag = _i.get("availability", "verified")
                if tag != "verified":
                    # Same warning the live dialog shows, so a preset is not
                    # built on a survey that cannot currently fetch.
                    self.combo_survey.setItemData(
                        self.combo_survey.count() - 1,
                        _AVAILABILITY.get(tag, ""), Qt.ItemDataRole.ToolTipRole)
        except Exception:
            pass
        _want = str(init.get("survey", _default) or _default)
        _i = self.combo_survey.findText(_want)
        if _i >= 0:
            self.combo_survey.setCurrentIndex(_i)
        elif _want:
            self.combo_survey.setEditText(_want)

        self.spin_work = QSpinBox()
        self.spin_work.setRange(256, 4096); self.spin_work.setSingleStep(256)
        self.spin_work.setValue(int(init.get("work_long_side", 1024)))
        self.spin_work.setToolTip(
            "Long side of the grid the reference is fetched on and both\n"
            "backgrounds are modelled at. A gradient is low-frequency by\n"
            "definition, so larger is slower without being better.")

        self.spin_degree = QSpinBox()
        self.spin_degree.setRange(0, 4)
        self.spin_degree.setValue(int(init.get("degree", 1)))
        self.spin_degree.setToolTip(
            "Polynomial degree for BOTH background models. Keep it low: a\n"
            "high-degree model on the target absorbs real structure before\n"
            "the reference gets a chance to explain it.")

        self.cb_rbf = QCheckBox("RBF refinement on both backgrounds")
        self.cb_rbf.setChecked(bool(init.get("rbf", True)))

        self.spin_samples = QSpinBox()
        self.spin_samples.setRange(20, 4000); self.spin_samples.setSingleStep(20)
        self.spin_samples.setValue(int(init.get("samples", 200)))

        self.spin_patch = QSpinBox()
        self.spin_patch.setRange(5, 151); self.spin_patch.setSingleStep(2)
        self.spin_patch.setValue(int(init.get("patch", 15)))

        self.spin_exclude = QSpinBox()
        self.spin_exclude.setRange(0, 95); self.spin_exclude.setSingleStep(5)
        self.spin_exclude.setSuffix(" %")
        self.spin_exclude.setValue(int(init.get("exclude", 50)))
        self.spin_exclude.setToolTip(
            "Fraction of the SURVEY's brightest pixels that are off-limits\n"
            "to sampling. The survey decides, not your frame — your gradient\n"
            "must not disqualify a location or the fit starves on the bright\n"
            "side.")

        self.spin_protect = QDoubleSpinBox()
        self.spin_protect.setRange(0.5, 20.0); self.spin_protect.setSingleStep(0.5)
        self.spin_protect.setDecimals(1)
        self.spin_protect.setValue(float(init.get("protect_k", 3.0)))
        self.spin_protect.setToolTip(
            "Signal protection on the reference, in MAD-sigma units.\n"
            "LOWER protects more.")

        self.spin_strength = QSpinBox()
        # Matches the live dialog: >100% is deliberate over-correction.
        self.spin_strength.setRange(0, 150); self.spin_strength.setSuffix(" %")
        self.spin_strength.setValue(int(init.get("strength", 100)))

        form = QFormLayout(self)
        form.addRow("Reference survey:", self.combo_survey)
        form.addRow("Work resolution:",  self.spin_work)
        form.addRow("Background degree:", self.spin_degree)
        form.addRow("Sample points:",    self.spin_samples)
        form.addRow("Patch size (px):",  self.spin_patch)
        form.addRow("Exclude brightest:", self.spin_exclude)
        form.addRow("Protect k (MAD):",  self.spin_protect)
        form.addRow("", self.cb_rbf)
        form.addRow("Strength:",         self.spin_strength)

        _note = QLabel(
            "Needs a plate solution and a network connection. A preset always "
            "uses a SURVEY: the dual-scope option in the live tool points at "
            "one array in one session, which a replay could not resolve.")
        _note.setWordWrap(True)
        _note.setStyleSheet("font-size: 10px; color: palette(placeholderText);")
        form.addRow(_note)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        return {
            "survey":         self.combo_survey.currentText().strip(),
            "work_long_side": int(self.spin_work.value()),
            "degree":         int(self.spin_degree.value()),
            "rbf":            bool(self.cb_rbf.isChecked()),
            "samples":        int(self.spin_samples.value()),
            "patch":          int(self.spin_patch.value()),
            "exclude":        int(self.spin_exclude.value()),
            "protect_k":      float(self.spin_protect.value()),
            "strength":       int(self.spin_strength.value()),
        }

class _RemovePedestalPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Remove Pedestal — Preset")
        init = dict(initial or {})

        self.combo_mode = QComboBox()
        self.combo_mode.addItem("Image minimum",        userData="min")
        self.combo_mode.addItem("Low percentile",       userData="percentile")
        self.combo_mode.addItem("First non-zero value", userData="first_nonzero")
        i = self.combo_mode.findData(str(init.get("mode", "min")).lower())
        self.combo_mode.setCurrentIndex(i if i >= 0 else 0)

        self.spin_pct = QDoubleSpinBox()
        self.spin_pct.setRange(0.0, 50.0); self.spin_pct.setDecimals(3)
        self.spin_pct.setSingleStep(0.05); self.spin_pct.setSuffix(" %")
        self.spin_pct.setValue(float(init.get("percentile", init.get("pct", 0.1))))

        self.cb_per_channel = QCheckBox("Per-channel (RGB)")
        self.cb_per_channel.setChecked(bool(init.get("per_channel", True)))

        form = QFormLayout(self)
        form.addRow("Subtract:", self.combo_mode)
        form.addRow("Percentile:", self.spin_pct)
        form.addRow("", self.cb_per_channel)

        def _sync(*_):
            self.spin_pct.setEnabled(self.combo_mode.currentData() == "percentile")
        self.combo_mode.currentIndexChanged.connect(_sync); _sync()

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        return {
            "mode": self.combo_mode.currentData() or "min",
            "percentile": float(self.spin_pct.value()),
            "per_channel": bool(self.cb_per_channel.isChecked()),
        }

class _RemoveGreenPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Remove Green — Preset")
        init = dict(initial or {})

        # Local labels so there’s no external dependency.
        MODE_LABELS = {
            "avg": "Average of other two channels",
            "max": "Max of other two channels",
            "min": "Min of other two channels",
        }
        MODE_INDEX = {"avg": 0, "max": 1, "min": 2}

        # Amount
        self.spin_amount = QDoubleSpinBox()
        self.spin_amount.setRange(0.0, 1.0)
        self.spin_amount.setDecimals(2)
        self.spin_amount.setSingleStep(0.05)
        self.spin_amount.setValue(float(init.get("amount", 1.00)))  # default full SCNR

        # Target channel
        CHANNEL_INDEX = {"G": 0, "R": 1, "B": 2, "M": 3, "C": 4, "Y": 5}
        self.combo_channel = QComboBox()
        self.combo_channel.addItem("Green",   userData="G")
        self.combo_channel.addItem("Red",     userData="R")
        self.combo_channel.addItem("Blue",    userData="B")
        self.combo_channel.addItem("Magenta", userData="M")
        self.combo_channel.addItem("Cyan",    userData="C")
        self.combo_channel.addItem("Yellow",  userData="Y")
        init_ch = str(init.get("channel", init.get("target_channel", "G"))).upper()
        self.combo_channel.setCurrentIndex(CHANNEL_INDEX.get(init_ch, 0))

        # Mode
        self.combo_mode = QComboBox()
        self.combo_mode.addItem(MODE_LABELS["avg"], userData="avg")
        self.combo_mode.addItem(MODE_LABELS["max"], userData="max")
        self.combo_mode.addItem(MODE_LABELS["min"], userData="min")
        init_mode = str(init.get("mode", init.get("neutral_mode", "avg"))).lower()
        self.combo_mode.setCurrentIndex(MODE_INDEX.get(init_mode, 0))

        # Preserve lightness
        self.cb_preserve = QCheckBox("Preserve lightness")
        self.cb_preserve.setChecked(bool(init.get("preserve_lightness", init.get("preserve", True))))

        # Layout
        form = QFormLayout(self)
        form.addRow("Target channel:", self.combo_channel)
        form.addRow("Amount (0–1):", self.spin_amount)
        form.addRow("Neutral mode:", self.combo_mode)
        form.addRow("", self.cb_preserve)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        return {
            "amount": float(self.spin_amount.value()),                 # 0..1
            "mode": self.combo_mode.currentData() or "avg",            # "avg" | "max" | "min"
            "preserve_lightness": bool(self.cb_preserve.isChecked()),  # True/False
            "channel": self.combo_channel.currentData() or "G",        # "R" | "G" | "B"
        }


class _BackgroundNeutralPresetDialog(QDialog):
    """
    Preset UI for Background Neutralization:
      • Mode: Auto (default) or Rectangle
      • Rect (normalized): x, y, w, h in [0..1]
    """
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Background Neutralization — Preset")
        init = dict(initial or {})

        # Mode radios
        self.radio_auto = QRadioButton("Auto (50×50 finder)")
        self.radio_rect = QRadioButton("Rectangle (normalized coords)")
        mode = (init.get("mode") or "auto").lower()
        if mode == "rect":
            self.radio_rect.setChecked(True)
        else:
            self.radio_auto.setChecked(True)

        # Rect spinboxes (normalized 0..1)
        rn = init.get("rect_norm") or [0.40, 0.60, 0.08, 0.06]
        self.spin_x = QDoubleSpinBox(); self._cfg_norm_box(self.spin_x, rn[0])
        self.spin_y = QDoubleSpinBox(); self._cfg_norm_box(self.spin_y, rn[1])
        self.spin_w = QDoubleSpinBox(); self._cfg_norm_box(self.spin_w, rn[2])
        self.spin_h = QDoubleSpinBox(); self._cfg_norm_box(self.spin_h, rn[3])

        form = QFormLayout(self)
        form.addRow(self.radio_auto)
        form.addRow(self.radio_rect)
        form.addRow("x (0..1):", self.spin_x)
        form.addRow("y (0..1):", self.spin_y)
        form.addRow("w (0..1):", self.spin_w)
        form.addRow("h (0..1):", self.spin_h)

        # Enable/disable rect fields based on mode
        self.radio_auto.toggled.connect(self._update_enabled)
        self.radio_rect.toggled.connect(self._update_enabled)
        self._update_enabled()

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)

    def _cfg_norm_box(self, box: QDoubleSpinBox, val: float):
        box.setRange(0.0, 1.0)
        box.setDecimals(3)
        box.setSingleStep(0.01)
        try:
            box.setValue(float(val))
        except Exception:
            box.setValue(0.0)

    def _update_enabled(self):
        on = self.radio_rect.isChecked()
        for w in (self.spin_x, self.spin_y, self.spin_w, self.spin_h):
            w.setEnabled(on)

    def result_dict(self) -> dict:
        if self.radio_auto.isChecked():
            return {"mode": "auto"}
        # sanitize/cap in [0,1]
        x = max(0.0, min(1.0, float(self.spin_x.value())))
        y = max(0.0, min(1.0, float(self.spin_y.value())))
        w = max(0.0, min(1.0, float(self.spin_w.value())))
        h = max(0.0, min(1.0, float(self.spin_h.value())))
        # ensure at least a 1e-6 nonzero footprint so integer rounding later doesn't zero-out
        if w == 0.0: w = 1e-6
        if h == 0.0: h = 1e-6
        return {"mode": "rect", "rect_norm": [x, y, w, h]}
    
class _WhiteBalancePresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("White Balance — Preset")
        init = dict(initial or {})
        v = QVBoxLayout(self)
        # Mode
        row = QHBoxLayout()
        row.addWidget(QLabel("Mode:"))
        self.mode = QComboBox()
        self.mode.addItems(["Star-Based", "Manual", "Auto"])
        m = (init.get("mode") or "star").lower()
        if m == "manual": self.mode.setCurrentText("Manual")
        elif m == "auto": self.mode.setCurrentText("Auto")
        else: self.mode.setCurrentText("Star-Based")
        row.addWidget(self.mode); row.addStretch()
        v.addLayout(row)
        # Star options
        self.grp_star = QGroupBox("Star-Based")
        sv = QGridLayout(self.grp_star)
        self.spin_thr = QDoubleSpinBox(); self.spin_thr.setRange(0.5, 200.0); self.spin_thr.setDecimals(1)
        self.spin_thr.setSingleStep(0.5); self.spin_thr.setValue(float(init.get("threshold", 50.0)))
        self.chk_reuse = QCheckBox("Reuse cached detections")
        self.chk_reuse.setChecked(bool(init.get("reuse_cached_sources", True)))
        self.chk_color_matrix = QCheckBox(
            "Advanced Color Matrix WB  "
            "(cross-channel matrix aligned to blackbody locus)"
        )

        self.chk_color_matrix.setToolTip(
            "Applies a 3×3 color matrix solved from the detected stellar population.\n"
            "NOT recommended for narrowband or duoband data."
        )

        self.chk_color_matrix.setChecked(bool(init.get("use_color_matrix", False)))
        self.chk_color_matrix.setStyleSheet("color: #f0a000;")
        sv.addWidget(QLabel("Threshold (σ):"), 0, 0); sv.addWidget(self.spin_thr, 0, 1)
        sv.addWidget(self.chk_reuse, 1, 0, 1, 2)
        sv.addWidget(self.chk_color_matrix, 2, 0, 1, 2)
        v.addWidget(self.grp_star)
        # Manual options
        self.grp_manual = QGroupBox("Manual")
        gv = QGridLayout(self.grp_manual)
        self.r = QDoubleSpinBox(); self._cfg_gain(self.r, float(init.get("r_gain", 1.0)))
        self.g = QDoubleSpinBox(); self._cfg_gain(self.g, float(init.get("g_gain", 1.0)))
        self.b = QDoubleSpinBox(); self._cfg_gain(self.b, float(init.get("b_gain", 1.0)))
        gv.addWidget(QLabel("Red gain:"), 0, 0); gv.addWidget(self.r, 0, 1)
        gv.addWidget(QLabel("Green gain:"), 1, 0); gv.addWidget(self.g, 1, 1)
        gv.addWidget(QLabel("Blue gain:"), 2, 0); gv.addWidget(self.b, 2, 1)
        v.addWidget(self.grp_manual)
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        v.addWidget(btns)
        self.mode.currentTextChanged.connect(self._refresh)
        self._refresh()

    def _cfg_gain(self, box: QDoubleSpinBox, val: float):
        box.setRange(0.5, 1.5); box.setDecimals(3); box.setSingleStep(0.01); box.setValue(val)

    def _refresh(self):
        t = self.mode.currentText()
        self.grp_star.setVisible(t == "Star-Based")
        self.grp_manual.setVisible(t == "Manual")

    def result_dict(self) -> dict:
        t = self.mode.currentText()
        if t == "Manual":
            return {"mode": "manual", "r_gain": float(self.r.value()), "g_gain": float(self.g.value()), "b_gain": float(self.b.value())}
        if t == "Auto":
            return {"mode": "auto"}
        return {
            "mode": "star",
            "threshold": float(self.spin_thr.value()),
            "reuse_cached_sources": bool(self.chk_reuse.isChecked()),
            "use_color_matrix": bool(self.chk_color_matrix.isChecked()),
        }


class _WaveScaleHDRPresetDialog(QDialog):
    """
    Preset UI for WaveScale HDR:
      • n_scales (2..10)
      • compression_factor (0.10..5.00)
      • mask_gamma (0.10..10.00)
      • decay_rate (0.10..1.00)
      • optional dim_gamma (enable to store; omit to use auto)
    """
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("WaveScale HDR — Preset")
        init = dict(initial or {})

        form = QFormLayout(self)

        self.sp_scales = QSpinBox()
        self.sp_scales.setRange(2, 10)
        self.sp_scales.setValue(int(init.get("n_scales", 5)))

        self.dp_comp = QDoubleSpinBox()
        self.dp_comp.setRange(0.10, 5.00)
        self.dp_comp.setDecimals(2)
        self.dp_comp.setSingleStep(0.05)
        self.dp_comp.setValue(float(init.get("compression_factor", 1.50)))

        self.dp_gamma = QDoubleSpinBox()
        self.dp_gamma.setRange(0.10, 10.00)
        self.dp_gamma.setDecimals(2)
        self.dp_gamma.setSingleStep(0.05)
        # matches slider default of 500 → 5.00
        self.dp_gamma.setValue(float(init.get("mask_gamma", 5.00)))

        self.dp_decay = QDoubleSpinBox()
        self.dp_decay.setRange(0.10, 1.00)
        self.dp_decay.setDecimals(2)
        self.dp_decay.setSingleStep(0.05)
        self.dp_decay.setValue(float(init.get("decay_rate", 0.50)))

        # Optional dim gamma
        row_dim = QHBoxLayout()
        self.chk_dim = QCheckBox("Use custom dim γ")
        self.dp_dim = QDoubleSpinBox()
        self.dp_dim.setRange(0.10, 6.00)
        self.dp_dim.setDecimals(2)
        self.dp_dim.setSingleStep(0.05)
        self.dp_dim.setValue(float(init.get("dim_gamma", 2.00)))
        if "dim_gamma" in init:
            self.chk_dim.setChecked(True)
        self.dp_dim.setEnabled(self.chk_dim.isChecked())
        self.chk_dim.toggled.connect(self.dp_dim.setEnabled)
        row_dim.addWidget(self.chk_dim)
        row_dim.addWidget(self.dp_dim, 1)

        form.addRow("Number of scales:", self.sp_scales)
        form.addRow("Coarse compression:", self.dp_comp)
        form.addRow("Mask gamma:", self.dp_gamma)
        form.addRow("Decay rate:", self.dp_decay)
        form.addRow("Dimming:", row_dim)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        out = {
            "n_scales": int(self.sp_scales.value()),
            "compression_factor": float(self.dp_comp.value()),
            "mask_gamma": float(self.dp_gamma.value()),
            "decay_rate": float(self.dp_decay.value()),
        }
        if self.chk_dim.isChecked():
            out["dim_gamma"] = float(self.dp_dim.value())  # you said you'll add this param
        return out

class _WaveScaleDarkEnhancerPresetDialog(QDialog):
    """
    Preset UI for WaveScale Dark Enhancer:
      • n_scales (2–10)
      • boost_factor (0.10–10.00)
      • mask_gamma (0.10–10.00)
      • iterations (1–10)
    """
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("WaveScale Dark Enhancer — Preset")
        init = dict(initial or {})

        form = QFormLayout(self)

        self.sp_scales = QSpinBox(); self.sp_scales.setRange(2, 10); self.sp_scales.setValue(int(init.get("n_scales", 6)))
        self.dp_boost  = QDoubleSpinBox(); self.dp_boost.setRange(0.10, 10.00); self.dp_boost.setDecimals(2); self.dp_boost.setSingleStep(0.05)
        self.dp_boost.setValue(float(init.get("boost_factor", 5.00)))
        self.dp_gamma  = QDoubleSpinBox(); self.dp_gamma.setRange(0.10, 10.00); self.dp_gamma.setDecimals(2); self.dp_gamma.setSingleStep(0.05)
        self.dp_gamma.setValue(float(init.get("mask_gamma", 1.00)))
        self.sp_iters  = QSpinBox(); self.sp_iters.setRange(1, 10); self.sp_iters.setValue(int(init.get("iterations", 2)))

        form.addRow("Number of scales:", self.sp_scales)
        form.addRow("Boost factor:", self.dp_boost)
        form.addRow("Mask gamma:", self.dp_gamma)
        form.addRow("Iterations:", self.sp_iters)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                QDialogButtonBox.StandardButton.Cancel,
                                parent=self)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        return {
            "n_scales": int(self.sp_scales.value()),
            "boost_factor": float(self.dp_boost.value()),
            "mask_gamma": float(self.dp_gamma.value()),
            "iterations": int(self.sp_iters.value()),
        }

class _CLAHEPresetDialog(QDialog):
    """
    Preset UI for CLAHE:
      • clip_limit (0.10–20.00)
      • tile_px (8–1024 px)  → converted to OpenCV tileGridSize based on image size
      • blend (0.00–1.00)
      • precision — 16- or 8-bit CLAHE plane

    Ranges mirror the CLAHE tool's own controls on purpose. A narrower range
    here would silently clamp a preset dropped from the tool's grip, so the
    shortcut would stop matching the settings it was created from.
    """
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("CLAHE — Preset")
        init = dict(initial or {})

        # Keep the default in step with the tool, so flipping the module
        # constant changes both places at once.
        try:
            from setiastro.saspro.clahe import DEFAULT_PRECISION as _DEF_PREC
        except Exception:
            _DEF_PREC = 16

        form = QFormLayout(self)

        self.dp_clip = QDoubleSpinBox()
        self.dp_clip.setRange(0.10, 20.00)
        self.dp_clip.setDecimals(2)
        self.dp_clip.setSingleStep(0.10)
        self.dp_clip.setValue(max(0.10, min(20.00, float(init.get("clip_limit", 2.00)))))

        self.sp_tile_px = QSpinBox()
        self.sp_tile_px.setRange(8, 1024)
        self.sp_tile_px.setSingleStep(8)

        # Support both old and new in the UI:
        if "tile_px" in init:
            self.sp_tile_px.setValue(max(8, min(1024, int(init.get("tile_px", 128)))))
        elif "tile" not in init:
            # No tile information at all (new/empty preset) -> the tool's own
            # default. Previously this fell into the legacy branch below and
            # came back as 256 px, which is not what the CLAHE tool opens with.
            self.sp_tile_px.setValue(128)
        else:
            # legacy tile count → rough px guess; keeps old presets "reasonable"
            legacy_tile = int(init.get("tile", 8))
            legacy_tile = max(2, min(legacy_tile, 128))
            # Heuristic: convert tile count to a "typical" px size assuming ~2048 min dim
            px_guess = int(round(2048 / float(legacy_tile)))
            px_guess = max(8, min(px_guess, 1024))
            # snap to step 8
            px_guess = int(round(px_guess / 8)) * 8
            self.sp_tile_px.setValue(px_guess)

        self.dp_blend = QDoubleSpinBox()
        self.dp_blend.setRange(0.00, 1.00)
        self.dp_blend.setDecimals(2)
        self.dp_blend.setSingleStep(0.05)
        # Accept fractional (0..1) or percent (0..100) presets.
        _b = float(init.get("blend", 1.0))
        if _b > 1.0:
            _b = _b / 100.0
        self.dp_blend.setValue(max(0.0, min(1.0, _b)))

        self.cb_16bit = QCheckBox("16-bit CLAHE plane")
        try:
            _prec = int(init.get("precision", _DEF_PREC))
        except Exception:
            _prec = _DEF_PREC
        self.cb_16bit.setChecked(_prec >= 16)
        self.cb_16bit.setToolTip(
            "Run CLAHE on a 16-bit plane instead of 8-bit.\n"
            "Avoids posterisation on 32-bit float data. Uncheck to reproduce\n"
            "results from SASpro builds before the CLAHE rework."
        )

        form.addRow("Clip limit:", self.dp_clip)
        form.addRow("Tile size (px):", self.sp_tile_px)
        form.addRow("Blend amount:", self.dp_blend)
        form.addRow("Precision:", self.cb_16bit)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        return {
            "clip_limit": float(self.dp_clip.value()),
            "tile_px": int(self.sp_tile_px.value()),
            "blend": float(self.dp_blend.value()),
            "precision": 16 if self.cb_16bit.isChecked() else 8,
        }

class _MorphologyPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Morphology — Preset")
        init = dict(initial or {})

        form = QFormLayout(self)

        self.op = QComboBox()
        self.op.addItems(["Erosion", "Dilation", "Opening", "Closing"])
        op = (init.get("operation","erosion") or "erosion").lower()
        idx = {"erosion":0,"dilation":1,"opening":2,"closing":3}.get(op,0)
        self.op.setCurrentIndex(idx)

        self.k = QSpinBox(); self.k.setRange(1,31); self.k.setSingleStep(2)
        kv = int(init.get("kernel", 3)); self.k.setValue(kv if kv%2==1 else kv+1)

        self.it = QSpinBox(); self.it.setRange(1,10); self.it.setValue(int(init.get("iterations",1)))

        form.addRow("Operation:", self.op)
        form.addRow("Kernel size (odd):", self.k)
        form.addRow("Iterations:", self.it)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        op = ["erosion","dilation","opening","closing"][self.op.currentIndex()]
        k  = int(self.k.value());  k = k if k%2==1 else k+1
        it = int(self.it.value())
        return {"operation": op, "kernel": k, "iterations": it}

class _PixelMathPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Pixel Math — Preset")
        init = dict(initial or {})
        v = QVBoxLayout(self)
        self.rb_single = QRadioButton("Single"); self.rb_single.setChecked(init.get("mode","single")=="single")
        self.rb_rgb    = QRadioButton("Per-channel"); self.rb_rgb.setChecked(init.get("mode","single")=="rgb")
        row = QHBoxLayout(); row.addWidget(self.rb_single); row.addWidget(self.rb_rgb); row.addStretch(1)
        v.addLayout(row)
        self.ed_single = QPlainTextEdit(); self.ed_single.setPlaceholderText("expr"); self.ed_single.setPlainText(init.get("expr",""))
        v.addWidget(self.ed_single)
        self.tabs = QTabWidget(); 
        self.ed_r, self.ed_g, self.ed_b = QPlainTextEdit(), QPlainTextEdit(), QPlainTextEdit()
        for ed, name, key in ((self.ed_r,"Red","expr_r"),(self.ed_g,"Green","expr_g"),(self.ed_b,"Blue","expr_b")):
            w = QWidget(); lay = QVBoxLayout(w); ed.setPlainText(init.get(key,"")); lay.addWidget(ed); self.tabs.addTab(w, name)
        v.addWidget(self.tabs)
        self.rb_single.toggled.connect(lambda on: (self.ed_single.setVisible(on), self.tabs.setVisible(not on)))
        self.rb_single.toggled.emit(self.rb_single.isChecked())
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        v.addWidget(btns)
    def result_dict(self) -> dict:
        if self.rb_single.isChecked():
            return {"mode":"single","expr":self.ed_single.toPlainText().strip()}
        return {"mode":"rgb","expr_r":self.ed_r.toPlainText().strip(),
                "expr_g":self.ed_g.toPlainText().strip(),"expr_b":self.ed_b.toPlainText().strip()}

class _SignatureInsertPresetDialog(QDialog):
    """
    Preset editor for Signature / Insert.
    Keeps the PNG path + placement so users can drag a shortcut and re-apply.
    """
    POS_KEYS = [
        ("Top-Left", "top_left"),
        ("Top-Center", "top_center"),
        ("Top-Right", "top_right"),
        ("Middle-Left", "middle_left"),
        ("Center", "center"),
        ("Middle-Right", "middle_right"),
        ("Bottom-Left", "bottom_left"),
        ("Bottom-Center", "bottom_center"),
        ("Bottom-Right", "bottom_right"),
    ]

    def __init__(self, parent, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Signature / Insert – Preset")
        self.setMinimumWidth(520)

        init = dict(initial or {})
        v = QVBoxLayout(self)

        tip = QLabel("Tip: For transparent signatures, use a PNG and “Load from File”. "
                     "Views are RGB, so alpha is not preserved.")
        tip.setWordWrap(True)
        tip.setStyleSheet("color:#e0b000;")
        v.addWidget(tip)

        grid = QGridLayout()

        # File path
        grid.addWidget(QLabel("Signature file (PNG/JPG/TIF):"), 0, 0)
        self.ed_path = QLineEdit(init.get("file_path", ""))
        b_browse = QPushButton("Browse…")
        def _pick():
            fp, _ = QFileDialog.getOpenFileName(self, "Select signature image",
                                                "", "Images (*.png *.jpg *.jpeg *.tif *.tiff)")
            if fp: self.ed_path.setText(fp)
        b_browse.clicked.connect(_pick)
        grid.addWidget(self.ed_path, 0, 1)
        grid.addWidget(b_browse, 0, 2)

        # Position
        grid.addWidget(QLabel("Position:"), 1, 0)
        self.cb_pos = QComboBox()
        for text, key in self.POS_KEYS:
            self.cb_pos.addItem(text, userData=key)
        want = init.get("position", "bottom_right")
        idx = max(0, next((i for i,(_,k) in enumerate(self.POS_KEYS) if k == want), 0))
        self.cb_pos.setCurrentIndex(idx)
        grid.addWidget(self.cb_pos, 1, 1)

        # Margins
        grid.addWidget(QLabel("Margin X (px):"), 2, 0)
        self.sp_mx = QSpinBox(); self.sp_mx.setRange(0, 5000); self.sp_mx.setValue(int(init.get("margin_x", 20)))
        grid.addWidget(self.sp_mx, 2, 1)

        grid.addWidget(QLabel("Margin Y (px):"), 3, 0)
        self.sp_my = QSpinBox(); self.sp_my.setRange(0, 5000); self.sp_my.setValue(int(init.get("margin_y", 20)))
        grid.addWidget(self.sp_my, 3, 1)

        # Scale / Opacity / Rotation
        grid.addWidget(QLabel("Scale (%)"), 4, 0)
        self.sp_scale = QSpinBox(); self.sp_scale.setRange(10, 800); self.sp_scale.setValue(int(init.get("scale", 100)))
        grid.addWidget(self.sp_scale, 4, 1)

        grid.addWidget(QLabel("Opacity (%)"), 5, 0)
        self.sp_op = QSpinBox(); self.sp_op.setRange(0, 100); self.sp_op.setValue(int(init.get("opacity", 100)))
        grid.addWidget(self.sp_op, 5, 1)

        grid.addWidget(QLabel("Rotation (°)"), 6, 0)
        self.sp_rot = QSpinBox(); self.sp_rot.setRange(-180, 180); self.sp_rot.setValue(int(init.get("rotation", 0)))
        grid.addWidget(self.sp_rot, 6, 1)

        # Auto affix
        self.cb_affix = QCheckBox("Auto-affix after placement")
        self.cb_affix.setChecked(bool(init.get("auto_affix", True)))
        grid.addWidget(self.cb_affix, 7, 0, 1, 2)

        v.addLayout(grid)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        v.addWidget(btns)

    def result_dict(self) -> dict:
        return {
            "file_path": self.ed_path.text().strip(),
            "position":  self.cb_pos.currentData(),
            "margin_x":  int(self.sp_mx.value()),
            "margin_y":  int(self.sp_my.value()),
            "scale":     int(self.sp_scale.value()),
            "opacity":   int(self.sp_op.value()),
            "rotation":  int(self.sp_rot.value()),
            "auto_affix": bool(self.cb_affix.isChecked()),
        }

class _HaloBGonPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Halo-B-Gon Preset")
        v = QVBoxLayout(self)
        g = QGridLayout(); v.addLayout(g)

        g.addWidget(QLabel("Reduction:"), 0, 0)
        self.sl = QSlider(Qt.Orientation.Horizontal); self.sl.setRange(0,3); self.sl.setValue(int((initial or {}).get("reduction",0)))
        self.lab = QLabel(["Extra Low","Low","Medium","High"][self.sl.value()])
        self.sl.valueChanged.connect(lambda v: self.lab.setText(["Extra Low","Low","Medium","High"][int(v)]))
        g.addWidget(self.sl, 0, 1); g.addWidget(self.lab, 0, 2)

        self.cb = QCheckBox("Linear data"); self.cb.setChecked(bool((initial or {}).get("linear",False)))
        g.addWidget(self.cb, 1, 1)

        row = QHBoxLayout(); v.addLayout(row)
        ok = QPushButton("OK"); ok.clicked.connect(self.accept)
        ca = QPushButton("Cancel"); ca.clicked.connect(self.reject)
        row.addStretch(1); row.addWidget(ok); row.addWidget(ca)

    def result_dict(self) -> dict:
        return {"reduction": int(self.sl.value()), "linear": bool(self.cb.isChecked())}

class _RescalePresetDialog(QDialog):
    """
    Preset dialog for Geometry → Rescale.
    Stores: {"factor": float} where factor ∈ [0.10, 10.00].
    """
    def __init__(self, parent=None, initial=None):
        super().__init__(parent)
        self.setWindowTitle("Rescale Preset")
        self._initial = initial or {}

        from PyQt6.QtWidgets import QFormLayout, QDoubleSpinBox, QDialogButtonBox

        lay = QVBoxLayout(self)
        form = QFormLayout()

        self.spn_factor = QDoubleSpinBox(self)
        self.spn_factor.setDecimals(2)
        self.spn_factor.setRange(0.10, 10.00)
        self.spn_factor.setSingleStep(0.05)
        self.spn_factor.setValue(float(self._initial.get("factor", 1.0)))
        form.addRow("Scaling factor:", self.spn_factor)

        lay.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)

        self.resize(320, 120)

    def result_dict(self):
        return {"factor": float(self.spn_factor.value())}

class _ImageCombinePresetDialog(QDialog):
    def __init__(self, parent, initial: dict):
        super().__init__(parent); self.setWindowTitle("Image Combine Preset")
        mode = QComboBox(); mode.addItems(["Average","Add","Subtract","Blend","Multiply","Divide","Screen","Overlay","Difference"])
        mode.setCurrentText(initial.get("mode", "Blend"))
        alpha = QSlider(Qt.Orientation.Horizontal); alpha.setRange(0,100); alpha.setValue(int(100*float(initial.get("opacity",1.0))))
        luma = QCheckBox("Luminance only"); luma.setChecked(bool(initial.get("luma_only", False)))
        out_rep = QRadioButton("Replace A"); out_new = QRadioButton("Create new"); (out_new if initial.get("output")=="new" else out_rep).setChecked(True)
        from PyQt6.QtWidgets import QLineEdit
        other = QLineEdit(initial.get("docB_title","")); other.setPlaceholderText("Optional: exact title of B")

        form = QFormLayout()
        form.addRow("Mode:", mode)
        form.addRow("Opacity:", alpha)
        form.addRow("", luma)
        form.addRow("Output:", None)
        h = QHBoxLayout(); h.addWidget(out_rep); h.addWidget(out_new); h.addStretch(1)
        form.addRow("", QLabel(""))
        root = QVBoxLayout(self); root.addLayout(form); root.addLayout(h)
        form.addRow("Other source (title):", other)
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        root.addWidget(btns)
        self._mode, self._alpha, self._luma, self._rep, self._other = mode, alpha, luma, out_rep, other

    def result_dict(self):
        return {
            "mode": self._mode.currentText(),
            "opacity": self._alpha.value()/100.0,
            "luma_only": self._luma.isChecked(),
            "output": "replace" if self._rep.isChecked() else "new",
            "docB_title": self._other.text().strip(),
        }

class _StarSpikesPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Diffraction Spikes Preset")
        v = QVBoxLayout(self)
        g = QGridLayout(); v.addLayout(g)
        ini = dict(initial or {})

        row = 0
        def dspin(mini, maxi, step, key, default):
            sp = QDoubleSpinBox(); sp.setRange(mini, maxi); sp.setSingleStep(step); sp.setValue(float(ini.get(key, default)))
            return sp

        def ispin(mini, maxi, step, key, default):
            sp = QSpinBox(); sp.setRange(mini, maxi); sp.setSingleStep(step); sp.setValue(int(ini.get(key, default)))
            return sp

        self.flux_min  = dspin(0.0, 999999.0, 10.0, "flux_min", 30.0);   g.addWidget(QLabel("Flux Min:"), row,0); g.addWidget(self.flux_min, row,1); row+=1
        self.flux_max  = dspin(1.0, 999999.0, 50.0, "flux_max", 300.0);  g.addWidget(QLabel("Flux Max:"), row,0); g.addWidget(self.flux_max, row,1); row+=1
        self.bmin      = dspin(0.1, 999.0,   0.5,  "bscale_min", 10.0);  g.addWidget(QLabel("Boost Min:"), row,0); g.addWidget(self.bmin, row,1); row+=1
        self.bmax      = dspin(0.1, 999.0,   0.5,  "bscale_max", 30.0);  g.addWidget(QLabel("Boost Max:"), row,0); g.addWidget(self.bmax, row,1); row+=1
        self.smin      = dspin(0.1, 999.0,   0.1,  "shrink_min", 1.0);   g.addWidget(QLabel("Shrink Min:"), row,0); g.addWidget(self.smin, row,1); row+=1
        self.smax      = dspin(0.1, 999.0,   0.1,  "shrink_max", 5.0);   g.addWidget(QLabel("Shrink Max:"), row,0); g.addWidget(self.smax, row,1); row+=1
        self.dth       = dspin(0.0, 100.0,   0.1,  "detect_thresh", 5.0);g.addWidget(QLabel("Detect Threshold:"), row,0); g.addWidget(self.dth, row,1); row+=1
        self.radius    = dspin(1.0, 512.0,   1.0,  "radius", 128.0);     g.addWidget(QLabel("Pupil Radius:"), row,0); g.addWidget(self.radius, row,1); row+=1
        self.obstr     = dspin(0.0, 0.99,    0.01, "obstruction", 0.2);  g.addWidget(QLabel("Obstruction:"), row,0); g.addWidget(self.obstr, row,1); row+=1
        self.vanes     = ispin(2,   8,       1,    "num_vanes", 4);      g.addWidget(QLabel("Num Vanes:"), row,0); g.addWidget(self.vanes, row,1); row+=1
        self.vwidth    = dspin(0.0, 50.0,    0.5,  "vane_width", 4.0);   g.addWidget(QLabel("Vane Width:"), row,0); g.addWidget(self.vwidth, row,1); row+=1
        self.rotdeg    = dspin(0.0, 360.0,   1.0,  "rotation", 0.0);     g.addWidget(QLabel("Rotation (°):"), row,0); g.addWidget(self.rotdeg, row,1); row+=1
        self.boost     = dspin(0.1, 10.0,    0.1,  "color_boost", 1.5);  g.addWidget(QLabel("Spike Boost:"), row,0); g.addWidget(self.boost, row,1); row+=1
        self.blur      = dspin(0.1, 10.0,    0.1,  "blur_sigma", 2.0);   g.addWidget(QLabel("PSF Blur Sigma:"), row,0); g.addWidget(self.blur, row,1); row+=1

        self.jwst = QCheckBox("JWST Pupil"); self.jwst.setChecked(bool(ini.get("jwst", False)))
        g.addWidget(self.jwst, row, 0, 1, 2); row += 1

        rowbox = QHBoxLayout(); v.addLayout(rowbox)
        ok = QPushButton("OK"); ca = QPushButton("Cancel")
        ok.clicked.connect(self.accept); ca.clicked.connect(self.reject)
        rowbox.addStretch(1); rowbox.addWidget(ok); rowbox.addWidget(ca)

    def result_dict(self) -> dict:
        return {
            "flux_min": float(self.flux_min.value()),
            "flux_max": float(self.flux_max.value()),
            "bscale_min": float(self.bmin.value()),
            "bscale_max": float(self.bmax.value()),
            "shrink_min": float(self.smin.value()),
            "shrink_max": float(self.smax.value()),
            "detect_thresh": float(self.dth.value()),
            "radius": float(self.radius.value()),
            "obstruction": float(self.obstr.value()),
            "num_vanes": int(self.vanes.value()),
            "vane_width": float(self.vwidth.value()),
            "rotation": float(self.rotdeg.value()),
            "color_boost": float(self.boost.value()),
            "blur_sigma": float(self.blur.value()),
            "jwst": bool(self.jwst.isChecked()),
        }
    
class _DebayerPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Debayer — Preset")
        init = dict(initial or {})
        self.combo = QComboBox(self)
        self.combo.addItems(["auto", "RGGB", "BGGR", "GRBG", "GBRG"])
        want = str(init.get("pattern", "auto")).upper()
        idx = max(0, self.combo.findText(want, Qt.MatchFlag.MatchFixedString))
        self.combo.setCurrentIndex(idx)

        lay = QVBoxLayout(self)
        row = QHBoxLayout(); row.addWidget(QLabel("Bayer pattern:")); row.addWidget(self.combo, 1)
        lay.addLayout(row)
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        lay.addWidget(btns)

    def result_dict(self) -> dict:
        return {"pattern": self.combo.currentText().upper()}

#src/setiastro/saspro/shortcuts.py

from setiastro.saspro.curves_preset import (
    list_custom_presets, _norm_mode,
    _unwrap_preset_dict, _coerce_modes_dict, _is_linear_points_norm,
    _shape_points_norm, _MODE_KEY_TO_LABEL, _LABEL_TO_MODE_KEY,
)

class _CurvesPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Curves — Preset")
        init = dict(initial or {})
        init = _unwrap_preset_dict(init)          # peel {"preset": {...}} etc.
        self._original = dict(init)
        self._is_multi = (init.get("kind") == "curves_multi"
                        or isinstance(init.get("modes"), dict))
        if self._is_multi:
            self._modes = _coerce_modes_dict(init.get("modes", {}))
            ak = str(init.get("active") or "K")
            if ak not in self._modes and self._modes:
                ak = next(iter(self._modes))
            self._active_key = ak
            pts = self._modes.get(ak) or [(0.0, 0.0), (1.0, 1.0)]
            init = {                              # drive the widgets from the real data
                "mode":  _MODE_KEY_TO_LABEL.get(ak, "K (Brightness)"),
                "shape": "linear" if _is_linear_points_norm(pts) else "custom",
                "amount": 1.0,
                "points_norm": pts,
            }
        else:
            self._modes, self._active_key = None, None

        # --- Mode ---------------------------------------------------------
        self.mode = QComboBox()
        self.mode.addItems(["K (Brightness)", "R", "G", "B", "L*", "a*", "b*", "Chroma", "Saturation"])
        want = (init.get("mode") or "K (Brightness)").strip()
        self.mode.setCurrentIndex(max(0, self.mode.findText(want)))

        # --- Shape --------------------------------------------------------
        self.shape = QComboBox()
        self.shape.addItem("Linear", "linear")
        self.shape.addItem("S-curve (mild)", "s_mild")
        self.shape.addItem("S-curve (medium)", "s_med")
        self.shape.addItem("S-curve (strong)", "s_strong")
        self.shape.addItem("Lift shadows", "lift_shadows")
        self.shape.addItem("Crush shadows", "crush_shadows")
        self.shape.addItem("Fade blacks", "fade_blacks")
        self.shape.addItem("Highlight roll-off", "rolloff_highlights")
        self.shape.addItem("Flatten contrast", "flatten")
        self.shape.addItem("Custom points", "custom")
        self.shape.setCurrentIndex(max(0, self.shape.findData((init.get("shape") or "linear").lower())))

        # --- Amount (ignored if custom) -----------------------------------
        self.amount = QDoubleSpinBox()
        self.amount.setRange(0.0, 1.0); self.amount.setDecimals(2)
        self.amount.setSingleStep(0.05)
        self.amount.setValue(float(init.get("amount", 0.50)))

        # --- Custom points (normalized "x,y; x,y; ...") -------------------
        self.points = QLineEdit()
        self.points.setPlaceholderText("points_norm: x,y; x,y; ...  (0..1)  e.g. 0,0; 0.25,0.15; 0.75,0.85; 1,1")
        if isinstance(init.get("points_norm"), (list, tuple)) and init["points_norm"]:
            s = "; ".join(f"{float(x):.6g},{float(y):.6g}" for x, y in init["points_norm"])
            self.points.setText(s)

        # ===================== Custom Presets picker ======================
        self.preset_picker = QComboBox()
        self.btn_load = QPushButton("Load custom → fields")

        # populate & enable/disable based on availability
        self._rebuild_customs()
        self.btn_load.clicked.connect(self._load_selected_preset_into_fields)

        # wrap the load-row in a QWidget so we can hide/show the whole row
        load_row = QHBoxLayout()
        load_row.setContentsMargins(0, 0, 0, 0)
        load_row.addWidget(self.btn_load)
        self._row_custom_controls = QWidget(self)
        self._row_custom_controls.setLayout(load_row)

        # layout (use explicit labels so they can be hidden with the row)
        form = QFormLayout(self)
        form.addRow(QLabel("Mode:", self), self.mode)
        form.addRow(QLabel("Shape:", self), self.shape)
        form.addRow(QLabel("Amount (0–1):", self), self.amount)
        form.addRow(QLabel("Custom points:", self), self.points)

        self._lbl_custom_picker = QLabel("Custom presets:", self)
        form.addRow(self._lbl_custom_picker, self.preset_picker)
        form.addRow(QLabel("", self), self._row_custom_controls)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        form.addRow(btns)

        # enable/disable + show/hide depending on shape
        def _update_enabled():
            custom = (self.shape.currentData() == "custom")
            self.points.setEnabled(custom)
            self.amount.setEnabled(custom)

            # show/hide the custom presets UI as requested
            self._set_custom_picker_visible(custom)

        self.shape.currentIndexChanged.connect(_update_enabled)
        _update_enabled()
    # ---------------------------------------------------------------------

    def _set_custom_picker_visible(self, visible: bool):
        """Show/hide the custom presets picker + load row."""
        for w in (self._lbl_custom_picker, self.preset_picker, self._row_custom_controls):
            w.setVisible(bool(visible))

    def _rebuild_customs(self):
        """Refresh the list from QSettings and (de)activate picker/load."""
        self.preset_picker.clear()
        customs = list_custom_presets()
        if not customs:
            self.preset_picker.addItem("(No custom presets saved)", userData=None)
            self.preset_picker.setEnabled(False)
            self.btn_load.setEnabled(False)
            return
        self.preset_picker.setEnabled(True)
        self.btn_load.setEnabled(True)
        for p in sorted(customs, key=lambda d: d.get("name", "").lower()):
            self.preset_picker.addItem(p.get("name", "(unnamed)"), userData=p)

    def _load_selected_preset_into_fields(self):
        p = self.preset_picker.currentData()
        if not isinstance(p, dict):
            return
        # mode
        want = _norm_mode(p.get("mode"))
        idx = self.mode.findText(want)
        if idx >= 0:
            self.mode.setCurrentIndex(idx)
        # switch to custom
        j = self.shape.findData("custom")
        if j >= 0:
            self.shape.setCurrentIndex(j)
        # points → text
        pts = p.get("points_norm") or []
        if isinstance(pts, (list, tuple)) and pts:
            s = "; ".join(f"{float(x):.6g},{float(y):.6g}" for x, y in pts)
            self.points.setText(s)

    # -------------------- parsing & result -------------------------------
    def _parse_points_text(self) -> list[tuple[float, float]]:
        txt = (self.points.text() or "").strip()
        if not txt:
            return []
        s = txt.replace("\n", ";").replace("\r", ";")
        parts = [p.strip() for p in s.split(";") if p.strip()]
        out: list[tuple[float, float]] = []
        for part in parts:
            p = part.replace(",", " ").split()
            if len(p) != 2:
                continue
            try:
                x = float(p[0]); y = float(p[1])
            except ValueError:
                continue
            out.append((max(0.0, min(1.0, x)), max(0.0, min(1.0, y))))

        if out:
            if all(abs(x - 0.0) > 1e-6 for x, _ in out): out.insert(0, (0.0, 0.0))
            if all(abs(x - 1.0) > 1e-6 for x, _ in out): out.append((1.0, 1.0))
            out = sorted(out, key=lambda t: t[0])
            cleaned, lastx = [], -1.0
            for x, y in out:
                if x <= lastx: x = min(1.0, lastx + 1e-4)
                cleaned.append((x, y)); lastx = x
            out = cleaned
        return out

    def result_dict(self) -> dict:
        mode_label = _norm_mode(self.mode.currentText())
        shape = self.shape.currentData() or "linear"
        amt   = float(self.amount.value())

        if self._is_multi:
            pts = (self._parse_points_text() or [(0.0, 0.0), (1.0, 1.0)]) \
                if shape == "custom" else _shape_points_norm(shape, amt)
            modes = dict(self._modes or {})
            modes[_LABEL_TO_MODE_KEY.get(mode_label, "K")] = \
                [(float(x), float(y)) for (x, y) in pts]
            out = dict(self._original)        # keep kind/version/other channels
            out.update({
                "kind": "curves_multi", "version": 2,
                "active": _LABEL_TO_MODE_KEY.get(mode_label, "K"),
                "modes": {k: [list(p) for p in v] for k, v in modes.items()},
            })
            for k in ("mode", "shape", "amount", "points_norm"):
                out.pop(k, None)
            return out

        d = {"mode": mode_label, "shape": shape, "amount": amt}
        if shape == "custom":
            pts = self._parse_points_text()
            if pts: d["points_norm"] = pts
            else:   d["shape"] = "linear"; d.pop("points_norm", None)
        return d

class _GHSPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Universal Hyperbolic Stretch — Preset")
        init = dict(initial or {})

        def _mk_spin(minv, maxv, step, val, dec=2):
            s = QDoubleSpinBox(); s.setRange(minv, maxv); s.setDecimals(dec); s.setSingleStep(step); s.setValue(val); return s

        # Function selector
        self.function = QComboBox()
        self.function.addItems([
            "Hyperbolic Stretch",
            "ArcSinh Stretch",
            "Logarithmic Stretch",
            "Exponential Stretch",
            "Power of Inverted Pixels",
        ])
        want_fn = str(init.get("function", "Hyperbolic Stretch")).strip()
        i = self.function.findText(want_fn)
        self.function.setCurrentIndex(max(0, i))

        # Channel selector
        self.mode = QComboBox()
        self.mode.addItems(["K (Brightness)", "R", "G", "B"])
        want_ch = (init.get("channel") or "K (Brightness)").strip()
        i = self.mode.findText(want_ch); self.mode.setCurrentIndex(max(0, i))

        # GHS-only params
        self.alpha = _mk_spin(0.02, 10.0, 0.02, float(init.get("alpha", 1.00)))
        self.beta  = _mk_spin(0.02, 10.0, 0.02, float(init.get("beta",  1.00)))

        # Strength-based params (arcsinh/log/exp/pip)
        self.strength = _mk_spin(0.01, 100.0, 0.5, float(init.get("strength", 5.00)))

        # Shared params
        self.gamma = _mk_spin(0.01,  5.0, 0.01, float(init.get("gamma", 1.00)))
        self.pivot = _mk_spin(0.00,  1.0, 0.01, float(init.get("pivot", 0.50)))
        self.lp    = _mk_spin(0.00,  1.0, 0.01, float(init.get("lp",    0.00)))
        self.hp    = _mk_spin(0.00,  1.0, 0.01, float(init.get("hp",    0.00)))

        form = QFormLayout(self)
        form.addRow("Function:", self.function)
        form.addRow("Channel:", self.mode)

        self._lbl_alpha    = QLabel("α (0.02–10):")
        self._lbl_beta     = QLabel("β (0.02–10):")
        self._lbl_strength = QLabel("Strength:")
        form.addRow(self._lbl_alpha,    self.alpha)
        form.addRow(self._lbl_beta,     self.beta)
        form.addRow(self._lbl_strength, self.strength)
        form.addRow("γ (0.01–5):",  self.gamma)
        form.addRow("Pivot (0–1):", self.pivot)
        form.addRow("LP (0–1):",    self.lp)
        form.addRow("HP (0–1):",    self.hp)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        form.addRow(btns)

        self._form = form
        self.function.currentTextChanged.connect(self._on_function_changed)
        self._on_function_changed(self.function.currentText())

    def _on_function_changed(self, text: str):
        fn = text.lower()
        is_ghs = "hyperbolic" in fn
        is_pip = "pip" in fn or "inverted" in fn
        is_strength = not is_ghs

        self._lbl_alpha.setVisible(is_ghs)
        self.alpha.setVisible(is_ghs)
        self._lbl_beta.setVisible(is_ghs)
        self.beta.setVisible(is_ghs)
        self._lbl_strength.setVisible(is_strength)
        self.strength.setVisible(is_strength)

        # PIP strength range is 0..2, others are 0.01..100
        if is_pip:
            self.strength.setRange(0.0, 2.0)
            self.strength.setSingleStep(0.05)
            if self.strength.value() > 2.0:
                self.strength.setValue(1.0)
        else:
            self.strength.setRange(0.01, 100.0)
            self.strength.setSingleStep(0.5)

        # Pivot is meaningless for PIP
        self.pivot.setEnabled(not is_pip)

        self.adjustSize()

    def result_dict(self) -> dict:
        fn = self.function.currentText()
        fn_lower = fn.lower()
        is_ghs = "hyperbolic" in fn_lower
        d = {
            "function": fn,
            "channel":  self.mode.currentText(),
            "gamma":    float(self.gamma.value()),
            "pivot":    float(self.pivot.value()),
            "lp":       float(self.lp.value()),
            "hp":       float(self.hp.value()),
        }
        if is_ghs:
            d["alpha"] = float(self.alpha.value())
            d["beta"]  = float(self.beta.value())
        else:
            d["strength"] = float(self.strength.value())
        return d       

class _ABEPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("ABE — Preset")
        p = dict(initial or {})

        form = QFormLayout(self)

        # ---- core background model ----
        self.degree  = QSpinBox(); self.degree.setRange(0, 6);  self.degree.setValue(int(p.get("degree", 2)))
        self.degree.setToolTip("0 = skip polynomial (RBF-only).")
        self.samples = QSpinBox(); self.samples.setRange(20, 100000); self.samples.setSingleStep(20); self.samples.setValue(int(p.get("samples", 120)))
        self.down    = QSpinBox(); self.down.setRange(1, 64); self.down.setValue(int(p.get("downsample", 6)))
        self.patch   = QSpinBox(); self.patch.setRange(5, 151); self.patch.setSingleStep(2); self.patch.setValue(int(p.get("patch", 15)))
        self.rbf     = QCheckBox("Enable RBF"); self.rbf.setChecked(bool(p.get("rbf", True)))
        self.smooth  = QDoubleSpinBox(); self.smooth.setRange(0.0, 10.0); self.smooth.setDecimals(3); self.smooth.setSingleStep(0.01); self.smooth.setValue(float(p.get("rbf_smooth", 1.0)))
        self.seed    = QSpinBox(); self.seed.setRange(-1, 99999); self.seed.setValue(int(p.get("seed", 42)))
        self.seed.setSpecialValueText("Random (no seed)")
        self.seed.setToolTip("-1 = non-deterministic (different each run).\nAny other value = fully reproducible results.")
        self.mk_bg   = QCheckBox("Also create background document"); self.mk_bg.setChecked(bool(p.get("make_background_doc", False)))

        form.addRow("Polynomial degree:", self.degree)
        form.addRow("# samples:",         self.samples)
        form.addRow("Downsample:",        self.down)
        form.addRow("Patch size (px):",   self.patch)
        form.addRow(self.rbf)
        form.addRow("RBF smooth:",        self.smooth)
        form.addRow("Random seed:",       self.seed)
        form.addRow(self.mk_bg)

        # ---- correction mode ----
        _mode = str(p.get("correction_mode", "subtract")).lower()
        self.cmb_correction = QComboBox()
        self.cmb_correction.addItems(["Subtract", "Divide"])
        self.cmb_correction.setCurrentText("Divide" if _mode == "divide" else "Subtract")
        self.cmb_correction.setToolTip(
            "Subtract: standard additive background removal.\n"
            "Divide: for vignetting / multiplicative gradients."
        )
        form.addRow("Correction mode:", self.cmb_correction)

        # ---- multiscale multiplicative-gradient refinement ----
        _ms = p.get("multiscale", None) or {}
        self.ms_enable = QCheckBox("Enable multiscale refinement")
        self.ms_enable.setChecked(bool(_ms.get("enabled", False)))
        self.ms_enable.setToolTip(
            "Second pass that removes sharp multiplicative defects (dust motes,\n"
            "reflections, filter-edge shadows) that poly/RBF can't model.\n"
            "NOTE: headless (dropped-on-image) runs have no exclusion polygon,\n"
            "so this flattens the whole frame with no galaxy protection."
        )
        form.addRow(self.ms_enable)

        self.ms_darkstar = QCheckBox("Remove stars first (DarkStar)")
        self.ms_darkstar.setChecked(bool(_ms.get("darkstar", True)))
        self.ms_darkstar.setToolTip(
            "Estimate the gradient on a starless copy so stars don't pollute it.\n"
            "Stars are kept in the final output. Strongly recommended."
        )
        form.addRow(self.ms_darkstar)

        self.ms_band_lo = QSpinBox(); self.ms_band_lo.setRange(0, 11); self.ms_band_lo.setValue(int(_ms.get("band_lo", 6)))
        self.ms_band_hi = QSpinBox(); self.ms_band_hi.setRange(0, 11); self.ms_band_hi.setValue(int(_ms.get("band_hi", 8)))
        self.ms_band_lo.setMaximumWidth(56); self.ms_band_hi.setMaximumWidth(56)
        self.ms_band_lo.setToolTip("First detail layer treated as gradient (lower = finer).")
        self.ms_band_hi.setToolTip("Last detail layer (inclusive); higher = coarser.")
        _band_row = QHBoxLayout(); _band_row.setContentsMargins(0, 0, 0, 0)
        _band_row.addWidget(self.ms_band_lo)
        _band_row.addWidget(QLabel("to"))
        _band_row.addWidget(self.ms_band_hi)
        _band_row.addStretch(1)
        _band_wrap = QWidget(); _band_wrap.setLayout(_band_row)
        form.addRow("Scale band:", _band_wrap)

        self.ms_residual = QCheckBox("Include coarsest residual")
        self.ms_residual.setChecked(bool(_ms.get("include_residual", False)))
        self.ms_residual.setToolTip(
            "Usually OFF — the smooth background is already handled by poly/RBF;\n"
            "including it here risks double-correcting."
        )
        form.addRow(self.ms_residual)

        self.ms_strength = QSpinBox(); self.ms_strength.setRange(0, 100); self.ms_strength.setSuffix(" %")
        self.ms_strength.setValue(int(round(float(_ms.get("strength", 1.0)) * 100)))
        self.ms_strength.setToolTip("Blend strength of the correction (100% = full).")
        form.addRow("Strength:", self.ms_strength)

        self.ms_protect = QDoubleSpinBox(); self.ms_protect.setRange(1.0, 5.0); self.ms_protect.setSingleStep(0.5); self.ms_protect.setDecimals(1)
        self.ms_protect.setValue(float(_ms.get("protect_k", 3.0)))
        self.ms_protect.setToolTip(
            "Signal-protection threshold (median + k·MAD).\n"
            "k=1-2 protects aggressively, k=3 balanced, k=4-5 protects only bright cores."
        )
        form.addRow("Protect k (MAD):", self.ms_protect)

        self.ms_smooth = QSpinBox(); self.ms_smooth.setRange(0, 10); self.ms_smooth.setSuffix(" px")
        self.ms_smooth.setValue(int(_ms.get("smooth_px", 2)))
        self.ms_smooth.setToolTip(
            "Blur the gradient MAP before dividing, to strip per-pixel noise the\n"
            "band picked up (worst at low band numbers). 0 = off; 2-3 px typical."
        )
        form.addRow("Smooth gradient map:", self.ms_smooth)

        # keep the multiscale sub-controls disabled until the feature is on
        def _sync_ms(on: bool):
            for w in (self.ms_darkstar, self.ms_band_lo, self.ms_band_hi,
                      self.ms_residual, self.ms_strength, self.ms_protect, self.ms_smooth):
                w.setEnabled(bool(on))
        self.ms_enable.toggled.connect(_sync_ms)
        _sync_ms(self.ms_enable.isChecked())

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        form.addRow(btns)

    def values(self) -> dict:
        """Emit the preset in the exact schema apply_abe_via_preset() reads.
        Only includes the multiscale block when enabled, keeping legacy presets
        byte-clean when the feature is off."""
        out = {
            "degree":              int(self.degree.value()),
            "samples":             int(self.samples.value()),
            "downsample":          int(self.down.value()),
            "patch":               int(self.patch.value()),
            "rbf":                 bool(self.rbf.isChecked()),
            "rbf_smooth":          float(self.smooth.value()),
            "seed":                int(self.seed.value()),
            "make_background_doc": bool(self.mk_bg.isChecked()),
            "correction_mode":     "divide" if self.cmb_correction.currentText() == "Divide" else "subtract",
        }
        if self.ms_enable.isChecked():
            out["multiscale"] = {
                "enabled":          True,
                "darkstar":         bool(self.ms_darkstar.isChecked()),
                "band_lo":          int(self.ms_band_lo.value()),
                "band_hi":          int(self.ms_band_hi.value()),
                "include_residual": bool(self.ms_residual.isChecked()),
                "strength":         float(self.ms_strength.value()) / 100.0,
                "protect_k":        float(self.ms_protect.value()),
                "smooth_px":        float(self.ms_smooth.value()),
            }
        return out

    def result_dict(self) -> dict:
        return {
            "degree":              int(self.degree.value()),
            "samples":             int(self.samples.value()),
            "downsample":          int(self.down.value()),
            "patch":               int(self.patch.value()),
            "rbf":                 bool(self.rbf.isChecked()),
            "rbf_smooth":          float(self.smooth.value()),
            "seed":                int(self.seed.value()),
            "make_background_doc": bool(self.mk_bg.isChecked()),
        }      
    
class _CropPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Crop Preset")
        init = dict(initial or {})
        mode = str(init.get("mode", "margins")).lower()
        margins = dict(init.get("margins", {}))

        lay = QVBoxLayout(self)
        form = QFormLayout()

        # --- Mode + help button row --------------------------------------
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItems(["margins", "rect_norm", "quad_norm"])
        self.cmb_mode.setCurrentText(mode)
        # Per-item tooltips
        self.cmb_mode.setItemData(0, "Crop by pixel margins from each edge.", Qt.ItemDataRole.ToolTipRole)
        self.cmb_mode.setItemData(1, "Axis-aligned rectangle in 0..1 normalized coords (optional rotation).", Qt.ItemDataRole.ToolTipRole)
        self.cmb_mode.setItemData(2, "Four corners (TL,TR,BR,BL) in 0..1 normalized coords for perspective/keystone.", Qt.ItemDataRole.ToolTipRole)

        # Tiny "?" button
        self.btn_mode_help = QToolButton()
        self.btn_mode_help.setText("?")
        self.btn_mode_help.setToolTip("What do these modes mean?")
        self.btn_mode_help.setFixedWidth(24)
        self.btn_mode_help.clicked.connect(self._show_mode_help)

        # Put combo + help button on one row for the form
        mode_row = QWidget(self)
        mode_row_lay = QHBoxLayout(mode_row)
        mode_row_lay.setContentsMargins(0, 0, 0, 0)
        mode_row_lay.addWidget(self.cmb_mode, 1)
        mode_row_lay.addWidget(self.btn_mode_help, 0)
        form.addRow("Mode:", mode_row)
        # -----------------------------------------------------------------

        # Margins UI
        self.top = QSpinBox(); self.right = QSpinBox(); self.bottom = QSpinBox(); self.left = QSpinBox()
        for sb in (self.top, self.right, self.bottom, self.left):
            sb.setRange(0, 1_000_000)
        self.top.setValue(int(margins.get("top", 0)))
        self.right.setValue(int(margins.get("right", 0)))
        self.bottom.setValue(int(margins.get("bottom", 0)))
        self.left.setValue(int(margins.get("left", 0)))

        self.cb_new = QCheckBox("Create new view")
        self.cb_new.setChecked(bool(init.get("create_new_view", False)))
        self.le_title = QLineEdit(init.get("title", "Crop"))

        form.addRow("Top (px):", self.top)
        form.addRow("Right (px):", self.right)
        form.addRow("Bottom (px):", self.bottom)
        form.addRow("Left (px):", self.left)
        form.addRow("", self.cb_new)
        form.addRow("New view title:", self.le_title)
        lay.addLayout(form)

        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, parent=self)
        btns.accepted.connect(self.accept); btns.rejected.connect(self.reject)
        lay.addWidget(btns)

    def _show_mode_help(self):
        current = self.cmb_mode.currentText()
        txt = (
            "<b>Crop modes</b><br><br>"
            "<b>margins</b> — Crop by pixel offsets from each image edge.<br>"
            "• <i>top/right/bottom/left</i> are in pixels.<br><br>"
            "<b>rect_norm</b> — Axis-aligned rectangle (optionally rotated) expressed in normalized 0..1 units.<br>"
            "• Schema: { mode:'rect_norm', rect:{ x, y, w, h, angle_deg } }<br>"
            "• x,y: top-left; w,h: size; angle_deg: CCW rotation around center (optional).<br><br>"
            "<b>quad_norm</b> — Arbitrary 4-corner crop in normalized 0..1 units (perspective/keystone).<br>"
            "• Schema: { mode:'quad_norm', quad:[[xTL,yTL],[xTR,yTR],[xBR,yBR],[xBL,yBL]] }<br>"
            "• Order: TL, TR, BR, BL. (0,0)=top-left, (1,1)=bottom-right."
        )
        # Small extra hint for the selected item
        if current == "rect_norm":
            txt += "<br><br><i>Tip:</i> Use rect_norm for regular boxes; add a small angle when needed."
        elif current == "quad_norm":
            txt += "<br><br><i>Tip:</i> Use quad_norm when the box edges aren’t parallel (keystone or tilt)."

        QMessageBox.information(self, "Crop modes help", txt)

    def result_dict(self) -> dict:
        return {
            "mode": self.cmb_mode.currentText(),
            "margins": {
                "top": int(self.top.value()),
                "right": int(self.right.value()),
                "bottom": int(self.bottom.value()),
                "left": int(self.left.value()),
            },
            "create_new_view": bool(self.cb_new.isChecked()),
            "title": self.le_title.text().strip() or "Crop",
        }

class _RGBAlignPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("RGB Align — Preset")
        init = dict(initial or {})
        v = QVBoxLayout(self)

        # ── model row ───────────────────────────────────────
        row = QHBoxLayout()
        row.addWidget(QLabel("Alignment model:"))
        self.cb_model = QComboBox()
        # include EDGE first
        self.cb_model.addItems(["edge", "homography", "affine", "poly3", "poly4"])
        want = init.get("model", "edge").lower()
        idx = max(0, self.cb_model.findText(want, Qt.MatchFlag.MatchFixedString))
        self.cb_model.setCurrentIndex(idx)
        row.addWidget(self.cb_model, 1)
        v.addLayout(row)

        # ── SEP sigma ───────────────────────────────────────
        sep_row = QHBoxLayout()
        sep_row.addWidget(QLabel("SEP sigma:"))
        self.sb_sigma = QSpinBox()
        self.sb_sigma.setRange(1, 10)
        self.sb_sigma.setValue(int(init.get("sep_sigma", 3)))
        self.sb_sigma.setToolTip("Detection threshold (σ) for EDGE mode.\n"
                                 "Higher = fewer stars. Only used when model = EDGE.")
        sep_row.addWidget(self.sb_sigma)
        v.addLayout(sep_row)

        # ── create new ──────────────────────────────────────
        self.chk_new = QCheckBox("Create new document")
        self.chk_new.setChecked(bool(init.get("new_doc", True)))
        v.addWidget(self.chk_new)

        # ── buttons ─────────────────────────────────────────
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        v.addWidget(btns)

    def result_dict(self) -> dict:
        return {
            "model": self.cb_model.currentText().lower(),   # "edge" / "homography" / ...
            "sep_sigma": int(self.sb_sigma.value()),        # <-- new
            "new_doc": bool(self.chk_new.isChecked()),
        }

class _GeomRotateAnyPresetDialog(QDialog):
    def __init__(self, parent=None, initial: dict | None = None):
        super().__init__(parent)
        self.setWindowTitle("Arbitrary Rotation — Preset")
        init = dict(initial or {})

        self.spin_angle = QDoubleSpinBox()
        self.spin_angle.setRange(-360.0, 360.0)
        self.spin_angle.setDecimals(2)
        self.spin_angle.setSingleStep(0.25)
        self.spin_angle.setValue(float(init.get("angle_deg", init.get("angle", 0.0))))

        form = QFormLayout(self)
        form.addRow("Angle (degrees):", self.spin_angle)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)

    def result_dict(self) -> dict:
        return {
            "angle_deg": float(self.spin_angle.value()),
        }