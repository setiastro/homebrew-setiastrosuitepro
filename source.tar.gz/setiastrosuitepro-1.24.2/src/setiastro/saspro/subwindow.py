# src/setiastro/saspro/subwindow.py
from __future__ import annotations

import csv
import json
import math
import os
import re
import time
import weakref
from dataclasses import dataclass
from typing import Any, List, Optional, Tuple
import csv

import numpy as np
from PyQt6 import sip
from setiastro.saspro.color_space_manager import tag_qimage_with_working_color_space
from PyQt6.QtCore import (
    QAbstractTableModel,
    QByteArray,
    QEvent,
    QMargins,
    QMimeData,
    QModelIndex,
    QPoint,
    QRect,
    QSettings,
    QSize,
    Qt,
    QTimer,
    pyqtSignal,
    QSortFilterProxyModel,
    QSignalBlocker, QVariant,
)
from PyQt6.QtGui import (
    QCursor,
    QDrag,
    QGuiApplication,
    QImage,
    QKeySequence,
    QPixmap,
    QShortcut,
    QWheelEvent,
)
from PyQt6.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QMdiSubWindow,
    QPushButton,
    QRubberBand,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QStyledItemDelegate,
    QTableView,
    QToolButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qtagg import NavigationToolbar2QT as NavToolbar
from matplotlib.figure import Figure

from setiastro.saspro.autostretch import autostretch, autostretch_with_lut, apply_autostretch_lut
from .layers import BLEND_MODES, ImageLayer, composite_stack, _resize_like
from setiastro.saspro.help_support import make_help_button

def _layer_profile_log(msg: str):
    """Append a layer-compositing timing line to <temp>/sas_layers_profile.log."""
    try:
        import os, tempfile, datetime
        p = os.path.join(tempfile.gettempdir(), "sas_layers_profile.log")
        with open(p, "a", encoding="utf-8") as f:
            f.write(datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3] + "  " + msg + "\n")
    except Exception:
        pass
from setiastro.saspro.dnd_mime import (
    MIME_ASTROMETRY,
    MIME_CMD,
    MIME_LINKVIEW,
    MIME_MASK,
    MIME_VIEWSTATE,
)
from setiastro.saspro.shortcuts import _unpack_cmd_payload
from setiastro.saspro.widgets.image_utils import ensure_contiguous
from setiastro.saspro.imageops.viewport_render import resize_for_display, to_uint8_rgb
from setiastro.saspro.imageops.viewport_canvas import ViewportImageCanvas
from setiastro.saspro.imageops.tiled_canvas import TiledImageCanvas


__all__ = ["ImageSubWindow", "TableSubWindow"]

class SimpleTableModel(QAbstractTableModel):
    def __init__(self, rows: list[list], headers: list[str], parent=None):
        super().__init__(parent)
        self._rows = rows
        self._headers = headers

    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else (len(self._headers) if self._headers else (len(self._rows[0]) if self._rows else 0))

    def data(self, index: QModelIndex, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return QVariant()
        if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.EditRole):
            try:
                return str(self._rows[index.row()][index.column()])
            except Exception:
                return ""
        return QVariant()

    def headerData(self, section: int, orientation: Qt.Orientation, role=Qt.ItemDataRole.DisplayRole):
        if role != Qt.ItemDataRole.DisplayRole:
            return QVariant()
        if orientation == Qt.Orientation.Horizontal:
            try:
                return self._headers[section] if self._headers and 0 <= section < len(self._headers) else f"C{section+1}"
            except Exception:
                return f"C{section+1}"
        else:
            return str(section + 1)


class _DragTab(QLabel):
    """
    Little grab tab you can drag to copy/sync view state.
    - Drag onto MDI background → duplicate view (same document)
    - Drag onto another subwindow → copy zoom/pan/stretch to that view
    """
    def __init__(self, owner, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.owner = owner
        self._press_pos = None
        self.setText("⧉")
        self.setToolTip(self.tr(
            "Drag to duplicate/copy view.\n"
            "Hold Alt while dragging to LINK this view with another (live pan/zoom sync).\n"
            "Hold Shift while dragging to drop this image as a mask onto another view.\n"
            "Hold Ctrl while dragging to copy the astrometric solution (WCS) to another view."
        ))

        self.setFixedSize(22, 18)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.setStyleSheet(
            "QLabel{background:rgba(255,255,255,30); "
            "border:1px solid rgba(255,255,255,60); border-radius:4px;}"
        )

    def mousePressEvent(self, ev):
        if ev.button() == Qt.MouseButton.LeftButton:
            self._press_pos = ev.position()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)


    def mouseMoveEvent(self, ev):
        if self._press_pos is None:
            return
        if (ev.position() - self._press_pos).manhattanLength() > 6:
            self.setCursor(Qt.CursorShape.OpenHandCursor)
            self._press_pos = None
            mods = QApplication.keyboardModifiers()
            if (mods & Qt.KeyboardModifier.AltModifier):
                self.owner._start_link_drag()
            elif (mods & Qt.KeyboardModifier.ShiftModifier):
                print("[DragTab] Shift+drag → start_mask_drag() from", id(self.owner))
                self.owner._start_mask_drag()
            elif (mods & Qt.KeyboardModifier.ControlModifier):
                self.owner._start_astrometry_drag()
            else:
                self.owner._start_viewstate_drag()

    def mouseReleaseEvent(self, ev):
        self._press_pos = None
        self.setCursor(Qt.CursorShape.OpenHandCursor)

MASK_GLYPH = "■"
#ACTIVE_PREFIX = "Active View: "
ACTIVE_PREFIX = ""
GLYPHS = "■●◆▲▪▫•◼◻◾◽🔗"
LINK_PREFIX = "🔗 "
DECORATION_PREFIXES = (
    LINK_PREFIX,                # "🔗 "
    f"{MASK_GLYPH} ",           # "■ "
    "Active View: ",            # legacy
)

_GLYPH_RE = re.compile(f"[{re.escape(GLYPHS)}]")

def _strip_ui_decorations(title: str) -> str:
    if not title:
        return ""
    s = str(title).strip()

    # Remove common prefix tag(s)
    s = s.replace("[LINK]", "").strip()

    # Remove glyphs anywhere (often used as status markers in titles)
    s = _GLYPH_RE.sub("", s)

    # Collapse repeated whitespace
    s = re.sub(r"\s+", " ", s).strip()
    return s

from astropy.wcs import WCS as _AstroWCS
from astropy.io.fits import Header as _FitsHeader

def build_celestial_wcs(header) -> _AstroWCS | None:
    """
    Given a FITS-like header or a dict with FITS keywords, return a *2-D celestial*
    astropy.wcs.WCS. Returns None if a sane celestial WCS cannot be recovered.
    Resilient to 3rd axes (RGB/STOKES) and SIP distortions.

    Accepted `header`:
      * astropy.io.fits.Header
      * dict of FITS cards (string->value)
      * dict containing {"FITSKeywords": {NAME: [{value: ..., comment: ...}], ...}}
    """
    if header is None:
        return None

    # (A) If we already got a WCS, try to coerce to celestial
    if isinstance(header, _AstroWCS):
        try:
            wc = getattr(header, "celestial", None)
            return wc if (wc is not None and getattr(wc, "naxis", 2) == 2) else header
        except Exception:
            return header

    # (B) Ensure we have a bona-fide FITS Header
    hdr_obj = None
    if isinstance(header, _FitsHeader):
        hdr_obj = header
    elif isinstance(header, dict):
        # XISF-style: {"FITSKeywords": {"CTYPE1":[{"value":"RA---TAN"}], ...}}
        if "FITSKeywords" in header and isinstance(header["FITSKeywords"], dict):
            from astropy.io.fits import Header
            hdr_obj = Header()
            for k, v in header["FITSKeywords"].items():
                if isinstance(v, list) and v:
                    val = v[0].get("value")
                    com = v[0].get("comment", "")
                    if val is not None:
                        try: hdr_obj[str(k)] = (val, com)
                        except Exception: hdr_obj[str(k)] = val
                elif v is not None:
                    try: hdr_obj[str(k)] = v
                    except Exception as e:
                        import logging
                        logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
        else:
            # Flat dict of FITS-like cards
            from astropy.io.fits import Header
            hdr_obj = Header()
            for k, v in header.items():
                try: hdr_obj[str(k)] = v
                except Exception as e:
                    import logging
                    logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

    if hdr_obj is None:
        return None

    # (C) Try full WCS first
    try:
        w = _AstroWCS(hdr_obj, relax=True)
        wc = getattr(w, "celestial", None)
        if wc is not None and getattr(wc, "naxis", 2) == 2:
            return wc
        if getattr(w, "has_celestial", False):
            return w.celestial
    except Exception:
        w = None

    # (D) Force a 2-axis interpretation (drop e.g. RGB axis)
    try:
        w2 = _AstroWCS(hdr_obj, relax=True, naxis=2)
        if getattr(w2, "has_celestial", False):
            return w2.celestial
    except Exception:
        pass

    # (E) As a last resort, scrub obvious axis-3 cards and retry
    try:
        hdr2 = hdr_obj.copy()
        for k in ("CTYPE3","CUNIT3","CRVAL3","CRPIX3",
                  "CD3_1","CD3_2","CD3_3","PC3_1","PC3_2","PC3_3"):
            if k in hdr2:
                del hdr2[k]
        w3 = _AstroWCS(hdr2, relax=True, naxis=2)
        if getattr(w3, "has_celestial", False):
            return w3.celestial
    except Exception:
        pass

    return None

def _compute_cropped_wcs(parent_hdr_like, x, y, w, h):
    """
    Build a cropped WCS header from parent_hdr_like and ROI (x,y,w,h).

    IMPORTANT:
    - If the parent header already describes a cropped ROI (NAXIS1/2 already
      equal to w/h, or the ROI is obviously outside the parent NAXIS), we
      *do not* shift CRPIX again. We just return a copy of the parent header,
      marking it as ROI-CROP if needed.
    """
    # Normalize ROI values to ints
    x = int(x)
    y = int(y)
    w = int(w)
    h = int(h)

    # Same helper as before; safe on dict/FITS Header
    try:
        from astropy.io.fits import Header
    except Exception:
        Header = None

    if Header is not None and isinstance(parent_hdr_like, Header):
        base = {k: parent_hdr_like.get(k) for k in parent_hdr_like.keys()}
    elif isinstance(parent_hdr_like, dict):
        fk = parent_hdr_like.get("FITSKeywords")
        if isinstance(fk, dict) and fk:
            base = {}
            for k, arr in fk.items():
                try:
                    base[k] = (arr or [{}])[0].get("value", None)
                except Exception:
                    pass
        else:
            base = dict(parent_hdr_like)
    else:
        base = {}

    # ------------------------------------------------------------------
    # Detect "already cropped" headers to avoid double-shifting CRPIX.
    # ------------------------------------------------------------------
    nax1 = base.get("NAXIS1")
    nax2 = base.get("NAXIS2")

    if isinstance(nax1, (int, float)) and isinstance(nax2, (int, float)):
        n1 = int(nax1)
        n2 = int(nax2)

        # Case A: parent already has same size as requested ROI,
        # but x,y are non-zero → this smells like ROI-of-ROI.
        if w == n1 and h == n2 and (x != 0 or y != 0):

            base["NAXIS1"], base["NAXIS2"] = n1, n2
            base.setdefault("CROPX", 0)
            base.setdefault("CROPY", 0)
            base.setdefault("SASKIND", "ROI-CROP")
            return base

        # Case B: ROI clearly outside parent dimensions → also treat as
        # "already cropped, don't touch CRPIX".
        if x >= n1 or y >= n2 or x + w > n1 or y + h > n2:

            base["NAXIS1"], base["NAXIS2"] = n1, n2
            base.setdefault("CROPX", 0)
            base.setdefault("CROPY", 0)
            base.setdefault("SASKIND", "ROI-CROP")
            return base

    # ------------------------------------------------------------------
    # Normal behavior: real crop relative to full-frame parent.
    # ------------------------------------------------------------------
    c1, c2 = base.get("CRPIX1"), base.get("CRPIX2")
    if isinstance(c1, (int, float)) and isinstance(c2, (int, float)):
        base["CRPIX1"] = float(c1) - float(x)
        base["CRPIX2"] = float(c2) - float(y)

    base["NAXIS1"], base["NAXIS2"] = w, h
    base["CROPX"], base["CROPY"] = x, y
    base["SASKIND"] = "ROI-CROP"
    return base

def _dnd_dbg_dump_state(tag: str, state: dict):
    try:
        import json
        # Keep it readable but complete
        keys = sorted(state.keys())
        print(f"\n[DNDDBG:{tag}] keys={keys}")
        for k in keys:
            v = state.get(k)
            # avoid huge blobs
            if isinstance(v, (dict, list)) and len(str(v)) > 400:
                print(f"  {k} = <{type(v).__name__} len={len(v)}>")
            else:
                print(f"  {k} = {v!r}")
        # show json size
        raw = json.dumps(state).encode("utf-8")
        print(f"[DNDDBG:{tag}] json_bytes={len(raw)} head={raw[:120]!r}")
    except Exception as e:
        print(f"[DNDDBG:{tag}] dump failed: {e}")

_DEBUG_DND_DUP = False

def _strip_ext_if_filename(s: str) -> str:
    s = (s or "").strip()
    if not s:
        return s
    base, ext = os.path.splitext(s)
    if ext and len(ext) <= 10:
        return base
    return s

# Add this class near the top of subwindow.py, before ImageSubWindow

class _LoupeWindow(QWidget):
    """
    A small always-on-top frameless window that shows a zoomed-in
    patch of the image around the cursor during Space+drag readout.
    Follows the mouse, offset so it doesn't obscure the cursor.
    """
    SIZE    = 161          # zoom-area size in pixels (square)
    PATCH   = 17           # source image pixels to sample (16×16)
    OFFSET  = (20, 20)     # px offset from cursor so it doesn't cover the probe point
    INFO_PAD   = 5         # inner padding of the readout strip (px)
    INFO_MAXPT = 10        # starting / maximum readout font point size
    INFO_MINPT = 7         # smallest we'll shrink the readout font to

    def __init__(self, parent=None, size=None, patch=None,
                 info_max_pt=None, show_info=True):
        # Resolve per-instance config (usually from QSettings). SIZE and PATCH
        # must be ODD so the crosshair bisects the centre pixel block, so we
        # coerce rather than assert — a stray even value shouldn't crash a probe.
        sz = int(size) if size else self.SIZE
        pt = int(patch) if patch else self.PATCH
        if sz % 2 == 0:
            sz += 1
        if pt % 2 == 0:
            pt += 1
        # instance attributes shadow the class defaults; all internal refs use self.*
        self.SIZE = max(41, sz)
        self.PATCH = max(3, pt)
        if info_max_pt:
            self.INFO_MAXPT = max(self.INFO_MINPT, int(info_max_pt))
        self._show_info = bool(show_info)

        super().__init__(parent, 
            Qt.WindowType.Tool |
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.WindowTransparentForInput
        )
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self._pixmap: QPixmap | None = None
        # optional compact readout strip (RGB / K + alpha,delta) beneath the zoom
        self._info_lines: list[str] = []
        self._info_h: int = 0
        self._info_font_cached = None
        self.setFixedSize(self.SIZE, self.SIZE)

    def set_patch(self, arr: np.ndarray):
        """
        arr: small H×W or H×W×3 float32 crop from the source image (already
             normalized 0-1 or uint8). We scale it up to fill the window.
        """
        if arr is None or arr.size == 0:
            self._pixmap = None
            self.update()
            return

        # normalize to uint8
        if arr.dtype == np.uint8:
            buf8 = arr
        elif arr.dtype == np.uint16:
            buf8 = (arr.astype(np.float32) / 65535.0 * 255.0).clip(0, 255).astype(np.uint8)
        else:
            buf8 = (np.clip(arr.astype(np.float32, copy=False), 0.0, 1.0) * 255.0).astype(np.uint8)

        # force H×W×3
        if buf8.ndim == 2:
            buf8 = np.stack([buf8] * 3, axis=-1)
        elif buf8.ndim == 3 and buf8.shape[2] == 1:
            buf8 = np.repeat(buf8, 3, axis=2)
        elif buf8.ndim == 3 and buf8.shape[2] > 3:
            buf8 = buf8[..., :3]

        buf8 = np.ascontiguousarray(buf8)
        h, w, _ = buf8.shape
        qimg = QImage(buf8.tobytes(), w, h, w * 3, QImage.Format.Format_RGB888)

        # scale up with nearest-neighbour so individual pixels are crisp blocks
        pm = QPixmap.fromImage(qimg)
        self._pixmap = pm.scaled(
            self.SIZE, self.SIZE,
            Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.FastTransformation,   # nearest-neighbour = crisp pixels
        )
        self.update()

    def set_readout(self, lines):
        """Set the compact info lines shown beneath the zoom (RGB/K + alpha,delta).

        Pass an empty list / None to hide the strip. The window grows
        downward to fit the text so the zoomed pixels are never covered.
        """
        self._info_lines = [str(x) for x in (lines or []) if str(x).strip()]
        self._recompute_info()
        self.setFixedSize(self.SIZE, self.SIZE + self._info_h)
        self.update()

    def _info_font(self):
        """Pick a monospace font, shrinking until the widest line fits."""
        from PyQt6.QtGui import QFont, QFontMetrics, QFontDatabase
        avail = self.SIZE - 2 * self.INFO_PAD
        # platform's native fixed-pitch font (Consolas/Menlo/DejaVu Sans Mono/...)
        f = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        f.setStyleHint(QFont.StyleHint.Monospace)
        f.setFixedPitch(True)
        for pt in range(self.INFO_MAXPT, self.INFO_MINPT - 1, -1):
            f.setPointSize(pt)
            fm = QFontMetrics(f)
            widest = max((fm.horizontalAdvance(t) for t in self._info_lines), default=0)
            if widest <= avail:
                break
        return f

    def _recompute_info(self):
        if not self._info_lines:
            self._info_h = 0
            self._info_font_cached = None
            return
        from PyQt6.QtGui import QFontMetrics
        f = self._info_font()
        self._info_font_cached = f
        fm = QFontMetrics(f)
        self._info_h = 2 * self.INFO_PAD + fm.height() * len(self._info_lines)

    def move_to_cursor(self, global_pos: QPoint):
        ox, oy = self.OFFSET
        w = self.width()
        h = self.height()
        x = global_pos.x() + ox
        y = global_pos.y() + oy

        # keep on screen
        screen = QApplication.screenAt(global_pos)
        if screen is not None:
            sg = screen.geometry()
            if x + w > sg.right():
                x = global_pos.x() - w - ox
            if y + h > sg.bottom():
                y = global_pos.y() - h - oy

        self.move(x, y)

    def paintEvent(self, ev):
        from PyQt6.QtGui import QPainter, QPen, QColor, QFontMetrics

        # Guard: don't attempt to paint if the widget isn't ready
        if self.width() <= 0 or self.height() <= 0:
            return

        p = QPainter(self)
        if not p.isActive():          # paint device returned engine==0
            return

        # ---- zoom area (top SIZE x SIZE) ----
        if self._pixmap is None:
            p.fillRect(QRect(0, 0, self.SIZE, self.SIZE), QColor(20, 20, 30))
        else:
            p.drawPixmap(0, 0, self._pixmap)

            cx = cy = self.SIZE // 2
            p.setPen(QPen(QColor(255, 0, 0, 200), 1))
            p.drawLine(cx, 0, cx, self.SIZE)
            p.drawLine(0, cy, self.SIZE, cy)

        # ---- info strip (RGB / K + alpha,delta), below the zoom ----
        if self._info_lines and self._info_h > 0:
            strip = QRect(0, self.SIZE, self.width(), self._info_h)
            p.fillRect(strip, QColor(0, 0, 0, 205))

            f = self._info_font_cached or self._info_font()
            p.setFont(f)
            fm = QFontMetrics(f)
            lh = fm.height()
            ty = self.SIZE + self.INFO_PAD + fm.ascent()
            p.setPen(QPen(QColor(235, 235, 235)))
            for line in self._info_lines:
                p.drawText(self.INFO_PAD, ty, line)
                ty += lh

        # ---- outer border around the whole window ----
        p.setPen(QPen(QColor(255, 255, 255, 120), 1))
        p.drawRect(0, 0, self.width() - 1, self.height() - 1)

        p.end()

class ImageSubWindow(QWidget):
    aboutToClose = pyqtSignal(object)
    autostretchChanged = pyqtSignal(bool)
    requestDuplicate = pyqtSignal(object)  # document
    layers_changed = pyqtSignal() 
    # Emitted when a source/mask document feeding this view's layers changes
    # (i.e. an edit to one of the views a layer references). Lets external
    # consumers such as the Layers dock preview recomposite on the spot.
    layer_sources_changed = pyqtSignal()

    viewTitleChanged = pyqtSignal(object, str)

    viewTransformChanged = pyqtSignal(float, int, int)
    _registry = weakref.WeakValueDictionary()
    resized = pyqtSignal() 
    replayOnBaseRequested = pyqtSignal(object)


    def __init__(self, document, parent=None):
        super().__init__(parent)
        self._base_document = None
        self.document = document
        self._last_title_for_emit = None
        self._docman = None
        self._docman_base_for_signal = None
        # ─────────────────────────────────────────────────────────
        # View / render state
        # ─────────────────────────────────────────────────────────
        self._min_scale = 0.02
        self._max_scale = 5.00  # 500%
        self.scale = 0.25
        self._dragging = False
        self._drag_start = QPoint()
        self._autostretch_linked = QSettings().value("display/stretch_linked", False, type=bool)
        self.autostretch_enabled = False
        self.autostretch_target = 0.25
        self.autostretch_sigma = 3.0
        self.autostretch_profile = "normal"
        self._autostretch_continuous = QSettings().value("display/autostretch_continuous", True, type=bool)
        self._autostretch_lut_cache = None
        self._autostretch_cache_key = None    
        self.show_mask_overlay = False
        self._mask_overlay_alpha = 0.5   # 0..1
        self._mask_overlay_invert = True
        self._layers: list[ImageLayer] = []
        self.layers_changed.connect(lambda: None)
        self._display_override: np.ndarray | None = None
        self._readout_hint_shown = False
        self._link_emit_timer = QTimer(self)
        self._link_emit_timer.setSingleShot(True)
        self._link_emit_timer.setInterval(100)  # tweak 120–250ms to taste
        self._link_emit_timer.timeout.connect(self._emit_view_transform_now)
        self._suppress_link_emit = False  # guard while applying remote updates      
        self._no_black_clip = QSettings().value("display/no_black_clip", False, type=bool)

        self._pan_live = False
        self._linked_views = weakref.WeakSet()
        ImageSubWindow._registry[id(self)] = self
        self._link_badge_on = False
        s = getattr(self, "_settings", None) or QSettings()
        self._settings = s
        self._smooth_zoom = s.value("display/smooth_zoom_settle", True, type=bool)



        # whenever we move/zoom, relay to linked peers
        self.viewTransformChanged.connect(self._relay_to_linked)
        # pixel readout live-probe state
        self._space_down = False
        self._readout_dragging = False
        self._loupe: _LoupeWindow | None = None
        # Pinch gesture state (macOS trackpad)
        self._gesture_zoom_start = None
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        # Title (doc/view) sync
        self._view_title_override = None
        self.document.changed.connect(self._sync_host_title)
        self._sync_host_title()
        self.document.changed.connect(self._refresh_local_undo_buttons)

        # Cached display buffer — viewport-sized, never a full-res 8-bit copy
        self._buf8 = None         # unused; kept so loupe falls back to document.image
        self._qimg_src = None     # QImage at display size
        self._pm_src = None
        self._pm_src_scale = None

        # Keep mask visuals in sync when doc changes
        self.document.changed.connect(self._on_doc_mask_changed)
        self.document.changed.connect(self._update_replay_button)
        # ─────────────────────────────────────────────────────────
        # Preview tabs state
        # ─────────────────────────────────────────────────────────
        self._tabs: QTabWidget | None = None
        self._previews: list[dict] = []  # {"id": int, "name": str, "roi": (x,y,w,h), "arr": np.ndarray}
        self._active_source_kind = "full"  # "full" | "preview"
        self._active_preview_id: int | None = None
        self._next_preview_id = 1

        # Rubber-band / selection for previews
        self._preview_select_mode = False
        self._rubber: QRubberBand | None = None
        self._rubber_origin: QPoint | None = None

        # ─────────────────────────────────────────────────────────
        # UI construction
        # ─────────────────────────────────────────────────────────
        lyt = QVBoxLayout(self)

        # Top row: drag-tab + Preview button
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        self._drag_tab = _DragTab(self)
        row.addWidget(self._drag_tab, 0, Qt.AlignmentFlag.AlignLeft)

        self._preview_btn = QToolButton(self)
        self._preview_btn.setText("⟂")  # crosshair glyph
        self._preview_btn.setToolTip(self.tr("Create Preview: click, then drag on the image to define a preview rectangle."))
        self._preview_btn.setCheckable(True)
        self._preview_btn.clicked.connect(self._toggle_preview_select_mode)
        row.addWidget(self._preview_btn, 0, Qt.AlignmentFlag.AlignLeft)
        # — Undo / Redo just for this subwindow —
        self._btn_undo = QToolButton(self)
        self._btn_undo.setText("↶")  # or use an icon
        self._btn_undo.setToolTip(self.tr("Undo (this view)"))
        self._btn_undo.setEnabled(False)
        self._btn_undo.clicked.connect(self._on_local_undo)
        row.addWidget(self._btn_undo, 0, Qt.AlignmentFlag.AlignLeft)

        self._btn_redo = QToolButton(self)
        self._btn_redo.setText("↷")
        self._btn_redo.setToolTip(self.tr("Redo (this view)"))
        self._btn_redo.setEnabled(False)
        self._btn_redo.clicked.connect(self._on_local_redo)
        row.addWidget(self._btn_redo, 0, Qt.AlignmentFlag.AlignLeft)

        self._btn_replay_main = QToolButton(self)
        self._btn_replay_main.setText("⟳")  # pick any glyph you like
        self._btn_replay_main.setToolTip(self.tr(
            "Click: replay the last action on the base image.\n"
            "Arrow: pick a specific past action to replay on the base image."
        ))
        self._btn_replay_main.setEnabled(False)  # enabled only when preview + history

        # Left-click = your existing 'replay last on base'
        self._btn_replay_main.clicked.connect(self._on_replay_last_clicked)

        # NEW: dropdown menu listing all replayable actions
        self._replay_menu = QMenu(self)
        self._btn_replay_main.setMenu(self._replay_menu)
        self._btn_replay_main.setPopupMode(
            QToolButton.ToolButtonPopupMode.MenuButtonPopup
        )

        row.addWidget(self._btn_replay_main, 0, Qt.AlignmentFlag.AlignLeft)


        # ── NEW: WCS grid toggle ─────────────────────────────────────────
        self._btn_wcs = QToolButton(self)
        self._btn_wcs.setText("⌗")
        self._btn_wcs.setToolTip(self.tr("Toggle WCS grid overlay (if WCS exists)"))
        self._btn_wcs.setCheckable(True)

        # Start OFF on every new view, regardless of WCS presence or past sessions
        self._show_wcs_grid = False
        self._btn_wcs.setChecked(False)

        self._btn_wcs.toggled.connect(self._on_toggle_wcs_grid)
        row.addWidget(self._btn_wcs, 0, Qt.AlignmentFlag.AlignLeft)
        # ─────────────────────────────────────────────────────────────────

        row.addStretch(1)

        self._zoom_label = QLabel("25%")
        self._zoom_label.setFixedWidth(52)
        self._zoom_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self._zoom_label.setStyleSheet("color: rgba(255,255,255,0.55); font-size: 11px;")
        self._zoom_label.setToolTip("Current zoom level")
        row.addWidget(self._zoom_label, 0, Qt.AlignmentFlag.AlignRight)

        # ---- Inline view title (shown when the MDI subwindow is maximized) ----
        self._inline_title = QLabel(self)
        self._inline_title.setText("")
        self._inline_title.setToolTip(self.tr("Active view"))
        self._inline_title.setVisible(False)
        self._inline_title.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self._inline_title.setStyleSheet("""
            QLabel {
                padding-left: 8px;
                padding-right: 6px;
                font-size: 11px;
                color: rgba(255,255,255,0.80);
            }
        """)
        self._inline_title.setSizePolicy(
            self._inline_title.sizePolicy().horizontalPolicy(),
            self._inline_title.sizePolicy().verticalPolicy(),
        )

        # Push everything after this to the far right
        row.addStretch(1)
        row.addWidget(self._inline_title, 0, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight)

        # (optional) tiny spacing to the edge
        row.addSpacing(6)

        row.addStretch(1)
        row.addWidget(make_help_button("image_view", self), 0, Qt.AlignmentFlag.AlignRight)
        lyt.addLayout(row)

        # QTabWidget that hosts "Full" (real viewer) + any Preview tabs (placeholder widgets)
        self._tabs = QTabWidget(self)
        self._tabs.setTabsClosable(True)
        self._tabs.setDocumentMode(True)
        self._tabs.setMovable(True)

        # Build the default "Full" tab, which contains the ONE real viewer (scroll+label)
        full_host = QWidget(self)
        full_v = QVBoxLayout(full_host)
        full_v.setContentsMargins(0, 0, 0, 0)

        self.scroll = QScrollArea(full_host)
        self.scroll.setWidgetResizable(False)
        self.scroll.setAlignment(Qt.AlignmentFlag.AlignCenter)        
        # Viewport/tiled canvas is the DEFAULT display path.
        #
        # The QLabel path presents by scaling the whole source pixmap to
        # src * scale, so its memory grows as the square of the zoom. Measured
        # on a 4436x4377 frame: 82 MB at 100%, 315 MB at 200%, 704 MB at 300%,
        # 1946 MB at 500% -- the 25x the user sees at 5x zoom. The tiled canvas
        # reports the same full size to the scroll area (identical scrollbar
        # ranges) but rasterizes only the exposed rect from source-resolution
        # tiles, so it measured a flat 82 MB at every one of those zooms.
        #
        # Output is pixel-identical: markers at known source pixels land at the
        # same widget coordinates in both paths, with the same values and the
        # same nearest-neighbour block sizes, at 100/200/400%.
        #
        # Set display/viewport_canvas = False (or SASPRO_VIEWPORT_CANVAS=0) to
        # go back to the whole-pixmap path.
        try:
            from PyQt6.QtCore import QSettings as _QSettings
            import os as _os
            _env = _os.environ.get("SASPRO_VIEWPORT_CANVAS", "").strip().lower()
            if _env in ("1", "true", "yes", "on"):
                self._use_viewport_canvas = True
            elif _env in ("0", "false", "no", "off"):
                self._use_viewport_canvas = False
            else:
                self._use_viewport_canvas = bool(
                    _QSettings().value("display/viewport_canvas", True, type=bool)
                )
        except Exception:
            self._use_viewport_canvas = True

        if self._use_viewport_canvas:
            self.label = TiledImageCanvas(self, alignment=Qt.AlignmentFlag.AlignCenter)
        else:
            self.label = QLabel(alignment=Qt.AlignmentFlag.AlignCenter)
        self.scroll.setWidget(self.label)
        self.scroll.viewport().setMouseTracking(True)
        self.label.setMouseTracking(True)        
        full_v.addWidget(self.scroll)

        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()
        for bar in (hbar, vbar):
            bar.valueChanged.connect(self._on_scroll_changed)
            bar.sliderMoved.connect(self._on_scroll_changed)
            bar.actionTriggered.connect(self._on_scroll_changed)

        # IMPORTANT: add the tab BEFORE connecting signals so currentChanged can't fire early
        self._full_tab_idx = self._tabs.addTab(full_host, self.tr("Full"))
        self._full_host = full_host
        self._tabs.tabBar().setVisible(False)  # hidden until a preview exists
        lyt.addWidget(self._tabs)

        # Now it’s safe to connect
        self._tabs.tabCloseRequested.connect(self._on_tab_close_requested)
        self._tabs.currentChanged.connect(self._on_tab_changed)
        self._tabs.currentChanged.connect(lambda _=None: self._refresh_local_undo_buttons())

        # DnD + event filters for the single viewer
        self.setAcceptDrops(True)
        self.scroll.viewport().installEventFilter(self)
        self.label.installEventFilter(self)

        # Context menu + shortcuts
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_ctx_menu)
        QShortcut(QKeySequence("F2"), self, activated=self._rename_document)
        QShortcut(QKeySequence("F3"), self, activated=self._rename_document)
        #QShortcut(QKeySequence("A"), self, activated=self.toggle_autostretch)
        QShortcut(QKeySequence("Ctrl+Space"), self, activated=self.toggle_autostretch)
        QShortcut(QKeySequence("Alt+Shift+A"), self, activated=self.toggle_autostretch)
        QShortcut(QKeySequence("Ctrl+K"), self, activated=self.toggle_mask_overlay)

        # Re-render when the document changes
        self.document.changed.connect(self._on_document_changed)
        self._render(rebuild=True)
        QTimer.singleShot(0, self._maybe_announce_readout_help)
        self._refresh_local_undo_buttons()
        self._update_replay_button()

        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()

        for bar in (hbar, vbar):
            bar.valueChanged.connect(self._schedule_emit_view_transform)
            bar.sliderMoved.connect(lambda _=None: self._schedule_emit_view_transform())
            bar.actionTriggered.connect(lambda _=None: self._schedule_emit_view_transform())

        # Mask/title adornments
        self._mask_dot_enabled = self._active_mask_array() is not None

        self._rebuild_title()

        # Track docs used by layer stack (if any)
        self._watched_docs = set()
        self._history_doc = None
        self._install_history_watchers()

        QTimer.singleShot(0, self._install_mdi_state_watch)
        QTimer.singleShot(0, self._update_inline_title_and_buttons)
        QTimer.singleShot(0, self._update_zoom_label)


    def _on_document_changed(self):
        """
        Primary document-changed handler for this view.

        This should be the main place that triggers a redraw for normal edits.
        """
        self._render(rebuild=True)

    def reload_display_settings(self):
        s = getattr(self, "_settings", None) or QSettings()
        self._settings = s

        # re-read any settings that are cached in the view
        self._smooth_zoom = s.value("display/smooth_zoom_settle", True, type=bool)
        self._autostretch_linked = s.value("display/stretch_linked", False, type=bool)
        self._autostretch_linked = s.value("display/stretch_linked", False, type=bool)
        self._autostretch_continuous = s.value("display/autostretch_continuous", True, type=bool)
        # if you cache bg opacity or other display keys here, re-read them too
        # self._bg_opacity = s.value("display/bg_opacity", 50, type=int) / 100.0

        # force redraw. The canvas is a child with its own paintEvent, and it
        # reads _smooth_zoom from there, so updating only the subwindow leaves
        # the new setting unpainted until something else happens to dirty it.
        try:
            self.label.update()
        except Exception:
            pass
        self.update()

    # ----- link drag payload -----
    def _start_link_drag(self):
        """
        Alt + drag from ⧉: start a 'link these two views' drag.
        """
        payload = {
            "source_view_id": id(self),
        }
        # identity hints (not strictly required, but nice to have)
        try:
            payload.update(self._drag_identity_fields())
        except Exception:
            pass

        md = QMimeData()
        md.setData(MIME_LINKVIEW, QByteArray(json.dumps(payload).encode("utf-8")))
        drag = QDrag(self)
        drag.setMimeData(md)
        if self.label.pixmap():
            drag.setPixmap(self.label.pixmap().scaled(
                64, 64, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
            drag.setHotSpot(QPoint(16, 16))
        drag.exec(Qt.DropAction.CopyAction)

    # ----- link management -----
    def link_to(self, other: "ImageSubWindow"):
        if other is self or other in self._linked_views:
            return

        # Gather the full sets (including each endpoint)
        a_group = set(self._linked_views) | {self}
        b_group = set(other._linked_views) | {other}
        merged = a_group | b_group

        # Clear old badges so we can reapply cleanly
        for v in merged:
            try:
                v._linked_views.discard(v)  # no-op safety
            except Exception:
                pass

        # Fully connect everyone to everyone
        for v in merged:
            v._linked_views.update(merged - {v})
            try:
                v._set_link_badge(True)
            except Exception:
                pass

        # Snap everyone to the initiator’s transform immediately
        try:
            s = float(self.scale)
            fx, fy = self._viewport_center_fraction()
            dims = self._link_ref_dims()   # SASPRO_RELATIVE_LINK
            for peer in merged - {self}:
                peer.apply_linked_center(s, fx, fy, from_link=True,
                                         src_dims=dims)
        except Exception:
            pass


    def unlink_from(self, other: "ImageSubWindow"):
        if other in self._linked_views:
            self._linked_views.discard(other)
            other._linked_views.discard(self)
        # clear badge if both are now free
        if not self._linked_views:
            self._set_link_badge(False)
        if not other._linked_views:
            other._set_link_badge(False)

    def unlink_all(self):
        peers = list(self._linked_views)
        for p in peers:
            self.unlink_from(p)

    def _relay_to_linked(self, scale: float, h: int, v: int):
        """
        When this view pans/zooms, nudge all linked peers. Guarded to avoid loops.

        Resolution-independent: forward the image point currently under THIS
        view's viewport centre as a fraction of the (scaled) image, plus the
        scale. Each peer re-derives its own scrollbars from that fraction using
        its own viewport, so linked windows no longer have to share a size.

        The zoom is relative too: this view's pixel dimensions ride along, so
        a peer at a different sampling (1x vs 2x drizzle) derives the zoom
        that puts the same field on screen at the same size.
        """
        try:
            fx, fy = self._viewport_center_fraction()
        except Exception:
            return
        s = float(scale)
        # SASPRO_RELATIVE_LINK: our own pixel dimensions travel with the
        # transform so each peer can derive its own zoom from the ratio.
        dims = self._link_ref_dims()
        for peer in list(self._linked_views):
            try:
                peer.apply_linked_center(s, fx, fy, from_link=True,
                                         src_dims=dims)
            except Exception:
                pass

    def _viewport_center_fraction(self):
        """(fx, fy) in [0, 1]: the image fraction under this view's viewport
        centre. Uses Qt's label->viewport mapping, so it is correct whether the
        image is larger than the viewport (scrollbars active) or smaller (centred
        by AlignCenter), and whether or not the 8192 render cap is in force
        (fractions are relative to this view's own label)."""
        vp = self.scroll.viewport()
        lbl = self.label
        p = lbl.mapFrom(vp, QPoint(vp.width() // 2, vp.height() // 2))
        lw = max(1, lbl.width())
        lh = max(1, lbl.height())
        fx = min(1.0, max(0.0, p.x() / float(lw)))
        fy = min(1.0, max(0.0, p.y() / float(lh)))
        return float(fx), float(fy)

    # ----- relative (field-matched) link helpers -----  SASPRO_RELATIVE_LINK
    def _link_ref_dims(self):
        """(W, H) in image pixels of whatever this view is currently showing -
        preview ROI, display override, or the document image. This is the frame
        of reference that linked-view fractions and zoom ratios are expressed
        against. None when nothing is loaded."""
        try:
            arr = self._current_display_source()
            if arr is None:
                return None
            shp = np.asarray(arr).shape
            if len(shp) < 2:
                return None
            h, w = int(shp[0]), int(shp[1])
            if w <= 0 or h <= 0:
                return None
            return w, h
        except Exception:
            return None

    def _link_scale_ratio(self, src_dims) -> float:
        """Factor converting a sender's zoom into this view's zoom so that both
        show the same FIELD at the same on-screen size.

        self.scale is screen px per image px and the label is sized to
        src * scale, so field magnification is scale * (image_width /
        field_width). Matching two views therefore means

            scale_self * W_self == scale_src * W_src   ->   ratio = W_src/W_self

        A 2x drizzle (twice the pixels) driving a 1x peer puts that peer at
        twice the zoom, which is what makes the two look identical.

        Uses the geometric mean of the width and height ratios: identical to the
        width ratio whenever the two images share an aspect - true for drizzle
        pairs of one stack - and a sane compromise when they do not. Returns
        1.0 when either side's dimensions are unknown, which reproduces the old
        absolute-zoom behaviour.
        """
        try:
            if not src_dims:
                return 1.0
            sw, sh = int(src_dims[0]), int(src_dims[1])
            own = self._link_ref_dims()
            if not own or sw <= 0 or sh <= 0:
                return 1.0
            ow, oh = int(own[0]), int(own[1])
            if ow <= 0 or oh <= 0:
                return 1.0
            r = math.sqrt((sw / float(ow)) * (sh / float(oh)))
            if not math.isfinite(r) or r <= 0.0:
                return 1.0
            return float(r)
        except Exception:
            return 1.0

    def apply_linked_center(self, scale, fx, fy, from_link=True,
                            src_dims=None):
        """Relative linked-view apply: show the same FIELD as the sender, at
        the same on-screen size, centred on the same fraction of the image.

        (fx, fy) is the sender's viewport centre as a fraction of ITS image,
        so pan is resolution-independent already - the 1x and 2x drizzle of
        one stack share fractions. src_dims is the sender's (W, H) in image
        pixels; when supplied, *scale* is converted into this view's own zoom
        via _link_scale_ratio() rather than copied verbatim. Omit it to get
        the old absolute-zoom behaviour.
        """
        self._suppress_link_emit = True
        try:
            # SASPRO_RELATIVE_LINK: convert the sender's zoom into ours.
            ratio = self._link_scale_ratio(src_dims)
            scale = float(scale) * ratio
            # A ratio link legitimately drives a peer past its own ceiling: a
            # 1x matching a 2x sitting at 5.0 has to reach 10.0. The clamp
            # bounds how far the FIELD may be magnified, so scale the bound by
            # the ratio too - otherwise the pair silently drifts apart at high
            # zoom, which is the bug this patch exists to remove. Costs nothing:
            # above 1.0 _render() upsamples a 1:1 pixmap (build_scale =
            # min(1.0, scale)) and the 8192-per-side cap still bounds memory.
            _lo = self._min_scale * min(1.0, ratio)
            _hi = self._max_scale * max(1.0, ratio)
            scale = float(max(_lo, min(scale, _hi)))
            if abs(scale - self.scale) > 1e-9:
                self.scale = scale
                self._render(rebuild=False)   # fast present; resizes label synchronously
                self._update_zoom_label()
                self._request_zoom_redraw()

            vp = self.scroll.viewport()
            lbl = self.label
            lx = float(fx) * float(lbl.width())
            ly = float(fy) * float(lbl.height())

            hbar = self.scroll.horizontalScrollBar()
            vbar = self.scroll.verticalScrollBar()
            new_h = int(round(lx - vp.width() * 0.5))
            new_v = int(round(ly - vp.height() * 0.5))
            hbar.setValue(max(hbar.minimum(), min(new_h, hbar.maximum())))
            vbar.setValue(max(vbar.minimum(), min(new_v, vbar.maximum())))
        finally:
            self._suppress_link_emit = False

        if not from_link:
            self._schedule_emit_view_transform()

    def _set_link_badge(self, on: bool):
        self._link_badge_on = bool(on)
        self._rebuild_title()

    def _on_scroll_changed(self, *_):
        if self._suppress_link_emit:
            return
        # If we’re actively dragging, emit immediately for realtime follow
        if self._dragging or self._pan_live:
            self._emit_view_transform_now()
        else:
            self._schedule_emit_view_transform()

    def _current_transform(self):
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()
        return float(self.scale), int(hbar.value()), int(vbar.value())

    def _emit_view_transform(self):
        try:
            h = int(self.scroll.horizontalScrollBar().value())
            v = int(self.scroll.verticalScrollBar().value())
        except Exception:
            h = v = 0
        try:
            self.viewTransformChanged.emit(float(self.scale), h, v)
        except Exception:
            pass

    def _schedule_emit_view_transform(self):
        if self._suppress_link_emit:
            return
        # If we’re in a live pan, don’t debounce—emit now.
        if self._dragging or self._pan_live:
            self._emit_view_transform_now()
        else:
            self._link_emit_timer.start()

    def _emit_view_transform_now(self):
        if self._suppress_link_emit:
            return
        h = self.scroll.horizontalScrollBar().value()
        v = self.scroll.verticalScrollBar().value()
        try:
            self.viewTransformChanged.emit(float(self.scale), int(h), int(v))
        except Exception:
            pass

    # ------------------------------------------------------------
    # MDI maximize handling: show inline title + avoid duplicate buttons
    # ------------------------------------------------------------
    def _install_mdi_state_watch(self):
        sw = self._mdi_subwindow()
        if sw is None:
            return
        # Watch maximize/restore changes on the hosting QMdiSubWindow
        sw.installEventFilter(self)

    def _is_mdi_maximized(self) -> bool:
        sw = self._mdi_subwindow()
        if sw is None:
            return False
        try:
            return sw.isMaximized()
        except Exception:
            return False

    def _set_mdi_minmax_buttons_enabled(self, enabled: bool):
        return  # leave Qt default buttons alone

    def _current_view_title_for_inline(self) -> str:
        # Prefer your already-pretty title (strip decorations if needed).
        try:
            # If you have _current_view_title_for_drag already, reuse it:
            return self._current_view_title_for_drag()
        except Exception:
            pass
        try:
            return (self.windowTitle() or "").strip()
        except Exception:
            return ""

    def _update_inline_title_and_buttons(self):
        maximized = self._is_mdi_maximized()

        # Show inline title only when maximized (optional)
        try:
            self._inline_title.setVisible(maximized)
            if maximized:
                self._inline_title.setText(self._current_view_title_for_inline() or "Untitled")
        except Exception:
            pass

        # IMPORTANT: do NOT change QMdiSubWindow window flags.
        # Leaving them alone restores the default Qt "double button" behavior.

    #------ Replay helpers------
    def _update_replay_button(self):
        btn = getattr(self, "_btn_replay_main", None)
        if not btn:
            return

        try:
            has_preview = self.has_active_preview()
        except Exception:
            has_preview = False

        menu = getattr(self, "_replay_menu", None)
        if menu is not None:
            menu.clear()

        if not has_preview:
            btn.setEnabled(False)
            return

        roi_doc = None
        dm = getattr(self, "_docman", None)
        if dm is not None:
            try:
                roi_doc = dm.get_document_for_view(self)
            except Exception:
                roi_doc = None

        history = list(getattr(roi_doc, "_preview_commands", []) or [])

        if menu is not None:
            for idx, entry in enumerate(reversed(history)):
                real_index = len(history) - 1 - idx
                step = entry.get("step") or f"Step {real_index+1}"
                act = menu.addAction(step)
                act.triggered.connect(
                    lambda _chk=False, i=real_index: self._replay_history_index(i)
                )

        btn.setEnabled(bool(history))

    def _replay_history_index(self, index: int):
        mw = self._find_main_window()
        if mw is None:
            return

        roi_doc = None
        dm = getattr(self, "_docman", None)
        if dm is not None:
            try:
                roi_doc = dm.get_document_for_view(self)
            except Exception:
                roi_doc = None

        if roi_doc is None:
            return

        commands = getattr(roi_doc, "_preview_commands", [])
        if not (0 <= index < len(commands)):
            return

        entry = commands[index]

        # Find the matching entry in _headless_history by command_id + position
        # so we can restore _last_headless_command to exactly what it was
        command_id = entry.get("command_id")
        target_sw = self._mdi_subwindow()

        # Walk headless history to find the nth occurrence of this cid
        # (history entries are in the same order as _preview_commands)
        hist = getattr(mw, "_headless_history", []) or []
        
        # Count how many times this cid appears in preview_commands up to and including index
        occurrence = sum(
            1 for e in commands[:index + 1]
            if e.get("command_id") == command_id
        )
        
        # Find the nth matching entry in headless history
        found = None
        count = 0
        for h in hist:
            from setiastro.saspro.command_ids import normalize_command_id
            if normalize_command_id(str(h.get("command_id", ""))) == command_id:
                count += 1
                if count == occurrence:
                    found = h
                    break

        if found is not None:
            payload = {
                "command_id": found.get("command_id"),
                "preset": dict(found.get("preset") or {}),
            }
            print(f"[Replay] replaying '{entry.get('step')}' cid={command_id!r} "
                  f"via history entry, preset_keys={list(payload['preset'].keys())}")
            old = getattr(mw, "_last_headless_command", None)
            try:
                mw._last_headless_command = payload
                mw.replay_last_action_on_base(target_sw=target_sw)
            finally:
                mw._last_headless_command = old
        else:
            # Fallback: use whatever is in _last_headless_command if cid matches
            last = getattr(mw, "_last_headless_command", None) or {}
            from setiastro.saspro.command_ids import normalize_command_id
            if normalize_command_id(str(last.get("command_id", ""))) == command_id:
                print(f"[Replay] replaying '{entry.get('step')}' cid={command_id!r} "
                      f"via _last_headless_command fallback")
                mw.replay_last_action_on_base(target_sw=target_sw)
            else:
                print(f"[Replay] no matching history entry for cid={command_id!r}, skipping")

    def _on_replay_last_clicked(self):
        """
        User clicked the ⟳ button *main area* (not the arrow).

        This still does the old behavior:
        - Emit replayOnBaseRequested(view)
        - Main window then replays the *last* action on the base doc
          for this subwindow (via replay_last_action_on_base).
        """
        # DEBUG: log that the button actually fired
        try:
            roi = None
            if hasattr(self, "has_active_preview") and self.has_active_preview():
                try:
                    roi = self.current_preview_roi()
                except Exception:
                    roi = None
            print(
                f"[Replay] Button clicked in view id={id(self)}, "
                f"has_active_preview={self.has_active_preview() if hasattr(self, 'has_active_preview') else 'n/a'}, "
                f"roi={roi}"
            )
        except Exception:
            pass


        self.replayOnBaseRequested.emit(self)

    def _update_zoom_label(self):
        lbl = getattr(self, "_zoom_label", None)
        if lbl is None:
            return
        try:
            pct = int(round(self.scale * 100))
            lbl.setText(f"{pct}%")
        except Exception:
            pass

    def set_view_transform(self, scale, hval, vval, from_link=False):
        self._suppress_link_emit = True
        try:
            scale = float(max(self._min_scale, min(scale, self._max_scale)))

            scale_changed = (abs(scale - self.scale) > 1e-9)
            if scale_changed:
                self.scale = scale
                self._render(rebuild=False)
                self._update_zoom_label()
                self._request_zoom_redraw()

            hbar = self.scroll.horizontalScrollBar()
            vbar = self.scroll.verticalScrollBar()
            hv = int(hval); vv = int(vval)
            if hv != hbar.value():
                hbar.setValue(hv)
            if vv != vbar.value():
                vbar.setValue(vv)
        finally:
            self._suppress_link_emit = False

        if not from_link:
            self._schedule_emit_view_transform()


    def _on_toggle_wcs_grid(self, on: bool):
        self._show_wcs_grid = bool(on)
        QSettings().setValue("display/show_wcs_grid", self._show_wcs_grid)
        self._render(rebuild=True)  # repaint current frame



    def _install_history_watchers(self):
        # disconnect old history doc
        hd = getattr(self, "_history_doc", None)
        if hd is not None and hasattr(hd, "changed"):
            try:
                hd.changed.disconnect(self._on_history_doc_changed)
            except Exception:
                pass
            # in case older builds were wired directly:
            try:
                hd.changed.disconnect(self._refresh_local_undo_buttons)
            except Exception:
                pass

        # resolve new history doc (ROI when on Preview tab, else base)
        new_hd = self._resolve_history_doc()
        self._history_doc = new_hd

        # connect new
        if new_hd is not None and hasattr(new_hd, "changed"):
            try:
                new_hd.changed.connect(self._on_history_doc_changed)
            except Exception:
                pass

        # make the buttons correct right now
        self._refresh_local_undo_buttons()

    def _drag_identity_fields(self) -> dict:
        st = {}
        try:
            doc = getattr(self, "document", None)
            # Use base_document id if available — document may be a _DocProxy
            base = getattr(self, "base_document", None) or doc
            st["doc_ptr"] = id(base) if base is not None else None
            st["doc_uid"] = getattr(base, "uid", None) or getattr(doc, "uid", None)
            meta = getattr(base, "metadata", {}) or {}
            st["file_path"] = (meta.get("file_path") or "").strip()
            st["base_doc_uid"] = meta.get("base_doc_uid") or st["doc_uid"]
            st["source_kind"] = meta.get("source_kind") or "full"
        except Exception:
            pass

        st["source_view_title"] = self._current_view_title_for_drag()

        try:
            sw = self._mdi_subwindow()
            st["source_sw_title_raw"] = (sw.windowTitle() if sw is not None else "")
        except Exception:
            st["source_sw_title_raw"] = ""

        return st


    def _on_local_undo(self):
        doc = self._resolve_history_doc()
        if not doc or not hasattr(doc, "undo"):
            return
        try:
            doc.undo()
            # Do NOT manually emit changed or call _render() here.
            # ImageDocument.undo() already emits changed, and our existing
            # changed connections handle redraw + button refresh.
        except Exception:
            pass

    def _on_local_redo(self):
        doc = self._resolve_history_doc()
        if not doc or not hasattr(doc, "redo"):
            return
        try:
            doc.redo()
            # Do NOT manually emit changed or call _render() here.
            # ImageDocument.redo() already emits changed, and our existing
            # changed connections handle redraw + button refresh.
        except Exception:
            pass

    def _on_tab_close_requested(self, idx: int):
        # Prevent closing "Full"
        if idx == self._full_tab_idx:
            return
        wid = self._tabs.widget(idx)
        prev_id = getattr(wid, "_preview_id", None)

        # Remove model entry
        self._previews = [p for p in self._previews if p["id"] != prev_id]
        # If you closed the active one, fall back to full
        if self._active_preview_id == prev_id:
            self._active_source_kind = "full"
            self._active_preview_id = None
            self._render(True)

        self._tabs.removeTab(idx)
        wid.deleteLater()

        # Hide tabs if no more previews
        if not self._previews:
            self._tabs.tabBar().setVisible(False)

        self._update_replay_button()     

    def _on_tab_changed(self, idx: int):
        if not hasattr(self, "_full_tab_idx"):
            return
        if idx == self._full_tab_idx:
            self._active_source_kind = "full"
            self._active_preview_id = None
            host = getattr(self, "_full_host", None) or self._tabs.widget(idx)  # ← safe
        else:
            wid = self._tabs.widget(idx)
            self._active_source_kind = "preview"
            self._active_preview_id = getattr(wid, "_preview_id", None)
            host = wid

        if host is not None:
            self._move_view_into(host)
        self._install_history_watchers()
        self._render(True)
        self._refresh_local_undo_buttons()
        self._update_replay_button() 
        self._emit_view_transform() 
        mw = self._find_main_window()
        if mw is not None and getattr(mw, "_auto_fit_on_resize", False):
            try:
                mw._zoom_active_fit()
            except Exception:
                pass

    def _toggle_preview_select_mode(self, on: bool):
        self._preview_select_mode = bool(on)
        self._set_preview_cursor(self._preview_select_mode)
        if self._preview_select_mode:
            mw = self._find_main_window()
            if mw and hasattr(mw, "statusBar"):
                mw.statusBar().showMessage(self.tr("Preview mode: drag a rectangle on the image to create a preview."), 6000)
        else:
            self._cancel_rubber()

    def _cancel_rubber(self):
        if self._rubber is not None:
            self._rubber.hide()
            self._rubber.deleteLater()
            self._rubber = None
        self._rubber_origin = None
        self._preview_select_mode = False
        self._set_preview_cursor(False)
        if self._preview_btn.isChecked():
            self._preview_btn.setChecked(False)

    def _current_tab_host(self):
        # returns the QWidget inside the current tab
        return self._tabs.widget(self._tabs.currentIndex())

    def _move_view_into(self, host_widget: QWidget):
        """Reparent the single viewer (scroll+label) into host_widget's layout."""
        if self.scroll.parent() is host_widget:
            return
        # take it out of the old parent layout
        try:
            old_layout = self.scroll.parentWidget().layout()
            if old_layout:
                old_layout.removeWidget(self.scroll)
        except Exception:
            pass

        # ensure host has a VBox layout
        lay = host_widget.layout()
        if lay is None:
            from PyQt6.QtWidgets import QVBoxLayout
            lay = QVBoxLayout(host_widget)
            lay.setContentsMargins(0, 0, 0, 0)

        # insert viewer; kill any placeholder child labels if present
        try:
            kids = host_widget.findChildren(QLabel, options=Qt.FindChildOption.FindDirectChildrenOnly)
        except Exception:
            kids = host_widget.findChildren(QLabel)  # recursive fallback
        for ch in list(kids):
            if ch is not self.label:
                ch.deleteLater()

        self.scroll.setParent(host_widget)
        lay.addWidget(self.scroll)
        self.scroll.show()

    def _set_preview_cursor(self, active: bool):
        cur = Qt.CursorShape.CrossCursor if active else Qt.CursorShape.ArrowCursor
        for w in (self, getattr(self, "scroll", None) and self.scroll.viewport(), getattr(self, "label", None)):
            if not w:
                continue
            try:
                w.unsetCursor()          # clear any prior override
                w.setCursor(cur)         # then set desired cursor
            except Exception:
                pass


    def _maybe_announce_readout_help(self):
        """Show the readout hint only once automatically."""
        if self._readout_hint_shown:
            return
        self._announce_readout_help()
        self._readout_hint_shown = True        

    def _announce_readout_help(self):
        mw = self._find_main_window()
        if mw and hasattr(mw, "statusBar"):
            sb = mw.statusBar()
            if sb:
                sb.showMessage(self.tr("Press Space + Click/Drag to probe pixels (WCS shown if available)"), 8000)


      
    # Longest-side limit used while compositing a live preview. Full resolution
    # is always used for merges / non-preview applies.
    _LAYER_PREVIEW_MAX_DIM = 1100
    # When True, per-update timing (composite / upscale / render) is appended to
    # <temp>/sas_layers_profile.log. Set False to disable once diagnosed.
    _LAYER_PROFILE = False

    def apply_layer_stack(self, layers, *, preview: bool = False):
        if getattr(self, "_compositing", False):
            return
        self._compositing = True
        import time as _time
        _t0 = _time.perf_counter()
        _t1 = _t2 = _t0
        base = None
        try:
            base = self.document.image
            if layers:
                max_dim = self._LAYER_PREVIEW_MAX_DIM if preview else None
                # Apply base levels to base before compositing (display-only)
                base_for_comp = base
                base_levels = getattr(self, "_base_levels", None)
                if base_levels and base_levels.get("enabled", False) and base is not None:
                    from setiastro.saspro.layers import _apply_levels, _ensure_3c, _float01
                    base_for_comp = _apply_levels(
                        _ensure_3c(_float01(base)),
                        float(base_levels.get("black_point", 0.0)),
                        float(base_levels.get("white_point", 1.0)),
                        float(base_levels.get("midtones", 0.5)),
                    )
                comp = composite_stack(base_for_comp, layers, max_dim=max_dim)
                _t1 = _time.perf_counter()
                if preview:
                    _t2 = _time.perf_counter()
                    self._display_override = comp
                    self._render_layer_preview(comp)
                    self.layers_changed.emit()
                else:
                    if (comp is not None and base is not None
                            and comp.shape[:2] != base.shape[:2]):
                        comp = _resize_like(comp, base.shape[:2])
                    _t2 = _time.perf_counter()
                    self._display_override = comp
                    self.layers_changed.emit()
                    self._render(rebuild=True)
            else:
                # No layers — base levels still apply as display-only
                base_levels = getattr(self, "_base_levels", None)
                if base_levels and base_levels.get("enabled", False) and base is not None:
                    from setiastro.saspro.layers import _apply_levels, _ensure_3c, _float01
                    comp = _apply_levels(
                        _ensure_3c(_float01(base)),
                        float(base_levels.get("black_point", 0.0)),
                        float(base_levels.get("white_point", 1.0)),
                        float(base_levels.get("midtones", 0.5)),
                    )
                    _t1 = _t2 = _time.perf_counter()
                    self._display_override = comp
                    self.layers_changed.emit()
                    if preview:
                        self._render_layer_preview(comp)
                    else:
                        self._render(rebuild=True)
                else:
                    self._display_override = None
                    _t1 = _t2 = _time.perf_counter()
                    self.layers_changed.emit()
                    self._render(rebuild=True)
            _t3 = _time.perf_counter()
            if getattr(self, "_LAYER_PROFILE", False):
                try:
                    sh = None if base is None else tuple(int(x) for x in base.shape[:2])
                    _layer_profile_log(
                        f"{'preview' if preview else 'full   '}  "
                        f"composite={(_t1-_t0)*1000:7.1f}ms  "
                        f"upscale={(_t2-_t1)*1000:7.1f}ms  "
                        f"render={(_t3-_t2)*1000:7.1f}ms  "
                        f"total={(_t3-_t0)*1000:7.1f}ms  "
                        f"layers={len(layers)} base={sh}")
                except Exception:
                    pass
        except Exception as e:
            print("[ImageSubWindow] apply_layer_stack error:", e)
        finally:
            self._compositing = False

    def _render_layer_preview(self, comp_small):
        """Fast live preview render.

        Does autostretch + 8-bit conversion on the SMALL composite, builds a small
        QImage, then upscales only the resulting QPixmap (fast Qt scaling) to the
        full source size so the on-screen zoom (which is in source-pixel units via
        self.scale) stays consistent with the full-resolution document. This keeps
        all per-pixel work at preview resolution instead of 16MP per frame.
        """
        try:
            from PyQt6 import sip as _sip
            if _sip.isdeleted(self):
                return
            lbl = getattr(self, "label", None)
            if lbl is None or _sip.isdeleted(lbl):
                return
        except Exception:
            return

        base = getattr(self.document, "image", None)
        if base is None or comp_small is None:
            self._render(rebuild=True)
            return

        full_h, full_w = int(base.shape[0]), int(base.shape[1])
        arr = np.asarray(comp_small)
        if arr.ndim == 3 and arr.shape[2] == 1:
            arr = arr[..., 0]
        is_mono = (arr.ndim == 2)

        import time as _pt
        _ta = _pt.perf_counter()

        # ---- autostretch on the small array, reusing the cached LUT if present ----
        if self.autostretch_enabled:
            arr_f = arr.astype(np.float32, copy=False)
            try:
                mx = float(arr_f.max()) if arr_f.size else 1.0
            except Exception:
                mx = 1.0
            if mx > 5.0:
                arr_f = arr_f / mx
            lut = getattr(self, "_autostretch_lut_cache", None)
            try:
                if lut is not None:
                    vis = apply_autostretch_lut(
                        arr_f, lut,
                        linked=(not is_mono and self._autostretch_linked),
                    )
                else:
                    vis, lut2 = autostretch_with_lut(
                        arr_f,
                        target_median=self.autostretch_target,
                        sigma=self.autostretch_sigma,
                        linked=(not is_mono and self._autostretch_linked),
                        use_24bit=None,
                        no_black_clip=bool(getattr(self, "_no_black_clip", False)),
                    )
                    self._autostretch_lut_cache = lut2
            except Exception:
                vis = np.clip(arr_f, 0.0, 1.0)
        else:
            vis = arr

        # ---- to uint8 RGB (still at preview resolution) ----
        if vis.dtype == np.uint8:
            buf8 = vis
        else:
            buf8 = (np.clip(vis.astype(np.float32, copy=False), 0.0, 1.0) * 255.0).astype(np.uint8)
        if buf8.ndim == 2:
            buf8 = np.stack([buf8] * 3, axis=-1)
        elif buf8.ndim == 3 and buf8.shape[2] == 1:
            buf8 = np.repeat(buf8, 3, axis=2)
        elif buf8.ndim == 3 and buf8.shape[2] > 3:
            buf8 = buf8[..., :3]
        buf8 = np.ascontiguousarray(buf8)

        h, w, _c = buf8.shape
        _tb = _pt.perf_counter()
        try:
            qimg = QImage(buf8.tobytes(), w, h, 3 * w, QImage.Format.Format_RGB888)
            qimg = tag_qimage_with_working_color_space(qimg)
            pm_small = QPixmap.fromImage(qimg)
            _tc = _pt.perf_counter()
            # Scale straight from the small preview to the on-screen display size
            # (full_size * current zoom) in ONE step — never materialize a 16MP
            # intermediate pixmap, which is what made this path slow.
            scale = float(getattr(self, "scale", 1.0) or 1.0)
            sw = max(1, int(full_w * scale))
            sh = max(1, int(full_h * scale))
            pm_disp = pm_small.scaled(
                sw, sh,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.FastTransformation,
            )
        except Exception:
            self._render(rebuild=True)
            return

        # Keep the small pixmap as the source; the trailing full-resolution apply
        # restores a display-sized _pm_src once dragging stops.
        self._qimg_src = None
        self._pm_src = pm_small
        self._pm_src_scale = float(scale)
        self._pm_src_wcs = None
        self._buf8 = None
        self.label.setPixmap(pm_disp)
        self.label.resize(pm_disp.size())
        if getattr(self, "_LAYER_PROFILE", False):
            try:
                _td = _pt.perf_counter()
                _layer_profile_log(
                    f"  prev-detail  stretch+8bit={(_tb-_ta)*1000:6.1f}ms  "
                    f"toqimg={(_tc-_tb)*1000:6.1f}ms  "
                    f"scale+paint={(_td-_tc)*1000:6.1f}ms  "
                    f"small=({w}x{h}) disp=({sw}x{sh}) zoom={scale:.3f}")
            except Exception:
                pass

    def keyPressEvent(self, ev):
        if ev.key() == Qt.Key.Key_Space:
            # only the first time we enter probe mode
            if not self._space_down and not self._readout_hint_shown:
                self._announce_readout_help()
                self._readout_hint_shown = True
            self._space_down = True
            ev.accept()
            return
        super().keyPressEvent(ev)



    def keyReleaseEvent(self, ev):
        if ev.key() == Qt.Key.Key_Space:
            self._space_down = False
            # DO NOT stop _readout_dragging here – mouse release will do that
            ev.accept()
            return
        super().keyReleaseEvent(ev)

    def _update_loupe(self, xi: int, yi: int, vp_pos: QPoint, sample=None):
        if self._loupe is None:
            # Loupe geometry/behaviour is user-configurable (Preferences ->
            # Pixel Readout). Read once at creation; changing the settings
            # applies to views opened afterward, not live to this one.
            try:
                s = QSettings()
                self._loupe = _LoupeWindow(
                    size=s.value("loupe/size", 161, type=int),
                    patch=s.value("loupe/patch", 17, type=int),
                    info_max_pt=s.value("loupe/info_font_pt", 10, type=int),
                    show_info=s.value("loupe/show_info", True, type=bool),
                )
            except Exception:
                self._loupe = _LoupeWindow()

        doc = getattr(self, "document", None)
        if doc is None or doc.image is None:
            return

        # ALWAYS crop from the raw document image. The visual patch gets
        # stretched below (if autostretch is on); the readout values come
        # from `sample`, which was taken from doc.image directly by
        # _sample_image_at_viewport_pos, so numbers stay honest.
        arr = np.asarray(doc.image)

        if arr.ndim == 2:
            H, W = arr.shape
        elif arr.ndim == 3:
            H, W = arr.shape[:2]
        else:
            return

        ph = self._loupe.PATCH
        pw = self._loupe.PATCH
        half = ph // 2

        # clamp the crop window to image bounds
        y0 = max(0, yi - half)
        y1 = min(H, y0 + ph)        # fixed size from y0, not yi+half+1
        x0 = max(0, xi - half)
        x1 = min(W, x0 + pw)

        if y1 <= y0 or x1 <= x0:
            return

        patch = arr[y0:y1, x0:x1]
        actual_h = patch.shape[0]
        actual_w = patch.shape[1]

        # only pad if we're genuinely at an edge
        if actual_h < ph or actual_w < pw:
            if arr.ndim == 2:
                padded = np.zeros((ph, pw), dtype=arr.dtype)
            else:
                padded = np.zeros((ph, pw, arr.shape[2]), dtype=arr.dtype)

            # figure out where in the padded canvas this patch lands
            top_pad  = max(0, half - (yi - y0))
            left_pad = max(0, half - (xi - x0))

            # clamp paste region so it never overruns padded bounds
            paste_h = min(actual_h, ph - top_pad)
            paste_w = min(actual_w, pw - left_pad)

            if paste_h > 0 and paste_w > 0:
                padded[top_pad:top_pad + paste_h,
                       left_pad:left_pad + paste_w] = patch[:paste_h, :paste_w]
            patch = padded

        # Apply the viewport's current display stretch to the patch for
        # the visual preview only. Readout numbers below are unaffected.
        patch_display = patch
        if getattr(self, "autostretch_enabled", False):
            try:
                stretched = self.apply_current_display_stretch(patch)
                if stretched is not None:
                    patch_display = stretched
            except Exception:
                pass

        global_pos = self.scroll.viewport().mapToGlobal(vp_pos)
        self._loupe.set_patch(patch_display)
        # compact RGB + alpha/delta readout inside the loupe (if enabled)
        show_info = getattr(self._loupe, "_show_info", True)
        try:
            lines = (self._loupe_info_lines(xi, yi, sample)
                     if (sample is not None and show_info) else [])
        except Exception:
            lines = []
        self._loupe.set_readout(lines)
        self._loupe.move_to_cursor(global_pos)
        if not self._loupe.isVisible():                       # show only once patch is ready
            self._loupe.show()

    def _hide_loupe(self):
        if self._loupe is not None:
            self._loupe.hide()

    def _sample_image_at_viewport_pos(self, vp_pos: QPoint):
        if self.document is None or self.document.image is None:
            return None

        arr = np.asarray(self.document.image)

        if arr.ndim == 2:
            h, w = arr.shape
            channels = 1
        elif arr.ndim == 3:
            h, w, channels = arr.shape[:3]
        else:
            return None

        # Convert viewport pos → label pos
        p_label = self.label.mapFrom(self.scroll.viewport(), vp_pos)

        if isinstance(self.label, ViewportImageCanvas):
            # Canvas is full-sized and self-centring: no pixmap-centring offset.
            pm_w, pm_h = int(self.label.width()), int(self.label.height())
            off_x = off_y = 0
        else:
            pm = self.label.pixmap()
            if pm is None:
                return None
            # Account for centering offset when image is smaller than viewport
            pm_w = pm.width()
            pm_h = pm.height()
            lbl_w = self.label.width()
            lbl_h = self.label.height()
            off_x = max(0, (lbl_w - pm_w) // 2)
            off_y = max(0, (lbl_h - pm_h) // 2)

        px = p_label.x() - off_x
        py = p_label.y() - off_y

        # If outside the actual pixmap area, bail out
        if px < 0 or py < 0 or px >= pm_w or py >= pm_h:
            return None

        scale = max(self.scale, 1e-12)
        xi = int(round(px / scale))
        yi = int(round(py / scale))

        if xi < 0 or yi < 0 or xi >= w or yi >= h:
            return None

        if arr.ndim == 2 or channels == 1:
            val = float(arr[yi, xi]) if arr.ndim == 2 else float(arr[yi, xi, 0])
            return (xi, yi, {"mono": val})

        pix = arr[yi, xi]
        r = float(pix[0])
        g = float(pix[1]) if channels > 1 else r
        b = float(pix[2]) if channels > 2 else r
        return (xi, yi, {"r": r, "g": g, "b": b})

    def sizeHint(self) -> QSize:
        lbl = getattr(self, "image_label", None) or getattr(self, "label", None)
        sa  = getattr(self, "scroll_area", None) or self.findChild(QScrollArea)
        if isinstance(lbl, ViewportImageCanvas):
            fw_, fh_ = lbl.full_size()
            if fw_ > 1 and fh_ > 1:
                lm = lbl.contentsMargins()
                w = int(fw_) + lm.left() + lm.right()
                h = int(fh_) + lm.top() + lm.bottom()
                if sa:
                    fw = sa.frameWidth(); w += fw * 2; h += fw * 2
                m = self.contentsMargins()
                w += m.left() + m.right() + 2
                h += m.top()  + m.bottom() + 20
                return QSize(w + 2, h + 8)
            return super().sizeHint()
        if lbl and hasattr(lbl, "pixmap") and lbl.pixmap() and not lbl.pixmap().isNull():
            pm = lbl.pixmap()
            dpr  = pm.devicePixelRatioF() if hasattr(pm, "devicePixelRatioF") else 1.0
            pm_w = int(math.ceil(pm.width()  / dpr))
            pm_h = int(math.ceil(pm.height() / dpr))

            lm = lbl.contentsMargins()
            w = pm_w + lm.left() + lm.right()
            h = pm_h + lm.top()  + lm.bottom()

            if sa:
                fw = sa.frameWidth()
                w += fw * 2
                h += fw * 2

            m = self.contentsMargins()
            w += m.left() + m.right() + 2
            h += m.top()  + m.bottom() + 20

            return QSize(w + 2, h + 8)

        return super().sizeHint()

    def _on_layer_source_changed(self):
        # A source/mask doc feeding one of this view's layers changed.
        #
        # Layers are previewed in the Layers dock's preview window ONLY — the
        # base view must stay pristine (its committed pixels) until an explicit
        # merge/push. So we do NOT composite into this view; we only clear any
        # stale layer-preview display override that may be showing, then notify
        # the dock so it can refresh its own preview.
        try:
            if getattr(self, "_display_override", None) is not None:
                self._display_override = None
                self._render(rebuild=True)
        except Exception as e:
            print("[ImageSubWindow] _on_layer_source_changed error:", e)
        try:
            self.layer_sources_changed.emit()
        except Exception:
            pass

    def _collect_layer_docs(self):
        """
        Collect unique ImageDocument objects referenced by the layer stack:
        - layer src_doc (if doc-backed)
        - layer mask_doc (if any)
        Raster/baked layers may have src_doc=None; those are ignored.
        Returns a LIST in a stable order (bottom→top traversal order), de-duped.
        """
        out = []
        seen = set()

        layers = getattr(self, "_layers", None) or []
        for L in layers:
            # 1) source doc (may be None for raster/baked layers)
            d = getattr(L, "src_doc", None)
            if d is not None:
                k = id(d)
                if k not in seen:
                    seen.add(k)
                    out.append(d)

            # 2) mask doc (also may be None)
            md = getattr(L, "mask_doc", None)
            if md is not None:
                k = id(md)
                if k not in seen:
                    seen.add(k)
                    out.append(md)

        return out


    def _reinstall_layer_watchers(self):
        """
        Reconnect layer source/mask document watchers to trigger live layer recomposite.
        Safe against:
        - raster/baked layers (src_doc=None)
        - deleted docs / partially-torn-down Qt objects
        - repeated calls
        """
        # Previous watchers
        olddocs = list(getattr(self, "_watched_docs", []) or [])

        # Disconnect old
        for d in olddocs:
            try:
                # Doc may already be deleted or signal gone
                d.changed.disconnect(self._on_layer_source_changed)
            except Exception:
                pass

        # Collect new
        newdocs = self._collect_layer_docs()

        # Connect new
        for d in newdocs:
            try:
                d.changed.connect(self._on_layer_source_changed)
            except Exception:
                pass

        # Store as list (stable)
        self._watched_docs = newdocs



    def toggle_mask_overlay(self):
        self.show_mask_overlay = not self.show_mask_overlay
        self._render(rebuild=True)

    def _rebuild_title(self, *, base: str | None = None):
        sub = self._mdi_subwindow()
        if not sub:
            return

        if base is None:
            base = self._effective_title() or self.tr("Untitled")

        # Strip badges (🔗, ■, etc) AND "Active View:" prefix
        core, _ = self._strip_decorations(base)

        # ALSO strip file extensions if it looks like a filename
        # (this prevents .tiff/.fit coming back via any fallback path)
        try:
            b, ext = os.path.splitext(core)
            if ext and len(ext) <= 10 and not core.endswith("..."):
                core = b
        except Exception:
            pass

        # Build the displayed title with badges
        shown = core
        if getattr(self, "_link_badge_on", False):
            shown = f"{LINK_PREFIX}{shown}"
        if self._mask_dot_enabled:
            shown = f"{MASK_GLYPH} {shown}"

        # Update chrome
        if shown != sub.windowTitle():
            sub.setWindowTitle(shown)
            sub.setToolTip(shown)

        # IMPORTANT: emit ONLY the clean core (no badges, no extensions)
        if core != self._last_title_for_emit:
            self._last_title_for_emit = core
            try:
                self.viewTitleChanged.emit(self, core)
            except Exception:
                pass



    def _strip_decorations(self, title: str) -> tuple[str, bool]:
        had = False
        # loop to remove multiple stacked badges, in any order
        while True:
            changed = False

            # A) explicit multi-char prefixes
            for pref in DECORATION_PREFIXES:
                if title.startswith(pref):
                    title = title[len(pref):]
                    had = changed = True

            # B) generic 1-glyph + space (covers any stray glyph in GLYPHS)
            if len(title) >= 2 and title[1] == " " and title[0] in GLYPHS:
                title = title[2:]
                had = changed = True

            if not changed:
                break

        return title, had


    def set_active_highlight(self, on: bool):
        self._is_active_flag = bool(on)
        return


    def _set_mask_highlight(self, on: bool):
        self._mask_dot_enabled = bool(on)
        self._rebuild_title()

    def _sync_host_title(self):
        # document renamed → rebuild from flags + new base
        self._rebuild_title()



    def base_doc_title(self) -> str:
        """The clean, base title (document display name), no prefixes/suffixes."""
        return self.document.display_name() or self.tr("Untitled")

    def _active_mask_array(self):
        """Return the active mask ndarray (H,W) or None."""
        doc = getattr(self, "document", None)
        if not doc:
            return None
        mid = getattr(doc, "active_mask_id", None)
        if not mid:
            return None
        masks = getattr(doc, "masks", {}) or {}
        layer = masks.get(mid)
        if layer is None:
            return None
        data = getattr(layer, "data", None)
        if data is None:
            return None
        import numpy as np
        a = np.asarray(data)
        if a.ndim == 3 and a.shape[2] == 1:
            a = a[..., 0]
        if a.ndim != 2:
            return None
        # ensure 0..1 float
        a = a.astype(np.float32, copy=False)
        a = np.clip(a, 0.0, 1.0)
        return a

    def refresh_mask_overlay(self):
        """Recompute the source buffer (incl. red mask tint) and repaint."""
        self._render(rebuild=True)

    def _apply_subwindow_style(self):
        """No-op shim retained for backward compatibility."""
        pass

    def _on_doc_mask_changed(self):
        """
        Doc changed → refresh mask title/badge state only.

        IMPORTANT:
        We do NOT call _render() here, because document.changed is already
        connected to a full redraw elsewhere. Calling _render() here can
        duplicate rebuild work on every document change.
        """
        has_mask = self._active_mask_array() is not None
        self._set_mask_highlight(has_mask)

    def set_autostretch_continuous(self, on: bool):
        on = bool(on)
        if self._autostretch_continuous == on:
            return
        self._autostretch_continuous = on
        # do not force recompute immediately unless autostretch is on and
        # user wants continuous mode back
        if self.autostretch_enabled and on:
            self._invalidate_autostretch_cache()
            self._recompute_autostretch_and_update()

    def _invalidate_autostretch_cache(self):
        self._autostretch_lut_cache = None
        self._autostretch_cache_key = None
    # ---------- public API ----------
    def set_autostretch(self, on: bool):
        on = bool(on)

        if not on:
            self.autostretch_enabled = False
            self._invalidate_autostretch_cache()
            try:
                self.autostretchChanged.emit(False)
            except Exception:
                pass
            self._recompute_autostretch_and_update()
            return

        # turning ON -> always compute a fresh stretch once
        self.autostretch_enabled = True
        self._invalidate_autostretch_cache()
        try:
            self.autostretchChanged.emit(True)
        except Exception:
            pass
        self._recompute_autostretch_and_update()

    def toggle_autostretch(self):
        self.set_autostretch(not self.autostretch_enabled)

    def set_autostretch_target(self, target: float):
        self.autostretch_target = float(target)
        self._invalidate_autostretch_cache()
        if self.autostretch_enabled:
            self._render(rebuild=True)

    def set_autostretch_sigma(self, sigma: float):
        self.autostretch_sigma = float(sigma)
        self._invalidate_autostretch_cache()
        if self.autostretch_enabled:
            self._render(rebuild=True)

    def set_autostretch_profile(self, profile: str):
        p = (profile or "").lower()
        if p not in ("normal", "hard"):
            p = "normal"
        if p == self.autostretch_profile:
            return
        if p == "hard":
            self.autostretch_target = 0.5
            self.autostretch_sigma  = 2
        else:
            self.autostretch_target = 0.3
            self.autostretch_sigma  = 5
        self.autostretch_profile = p
        self._invalidate_autostretch_cache()
        if self.autostretch_enabled:
            self._render(rebuild=True)

    def is_autostretch_linked(self) -> bool:
        return bool(self._autostretch_linked)

    def set_autostretch_linked(self, linked: bool):
        linked = bool(linked)
        if self._autostretch_linked == linked:
            return
        self._autostretch_linked = linked
        self._invalidate_autostretch_cache()
        if self.autostretch_enabled:
            self._recompute_autostretch_and_update()

    def is_hard_autostretch(self) -> bool:
        return self.autostretch_profile == "hard"

    def _effective_title(self) -> str:
        """
        Returns the *core* title for this view (no UI badges like 🔗/■, and no file extension).
        Badges are added later by _rebuild_title().
        """
        # 1) Prefer per-view override if set
        t = (self._view_title_override or "").strip()

        # 2) Else prefer metadata display_name (what duplicate/rename should set)
        if not t:
            try:
                md = getattr(self.document, "metadata", {}) or {}
                t = (md.get("display_name") or "").strip()
            except Exception:
                t = ""

        # 3) Else fall back to doc.display_name()
        if not t:
            try:
                t = (self.document.display_name() or "").strip()
            except Exception:
                t = ""

        t = t or self.tr("Untitled")

        # Strip UI decorations (🔗, ■, Active View:, etc.)
        try:
            t, _ = self._strip_decorations(t)
        except Exception:
            pass

        # Strip extension if it looks like a filename
        try:
            base, ext = os.path.splitext(t)
            if ext and len(ext) <= 10:
                t = base
        except Exception:
            pass

        return t


    def _show_ctx_menu(self, pos):
        menu = QMenu(self)
        a_doc  = menu.addAction(self.tr("Rename Document…  (F2)"))
        menu.addSeparator()
        a_min  = menu.addAction(self.tr("Send to Shelf"))
        a_clear = menu.addAction(self.tr("Reset Document Name…"))
        menu.addSeparator()
        a_unlink = menu.addAction(self.tr("Unlink from Linked Views"))
        menu.addSeparator()
        a_help = menu.addAction(self.tr("Show pixel/WCS readout hint"))
        menu.addSeparator()
        a_prev = menu.addAction(self.tr("Create Preview (drag rectangle)"))
        menu.addSeparator()
        a_layers = menu.addAction(self.tr("Open Layers Panel for This View"))  # ← ADD
        menu.addSeparator()
        # --- Mask actions (requested in zoom/context menu) ---
        mw = self._find_main_window()
        vw = self  # this ImageSubWindow is the view
        doc = getattr(vw, "document", None)

        has_mask = bool(doc and getattr(doc, "active_mask_id", None))

        menu.addSeparator()
        menu.addSection(self.tr("Mask"))

        # 1) Toggle overlay (single item: Show/Hide)
        a_mask_overlay = menu.addAction(self.tr("Show Mask Overlay"))
        a_mask_overlay.setCheckable(True)
        a_mask_overlay.setChecked(bool(getattr(vw, "show_mask_overlay", False)))
        a_mask_overlay.setEnabled(has_mask)

        # 2) Invert mask
        a_invert = menu.addAction(self.tr("Invert Mask"))
        a_invert.setEnabled(has_mask)

        # 3) Remove mask
        a_remove = menu.addAction(self.tr("Remove Mask"))
        a_remove.setEnabled(has_mask)

        act = menu.exec(self.mapToGlobal(pos))

        if act == a_doc:
            self._rename_document()
        elif act == a_min:
            self._send_to_shelf()
        elif act == a_clear:
            current = self.document.display_name()
            # Try to derive original name from file path
            meta = getattr(self.document, "metadata", {}) or {}
            fpath = (meta.get("file_path") or "").strip()
            if fpath:
                import os
                original = os.path.splitext(os.path.basename(fpath))[0]
            else:
                original = current

            new_name, ok = QInputDialog.getText(
                self, self.tr("Reset Document Name"),
                self.tr("Document name:"),
                text=original
            )
            if ok and new_name.strip() and new_name.strip() != current:
                self.document.metadata["display_name"] = new_name.strip()
                self.document.changed.emit()
                self._sync_host_title()
        elif act == a_unlink:
            self.unlink_all()
        elif act == a_help:
            self._announce_readout_help()
        elif act == a_prev:
            self._preview_btn.setChecked(True)
            self._toggle_preview_select_mode(True)
        elif act == a_layers:
            self._open_layers_for_this_view()            
        # --- Mask dispatch ---
        elif act == a_mask_overlay:
            if mw:
                if a_mask_overlay.isChecked():
                    mw._show_mask_overlay()
                else:
                    mw._hide_mask_overlay()
        elif act == a_invert:
            if mw:
                mw._invert_mask()
        elif act == a_remove:
            if mw:
                mw._remove_mask_menu()

    def _open_layers_for_this_view(self):
        mw = self._find_main_window()
        if mw is None:
            return

        layers_dock = getattr(mw, "layers_dock", None)
        if layers_dock is None:
            return

        try:
            layers_dock.show()
            layers_dock.raise_()
        except Exception:
            pass

        try:
            combo = getattr(layers_dock, "view_combo", None)
            if combo is None:
                return

            # Compare uids — never widget identity, widgets can be deleted
            my_doc = getattr(self, "document", None)
            my_uid = getattr(my_doc, "uid", None)
            if my_uid is None:
                return

            for i in range(combo.count()):
                if combo.itemData(i) == my_uid:
                    combo.setCurrentIndex(i)
                    break
        except Exception:
            pass

    def _send_to_shelf(self):
        sub = self._mdi_subwindow()
        mw  = self._find_main_window()
        
        # Activate neighbor before hiding so focus flows naturally
        if sub is not None and mw is not None:
            if hasattr(mw, "_activate_neighbor_on_close"):
                try:
                    mw._activate_neighbor_on_close(sub)
                except Exception:
                    pass

        if sub and mw and hasattr(mw, "window_shelf"):
            sub.hide()
            mw.window_shelf.add_entry(sub)

    def _rename_view(self):
        """LEGACY: View rename removed. Keep as shim so older calls don't break."""
        return self._rename_document()


    def _rename_document(self):
        current = self.document.display_name()
        new, ok = QInputDialog.getText(
            self, self.tr("Rename Document"), self.tr("New name:"), text=current
        )
        if not (ok and new.strip()):
            return

        new_name = new.strip()
        if new_name == current:
            return

        self.document.metadata["display_name"] = new_name
        self.document.changed.emit()  # everyone listening updates
        self._sync_host_title()       # update this subwindow title immediately

        mw = self._find_main_window()
        if mw and hasattr(mw, "layers_dock") and mw.layers_dock:
            try:
                mw.layers_dock._refresh_titles_only()
            except Exception:
                pass


    def set_scale(self, s: float):
        s = float(max(self._min_scale, min(s, self._max_scale)))
        if abs(s - self.scale) < 1e-9:
            return
        self.scale = s
        self._render()
        self._schedule_emit_view_transform()
        # Always schedule a debounced settle. Even with smooth-zoom-settle OFF,
        # zooming IN can leave the cached (display-scale) pixmap under-resolved;
        # the settle is what re-rasterizes it from the full-res source.
        self._request_zoom_redraw()
        self._update_zoom_label()



    # ---- view state API (center in image coords + scale) ----
    #def get_view_state(self) -> dict:
    #    pm = self.label.pixmap()
    #    if pm is None:
    #        return {"scale": self.scale, "center": (0.0, 0.0)}
    #    vp = self.scroll.viewport().size()
    #    hbar = self.scroll.horizontalScrollBar()
    #    vbar = self.scroll.verticalScrollBar()
    #    cx_label = hbar.value() + vp.width() / 2.0
    #    cy_label = vbar.value() + vp.height() / 2.0
    #    return {
    #        "scale": float(self.scale),
    #        "center": (float(cx_label / max(1e-6, self.scale)),
    #                   float(cy_label / max(1e-6, self.scale)))
    #    }

    def _start_viewstate_drag(self):
        """Package view state + robust doc identity into a drag."""
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()

        state = {
            "doc_ptr": id(self.document),
            "scale": float(self.scale),
            "hval": int(hbar.value()),
            "vval": int(vbar.value()),
            "autostretch": bool(self.autostretch_enabled),
            "autostretch_target": float(self.autostretch_target),
            "source_view_id": id(self),   # ← ADD THIS
        }
        state.update(self._drag_identity_fields())

        roi = None
        try:
            if hasattr(self, "has_active_preview") and self.has_active_preview():
                r = self.current_preview_roi()
                if r and len(r) == 4:
                    roi = tuple(map(int, r))
        except Exception:
            roi = None

        if roi:
            state["roi"] = roi
            state["source_kind"] = "roi-preview"
            try:
                pname = self.current_preview_name()
            except Exception:
                pname = None
            if pname:
                state["preview_name"] = str(pname)
        else:
            state["source_kind"] = "full"
        # When on a preview tab, include the ROI doc identity so the
        # duplicate opens the edited preview, not the base image
        if roi and self._docman is not None:
            try:
                roi_doc = self._docman.get_document_for_view(self)
                if roi_doc is not None:
                    state["roi_doc_ptr"] = id(roi_doc)
                    state["roi_doc_uid"] = getattr(roi_doc, "uid", None)
            except Exception:
                pass
        if _DEBUG_DND_DUP:
            _dnd_dbg_dump_state("DRAG_START:dragtab", state)


        md = QMimeData()
        md.setData(MIME_VIEWSTATE, QByteArray(json.dumps(state).encode("utf-8")))

        drag = QDrag(self)
        drag.setMimeData(md)

        pm = self.label.pixmap()
        if pm and not pm.isNull():
            drag.setPixmap(
                pm.scaled(
                    96, 96,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
            drag.setHotSpot(QPoint(16, 16))  # optional, but feels nicer
        drag.exec(Qt.DropAction.CopyAction)
        try:
            mw = self._find_main_window()
            if mw is not None:
                mw._pending_spawn_cursor_pos = QCursor.pos()
        except Exception:
            pass



    def _start_mask_drag(self):
        """
        Start a drag that carries 'this document is a mask' to drop targets.
        """
        doc = self.document
        if doc is None:
            return

        payload = {
            # New-style field
            "mask_doc_ptr": id(doc),

            # Backward-compat field: many handlers still look for 'doc_ptr'
            "doc_ptr": id(doc),

            "mode": "replace",       # future: "union"/"intersect"/"diff"
            "invert": False,
            "feather": 0.0,          # px
            "name": doc.display_name(),
        }

        # Add identity hints (uids, base uid, file_path)
        payload.update(self._drag_identity_fields())

        md = QMimeData()
        md.setData(MIME_MASK, QByteArray(json.dumps(payload).encode("utf-8")))

        drag = QDrag(self)
        drag.setMimeData(md)
        if self.label.pixmap():
            drag.setPixmap(
                self.label.pixmap().scaled(
                    64, 64,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
            drag.setHotSpot(QPoint(16, 16))
        drag.exec(Qt.DropAction.CopyAction)

    def _start_astrometry_drag(self):
        """
        Start a drag that carries 'copy astrometric solution from this document'.
        We only send a pointer; the main window resolves + copies actual WCS.
        """
        payload = {
            "wcs_from_doc_ptr": id(self.document),
            "name": self.document.display_name(),
        }
        payload.update(self._drag_identity_fields()) 
        md = QMimeData()
        md.setData(MIME_ASTROMETRY, QByteArray(json.dumps(payload).encode("utf-8")))

        drag = QDrag(self)
        drag.setMimeData(md)
        if self.label.pixmap():
            drag.setPixmap(self.label.pixmap().scaled(
                64, 64, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
            drag.setHotSpot(QPoint(16, 16))
        drag.exec(Qt.DropAction.CopyAction)


    def apply_view_state(self, st: dict):
        try:
            new_scale = float(st.get("scale", self.scale))
        except Exception:
            new_scale = self.scale
        # clamp with new max
        self.scale = max(self._min_scale, min(new_scale, self._max_scale))
        # Fast present at the new scale first so label size + scrollbar
        # ranges are correct before we position the view.
        self._render(rebuild=False)

        vp = self.scroll.viewport().size()
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()

        if "hval" in st or "vval" in st:
            # direct scrollbar values (fast path)
            hv = int(st.get("hval", hbar.value()))
            vv = int(st.get("vval", vbar.value()))
            hbar.setValue(hv)
            vbar.setValue(vv)
        else:
            # fallback: center in image coordinates
            center = st.get("center")
            if center is not None:
                try:
                    cx_img, cy_img = float(center[0]), float(center[1])
                except Exception:
                    cx_img = cy_img = None
                if cx_img is not None:
                    cx_label = cx_img * self.scale
                    cy_label = cy_img * self.scale
                    hbar.setValue(int(cx_label - vp.width()  / 2.0))
                    vbar.setValue(int(cy_label - vp.height() / 2.0))

        # Trigger the same settle logic a real zoom-end uses so the receiving
        # view rebuilds the source pixmap when the dropped scale is beyond the
        # cached resolution -- otherwise it stays pixelated until the user
        # nudges the zoom to force a rebuild.
        try:
            if self._zoom_settle_needs_rebuild():
                self._render(rebuild=True)
            elif getattr(self, "_smooth_zoom", True):
                self._present_scaled(interactive=False)
        except Exception:
            pass
        finally:
            try:
                self._hide_recalc_overlay()
            except Exception:
                pass

        try:
            self._emit_view_transform()
        except Exception:
            pass


    # ---- DnD 'view tab' -------------------------------------------------

    def _mdi_subwindow(self):
        """Return the QMdiSubWindow that hosts this view, or None."""
        try:
            from PyQt6.QtWidgets import QMdiSubWindow
            p = self.parent()
            while p is not None:
                if isinstance(p, QMdiSubWindow):
                    return p
                p = p.parent()
        except Exception:
            pass
        return None

    def _current_view_title_for_drag(self) -> str:
        """
        The *actual* user-visible view title (what they renamed to),
        NOT the document/file name.
        """
        title = ""
        try:
            sw = self._mdi_subwindow()
            if sw is not None:
                title = (sw.windowTitle() or "").strip()
        except Exception:
            title = ""

        if not title:
            try:
                title = (self.windowTitle() or "").strip()
            except Exception:
                title = ""

        if not title:
            # absolute fallback
            try:
                title = (self.document.display_name() or "").strip()
            except Exception:
                title = ""

        # Optional: strip [LINK], glyphs, etc if your title includes those
        try:
            title = _strip_ui_decorations(title)
        except Exception:
            pass

        return title or "Untitled"


    # accept view-state drops anywhere in the view
    def dragEnterEvent(self, ev):
        md = ev.mimeData()

        if (md.hasFormat(MIME_VIEWSTATE)
                or md.hasFormat(MIME_ASTROMETRY)
                or md.hasFormat(MIME_MASK)
                or md.hasFormat(MIME_CMD)
                or md.hasFormat(MIME_LINKVIEW)):
            ev.acceptProposedAction()
        else:
            ev.ignore()

    def dragMoveEvent(self, ev):
        md = ev.mimeData()

        if (md.hasFormat(MIME_VIEWSTATE)
                or md.hasFormat(MIME_ASTROMETRY)
                or md.hasFormat(MIME_MASK)
                or md.hasFormat(MIME_CMD)
                or md.hasFormat(MIME_LINKVIEW)):
            ev.acceptProposedAction()
        else:
            ev.ignore()

    def dropEvent(self, ev):
        md = ev.mimeData()

        # 0) Function/Action command → forward to main window for headless/UI routing
        if md.hasFormat(MIME_CMD):
            try:
                payload = _unpack_cmd_payload(bytes(md.data(MIME_CMD)))
            except Exception:
                ev.ignore(); return
            mw = self._find_main_window()
            sw = self._mdi_subwindow()
            if mw and sw and hasattr(mw, "_handle_command_drop"):
                mw._handle_command_drop(payload, sw)
                ev.acceptProposedAction()
            else:
                ev.ignore()
            return

        # 1) view state (existing)
        if md.hasFormat(MIME_VIEWSTATE):
            try:
                st = json.loads(bytes(md.data(MIME_VIEWSTATE)).decode("utf-8"))
                self.apply_view_state(st)
                ev.acceptProposedAction()
            except Exception:
                ev.ignore()
            return

        # 2) mask (NEW) → forward to main-window handler using this view as target
        if md.hasFormat(MIME_MASK):
            try:
                payload = json.loads(bytes(md.data(MIME_MASK)).decode("utf-8"))
            except Exception:
                ev.ignore(); return
            mw = self._find_main_window()
            sw = self._mdi_subwindow()
            if mw and sw and hasattr(mw, "_handle_mask_drop"):
                mw._handle_mask_drop(payload, sw)
                ev.acceptProposedAction()
            else:
                ev.ignore()
            return

        # 3) astrometry (existing forwarding)
        if md.hasFormat(MIME_ASTROMETRY):
            try:
                payload = json.loads(bytes(md.data(MIME_ASTROMETRY)).decode("utf-8"))
            except Exception:
                ev.ignore(); return
            mw = self._find_main_window()
            sw = self._mdi_subwindow()
            if mw and hasattr(mw, "_on_astrometry_drop") and sw is not None:
                mw._on_astrometry_drop(payload, sw)
                ev.acceptProposedAction()
            else:
                ev.ignore()
            return

        if md.hasFormat(MIME_LINKVIEW):
            try:
                payload = json.loads(bytes(md.data(MIME_LINKVIEW)).decode("utf-8"))
                sid = int(payload.get("source_view_id"))
            except Exception:
                ev.ignore(); return
            src = ImageSubWindow._registry.get(sid)
            if src is not None and src is not self:
                src.link_to(self)
                ev.acceptProposedAction()
            else:
                ev.ignore()
            return

        ev.ignore()

    def _current_view_display_name(self) -> str:
        """
        Best-effort: the exact title the user sees for THIS subwindow/view.
        Prefer QMdiSubWindow title, fallback to document display_name.
        """
        # 1) QMdiSubWindow title (what user sees)
        try:
            sw = self._mdi_subwindow()
            if sw is not None:
                t = (sw.windowTitle() or "").strip()
                if t:
                    return t
        except Exception:
            pass

        # 2) This widget's own windowTitle (sometimes used)
        try:
            t = (self.windowTitle() or "").strip()
            if t:
                return t
        except Exception:
            pass

        # 3) Document display name fallback
        try:
            d = getattr(self, "document", None)
            if d is not None and hasattr(d, "display_name"):
                t = (d.display_name() or "").strip()
                if t:
                    return t
        except Exception:
            pass

        return "Untitled"


    # keep the tab visible if the widget resizes
    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        try:
            self.resized.emit()
        except Exception:
            pass        
        if hasattr(self, "_view_tab"):
            self._view_tab.raise_()




    def _on_docman_nudge(self, *args):
        # Guard against late signals hitting after destruction/minimize
        try:
            from PyQt6 import sip as _sip
            if _sip.isdeleted(self):
                return
        except Exception:
            pass
        try:
            self._refresh_local_undo_buttons()
        except RuntimeError:
            # Buttons already gone; safe to ignore
            pass
        except Exception:
            pass


    def _recompute_autostretch_and_update(self):
        self._invalidate_autostretch_cache()
        self._qimg_src = None
        self._render(True)

    def set_doc_manager(self, docman):
        # Disconnect old docman hooks first
        old = getattr(self, "_docman", None)
        if old is not None:
            try:
                old.imageRegionUpdated.disconnect(self._on_doc_region_updated)
            except Exception:
                pass
            try:
                old.imageRegionUpdated.disconnect(self._on_docman_nudge)
            except Exception:
                pass
            try:
                if hasattr(old, "previewRepaintRequested"):
                    old.previewRepaintRequested.disconnect(self._on_docman_nudge)
            except Exception:
                pass

        # Disconnect old base.changed hook first
        old_base = getattr(self, "_docman_base_for_signal", None)
        if old_base is not None:
            try:
                old_base.changed.disconnect(self._on_base_doc_changed)
            except Exception:
                pass

        self._docman = docman

        try:
            docman.imageRegionUpdated.connect(self._on_doc_region_updated)
        except Exception:
            pass

        try:
            docman.imageRegionUpdated.connect(self._on_docman_nudge)
        except Exception:
            pass

        try:
            if hasattr(docman, "previewRepaintRequested"):
                docman.previewRepaintRequested.connect(self._on_docman_nudge)
        except Exception:
            pass

        base = getattr(self, "base_document", None) or getattr(self, "document", None)
        self._docman_base_for_signal = base

        if base is not None:
            try:
                base.changed.connect(self._on_base_doc_changed)
            except Exception:
                pass

        self._install_history_watchers()

    def _on_base_doc_changed(self):
        """
        Base/full document changed.

        Avoid forcing another redraw here because document.changed already
        drives rendering in this view. Keep this lightweight.
        """
        QTimer.singleShot(0, self._refresh_local_undo_buttons)

    def _on_history_doc_changed(self):
        """
        Current history doc (full or ROI) changed.

        Keep this lightweight. Rendering is already driven by the document's
        changed signal connections, so only refresh local buttons here.
        """
        QTimer.singleShot(0, self._refresh_local_undo_buttons)
        QTimer.singleShot(0, self._update_replay_button)

    def _on_doc_region_updated(self, doc, roi_tuple_or_none):
        # Only react if it’s our base doc
        base = getattr(self, "base_document", None) or getattr(self, "document", None)
        if doc is None or base is None or doc is not base:
            return

        # Full-image / unknown update -> redraw
        if roi_tuple_or_none is None:
            QTimer.singleShot(0, lambda: self._render(rebuild=True))
            return

        # If not on a preview tab, just redraw
        if not (getattr(self, "_active_source_kind", None) == "preview"
                and getattr(self, "_active_preview_id", None) is not None):
            QTimer.singleShot(0, lambda: self._render(rebuild=True))
            return

        # Preview active: redraw only if changed region overlaps our ROI
        try:
            my_roi = self.current_preview_roi()
        except Exception:
            my_roi = None

        if my_roi is None:
            QTimer.singleShot(0, lambda: self._render(rebuild=True))
            return

        if self._roi_intersects(my_roi, roi_tuple_or_none):
            QTimer.singleShot(0, lambda: self._render(rebuild=True))

    @staticmethod
    def _roi_intersects(a, b):
        ax, ay, aw, ah = map(int, a)
        bx, by, bw, bh = map(int, b)
        if aw <= 0 or ah <= 0 or bw <= 0 or bh <= 0:
            return False
        return not (ax+aw <= bx or bx+bw <= ax or ay+ah <= by or by+bh <= ay)

    def refresh_from_docman(self):
        #print("[ImageSubWindow] refresh_from_docman called")
        """
        Called by MainWindow when DocManager says the image changed.
        We nuke the cached QImage and rebuild from the current doc proxy
        (which resolves ROI vs full), so the Preview tab repaints correctly.
        """
        try:
            # Invalidate any cached source so _render() fully rebuilds
            if hasattr(self, "_qimg_src"):
                self._qimg_src = None
        except Exception:
            pass
        self._render(rebuild=True)

    def _deg_to_hms(self, ra_deg: float) -> str:
        """RA in degrees → 'HH:MM:SS' (rounded secs, with carry)."""
        ra_h = ra_deg / 15.0
        hh = int(ra_h) % 24
        mmf = (ra_h - hh) * 60.0
        mm = int(mmf)
        ss = int(round((mmf - mm) * 60.0))
        if ss == 60:
            ss = 0; mm += 1
        if mm == 60:
            mm = 0; hh = (hh + 1) % 24
        return f"{hh:02d}:{mm:02d}:{ss:02d}"

    def _deg_to_dms(self, dec_deg: float) -> str:
        """Dec in degrees → '±DD:MM:SS' (rounded secs, with carry)."""
        sign = "+" if dec_deg >= 0 else "-"
        d = abs(dec_deg)
        dd = int(d)
        mf = (d - dd) * 60.0
        mm = int(mf)
        ss = int(round((mf - mm) * 60.0))
        if ss == 60:
            ss = 0; mm += 1
        if mm == 60:
            mm = 0; dd += 1
        return f"{sign}{dd:02d}:{mm:02d}:{ss:02d}"

    def copy_viewport_to_clipboard_image(self) -> QImage | None:
        """
        Returns a QImage of exactly what the user is currently seeing:
        - includes autostretch + mask overlay (because it uses the rendered pixmap)
        - includes current zoom scale + pan position (viewport crop)
        - works for Full tab and Preview tabs (because _pm_src is built from active source)
        """
        if isinstance(self.label, ViewportImageCanvas):
            vp = self.scroll.viewport()
            hbar = self.scroll.horizontalScrollBar()
            vbar = self.scroll.verticalScrollBar()
            x = max(0, int(hbar.value()))
            y = max(0, int(vbar.value()))
            w = max(1, min(int(vp.width()), int(self.label.width()) - x))
            h = max(1, min(int(vp.height()), int(self.label.height()) - y))
            grab = self.label.grab(QRect(x, y, w, h))
            return None if grab.isNull() else grab.toImage()

        # Make sure we have something rendered
        pm = getattr(self, "_pm_src", None)
        if pm is None or pm.isNull():
            # Try to build it once (slow path) if needed
            try:
                self._render(rebuild=True)
                pm = getattr(self, "_pm_src", None)
            except Exception:
                pm = None

        if pm is None or pm.isNull():
            return None

        # We need the *currently displayed* pixmap size, not the source pixmap
        # Because _present_scaled likely sets label pixmap to a scaled version.
        shown_pm = self.label.pixmap()
        if shown_pm is None or shown_pm.isNull():
            # fallback to unscaled source if label doesn't have one
            shown_pm = pm

        vp = self.scroll.viewport()
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()

        # Visible rect in label coordinates:
        # scrollbars are offsets into the label widget.
        x = int(hbar.value())
        y = int(vbar.value())
        w = int(vp.width())
        h = int(vp.height())

        # Clamp crop to pixmap bounds (important when image smaller than viewport)
        px_w = int(shown_pm.width())
        px_h = int(shown_pm.height())

        if px_w <= 0 or px_h <= 0:
            return None

        if x < 0: x = 0
        if y < 0: y = 0
        if x >= px_w or y >= px_h:
            return None

        w = min(w, px_w - x)
        h = min(h, px_h - y)
        if w <= 0 or h <= 0:
            return None

        cropped = shown_pm.copy(QRect(x, y, w, h))
        if cropped.isNull():
            return None

        return cropped.toImage()

    def set_no_black_clip(self, enabled: bool):
        self._no_black_clip = bool(enabled)
        if self.autostretch_enabled:
            self._autostretch_lut_cache = None   # invalidate cache
            self._render(rebuild=True)
    # ---------- rendering ----------
    def _render(self, rebuild: bool = False):
        # ---- GUARD: widget/label/document may be deleted during teardown ----
        try:
            from PyQt6 import sip as _sip
            if _sip.isdeleted(self):
                return
            lbl = getattr(self, "label", None)
            if lbl is None or _sip.isdeleted(lbl):
                return
            doc = getattr(self, "document", None)
            if doc is None:
                return
            img = getattr(doc, "image", None)
            if img is None:
                return
        except Exception:
            return
        # ---------------------------------------------------------------------------

        # ---------------------------------------------------------------------------
        # FAST PATH: if we're not rebuilding content and we already have a source pixmap,
        # just present scaled (fast). This is the key to smooth zoom.
        # ---------------------------------------------------------------------------
        if (not rebuild) and getattr(self, "_pm_src", None) is not None:
            self._present_scaled(interactive=True)
            return

        # ---------------------------
        # 1) Choose & sync source arr
        # ---------------------------
        base_img = None
        if self._active_source_kind == "preview" and self._active_preview_id is not None:
            src = next((p for p in self._previews if p["id"] == self._active_preview_id), None)
            if src is not None:
                if rebuild:
                    roi_img = None
                    if hasattr(self, "_docman") and self._docman is not None:
                        try:
                            roi_doc = self._docman.get_document_for_view(self)
                            roi_img = getattr(roi_doc, "image", None)
                        except Exception:
                            pass

                    if roi_img is not None:
                        src["arr"] = np.asarray(roi_img).copy()
                    else:
                        roi = src["roi"]
                        x, y, w, h = roi
                        parent_img = getattr(self.document, "image", None)
                        if parent_img is not None:
                            src["arr"] = np.asarray(parent_img)[y:y+h, x:x+w].copy()

                base_img = src.get("arr", None)
        else:
            base_img = self._display_override if (self._display_override is not None) else (
                getattr(self.document, "image", None)
            )

        if base_img is None:
            self._qimg_src = None
            self._pm_src = None
            self._pm_src_scale = None
            self._pm_src_wcs = None
            self._buf8 = None
            self.label.clear()
            return

        arr = np.asarray(base_img)

        # ---------------------------------------
        # 2) Normalize dimensionality and dtype
        # ---------------------------------------
        if arr.ndim == 0:
            arr = arr.reshape(1, 1)
        elif arr.ndim == 1:
            arr = arr[np.newaxis, :]
        elif arr.ndim == 3 and arr.shape[2] == 1:
            arr = arr[..., 0]

        is_mono = (arr.ndim == 2)

        # ---------------------------------------
        # 3) Viewport-sized visualization (never a full-res 8-bit copy)
        # ---------------------------------------
        scale = float(getattr(self, "scale", 1.0) or 1.0)
        src_h, src_w = int(arr.shape[0]), int(arr.shape[1])

        # We never build the numpy display buffer bigger than source. Zoom past
        # 100% is presentation-time upscaling: Qt scales _pm_src up to the label
        # size in one pass (nearest for crisp pixels, or bilinear when smooth-zoom
        # is on). Pre-upsampling in numpy would just replicate pixels into a
        # larger uint8 buffer for no visual gain -- and, when smooth-zoom is on,
        # actively degrade quality (Qt smooths an already-blocky nearest upsample
        # instead of smoothing the source directly).
        build_scale = min(1.0, float(scale))

        out_w = max(1, int(round(src_w * build_scale)))
        out_h = max(1, int(round(src_h * build_scale)))
        # Hard cap so a huge mosaic at 100% still stays bounded (RAM sanity).
        # When either the 1.0 cap or the 8192 cap engages, the pixmap represents
        # an EFFECTIVE scale below what the user asked for. _pm_src_scale below
        # records that honest value so _present_scaled sizes the label to
        # src * self.scale (via Qt upsampling) and every consumer of self.scale
        # (zoom % readout, loupe coord math, view-state drops, linked views)
        # stays in sync with what is actually on screen.
        _max_side = 8192
        effective_scale = float(build_scale)
        if out_w > _max_side or out_h > _max_side:
            k = min(_max_side / out_w, _max_side / out_h)
            out_w = max(1, int(out_w * k))
            out_h = max(1, int(out_h * k))
            effective_scale = float(build_scale) * float(k)

        vis_src = arr
        if np.issubdtype(arr.dtype, np.integer):
            info = np.iinfo(arr.dtype)
            vis_src = arr.astype(np.float32) / float(max(1, info.max))
        elif not np.issubdtype(arr.dtype, np.floating):
            vis_src = arr.astype(np.float32, copy=False)

        small = resize_for_display(vis_src, out_w, out_h)

        if self.autostretch_enabled:
            arr_f = vis_src.astype(np.float32, copy=False)
            mx = float(arr_f.max()) if arr_f.size else 1.0
            if mx > 5.0:
                arr_f = arr_f / mx
                small = resize_for_display(arr_f, out_w, out_h)

            cache_key = (
                bool(is_mono),
                bool(self._autostretch_linked),
                float(self.autostretch_target),
                float(self.autostretch_sigma),
                bool(getattr(self, "_no_black_clip", False)),
                tuple(arr_f.shape),
            )
            use_cached = (
                (not self._autostretch_continuous)
                and (self._autostretch_lut_cache is not None)
                and (self._autostretch_cache_key == cache_key)
            )
            if not use_cached:
                n = int(arr_f.shape[0]) * int(arr_f.shape[1])
                s = max(1, int(np.sqrt(n / 65536.0))) if n > 65536 else 1
                sample = np.ascontiguousarray(arr_f[::s, ::s])
                _stretched, lut_cache = autostretch_with_lut(
                    sample,
                    target_median=self.autostretch_target,
                    sigma=self.autostretch_sigma,
                    linked=(not is_mono and self._autostretch_linked),
                    use_24bit=None,
                    no_black_clip=bool(getattr(self, "_no_black_clip", False)),
                )
                self._autostretch_lut_cache = lut_cache
                self._autostretch_cache_key = cache_key
            vis = apply_autostretch_lut(
                small.astype(np.float32, copy=False),
                self._autostretch_lut_cache,
                linked=(not is_mono and self._autostretch_linked),
            )
        else:
            vis = small

        # ---------------------------------------
        # 4) Convert to 8-bit RGB for QImage (display size only)
        # ---------------------------------------
        buf8 = to_uint8_rgb(vis)

        # ---------------------------------------
        # 5) Optional mask overlay (baked into buf8)
        # ---------------------------------------
        if getattr(self, "show_mask_overlay", False):
            m = self._active_mask_array()
            if m is not None:
                if getattr(self, "_mask_overlay_invert", True):
                    m = 1.0 - m
                th, tw = buf8.shape[:2]
                sh, sw = m.shape[:2]
                if (sh, sw) != (th, tw):
                    yi = (np.linspace(0, sh - 1, th)).astype(np.int32)
                    xi = (np.linspace(0, sw - 1, tw)).astype(np.int32)
                    m = m[yi][:, xi]
                a = m.astype(np.float32, copy=False) * float(getattr(self, "_mask_overlay_alpha", 0.35))
                bf = buf8.astype(np.float32, copy=False)
                bf[..., 0] = np.clip(bf[..., 0] + (255.0 - bf[..., 0]) * a, 0.0, 255.0)
                buf8 = bf.astype(np.uint8, copy=False)

        # ---------------------------------------
        # 6) Build QImage with deep copy so Qt owns the buffer.
        #    The zero-copy sip.voidptr path leaves a dangling pointer
        #    if _buf8 is GC'd during subwindow teardown — segfaults on Linux.
        # ---------------------------------------
        if buf8.dtype != np.uint8:
            buf8 = buf8.astype(np.uint8)

        buf8 = ensure_contiguous(buf8)
        h, w, c = buf8.shape
        bytes_per_line = int(w * 3)

        self._buf8 = None  # loupe / readout sample document.image (source coords)

        try:
            # tobytes() makes a deep copy — Qt owns this memory independently
            # of the numpy array lifetime, eliminating the dangling pointer crash
            qimg = QImage(
                buf8.tobytes(),
                w, h,
                bytes_per_line,
                QImage.Format.Format_RGB888,
            )
            if qimg is None or qimg.isNull():
                raise RuntimeError("QImage null")
        except Exception:
            self._qimg_src = None
            self._pm_src = None
            self._pm_src_scale = None
            self._pm_src_wcs = None
            self._buf8 = None
            self.label.clear()
            return

        qimg = tag_qimage_with_working_color_space(qimg)
        self._qimg_src = qimg

        # Cache pixmap at the current display scale (not 1:1 source pixels)
        self._pm_src = QPixmap.fromImage(self._qimg_src)
        if isinstance(self.label, ViewportImageCanvas):
            self.label.invalidate()   # LUT/data changed -> drop cached tiles + proxy
        # Truthful: this is the scale that the built pixmap actually represents.
        # Equals `scale` when the 8192 cap did NOT engage; below `scale` when it
        # did. Downstream (_present_scaled, _zoom_settle_needs_rebuild) rely on
        # this being honest so ratio math sizes the label to src_w*self.scale
        # and every coord conversion using self.scale keeps working.
        self._pm_src_scale = float(effective_scale)
        # Remember the TRUE source dimensions this pixmap was built from, so the
        # zoom-settle can tell when the cached pixmap is under-resolved for the
        # current zoom and needs a full-res re-rasterize.
        self._pm_src_src_w = int(src_w)
        self._pm_src_src_h = int(src_h)

        # Invalidate any cached "WCS baked" pixmap on rebuild
        self._pm_src_wcs = None

        # Present final-quality after rebuild — but only if the user wants smoothing
        # on the final settle. Otherwise stay on the fast (nearest-neighbour) present
        # so undo/redo, process-applied, and doc-region updates keep the real pixels
        # visible without needing a zoom/resize nudge.
        self._present_scaled(interactive=not getattr(self, "_smooth_zoom", True))

        rebuild = False  # done


    def _current_display_source(self):
        """The array currently on display: preview ROI array, display override,
        else the document image. Mirrors _render()'s source selection so the
        canvas rasterizes exactly what _render() would."""
        try:
            if self._active_source_kind == "preview" and self._active_preview_id is not None:
                src = next((p for p in self._previews if p["id"] == self._active_preview_id), None)
                return None if src is None else src.get("arr", None)
            if getattr(self, "_display_override", None) is not None:
                return self._display_override
            doc = getattr(self, "document", None)
            return getattr(doc, "image", None) if doc is not None else None
        except Exception:
            return None

    def _present_viewport_canvas(self):
        """Size the canvas to the FULL (uncapped) scaled image so scroll ranges
        are correct, then repaint. Pixels are produced per-viewport in
        ViewportImageCanvas.paintEvent -> _rasterize_widget_rect(); no
        full-resolution pixmap is ever built here."""
        arr = self._current_display_source()
        if arr is None:
            try:
                self.label.clear()
            except Exception:
                pass
            return
        a = np.asarray(arr)
        if a.ndim == 3 and a.shape[-1] == 1:
            a = a[..., 0]
        if a.ndim not in (2, 3):
            return
        src_h, src_w = int(a.shape[0]), int(a.shape[1])
        scale = float(getattr(self, "scale", 1.0) or 1.0)
        full_w = max(1, int(round(src_w * scale)))
        full_h = max(1, int(round(src_h * scale)))
        self.label.request_full_size(full_w, full_h, src_w, src_h)

    def _rasterize_widget_rect(self, wx, wy, ww, wh):
        """Rasterize ONLY the widget rectangle (wx, wy, ww, wh) at true scale.

        Returns (QImage, ox, oy): the image is drawn at widget offset (ox, oy),
        which is snapped to whole source pixels for exact alignment (it may sit
        <= scale px left/above the requested rect; QPainter clips the overhang).
        Reuses the autostretch LUT cached by _render(), so the stretch matches
        the overview. Cost is O(viewport), with no per-side cap.
        """
        arr = self._current_display_source()
        if arr is None:
            return None
        a = np.asarray(arr)
        if a.ndim == 3 and a.shape[-1] == 1:
            a = a[..., 0]
        if a.ndim not in (2, 3):
            return None
        is_mono = (a.ndim == 2)
        src_h, src_w = int(a.shape[0]), int(a.shape[1])
        scale = float(getattr(self, "scale", 1.0) or 1.0)

        # Widget rect -> integer source crop (snapped outward to whole pixels).
        sx = max(0, min(int(np.floor(wx / scale)), src_w - 1))
        sy = max(0, min(int(np.floor(wy / scale)), src_h - 1))
        sx2 = max(sx + 1, min(int(np.ceil((wx + ww) / scale)), src_w))
        sy2 = max(sy + 1, min(int(np.ceil((wy + wh) / scale)), src_h))
        crop_w = sx2 - sx
        crop_h = sy2 - sy

        # Output size = crop rendered at scale; offset = crop origin at scale.
        ox = int(round(sx * scale))
        oy = int(round(sy * scale))
        out_w = max(1, int(round(crop_w * scale)))
        out_h = max(1, int(round(crop_h * scale)))

        # Float view for the stretch/convert path (mirror _render dtype handling).
        vis_src = a
        if np.issubdtype(a.dtype, np.integer):
            info = np.iinfo(a.dtype)
            vis_src = a.astype(np.float32) / float(max(1, info.max))
        elif not np.issubdtype(a.dtype, np.floating):
            vis_src = a.astype(np.float32, copy=False)

        small = resize_for_display(
            vis_src, out_w, out_h,
            src_x=sx, src_y=sy, src_w=crop_w, src_h=crop_h,
        )

        lut = getattr(self, "_autostretch_lut_cache", None)
        if getattr(self, "autostretch_enabled", False) and lut is not None:
            try:
                vis = apply_autostretch_lut(
                    small.astype(np.float32, copy=False),
                    lut,
                    linked=(not is_mono and getattr(self, "_autostretch_linked", False)),
                )
            except Exception:
                vis = small
        else:
            vis = small

        buf8 = to_uint8_rgb(vis)

        # Mask overlay, baked over the same source crop (parity with _render()).
        if getattr(self, "show_mask_overlay", False):
            try:
                m = self._active_mask_array()
            except Exception:
                m = None
            if m is not None:
                m = np.asarray(m)
                if getattr(self, "_mask_overlay_invert", True):
                    m = 1.0 - m
                mc = m[sy:sy2, sx:sx2]
                th, tw = buf8.shape[:2]
                sh2, sw2 = mc.shape[:2]
                if sh2 > 0 and sw2 > 0:
                    if (sh2, sw2) != (th, tw):
                        yi = np.linspace(0, sh2 - 1, th).astype(np.int32)
                        xi = np.linspace(0, sw2 - 1, tw).astype(np.int32)
                        mc = mc[yi][:, xi]
                    ov = mc.astype(np.float32, copy=False) * float(getattr(self, "_mask_overlay_alpha", 0.35))
                    bf = buf8.astype(np.float32, copy=False)
                    bf[..., 0] = np.clip(bf[..., 0] + (255.0 - bf[..., 0]) * ov, 0.0, 255.0)
                    buf8 = bf.astype(np.uint8, copy=False)

        if buf8.dtype != np.uint8:
            buf8 = buf8.astype(np.uint8)
        buf8 = ensure_contiguous(buf8)
        h, w = int(buf8.shape[0]), int(buf8.shape[1])
        try:
            qimg = QImage(buf8.tobytes(), w, h, w * 3, QImage.Format.Format_RGB888)
            if qimg.isNull():
                return None
        except Exception:
            return None
        try:
            qimg = tag_qimage_with_working_color_space(qimg)
        except Exception:
            pass
        return qimg, ox, oy

    def _render_source_tile(self, sx, sy, sw, sh):
        """Source-resolution RGB of a tile (sx, sy, sw, sh), LUT + mask applied,
        with NO geometric scaling -- TiledImageCanvas scales cached tiles on
        blit. Same stretch/mask path as _rasterize_widget_rect, minus the resize.
        Returns a QImage (or None)."""
        arr = self._current_display_source()
        if arr is None:
            return None
        a = np.asarray(arr)
        if a.ndim == 3 and a.shape[-1] == 1:
            a = a[..., 0]
        if a.ndim not in (2, 3):
            return None
        is_mono = (a.ndim == 2)
        H, W = int(a.shape[0]), int(a.shape[1])
        sx = max(0, int(sx)); sy = max(0, int(sy))
        sw = max(1, min(int(sw), W - sx)); sh = max(1, min(int(sh), H - sy))
        sx2 = sx + sw; sy2 = sy + sh
        crop = a[sy:sy2, sx:sx2]

        vis = crop.astype(np.float32, copy=False)
        if np.issubdtype(a.dtype, np.integer):
            info = np.iinfo(a.dtype)
            vis = crop.astype(np.float32) / float(max(1, info.max))

        lut = getattr(self, "_autostretch_lut_cache", None)
        if getattr(self, "autostretch_enabled", False) and lut is not None:
            try:
                vis = apply_autostretch_lut(
                    vis, lut,
                    linked=(not is_mono and getattr(self, "_autostretch_linked", False)),
                )
            except Exception:
                pass

        buf8 = to_uint8_rgb(vis)

        # Mask overlay over the same source crop (parity with _render()).
        if getattr(self, "show_mask_overlay", False):
            try:
                m = self._active_mask_array()
            except Exception:
                m = None
            if m is not None:
                m = np.asarray(m)
                if getattr(self, "_mask_overlay_invert", True):
                    m = 1.0 - m
                mc = m[sy:sy2, sx:sx2]
                th, tw = buf8.shape[:2]
                sh2, sw2 = mc.shape[:2]
                if sh2 > 0 and sw2 > 0:
                    if (sh2, sw2) != (th, tw):
                        yi = np.linspace(0, sh2 - 1, th).astype(np.int32)
                        xi = np.linspace(0, sw2 - 1, tw).astype(np.int32)
                        mc = mc[yi][:, xi]
                    ov = mc.astype(np.float32, copy=False) * float(getattr(self, "_mask_overlay_alpha", 0.35))
                    bf = buf8.astype(np.float32, copy=False)
                    bf[..., 0] = np.clip(bf[..., 0] + (255.0 - bf[..., 0]) * ov, 0.0, 255.0)
                    buf8 = bf.astype(np.uint8, copy=False)

        if buf8.dtype != np.uint8:
            buf8 = buf8.astype(np.uint8)
        buf8 = ensure_contiguous(buf8)
        h, w = int(buf8.shape[0]), int(buf8.shape[1])
        try:
            qimg = QImage(buf8.tobytes(), w, h, w * 3, QImage.Format.Format_RGB888)
            if qimg.isNull():
                return None
        except Exception:
            return None
        try:
            qimg = tag_qimage_with_working_color_space(qimg)
        except Exception:
            pass
        return qimg

    def _present_scaled(self, interactive: bool):
        """
        Present the cached source pixmap scaled to current self.scale.

        interactive=True:
        - Fast scaling
        - No WCS draw
        interactive=False:
        - Smooth scaling
        - Optionally draw WCS overlay once
        """
        # Viewport-crop path: size the canvas and let paintEvent rasterize only
        # what's visible.
        #
        # Exception: the WCS grid. Its painter bakes onto a whole scaled pixmap
        # and has not been ported to paint per-exposed-rect, so while the grid
        # is switched ON we fall through to the whole-pixmap path below and
        # hand the canvas the finished pixmap as a direct override. That gives
        # up the memory win for as long as the grid is on -- it is the old
        # behaviour exactly -- but losing the overlay silently would be worse.
        # Porting the painter removes this branch.
        if (isinstance(self.label, ViewportImageCanvas)
                and not getattr(self, "_show_wcs_grid", False)):
            # Drop anything the whole-pixmap path left behind. Those caches are
            # normally replaced on the next present, but the viewport path
            # returns before that -- so switching the grid off at high zoom
            # would otherwise strand the last bake (measured 599 MB at 300%)
            # for the life of the view.
            self._present_scaled_cache = None
            self._pm_src_wcs = None
            self._pm_src_wcs_key = None
            self._present_viewport_canvas()
            return

        if getattr(self, "_pm_src", None) is None:
            return

        pm_base = self._pm_src

        src_scale = float(getattr(self, "_pm_src_scale", None) or 1.0)
        ratio = float(self.scale) / max(src_scale, 1e-12)
        sw = max(1, int(round(pm_base.width() * ratio)))
        sh = max(1, int(round(pm_base.height() * ratio)))

        # Honour the "smooth on final redraw" setting globally. If the user has
        # disabled it, we never smooth — even on non-interactive presents.
        if interactive or not getattr(self, "_smooth_zoom", True):
            mode = Qt.TransformationMode.FastTransformation
        else:
            mode = Qt.TransformationMode.SmoothTransformation

        # Memoise the scaled pixmap. _render() calls _present_scaled twice
        # (interactive then settle) and the WCS re-present hits the same scale,
        # so this skips redundant full-image QPixmap.scaled() calls. The key
        # includes pm_base.cacheKey(), so a rebuilt _pm_src invalidates it for free.
        _pkey = (pm_base.cacheKey(), int(sw), int(sh), mode)
        _pc = getattr(self, "_present_scaled_cache", None)
        if _pc is not None and _pc[0] == _pkey:
            pm_scaled = _pc[1]
        else:
            pm_scaled = pm_base.scaled(sw, sh, Qt.AspectRatioMode.KeepAspectRatio, mode)
            self._present_scaled_cache = (_pkey, pm_scaled)

        # WCS grid: driven ONLY by the user's toggle, not by `interactive`.
        # Cache key MUST include the scaling mode (`mode`) so an interactive
        # fast-scaled bake does not shadow the smooth-scaled settle present
        # (and vice-versa). Also key on pm_base.cacheKey() so a rebuild of
        # _pm_src invalidates the grid cache for free.
        if getattr(self, "_show_wcs_grid", False):
            cache_key = (pm_base.cacheKey(), int(sw), int(sh), mode, float(self.scale))
            if getattr(self, "_pm_src_wcs_key", None) != cache_key or getattr(self, "_pm_src_wcs", None) is None:
                pm_scaled = self._draw_wcs_grid_on_pixmap(pm_scaled)
                self._pm_src_wcs = pm_scaled
                self._pm_src_wcs_key = cache_key
            else:
                pm_scaled = self._pm_src_wcs

        if isinstance(self.label, ViewportImageCanvas):
            # Grid-on fallback (see the note at the top of this method). The
            # canvas is sized through request_full_size() -- that is what drives
            # the scroll range -- and it MUST come first, because it clears any
            # standing override. Then the baked pixmap goes in as the override.
            _sc = max(float(self.scale), 1e-9)
            self.label.request_full_size(
                pm_scaled.width(), pm_scaled.height(),
                max(1, int(round(pm_scaled.width() / _sc))),
                max(1, int(round(pm_scaled.height() / _sc))),
            )
            self.label.setPixmap(pm_scaled)
            return

        self.label.setPixmap(pm_scaled)
        self.label.resize(pm_scaled.size())
        return

    def apply_current_display_stretch(self, image=None):
        if not self.autostretch_enabled:
            return None

        lut = self._autostretch_lut_cache
        if lut is None:
            self._render(rebuild=True)
            lut = self._autostretch_lut_cache
        if lut is None:
            return None

        a = np.asarray(self.document.image if image is None else image)
        if a.size == 0:
            return None

        is_mono = (a.ndim == 2) or (a.ndim == 3 and a.shape[2] == 1)

        # Derive the LUT's bit-depth from its length so apply can't mismatch the
        # build (12-bit LUT = 4096 entries, 24-bit = 16,777,216). This is immune to
        # the display/autostretch_24bit setting being changed after the LUT was
        # built without the display cache being invalidated.
        lut0 = lut[0] if isinstance(lut, tuple) else lut   # tuple = unlinked color
        n = int(np.asarray(lut0).shape[0])
        use_24bit = (n > 4096)

        # mirror _render()'s pre-LUT normalization exactly
        if np.issubdtype(a.dtype, np.integer):
            info = np.iinfo(a.dtype)
            arr_f = a.astype(np.float32) / float(max(1, info.max))
        else:
            arr_f = a.astype(np.float32, copy=False)

        mx = float(arr_f.max()) if arr_f.size else 1.0
        if mx > 5.0:
            arr_f = arr_f / mx

        out = apply_autostretch_lut(
            arr_f, lut,
            linked=(not is_mono and self._autostretch_linked),
            use_24bit=use_24bit,           # explicit, from the LUT — not QSettings
        )
        return np.clip(np.asarray(out, dtype=np.float32), 0.0, 1.0)

    def _draw_wcs_grid_on_pixmap(self, pm_scaled: QPixmap) -> QPixmap:
        """
        Draw the WCS grid, with astropy's inverse-WCS warnings silenced.

        A grid line that leaves the frame asks the inverse WCS for a point it
        cannot reach, and for a TAN-SIP solution that inversion is iterative:
        astropy WARNS rather than raises ("all_world2pix failed to converge",
        "All-NaN slice encountered"). The painter already skips any sample
        that comes back non-finite, so the condition is handled -- but without
        this the log fills up on every repaint of a distorted field.

        catch_warnings() mutates global state, so it must be a context manager
        around the whole call: hand-rolled enter/exit would leak the filter
        into the rest of the application if painting ever raised.
        """
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            warnings.simplefilter("ignore", UserWarning)
            return self._draw_wcs_grid_on_pixmap_impl(pm_scaled)

    def _draw_wcs_grid_on_pixmap_impl(self, pm_scaled: QPixmap) -> QPixmap:
        """
        Your existing WCS painter logic, moved to operate on a QPixmap (already scaled).
        Runs ONLY on non-interactive redraw.
        """
        wcs2 = self._get_celestial_wcs()
        if wcs2 is None:
            return pm_scaled

        from PyQt6.QtGui import QPainter, QPen, QColor, QFont, QBrush
        from PyQt6.QtCore import QSettings, QRect
        from astropy.wcs.utils import proj_plane_pixel_scales
        import numpy as _np

        _settings = getattr(self, "_settings", None) or QSettings()
        pref_enabled   = _settings.value("wcs_grid/enabled", True, type=bool)
        pref_mode      = _settings.value("wcs_grid/mode", "auto", type=str)
        pref_step_unit = _settings.value("wcs_grid/step_unit", "deg", type=str)
        pref_step_val  = _settings.value("wcs_grid/step_value", 1.0, type=float)

        if not pref_enabled:
            return pm_scaled

        # Determine full image geometry from the science array (display pixmap is scaled)
        src = getattr(self.document, "image", None)
        if src is None:
            return pm_scaled
        H_full = int(np.asarray(src).shape[0])
        W_full = int(np.asarray(src).shape[1])

        # Pixel scales/FOV
        px_scales_deg = proj_plane_pixel_scales(wcs2)
        px_deg = float(max(px_scales_deg[0], px_scales_deg[1]))
        fov_deg = px_deg * float(max(W_full, H_full))

        # Grid steps are chosen AFTER the sky bounds are known: the RA step
        # depends on declination, so it cannot be settled here.

        # World bounds from corners
        # Sample the whole BORDER, not the four corners. Near a pole the
        # extreme declination lies part-way along an edge rather than at a
        # corner, so corner sampling reports a dec range far narrower than the
        # frame really covers -- the same trap the catalogue box fell into.
        _bn = 64
        _t = _np.linspace(0.0, 1.0, _bn)
        _bx = _np.concatenate([_t * (W_full - 1), _np.full(_bn, W_full - 1.0),
                               (1.0 - _t) * (W_full - 1), _np.zeros(_bn)])
        _by = _np.concatenate([_np.zeros(_bn), _t * (H_full - 1),
                               _np.full(_bn, H_full - 1.0), (1.0 - _t) * (H_full - 1)])
        try:
            ra_b, dec_b = wcs2.pixel_to_world_values(_bx, _by)
            _good = _np.isfinite(ra_b) & _np.isfinite(dec_b)
            ra_b, dec_b = _np.asarray(ra_b)[_good], _np.asarray(dec_b)[_good]
            if ra_b.size == 0:
                raise ValueError("no finite border samples")
            dec_min = float(_np.min(dec_b));  dec_max = float(_np.max(dec_b))
            # RA needs circular statistics: min/max of raw angles is wrong
            # across the 0/360 seam. Work relative to the mean DIRECTION, so
            # the span comes out right wherever the seam falls.
            _rr = _np.radians(ra_b)
            _ref = float(_np.degrees(_np.arctan2(_np.mean(_np.sin(_rr)),
                                                 _np.mean(_np.cos(_rr))))) % 360.0
            _off = ((ra_b - _ref + 180.0) % 360.0) - 180.0
            ra_min = _ref + float(_np.min(_off))
            ra_max = _ref + float(_np.max(_off))
            ra_shift = 0.0
        except Exception:
            ra_min, ra_max, dec_min, dec_max, ra_shift = 0.0, 360.0, -90.0, 90.0, 0.0

        # ── Is a celestial pole in the frame? ───────────────────────────────
        # Every line of constant RA runs through the pole, so once it is inside
        # the picture the RA range is the whole circle whatever the corners
        # say -- and the corner-based wrap test above cannot tell, because the
        # corner RAs scatter right around the sky.
        # Decide this with FORWARD transforms only, by WINDING NUMBER.
        #
        # Asking world_to_pixel_values where the pole lands looks simpler, but
        # for a TAN-SIP solution that is an iterative inversion, and probing a
        # pole 179 deg away makes it diverge -- the source of the
        # "all_world2pix failed to converge" and "All-NaN slice" warnings.
        #
        # Walk the border instead and add up the change in RA. RA is the angle
        # about the pole, so a border that encloses it turns through a full
        # 360 deg, and one that does not comes back to where it started. That
        # is exact, unlike comparing the pole's distance against the frame
        # radius: the corners lie further out than the edges, so a radius test
        # calls a pole "inside" while it sits beyond the top edge.
        pole_in_frame, pole_dec = False, 0.0
        try:
            _c_ra, _c_dec = wcs2.pixel_to_world_values(
                (W_full - 1) * 0.5, (H_full - 1) * 0.5)
            _c_dec = float(_c_dec)
            if _np.isfinite(_c_dec) and ra_b.size >= 8:
                _loop = _np.radians(_np.append(ra_b, ra_b[0]))
                _turn = float(_np.sum(_np.diff(_np.unwrap(_loop))))
                if abs(_turn) > _np.pi:          # a full turn, not a wobble
                    pole_in_frame = True
                    pole_dec = 90.0 if _c_dec >= 0.0 else -90.0
        except Exception:
            pass

        if pole_in_frame:
            ra_min, ra_max, ra_shift = 0.0, 360.0, 0.0
            if pole_dec > 0:
                dec_max = 90.0
            else:
                dec_min = -90.0

        # ── Separate steps for Dec and RA ───────────────────────────────────
        # Meridians converge: two lines of constant RA that differ by `step`
        # are only step*cos(dec) apart on the sky. At Dec +88.5 that is a
        # factor of 38, so one step shared between both axes draws a readable
        # Dec grid and a solid fan of RA lines.
        _NICE_DEC = [0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 15, 30]
        _NICE_RA  = [0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 15,
                     30, 45, 60, 90, 120, 180]
        _MAX_RA_LINES = 24

        if pref_mode == "fixed":
            dec_step = float(pref_step_val if pref_step_unit == "deg"
                             else (pref_step_val / 60.0))
            dec_step = max(1e-6, min(dec_step, 90.0))
            ra_step = dec_step
        else:
            target_lines = 8
            desired = max(fov_deg / target_lines, px_deg * 100)
            dec_step = min((x for x in _NICE_DEC if x >= desired), default=30)
            if pole_in_frame:
                # Meridians meet AT the pole, so "equal spacing on the sky" is
                # not a thing that exists here -- 1/cos(dec) runs away to
                # infinity and would leave a single line through the middle.
                # Evenly spaced spokes are what a star chart draws instead.
                _SPOKES = [15, 30, 45, 60, 90]
                ra_step = next((x for x in _SPOKES
                                if 360.0 / x <= _MAX_RA_LINES), 90)
            else:
                # Scale the RA step by 1/cos(dec) at the declination the
                # frame is CENTRED on. Using the extreme instead lets one
                # edge that creeps toward the pole blow the step out for the
                # whole picture -- a frame reaching Dec 89.9 would end up with
                # a single meridian through it.
                _dec_ref = min(89.9, abs(0.5 * (dec_min + dec_max)))
                _cosd = max(float(_np.cos(_np.radians(_dec_ref))), 1e-4)
                ra_step = min((x for x in _NICE_RA if x >= desired / _cosd),
                              default=180)

        # Whatever the arithmetic said, never draw more meridians than can be
        # told apart. With the pole in frame the span is the full 360 deg.
        _MIN_RA_LINES = 3
        _ra_span = 360.0 if pole_in_frame else max(1e-9, ra_max - ra_min)
        while (_ra_span / ra_step) > _MAX_RA_LINES:
            _bigger = [x for x in _NICE_RA if x > ra_step]
            if not _bigger:
                break
            ra_step = _bigger[0]
        # ...and a floor, so a frame near the pole does not end up with one
        # lonely meridian just because cos(dec) is small there.
        while (_ra_span / ra_step) < _MIN_RA_LINES:
            _smaller = [x for x in _NICE_RA if x < ra_step]
            if not _smaller:
                break
            ra_step = _smaller[-1]

        pm = QPixmap(pm_scaled)  # copy so we don’t mutate caller
        p = QPainter(pm)
        pen = QPen(QColor(255, 255, 255, 140))
        pen.setWidth(1)
        p.setPen(pen)

        # Scale factor between full-res image and pm_scaled
        s = float(pm.width()) / float(max(1, W_full))

        Wf, Hf = float(W_full), float(H_full)

        def draw_world_poly(xs_world, ys_world):
            try:
                px, py = wcs2.world_to_pixel_values(xs_world, ys_world)
            except Exception:
                return

            px = _np.asarray(px, dtype=float)
            py = _np.asarray(py, dtype=float)

            ok = _np.isfinite(px) & _np.isfinite(py)
            margin = float(max(Wf, Hf) * 2.0)
            ok &= (px > -margin) & (px < (Wf - 1.0 + margin))
            ok &= (py > -margin) & (py < (Hf - 1.0 + margin))

            for i in range(1, len(px)):
                if not (ok[i-1] and ok[i]):
                    continue
                x0 = float(px[i-1]) * s
                y0 = float(py[i-1]) * s
                x1 = float(px[i])   * s
                y1 = float(py[i])   * s
                if max(abs(x0), abs(y0), abs(x1), abs(y1)) > 2.0e9:
                    continue
                p.drawLine(int(x0), int(y0), int(x1), int(y1))

        ra_samples = _np.linspace(ra_min, ra_max, 512, dtype=float)
        ra_samples_wrapped = _np.mod(ra_samples + ra_shift, 360.0) if ra_shift else ra_samples
        dec_samples = _np.linspace(dec_min, dec_max, 512, dtype=float)

        def _frange(a, b, sstep):
            out = []
            x = a
            while x <= b + 1e-9:
                out.append(x)
                x += sstep
            return out

        def _round_to(x, sstep):
            return sstep * round(x / sstep)

        ra_start  = _round_to(ra_min, ra_step)
        dec_start = _round_to(dec_min, dec_step)

        # Parallels of Dec. With the pole in frame these close into circles
        # around it, so they have to be sampled right around the sky rather
        # than across the corner-derived RA span.
        if pole_in_frame:
            dec_ra_samples = _np.linspace(0.0, 360.0, 1441, dtype=float)
        else:
            dec_ra_samples = ra_samples_wrapped
        dec_values = [d for d in _frange(dec_start, dec_max, dec_step)
                      if -90.0 < d < 90.0]
        for dec in dec_values:
            draw_world_poly(dec_ra_samples, _np.full_like(dec_ra_samples, dec))

        # Meridians. Round the circle once when the pole is in frame, so the
        # spokes are evenly spaced instead of bunched where the corners fell.
        if pole_in_frame:
            # stop half a step short of 360 so the last spoke is not a
            # duplicate of the one at 0
            ra_values = [r % 360.0
                         for r in _frange(0.0, 360.0 - 0.5 * ra_step, ra_step)]
        else:
            ra_values = [(r + ra_shift) % 360.0
                         for r in _frange(ra_start, ra_max, ra_step)]
        for ra_w in ra_values:
            draw_world_poly(_np.full_like(dec_samples, ra_w), dec_samples)

        # Labels
        font = QFont()
        font.setPixelSize(11)
        p.setFont(font)
        text_pen  = QPen(QColor(255, 255, 255, 230))
        box_brush = QBrush(QColor(0, 0, 0, 140))
        p.setPen(text_pen)

        img_w = pm.width()
        img_h = pm.height()

        def _draw_label(x, y, txt, anchor="lt"):
            if not _np.isfinite([x, y]).all():
                return
            fm = p.fontMetrics()
            wtxt = fm.horizontalAdvance(txt) + 6
            htxt = fm.height() + 4

            if anchor == "lt":
                rx, ry = int(x) + 4, int(y) + 3
            elif anchor == "rt":
                rx, ry = int(x) - wtxt - 4, int(y) + 3
            elif anchor == "lb":
                rx, ry = int(x) + 4, int(y) - htxt - 3
            else:
                rx, ry = int(x) - wtxt // 2, int(y) + 3

            rx = max(0, min(rx, img_w - wtxt - 1))
            ry = max(0, min(ry, img_h - htxt - 1))

            rect = QRect(rx, ry, wtxt, htxt)
            p.save()
            p.setBrush(box_brush)
            p.setPen(Qt.PenStyle.NoPen)
            p.drawRoundedRect(rect, 4, 4)
            p.restore()
            p.drawText(rect.adjusted(3, 2, -3, -2),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, txt)

        # Labels are placed only when they are far enough from one that is
        # already down. Near a pole the meridians arrive almost on top of each
        # other, and one label per line turns the border into a wall of digits.
        _placed = []
        def _too_close(x, y, min_sep=46.0):
            for (px_, py_) in _placed:
                if abs(px_ - x) < min_sep and abs(py_ - y) < min_sep:
                    return True
            _placed.append((x, y))
            return False

        # DEC labels on left edge
        for dec in dec_values:
            try:
                x_pix, y_pix = wcs2.world_to_pixel_values((ra_min + ra_shift) % 360.0, dec)
                if not _np.isfinite([x_pix, y_pix]).all():
                    continue
                x_pix = min(max(x_pix, 0.0), Wf - 1.0)
                y_pix = min(max(y_pix, 0.0), Hf - 1.0)
                if _too_close(x_pix * s, y_pix * s):
                    continue
                _draw_label(x_pix * s, y_pix * s, self._deg_to_dms(dec), anchor="lt")
            except Exception:
                pass

        # RA labels. Anchored at the edge of the frame furthest from the pole,
        # because the meridians all meet AT the pole -- labelling the near edge
        # would pile every one of them onto the same few pixels.
        _ra_label_dec = dec_min if (not pole_in_frame or pole_dec > 0) else dec_max
        for ra_wrapped in ra_values:
            try:
                x_pix, y_pix = wcs2.world_to_pixel_values(ra_wrapped, _ra_label_dec)
                if not _np.isfinite([x_pix, y_pix]).all():
                    continue
                x_pix = min(max(x_pix, 0.0), Wf - 1.0)
                y_pix = min(max(y_pix, 0.0), Hf - 1.0)
                if _too_close(x_pix * s, y_pix * s):
                    continue
                _draw_label(x_pix * s, y_pix * s, self._deg_to_hms(ra_wrapped), anchor="ct")
            except Exception:
                pass

        p.end()
        return pm


    # ---------- interaction ----------
    def _zoom_to_scale(self, new_scale: float, *, anchor_vp: QPoint | None = None):
        """Set an absolute scale while keeping the image pixel under *anchor_vp* fixed.

        If *anchor_vp* is None, the viewport centre is used. Scrollbars are clamped
        when the requested centre cannot be kept (near edges / image smaller than
        the viewport), which is the only case that may shift toward a corner.
        """
        if getattr(self, "_qimg_src", None) is None and getattr(self, "_pm_src", None) is None:
            return

        old_scale = float(self.scale)
        new_scale = max(self._min_scale, min(float(new_scale), self._max_scale))
        if abs(new_scale - old_scale) < 1e-8:
            return

        vp = self.scroll.viewport()
        hbar = self.scroll.horizontalScrollBar()
        vbar = self.scroll.verticalScrollBar()

        if anchor_vp is None:
            anchor_vp = QPoint(vp.width() // 2, vp.height() // 2)

        x_label_pre = hbar.value() + anchor_vp.x()
        y_label_pre = vbar.value() + anchor_vp.y()

        xi = x_label_pre / max(old_scale, 1e-12)
        yi = y_label_pre / max(old_scale, 1e-12)

        self.scale = new_scale
        self._present_scaled(interactive=True)

        # Keep the pre-zoom image pixel under the same viewport point
        x_label_post = xi * new_scale
        y_label_post = yi * new_scale

        new_h = int(round(x_label_post - anchor_vp.x()))
        new_v = int(round(y_label_post - anchor_vp.y()))

        # The scroll area updates its scrollbar ranges from the just-resized label
        # only on a deferred layout pass, so hbar/vbar max/min may still hold the
        # PRE-zoom range here. Setting the value against the stale range clamps it
        # wrong and the view jumps toward a corner once the range catches up.
        # Refresh the range from the label's synchronously-updated size first.
        max_h = max(0, int(self.label.width())  - int(vp.width()))
        max_v = max(0, int(self.label.height()) - int(vp.height()))
        hbar.setRange(0, max_h)
        vbar.setRange(0, max_v)
        hbar.setPageStep(int(vp.width()))
        vbar.setPageStep(int(vp.height()))

        new_h = max(0, min(new_h, max_h))
        new_v = max(0, min(new_v, max_v))

        hbar.setValue(new_h)
        vbar.setValue(new_v)

        self._update_zoom_label()
        self._schedule_emit_view_transform()
        self._request_zoom_redraw()

    def _zoom_at_anchor(self, factor: float):
        if getattr(self, "_qimg_src", None) is None and getattr(self, "_pm_src", None) is None:
            return

        old_scale = float(self.scale)
        new_scale = max(self._min_scale, min(old_scale * float(factor), self._max_scale))
        if abs(new_scale - old_scale) < 1e-8:
            return

        vp = self.scroll.viewport()
        try:
            anchor_vp = vp.mapFromGlobal(QCursor.pos())
        except Exception:
            anchor_vp = None

        if (anchor_vp is None) or (not vp.rect().contains(anchor_vp)):
            anchor_vp = None  # _zoom_to_scale defaults to viewport centre

        self._zoom_to_scale(new_scale, anchor_vp=anchor_vp)

    def _zoom_settle_needs_rebuild(self) -> bool:
        """
        True when the cached display pixmap is under-resolved for the current
        zoom — i.e. we are UPSAMPLING _pm_src and a rebuild from the full-res
        source would actually recover detail (and we are still below the
        8192-per-side render cap).

        This is what makes zoom-in sharp again now that _pm_src is rasterized at
        display scale instead of 1:1. It is deliberately independent of the
        smooth-zoom-settle *interpolation* preference.
        """
        if isinstance(self.label, ViewportImageCanvas):
            # The viewport canvas always paints at true 1:1 for the current zoom;
            # there is no under-resolved pixmap to rebuild, so skip the settle.
            return False

        pm = getattr(self, "_pm_src", None)
        if pm is None or pm.isNull():
            return False

        src_w = int(getattr(self, "_pm_src_src_w", 0) or 0)
        src_h = int(getattr(self, "_pm_src_src_h", 0) or 0)
        if src_w <= 0 or src_h <= 0:
            # Fall back to inferring source size from the recorded build scale.
            base_scale = float(getattr(self, "_pm_src_scale", 0.0) or 0.0)
            if base_scale <= 0.0:
                return False
            src_w = max(1, int(round(pm.width()  / base_scale)))
            src_h = max(1, int(round(pm.height() / base_scale)))

        # Effective source-scale currently baked into the cached pixmap.
        cur_eff = pm.width() / float(src_w)

        # Best effective scale a rebuild could produce at the current zoom,
        # honouring both the 8192-per-side cap and the 1.0 cap that _render()
        # applies (we never build the numpy buffer larger than source).
        _max_side = 8192
        achievable = min(float(self.scale),
                         1.0,
                         _max_side / float(src_w),
                         _max_side / float(src_h))

        tol = 0.01
        return (float(self.scale) > cur_eff * (1.0 + tol)) and \
               (achievable > cur_eff * (1.0 + tol))

    def _recalc_overlay_widget(self):
        """Lazily build the small translucent 'recalculating' overlay."""
        lbl = getattr(self, "_recalc_overlay", None)
        if lbl is not None:
            return lbl
        try:
            vp = self.scroll.viewport()
        except Exception:
            return None
        lbl = QLabel(vp)
        lbl.setStyleSheet(
            "background: rgba(0,0,0,0.55); color: rgba(255,255,255,0.90);"
            " padding: 3px 8px; border-radius: 6px; font-size: 11px;"
        )
        lbl.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        lbl.hide()
        self._recalc_overlay = lbl
        return lbl

    def _show_recalc_overlay(self):
        lbl = self._recalc_overlay_widget()
        if lbl is None:
            return
        lbl.setText(
            self.tr("Recalculating display stretch…")
            if getattr(self, "autostretch_enabled", False)
            else self.tr("Refreshing view…")
        )
        lbl.adjustSize()
        try:
            vp = self.scroll.viewport()
            m = 8
            lbl.move(m, max(m, vp.height() - lbl.height() - m))
        except Exception:
            pass
        lbl.show()
        lbl.raise_()

    def _hide_recalc_overlay(self):
        lbl = getattr(self, "_recalc_overlay", None)
        if lbl is not None:
            lbl.hide()

    def _set_canvas_interacting(self, on: bool):
        """Tell the canvas a gesture is in progress.

        Fast (nearest) blits while the wheel is still turning or a pan is
        being dragged; the smooth one is for when it stops -- which is the
        whole of what "smooth zoom FINAL redraw" promises. The canvas has
        had set_interacting() since it was written and nothing ever called
        it, so it sat False forever; that was harmless only because the
        smooth blit was capped at scale < 1.0. It is not capped now.

        Does nothing on the plain-QLabel path, which has no such notion.
        """
        lbl = getattr(self, "label", None)
        fn = getattr(lbl, "set_interacting", None)
        if fn is None:
            return
        try:
            fn(bool(on))
            lbl.update()
        except RuntimeError:
            pass

    def _request_zoom_redraw(self):
        if getattr(self, "_zoom_timer", None) is None:
            self._zoom_timer = QTimer(self)
            self._zoom_timer.setSingleShot(True)
            self._zoom_timer.timeout.connect(self._apply_zoom_redraw)

        # Single-shot + restart-on-every-zoom collapses a wheel/click burst into
        # ONE settle ~180ms after the user stops. Only surface the overlay when
        # the settle will actually re-rasterize (zoomed in past the cached
        # resolution); zooming out costs nothing and stays silent.
        if self._zoom_settle_needs_rebuild():
            self._show_recalc_overlay()

        self._set_canvas_interacting(True)
        self._zoom_timer.start(500)


    def _apply_zoom_redraw(self):
        if getattr(self, "_pm_src", None) is None:
            self._set_canvas_interacting(False)
            self._hide_recalc_overlay()
            return
        try:
            if self._zoom_settle_needs_rebuild():
                # Re-rasterize _pm_src from the full-res source at the settled
                # scale. _render() ends on a smooth present when smooth-zoom is
                # on, else a crisp (nearest) present — either way at full res.
                self._render(rebuild=True)
            elif getattr(self, "_smooth_zoom", True):
                # Nothing to re-rasterize (zoomed out, or already at native/cap):
                # just give the smooth final present the settle used to provide.
                self._present_scaled(interactive=False)
        finally:
            self._set_canvas_interacting(False)
            self._hide_recalc_overlay()



    def has_active_preview(self) -> bool:
        return self._active_source_kind == "preview" and self._active_preview_id is not None

    def current_preview_roi(self) -> tuple[int,int,int,int] | None:
        """
        Returns (x, y, w, h) in FULL image coordinates if a preview tab is active, else None.
        """
        if not self.has_active_preview():
            return None
        src = next((p for p in self._previews if p["id"] == self._active_preview_id), None)
        return None if src is None else tuple(src["roi"])

    def current_preview_name(self) -> str | None:
        if not self.has_active_preview():
            return None
        src = next((p for p in self._previews if p["id"] == self._active_preview_id), None)
        return None if src is None else src["name"]



    def _find_main_window(self):
        p = self.parent()
        while p is not None and not hasattr(p, "docman"):
            p = p.parent()
        return p

    def event(self, e):
        """Override event() to handle native macOS gestures (pinch zoom)."""
        # Handle native gestures (macOS trackpad pinch zoom)
        if e.type() == QEvent.Type.NativeGesture:
            gesture_type = e.gestureType()

            if gesture_type == Qt.NativeGestureType.BeginNativeGesture:
                # Start of pinch gesture - store initial scale
                self._gesture_zoom_start = self.scale
                e.accept()
                return True

            elif gesture_type == Qt.NativeGestureType.ZoomNativeGesture:
                # Ongoing pinch zoom - value() is cumulative scale factor
                # Typical values: -0.5 to +0.5 for moderate pinches
                zoom_delta = e.value()

                # Convert delta to zoom factor
                # Use smaller multiplier for smoother feel (0.5x damping)
                factor = 1.0 + (zoom_delta * 0.5)

                # Apply incremental zoom
                self._zoom_at_anchor(factor)
                e.accept()
                return True

            elif gesture_type == Qt.NativeGestureType.EndNativeGesture:
                # End of pinch gesture - cleanup
                self._gesture_zoom_start = None
                e.accept()
                return True

        # Let parent handle all other events
        return super().event(e)



    def eventFilter(self, obj, ev):
        is_on_view = (obj is self.label) or (obj is self.scroll.viewport())

        # 0) PREVIEW-SELECT MODE: consume mouse events first so earlier branches don't steal them
        if self._preview_select_mode and is_on_view:
            vp = self.scroll.viewport()
            if ev.type() == QEvent.Type.MouseButtonPress and ev.button() == Qt.MouseButton.LeftButton:
                vp_pos = obj.mapTo(vp, ev.pos())
                self._rubber_origin = vp_pos
                if self._rubber is None:
                    self._rubber = QRubberBand(QRubberBand.Shape.Rectangle, vp)
                self._rubber.setGeometry(QRect(self._rubber_origin, QSize(1, 1)))
                self._rubber.show()
                ev.accept(); return True

            if ev.type() == QEvent.Type.MouseMove and self._rubber is not None and self._rubber_origin is not None:
                vp_pos = obj.mapTo(vp, ev.pos())
                rect = QRect(self._rubber_origin, vp_pos).normalized()
                self._rubber.setGeometry(rect)
                ev.accept(); return True

            if ev.type() == QEvent.Type.MouseButtonRelease and self._rubber is not None and self._rubber_origin is not None:
                vp_pos = obj.mapTo(vp, ev.pos())
                rect = QRect(self._rubber_origin, vp_pos).normalized()
                self._finish_preview_rect(rect)
                ev.accept(); return True
            # don’t swallow unrelated events

        # 1) Ctrl + wheel → zoom
        # 1) Mouse wheel → zoom
        #    Keep Ctrl+wheel working, but also allow plain wheel zoom.
        if ev.type() == QEvent.Type.Wheel:
            # Try pixelDelta first (macOS trackpad gives smooth values)
            dy = ev.pixelDelta().y()

            if dy != 0:
                # Smooth trackpad scrolling: use smaller base factor
                # Scale proportionally to delta magnitude for natural feel
                abs_dy = abs(dy)

                # Keep Ctrl as a slightly stronger zoom gesture if user uses it,
                # while plain wheel still zooms naturally.
                ctrl_down = bool(ev.modifiers() & Qt.KeyboardModifier.ControlModifier)

                if abs_dy <= 3:
                    base_factor = 1.012 if ctrl_down else 1.010
                elif abs_dy <= 10:
                    base_factor = 1.025 if ctrl_down else 1.020
                else:
                    base_factor = 1.040 if ctrl_down else 1.030

                factor = base_factor if dy > 0 else 1 / base_factor

            else:
                # Traditional mouse wheel: use angleDelta
                dy = ev.angleDelta().y()
                if dy == 0:
                    return True

                ctrl_down = bool(ev.modifiers() & Qt.KeyboardModifier.ControlModifier)

                # Keep old-ish Ctrl behavior, but let normal wheel zoom too
                step = 1.15 if ctrl_down else 1.12
                factor = step if dy > 0 else 1 / step

            self._zoom_at_anchor(factor)
            ev.accept()
            return True
        
        # 2) Space+click → start readout
        if ev.type() == QEvent.Type.MouseButtonPress:
            if self._space_down and ev.button() == Qt.MouseButton.LeftButton:
                vp_pos = obj.mapTo(self.scroll.viewport(), ev.pos())
                res = self._sample_image_at_viewport_pos(vp_pos)
                if res is not None:
                    xi, yi, sample = res
                    self._show_readout(xi, yi, sample)
                    self._update_loupe(xi, yi, vp_pos, sample)
                self._readout_dragging = True
                return True
            return False

        # 3) Space+drag → live readout
        if ev.type() == QEvent.Type.MouseMove:
            if self._readout_dragging:
                vp_pos = obj.mapTo(self.scroll.viewport(), ev.pos())
                res = self._sample_image_at_viewport_pos(vp_pos)
                if res is not None:
                    xi, yi, sample = res
                    self._show_readout(xi, yi, sample)
                    self._update_loupe(xi, yi, vp_pos, sample)
                return True
            return False

        # 4) Release → stop live readout
        if ev.type() == QEvent.Type.MouseButtonRelease:
            if self._readout_dragging:
                self._readout_dragging = False
                self._hide_loupe()
                return True
            return False

        sw = self._mdi_subwindow()
        if sw is not None and obj is sw:
            et = ev.type()
            if et in (QEvent.Type.WindowStateChange, QEvent.Type.Show, QEvent.Type.Resize):
                QTimer.singleShot(0, self._update_inline_title_and_buttons)

        return super().eventFilter(obj, ev)

    def _viewport_pos_to_image_xy(self, vp_pos: QPoint) -> tuple[int, int] | None:
        """
        Convert a point in viewport coordinates to FULL image pixel coordinates.
        Returns None if the point is outside the displayed pixmap (in margins).
        """
        # Convert viewport point into label coordinates
        p_label = self.label.mapFrom(self.scroll.viewport(), vp_pos)

        if isinstance(self.label, ViewportImageCanvas):
            pm_w, pm_h = int(self.label.width()), int(self.label.height())
            off_x = off_y = 0
        else:
            pm = self.label.pixmap()
            if pm is None:
                return None
            # If label is larger than pixmap, pixmap may be centered inside label.
            pm_w, pm_h = pm.width(), pm.height()
            lbl_w, lbl_h = self.label.width(), self.label.height()
            off_x = max(0, (lbl_w - pm_w) // 2)
            off_y = max(0, (lbl_h - pm_h) // 2)

        px = p_label.x() - off_x
        py = p_label.y() - off_y

        # Outside the drawn pixmap area → clamp
        px = max(0, min(px, pm_w - 1))
        py = max(0, min(py, pm_h - 1))

        s = max(float(self.scale), 1e-12)

        # pixmap pixels -> image pixels (pm = image * scale)
        xi = int(round(px / s))
        yi = int(round(py / s))
        return xi, yi

    def _finish_preview_rect(self, vp_rect: QRect):
        if vp_rect.width() < 4 or vp_rect.height() < 4:
            self._cancel_rubber()
            return

        # Convert the two corners from viewport space to image space
        p0 = self._viewport_pos_to_image_xy(vp_rect.topLeft())
        p1 = self._viewport_pos_to_image_xy(vp_rect.bottomRight())

        if p0 is None or p1 is None:
            # User dragged into margins; you can either cancel or clamp.
            # Cancel is simplest:
            self._cancel_rubber()
            return

        x0, y0 = p0
        x1, y1 = p1

        x = min(x0, x1)
        y = min(y0, y1)
        w = abs(x1 - x0)
        h = abs(y1 - y0)

        if w < 1 or h < 1:
            self._cancel_rubber()
            return

        self._create_preview_from_roi((x, y, w, h))
        self._cancel_rubber()

    def _create_preview_from_roi(self, roi: tuple[int,int,int,int]):
        """
        roi: (x, y, w, h) in FULL IMAGE coordinates
        """
        arr = np.asarray(self.document.image)
        H, W = (arr.shape[0], arr.shape[1]) if arr.ndim >= 2 else (0, 0)
        x, y, w, h = roi
        # clamp to image bounds
        x = max(0, min(x, max(0, W-1)))
        y = max(0, min(y, max(0, H-1)))
        w = max(1, min(w, W - x))
        h = max(1, min(h, H - y))

        crop = arr[y:y+h, x:x+w].copy()  # isolate for preview

        pid = self._next_preview_id
        self._next_preview_id += 1
        name = self.tr("Preview {0} ({1}×{2})").format(pid, w, h)

        self._previews.append({"id": pid, "name": name, "roi": (x, y, w, h), "arr": crop})

        # Build a tab with a simple QLabel viewer (reuses global rendering through _render)
        host = QWidget(self)
        l = QVBoxLayout(host); l.setContentsMargins(0,0,0,0)
        # For simplicity, we reuse the SAME scroll/label pipeline; the source image is switched in _render
        # but we still want a local label so the tab displays something. Make a tiny label holder:
        holder = QLabel(" ")  # placeholder; we still render into self.label (single view)
        holder.setMinimumHeight(1)
        l.addWidget(holder)

        host._preview_id = pid  # attach id for lookups
        idx = self._tabs.addTab(host, name)
        self._tabs.setCurrentIndex(idx)
        self._tabs.tabBar().setVisible(True)  # show tabs when first preview appears

        # Switch active source and redraw
        self._active_source_kind = "preview"
        self._active_preview_id = pid
        self._render(True)
        self._update_replay_button()  
        mw = self._find_main_window()
        if mw is not None and getattr(mw, "_auto_fit_on_resize", False):
            try:
                mw._zoom_active_fit()
            except Exception:
                pass        

    def mousePressEvent(self, e):
        # If we're defining a preview ROI, don't start panning here
        if self._preview_select_mode:
            e.ignore()             # let the eventFilter (label/viewport) handle it
            return

        if e.button() == Qt.MouseButton.LeftButton:
            if self._space_down:
                vp = self.scroll.viewport()
                vp_pos = vp.mapFrom(self, e.pos())
                res = self._sample_image_at_viewport_pos(vp_pos)
                if res is not None:
                    xi, yi, sample = res
                    self._show_readout(xi, yi, sample)
                    self._update_loupe(xi, yi, vp_pos, sample)
                self._readout_dragging = True
                return

            # normal pan mode
            self._dragging = True
            self._set_canvas_interacting(True)
            self._pan_live = True   
            self._drag_start = e.pos()

            # NEW: emit once at drag start so linked views sync instantly
            self._emit_view_transform()
            return

        super().mousePressEvent(e)

    def _parse_probe_sample(self, sample):
        """Extract raw (r,g,b) or mono k from a probe `sample` value.

        Mirrors the historical status-bar logic exactly so the loupe and the
        toolbar always report identical pixel values. Returns (r, g, b, k)
        where the unused ones are None.
        """
        r = g = b = k = None
        if isinstance(sample, dict):
            if "mono" in sample:
                try:
                    k = float(sample["mono"])
                except Exception:
                    k = sample["mono"]
            elif all(ch in sample for ch in ("r", "g", "b")):
                try:
                    r = float(sample["r"]); g = float(sample["g"]); b = float(sample["b"])
                except Exception:
                    r = sample["r"]; g = sample["g"]; b = sample["b"]
            else:
                for v in sample.values():
                    try:
                        k = float(v)
                        break
                    except Exception:
                        continue
        elif isinstance(sample, (list, tuple)):
            if len(sample) == 1:
                try:
                    k = float(sample[0])
                except Exception:
                    k = sample[0]
            elif len(sample) >= 3:
                try:
                    r = float(sample[0]); g = float(sample[1]); b = float(sample[2])
                except Exception:
                    r, g, b = sample[0], sample[1], sample[2]
        elif sample is not None:
            try:
                k = float(sample)
            except Exception:
                k = sample
        return r, g, b, k

    def _probe_radec(self, xi, yi):
        """Return (ra_deg, dec_deg) at pixel (xi, yi), or (None, None)."""
        wcs2 = self._get_celestial_wcs()
        if wcs2 is None:
            return None, None
        try:
            ra_deg, dec_deg = map(float, wcs2.pixel_to_world_values(float(xi), float(yi)))
            return ra_deg, dec_deg
        except Exception:
            return None, None

    @staticmethod
    def _fmt_ra_hms(ra_deg, sec_prec=1):
        """Compact RA as HH:MM:SS(.s), with a rounding-carry guard."""
        ra_h = (float(ra_deg) / 15.0) % 24.0
        hh = int(ra_h)
        rem = (ra_h - hh) * 60.0
        mm = int(rem)
        ss = (rem - mm) * 60.0
        q = 10 ** sec_prec
        if round(ss * q) >= 60 * q:
            ss = 0.0; mm += 1
            if mm >= 60:
                mm = 0; hh = (hh + 1) % 24
        width = 2 + (sec_prec + 1 if sec_prec else 0)
        return f"{hh:02d}:{mm:02d}:{ss:0{width}.{sec_prec}f}"

    @staticmethod
    def _fmt_dec_dms(dec_deg, sec_prec=0):
        """Compact Dec as +DD:MM:SS(.s), with a rounding-carry guard."""
        dec_deg = float(dec_deg)
        sign = "+" if dec_deg >= 0 else "-"
        d = abs(dec_deg)
        dd = int(d)
        rem = (d - dd) * 60.0
        mm = int(rem)
        ss = (rem - mm) * 60.0
        q = 10 ** sec_prec
        if round(ss * q) >= 60 * q:
            ss = 0.0; mm += 1
            if mm >= 60:
                mm = 0; dd += 1
        width = 2 + (sec_prec + 1 if sec_prec else 0)
        return f"{sign}{dd:02d}:{mm:02d}:{ss:0{width}.{sec_prec}f}"

    def _loupe_info_lines(self, xi, yi, sample):
        """Build the compact lines shown inside the loupe: RGB/K then a,d."""
        r, g, b, k = self._parse_probe_sample(sample)
        lines = []

        if r is not None and g is not None and b is not None:
            try:
                lines.append(f"R {float(r):.4f}  G {float(g):.4f}  B {float(b):.4f}")
            except Exception:
                lines.append(f"R {r}  G {g}  B {b}")
        elif k is not None:
            doc = getattr(self, "document", None)
            meta = getattr(doc, "metadata", {}) or {}
            if meta.get("is_count_layer"):
                try:
                    cnt = int(round(float(k) * float(meta.get("count_max", 1.0))))
                    lines.append(f"N {cnt}")
                except Exception:
                    lines.append(f"K {k}")
            else:
                try:
                    lines.append(f"K {float(k):.4f}")
                except Exception:
                    lines.append(f"K {k}")

        ra_deg, dec_deg = self._probe_radec(xi, yi)
        if ra_deg is not None and dec_deg is not None:
            # Greek alpha (RA) / delta (Dec), PixInsight-style, to save room
            lines.append(f"\u03b1 {self._fmt_ra_hms(ra_deg, 1)}")
            lines.append(f"\u03b4 {self._fmt_dec_dms(dec_deg, 0)}")
        return lines

    def _show_readout(self, xi, yi, sample):
        mw = self._find_main_window()
        if mw is None:
            return

        # We want raw float prints, never 16-bit normalized
        r, g, b, k = self._parse_probe_sample(sample)

        msg = f"x={xi}  y={yi}"

        if r is not None and g is not None and b is not None:
            try:
                msg += f"   R={float(r):.6f}  G={float(g):.6f}  B={float(b):.6f}"
            except Exception:
                msg += f"   R={r}  G={g}  B={b}"
        elif k is not None:
            try:
                msg += f"   K={float(k):.6f}"
            except Exception:
                msg += f"   K={k}"
        else:
            # final fallback if everything was weird
            msg += "   K=?"

        # ---- WCS ----
        ra_deg, dec_deg = self._probe_radec(xi, yi)
        if ra_deg is not None and dec_deg is not None:
            try:
                # RA
                ra_h = ra_deg / 15.0
                ra_hh = int(ra_h)
                ra_mm = int((ra_h - ra_hh) * 60.0)
                ra_ss = ((ra_h - ra_hh) * 60.0 - ra_mm) * 60.0

                # Dec
                sign = "+" if dec_deg >= 0 else "-"
                d = abs(dec_deg)
                dec_dd = int(d)
                dec_mm = int((d - dec_dd) * 60.0)
                dec_ss = ((d - dec_dd) * 60.0 - dec_mm) * 60.0

                msg += (
                    f"   RA={ra_hh:02d}:{ra_mm:02d}:{ra_ss:05.2f}"
                    f"  Dec={sign}{dec_dd:02d}:{dec_mm:02d}:{dec_ss:05.2f}"
                )
            except Exception:
                pass

        # ---- Count layer readout: show actual integer count, not normalized float ----
        doc = getattr(self, "document", None)
        meta = getattr(doc, "metadata", {}) or {}
        if meta.get("is_count_layer") and k is not None:
            count_max = float(meta.get("count_max", 1.0))
            actual_count = int(round(k * count_max))
            msg = msg.replace(f"K={k:.6f}", f"frames_rejected={actual_count}")

        mw.statusBar().showMessage(msg)



    # 1) helper to build ROI-adjusted WCS (keeps projection/rotation/CD/PC intact)
    def _wcs_for_roi(self, base_wcs, roi, arr_shape=None):
        # roi = (x, y, w, h) in FULL-image pixel coords
        import numpy as np
        if base_wcs is None or roi is None:
            return base_wcs
        x, y, w, h = map(int, roi)
        wnew = base_wcs.deepcopy()
        # shift reference pixel into the cropped frame
        wnew.wcs.crpix = wnew.wcs.crpix - np.array([float(x), float(y)], dtype=float)
        # tell astropy the new image size for grid/edge computations
        try:
            wnew.array_shape = (h, w)
            wnew.pixel_shape = (w, h)
        except Exception:
            pass
        # prefer 2-D celestial
        try:
            cel = getattr(wnew, "celestial", None)
            if cel is not None and getattr(cel, "naxis", 2) == 2:
                return cel
        except Exception:
            pass
        return wnew


    # 2) make _get_celestial_wcs ROI-aware
    def _get_celestial_wcs(self):
        """
        Return the *correct* celestial WCS for whatever the user is actually
        seeing in this view.

        - On the Full tab: just use the document's WCS / header.
        - On a Preview tab: prefer the ROI backing doc's WCS from DocManager.
          If that's not available, synthesize a cropped header from the base
          header + preview ROI via _compute_cropped_wcs().
        """
        doc = getattr(self, "document", None)
        if doc is None:
            return None

        # -----------------------------
        # FULL IMAGE (no preview active)
        # -----------------------------
        if not self.has_active_preview():
            meta = getattr(doc, "metadata", {}) or {}
            w = meta.get("wcs")
            if isinstance(w, _AstroWCS):
                try:
                    wc = getattr(w, "celestial", None)
                    return wc if (wc is not None and getattr(wc, "naxis", 2) == 2) else w
                except Exception:
                    return w

            hdr = (
                meta.get("original_header")
                or meta.get("fits_header")
                or meta.get("header")
            )
            if hdr is None:
                return None

            w = build_celestial_wcs(hdr)
            if w is not None:
                meta["wcs"] = w
            return w

        # -----------------------------
        # PREVIEW TAB (ROI view)
        # -----------------------------
        roi = self.current_preview_roi()
        if roi is None:
            return None

        # Base document is the full image doc; backing_doc may be the ROI doc
        base_doc = getattr(self, "base_document", None) or doc
        base_meta = getattr(base_doc, "metadata", {}) or {}

        dm = getattr(self, "_docman", None)
        backing_doc = None
        if dm is not None:
            try:
                backing_doc = dm.get_document_for_view(self)
            except Exception:
                backing_doc = None

        # 1) If DocManager has a separate ROI doc for this view, use ITS WCS
        if backing_doc is not None and backing_doc is not base_doc:
            bmeta = getattr(backing_doc, "metadata", {}) or {}
            w = bmeta.get("wcs")
            if isinstance(w, _AstroWCS):
                try:
                    wc = getattr(w, "celestial", None)
                    return wc if (wc is not None and getattr(wc, "naxis", 2) == 2) else w
                except Exception:
                    return w

            hdr = (
                bmeta.get("original_header")
                or bmeta.get("fits_header")
                or bmeta.get("header")
            )
            if hdr is not None:
                w = build_celestial_wcs(hdr)
                if w is not None:
                    bmeta["wcs"] = w
                    return w

        # 2) Fallback: synthesize cropped WCS from base header + ROI
        hdr_full = (
            base_meta.get("original_header")
            or base_meta.get("fits_header")
            or base_meta.get("header")
        )
        if hdr_full is None:
            return None

        cache_key = f"_preview_wcs_{self._active_preview_id}"
        cached = base_meta.get(cache_key)
        if isinstance(cached, _AstroWCS):
            try:
                wc = getattr(cached, "celestial", None)
                return wc if (wc is not None and getattr(wc, "naxis", 2) == 2) else cached
            except Exception:
                pass

        try:
            x, y, w, h = map(int, roi)
            cropped_hdr = _compute_cropped_wcs(hdr_full, x, y, w, h)
            wcs = build_celestial_wcs(cropped_hdr)
        except Exception:
            wcs = None

        if wcs is not None:
            base_meta[cache_key] = wcs
        return wcs


    def _extract_wcs_from_doc(self):
        """
        Try to get an astropy WCS from the current document or a sensible parent.
        Caches the resolved WCS on whichever doc we pulled it from.
        """
        doc = getattr(self, "document", None)
        if doc is None:
            return None

        def _try_on_meta(meta: dict):
            # (1) literal WCS object stored?
            w = meta.get("wcs")
            if isinstance(w, _AstroWCS):
                return w
            # (2) any header-like thing present?
            hdr = meta.get("original_header") or meta.get("fits_header") or meta.get("header")
            return build_celestial_wcs(hdr)

        # 1) current doc (+ cache)
        meta = getattr(doc, "metadata", {}) or {}
        if "_astropy_wcs" in meta:
            return meta["_astropy_wcs"]
        w = _try_on_meta(meta)
        if w is not None:
            meta["_astropy_wcs"] = w
            return w

        # 2) likely parents/sources
        candidates = []

        base = getattr(self, "base_document", None)
        if base is not None and base is not doc:
            candidates.append(base)

        dm = getattr(self, "_docman", None)
        if dm is not None and hasattr(dm, "get_document_for_view"):
            try:
                src = dm.get_document_for_view(self)
                if src is not None and src is not doc and src is not base:
                    candidates.append(src)
            except Exception:
                pass

        src_uid = meta.get("wcs_source_doc_uid") or meta.get("base_doc_uid")
        if src_uid is not None:
            try:
                from setiastro.saspro.doc_manager import DocManager
                reg = getattr(DocManager, "_global_registry", {})
                by_uid = reg.get(src_uid)
                if by_uid and by_uid not in candidates and by_uid is not doc and by_uid is not base:
                    candidates.append(by_uid)
            except Exception:
                pass

        for cand in candidates:
            m = getattr(cand, "metadata", {}) or {}
            if "_astropy_wcs" in m:
                meta["_astropy_wcs"] = m["_astropy_wcs"]
                return m["_astropy_wcs"]
            w = _try_on_meta(m)
            if w is not None:
                m["_astropy_wcs"] = w
                meta["_astropy_wcs"] = w
                return w

        return None


  
    def mouseMoveEvent(self, e):
        # While defining preview ROI, let the eventFilter drive the QRubberBand
        if self._preview_select_mode:
            e.ignore()
            return

        if self._readout_dragging:
            vp = self.scroll.viewport()
            vp_pos = vp.mapFrom(self, e.pos())
            res = self._sample_image_at_viewport_pos(vp_pos)
            if res is not None:
                xi, yi, sample = res
                self._show_readout(xi, yi, sample)
                self._update_loupe(xi, yi, vp_pos, sample)
            return

        if self._dragging:
            delta = e.pos() - self._drag_start
            hbar = self.scroll.horizontalScrollBar()
            vbar = self.scroll.verticalScrollBar()
            # Coalesce the pan into a SINGLE linked emit. Previously each of the
            # two setValue() calls fired the scroll-changed slot -> emit, plus the
            # explicit emit below: up to 3 relays to every peer per mouse-move.
            self._suppress_link_emit = True
            try:
                hbar.setValue(hbar.value() - delta.x())
                vbar.setValue(vbar.value() - delta.y())
            finally:
                self._suppress_link_emit = False
            self._drag_start = e.pos()
            self._emit_view_transform_now()
            return

        super().mouseMoveEvent(e)



    def mouseReleaseEvent(self, e):
        if self._preview_select_mode:
            e.ignore(); return
        if e.button() == Qt.MouseButton.LeftButton:
            self._dragging = False
            self._pan_live = False
            self._set_canvas_interacting(False)
            self._readout_dragging = False
            self._hide_loupe()
            self._emit_view_transform()
            return
        super().mouseReleaseEvent(e)


    def closeEvent(self, e):
        # Cancel pending timers before teardown so they can't fire into
        # a partially-destroyed widget and trigger segfaults
        try:
            zt = getattr(self, "_zoom_timer", None)
            if zt is not None:
                zt.stop()
            self._hide_recalc_overlay()
        except Exception:
            pass
        try:
            lt = getattr(self, "_link_emit_timer", None)
            if lt is not None:
                lt.stop()
        except Exception:
            pass

        mw = self._find_main_window()
        doc = getattr(self, "document", None)

        force = bool(getattr(mw, "_force_close_all", False))

        if not force and doc is not None:
            should_warn = False
            if mw and hasattr(mw, "_document_has_edits"):
                should_warn = mw._document_has_edits(doc)
            else:
                try:
                    should_warn = bool(doc.can_undo())
                except Exception:
                    should_warn = False

            if should_warn:
                r = QMessageBox.question(
                    self, self.tr("Close Image?"),
                    self.tr("This image has edits that aren't applied/saved.\nClose anyway?"),
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                if r != QMessageBox.StandardButton.Yes:
                    e.ignore()
                    return

        try:
            if hasattr(self, "_docman") and self._docman is not None:
                self._docman.imageRegionUpdated.disconnect(self._on_doc_region_updated)
                try:
                    self._docman.imageRegionUpdated.disconnect(self._on_docman_nudge)
                except Exception:
                    pass
                if hasattr(self._docman, "previewRepaintRequested"):
                    try:
                        self._docman.previewRepaintRequested.disconnect(self._on_docman_nudge)
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            base = getattr(self, "base_document", None) or getattr(self, "document", None)
            if base is not None:
                base.changed.disconnect(self._on_base_doc_changed)
        except Exception:
            pass
        try:
            self.unlink_all()
        except Exception:
            pass
        try:
            if id(self) in ImageSubWindow._registry:
                ImageSubWindow._registry.pop(id(self), None)
        except Exception:
            pass
        try:
            if hasattr(self, "aboutToClose"):
                self.aboutToClose.emit(doc)
        except Exception:
            pass
        try:
            if self._loupe is not None:
                self._loupe.hide()
                self._loupe.deleteLater()
                self._loupe = None
        except Exception:
            pass
        # Clear cached buffers so numpy arrays are released before Qt
        # finishes tearing down child widgets
        self._buf8 = None
        self._qimg_src = None
        self._pm_src = None
        self._pm_src_scale = None
        self._pm_src_wcs = None

        super().closeEvent(e)

    def _resolve_history_doc(self):
        """
        Return the doc whose history we should mutate:
        - If a Preview tab is active → the ROI/proxy doc from DocManager
        - Otherwise → the base/full document
        """
        # Prefer DocManager's ROI-aware mapping if present
        dm = getattr(self, "_docman", None)
        if (self._active_source_kind == "preview"
                and self._active_preview_id is not None
                and dm is not None
                and hasattr(dm, "get_document_for_view")):
            try:
                d = dm.get_document_for_view(self)
                if d is not None:
                    return d
            except Exception:
                pass
        # Fallback to the main doc
        return getattr(self, "document", None)


    def _refresh_local_undo_buttons(self):
        """Enable/disable the local Undo/Redo toolbuttons based on can_undo/can_redo."""
        try:
            doc = self._resolve_history_doc()
            can_u = bool(doc and hasattr(doc, "can_undo") and doc.can_undo())
            can_r = bool(doc and hasattr(doc, "can_redo") and doc.can_redo())
        except Exception:
            can_u = can_r = False

        b_u = getattr(self, "_btn_undo", None)
        b_r = getattr(self, "_btn_redo", None)

        try:
            if b_u: b_u.setEnabled(can_u)
        except RuntimeError:
            return
        except Exception:
            pass
        try:
            if b_r: b_r.setEnabled(can_r)
        except RuntimeError:
            return
        except Exception:
            pass

# --- NEW: Enhanced TableSubWindow + Plot/Stats --------------------------------
# ----------------------------- helpers ---------------------------------
def _norm_name(s: str) -> str:
    s = (s or "").strip().lower()
    s = s.replace("-", "_").replace(" ", "_")
    s = re.sub(r"[^a-z0-9_]+", "", s)
    return s


def _find_column_candidates(model: TypedTableModel) -> dict[str, list[int]]:
    """
    Build a semantic map of likely science columns from FITS/MAST-style names.
    """
    out = {
        "time": [],
        "flux": [],
        "flux_err": [],
        "wavelength": [],
        "frequency": [],
        "intensity": [],
        "quality": [],
        "cadence": [],
        "background": [],
        "magnitude": [],
    }

    for i, ci in enumerate(model.column_infos()):
        name = _norm_name(ci.name)

        # time-like
        if name in ("time", "bjd", "mjd", "jd", "hjd") or "time" in name:
            out["time"].append(i)

        # flux-like
        if any(k in name for k in (
            "pdcsap_flux", "sap_flux", "det_flux", "sys_rm_flux", "flux", "counts", "rate"
        )):
            out["flux"].append(i)

        # error-like
        if any(k in name for k in (
            "flux_err", "error", "err", "unc", "uncert"
        )):
            out["flux_err"].append(i)

        # wavelength / spectrum axis
        if any(k in name for k in (
            "wavelength", "lambda", "wave", "lam", "angstrom", "nm", "micron", "um"
        )):
            out["wavelength"].append(i)

        # frequency axis
        if any(k in name for k in (
            "frequency", "freq", "hz", "ghz", "mhz"
        )):
            out["frequency"].append(i)

        # intensity / spectral ordinate
        if any(k in name for k in (
            "intensity", "signal", "spectrum", "spec_flux", "flam", "fnu", "net", "value"
        )):
            out["intensity"].append(i)

        if "quality" in name or "qual" in name:
            out["quality"].append(i)

        if "cadence" in name:
            out["cadence"].append(i)

        if "bkg" in name or "background" in name:
            out["background"].append(i)

        if "mag" in name:
            out["magnitude"].append(i)

    return out


def _pick_first_existing(candidates: list[int], valid_numeric: set[int]) -> Optional[int]:
    for c in candidates:
        if c in valid_numeric:
            return c
    return None


def _guess_plot_columns(model: TypedTableModel) -> dict[str, Optional[int]]:
    """
    Best-effort semantic guessing for common astronomy table patterns.
    """
    numeric_cols = {i for i, ci in enumerate(model.column_infos()) if ci.is_numeric}
    sem = _find_column_candidates(model)

    time_col = _pick_first_existing(sem["time"], numeric_cols)

    # Prefer PDCSAP/SAP/DET style columns before generic flux
    flux_ranked = []
    for i in sem["flux"]:
        nm = _norm_name(model.column_infos()[i].name)
        rank = 100
        if "pdcsap_flux" in nm:
            rank = 0
        elif "sap_flux" in nm:
            rank = 1
        elif "det_flux" in nm:
            rank = 2
        elif "sys_rm_flux" in nm:
            rank = 3
        elif "flux" in nm:
            rank = 10
        flux_ranked.append((rank, i))
    flux_ranked.sort()
    flux_col = flux_ranked[0][1] if flux_ranked else None

    flux_err_col = _pick_first_existing(sem["flux_err"], numeric_cols)
    wave_col = _pick_first_existing(sem["wavelength"], numeric_cols)
    freq_col = _pick_first_existing(sem["frequency"], numeric_cols)
    inten_col = _pick_first_existing(sem["intensity"], numeric_cols)
    mag_col = _pick_first_existing(sem["magnitude"], numeric_cols)

    # fallback generic numeric columns
    numeric_list = sorted(numeric_cols)
    if time_col is None and numeric_list:
        time_col = numeric_list[0]
    if flux_col is None and len(numeric_list) >= 2:
        flux_col = numeric_list[1]
    elif flux_col is None and numeric_list:
        flux_col = numeric_list[0]

    if inten_col is None:
        # for spectra, if no explicit intensity, use best flux-like column
        inten_col = flux_col

    return {
        "time": time_col,
        "flux": flux_col,
        "flux_err": flux_err_col,
        "wavelength": wave_col,
        "frequency": freq_col,
        "intensity": inten_col,
        "magnitude": mag_col,
    }


def _finite_mask(*arrays: np.ndarray) -> np.ndarray:
    if not arrays:
        return np.array([], dtype=bool)
    m = np.ones_like(arrays[0], dtype=bool)
    for a in arrays:
        m &= np.isfinite(a)
    return m


def _sigma_clip_mask(y: np.ndarray, sigma: float) -> np.ndarray:
    if y.size == 0 or sigma <= 0:
        return np.ones_like(y, dtype=bool)
    med = np.nanmedian(y)
    mad = np.nanmedian(np.abs(y - med))
    if not np.isfinite(mad) or mad <= 0:
        std = np.nanstd(y)
        if not np.isfinite(std) or std <= 0:
            return np.ones_like(y, dtype=bool)
        return np.abs(y - med) <= sigma * std
    robust_sigma = 1.4826 * mad
    return np.abs(y - med) <= sigma * robust_sigma


def _phase_fold(x: np.ndarray, period: float, epoch: float = 0.0) -> np.ndarray:
    if period <= 0:
        return x.copy()
    return ((x - epoch) / period) % 1.0


def _bin_xy(x: np.ndarray, y: np.ndarray, nbins: int) -> tuple[np.ndarray, np.ndarray]:
    if x.size == 0 or y.size == 0 or nbins <= 1:
        return x, y
    edges = np.linspace(np.nanmin(x), np.nanmax(x), nbins + 1)
    which = np.digitize(x, edges) - 1
    xb = []
    yb = []
    for b in range(nbins):
        m = which == b
        if not np.any(m):
            continue
        xb.append(float(np.nanmedian(x[m])))
        yb.append(float(np.nanmedian(y[m])))
    if not xb:
        return x, y
    return np.asarray(xb, dtype=np.float64), np.asarray(yb, dtype=np.float64)

def _safe_str(x: Any) -> str:
    if x is None:
        return ""
    # FITS tables often have bytes
    if isinstance(x, (bytes, bytearray)):
        try:
            return x.decode("utf-8", errors="replace")
        except Exception:
            try:
                return x.decode("latin1", errors="replace")
            except Exception:
                return repr(x)
    # numpy scalars
    try:
        if isinstance(x, (np.generic,)):
            x = x.item()
    except Exception:
        pass
    return str(x)

def _is_missing(x: Any) -> bool:
    if x is None:
        return True
    try:
        if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
            return True
    except Exception:
        pass
    try:
        if isinstance(x, (np.floating, np.integer)):
            xv = x.item()
            if isinstance(xv, float) and (math.isnan(xv) or math.isinf(xv)):
                return True
    except Exception:
        pass
    return False

def _try_float(x: Any) -> Optional[float]:
    if _is_missing(x):
        return None
    # already numeric
    if isinstance(x, (int, float, np.integer, np.floating)):
        try:
            v = float(x)
            if math.isnan(v) or math.isinf(v):
                return None
            return v
        except Exception:
            return None

    s = _safe_str(x).strip()
    if not s:
        return None
    # handle FITS bytes shown like b'...'
    # also allow scientific notation
    try:
        v = float(s)
        if math.isnan(v) or math.isinf(v):
            return None
        return v
    except Exception:
        return None

def _numeric_fraction(values: List[Any]) -> float:
    if not values:
        return 0.0
    ok = 0
    tot = 0
    for v in values:
        tot += 1
        if _try_float(v) is not None:
            ok += 1
    return ok / max(1, tot)

def _calc_stats_numeric(vals: np.ndarray) -> dict:
    # vals is 1D float, may contain NaNs already removed
    if vals.size == 0:
        return dict(count=0)
    return dict(
        count=int(vals.size),
        min=float(np.min(vals)),
        max=float(np.max(vals)),
        mean=float(np.mean(vals)),
        median=float(np.median(vals)),
        std=float(np.std(vals)),
    )


# ----------------------------- models ----------------------------------

@dataclass
class ColumnInfo:
    name: str
    is_numeric: bool
    numeric_values: Optional[np.ndarray] = None   # scalar numeric columns only
    is_vector: bool = False
    vector_lengths: Optional[List[int]] = None

def _describe_array_value(x: Any) -> Optional[str]:
    """
    Human-friendly summary for ndarray / array-like cell values that are
    not appropriate to display inline as a long flattened vector.
    """
    if x is None:
        return None

    try:
        arr = np.asarray(x)
    except Exception:
        return None

    if arr.ndim == 0:
        return None

    shape_txt = "×".join(str(int(s)) for s in arr.shape)
    dtype_txt = str(arr.dtype)

    try:
        arrf = np.asarray(arr, dtype=np.float64)
        finite = arrf[np.isfinite(arrf)]
        if finite.size > 0:
            return (
                f"array[{shape_txt}] {dtype_txt}  "
                f"min={float(np.min(finite)):.6g}  "
                f"max={float(np.max(finite)):.6g}"
            )
    except Exception:
        pass

    return f"array[{shape_txt}] {dtype_txt}"

class TypedTableModel(QAbstractTableModel):
    """
    Table model with lightweight type inference per column.

    Supports:
      - scalar numeric columns
      - vector-in-cell numeric columns (common in spectra tables)
    """
    def __init__(self, rows: list, headers: list, parent=None):
        super().__init__(parent)
        self._headers = [str(h) for h in (headers or [])]
        self._rows = list(rows or [])
        self._nrows = len(self._rows)
        self._ncols = len(self._headers) if self._headers else (len(self._rows[0]) if self._rows else 0)

        if not self._headers:
            self._headers = [f"COL_{i}" for i in range(self._ncols)]

        self._colinfo: list[ColumnInfo] = []
        self._build_column_info()

    def _build_column_info(self):
        self._colinfo.clear()

        for c in range(self._ncols):
            col_vals = []
            for r in range(self._nrows):
                try:
                    col_vals.append(self._rows[r][c])
                except Exception:
                    col_vals.append(None)

            scalar_frac = _numeric_fraction(col_vals)
            vector_frac = _sequence_numeric_fraction(col_vals)

            # Prefer vector classification when clearly sequence-like
            is_vector = (vector_frac >= 0.50)
            is_scalar = (not is_vector) and (scalar_frac >= 0.80) and (self._nrows >= 1)

            if is_vector:
                lengths: List[int] = []
                for v in col_vals:
                    arr = _flatten_numeric_sequence(v)
                    lengths.append(int(arr.size) if arr is not None else 0)

                self._colinfo.append(
                    ColumnInfo(
                        name=self._headers[c],
                        is_numeric=True,
                        numeric_values=None,
                        is_vector=True,
                        vector_lengths=lengths,
                    )
                )

            elif is_scalar:
                nv = np.full((self._nrows,), np.nan, dtype=np.float64)
                for i, v in enumerate(col_vals):
                    f = _try_float(v)
                    if f is not None:
                        nv[i] = f

                self._colinfo.append(
                    ColumnInfo(
                        name=self._headers[c],
                        is_numeric=True,
                        numeric_values=nv,
                        is_vector=False,
                        vector_lengths=None,
                    )
                )

            else:
                self._colinfo.append(
                    ColumnInfo(
                        name=self._headers[c],
                        is_numeric=False,
                        numeric_values=None,
                        is_vector=False,
                        vector_lengths=None,
                    )
                )

    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else self._nrows

    def columnCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else self._ncols

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole):
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == Qt.Orientation.Horizontal:
            if 0 <= section < len(self._headers):
                return self._headers[section]
        else:
            return str(section + 1)
        return None

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None

        r = index.row()
        c = index.column()

        try:
            v = self._rows[r][c]
        except Exception:
            v = None

        ci = self._colinfo[c]

        if role == Qt.ItemDataRole.DisplayRole:
            if ci.is_vector:
                return _display_compact_value(v)

            # even if the column is not classified as vector, array-like payloads
            # should display as a readable summary instead of raw garbage
            desc = _describe_array_value(v)
            if desc is not None:
                return desc

            f = _try_float(v)
            if f is not None and ci.is_numeric:
                return f"{f:.10g}"

            return _safe_str(v)

        if role == Qt.ItemDataRole.TextAlignmentRole:
            if ci.is_numeric and not ci.is_vector:
                return int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            return int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)

        if role == Qt.ItemDataRole.ToolTipRole:
            if ci.is_vector:
                arr = _flatten_numeric_sequence(v)
                if arr is not None:
                    finite = arr[np.isfinite(arr)]
                    if finite.size:
                        return (
                            f"{ci.name}\n"
                            f"Vector length: {arr.size}\n"
                            f"Min: {float(np.min(finite)):.6g}\n"
                            f"Max: {float(np.max(finite)):.6g}"
                        )
                    return f"{ci.name}\nVector length: {arr.size}"

            # For multi-dimensional array payloads, show shape summary instead
            desc = _describe_array_value(v)
            if desc is not None:
                return f"{ci.name}\n{desc}"

            return _safe_str(v)

        return None

    def column_infos(self) -> list[ColumnInfo]:
        return self._colinfo

    def raw_value(self, row: int, col: int) -> Any:
        try:
            return self._rows[row][col]
        except Exception:
            return None

    def numeric_column(self, col: int) -> Optional[np.ndarray]:
        if 0 <= col < len(self._colinfo):
            ci = self._colinfo[col]
            if ci.is_numeric and not ci.is_vector:
                return ci.numeric_values
        return None

    def vector_for_row(self, row: int, col: int) -> Optional[np.ndarray]:
        """
        Return one row's vector payload for a vector column as float64 1-D array.
        Returns None if the cell is not a usable numeric vector.
        """
        if not (0 <= col < len(self._colinfo)):
            return None
        if not (0 <= row < self._nrows):
            return None

        ci = self._colinfo[col]
        if not ci.is_vector:
            return None

        raw = self.raw_value(row, col)
        arr = _flatten_numeric_sequence(raw)
        if arr is None:
            return None
        return np.asarray(arr, dtype=np.float64)

    def vector_column_for_rows(self, col: int, source_rows: List[int]) -> Optional[np.ndarray]:
        """
        Flatten a vector-in-cell column across the specified source rows.
        If the column is scalar numeric, returns those scalar values.
        """
        if not (0 <= col < len(self._colinfo)):
            return None

        ci = self._colinfo[col]

        if ci.is_vector:
            parts = []
            for sr in source_rows:
                arr = self.vector_for_row(sr, col)
                if arr is not None and arr.size > 0:
                    parts.append(arr)

            if not parts:
                return np.array([], dtype=np.float64)

            return np.concatenate(parts).astype(np.float64, copy=False)

        if ci.is_numeric and ci.numeric_values is not None:
            out = np.full((len(source_rows),), np.nan, dtype=np.float64)
            for i, sr in enumerate(source_rows):
                if 0 <= sr < ci.numeric_values.shape[0]:
                    out[i] = ci.numeric_values[sr]
            return out

        return None


class MultiColumnContainsFilterProxy(QSortFilterProxyModel):
    """
    Simple row filter: keep rows where ANY column contains the substring (case-insensitive).
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self._needle = ""

        # sorting is enabled by view; keep stable sort
        self.setSortCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.setFilterCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)

    def set_needle(self, text: str):
        self._needle = (text or "").strip().lower()
        self.invalidateFilter()

    def filterAcceptsRow(self, source_row: int, source_parent: QModelIndex) -> bool:
        n = self._needle
        if not n:
            return True

        m = self.sourceModel()
        if m is None:
            return True

        cols = m.columnCount()
        for c in range(cols):
            idx = m.index(source_row, c, source_parent)
            s = m.data(idx, Qt.ItemDataRole.DisplayRole)
            if s is None:
                continue
            if n in str(s).lower():
                return True
        return False


# ----------------------------- stats panel ----------------------------------

def _is_array_like_1d(x: Any) -> bool:
    if x is None:
        return False

    if isinstance(x, np.ndarray):
        return x.ndim == 1 and x.size > 0

    if isinstance(x, (list, tuple)) and len(x) > 0:
        # exclude strings / bytes
        if isinstance(x, (str, bytes, bytearray)):
            return False
        return True

    return False


def _to_1d_float_array(x: Any) -> Optional[np.ndarray]:
    """
    Convert array-like cell content to a 1D float64 vector.
    Returns None if conversion fails or if result is not 1D numeric.
    """
    if x is None:
        return None

    # bytes that actually contain text are not treated as vectors
    if isinstance(x, (bytes, bytearray, str)):
        return None

    try:
        arr = np.asarray(x)
    except Exception:
        return None

    if arr.ndim != 1 or arr.size == 0:
        return None

    # object arrays / mixed arrays -> elementwise float parse
    try:
        if arr.dtype == object:
            out = np.full(arr.shape, np.nan, dtype=np.float64)
            ok_any = False
            for i, v in enumerate(arr.tolist()):
                f = _try_float(v)
                if f is not None:
                    out[i] = f
                    ok_any = True
            return out if ok_any else None

        arr = arr.astype(np.float64, copy=False)
        arr[~np.isfinite(arr)] = np.nan
        return arr
    except Exception:
        # final fallback: try elementwise parse
        try:
            vals = []
            ok_any = False
            for v in list(arr):
                f = _try_float(v)
                vals.append(np.nan if f is None else f)
                ok_any = ok_any or (f is not None)
            out = np.asarray(vals, dtype=np.float64)
            return out if ok_any else None
        except Exception:
            return None


def _preview_value(x: Any, max_items: int = 6) -> str:
    """
    User-facing display string for cells.
    - true 1-D numeric vectors get a compact preview
    - multi-dimensional arrays get a shape/dtype summary
    """
    vec = _flatten_numeric_sequence(x)
    if vec is not None:
        finite = vec[np.isfinite(vec)]
        n = int(vec.size)
        head = vec[:max_items]
        head_txt = ", ".join(
            ("nan" if not np.isfinite(v) else f"{float(v):.6g}")
            for v in head
        )
        if n > max_items:
            head_txt += ", …"
        if finite.size:
            return f"[{head_txt}]  (n={n})"
        return f"[{head_txt}]"

    desc = _describe_array_value(x)
    if desc is not None:
        return desc

    return _safe_str(x)

def _is_sequence_like(x: Any) -> bool:
    if x is None:
        return False
    if isinstance(x, (str, bytes, bytearray)):
        return False
    if isinstance(x, np.ndarray):
        return x.ndim >= 1
    return isinstance(x, (list, tuple))

def _flatten_numeric_sequence(x: Any) -> Optional[np.ndarray]:
    """
    Return a 1-D float64 array only for TRUE 1-D numeric vector content.

    Important:
    - 2-D / 3-D ndarray payloads are NOT flattened anymore.
    - This prevents calibration-array table cells (e.g. HDRLET/WCS correction
      payloads) from being misclassified as plottable vectors.
    """
    if x is None:
        return None

    # strings are never vectors
    if isinstance(x, (str, bytes, bytearray)):
        return None

    # numpy arrays: only accept genuine 1-D
    if isinstance(x, np.ndarray):
        try:
            arr = np.asarray(x)
            if arr.ndim == 0:
                f = _try_float(arr.item())
                if f is None:
                    return None
                return np.array([f], dtype=np.float64)

            if arr.ndim != 1:
                return None

            out = np.full(arr.shape, np.nan, dtype=np.float64)
            any_ok = False
            for i, v in enumerate(arr):
                f = _try_float(v)
                if f is not None:
                    out[i] = f
                    any_ok = True
            return out if any_ok else None
        except Exception:
            return None

    # list / tuple: only accept if elements themselves are not nested sequences
    if isinstance(x, (list, tuple)):
        try:
            if len(x) == 0:
                return None

            # reject nested lists/tuples/arrays -> not a simple 1-D vector cell
            for v in x:
                if isinstance(v, np.ndarray):
                    if np.asarray(v).ndim != 0:
                        return None
                elif isinstance(v, (list, tuple)) and not isinstance(v, (str, bytes, bytearray)):
                    return None

            out = np.full((len(x),), np.nan, dtype=np.float64)
            any_ok = False
            for i, v in enumerate(x):
                f = _try_float(v)
                if f is not None:
                    out[i] = f
                    any_ok = True
            return out if any_ok else None
        except Exception:
            return None

    # stringified bracket vector: only simple 1-D numeric lists
    s = _safe_str(x).strip()
    if not s:
        return None

    if len(s) >= 2 and s[0] == "[" and s[-1] == "]":
        try:
            body = s[1:-1].replace(",", " ")
            parts = [p for p in body.split() if p]
            if not parts:
                return None

            out = np.full((len(parts),), np.nan, dtype=np.float64)
            any_ok = False
            for i, p in enumerate(parts):
                try:
                    v = float(p)
                    if np.isfinite(v):
                        out[i] = v
                        any_ok = True
                except Exception:
                    pass
            return out if any_ok else None
        except Exception:
            return None

    return None

def _sequence_numeric_fraction(values: List[Any]) -> float:
    """
    Fraction of cells that contain TRUE 1-D numeric vectors.
    Multi-dimensional arrays no longer count as vector cells.
    """
    if not values:
        return 0.0

    ok = 0
    for v in values:
        arr = _flatten_numeric_sequence(v)
        if arr is not None and arr.size > 0 and np.isfinite(arr).any():
            ok += 1

    return ok / max(1, len(values))

def _display_compact_value(x: Any, max_items: int = 4) -> str:
    # First: true 1-D numeric vectors
    arr = _flatten_numeric_sequence(x)
    if arr is not None and arr.size > 1:
        finite = arr[np.isfinite(arr)]
        preview = finite[:max_items] if finite.size > 0 else arr[:max_items]
        preview_txt = ", ".join(f"{float(v):.6g}" for v in preview)
        if arr.size > max_items:
            preview_txt += ", ..."
        return f"array[{arr.size}]: {preview_txt}"

    # Second: non-1D arrays / nested payloads -> summarize, do NOT flatten
    desc = _describe_array_value(x)
    if desc is not None:
        return desc

    return _safe_str(x)

def _normalize_unit_text(unit: str) -> str:
    s = (unit or "").strip()
    if not s:
        return ""

    sl = s.lower().replace("angstroms", "angstrom").replace("microns", "micron")

    # wavelength units
    if sl in ("a", "å", "angstrom", "ang", "angs"):
        return "Å"
    if sl in ("nm", "nanometer", "nanometers"):
        return "nm"
    if sl in ("um", "µm", "micron", "micrometer", "micrometers"):
        return "µm"

    # common time units
    if sl in ("d", "day", "days"):
        return "days"
    if sl in ("hour", "hours", "hr", "hrs"):
        return "hours"
    if sl in ("min", "minute", "minutes"):
        return "min"
    if sl in ("s", "sec", "secs", "second", "seconds"):
        return "s"

    return s


def _guess_unit_from_name(name: str) -> Optional[str]:
    n = (name or "").strip().lower()

    # explicit wavelength unit hints
    if "angstrom" in n or " ang " in f" {n} " or n.endswith("_aa") or n.endswith("_a"):
        return "Å"
    if "micron" in n or "um" in n or "µm" in n:
        return "µm"
    if "nanometer" in n or re.search(r"(^|[_\s])nm($|[_\s])", n):
        return "nm"

    # explicit time hints
    if "btjd" in n:
        return "days"
    if n == "time" or " time" in n or n.startswith("time_"):
        return "days"

    # explicit magnitude / flux-ish hints
    if "mag" in n:
        return "mag"
    if "count" in n:
        return "counts"
    if "adu" in n:
        return "ADU"

    return None


def _guess_unit_from_values(col_name: str, vals: np.ndarray) -> Optional[str]:
    """
    Heuristic fallback only when metadata/unit strings are missing.
    Mainly intended for wavelength/time columns.
    """
    try:
        arr = np.asarray(vals, dtype=np.float64)
        arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            return None

        name = (col_name or "").lower()
        med = float(np.nanmedian(arr))
        amin = float(np.nanmin(arr))
        amax = float(np.nanmax(arr))

        # time-like columns
        if "time" in name or "btjd" in name or "bjd" in name or "mjd" in name or "jd" in name:
            return "days"

        # wavelength-like columns
        if "wave" in name or "wavelength" in name or "lambda" in name:
            # typical microns
            if 0.05 <= med <= 30.0:
                return "µm"
            # typical nm
            if 50.0 <= med <= 3000.0:
                # far-UV / optical spectra in the 1000–3000 range are often Å, not nm
                if 900.0 <= amin <= 30000.0 and amax <= 30000.0:
                    return "Å"
                return "nm"
            # typical Å
            if 900.0 <= med <= 30000.0:
                return "Å"

        return None
    except Exception:
        return None

# ----------------------------- plot dialog ----------------------------------
class PlotTableDialog(QDialog):
    def __init__(self, parent, source_model: TypedTableModel, proxy_model: MultiColumnContainsFilterProxy):
        super().__init__(parent)
        self.setWindowTitle("Plot Table Columns")
        self._src = source_model
        self._proxy = proxy_model
        self._semantic = _guess_plot_columns(self._src)
        self._crop_syncing = False

        self._auto_plot_timer = QTimer(self)
        self._auto_plot_timer.setSingleShot(True)
        self._auto_plot_timer.timeout.connect(self._do_plot)
        # Debounce specifically for typed crop edits
        self._crop_edit_timer = QTimer(self)
        self._crop_edit_timer.setSingleShot(True)
        self._crop_edit_timer.timeout.connect(self._queue_auto_plot)
        root = QVBoxLayout(self)

        # ---------------- main 2-column splitter ----------------
        main_split = QSplitter(Qt.Orientation.Horizontal, self)
        root.addWidget(main_split, 1)

        # ================= LEFT: controls =================
        left_wrap = QWidget(self)
        left_root = QVBoxLayout(left_wrap)
        left_root.setContentsMargins(0, 0, 0, 0)

        left_scroll = QScrollArea(self)
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        left_root.addWidget(left_scroll, 1)

        left_content = QWidget(self)
        left_scroll.setWidget(left_content)
        left_content_lay = QVBoxLayout(left_content)
        left_content_lay.setContentsMargins(0, 0, 0, 0)

        ctrl = QGroupBox("Plot Settings", self)
        form = QFormLayout(ctrl)
        left_content_lay.addWidget(ctrl)
        left_content_lay.addStretch(1)

        self.cmb_preset = QComboBox(self)
        self.cmb_preset.addItem("Generic X-Y", userData="generic")
        self.cmb_preset.addItem("TESS Light Curve", userData="tess_lc")
        self.cmb_preset.addItem("Phase Folded Light Curve", userData="phase")
        self.cmb_preset.addItem("Spectrum", userData="spectrum")
        self.cmb_preset.addItem("Histogram", userData="hist")
        form.addRow("Preset:", self.cmb_preset)

        self.cmb_x = QComboBox(self)
        self.cmb_y = QComboBox(self)
        self.cmb_yerr = QComboBox(self)
        self.cmb_yerr.addItem("(none)", userData=-1)

        self._num_cols: list[int] = []
        for i, ci in enumerate(self._src.column_infos()):
            if ci.is_numeric or ci.is_vector:
                self._num_cols.append(i)
                label = ci.name
                if ci.is_vector:
                    label = f"{label} [vector]"
                self.cmb_x.addItem(label, userData=i)
                self.cmb_y.addItem(label, userData=i)
                self.cmb_yerr.addItem(label, userData=i)

        form.addRow("X:", self.cmb_x)
        form.addRow("Y:", self.cmb_y)
        form.addRow("Y error:", self.cmb_yerr)

        self.chk_sort_x = QCheckBox("Sort by X", self)
        self.chk_sort_x.setChecked(True)
        form.addRow("", self.chk_sort_x)

        self.chk_remove_nan = QCheckBox("Remove NaNs / missing", self)
        self.chk_remove_nan.setChecked(True)
        form.addRow("", self.chk_remove_nan)

        self.chk_line = QCheckBox("Connect points (line)", self)
        self.chk_line.setChecked(False)
        form.addRow("", self.chk_line)

        self.chk_normalize_y = QCheckBox("Normalize Y by median", self)
        self.chk_normalize_y.setChecked(False)
        form.addRow("", self.chk_normalize_y)

        self.chk_invert_y = QCheckBox("Invert Y axis (magnitudes)", self)
        self.chk_invert_y.setChecked(False)
        form.addRow("", self.chk_invert_y)

        self.chk_log_x = QCheckBox("Log X axis", self)
        self.chk_log_y = QCheckBox("Log Y axis", self)
        log_row = QWidget(self)
        log_lay = QHBoxLayout(log_row)
        log_lay.setContentsMargins(0, 0, 0, 0)
        log_lay.addWidget(self.chk_log_x)
        log_lay.addWidget(self.chk_log_y)
        log_lay.addStretch(1)
        form.addRow("", log_row)

        self.chk_sigma_clip = QCheckBox("Sigma clip Y", self)
        self.chk_sigma_clip.setChecked(False)
        self.sp_sigma = QDoubleSpinBox(self)
        self.sp_sigma.setRange(0.5, 20.0)
        self.sp_sigma.setSingleStep(0.5)
        self.sp_sigma.setValue(4.0)
        sig_row = QWidget(self)
        sig_lay = QHBoxLayout(sig_row)
        sig_lay.setContentsMargins(0, 0, 0, 0)
        sig_lay.addWidget(self.chk_sigma_clip)
        sig_lay.addWidget(self.sp_sigma)
        sig_lay.addStretch(1)
        form.addRow("", sig_row)

        self.sp_ms = QDoubleSpinBox(self)
        self.sp_ms.setRange(0.5, 20.0)
        self.sp_ms.setSingleStep(0.5)
        self.sp_ms.setValue(3.0)
        form.addRow("Marker size:", self.sp_ms)

        # -------- X crop controls --------
        self.chk_crop_x = QCheckBox("Crop X range", self)
        self.chk_crop_x.setChecked(False)

        self.sp_xmin = QDoubleSpinBox(self)
        self.sp_xmin.setDecimals(8)
        self.sp_xmin.setRange(-1e18, 1e18)
        self.sp_xmin.setSingleStep(0.1)

        self.sp_xmax = QDoubleSpinBox(self)
        self.sp_xmax.setDecimals(8)
        self.sp_xmax.setRange(-1e18, 1e18)
        self.sp_xmax.setSingleStep(0.1)

        crop_row = QWidget(self)
        crop_lay = QHBoxLayout(crop_row)
        crop_lay.setContentsMargins(0, 0, 0, 0)
        crop_lay.addWidget(self.chk_crop_x)
        crop_lay.addWidget(QLabel("Min:"))
        crop_lay.addWidget(self.sp_xmin, 1)
        crop_lay.addWidget(QLabel("Max:"))
        crop_lay.addWidget(self.sp_xmax, 1)
        form.addRow("", crop_row)

        self.sp_period = QDoubleSpinBox(self)
        self.sp_period.setRange(1e-9, 1e9)
        self.sp_period.setDecimals(8)
        self.sp_period.setValue(1.0)

        self.sp_epoch = QDoubleSpinBox(self)
        self.sp_epoch.setRange(-1e9, 1e9)
        self.sp_epoch.setDecimals(8)
        self.sp_epoch.setValue(0.0)

        self.sp_phase_bins = QSpinBox(self)
        self.sp_phase_bins.setRange(2, 1000)
        self.sp_phase_bins.setValue(100)

        form.addRow("Period:", self.sp_period)
        form.addRow("Epoch:", self.sp_epoch)
        form.addRow("Phase bins:", self.sp_phase_bins)

        self.sp_hist_bins = QSpinBox(self)
        self.sp_hist_bins.setRange(5, 5000)
        self.sp_hist_bins.setValue(50)
        form.addRow("Histogram bins:", self.sp_hist_bins)

        # ================= RIGHT: plot =================
        right_wrap = QWidget(self)
        right_root = QVBoxLayout(right_wrap)
        right_root.setContentsMargins(0, 0, 0, 0)

        self.fig = Figure(figsize=(7, 5), dpi=100)
        self.canvas = FigureCanvas(self.fig)
        self.toolbar = NavToolbar(self.canvas, self)

        right_root.addWidget(self.toolbar)
        right_root.addWidget(self.canvas, 1)

        main_split.addWidget(left_wrap)
        main_split.addWidget(right_wrap)
        main_split.setStretchFactor(0, 0)
        main_split.setStretchFactor(1, 1)
        main_split.setSizes([340, 860])

        # ---------------- bottom buttons ----------------
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Close, parent=self)
        self.btn_plot = QPushButton("Plot", self)
        self.btn_plot.clicked.connect(self._do_plot)
        btns.addButton(self.btn_plot, QDialogButtonBox.ButtonRole.ActionRole)
        btns.rejected.connect(self.reject)
        root.addWidget(btns)

        self.cmb_preset.currentIndexChanged.connect(self._preset_changed)

        self._connect_auto_refresh()

        self.resize(1240, 780)

        self._preset_changed()
        if self.cmb_x.count() > 0 and self.cmb_y.count() > 0:
            self._queue_auto_plot()

    def _queue_crop_edit_plot(self):
        """
        Slightly longer debounce for typed crop min/max edits so we do not
        replot on every character while the user is typing.
        """
        self._crop_edit_timer.start(500)

    def _commit_crop_edit_plot(self):
        """
        Fire quickly once editing is committed (enter/tab/focus-out).
        """
        self._crop_edit_timer.stop()
        self._queue_auto_plot()

    def _document_metadata(self) -> dict:
        try:
            p = self.parent()
            if p is not None and hasattr(p, "document"):
                md = getattr(p.document, "metadata", None)
                if isinstance(md, dict):
                    return md
        except Exception:
            pass
        return {}


    def _column_name(self, col: int) -> str:
        try:
            infos = self._src.column_infos()
            if 0 <= col < len(infos):
                return str(infos[col].name)
        except Exception:
            pass
        return ""


    def _guess_axis_unit(self, col: int, vals: Optional[np.ndarray] = None) -> Optional[str]:
        """
        Priority:
        1) document.metadata unit maps if present
        2) explicit hints in column name
        3) value heuristics (mostly wavelength/time)
        """
        if col < 0:
            return None

        name = self._column_name(col)
        md = self._document_metadata()

        # common places you may later stash TUNITn / astropy units
        for key in ("column_units", "table_units", "units", "tunits"):
            try:
                m = md.get(key)
                if isinstance(m, dict):
                    # exact header
                    if name in m and m[name]:
                        return _normalize_unit_text(str(m[name]))
                    # lowercase fallback
                    lowmap = {str(k).lower(): v for k, v in m.items()}
                    if name.lower() in lowmap and lowmap[name.lower()]:
                        return _normalize_unit_text(str(lowmap[name.lower()]))
            except Exception:
                pass

        unit = _guess_unit_from_name(name)
        if unit:
            return unit

        if vals is not None:
            unit = _guess_unit_from_values(name, vals)
            if unit:
                return unit

        return None


    def _axis_label_for_col(self, col: int, vals: Optional[np.ndarray] = None) -> str:
        name = self._column_name(col)
        unit = self._guess_axis_unit(col, vals)
        if unit:
            return f"{name} [{unit}]"
        return name or "Value"


    def _sync_crop_to_series(self, x: np.ndarray, *, force: bool = False):
        """
        Sync crop spinboxes to the current X data range.

        Rules:
        - force=True:
            always overwrite min/max with the current full data range
        - force=False:
            only overwrite when crop is OFF, or when the current min/max are invalid
        """
        try:
            arr = np.asarray(x, dtype=np.float64)
            arr = arr[np.isfinite(arr)]
            if arr.size == 0:
                return

            xmin = float(np.min(arr))
            xmax = float(np.max(arr))
            if xmax < xmin:
                xmin, xmax = xmax, xmin

            # If user is actively cropping, preserve their values unless forced
            if (not force) and self.chk_crop_x.isChecked():
                cur_min = float(self.sp_xmin.value())
                cur_max = float(self.sp_xmax.value())

                # keep user's crop if it looks sane
                if np.isfinite(cur_min) and np.isfinite(cur_max) and cur_max >= cur_min:
                    return

            self._crop_syncing = True
            try:
                self.sp_xmin.setValue(xmin)
                self.sp_xmax.setValue(xmax)
            finally:
                self._crop_syncing = False

        except Exception:
            pass

    def _refresh_crop_bounds_from_current_x(self, *, force: bool = False):
        """
        Refresh crop bounds from the currently selected X source.
        Preserves user crop unless force=True.
        """
        try:
            if self.cmb_x.count() <= 0:
                return
            xcol = int(self.cmb_x.currentData())
            x = self._gather_visible_series(xcol)
            self._sync_crop_to_series(x, force=force)
        except Exception:
            pass

    def _apply_x_crop(self, x: np.ndarray, y: np.ndarray, yerr: Optional[np.ndarray]):
        if not self.chk_crop_x.isChecked():
            return x, y, yerr

        xmin = float(self.sp_xmin.value())
        xmax = float(self.sp_xmax.value())
        if xmax < xmin:
            xmin, xmax = xmax, xmin

        mask = np.isfinite(x) & (x >= xmin) & (x <= xmax)
        x2 = x[mask]
        y2 = y[mask]
        yerr2 = yerr[mask] if yerr is not None else None
        return x2, y2, yerr2

    def _connect_auto_refresh(self):
        # combos
        self.cmb_preset.currentIndexChanged.connect(self._queue_auto_plot)
        self.cmb_x.currentIndexChanged.connect(self._queue_auto_plot)
        self.cmb_y.currentIndexChanged.connect(self._queue_auto_plot)
        self.cmb_yerr.currentIndexChanged.connect(self._queue_auto_plot)

        # checkboxes
        self.chk_sort_x.toggled.connect(self._queue_auto_plot)
        self.chk_remove_nan.toggled.connect(self._queue_auto_plot)
        self.chk_line.toggled.connect(self._queue_auto_plot)
        self.chk_normalize_y.toggled.connect(self._queue_auto_plot)
        self.chk_invert_y.toggled.connect(self._queue_auto_plot)
        self.chk_log_x.toggled.connect(self._queue_auto_plot)
        self.chk_log_y.toggled.connect(self._queue_auto_plot)
        self.chk_sigma_clip.toggled.connect(self._queue_auto_plot)
        self.chk_crop_x.toggled.connect(self._queue_auto_plot)

        # general spinboxes
        self.sp_sigma.valueChanged.connect(self._queue_auto_plot)
        self.sp_ms.valueChanged.connect(self._queue_auto_plot)
        self.sp_period.valueChanged.connect(self._queue_auto_plot)
        self.sp_epoch.valueChanged.connect(self._queue_auto_plot)
        self.sp_phase_bins.valueChanged.connect(self._queue_auto_plot)
        self.sp_hist_bins.valueChanged.connect(self._queue_auto_plot)

        # crop spinboxes:
        #  - typing in the line edit gets debounced
        #  - commit/focus-out replots immediately
        #  - arrow-button / wheel / programmatic value changes still update
        try:
            if self.sp_xmin.lineEdit() is not None:
                self.sp_xmin.lineEdit().textEdited.connect(lambda *_: self._queue_crop_edit_plot())
            self.sp_xmin.editingFinished.connect(self._commit_crop_edit_plot)
            self.sp_xmin.valueChanged.connect(lambda *_: (None if self._crop_syncing else self._queue_crop_edit_plot()))
        except Exception:
            self.sp_xmin.valueChanged.connect(self._queue_crop_edit_plot)

        try:
            if self.sp_xmax.lineEdit() is not None:
                self.sp_xmax.lineEdit().textEdited.connect(lambda *_: self._queue_crop_edit_plot())
            self.sp_xmax.editingFinished.connect(self._commit_crop_edit_plot)
            self.sp_xmax.valueChanged.connect(lambda *_: (None if self._crop_syncing else self._queue_crop_edit_plot()))
        except Exception:
            self.sp_xmax.valueChanged.connect(self._queue_crop_edit_plot)

        # also replot when selected table row changes
        try:
            parent_tbl = self.parent()
            if parent_tbl is not None and hasattr(parent_tbl, "table"):
                sel = parent_tbl.table.selectionModel()
                if sel is not None:
                    sel.currentRowChanged.connect(lambda *_: self._queue_auto_plot())
                    sel.selectionChanged.connect(lambda *_: self._queue_auto_plot())
        except Exception:
            pass

    def _queue_auto_plot(self):
        self._auto_plot_timer.start(200)

    def _current_source_row(self) -> Optional[int]:
        try:
            parent_tbl = self.parent()
            if parent_tbl is not None and hasattr(parent_tbl, "table"):
                idx = parent_tbl.table.currentIndex()
                if idx.isValid():
                    sidx = self._proxy.mapToSource(idx)
                    if sidx.isValid():
                        return int(sidx.row())
        except Exception:
            pass

        if self._proxy.rowCount() > 0:
            try:
                sidx = self._proxy.mapToSource(self._proxy.index(0, 0))
                if sidx.isValid():
                    return int(sidx.row())
            except Exception:
                pass

        return None

    def _gather_visible_series(self, col: int) -> np.ndarray:
        """
        Returns a numeric series for plotting.

        Behavior:
        - scalar numeric column -> visible rows
        - vector column -> current source row's vector (or first visible row)
        """
        if col < 0:
            return np.array([], dtype=np.float64)

        # scalar numeric column
        nv = self._src.numeric_column(col)
        if nv is not None:
            out = np.empty((self._proxy.rowCount(),), dtype=np.float64)
            out[:] = np.nan
            for pr in range(self._proxy.rowCount()):
                src_idx = self._proxy.mapToSource(self._proxy.index(pr, col))
                sr = src_idx.row()
                if 0 <= sr < nv.shape[0]:
                    out[pr] = nv[sr]
            return out

        # vector column
        sr = self._current_source_row()
        if sr is None:
            return np.array([], dtype=np.float64)

        vec = _flatten_numeric_sequence(self._src.raw_value(sr, col))
        if vec is None:
            return np.array([], dtype=np.float64)

        return np.asarray(vec, dtype=np.float64)

    def _set_combo_to_col(self, combo: QComboBox, col: Optional[int]):
        if col is None:
            return
        idx = combo.findData(col)
        if idx >= 0:
            combo.setCurrentIndex(idx)

    def _preset_changed(self):
        preset = self.cmb_preset.currentData()

        self.chk_line.setChecked(False)
        self.chk_sort_x.setChecked(True)
        self.chk_normalize_y.setChecked(False)
        self.chk_invert_y.setChecked(False)
        self.chk_log_x.setChecked(False)
        self.chk_log_y.setChecked(False)

        is_phase = (preset == "phase")
        is_hist = (preset == "hist")
        self.sp_period.setEnabled(is_phase)
        self.sp_epoch.setEnabled(is_phase)
        self.sp_phase_bins.setEnabled(is_phase)
        self.sp_hist_bins.setEnabled(is_hist)

        # Crop is useful for all X-Y style plots
        crop_ok = preset in ("generic", "tess_lc", "phase", "spectrum")
        self.chk_crop_x.setEnabled(crop_ok)
        self.sp_xmin.setEnabled(crop_ok and self.chk_crop_x.isChecked())
        self.sp_xmax.setEnabled(crop_ok and self.chk_crop_x.isChecked())

        sem = self._semantic

        if preset == "tess_lc":
            self._set_combo_to_col(self.cmb_x, sem["time"])
            self._set_combo_to_col(self.cmb_y, sem["flux"])
            self._set_combo_to_col(self.cmb_yerr, sem["flux_err"])
            self.chk_line.setChecked(False)
            self.chk_normalize_y.setChecked(True)

        elif preset == "phase":
            self._set_combo_to_col(self.cmb_x, sem["time"])
            self._set_combo_to_col(self.cmb_y, sem["flux"])
            self._set_combo_to_col(self.cmb_yerr, sem["flux_err"])
            self.chk_line.setChecked(False)
            self.chk_normalize_y.setChecked(True)

        elif preset == "spectrum":
            xcol = sem["wavelength"] if sem["wavelength"] is not None else sem["frequency"]
            ycol = sem["intensity"] if sem["intensity"] is not None else sem["flux"]
            self._set_combo_to_col(self.cmb_x, xcol)
            self._set_combo_to_col(self.cmb_y, ycol)
            self.chk_line.setChecked(True)

        elif preset == "hist":
            if sem["flux"] is not None:
                self._set_combo_to_col(self.cmb_y, sem["flux"])

        else:
            if sem["time"] is not None:
                self._set_combo_to_col(self.cmb_x, sem["time"])
            if sem["flux"] is not None:
                self._set_combo_to_col(self.cmb_y, sem["flux"])

        # IMPORTANT:
        # Only refresh crop bounds if crop is not actively being used.
        # This preserves the user's custom min/max when switching presets.
        self._refresh_crop_bounds_from_current_x(force=False)

        self._queue_auto_plot()

    def _apply_common_cleaning(self, x: np.ndarray, y: np.ndarray, yerr: Optional[np.ndarray]):
        mask = np.ones_like(y, dtype=bool)

        if self.chk_remove_nan.isChecked():
            mask &= _finite_mask(x, y)
            if yerr is not None:
                mask &= np.isfinite(yerr)

        x2 = x[mask]
        y2 = y[mask]
        yerr2 = yerr[mask] if yerr is not None else None

        if self.chk_sigma_clip.isChecked() and x2.size > 0 and y2.size > 0:
            cm = _sigma_clip_mask(y2, float(self.sp_sigma.value()))
            x2 = x2[cm]
            y2 = y2[cm]
            if yerr2 is not None:
                yerr2 = yerr2[cm]

        if self.chk_normalize_y.isChecked() and y2.size > 0:
            med = np.nanmedian(y2)
            if np.isfinite(med) and med != 0:
                y2 = y2 / med
                if yerr2 is not None:
                    yerr2 = yerr2 / abs(med)

        return x2, y2, yerr2

    def _do_plot(self):
        if self.cmb_y.count() == 0:
            self.fig.clear()
            self.canvas.draw()
            return

        preset = self.cmb_preset.currentData()
        ycol = int(self.cmb_y.currentData())
        xcol = int(self.cmb_x.currentData()) if self.cmb_x.count() > 0 else -1
        yerr_col = int(self.cmb_yerr.currentData())

        self.sp_xmin.setEnabled(self.chk_crop_x.isEnabled() and self.chk_crop_x.isChecked())
        self.sp_xmax.setEnabled(self.chk_crop_x.isEnabled() and self.chk_crop_x.isChecked())

        self.fig.clear()
        ax = self.fig.add_subplot(111)
        ms = float(self.sp_ms.value())

        try:
            if preset == "hist":
                y = self._gather_visible_series(ycol)
                y = y[np.isfinite(y)]

                if self.chk_sigma_clip.isChecked():
                    y = y[_sigma_clip_mask(y, float(self.sp_sigma.value()))]

                if self.chk_normalize_y.isChecked() and y.size > 0:
                    med = np.nanmedian(y)
                    if np.isfinite(med) and med != 0:
                        y = y / med

                if y.size == 0:
                    ax.text(0.5, 0.5, "No valid numeric data for histogram.",
                            ha="center", va="center", transform=ax.transAxes)
                else:
                    ax.hist(y, bins=int(self.sp_hist_bins.value()))
                    ax.set_xlabel(self._axis_label_for_col(ycol, y))
                    ax.set_ylabel("Count")
                    ax.set_title(f"Histogram: {self._column_name(ycol)}")

            else:
                if self.cmb_x.count() == 0:
                    ax.text(0.5, 0.5, "No numeric/vector X column available.",
                            ha="center", va="center", transform=ax.transAxes)
                else:
                    x = self._gather_visible_series(xcol)
                    y = self._gather_visible_series(ycol)
                    yerr = self._gather_visible_series(yerr_col) if yerr_col >= 0 else None

                    # keep crop bounds synced to current data unless user is actively using crop
                    if not self._crop_syncing:
                        self._sync_crop_to_series(x, force=False)

                    if x.size == 0 or y.size == 0:
                        ax.text(0.5, 0.5, "No data available.",
                                ha="center", va="center", transform=ax.transAxes)
                    else:
                        if x.ndim == 1 and y.ndim == 1 and x.size != y.size:
                            ax.text(0.5, 0.5, f"X and Y lengths do not match ({x.size} vs {y.size}).",
                                    ha="center", va="center", transform=ax.transAxes)
                        else:
                            if yerr is not None and yerr.size not in (0, y.size):
                                yerr = None

                            x2, y2, yerr2 = self._apply_common_cleaning(x, y, yerr)

                            # crop BEFORE phase folding
                            x2, y2, yerr2 = self._apply_x_crop(x2, y2, yerr2)

                            if x2.size == 0:
                                ax.text(0.5, 0.5, "All rows were filtered out.",
                                        ha="center", va="center", transform=ax.transAxes)
                            elif preset == "phase":
                                period = float(self.sp_period.value())
                                epoch = float(self.sp_epoch.value())
                                x2 = _phase_fold(x2, period, epoch)

                                if self.chk_sort_x.isChecked():
                                    order = np.argsort(x2)
                                    x2 = x2[order]
                                    y2 = y2[order]
                                    if yerr2 is not None:
                                        yerr2 = yerr2[order]

                                xb, yb = _bin_xy(x2, y2, int(self.sp_phase_bins.value()))
                                ax.plot(x2, y2, "o", alpha=0.35, markersize=max(1.0, ms - 1.0))
                                if xb.size > 0:
                                    ax.plot(xb, yb, "-", linewidth=1.5)
                                ax.set_xlabel("Phase")
                                ax.set_ylabel(self._axis_label_for_col(ycol, y2))
                                ax.set_title("Phase-Folded Light Curve")

                            else:
                                if self.chk_sort_x.isChecked():
                                    order = np.argsort(x2)
                                    x2 = x2[order]
                                    y2 = y2[order]
                                    if yerr2 is not None:
                                        yerr2 = yerr2[order]

                                if preset == "spectrum":
                                    if yerr2 is not None:
                                        ax.errorbar(
                                            x2, y2, yerr=yerr2,
                                            fmt="-",
                                            linewidth=1.0,
                                            ecolor="orange"
                                        )
                                    else:
                                        ax.plot(x2, y2, "-", linewidth=1.0)
                                    ax.set_title("Spectrum")
                                else:
                                    if yerr2 is not None:
                                        ax.errorbar(
                                            x2, y2, yerr=yerr2,
                                            fmt="o" if not self.chk_line.isChecked() else "-o",
                                            markersize=ms,
                                            ecolor="orange"
                                        )
                                    else:
                                        if self.chk_line.isChecked():
                                            ax.plot(x2, y2, "-o", markersize=ms)
                                        else:
                                            ax.plot(x2, y2, "o", markersize=ms)

                                ax.set_xlabel(self._axis_label_for_col(xcol, x2))
                                ax.set_ylabel(self._axis_label_for_col(ycol, y2))

            if self.chk_log_x.isChecked():
                try:
                    ax.set_xscale("log")
                except Exception:
                    pass

            if self.chk_log_y.isChecked():
                try:
                    ax.set_yscale("log")
                except Exception:
                    pass

            if self.chk_invert_y.isChecked():
                ax.invert_yaxis()

            ax.grid(True, which="both", alpha=0.3)
            self.fig.tight_layout()
            self.canvas.draw()

        except Exception as e:
            self.fig.clear()
            ax = self.fig.add_subplot(111)
            ax.text(0.5, 0.5, f"Plot failed:\n{type(e).__name__}: {e}",
                    ha="center", va="center", transform=ax.transAxes)
            ax.set_axis_off()
            self.fig.tight_layout()
            self.canvas.draw()
# ----------------------------- TableSubWindow --------------------------------
@dataclass
class NewTableColumnSpec:
    name: str
    kind: str   # "text", "float", "int", "bool", "ra", "dec", "note"


class _TypeComboDelegate(QStyledItemDelegate):
    OPTIONS = ["text", "float", "int", "bool", "ra", "dec", "note"]

    _TOOLTIPS = {
        "text": "General text",
        "float": "Decimal numbers",
        "int": "Whole numbers",
        "bool": "True / False values",
        "ra": "Right Ascension",
        "dec": "Declination",
        "note": "Longer notes or comments",
    }

    def createEditor(self, parent, option, index):
        combo = QComboBox(parent)
        for opt in self.OPTIONS:
            combo.addItem(opt)
            i = combo.count() - 1
            combo.setItemData(i, self._TOOLTIPS.get(opt, ""), Qt.ItemDataRole.ToolTipRole)
        return combo

    def setEditorData(self, editor, index):
        val = str(index.model().data(index, Qt.ItemDataRole.EditRole) or "text")
        i = editor.findText(val)
        editor.setCurrentIndex(max(0, i))

    def setModelData(self, editor, model, index):
        model.setData(index, editor.currentText(), Qt.ItemDataRole.EditRole)


class _NewTableColumnsModel(QAbstractTableModel):
    HEADERS = ["Column Name", "Type"]
    TYPE_OPTIONS = ["text", "float", "int", "bool", "ra", "dec", "note"]

    def __init__(self, specs: list[NewTableColumnSpec], parent=None):
        super().__init__(parent)
        self._specs = list(specs)

    def specs(self) -> list[NewTableColumnSpec]:
        return [NewTableColumnSpec(s.name, s.kind) for s in self._specs]

    def set_specs(self, specs: list[NewTableColumnSpec]):
        self.beginResetModel()
        self._specs = list(specs)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self._specs)

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else 2

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == Qt.Orientation.Horizontal:
            if 0 <= section < len(self.HEADERS):
                return self.HEADERS[section]
        return str(section + 1)

    def flags(self, index):
        if not index.isValid():
            return Qt.ItemFlag.NoItemFlags
        return (
            Qt.ItemFlag.ItemIsEnabled
            | Qt.ItemFlag.ItemIsSelectable
            | Qt.ItemFlag.ItemIsEditable
        )

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None

        spec = self._specs[index.row()]

        if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.EditRole):
            if index.column() == 0:
                return spec.name
            elif index.column() == 1:
                return spec.kind

        return None

    def setData(self, index, value, role=Qt.ItemDataRole.EditRole):
        if not index.isValid() or role != Qt.ItemDataRole.EditRole:
            return False

        spec = self._specs[index.row()]
        txt = str(value).strip()

        if index.column() == 0:
            spec.name = txt or spec.name
        elif index.column() == 1:
            if txt not in self.TYPE_OPTIONS:
                return False
            spec.kind = txt
        else:
            return False

        self.dataChanged.emit(index, index, [Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.EditRole])
        return True


class CreateTableDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Create Table")
        self.resize(560, 420)

        root = QVBoxLayout(self)

        form = QFormLayout()
        self.edit_name = QLineEdit(self)
        self.edit_name.setText("New Table")

        self.sp_rows = QSpinBox(self)
        self.sp_rows.setRange(0, 100000)
        self.sp_rows.setValue(10)

        self.sp_cols = QSpinBox(self)
        self.sp_cols.setRange(1, 256)
        self.sp_cols.setValue(3)

        form.addRow("Table name:", self.edit_name)
        form.addRow("Initial rows:", self.sp_rows)
        form.addRow("Columns:", self.sp_cols)
        root.addLayout(form)

        root.addWidget(QLabel("Define columns:"))

        self.col_table = QTableView(self)
        root.addWidget(self.col_table, 1)

        self._col_model = _NewTableColumnsModel(self._default_specs(self.sp_cols.value()), self)
        self.col_table.setModel(self._col_model)
        self.col_table.setItemDelegateForColumn(1, _TypeComboDelegate(self.col_table))
        self.col_table.horizontalHeader().setStretchLastSection(True)
        self.col_table.verticalHeader().setVisible(False)
        self.col_table.resizeColumnsToContents()
        help_lbl = QLabel(
            "Column type guide:\n"
            "• text  — general text\n"
            "• note  — longer comments / notes\n"
            "• int   — whole numbers\n"
            "• float — decimal numbers\n"
            "• bool  — true/false values\n"
            "• ra    — Right Ascension\n"
            "• dec   — Declination"
        )
        help_lbl.setWordWrap(True)
        help_lbl.setStyleSheet("""
            QLabel {
                background: rgba(255, 255, 255, 18);
                border: 1px solid rgba(255, 255, 255, 40);
                border-radius: 4px;
                padding: 6px;
            }
        """)
        root.addWidget(help_lbl)
        self.sp_cols.valueChanged.connect(self._resize_specs)

        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        btns.accepted.connect(self._accept_if_valid)
        btns.rejected.connect(self.reject)
        root.addWidget(btns)

    def _default_specs(self, n: int) -> list[NewTableColumnSpec]:
        defaults = []
        useful_names = [
            ("Name", "text"),
            ("RA", "ra"),
            ("DEC", "dec"),
            ("Pixel X", "float"),
            ("Pixel Y", "float"),
            ("Type", "text"),
            ("Notes", "note"),
        ]
        for i in range(n):
            if i < len(useful_names):
                nm, kd = useful_names[i]
            else:
                nm, kd = (f"Column {i+1}", "text")
            defaults.append(NewTableColumnSpec(nm, kd))
        return defaults

    def _resize_specs(self, n: int):
        old = self._col_model.specs()
        new_specs = []
        for i in range(n):
            if i < len(old):
                new_specs.append(old[i])
            else:
                new_specs.append(NewTableColumnSpec(f"Column {i+1}", "text"))
        self._col_model.set_specs(new_specs)
        self.col_table.resizeColumnsToContents()

    def _accept_if_valid(self):
        name = self.table_name().strip()
        if not name:
            QMessageBox.information(self, "Create Table", "Please enter a table name.")
            return

        specs = self.column_specs()
        if not specs:
            QMessageBox.information(self, "Create Table", "Please define at least one column.")
            return

        bad = [c.name for c in specs if not str(c.name).strip()]
        if bad:
            QMessageBox.information(self, "Create Table", "All columns must have names.")
            return

        self.accept()

    def table_name(self) -> str:
        return self.edit_name.text().strip()

    def row_count(self) -> int:
        return int(self.sp_rows.value())

    def column_specs(self) -> list[NewTableColumnSpec]:
        return self._col_model.specs()


class TableStatsPanel(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("Stats", parent)
        self.setMinimumWidth(260)

        lay = QFormLayout(self)

        self.lbl_rows = QLabel("—")
        self.lbl_cols = QLabel("—")
        self.lbl_sel_col = QLabel("—")
        self.lbl_type = QLabel("—")
        self.lbl_count = QLabel("—")
        self.lbl_min = QLabel("—")
        self.lbl_max = QLabel("—")
        self.lbl_mean = QLabel("—")
        self.lbl_median = QLabel("—")
        self.lbl_std = QLabel("—")
        self.lbl_unique = QLabel("—")

        lay.addRow("Rows (visible):", self.lbl_rows)
        lay.addRow("Columns:", self.lbl_cols)
        lay.addRow("Selected col:", self.lbl_sel_col)
        lay.addRow("Type:", self.lbl_type)
        lay.addRow("Count:", self.lbl_count)
        lay.addRow("Min:", self.lbl_min)
        lay.addRow("Max:", self.lbl_max)
        lay.addRow("Mean:", self.lbl_mean)
        lay.addRow("Median:", self.lbl_median)
        lay.addRow("Std:", self.lbl_std)
        lay.addRow("Unique (sample):", self.lbl_unique)

    def set_table_shape(self, nrows_visible: int, ncols: int):
        self.lbl_rows.setText(str(nrows_visible))
        self.lbl_cols.setText(str(ncols))

    def set_selection_info(
        self,
        col_name: str,
        is_numeric: bool,
        stats: Optional[dict] = None,
        unique_sample: Optional[int] = None,
    ):
        self.lbl_sel_col.setText(col_name or "—")
        self.lbl_type.setText("numeric" if is_numeric else "text/mixed")

        if is_numeric and stats and stats.get("count", 0) > 0:
            self.lbl_count.setText(str(stats.get("count", "—")))
            self.lbl_min.setText(f"{stats.get('min'):.10g}")
            self.lbl_max.setText(f"{stats.get('max'):.10g}")
            self.lbl_mean.setText(f"{stats.get('mean'):.10g}")
            self.lbl_median.setText(f"{stats.get('median'):.10g}")
            self.lbl_std.setText(f"{stats.get('std'):.10g}")
        else:
            self.lbl_count.setText("—")
            self.lbl_min.setText("—")
            self.lbl_max.setText("—")
            self.lbl_mean.setText("—")
            self.lbl_median.setText("—")
            self.lbl_std.setText("—")

        self.lbl_unique.setText("—" if unique_sample is None else str(unique_sample))


class EditableTypedTableModel(TypedTableModel):
    def __init__(self, rows: list, headers: list, column_kinds: Optional[list[str]] = None, parent=None):
        self._column_kinds = list(column_kinds or [])
        super().__init__(rows, headers, parent)

        if len(self._column_kinds) < self._ncols:
            self._column_kinds.extend(["text"] * (self._ncols - len(self._column_kinds)))

    def flags(self, index: QModelIndex):
        if not index.isValid():
            return Qt.ItemFlag.NoItemFlags
        return (
            Qt.ItemFlag.ItemIsEnabled
            | Qt.ItemFlag.ItemIsSelectable
            | Qt.ItemFlag.ItemIsEditable
        )

    def setData(self, index: QModelIndex, value: Any, role: int = Qt.ItemDataRole.EditRole):
        if not index.isValid() or role != Qt.ItemDataRole.EditRole:
            return False

        r = index.row()
        c = index.column()

        if not (0 <= r < self._nrows and 0 <= c < self._ncols):
            return False

        kind = self._column_kinds[c] if c < len(self._column_kinds) else "text"
        parsed = self._coerce_value_for_kind(value, kind)
        self._rows[r][c] = parsed

        self._build_column_info()
        self.dataChanged.emit(index, index, [Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.EditRole])
        return True

    def _coerce_value_for_kind(self, value: Any, kind: str):
        txt = "" if value is None else str(value).strip()

        if kind in ("text", "note", "ra", "dec"):
            return txt

        if kind == "float":
            if txt == "":
                return ""
            try:
                return float(txt)
            except Exception:
                return txt

        if kind == "int":
            if txt == "":
                return ""
            try:
                return int(float(txt))
            except Exception:
                return txt

        if kind == "bool":
            t = txt.lower()
            if t in ("1", "true", "yes", "y", "checked"):
                return True
            if t in ("0", "false", "no", "n", "unchecked"):
                return False
            return False if txt == "" else txt

        return txt

    def _default_value_for_kind(self, kind: str):
        if kind == "bool":
            return False
        return ""

    def insert_rows_at_end(self, count: int = 1):
        count = max(1, int(count))
        start = self._nrows
        end = self._nrows + count - 1
        self.beginInsertRows(QModelIndex(), start, end)
        for _ in range(count):
            self._rows.append([self._default_value_for_kind(k) for k in self._column_kinds[:self._ncols]])
        self._nrows = len(self._rows)
        self.endInsertRows()
        self._build_column_info()

    def remove_source_rows(self, rows_to_remove: list[int]):
        if not rows_to_remove:
            return
        rows_sorted = sorted(set(r for r in rows_to_remove if 0 <= r < self._nrows), reverse=True)
        for r in rows_sorted:
            self.beginRemoveRows(QModelIndex(), r, r)
            del self._rows[r]
            self._nrows -= 1
            self.endRemoveRows()
        self._build_column_info()

    def insert_column_at_end(self, name: str, kind: str = "text"):
        pos = self._ncols
        self.beginInsertColumns(QModelIndex(), pos, pos)
        self._headers.append(str(name or f"Column {pos+1}"))
        self._column_kinds.append(str(kind or "text"))
        default_val = self._default_value_for_kind(kind)
        for r in range(self._nrows):
            self._rows[r].append(default_val)
        self._ncols += 1
        self.endInsertColumns()
        self._build_column_info()

    def column_kinds(self) -> list[str]:
        return list(self._column_kinds)


class TableSubWindow(QWidget):
    """
    Enhanced table view for FITS/astropy tables and editable internal tables:
      - Export CSV
      - Copy selected rows as CSV
      - Search/filter rows
      - Stats panel
      - Plot dialog
      - Optional editing for internal tables
    """
    viewTitleChanged = pyqtSignal(object, str)

    def __init__(self, table_document, parent=None):
        super().__init__(parent)
        self.document = table_document
        self._last_title_for_emit = None

        md = getattr(self.document, "metadata", {}) or {}
        self._editable = bool(md.get("editable", False))

        self.btn_add_row = None
        self.btn_del_row = None
        self.btn_add_col = None

        root = QVBoxLayout(self)

        # --- header row
        header_row = QHBoxLayout()
        self.title_lbl = QLabel(self.document.display_name())
        header_row.addWidget(self.title_lbl)
        header_row.addStretch(1)

        self.search_edit = QLineEdit(self)
        self.search_edit.setPlaceholderText("Search / filter rows…")
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.setMaximumWidth(360)
        header_row.addWidget(self.search_edit)

        if self._editable:
            self.btn_add_row = QPushButton(self.tr("Add Row"), self)
            self.btn_del_row = QPushButton(self.tr("Delete Row(s)"), self)
            self.btn_add_col = QPushButton(self.tr("Add Column"), self)
            header_row.addWidget(self.btn_add_row)
            header_row.addWidget(self.btn_del_row)
            header_row.addWidget(self.btn_add_col)

        self.btn_plot = QPushButton(self.tr("Plot…"), self)
        self.btn_copy = QPushButton(self.tr("Copy Rows"), self)
        self.export_btn = QPushButton(self.tr("Export CSV…"), self)

        header_row.addWidget(self.btn_plot)
        header_row.addWidget(self.btn_copy)
        header_row.addWidget(self.export_btn)

        root.addLayout(header_row)

        # optional table info / warning banner
        self.info_lbl = QLabel(self)
        self.info_lbl.setWordWrap(True)
        self.info_lbl.setVisible(False)
        self.info_lbl.setStyleSheet("""
            QLabel {
                background: rgba(255, 215, 0, 32);
                border: 1px solid rgba(255, 215, 0, 96);
                border-radius: 4px;
                padding: 6px;
            }
        """)
        root.addWidget(self.info_lbl)

        # --- main splitter: table + stats
        split = QSplitter(self)
        split.setOrientation(Qt.Orientation.Horizontal)
        root.addWidget(split, 1)

        # table
        table_wrap = QWidget(self)
        table_lay = QVBoxLayout(table_wrap)
        table_lay.setContentsMargins(0, 0, 0, 0)

        self.table = QTableView(self)
        self.table.setSortingEnabled(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableView.SelectionMode.ExtendedSelection)
        table_lay.addWidget(self.table, 1)

        split.addWidget(table_wrap)

        # stats
        self.stats = TableStatsPanel(self)
        split.addWidget(self.stats)
        split.setStretchFactor(0, 5)
        split.setStretchFactor(1, 1)

        # data/model
        rows = getattr(self.document, "rows", [])
        headers = getattr(self.document, "headers", [])
        column_kinds = list(md.get("column_kinds", []))

        if self._editable:
            self._src_model = EditableTypedTableModel(rows, headers, column_kinds=column_kinds, parent=self)
        else:
            self._src_model = TypedTableModel(rows, headers, self)

        self._proxy = MultiColumnContainsFilterProxy(self)
        self._proxy.setSourceModel(self._src_model)

        self.table.setModel(self._proxy)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.resizeColumnsToContents()

        if self._editable:
            self.table.setEditTriggers(
                QAbstractItemView.EditTrigger.DoubleClicked
                | QAbstractItemView.EditTrigger.EditKeyPressed
                | QAbstractItemView.EditTrigger.SelectedClicked
            )

        # connect signals
        self.export_btn.clicked.connect(self._export_csv)
        self.btn_copy.clicked.connect(self._copy_selected_rows_csv)
        self.btn_plot.clicked.connect(self._open_plot_dialog)
        self.search_edit.textChanged.connect(self._on_search_changed)

        if self._editable:
            if self.btn_add_row is not None:
                self.btn_add_row.clicked.connect(self._add_row)
            if self.btn_del_row is not None:
                self.btn_del_row.clicked.connect(self._delete_selected_rows)
            if self.btn_add_col is not None:
                self.btn_add_col.clicked.connect(self._add_column)

        sel = self.table.selectionModel()
        if sel is not None:
            sel.selectionChanged.connect(self._update_stats_from_selection)

        self._sync_host_title()

        try:
            self.document.changed.connect(self._on_doc_changed)
        except Exception:
            pass

        self._update_info_banner()
        self._update_stats_from_selection()

    # ---- doc/title
    def _on_doc_changed(self):
        self.title_lbl.setText(self.document.display_name())
        self._sync_host_title()
        self._update_info_banner()

    def _mdi_subwindow(self) -> QMdiSubWindow | None:
        w = self.parent()
        while w is not None and not isinstance(w, QMdiSubWindow):
            w = w.parent()
        return w

    def _sync_host_title(self):
        sub = self._mdi_subwindow()
        if not sub:
            return
        title = self.document.display_name()
        if title != sub.windowTitle():
            sub.setWindowTitle(title)
            sub.setToolTip(title)
            if title != self._last_title_for_emit:
                self._last_title_for_emit = title
                try:
                    self.viewTitleChanged.emit(self, title)
                except Exception:
                    pass

    def _update_info_banner(self):
        md = getattr(self.document, "metadata", {}) or {}

        notice = str(md.get("table_notice", "") or "").strip()
        is_hdrlet = bool(md.get("is_hdrlet_table", False))

        if not notice and is_hdrlet:
            notice = (
                "This table appears to be an HDRLET / WCS-correction reference table. "
                "It is shown so all FITS data remains accessible, but it is not a normal "
                "spectrum-style vector table."
            )

        self.info_lbl.setVisible(bool(notice))
        self.info_lbl.setText(notice if notice else "")

    # ---- search/filter
    def _on_search_changed(self, text: str):
        self._proxy.set_needle(text)
        self._update_stats_from_selection()

    # ---- stats
    def _update_stats_from_selection(self, *_):
        nrows_vis = self._proxy.rowCount()
        ncols = self._src_model.columnCount()
        self.stats.set_table_shape(nrows_vis, ncols)

        idx = self.table.currentIndex()
        if not idx.isValid():
            self.stats.set_selection_info("—", False, None, None)
            return

        col = idx.column()
        infos = self._src_model.column_infos()
        if not (0 <= col < len(infos)):
            self.stats.set_selection_info("—", False, None, None)
            return

        ci = infos[col]

        source_rows: List[int] = []
        for pr in range(self._proxy.rowCount()):
            sidx = self._proxy.mapToSource(self._proxy.index(pr, 0))
            sr = sidx.row()
            if sr >= 0:
                source_rows.append(sr)

        if ci.is_numeric:
            arr = self._src_model.vector_column_for_rows(col, source_rows)
            if arr is not None:
                arr = np.asarray(arr, dtype=np.float64)
                arr = arr[np.isfinite(arr)]
            else:
                arr = np.array([], dtype=np.float64)

            st = _calc_stats_numeric(arr)
            label = f"{ci.name} [vector]" if ci.is_vector else ci.name
            self.stats.set_selection_info(label, True, st, None)
            return

        uniq = set()
        cap = 5000
        for pr in range(min(self._proxy.rowCount(), cap)):
            sidx = self._proxy.mapToSource(self._proxy.index(pr, col))
            sr = sidx.row()
            uniq.add(_safe_str(self._src_model.raw_value(sr, col)))

        self.stats.set_selection_info(ci.name, False, None, len(uniq))

    # ---- copy selected rows
    def _copy_selected_rows_csv(self):
        sel = self.table.selectionModel()
        if sel is None:
            return
        rows = sel.selectedRows()
        if not rows:
            QMessageBox.information(self, "Copy", "No rows selected.")
            return

        proxy_rows = sorted({r.row() for r in rows})
        cols = self._src_model.columnCount()
        headers = [self._src_model.headerData(c, Qt.Orientation.Horizontal) for c in range(cols)]
        headers = [str(h) for h in headers]

        out_lines = []
        out_lines.append(",".join([self._csv_escape(h) for h in headers]))

        for pr in proxy_rows:
            sidx0 = self._proxy.mapToSource(self._proxy.index(pr, 0))
            sr = sidx0.row()
            row_vals = []
            for c in range(cols):
                row_vals.append(_safe_str(self._src_model.raw_value(sr, c)))
            out_lines.append(",".join([self._csv_escape(v) for v in row_vals]))

        txt = "\n".join(out_lines)
        QGuiApplication.clipboard().setText(txt)
        QMessageBox.information(self, "Copy", f"Copied {len(proxy_rows)} rows to clipboard as CSV.")

    def _persist_editable_table_back_to_document(self):
        if not self._editable:
            return

        try:
            self.document.rows = [list(r) for r in self._src_model._rows]
            self.document.headers = list(self._src_model._headers)

            md = dict(getattr(self.document, "metadata", {}) or {})
            md["editable"] = True
            if hasattr(self._src_model, "column_kinds"):
                md["column_kinds"] = self._src_model.column_kinds()
            self.document.metadata = md

            try:
                self.document.changed.emit()
            except Exception:
                pass
        except Exception:
            pass

    def _add_row(self):
        if not self._editable:
            return
        self._src_model.insert_rows_at_end(1)
        self._persist_editable_table_back_to_document()
        self._update_stats_from_selection()

    def _delete_selected_rows(self):
        if not self._editable:
            return

        sel = self.table.selectionModel()
        if sel is None:
            return

        proxy_rows = sorted({idx.row() for idx in sel.selectedRows()}, reverse=True)
        if not proxy_rows:
            QMessageBox.information(self, "Delete Rows", "No rows selected.")
            return

        source_rows = []
        for pr in proxy_rows:
            sidx = self._proxy.mapToSource(self._proxy.index(pr, 0))
            if sidx.isValid():
                source_rows.append(int(sidx.row()))

        self._src_model.remove_source_rows(source_rows)
        self._persist_editable_table_back_to_document()
        self._update_stats_from_selection()

    def _add_column(self):
        if not self._editable:
            return

        name, ok = QInputDialog.getText(self, "Add Column", "Column name:")
        if not ok or not str(name).strip():
            return

        kind, ok = QInputDialog.getItem(
            self,
            "Add Column",
            "Column type:",
            ["text", "float", "int", "bool", "ra", "dec", "note"],
            0,
            False,
        )
        if not ok:
            return

        self._src_model.insert_column_at_end(str(name).strip(), str(kind))
        self._persist_editable_table_back_to_document()
        self.table.resizeColumnsToContents()
        self._update_stats_from_selection()

    @staticmethod
    def _csv_escape(s: str) -> str:
        if s is None:
            return ""
        s = str(s)
        if any(ch in s for ch in [",", '"', "\n", "\r"]):
            s = s.replace('"', '""')
            return f'"{s}"'
        return s

    # ---- plot
    def _open_plot_dialog(self):
        dlg = PlotTableDialog(self, self._src_model, self._proxy)
        dlg.setModal(False)
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

    # ---- export csv
    def _export_csv(self):
        existing = getattr(self.document, "metadata", {}).get("table_csv")
        if existing and os.path.exists(existing):
            dst, ok = QFileDialog.getSaveFileName(
                self,
                self.tr("Save CSV As…"),
                os.path.basename(existing),
                self.tr("CSV Files (*.csv)")
            )
            if ok and dst:
                try:
                    import shutil
                    shutil.copyfile(existing, dst)
                except Exception as e:
                    QMessageBox.warning(self, self.tr("Export CSV"), self.tr("Failed to copy CSV:\n{0}").format(e))
            return

        dst, ok = QFileDialog.getSaveFileName(
            self,
            self.tr("Export CSV…"),
            "table.csv",
            self.tr("CSV Files (*.csv)")
        )
        if not ok or not dst:
            return

        try:
            import csv

            cols = self._src_model.columnCount()
            hdrs = [self._src_model.headerData(c, Qt.Orientation.Horizontal) for c in range(cols)]
            hdrs = [str(h) for h in hdrs]

            with open(dst, "w", encoding="utf-8", newline="") as f:
                w = csv.writer(f)
                w.writerow(hdrs)

                for pr in range(self._proxy.rowCount()):
                    sidx0 = self._proxy.mapToSource(self._proxy.index(pr, 0))
                    sr = sidx0.row()
                    row = [_safe_str(self._src_model.raw_value(sr, c)) for c in range(cols)]
                    w.writerow(row)

        except Exception as e:
            QMessageBox.warning(self, self.tr("Export CSV"), self.tr("Failed to export CSV:\n{0}").format(e))