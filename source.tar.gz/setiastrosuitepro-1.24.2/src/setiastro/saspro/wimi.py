import sys
import urllib
# Standard library imports
from tifffile import imwrite
import os
os.environ['LIGHTKURVE_STYLE'] = 'default'
import tempfile
import time
import json
import math
from datetime import datetime, timedelta, timezone
from urllib.parse import quote
import webbrowser
from setiastro.saspro.legacy.xisf import XISF
import requests
import csv
import lz4.block
import zstandard
import ast
from setiastro.saspro.main_helpers import non_blocking_sleep
import platform
from pathlib import Path
from typing import List, Tuple, Set
from io import BytesIO
import re
from collections import defaultdict
from scipy.spatial import KDTree
import matplotlib
matplotlib.use("QtAgg") 
import numpy as np
from typing import List, Tuple, Optional, Callable
import inspect
#if running in IDE which runs ipython or jupiter in backend reconfigure may not be available
if (sys.stdout is not None) and (hasattr(sys.stdout, "reconfigure")):
    sys.stdout.reconfigure(encoding='utf-8')
try:
    from photutils.isophote import Ellipse
except Exception as e:
    Ellipse = EllipseGeometry = build_ellipse_model = None
from astropy.io.votable import parse_single_table
from astropy.table import Table
import sqlite3
import sep
from setiastro.saspro.help_support import make_help_button
from setiastro.saspro import cds_health
import lightkurve as lk
lk.MPLSTYLE = None
from astropy.coordinates import SkyCoord
from astropy import units as u
import plotly.graph_objects as go
from astropy.io.fits import Header
# Reproject for WCS-based alignment
try:
    from reproject import reproject_interp
except ImportError:
    reproject_interp = None  # fallback if not installed

# OpenCV for transform estimation & warping

OPENCV_AVAILABLE = True

# Third-party library imports
import pandas as pd
import cv2
from PIL import Image, ImageDraw, ImageFont

# Astropy and Astroquery imports
from astropy.io import fits
from astropy.time import Time
from astropy.wcs import WCS
from astroquery.simbad import Simbad
from astroquery.mast import Mast
from astroquery.vizier import Vizier
from astropy.utils.data import conf

import numpy.ma as ma
from matplotlib.patches import Circle
from setiastro.saspro.plate_solver import plate_solve_doc_inplace, _active_doc_from_parent, _get_seed_mode, _set_seed_mode, _as_header
from setiastro.saspro.widgets.themed_buttons import themed_toolbtn

#################################
# PyQt6 Imports
#################################
from collections import defaultdict
import fnmatch

# ----- QtWidgets -----
from PyQt6.QtWidgets import (    QApplication,    QWidget,    QVBoxLayout,    QHBoxLayout,    QLabel,    QPushButton,    QFileDialog,    QGraphicsView,    QGraphicsScene,    QMessageBox,    QInputDialog,    QTreeWidget,
    QTreeWidgetItem,    QFrame,    QCheckBox,    QDialog,    QFormLayout,    QSpinBox,    QDialogButtonBox,    QGridLayout,    QGraphicsEllipseItem,    QGraphicsLineItem,    QGraphicsRectItem,
    QGraphicsPathItem,    QDoubleSpinBox,    QColorDialog,    QFontDialog,    QStyle,    QAbstractItemView,    
    QGroupBox,    QGraphicsTextItem,    QComboBox,    QLineEdit,    QProgressBar,    QGraphicsItem,
    QToolButton,    QStatusBar,    QMenu,     QProgressDialog,     QDockWidget,    QDateTimeEdit
)

# ----- QtGui -----
from PyQt6.QtGui import (QPixmap,QImage,    QPainter,    QPen,    QColor,    QTransform,    QIcon,    QPainterPath,    QKeySequence,    QFont,    QBrush,    QShortcut,    
    QPalette,     QAction  
)

# ----- QtCore -----
from PyQt6.QtCore import (    Qt,    QRectF,    QLineF,    QPointF,    QThread,    pyqtSignal,    QTimer,    QEvent,    pyqtSlot,  
   QSettings,    QSignalBlocker,    QDateTime, QEventLoop, QStandardPaths
)


# Math functions
from math import sqrt

from setiastro.saspro.legacy.image_manager import load_image, save_image
from setiastro.saspro.imageops.stretch import stretch_color_image, stretch_mono_image
from setiastro.saspro import minorbodycatalog as mbc

# Interactive 3D orbit viewer (shared with the Supernova/Asteroid Hunter).
# Guarded so a missing pyqtgraph.opengl / PyOpenGL degrades to a message
# on the "SASpro Orbit Explorer" choice rather than breaking the module.
try:
    from setiastro.saspro.orbit_explorer import (
        open_orbit_explorer, extract_elements_from_row,
    )
    _HAS_ORBIT_EXPLORER = True
    _ORBIT_EXPLORER_ERR = ""
except Exception as _oe_err:                     # pragma: no cover
    _HAS_ORBIT_EXPLORER = False
    _ORBIT_EXPLORER_ERR = str(_oe_err)

    def extract_elements_from_row(_row):
        return None

    def open_orbit_explorer(*_a, **_k):
        return None

from setiastro.saspro.resources import get_icon_path

# Determine if running inside a PyInstaller bundle
if hasattr(sys, '_MEIPASS'):
    # Set path for PyInstaller bundle
    data_path = os.path.join(sys._MEIPASS, "astroquery", "simbad", "data")
else:
    # Set path using astroquery package location (cross-platform)
    try:
        import astroquery.simbad
        data_path = os.path.join(os.path.dirname(astroquery.simbad.__file__), "data")
    except Exception:
        # Fallback: try to find in site-packages
        import site
        for sp in site.getsitepackages():
            candidate = os.path.join(sp, "astroquery", "simbad", "data")
            if os.path.isdir(candidate):
                data_path = candidate
                break
        else:
            data_path = ""  # Will fail gracefully if not found

# Ensure the final path doesn't contain 'data/data' duplication
if 'data/data' in data_path:
    data_path = data_path.replace('data/data', 'data')

if data_path:
    conf.dataurl = f'file://{data_path}/'


from setiastro.saspro.resources import (
    wrench_path,
    eye_icon_path,
    disk_icon_path,
    nuke_path,
    hubble_path,
    collage_path,
    annotated_path,
    colorwheel_path,
    font_path,
    csv_icon_path,
    hrdiagram_path,
)


# Constants for comoving radial distance calculation
H0 = 69.6  # Hubble constant in km/s/Mpc
WM = 0.286  # Omega(matter)
WV = 0.714  # Omega(vacuum)
c = 299792.458  # speed of light in km/s
Tyr = 977.8  # coefficient to convert 1/H into Gyr
Mpc_to_Gly = 3.262e-3  # Conversion from Mpc to Gly

otype_long_name_lookup = {
    "ev": "transient event",
    "Rad": "Radio-source",
    "mR": "metric Radio-source",
    "cm": "centimetric Radio-source",
    "mm": "millimetric Radio-source",
    "smm": "sub-millimetric source",
    "HI": "HI (21cm) source",
    "rB": "radio Burst",
    "Mas": "Maser",
    "IR": "Infra-Red source",
    "FIR": "Far-Infrared source",
    "MIR": "Mid-Infrared source",
    "NIR": "Near-Infrared source",
    "blu": "Blue object",
    "UV": "UV-emission source",
    "X": "X-ray source",
    "UX?": "Ultra-luminous X-ray candidate",
    "ULX": "Ultra-luminous X-ray source",
    "gam": "gamma-ray source",
    "gB": "gamma-ray Burst",
    "err": "Not an object (error, artefact, ...)",
    "grv": "Gravitational Source",
    "Lev": "(Micro)Lensing Event",
    "LS?": "Possible gravitational lens System",
    "Le?": "Possible gravitational lens",
    "LI?": "Possible gravitationally lensed image",
    "gLe": "Gravitational Lens",
    "gLS": "Gravitational Lens System (lens+images)",
    "GWE": "Gravitational Wave Event",
    "..?": "Candidate objects",
    "G?": "Possible Galaxy",
    "SC?": "Possible Supercluster of Galaxies",
    "C?G": "Possible Cluster of Galaxies",
    "Gr?": "Possible Group of Galaxies",
    "**?": "Physical Binary Candidate",
    "EB?": "Eclipsing Binary Candidate",
    "Sy?": "Symbiotic Star Candidate",
    "CV?": "Cataclysmic Binary Candidate",
    "No?": "Nova Candidate",
    "XB?": "X-ray binary Candidate",
    "LX?": "Low-Mass X-ray binary Candidate",
    "HX?": "High-Mass X-ray binary Candidate",
    "Pec?": "Possible Peculiar Star",
    "Y*?": "Young Stellar Object Candidate",
    "TT?": "T Tau star Candidate",
    "C*?": "Possible Carbon Star",
    "S*?": "Possible S Star",
    "OH?": "Possible Star with envelope of OH/IR type",
    "WR?": "Possible Wolf-Rayet Star",
    "Be?": "Possible Be Star",
    "Ae?": "Possible Herbig Ae/Be Star",
    "HB?": "Possible Horizontal Branch Star",
    "RR?": "Possible Star of RR Lyr type",
    "Ce?": "Possible Cepheid",
    "WV?": "Possible Variable Star of W Vir type",
    "RB?": "Possible Red Giant Branch star",
    "sg?": "Possible Supergiant star",
    "s?r": "Possible Red supergiant star",
    "s?y": "Possible Yellow supergiant star",
    "s?b": "Possible Blue supergiant star",
    "AB?": "Asymptotic Giant Branch Star candidate",
    "LP?": "Long Period Variable candidate",
    "Mi?": "Mira candidate",
    "pA?": "Post-AGB Star Candidate",
    "BS?": "Candidate blue Straggler Star",
    "HS?": "Hot subdwarf candidate",
    "WD?": "White Dwarf Candidate",
    "N*?": "Neutron Star Candidate",
    "BH?": "Black Hole Candidate",
    "SN?": "SuperNova Candidate",
    "LM?": "Low-mass star candidate",
    "BD?": "Brown Dwarf Candidate",
    "mul": "Composite object",
    "reg": "Region defined in the sky",
    "vid": "Underdense region of the Universe",
    "SCG": "Supercluster of Galaxies",
    "ClG": "Cluster of Galaxies",
    "GrG": "Group of Galaxies",
    "CGG": "Compact Group of Galaxies",
    "PaG": "Pair of Galaxies",
    "IG": "Interacting Galaxies",
    "C?*": "Possible (open) star cluster",
    "Gl?": "Possible Globular Cluster",
    "Cl*": "Cluster of Stars",
    "GlC": "Globular Cluster",
    "OpC": "Open (galactic) Cluster",
    "As*": "Association of Stars",
    "St*": "Stellar Stream",
    "MGr": "Moving Group",
    "**": "Double or multiple star",
    "EB*": "Eclipsing binary",
    "Al*": "Eclipsing binary of Algol type",
    "bL*": "Eclipsing binary of beta Lyr type",
    "WU*": "Eclipsing binary of W UMa type",
    "SB*": "Spectroscopic binary",
    "El*": "Ellipsoidal variable Star",
    "Sy*": "Symbiotic Star",
    "CV*": "Cataclysmic Variable Star",
    "DQ*": "CV DQ Her type (intermediate polar)",
    "AM*": "CV of AM Her type (polar)",
    "NL*": "Nova-like Star",
    "No*": "Nova",
    "DN*": "Dwarf Nova",
    "XB*": "X-ray Binary",
    "LXB": "Low Mass X-ray Binary",
    "HXB": "High Mass X-ray Binary",
    "ISM": "Interstellar matter",
    "PoC": "Part of Cloud",
    "PN?": "Possible Planetary Nebula",
    "CGb": "Cometary Globule",
    "bub": "Bubble",
    "EmO": "Emission Object",
    "Cld": "Cloud",
    "GNe": "Galactic Nebula",
    "DNe": "Dark Cloud (nebula)",
    "RNe": "Reflection Nebula",
    "MoC": "Molecular Cloud",
    "glb": "Globule (low-mass dark cloud)",
    "cor": "Dense core",
    "SFR": "Star forming region",
    "HVC": "High-velocity Cloud",
    "HII": "HII (ionized) region",
    "PN": "Planetary Nebula",
    "sh": "HI shell",
    "SR?": "SuperNova Remnant Candidate",
    "SNR": "SuperNova Remnant",
    "of?": "Outflow candidate",
    "out": "Outflow",
    "HH": "Herbig-Haro Object",
    "*": "Star",
    "V*?": "Star suspected of Variability",
    "Pe*": "Peculiar Star",
    "HB*": "Horizontal Branch Star",
    "Y*O": "Young Stellar Object",
    "Ae*": "Herbig Ae/Be star",
    "Em*": "Emission-line Star",
    "Be*": "Be Star",
    "BS*": "Blue Straggler Star",
    "RG*": "Red Giant Branch star",
    "AB*": "Asymptotic Giant Branch Star (He-burning)",
    "C*": "Carbon Star",
    "S*": "S Star",
    "sg*": "Evolved supergiant star",
    "s*r": "Red supergiant star",
    "s*y": "Yellow supergiant star",
    "s*b": "Blue supergiant star",
    "HS*": "Hot subdwarf",
    "pA*": "Post-AGB Star (proto-PN)",
    "WD*": "White Dwarf",
    "LM*": "Low-mass star (M<1solMass)",
    "BD*": "Brown Dwarf (M<0.08solMass)",
    "N*": "Confirmed Neutron Star",
    "OH*": "OH/IR star",
    "TT*": "T Tau-type Star",
    "WR*": "Wolf-Rayet Star",
    "PM*": "High proper-motion Star",
    "HV*": "High-velocity Star",
    "V*": "Variable Star",
    "Ir*": "Variable Star of irregular type",
    "Or*": "Variable Star of Orion Type",
    "Er*": "Eruptive variable Star",
    "RC*": "Variable Star of R CrB type",
    "RC?": "Variable Star of R CrB type candidate",
    "Ro*": "Rotationally variable Star",
    "a2*": "Variable Star of alpha2 CVn type",
    "Psr": "Pulsar",
    "BY*": "Variable of BY Dra type",
    "RS*": "Variable of RS CVn type",
    "Pu*": "Pulsating variable Star",
    "RR*": "Variable Star of RR Lyr type",
    "Ce*": "Cepheid variable Star",
    "dS*": "Variable Star of delta Sct type",
    "RV*": "Variable Star of RV Tau type",
    "WV*": "Variable Star of W Vir type",
    "bC*": "Variable Star of beta Cep type",
    "cC*": "Classical Cepheid (delta Cep type)",
    "gD*": "Variable Star of gamma Dor type",
    "SX*": "Variable Star of SX Phe type (subdwarf)",
    "LP*": "Long-period variable star",
    "Mi*": "Variable Star of Mira Cet type",
    "SN*": "SuperNova",
    "su*": "Sub-stellar object",
    "Pl?": "Extra-solar Planet Candidate",
    "Pl": "Extra-solar Confirmed Planet",
    "G": "Galaxy",
    "PoG": "Part of a Galaxy",
    "GiC": "Galaxy in Cluster of Galaxies",
    "BiC": "Brightest galaxy in a Cluster (BCG)",
    "GiG": "Galaxy in Group of Galaxies",
    "GiP": "Galaxy in Pair of Galaxies",
    "rG": "Radio Galaxy",
    "H2G": "HII Galaxy",
    "LSB": "Low Surface Brightness Galaxy",
    "AG?": "Possible Active Galaxy Nucleus",
    "Q?": "Possible Quasar",
    "Bz?": "Possible Blazar",
    "BL?": "Possible BL Lac",
    "EmG": "Emission-line galaxy",
    "SBG": "Starburst Galaxy",
    "bCG": "Blue compact Galaxy",
    "LeI": "Gravitationally Lensed Image",
    "LeG": "Gravitationally Lensed Image of a Galaxy",
    "LeQ": "Gravitationally Lensed Image of a Quasar",
    "AGN": "Active Galaxy Nucleus",
    "LIN": "LINER-type Active Galaxy Nucleus",
    "SyG": "Seyfert Galaxy",
    "Sy1": "Seyfert 1 Galaxy",
    "Sy2": "Seyfert 2 Galaxy",
    "Bla": "Blazar",
    "BLL": "BL Lac - type object",
    "OVV": "Optically Violently Variable object",
    "QSO": "Quasar"
}


# ────────────────────────────────────────────────
# 1a) Map each SIMBAD otype → one of our high-level categories
# ────────────────────────────────────────────────
OTYPE_TO_CATEGORY = {
    # Transient & Explosive Events
    "ev":   "Transient & Explosive",
    "rB":   "Transient & Explosive",
    "gB":   "Transient & Explosive",
    "GWE":  "Transient & Explosive",
    "SN*":  "Transient & Explosive",
    "SN?":  "Transient & Explosive",
    "SR?":  "Transient & Explosive",
    "SNR":  "Transient & Explosive",
    "Lev":  "Transient & Explosive",

    # High-Energy / X-ray / γ-ray
    "X":    "High-Energy / X-ray / γ-ray",
    "UX?":  "High-Energy / X-ray / γ-ray",
    "ULX":  "High-Energy / X-ray / γ-ray",
    "gam":  "High-Energy / X-ray / γ-ray",
    "grv":  "High-Energy / X-ray / γ-ray",
    "Psr":  "High-Energy / X-ray / γ-ray",
    "N*?":  "High-Energy / X-ray / γ-ray",
    "BH?":  "High-Energy / X-ray / γ-ray",

    # Radio & sub-millimetric
    "Rad":  "Radio & Sub-mm",
    "mR":   "Radio & Sub-mm",
    "cm":   "Radio & Sub-mm",
    "mm":   "Radio & Sub-mm",
    "smm":  "Radio & Sub-mm",
    "HI":   "Radio & Sub-mm",
    "Mas":  "Radio & Sub-mm",

    # IR / Optical / UV / Blue
    "IR":   "IR / Optical / UV",
    "FIR":  "IR / Optical / UV",
    "MIR":  "IR / Optical / UV",
    "NIR":  "IR / Optical / UV",
    "UV":   "IR / Optical / UV",
    "blu":  "IR / Optical / UV",

    # Gravitational Lensing & Microlensing
    "Lev":  "Gravitational Lensing",
    "LS?":  "Gravitational Lensing",
    "Le?":  "Gravitational Lensing",
    "LI?":  "Gravitational Lensing",
    "gLe":  "Gravitational Lensing",
    "gLS":  "Gravitational Lensing",

    # Stars & Stellar Objects
    "*":    "Stars & Stellar",
    "V*":   "Stars & Stellar",
    "Pe*":  "Stars & Stellar",
    "HB*":  "Stars & Stellar",
    "Y*O":  "Stars & Stellar",
    "Ae*":  "Stars & Stellar",
    "Em*":  "Stars & Stellar",
    "Be*":  "Stars & Stellar",
    "BS*":  "Stars & Stellar",
    "RG*":  "Stars & Stellar",
    "AB*":  "Stars & Stellar",
    "C*":   "Stars & Stellar",
    "S*":   "Stars & Stellar",
    "sg*":  "Stars & Stellar",
    "s*r":  "Stars & Stellar",
    "s*y":  "Stars & Stellar",
    "s*b":  "Stars & Stellar",
    "HS*":  "Stars & Stellar",
    "pA*":  "Stars & Stellar",
    "WD*":  "Stars & Stellar",
    "LM*":  "Stars & Stellar",
    "BD*":  "Stars & Stellar",
    "N*":   "Stars & Stellar",
    "OH*":  "Stars & Stellar",
    "TT*":  "Stars & Stellar",
    "WR*":  "Stars & Stellar",
    "PM*":  "Stars & Stellar",
    "HV*":  "Stars & Stellar",
    "C?*":  "Stars & Stellar",
    "Pec?": "Stars & Stellar",
    "Y*?":  "Stars & Stellar",
    "TT?":  "Stars & Stellar",
    "C*?":  "Stars & Stellar",
    "S*?":  "Stars & Stellar",
    "OH?":  "Stars & Stellar",
    "WR?":  "Stars & Stellar",
    "Be?":  "Stars & Stellar",
    "Ae?":  "Stars & Stellar",
    "HB?":  "Stars & Stellar",
    "RB?":  "Stars & Stellar",
    "sg?":  "Stars & Stellar",
    "s?r":  "Stars & Stellar",
    "s?y":  "Stars & Stellar",
    "s?b":  "Stars & Stellar",
    "pA?":  "Stars & Stellar",
    "BS?":  "Stars & Stellar",
    "HS?":  "Stars & Stellar",
    "WD?":  "Stars & Stellar",    

    # Binaries & Multiples / Variables
    "**":   "Binaries & Variables",
    "EB*":  "Binaries & Variables",
    "Al*":  "Binaries & Variables",
    "bL*":  "Binaries & Variables",
    "WU*":  "Binaries & Variables",
    "SB*":  "Binaries & Variables",
    "El*":  "Binaries & Variables",
    "Sy*":  "Binaries & Variables",
    "CV*":  "Binaries & Variables",
    "DQ*":  "Binaries & Variables",
    "AM*":  "Binaries & Variables",
    "NL*":  "Binaries & Variables",
    "No*":  "Binaries & Variables",
    "DN*":  "Binaries & Variables",
    "XB*":  "Binaries & Variables",
    "LXB":  "Binaries & Variables",
    "HXB":  "Binaries & Variables",
    "Pl?":  "Binaries & Variables",
    "Ce?":  "Binaries & Variables",
    "Ce*":  "Binaries & Variables",
    "cC*":  "Binaries & Variables",
    "**?":  "Binaries & Variables",
    "EB?":  "Binaries & Variables",
    "Sy?":  "Binaries & Variables",
    "CV?":  "Binaries & Variables",
    "No?":  "Binaries & Variables",
    "XB?":  "Binaries & Variables",
    "LX?":  "Binaries & Variables",
    "HX?":  "Binaries & Variables",
    "RR?":  "Binaries & Variables",
    "WV?":  "Binaries & Variables",
    "LP?":  "Binaries & Variables",
    "Mi?":  "Binaries & Variables",
    "Ce?":  "Binaries & Variables",
    "cC*":  "Binaries & Variables",
    "Pl?":  "Binaries & Variables",    

    # Clusters & Associations
    "Cl*":  "Clusters & Associations",
    "GlC":  "Clusters & Associations",
    "OpC":  "Clusters & Associations",
    "As*":  "Clusters & Associations",
    "St*":  "Clusters & Associations",
    "MGr":  "Clusters & Associations",
    "C?*":  "Clusters & Associations",
    "Gl?":  "Clusters & Associations",    

    # Nebulae & Interstellar Matter
    "PN":   "Nebulae & ISM",
    "PN?":  "Nebulae & ISM",
    "EmO":  "Nebulae & ISM",
    "GNe":  "Nebulae & ISM",
    "DNe":  "Nebulae & ISM",
    "RNe":  "Nebulae & ISM",
    "MoC":  "Nebulae & ISM",
    "Cld":  "Nebulae & ISM",
    "bub":  "Nebulae & ISM",
    "Cld":  "Nebulae & ISM",
    "Cld":  "Nebulae & ISM",
    "sh":   "Nebulae & ISM",
    "SFR":  "Nebulae & ISM",
    "HVC":  "Nebulae & ISM",
    "CGb":  "Nebulae & ISM",
    "PoC":  "Nebulae & ISM",
    "glb":  "Nebulae & ISM",
    "cor":  "Nebulae & ISM",
    "out":  "Nebulae & ISM",
    "HH":   "Nebulae & ISM",
    "HII":  "Nebulae & ISM",
    "ISM":  "Nebulae & ISM",
    "of?":  "Nebulae & ISM",    

    # Galaxies & Active Nuclei
    "G":    "Galaxies & AGN",
    "PoG":  "Galaxies & AGN",
    "EmG":  "Galaxies & AGN",
    "SBG":  "Galaxies & AGN",
    "LSB":  "Galaxies & AGN",
    "AGN":  "Galaxies & AGN",
    "LIN":  "Galaxies & AGN",
    "SyG":  "Galaxies & AGN",
    "Sy1":  "Galaxies & AGN",
    "Sy2":  "Galaxies & AGN",
    "Bla":  "Galaxies & AGN",
    "BLL":  "Galaxies & AGN",
    "OVV":  "Galaxies & AGN",
    "QSO":  "Galaxies & AGN",
    "Q?":   "Galaxies & AGN",
    "AG?":  "Galaxies & AGN",
    "G?":   "Galaxies & AGN",
    "IG":   "Galaxies & AGN",
    "GiC":  "Galaxies & AGN",
    "BiC":  "Galaxies & AGN",
    "GiP":  "Galaxies & AGN",
    "rG":   "Galaxies & AGN",
    "H2G":  "Galaxies & AGN",
    "Bz?":  "Galaxies & AGN",
    "BL?":  "Galaxies & AGN",    


    # Large-Scale Structure: clusters, superclusters, voids
    "ClG":  "Large-Scale Structure",
    "GrG":  "Large-Scale Structure",
    "CGG":  "Large-Scale Structure",
    "PaG":  "Large-Scale Structure",
    "SCG":  "Large-Scale Structure",
    "SC?":  "Large-Scale Structure",
    "C?G":  "Large-Scale Structure",
    "Gr?":  "Large-Scale Structure",
    "vid":  "Large-Scale Structure",
    "GiG":  "Large-Scale Structure",

    # Regions, Clouds & Artefacts
    "reg":  "Regions & Clouds",
    "mul":  "Regions & Clouds",

    # Errors & Artefacts / Unknown
    "err":  "Errors & Artefacts",
    "..?":  "Errors & Artefacts",  
}

# ────────────────────────────────────────────────
# 1b) Assign each category a distinct QColor
# ────────────────────────────────────────────────
CATEGORY_TO_COLOR = {
    "Transient & Explosive":        QColor(255,   0,   0),  # red
    "High-Energy / X-ray / γ-ray":  QColor(255, 165,   0),  # orange
    "Radio & Sub-mm":               QColor(128,   0, 128),  # purple
    "IR / Optical / UV":            QColor(  0, 128,   0),  # green
    "Gravitational Lensing":        QColor(218, 112, 214),  # orchid
    "Stars & Stellar":              QColor(  0,   0, 255),  # blue
    "Binaries & Variables":         QColor(255, 255,   0),  # yellow
    "Clusters & Associations":      QColor(165,  42,  42),  # brown
    "Nebulae & ISM":                QColor(  0, 128, 128),  # teal
    "Galaxies & AGN":               QColor(255,   0, 255),  # magenta
    "Large-Scale Structure":        QColor( 200,  200,  200),  # dark gray
    "Regions & Clouds":             QColor( 95, 158, 160),  # cadet blue
    "Errors & Artefacts":           QColor(128, 128, 128),  # gray
}



# SIMBAD endpoint configuration.
#
# TIMEOUT was renamed to lowercase `timeout` in astroquery 0.4.8, so on a
# current astroquery the old spelling is a silent no-op and every call falls
# back to the OS TCP timeout (~130 s on Linux, ~21 s on Windows). Set both
# names. And keep the value well under the old 300 s — five minutes is a
# sane ceiling for a slow-but-alive archive and exactly what makes a dead
# one feel like a hang.
Simbad.ROW_LIMIT = 0  # Remove row limit for full results

_SIMBAD_TIMEOUT_S = 45


def _configure_simbad_endpoint(server: str | None = None,
                               timeout: float = _SIMBAD_TIMEOUT_S) -> str:
    """
    Point astroquery at `server` (or whichever mirror cds_health last found
    healthy) and bound its timeouts. Returns the hostname actually selected so
    callers can build matching sim-sam / sim-basic URLs against the same host.
    """
    import astroquery.simbad as _aqs

    host = server or cds_health.current_server()
    for setter in (
        lambda: setattr(_aqs.conf, "server", host),
        lambda: setattr(Simbad, "server", host),
        lambda: setattr(_aqs.conf, "timeout", float(timeout)),
        lambda: setattr(Simbad, "timeout", float(timeout)),
        lambda: setattr(Simbad, "TIMEOUT", float(timeout)),
    ):
        try:
            setter()
        except Exception:
            pass
    return host


_configure_simbad_endpoint()

# Astrometry.net API constants
ASTROMETRY_API_URL = "http://nova.astrometry.net/api/"
ASTROMETRY_API_KEY_FILE = "astrometry_api_key.txt"

def save_api_key(api_key):
    # Bare QSettings() -> app-default store (inherits org/app set at startup).
    QSettings().setValue("astrometry_api_key", api_key)
    print("API key saved.")

def load_api_key():
    s = QSettings()
    api_key = s.value("astrometry_api_key", "")
    if not api_key:
        # One-time migration from the old hard-coded store, if a key was
        # saved there by a previous build. Harmless if the stores coincide.
        legacy = QSettings("Seti Astro", "Seti Astro Suite").value("astrometry_api_key", "")
        if legacy:
            s.setValue("astrometry_api_key", legacy)
            api_key = legacy
    if api_key:
        print("API key loaded.")
    return api_key

def _find_main_window(w):
    p = w.parent()
    while p and not (hasattr(p, "doc_manager") or hasattr(p, "docman")):
        p = p.parent()
    return p


# --- MarkerLayer: one lightweight item that draws all markers efficiently ---
from PyQt6.QtWidgets import QGraphicsItem
from PyQt6.QtCore import QRectF, QPointF, Qt
from PyQt6.QtGui import QPainter, QPen, QColor

class MarkerLayer(QGraphicsItem):
    def __init__(self, image_w, image_h, show_names_fn, color_fn, style_fn,
                 selected_name_fn=lambda: None, show_active_name_fn=lambda: False,
                 name_font_fn=None, name_color_fn=None,
                 radius_px=6, cell=64, parent=None):
        super().__init__(parent)
        self._w, self._h = image_w, image_h
        self._bounds = QRectF(0, 0, self._w, self._h)
        self._radius = radius_px
        self._cell = cell
        self._grid = {}
        self._show_names = show_names_fn
        self._color = color_fn              # fallback color
        self._style = style_fn
        self._selected_name = selected_name_fn
        self._show_active_name = show_active_name_fn
        # Object-name label styling (configurable in WIMI Settings). Defaults
        # keep the old look (Arial 12, white) when no getters are supplied.
        self._name_font = name_font_fn or (lambda: QFont("Arial", 12))
        self._name_color = name_color_fn or (lambda: QColor(255, 255, 255))
        self.setZValue(100)
        self.setCacheMode(QGraphicsItem.CacheMode.DeviceCoordinateCache)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemUsesExtendedStyleOption, True)
        self.setAcceptedMouseButtons(Qt.MouseButton.NoButton)

    def boundingRect(self) -> QRectF:
        return self._bounds

    def resize(self, w, h):
        if w == self._w and h == self._h:
            return
        self.prepareGeometryChange()
        self._w, self._h = w, h
        self._bounds = QRectF(0, 0, w, h)

    def set_points(self, pts):
        try:
            if self.scene() is None:
                return
        except RuntimeError:
            return

        self._grid.clear()
        c = self._cell
        for p in pts:
            x, y = p["x"], p["y"]
            gx, gy = int(x // c), int(y // c)
            self._grid.setdefault((gx, gy), []).append(p)
        try:
            self.update()
        except RuntimeError:
            pass

    def paint(self, p: QPainter, option, widget):
        vr = option.exposedRect.adjusted(-self._cell, -self._cell, self._cell, self._cell)
        c = self._cell

        show_names = self._show_names()
        style = self._style()
        selected_name = self._selected_name()
        show_active = self._show_active_name()

        # Extract current scene→device scale so we can draw in screen pixels
        t = p.transform()
        # Average of x and y scale factors
        scene_scale = (abs(t.m11()) + abs(t.m22())) / 2.0
        if scene_scale < 1e-9:
            scene_scale = 1.0

        # Fixed screen-space radius in pixels
        FIXED_SCREEN_R = 6.0

        base_pen = QPen()
        base_pen.setCosmetic(True)
        base_pen.setWidth(1)

        gx0 = int(max(0, int(vr.left()  // c)))
        gy0 = int(max(0, int(vr.top()   // c)))
        gx1 = int(int(vr.right()  // c))
        gy1 = int(int(vr.bottom() // c))

        for gy in range(gy0, gy1 + 1):
            for gx in range(gx0, gx1 + 1):
                for pt in self._grid.get((gx, gy), ()):
                    x, y = pt["x"], pt["y"]
                    if not vr.contains(QPointF(x, y)):
                        continue

                    is_sel = bool(selected_name) and pt.get("name") == selected_name
                    col = (QColor(0, 255, 0) if is_sel
                        else pt.get("color", self._color()))
                    base_pen.setColor(col)
                    p.setPen(base_pen)

                    radius_px = pt.get("radius_px")  # scene-space radius, or None
                    ellipse   = pt.get("ellipse")    # (semi_major_px, semi_minor_px, angle_deg) or None

                    if ellipse is not None:
                        # Oriented ellipse from catalog major/minor axis + position angle
                        a_px, b_px, ang_deg = ellipse
                        min_r = FIXED_SCREEN_R / scene_scale
                        a_px = max(a_px, min_r)
                        b_px = max(b_px, min_r)
                        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                        p.save()
                        p.translate(x, y)
                        p.rotate(ang_deg)
                        p.drawEllipse(QPointF(0.0, 0.0), a_px, b_px)
                        p.restore()
                        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
                    elif radius_px is not None and radius_px > 0:
                        # Draw a circle scaled to the object's actual angular size
                        # radius_px is in scene/image pixels → already correct for QPainter scene coords
                        min_r = FIXED_SCREEN_R / scene_scale  # don't go smaller than fixed size
                        r = max(radius_px, min_r)
                        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                        p.drawEllipse(QPointF(x, y), r, r)
                        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
                    else:
                        # Fixed screen-space size: convert screen pixels → scene units
                        r = FIXED_SCREEN_R / scene_scale

                        if style == "Crosshair":
                            p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
                            p.drawLine(QLineF(x - r, y,     x + r, y))
                            p.drawLine(QLineF(x,     y - r, x,     y + r))
                        else:
                            p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                            p.drawEllipse(QPointF(x, y), r, r)
                            p.setRenderHint(QPainter.RenderHint.Antialiasing, False)

                    if pt.get("name") and (show_names or (show_active and is_sel)):
                        text_pen = QPen(self._name_color())
                        text_pen.setCosmetic(True)
                        p.setPen(text_pen)
                        # Configurable font, drawn screen-constant: the point
                        # size is divided by the current zoom so the label is
                        # the same on-screen size at any zoom (the markers are
                        # screen-constant too). pointSizeF is preferred; fall
                        # back to pixelSize when the font was built that way.
                        nf = QFont(self._name_font())
                        base_pt = nf.pointSizeF()
                        p.save()
                        if base_pt > 0:
                            nf.setPointSizeF(max(0.1, base_pt / scene_scale))
                        else:
                            base_px = nf.pixelSize() if nf.pixelSize() > 0 else 12
                            nf.setPixelSize(max(1, int(round(base_px / scene_scale))))
                        p.setFont(nf)
                        # Offset name label by fixed screen amount
                        label_offset = (FIXED_SCREEN_R + 2.0) / scene_scale
                        p.drawText(QPointF(x + label_offset, y - label_offset), str(pt["name"]))
                        p.restore()
                        p.setPen(base_pen)

def _qt_is_alive(obj) -> bool:
    if obj is None:
        return False
    try:
        import shiboken6
        return shiboken6.isValid(obj)
    except Exception:
        pass
    try:
        from PyQt6 import sip
        return not sip.isdeleted(obj)
    except Exception:
        pass
    try:
        _ = obj.scene()
        return True
    except RuntimeError:
        return False


class CustomGraphicsView(QGraphicsView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.setMouseTracking(True)  # Enable mouse tracking
        self.setDragMode(QGraphicsView.DragMode.NoDrag)  # Disable default drag mode to avoid hand cursor
        self.setCursor(Qt.CursorShape.ArrowCursor)  # Set default cursor to arrow
        self.drawing_item = None
        self.start_pos = None     
        self.annotation_items = []  # Store annotation items  
        self.drawing_measurement = False
        self.measurement_start = QPointF()    
        self._search_circle_item = None
         

        self.selected_object = None  # Initialize selected_object to None
        self.show_names = False 

        # Variables for drawing the circle
        self.circle_center = None
        self.circle_radius = 0
        self.drawing_circle = False  # Flag to check if we're currently drawing a circle
        self.dragging = False  # Flag to manage manual dragging


    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if event.modifiers() == Qt.KeyboardModifier.ControlModifier:
                # Start annotation mode with the current tool
                self.start_pos = self.mapToScene(event.pos())

                # Check which tool is currently selected
                if self.parent.current_tool == "Ellipse":
                    self.drawing_item = QGraphicsEllipseItem()
                    self.drawing_item.setPen(QPen(self.parent.selected_color, 2))
                    self.parent.main_scene.addItem(self.drawing_item)

                elif self.parent.current_tool == "Rectangle":
                    self.drawing_item = QGraphicsRectItem()
                    self.drawing_item.setPen(QPen(self.parent.selected_color, 2))
                    self.parent.main_scene.addItem(self.drawing_item)

                elif self.parent.current_tool == "Arrow":
                    self.drawing_item = QGraphicsLineItem()
                    self.drawing_item.setPen(QPen(self.parent.selected_color, 2))
                    self.parent.main_scene.addItem(self.drawing_item)

                elif self.parent.current_tool == "Freehand":
                    self.drawing_item = QGraphicsPathItem()
                    path = QPainterPath(self.start_pos)
                    self.drawing_item.setPath(path)
                    self.drawing_item.setPen(QPen(self.parent.selected_color, 2))
                    self.parent.main_scene.addItem(self.drawing_item)

                elif self.parent.current_tool == "Text":
                    text, ok = QInputDialog.getText(self, "Add Text", "Enter text:")
                    if ok and text:
                        text_item = QGraphicsTextItem(text)
                        text_item.setPos(self.start_pos)
                        text_item.setDefaultTextColor(self.parent.selected_color)  # Use selected color
                        text_item.setFont(self.parent.selected_font)  # Use selected font
                        self.parent.main_scene.addItem(text_item)
                        
                        # Store as ('text', text, position, color)
                        self.annotation_items.append(('text', text, self.start_pos, self.parent.selected_color))


                elif self.parent.current_tool == "Compass":
                    self.place_celestial_compass(self.start_pos)

            elif event.modifiers() == Qt.KeyboardModifier.ShiftModifier:
                # Start drawing a circle for Shift+Click
                self.drawing_circle = True
                self.circle_center = self.mapToScene(event.pos())
                self.circle_radius = 0
                self.parent.status_label.setText("Drawing circle: Shift + Drag")
                self.update_circle()

            elif event.modifiers() == Qt.KeyboardModifier.AltModifier:
                # Start celestial measurement for Alt+Click
                self.measurement_start = self.mapToScene(event.pos())
                self.drawing_measurement = True
                self.drawing_item = None  # Clear any active annotation item
    

            else:
                # Detect if an object circle was clicked without Shift or Ctrl
                scene_pos = self.mapToScene(event.pos())
                clicked_object = self.get_object_at_position(scene_pos)
                
                if clicked_object:
                    # Select the clicked object and redraw
                    self.parent.selected_object = clicked_object
                    self.select_object(clicked_object)
                    self.draw_query_results()
                    self.update_mini_preview()
                    
                    # Highlight the corresponding row in the TreeWidget
                    for i in range(self.parent.results_tree.topLevelItemCount()):
                        item = self.parent.results_tree.topLevelItem(i)
                        if item.text(2) == clicked_object["name"]:  # Assuming third element is 'Name'
                            self.parent.results_tree.setCurrentItem(item)
                            break
                else:
                    # Start manual dragging if no modifier is held
                    self.dragging = True
                    self.setCursor(Qt.CursorShape.ClosedHandCursor)  # Use closed hand cursor to indicate dragging
                    self.drag_start_pos = event.pos()  # Store starting position

        super().mousePressEvent(event)


    def mouseDoubleClickEvent(self, event):
        """Handle double-click on an object in the main image."""
        scene_pos = self.mapToScene(event.pos())
        clicked_object = self.get_object_at_position(scene_pos)

        if clicked_object:
            object_name = clicked_object.get("name")
            ra  = float(clicked_object.get("ra"))
            dec = float(clicked_object.get("dec"))
            source = clicked_object.get("source", "Simbad")
            kind   = clicked_object.get("long_type", "") or clicked_object.get("type", "")

            s = (source or "").strip().lower()

            # --- Minor-body overlays → choose how to explore ---
            if s.startswith("minordb"):
                prompt_minor_body_choice(self.parent, object_name, kind=kind)
                return

            if source == "Simbad" and object_name:
                # Open Simbad URL with encoded object name
                encoded_name = quote(object_name)
                url = f"https://simbad.cds.unistra.fr/simbad/sim-basic?Ident={encoded_name}&submit=SIMBAD+search"
                webbrowser.open(url)
            elif source == "GaiaLocal":
                # Simbad has no reverse index on Gaia DR3 ids — sim-id 404s
                # for the fainter sources that motivated the augment in the
                # first place. 20" cone at the star's coords always lands.
                ra_f  = clicked_object.get("ra")
                dec_f = clicked_object.get("dec")
                if ra_f is None or dec_f is None:
                    return
                url = (
                    "https://simbad.cds.unistra.fr/simbad/sim-coo?"
                    f"Coord={ra_f:+.6f}{dec_f:+.6f}"
                    "&CooFrame=ICRS&CooEpoch=2000&CooEqui=2000"
                    "&Radius=20&Radius.unit=arcsec"
                    "&submit=submit+query"
                )
                webbrowser.open(url)
            elif source == "Vizier":
                # Format the NED search URL with proper RA, Dec, and radius
                radius = 5 / 60  # Radius in arcminutes (5 arcseconds)
                dec_sign = "%2B" if dec >= 0 else "-"  # Determine sign for declination
                ned_url = (
                    f"http://ned.ipac.caltech.edu/conesearch?search_type=Near%20Position%20Search"
                    f"&ra={ra:.6f}d&dec={dec_sign}{abs(dec):.6f}d&radius={radius:.3f}"
                    "&in_csys=Equatorial&in_equinox=J2000.0"
                )
                webbrowser.open(ned_url)
            elif source == "Mast":
                # Open MAST URL using RA and Dec with a small radius for object lookup
                mast_url = f"https://mast.stsci.edu/portal/Mashup/Clients/Mast/Portal.html?searchQuery={ra}%2C{dec}%2Cradius%3D0.0006"
                webbrowser.open(mast_url)                
        else:
            super().mouseDoubleClickEvent(event)

    def mouseMoveEvent(self, event):
        scene_pos = self.mapToScene(event.pos())

        if self.drawing_circle:
            # Update the circle radius as the mouse moves
            self.circle_radius = np.sqrt(
                (scene_pos.x() - self.circle_center.x()) ** 2 +
                (scene_pos.y() - self.circle_center.y()) ** 2
            )
            self.update_circle()

        elif self.drawing_measurement:
            # Update the measurement line dynamically as the mouse moves
            if self.drawing_item:
                self.parent.main_scene.removeItem(self.drawing_item)  # Remove previous line if exists
            self.drawing_item = QGraphicsLineItem(QLineF(self.measurement_start, scene_pos))
            self.drawing_item.setPen(QPen(Qt.GlobalColor.green, 2, Qt.PenStyle.DashLine))  # Use green dashed line for measurement
            self.parent.main_scene.addItem(self.drawing_item)

        elif self.drawing_item:
            # Update the current drawing item based on the selected tool and mouse position
            if isinstance(self.drawing_item, QGraphicsEllipseItem) and self.parent.current_tool == "Ellipse":
                # For Ellipse tool, update the ellipse dimensions
                rect = QRectF(self.start_pos, scene_pos).normalized()
                self.drawing_item.setRect(rect)

            elif isinstance(self.drawing_item, QGraphicsRectItem) and self.parent.current_tool == "Rectangle":
                # For Rectangle tool, update the rectangle dimensions
                rect = QRectF(self.start_pos, scene_pos).normalized()
                self.drawing_item.setRect(rect)

            elif isinstance(self.drawing_item, QGraphicsLineItem) and self.parent.current_tool == "Arrow":
                # For Arrow tool, set the line from start_pos to current mouse position
                line = QLineF(self.start_pos, scene_pos)
                self.drawing_item.setLine(line)

            elif isinstance(self.drawing_item, QGraphicsPathItem) and self.parent.current_tool == "Freehand":
                # For Freehand tool, add a line to the path to follow the mouse movement
                path = self.drawing_item.path()
                path.lineTo(scene_pos)
                self.drawing_item.setPath(path)

        elif self.dragging:
            # Handle manual dragging by scrolling the view
            delta = event.pos() - self.drag_start_pos
            self.horizontalScrollBar().setValue(self.horizontalScrollBar().value() - delta.x())
            self.verticalScrollBar().setValue(self.verticalScrollBar().value() - delta.y())
            self.drag_start_pos = event.pos()
        else:
            # Update RA/Dec display as the cursor moves
            self.parent.update_ra_dec_from_mouse(event)
            
        super().mouseMoveEvent(event)
                

    def mouseReleaseEvent(self, event):
        if self.drawing_circle and event.button() == Qt.MouseButton.LeftButton:
            # Stop drawing the circle
            self.drawing_circle = False
            self.parent.circle_center = self.circle_center
            self.parent.circle_radius = self.circle_radius

            # Calculate RA/Dec for the circle center
            ra, dec = self.parent.calculate_ra_dec_from_pixel(self.circle_center.x(), self.circle_center.y())
            if ra is not None and dec is not None:
                self.parent.ra_label.setText(f"RA: {self.parent.convert_ra_to_hms(ra)}")
                self.parent.dec_label.setText(f"Dec: {self.parent.convert_dec_to_dms(dec)}")

                if self.parent.pixscale:
                    radius_arcmin = self.circle_radius * self.parent.pixscale / 60.0
                    self.parent.status_label.setText(
                        f"Circle set at center RA={ra:.6f}, Dec={dec:.6f}, radius={radius_arcmin:.2f} arcmin"
                    )
                else:
                    self.parent.status_label.setText("Pixscale not available for radius calculation.")
            else:
                self.parent.status_label.setText("Unable to determine RA/Dec due to missing WCS.")

            # Update circle data and redraw
            self.parent.update_circle_data()
            self.update_circle()

        elif self.drawing_measurement and event.button() == Qt.MouseButton.LeftButton:
            # Complete the measurement when the mouse is released
            self.drawing_measurement = False
            measurement_end = self.mapToScene(event.pos())

            # Calculate celestial distance between start and end points
            ra1, dec1 = self.parent.calculate_ra_dec_from_pixel(self.measurement_start.x(), self.measurement_start.y())
            ra2, dec2 = self.parent.calculate_ra_dec_from_pixel(measurement_end.x(), measurement_end.y())
            
            if ra1 is not None and dec1 is not None and ra2 is not None and dec2 is not None:
                # Compute the angular distance
                angular_distance = self.parent.calculate_angular_distance(ra1, dec1, ra2, dec2)
                distance_text = self.parent.format_distance_as_dms(angular_distance)

                # Create and add the line item for display
                measurement_line_item = QGraphicsLineItem(QLineF(self.measurement_start, measurement_end))
                measurement_line_item.setPen(QPen(Qt.GlobalColor.green, 2, Qt.PenStyle.DashLine))
                self.parent.main_scene.addItem(measurement_line_item)

                # Create a midpoint position for the distance text
                midpoint = QPointF(
                    (self.measurement_start.x() + measurement_end.x()) / 2,
                    (self.measurement_start.y() + measurement_end.y()) / 2
                )

                # Create and add the text item at the midpoint
                text_item = QGraphicsTextItem(distance_text)
                text_item.setPos(midpoint)
                text_item.setDefaultTextColor(Qt.GlobalColor.green)
                text_item.setFont(self.parent.selected_font)  # Use the selected font
                self.parent.main_scene.addItem(text_item)

                # Store the line and text in annotation items for future reference
                measurement_line = QLineF(self.measurement_start, measurement_end)
                self.annotation_items.append(('line', measurement_line, QColor(0, 255, 0)))
                self.annotation_items.append(('text', distance_text, midpoint, QColor(0, 255, 0)))

            # Clear the temporary measurement line item without removing the final line
            self.drawing_item = None



        elif self.drawing_item and event.button() == Qt.MouseButton.LeftButton:
            # Finalize the shape drawing and add its properties to annotation_items
            if isinstance(self.drawing_item, QGraphicsEllipseItem):
                rect = self.drawing_item.rect()
                color = self.drawing_item.pen().color()
                self.annotation_items.append(('ellipse', rect, color))
            elif isinstance(self.drawing_item, QGraphicsRectItem):
                rect = self.drawing_item.rect()
                color = self.drawing_item.pen().color()
                self.annotation_items.append(('rect', rect, color))
            elif isinstance(self.drawing_item, QGraphicsLineItem):
                line = self.drawing_item.line()
                color = self.drawing_item.pen().color()
                self.annotation_items.append(('line', line, color))
            elif isinstance(self.drawing_item, QGraphicsTextItem):
                pos = self.drawing_item.pos()
                text = self.drawing_item.toPlainText()
                color = self.drawing_item.defaultTextColor()
                self.annotation_items.append(('text', text, pos, color))
            elif isinstance(self.drawing_item, QGraphicsPathItem):  # Handle Freehand
                path = self.drawing_item.path()
                color = self.drawing_item.pen().color()
                self.annotation_items.append(('freehand', path, color))        

            # Clear the temporary drawing item
            self.drawing_item = None

        # Stop manual dragging and reset cursor to arrow
        self.dragging = False
        self.setCursor(Qt.CursorShape.ArrowCursor)
        
        # Update the mini preview to reflect any changes
        self.update_mini_preview()

        super().mouseReleaseEvent(event)

    def contextMenuEvent(self, event):
        """Right-click context menu for an object under the cursor."""
        scene_pos = self.mapToScene(event.pos())
        clicked_object = self.get_object_at_position(scene_pos)

        if not clicked_object:
            super().contextMenuEvent(event)
            return

        # Select it first so the tree/main view stay in sync
        self.parent.selected_object = clicked_object
        self.select_object(clicked_object)
        self.draw_query_results()
        self.update_mini_preview()
        for i in range(self.parent.results_tree.topLevelItemCount()):
            item = self.parent.results_tree.topLevelItem(i)
            if item.text(2) == clicked_object.get("name"):
                self.parent.results_tree.setCurrentItem(item)
                break

        menu = QMenu(self)

        name   = clicked_object.get("name", "")
        ra     = clicked_object.get("ra")
        dec    = clicked_object.get("dec")
        source = (clicked_object.get("source", "Simbad") or "Simbad").strip()

        act_open = menu.addAction(f"Open Website ({source})")
        act_open.triggered.connect(lambda: self._open_object_website(clicked_object))

        act_zoom = menu.addAction("Zoom to Object")
        act_zoom.triggered.connect(lambda: self.zoom_to_coordinates(ra, dec))

        act_copy_radec = menu.addAction("Copy RA/Dec")
        act_copy_radec.triggered.connect(lambda: self._copy_object_radec(clicked_object))

        act_copy_info = menu.addAction("Copy Object Information")
        act_copy_info.triggered.connect(lambda: self.parent.copy_object_information(
            self._tree_item_for_object(clicked_object)
        ))

        menu.addSeparator()

        try:
            from setiastro.saspro.gaia_database import get_library
            has_lib = bool(get_library().installed_bands())
        except Exception:
            has_lib = False

        act_spectrum = menu.addAction("View Gaia XP Spectrum")
        act_spectrum.setEnabled(has_lib)
        if not has_lib:
            act_spectrum.setToolTip("No Gaia library installed — use Settings → Gaia XP Spectral Library")
        act_spectrum.triggered.connect(lambda: self.parent._show_gaia_spectrum_for_item(
            self._tree_item_for_object(clicked_object)
        ))

        menu.addSeparator()

        act_delete = menu.addAction("Delete Object")
        act_delete.triggered.connect(lambda: self._delete_object(clicked_object))

        menu.exec(event.globalPos())

    def _tree_item_for_object(self, obj):
        """Find the QTreeWidgetItem matching this object's name."""
        name = obj.get("name")
        for i in range(self.parent.results_tree.topLevelItemCount()):
            item = self.parent.results_tree.topLevelItem(i)
            if item.text(2) == name:
                return item
        return None

    def _open_object_website(self, obj):
        name   = obj.get("name", "")
        ra     = obj.get("ra")
        dec    = obj.get("dec")
        source = (obj.get("source", "Simbad") or "Simbad").strip()
        kind   = obj.get("long_type", "") or obj.get("type", "")

        s = source.lower()
        if s.startswith("minordb"):
            prompt_minor_body_choice(self.parent, name, kind=kind)
            return

        try:
            ra_f, dec_f = float(ra), float(dec)
        except (TypeError, ValueError):
            ra_f = dec_f = None

        if source == "Simbad" and name:
            encoded_name = quote(name)
            webbrowser.open(
                f"https://simbad.cds.unistra.fr/simbad/sim-basic?Ident={encoded_name}&submit=SIMBAD+search"
            )
        elif source == "GaiaLocal" and ra_f is not None:
            # Simbad has no reverse index on Gaia DR3 ids — sim-id 404s for
            # the fainter sources that motivated the local augment. A 20"
            # cone at the object's coords always lands on something useful.
            webbrowser.open(
                "https://simbad.cds.unistra.fr/simbad/sim-coo?"
                f"Coord={ra_f:+.6f}{dec_f:+.6f}"
                "&CooFrame=ICRS&CooEpoch=2000&CooEqui=2000"
                "&Radius=20&Radius.unit=arcsec"
                "&submit=submit+query"
            )
        elif source == "Vizier" and ra_f is not None:
            radius = 5 / 60
            dec_sign = "%2B" if dec_f >= 0 else "-"
            webbrowser.open(
                f"http://ned.ipac.caltech.edu/conesearch?search_type=Near%20Position%20Search"
                f"&ra={ra_f:.6f}d&dec={dec_sign}{abs(dec_f):.6f}d&radius={radius:.3f}"
                "&in_csys=Equatorial&in_equinox=J2000.0"
            )
        elif source == "Mast" and ra_f is not None:
            webbrowser.open(
                f"https://mast.stsci.edu/portal/Mashup/Clients/Mast/Portal.html?"
                f"searchQuery={ra_f}%2C{dec_f}%2Cradius%3D0.0006"
            )

    def _copy_object_radec(self, obj):
        ra  = obj.get("ra")
        dec = obj.get("dec")
        try:
            text = f"{float(ra):.6f}, {float(dec):.6f}"
        except (TypeError, ValueError):
            text = f"{ra}, {dec}"
        QApplication.clipboard().setText(text)
        self.parent.status_label.setText(f"Copied RA/Dec: {text}")

    def _delete_object(self, obj):
        item = self._tree_item_for_object(obj)
        if item is not None:
            self.parent.results_tree.setCurrentItem(item)
            item.setSelected(True)
        self.delete_selected_objects()

    def draw_measurement_line_and_label(self, distance_ddmmss):
        """Draw the measurement line and label with the celestial distance."""
        # Draw line
        line_item = QGraphicsLineItem(
            QLineF(self.measurement_start, self.measurement_end)
        )
        line_item.setPen(QPen(QColor(0, 255, 255), 2))  # Cyan color for measurement
        self.parent.main_scene.addItem(line_item)

        # Place distance text at the midpoint of the line
        midpoint = QPointF(
            (self.measurement_start.x() + self.measurement_end.x()) / 2,
            (self.measurement_start.y() + self.measurement_end.y()) / 2
        )
        text_item = QGraphicsTextItem(distance_ddmmss)
        text_item.setDefaultTextColor(QColor(0, 255, 255))  # Same color as line
        text_item.setPos(midpoint)
        self.parent.main_scene.addItem(text_item)
        
        # Append both line and text to annotation_items
        line = QLineF(self.measurement_start, self.measurement_end)
        self.annotation_items.append(('line', line, QColor(0, 255, 255)))
        self.annotation_items.append(('text', distance_ddmmss, midpoint, QColor(0, 255, 255)))



    
    def wheelEvent(self, event):
        """Handle zoom in and out with the mouse wheel."""
        if event.angleDelta().y() > 0:
            self.parent.zoom_in()
        else:
            self.parent.zoom_out()        

    def update_circle(self):
        """Draws the search circle on the main scene if circle_center and circle_radius are set."""
        if self.parent.main_image and self.circle_center is not None and self.circle_radius > 0:
            # Clear the main scene and add the main image back
            self.parent.main_scene.clear()
            self.parent._marker_layer = None  # <--- add this line
            self.parent.main_scene.addPixmap(self.parent.main_image)

            # Redraw all shapes and annotations from stored properties
            for item in self.annotation_items:
                if item[0] == 'ellipse':
                    rect = item[1]
                    color = item[2]
                    ellipse = QGraphicsEllipseItem(rect)
                    ellipse.setPen(QPen(color, 2))
                    self.parent.main_scene.addItem(ellipse)
                elif item[0] == 'rect':
                    rect = item[1]
                    color = item[2]
                    rect_item = QGraphicsRectItem(rect)
                    rect_item.setPen(QPen(color, 2))
                    self.parent.main_scene.addItem(rect_item)
                elif item[0] == 'line':
                    line = item[1]

                    # accept either QLineF or QGraphicsLineItem
                    if isinstance(line, QGraphicsLineItem):
                        line = line.line()

                    color = item[2] if len(item) > 2 else QColor(0, 255, 0)

                    line_item = QGraphicsLineItem(line)
                    line_item.setPen(QPen(color, 2))
                    self.parent.main_scene.addItem(line_item)

                elif item[0] == 'text':
                    # support BOTH tuple shapes:
                    #   ('text', text, pos, color)
                    #   ('text', pos, text, color)
                    a1, a2 = item[1], item[2]
                    if isinstance(a1, QPointF) and isinstance(a2, str):
                        pos, text = a1, a2
                    else:
                        text, pos = a1, a2

                    color = item[3] if len(item) > 3 else QColor(255, 255, 255)

                    text_item = QGraphicsTextItem(text)
                    text_item.setPos(pos)
                    text_item.setDefaultTextColor(color)
                    text_item.setFont(self.parent.selected_font)
                    self.parent.main_scene.addItem(text_item)

                elif item[0] == 'freehand':  # Redraw Freehand
                    path = item[1]
                    color = item[2]
                    freehand_item = QGraphicsPathItem(path)
                    freehand_item.setPen(QPen(color, 2))
                    self.parent.main_scene.addItem(freehand_item)        

                elif item[0] == 'compass':
                    compass = item[1]
                    # North Line
                    north_line_coords = compass['north_line']
                    north_line_item = QGraphicsLineItem(
                        north_line_coords[0], north_line_coords[1], north_line_coords[2], north_line_coords[3]
                    )
                    north_line_item.setPen(QPen(Qt.GlobalColor.red, 2))
                    self.parent.main_scene.addItem(north_line_item)
                    
                    # East Line
                    east_line_coords = compass['east_line']
                    east_line_item = QGraphicsLineItem(
                        east_line_coords[0], east_line_coords[1], east_line_coords[2], east_line_coords[3]
                    )
                    east_line_item.setPen(QPen(Qt.GlobalColor.blue, 2))
                    self.parent.main_scene.addItem(east_line_item)
                    
                    # North Label
                    text_north = QGraphicsTextItem(compass['north_label'][2])
                    text_north.setPos(compass['north_label'][0], compass['north_label'][1])
                    text_north.setDefaultTextColor(Qt.GlobalColor.red)
                    self.parent.main_scene.addItem(text_north)
                    
                    # East Label
                    text_east = QGraphicsTextItem(compass['east_label'][2])
                    text_east.setPos(compass['east_label'][0], compass['east_label'][1])
                    text_east.setDefaultTextColor(Qt.GlobalColor.blue)
                    self.parent.main_scene.addItem(text_east)

                elif item[0] == 'measurement':  # Redraw celestial measurement line
                    line = item[1]
                    color = item[2]
                    text_position = item[3]
                    distance_text = item[4]
                    
                    # Draw the measurement line
                    measurement_line_item = QGraphicsLineItem(line)
                    measurement_line_item.setPen(QPen(color, 2, Qt.PenStyle.DashLine))  # Dashed line for measurement
                    self.parent.main_scene.addItem(measurement_line_item)
                    
                    # Draw the distance text label
                    text_item = QGraphicsTextItem(distance_text)
                    text_item.setPos(text_position)
                    text_item.setDefaultTextColor(color)
                    text_item.setFont(self.parent.selected_font)
                    self.parent.main_scene.addItem(text_item)                                
                        
            
            # Draw the search circle
            # >>> Recreate + repopulate the marker layer so query results persist
            self.parent._ensure_marker_layer()            # <--- add this line
            self.parent._set_marker_points_from_results() # <--- add this line

            # Draw the search circle
            pen_circle = QPen(QColor(255, 0, 0), 2)
            pen_circle.setCosmetic(True)                  # stays same width while zooming (optional)
            circle = self.parent.main_scene.addEllipse(
                int(self.circle_center.x() - self.circle_radius),
                int(self.circle_center.y() - self.circle_radius),
                int(self.circle_radius * 2),
                int(self.circle_radius * 2),
                pen_circle
            )
            circle.setZValue(10_000)                      # keep circle above markers/pixmap (optional)

            self.update_mini_preview()
        else:
            # If circle is disabled, restore base layers and markers too
            self.parent.main_scene.clear()
            self.parent._marker_layer = None              # <--- add this line
            self.parent.main_scene.addPixmap(self.parent.main_image)
            self.parent._ensure_marker_layer()            # <--- add this line
            self.parent._set_marker_points_from_results() # <--- add this line

    def delete_selected_object(self):
        if self.selected_object is None:
            self.parent.status_label.setText("No object selected to delete.")
            return

        # Remove the selected object from the results list
        self.parent.results = [obj for obj in self.parent.results if obj != self.selected_object]

        # Remove the corresponding row from the TreeBox
        for i in range(self.parent.results_tree.topLevelItemCount()):
            item = self.parent.results_tree.topLevelItem(i)
            if item.text(2) == self.selected_object["name"]:  # Match the name in the third column
                self.parent.results_tree.takeTopLevelItem(i)
                break

        # Clear the selection
        self.selected_object = None
        self.parent.results_tree.clearSelection()

        # Redraw the main and mini previews without the deleted marker
        self.draw_query_results()
        self.update_mini_preview()

        # Update the status label
        self.parent.status_label.setText("Selected object and marker removed.")

    def delete_selected_objects(self):
        items = self.parent.results_tree.selectedItems()
        if not items:
            self.parent.status_label.setText("No objects selected to delete.")
            return

        # Collect names from the selected rows (column 2 is "Name")
        names_to_delete = {it.text(2) for it in items if it.text(2)}

        # Remove from results
        before = len(self.parent.results)
        self.parent.results = [obj for obj in self.parent.results if obj.get("name") not in names_to_delete]
        after = len(self.parent.results)

        # Remove the rows from the tree (handle both top-level and children just in case)
        for it in items:
            parent = it.parent()
            if parent is None:
                idx = self.parent.results_tree.indexOfTopLevelItem(it)
                if idx != -1:
                    self.parent.results_tree.takeTopLevelItem(idx)
            else:
                parent.removeChild(it)

        # Clear selection & selected highlight
        self.selected_object = None
        if hasattr(self.parent, "_set_selected_name"):
            self.parent._set_selected_name(None)

        # Update marker layer + mini preview (no scene clears, so we don’t delete the layer)
        self.parent._ensure_marker_layer()
        self.parent._set_marker_points_from_results()
        if self.parent._marker_layer:
            self.parent._marker_layer.update()
        self.update_mini_preview()

        # Update counters / status
        self.parent.object_count_label.setText(f"Objects Found: {after}")
        removed = before - after
        self.parent.status_label.setText(f"Removed {removed} object(s).")


    def scrollContentsBy(self, dx, dy):
        super().scrollContentsBy(dx, dy)
        # Debounced — timer lives on the WIMIDialog parent
        try:
            self.parent._green_box_timer.start()
        except Exception:
            self.parent.update_green_box()

    def update_mini_preview(self):
        """Delegate to the parent's scene-render based mini preview."""
        try:
            QTimer.singleShot(0, self.parent.update_green_box)
        except Exception:
            pass

    def place_celestial_compass(self, center):
        compass_radius = 50

        # Determine parity from WCS CD matrix determinant
        parity = 1.0
        try:
            hdr = self.parent.header
            cd11 = float(hdr.get("CD1_1", 0))
            cd12 = float(hdr.get("CD1_2", 0))
            cd21 = float(hdr.get("CD2_1", 0))
            cd22 = float(hdr.get("CD2_2", 0))
            det = cd11 * cd22 - cd12 * cd21
            if det > 0:
                parity = -1.0
        except Exception:
            pass

        orientation_radians = math.radians(self.parent.orientation)

        north_dx =  parity * math.sin(orientation_radians) * compass_radius
        north_dy = -math.cos(orientation_radians) * compass_radius
        east_dx  = -parity * math.cos(orientation_radians) * compass_radius
        east_dy  = -math.sin(orientation_radians) * compass_radius

        # ── WCS sanity check: verify arrows point the right way ──────────
        wcs = getattr(self.parent, "wcs", None)
        if wcs is not None:
            try:
                cx, cy = center.x(), center.y()
                probe = 3  # pixels

                # North check: moving north_dx/north_dy should increase Dec
                ra0,  dec0  = self.parent.calculate_ra_dec_from_pixel(cx, cy)
                ra_n, dec_n = self.parent.calculate_ra_dec_from_pixel(
                    cx + north_dx / compass_radius * probe,
                    cy + north_dy / compass_radius * probe
                )
                if dec_n is not None and dec0 is not None and (dec_n - dec0) < 0:
                    # North arrow is pointing South — flip it
                    north_dx, north_dy = -north_dx, -north_dy
                    print("[Compass] North flipped by WCS sanity check")

                # East check: moving east_dx/east_dy should decrease RA
                # (RA increases westward, so East = decreasing RA)
                ra_e, dec_e = self.parent.calculate_ra_dec_from_pixel(
                    cx + east_dx / compass_radius * probe,
                    cy + east_dy / compass_radius * probe
                )
                if ra_e is not None and ra0 is not None:
                    dra = ra_e - ra0
                    if dra > 180:
                        dra -= 360
                    elif dra < -180:
                        dra += 360
                    # East = direction of INCREASING RA in the sky
                    # If probing our East arrow gives DECREASING RA, the arrow is wrong
                    if dra < 0:
                        east_dx, east_dy = -east_dx, -east_dy
                        print("[Compass] East flipped by WCS sanity check")

            except Exception as e:
                print(f"[Compass] WCS sanity check failed: {e}")

        # Draw North line
        north_line = QGraphicsLineItem(
            center.x(), center.y(),
            center.x() + north_dx, center.y() + north_dy
        )
        north_line.setPen(QPen(Qt.GlobalColor.red, 2))
        self.parent.main_scene.addItem(north_line)

        # Draw East line
        east_line = QGraphicsLineItem(
            center.x(), center.y(),
            center.x() + east_dx, center.y() + east_dy
        )
        east_line.setPen(QPen(Qt.GlobalColor.blue, 2))
        self.parent.main_scene.addItem(east_line)

        text_north = QGraphicsTextItem("N")
        text_north.setDefaultTextColor(Qt.GlobalColor.red)
        text_north.setPos(center.x() + north_dx - 10, center.y() + north_dy - 10)
        self.parent.main_scene.addItem(text_north)

        text_east = QGraphicsTextItem("E")
        text_east.setDefaultTextColor(Qt.GlobalColor.blue)
        text_east.setPos(center.x() + east_dx - 15, center.y() + east_dy - 10)
        self.parent.main_scene.addItem(text_east)

        self.annotation_items.append((
            "compass", {
                "center": center,
                "north_line": (center.x(), center.y(), center.x() + north_dx, center.y() + north_dy),
                "east_line":  (center.x(), center.y(), center.x() + east_dx,  center.y() + east_dy),
                "north_label": (center.x() + north_dx - 10, center.y() + north_dy - 10, "N"),
                "east_label":  (center.x() + east_dx  - 15, center.y() + east_dy  - 10, "E"),
                "orientation": self.parent.orientation
            }
        ))

    def zoom_to_coordinates(self, ra, dec):
        """Zoom to the specified RA/Dec coordinates and center the view on that position."""
        # Calculate the pixel position from RA and Dec
        pixel_x, pixel_y = self.parent.calculate_pixel_from_ra_dec(ra, dec)
        
        if pixel_x is not None and pixel_y is not None:
            # Reset the zoom to 1:1 FIRST, then center -- centering depends on the
            # current transform, so it must happen after the transform is set.
            self.resetTransform()
            self.scale(1.0, 1.0)
            self.parent.zoom_level = 1.0

            # Re-pad the scene for the new zoom so the target can be centered even
            # when it sits near (or past) the image edge.
            self.parent._update_scene_margins()

            self.centerOn(pixel_x, pixel_y)

            # Optionally, update the mini preview to reflect the new zoom and center
            self.update_mini_preview()

    def draw_query_results(self):
        """Draw query results with or without names based on the show_names setting."""
        if self.parent.main_image:
            # Clear the main scene and re-add the main image
            self.parent.main_scene.clear()
            self.parent.main_scene.addPixmap(self.parent.main_image)

            self.parent._marker_layer = None
            self.parent._ensure_marker_layer()
            self.parent._set_marker_points_from_results()

            # Redraw all shapes and annotations from stored properties
            for item in self.annotation_items:
                if item[0] == 'ellipse':
                    rect = item[1]
                    color = item[2]
                    ellipse = QGraphicsEllipseItem(rect)
                    ellipse.setPen(QPen(color, 2))
                    self.parent.main_scene.addItem(ellipse)
                elif item[0] == 'rect':
                    rect = item[1]
                    color = item[2]
                    rect_item = QGraphicsRectItem(rect)
                    rect_item.setPen(QPen(color, 2))
                    self.parent.main_scene.addItem(rect_item)
                elif item[0] == 'line':
                    line = item[1]
                    color = item[2]
                    line_item = QGraphicsLineItem(line)
                    line_item.setPen(QPen(color, 2))
                    self.parent.main_scene.addItem(line_item)
                elif item[0] == 'text':
                    text = item[1]            # The text string
                    pos = item[2]             # A QPointF for the position
                    color = item[3]           # The color for the text

                    text_item = QGraphicsTextItem(text)
                    text_item.setPos(pos)
                    text_item.setDefaultTextColor(color)
                    text_item.setFont(self.parent.selected_font)
                    self.parent.main_scene.addItem(text_item)

                elif item[0] == 'freehand':  # Redraw Freehand
                    path = item[1]
                    color = item[2]
                    freehand_item = QGraphicsPathItem(path)
                    freehand_item.setPen(QPen(color, 2))
                    self.parent.main_scene.addItem(freehand_item)                      
                elif item[0] == 'measurement':  # Redraw celestial measurement line
                    line = item[1]
                    color = item[2]
                    text_position = item[3]
                    distance_text = item[4]
                    
                    # Draw the measurement line
                    measurement_line_item = QGraphicsLineItem(line)
                    measurement_line_item.setPen(QPen(color, 2, Qt.PenStyle.DashLine))  # Dashed line for measurement
                    self.parent.main_scene.addItem(measurement_line_item)
                    
                    # Draw the distance text label
                    text_item = QGraphicsTextItem(distance_text)
                    text_item.setPos(text_position)
                    text_item.setDefaultTextColor(color)
                    text_item.setFont(self.parent.selected_font)
                    self.parent.main_scene.addItem(text_item)        
                elif item[0] == 'compass':
                    compass = item[1]
                    # North Line
                    north_line_coords = compass['north_line']
                    north_line_item = QGraphicsLineItem(
                        north_line_coords[0], north_line_coords[1], north_line_coords[2], north_line_coords[3]
                    )
                    north_line_item.setPen(QPen(Qt.GlobalColor.red, 2))
                    self.parent.main_scene.addItem(north_line_item)
                    
                    # East Line
                    east_line_coords = compass['east_line']
                    east_line_item = QGraphicsLineItem(
                        east_line_coords[0], east_line_coords[1], east_line_coords[2], east_line_coords[3]
                    )
                    east_line_item.setPen(QPen(Qt.GlobalColor.blue, 2))
                    self.parent.main_scene.addItem(east_line_item)
                    
                    # North Label
                    text_north = QGraphicsTextItem(compass['north_label'][2])
                    text_north.setPos(compass['north_label'][0], compass['north_label'][1])
                    text_north.setDefaultTextColor(Qt.GlobalColor.red)
                    self.parent.main_scene.addItem(text_north)
                    
                    # East Label
                    text_east = QGraphicsTextItem(compass['east_label'][2])
                    text_east.setPos(compass['east_label'][0], compass['east_label'][1])
                    text_east.setDefaultTextColor(Qt.GlobalColor.blue)
                    self.parent.main_scene.addItem(text_east)                               
            # Ensure the search circle is drawn if circle data is available
            #if self.circle_center is not None and self.circle_radius > 0:
            #    self.update_circle()

            # Draw object markers (circle or crosshair)
            for obj in self.parent.results:
                ra, dec, name = obj["ra"], obj["dec"], obj["name"]
                x, y = self.parent.calculate_pixel_from_ra_dec(ra, dec)
                if x is not None and y is not None:
                    # Determine color: green if selected, red otherwise
                    base_color = obj["color"]
                    pen_color  = QColor(0,255,0) if obj is self.selected_object else base_color
                    pen = QPen(pen_color, 2)

                    if self.parent.marker_style == "Circle":
                        # Draw a circle around the object
                        self.parent.main_scene.addEllipse(int(x - 5), int(y - 5), 10, 10, pen)
                    elif self.parent.marker_style == "Crosshair":
                        # Draw crosshair with a 5-pixel gap in the middle
                        crosshair_size = 10
                        gap = 5
                        line1 = QLineF(x - crosshair_size, y, x - gap, y)
                        line2 = QLineF(x + gap, y, x + crosshair_size, y)
                        line3 = QLineF(x, y - crosshair_size, x, y - gap)
                        line4 = QLineF(x, y + gap, x, y + crosshair_size)
                        for line in [line1, line2, line3, line4]:
                            crosshair_item = QGraphicsLineItem(line)
                            crosshair_item.setPen(pen)
                            self.parent.main_scene.addItem(crosshair_item)
                    if self.parent.show_names:
                        #print(f"Drawing name: {name} at ({x}, {y})")  # Debugging statement
                        text_color = obj.get("color", QColor(Qt.GlobalColor.white))
                        text_item = QGraphicsTextItem(name)
                        text_item.setPos(x + 10, y + 10)  # Offset to avoid overlapping the marker
                        text_item.setDefaultTextColor(text_color)
                        text_item.setFont(self.parent.selected_font)
                        self.parent.main_scene.addItem(text_item)                            
    

    def clear_query_results(self):
        """Clear query markers from the main image without removing annotations."""
        # Clear the main scene and add the main image back
        self.parent.main_scene.clear()
        if self.parent.main_image:
            self.parent.main_scene.addPixmap(self.parent.main_image)

        self.parent._marker_layer = None
        self.parent._ensure_marker_layer()
        self.parent._set_marker_points_from_results()

        # Redraw the stored annotation items
        for item in self.annotation_items:
            if item[0] == 'ellipse':
                rect = item[1]
                color = item[2]
                ellipse = QGraphicsEllipseItem(rect)
                ellipse.setPen(QPen(color, 2))
                self.parent.main_scene.addItem(ellipse)
            elif item[0] == 'rect':
                rect = item[1]
                color = item[2]
                rect_item = QGraphicsRectItem(rect)
                rect_item.setPen(QPen(color, 2))
                self.parent.main_scene.addItem(rect_item)
            elif item[0] == 'line':
                line = item[1]
                color = item[2]
                line_item = QGraphicsLineItem(line)
                line_item.setPen(QPen(color, 2))
                self.parent.main_scene.addItem(line_item)
            elif item[0] == 'text':
                text = item[1]            # The text string
                pos = item[2]             # A QPointF for the position
                color = item[3]           # The color for the text

                text_item = QGraphicsTextItem(text)
                text_item.setPos(pos)
                text_item.setDefaultTextColor(color)
                text_item.setFont(self.parent.selected_font)
                self.parent.main_scene.addItem(text_item)

            elif item[0] == 'freehand':  # Redraw Freehand
                path = item[1]
                color = item[2]
                freehand_item = QGraphicsPathItem(path)
                freehand_item.setPen(QPen(color, 2))
                self.parent.main_scene.addItem(freehand_item)  
            elif item[0] == 'measurement':  # Redraw celestial measurement line
                line = item[1]
                color = item[2]
                text_position = item[3]
                distance_text = item[4]
                
                # Draw the measurement line
                measurement_line_item = QGraphicsLineItem(line)
                measurement_line_item.setPen(QPen(color, 2, Qt.PenStyle.DashLine))  # Dashed line for measurement
                self.parent.main_scene.addItem(measurement_line_item)
                
                # Draw the distance text label
                text_item = QGraphicsTextItem(distance_text)
                text_item.setPos(text_position)
                text_item.setDefaultTextColor(color)
                text_item.setFont(self.parent.selected_font)
                self.parent.main_scene.addItem(text_item)       
            elif item[0] == 'compass':
                compass = item[1]
                # North line
                north_line_item = QGraphicsLineItem(
                    compass['north_line'][0], compass['north_line'][1],
                    compass['north_line'][2], compass['north_line'][3]
                )
                north_line_item.setPen(QPen(Qt.GlobalColor.red, 2))
                self.parent.main_scene.addItem(north_line_item)
                # East line
                east_line_item = QGraphicsLineItem(
                    compass['east_line'][0], compass['east_line'][1],
                    compass['east_line'][2], compass['east_line'][3]
                )
                east_line_item.setPen(QPen(Qt.GlobalColor.blue, 2))
                self.parent.main_scene.addItem(east_line_item)
                # North label
                text_north = QGraphicsTextItem(compass['north_label'][2])
                text_north.setPos(compass['north_label'][0], compass['north_label'][1])
                text_north.setDefaultTextColor(Qt.GlobalColor.red)
                self.parent.main_scene.addItem(text_north)
                # East label
                text_east = QGraphicsTextItem(compass['east_label'][2])
                text_east.setPos(compass['east_label'][0], compass['east_label'][1])
                text_east.setDefaultTextColor(Qt.GlobalColor.blue)
                self.parent.main_scene.addItem(text_east)
        
        # Update the circle data, if any
        self.parent.update_circle_data()
                        

    def set_query_results(self, results):
        """Store results, assign each object a category & color, then redraw."""
        self.parent.results = results

        for obj in self.parent.results:
            # use the same key you populated in MainWindow.query_simbad
            short_type = obj.get("short_type", "")
            category   = OTYPE_TO_CATEGORY.get(short_type, "Errors & Artefacts")
            obj["category"] = category

            # lookup the QColor for that category (fallback to white)
            obj["color"]    = CATEGORY_TO_COLOR.get(category, QColor(255,255,255))

        self.draw_query_results()

    def get_object_at_position(self, pos):
        """Find the object at the given position in the main preview."""
        for obj in self.parent.results:
            ra, dec = obj["ra"], obj["dec"]
            x, y = self.parent.calculate_pixel_from_ra_dec(ra, dec)
            if x is not None and y is not None:
                if abs(pos.x() - x) <= 5 and abs(pos.y() - y) <= 5:
                    return obj
        return None


    def select_object(self, selected_obj):
        self.selected_object = selected_obj
        sel_name = selected_obj["name"] if selected_obj else None
        self.parent._set_selected_name(sel_name)

        for i in range(self.parent.results_tree.topLevelItemCount()):
            item = self.parent.results_tree.topLevelItem(i)
            if item.text(2) == (selected_obj.get("name") if selected_obj else None):
                self.parent.results_tree.setCurrentItem(item)
                break

    def undo_annotation(self):
        """Remove the last annotation item from the scene and annotation_items list."""
        if self.annotation_items:
            # Remove the last item from annotation_items
            self.annotation_items.pop()

            # Clear the scene and redraw all annotations except the last one
            self.parent.main_scene.clear()
            if self.parent.main_image:
                self.parent.main_scene.addPixmap(self.parent.main_image)

            # NEW:
            self.parent._marker_layer = None
            self.parent._ensure_marker_layer()
            self.parent._set_marker_points_from_results()

            # Redraw remaining annotations
            self.redraw_annotations()

            # Optionally, update the mini preview to reflect changes
            self.update_mini_preview()

    def clear_annotations(self):
        """Clear all annotation items from the scene and annotation_items list."""
        # Clear all items in annotation_items and update the scene
        self.annotation_items.clear()
        self.parent.main_scene.clear()

        self.parent._marker_layer = None
        self.parent._ensure_marker_layer()
        self.parent._set_marker_points_from_results()

        # Redraw only the main image
        if self.parent.main_image:
            self.parent.main_scene.addPixmap(self.parent.main_image)

        # Optionally, update the mini preview to reflect changes
        self.update_mini_preview()

    def redraw_annotations(self):
        """Helper function to redraw all annotations from annotation_items."""
        for item in self.annotation_items:
            if item[0] == 'ellipse':
                rect = item[1]
                color = item[2]
                ellipse = QGraphicsEllipseItem(rect)
                ellipse.setPen(QPen(color, 2))
                self.parent.main_scene.addItem(ellipse)
            elif item[0] == 'rect':
                rect = item[1]
                color = item[2]
                rect_item = QGraphicsRectItem(rect)
                rect_item.setPen(QPen(color, 2))
                self.parent.main_scene.addItem(rect_item)
            elif item[0] == 'line':
                line = item[1]
                # Safely get color or default to green if missing
                color = item[2] if len(item) > 2 else QColor(0, 255, 0)
                line_item = QGraphicsLineItem(line)
                line_item.setPen(QPen(color, 2))
                self.parent.main_scene.addItem(line_item)
            elif item[0] == 'text':
                text = item[1]            # The text string
                pos = item[2]             # A QPointF for the position
                color = item[3]           # The color for the text

                text_item = QGraphicsTextItem(text)
                text_item.setPos(pos)
                text_item.setDefaultTextColor(color)
                text_item.setFont(self.parent.selected_font)
                self.parent.main_scene.addItem(text_item)

            elif item[0] == 'freehand':  # Redraw Freehand
                path = item[1]
                color = item[2]
                freehand_item = QGraphicsPathItem(path)
                freehand_item.setPen(QPen(color, 2))
                self.parent.main_scene.addItem(freehand_item) 
            elif item[0] == 'measurement':  # Redraw celestial measurement line
                line = item[1]
                color = item[2]
                text_position = item[3]
                distance_text = item[4]
                
                # Draw the measurement line
                measurement_line_item = QGraphicsLineItem(line)
                measurement_line_item.setPen(QPen(color, 2, Qt.PenStyle.DashLine))  # Dashed line for measurement
                self.parent.main_scene.addItem(measurement_line_item)
                
                # Draw the distance text label
                text_item = QGraphicsTextItem(distance_text)
                text_item.setPos(text_position)
                text_item.setDefaultTextColor(color)
                text_item.setFont(self.parent.selected_font)
                self.parent.main_scene.addItem(text_item)                                        
            elif item[0] == 'compass':
                compass = item[1]
                # Redraw north line
                north_line_item = QGraphicsLineItem(
                    compass['north_line'][0], compass['north_line'][1],
                    compass['north_line'][2], compass['north_line'][3]
                )
                north_line_item.setPen(QPen(Qt.GlobalColor.red, 2))
                self.parent.main_scene.addItem(north_line_item)
                
                # Redraw east line
                east_line_item = QGraphicsLineItem(
                    compass['east_line'][0], compass['east_line'][1],
                    compass['east_line'][2], compass['east_line'][3]
                )
                east_line_item.setPen(QPen(Qt.GlobalColor.blue, 2))
                self.parent.main_scene.addItem(east_line_item)
                
                # Redraw labels
                text_north = QGraphicsTextItem(compass['north_label'][2])
                text_north.setPos(compass['north_label'][0], compass['north_label'][1])
                text_north.setDefaultTextColor(Qt.GlobalColor.red)
                self.parent.main_scene.addItem(text_north)
                
                text_east = QGraphicsTextItem(compass['east_label'][2])
                text_east.setPos(compass['east_label'][0], compass['east_label'][1])
                text_east.setDefaultTextColor(Qt.GlobalColor.blue)
                self.parent.main_scene.addItem(text_east)        

class ThreeDSettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("3D Model Settings")
        layout = QVBoxLayout(self)

        # Image Plane Style
        layout.addWidget(QLabel("Image Plane Style:"))
        self.plane_style_cb = QComboBox()
        self.plane_style_cb.addItems([
            "Mesh RGB Scatter Plane",
            "Smooth Grayscale Image Plane"
        ])
        layout.addWidget(self.plane_style_cb)

        # Resolution
        res_layout = QHBoxLayout()
        res_layout.addWidget(QLabel("Resolution:"))
        self.res_spin = QSpinBox()
        self.res_spin.setRange(50, 2000)
        self.res_spin.setSingleStep(50)
        self.res_spin.setValue(500)
        res_layout.addWidget(self.res_spin)
        layout.addLayout(res_layout)

        # Z-Axis Range Options (Min-Max/Custom as before)
        layout.addWidget(QLabel("Z-Axis Range:"))
        self.zaxis_cb = QComboBox()
        self.zaxis_cb.addItems(["Default", "Min-Max", "Custom"])
        layout.addWidget(self.zaxis_cb)

        self.custom_widget = QWidget()
        cl = QHBoxLayout(self.custom_widget)
        cl.addWidget(QLabel("Min:"))
        self.zmin_spin = QDoubleSpinBox()
        self.zmin_spin.setRange(-1e6, 1e6)
        self.zmin_spin.setValue(0.0)
        cl.addWidget(self.zmin_spin)
        cl.addWidget(QLabel("Max:"))
        self.zmax_spin = QDoubleSpinBox()
        self.zmax_spin.setRange(-1e6, 1e6)
        self.zmax_spin.setValue(10.0)
        cl.addWidget(self.zmax_spin)
        layout.addWidget(self.custom_widget)
        self.custom_widget.setVisible(False)
        self.zaxis_cb.currentIndexChanged.connect(
            lambda idx: self.custom_widget.setVisible(self.zaxis_cb.currentText() == "Custom")
        )

        # Z-Axis Scale: Log vs Linear
        layout.addWidget(QLabel("Z-Axis Scale:"))
        self.zscale_cb = QComboBox()
        self.zscale_cb.addItems(["Logarithmic", "Linear"])
        layout.addWidget(self.zscale_cb)

        # Linear max input
        self.linear_widget = QWidget()
        ll = QHBoxLayout(self.linear_widget)
        ll.addWidget(QLabel("Linear Z-Max:"))
        self.linear_max_spin = QDoubleSpinBox()
        self.linear_max_spin.setRange(0.1, 1e12)
        self.linear_max_spin.setValue(1e4)
        ll.addWidget(self.linear_max_spin)
        layout.addWidget(self.linear_widget)
        self.linear_widget.setVisible(False)
        self.zscale_cb.currentIndexChanged.connect(
            lambda idx: self.linear_widget.setVisible(self.zscale_cb.currentText() == "Linear")
        )

        self.reverse_cb = QCheckBox("Reverse Z-Axis")
        self.reverse_cb.setChecked(False)
        layout.addWidget(self.reverse_cb)

        # Object Color
        layout.addWidget(QLabel("Object Color:"))
        self.color_cb = QComboBox()
        self.color_cb.addItems(["Image-Based", "Legend Color", "Solid (Custom)"])
        layout.addWidget(self.color_cb)

        self.color_btn = QPushButton("Choose Color…")
        self.custom_color = QColor(255, 0, 0)
        self.color_btn.setVisible(False)
        layout.addWidget(self.color_btn)
        self.color_btn.clicked.connect(self._choose_color)
        self.color_cb.currentIndexChanged.connect(
            lambda idx: self.color_btn.setVisible(self.color_cb.currentText() == "Solid (Custom)")
        )

        # Z-Axis Height control
        layout.addWidget(QLabel("Z-Axis Height (aspect ratio z):"))
        self.zheight_spin = QDoubleSpinBox()
        self.zheight_spin.setRange(0.1, 10.0)
        self.zheight_spin.setSingleStep(0.1)
        self.zheight_spin.setValue(0.5)
        layout.addWidget(self.zheight_spin)

        # ─── Show Connector Lines ─────────────────────────────
        self.lines_cb = QCheckBox("Show Connector Lines")
        self.lines_cb.setChecked(True)
        layout.addWidget(self.lines_cb)

        # OK / Cancel
        btns = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _choose_color(self):
        col = QColorDialog.getColor(self.custom_color, self, "Select Object Color")
        if col.isValid():
            self.custom_color = col

    def getSettings(self):
        if self.exec() == QDialog.DialogCode.Accepted:
            return {
                "plane_style": self.plane_style_cb.currentText(),
                "resolution": self.res_spin.value(),
                "z_option":   self.zaxis_cb.currentText(),
                "z_min":      self.zmin_spin.value(),
                "z_max":      self.zmax_spin.value(),
                "z_scale":    self.zscale_cb.currentText(),
                "linear_max": self.linear_max_spin.value(),
                "object_color": self.color_cb.currentText(),
                "custom_color": self.custom_color,      # QColor
                "z_height":   self.zheight_spin.value(),
                "show_lines": self.lines_cb.isChecked(),
                "reverse_z":   self.reverse_cb.isChecked(),
            }
        return None


# ---------------------------------------------------------------------------
# Synthetic filter curves (Johnson B and V, on Angstrom grid 3000-11000 Å)
# These are the standard Bessell 1990 curves, tabulated coarsely.
# For the purpose of synthesizing B-V from Gaia XP the exact shape matters
# less than consistency — all stars go through the same curves.
# ---------------------------------------------------------------------------
 
_B_WL  = np.array([3600,3700,3800,3900,4000,4100,4200,4300,4400,4500,
                   4600,4700,4800,4900,5000,5100,5200,5300,5400,5500], dtype=np.float64)
_B_TP  = np.array([0.00,0.03,0.13,0.37,0.68,0.92,1.00,0.97,0.86,0.69,
                   0.49,0.32,0.18,0.08,0.02,0.00,0.00,0.00,0.00,0.00], dtype=np.float64)
 
_V_WL  = np.array([4700,4800,4900,5000,5100,5200,5300,5400,5500,5600,
                   5700,5800,5900,6000,6100,6200,6300,6400,6500,6600,6700,6800,6900,7000], dtype=np.float64)
_V_TP  = np.array([0.00,0.01,0.03,0.08,0.18,0.36,0.60,0.83,0.96,1.00,
                   0.99,0.93,0.83,0.71,0.58,0.44,0.32,0.21,0.12,0.06,0.02,0.01,0.00,0.00], dtype=np.float64)
 
_WL_GRID = np.arange(3000, 11001, dtype=np.float64)   # 1-Å grid
 
# Gaia DR3 BP and RP passbands — coarse but adequate nominal transmission
# curves (EDR3 revised passbands, sampled). Used only to synthesize a BP-RP
# color from an XP spectrum for the Curtis (2020) Teff relation; the exact
# shape matters far less than for absolute photometry because BP-RP is a
# broad color and the zero-point is fixed empirically below.
_BP_WL = np.array([3300,3500,3700,3900,4100,4300,4500,4700,4900,5100,
                   5300,5500,5700,5900,6100,6300,6500,6700], dtype=np.float64)
_BP_TP = np.array([0.00,0.12,0.38,0.60,0.73,0.80,0.83,0.84,0.83,0.80,
                   0.74,0.65,0.53,0.39,0.25,0.13,0.04,0.00], dtype=np.float64)

_RP_WL = np.array([6200,6400,6600,6800,7000,7300,7600,7900,8200,8500,
                   8800,9100,9400,9700,10000,10300,10500], dtype=np.float64)
_RP_TP = np.array([0.00,0.15,0.42,0.66,0.82,0.93,0.98,1.00,0.98,0.93,
                   0.85,0.74,0.60,0.44,0.28,0.13,0.00], dtype=np.float64)


def _synth_bp_rp_from_xp(flux_arr, wl_nm):
    """
    Synthesize a Gaia (BP - RP) color from an XP spectrum, in magnitudes.
    Ratio of passband integrals — the multiplicative zero-point cancels, and
    a fixed empirical offset anchors the color to the Gaia scale.
    Returns BP-RP (float) or None on failure.
    """
    try:
        wl_ang = np.asarray(wl_nm, dtype=np.float64) * 10.0
        flux   = np.asarray(flux_arr, dtype=np.float64)
        if wl_ang[0] > wl_ang[-1]:
            wl_ang = wl_ang[::-1]
            flux   = flux[::-1]

        flux_grid = np.interp(_WL_GRID, wl_ang, flux, left=0.0, right=0.0)
        flux_grid = np.where(flux_grid > 0, flux_grid, 0.0)

        bp_tp = np.interp(_WL_GRID, _BP_WL, _BP_TP, left=0.0, right=0.0)
        rp_tp = np.interp(_WL_GRID, _RP_WL, _RP_TP, left=0.0, right=0.0)

        f_BP = float(np.trapz(flux_grid * bp_tp, _WL_GRID))
        f_RP = float(np.trapz(flux_grid * rp_tp, _WL_GRID))
        if f_BP <= 0 or f_RP <= 0:
            return None

        # Zero-point so a Vega-like spectrum lands near BP-RP ≈ 0.03.
        # Colors are what feed Curtis 2020; a small constant offset keeps the
        # synthesized color on the Gaia scale. Calibrate ZP_BPRP against a few
        # known stars in your data if you want to tighten it.
        ZP_BPRP = 0.05
        bp_rp = -2.5 * math.log10(f_BP / f_RP) + ZP_BPRP
        return float(bp_rp)
    except Exception:
        return None

def _synth_bv_from_xp(flux_arr, wl_nm):
    """
    Compute synthetic B-V color index from XP spectrum.
    Uses the ratio of filter integrals — zero-point cancels out.
    Returns B-V (float) or None on failure.
    """
    try:
        wl_ang = np.asarray(wl_nm, dtype=np.float64) * 10.0
        flux   = np.asarray(flux_arr, dtype=np.float64)
        if wl_ang[0] > wl_ang[-1]:
            wl_ang = wl_ang[::-1]
            flux   = flux[::-1]

        flux_grid = np.interp(_WL_GRID, wl_ang, flux, left=0.0, right=0.0)
        flux_grid = np.where(flux_grid > 0, flux_grid, 0.0)

        b_tp = np.interp(_WL_GRID, _B_WL, _B_TP, left=0.0, right=0.0)
        v_tp = np.interp(_WL_GRID, _V_WL, _V_TP, left=0.0, right=0.0)

        f_B = float(np.trapz(flux_grid * b_tp, _WL_GRID))
        f_V = float(np.trapz(flux_grid * v_tp, _WL_GRID))

        if f_B <= 0 or f_V <= 0:
            return None

        # B-V = -2.5 * log10(f_B / f_V) + ZP_BV
        # Vega zero-point offset for Johnson B-V: +0.09 mag
        # (Vega has B-V = -0.001 by definition but the Bessell curves
        #  give a small offset vs a flat spectrum)
        ZP_BV = 0.09
        bv = -2.5 * math.log10(f_B / f_V) + ZP_BV
        return float(bv)
    except Exception:
        return None 
 
def _synth_mag_from_xp(flux_arr, wl_nm, filter_wl_ang, filter_tp,
                        vega_flux_density=3.63e-9):
    """
    Synthesize an AB/Vega-ish magnitude from an XP flux array.
 
    flux_arr  : flux in W/nm/m² (Gaia XP units), sampled at wl_nm (nm)
    wl_nm     : wavelength array in nm (Gaia XP output)
    filter_wl_ang : filter transmission wavelengths in Angstrom
    filter_tp : filter transmission (0–1)
 
    Returns magnitude (float) or NaN on failure.
    """
    try:
        # Convert XP wavelengths nm → Å and resample onto _WL_GRID
        wl_ang = np.asarray(wl_nm, dtype=np.float64) * 10.0
        flux   = np.asarray(flux_arr, dtype=np.float64)
        if wl_ang[0] > wl_ang[-1]:
            wl_ang = wl_ang[::-1]
            flux   = flux[::-1]
 
        flux_grid = np.interp(_WL_GRID, wl_ang, flux, left=0.0, right=0.0)
        flux_grid = np.where(flux_grid > 0, flux_grid, 0.0)
 
        # Interpolate filter onto same grid
        tp_grid = np.interp(_WL_GRID, filter_wl_ang, filter_tp, left=0.0, right=0.0)
 
        # Integrate  ∫ f(λ) T(λ) dλ  (trapezoidal)
        num = float(np.trapz(flux_grid * tp_grid, _WL_GRID))
        den = float(np.trapz(tp_grid, _WL_GRID))
 
        if den <= 0 or num <= 0:
            return float('nan')
 
        f_mean = num / den  # mean flux density in passband
 
        # Convert to magnitude using Vega reference (approximate, consistent)
        # vega_flux_density ≈ 3.63e-9 W/cm²/Å → needs unit matching
        # XP flux is in W/nm/m² = 1e-10 W/Å/cm²  (1 m² = 1e4 cm², 1 nm = 10 Å → /10)
        # So:  f [W/nm/m²]  →  f * 1e-4 / 10 [W/Å/cm²]  =  f * 1e-5  [W/Å/cm²]
        # Vega reference in same units: 3.63e-9 W/cm²/Å (B band reference is similar)
        # We just want consistent colours so the exact zero-point doesn't matter.
        mag = -2.5 * math.log10(f_mean)
        return mag
    except Exception:
        return float('nan')
 
 
def _blackbody_teff_from_xp(flux_arr, wl_nm):
    """
    Estimate Teff by least-squares fitting a Planck function to the XP continuum.
    Returns Teff in Kelvin, or None on failure.
    Grid-searches 2500–50000 K then refines.
    """
    try:
        from scipy.optimize import minimize_scalar
 
        wl_ang = np.asarray(wl_nm, dtype=np.float64) * 10.0
        flux   = np.asarray(flux_arr, dtype=np.float64)
        if wl_ang[0] > wl_ang[-1]:
            wl_ang = wl_ang[::-1]
            flux   = flux[::-1]
 
        # Only use optical range 4000–8000 Å for the fit (avoids XP edge noise)
        mask = (wl_ang >= 4000) & (wl_ang <= 8000)
        wl_f = wl_ang[mask]
        fl_f = flux[mask]
        if len(wl_f) < 10:
            return None
 
        fl_f = np.where(fl_f > 0, fl_f, 0.0)
        if fl_f.max() <= 0:
            return None
 
        # Normalise so the fit is scale-independent
        fl_norm = fl_f / fl_f.max()
 
        h = 6.626e-34; c_ms = 3e8; k = 1.381e-23
 
        def planck(T):
            lam = wl_f * 1e-10      # Å → m
            B = (2 * h * c_ms**2 / lam**5) / (np.exp(h * c_ms / (lam * k * T)) - 1.0)
            B_norm = B / B.max() if B.max() > 0 else B
            resid = fl_norm - B_norm
            return float(np.sum(resid**2))
 
        # Coarse grid
        T_grid = np.arange(2500, 50001, 500)
        losses = [planck(T) for T in T_grid]
        T0 = float(T_grid[np.argmin(losses)])
 
        # Refine
        result = minimize_scalar(planck, bounds=(max(1000, T0 - 2000), T0 + 2000),
                                 method='bounded')
        return float(result.x) if result.success else T0
    except Exception:
        return None
 
# ---------------------------------------------------------------------------
# Colour → Teff relations
#
# Two relations, each clamped to its calibrated domain (outside which they go
# non-physical and must return None rather than a nonsense temperature):
#
#  • Curtis et al. (2020): Gaia (BP-RP)_0 → Teff, 7th-order polynomial.
#    Valid 0.55 < BP-RP < 3.20  (3070–6470 K), ~50 K precision. This is the
#    modern, Gaia-native relation — preferred whenever a BP-RP colour exists
#    (i.e. the XP path). Calibrated on DEREDDENED colour; we feed observed
#    colour, so for reddened fields the Teff is biased cool. No extinction
#    handling here yet — flagged for a future pass.
#
#  • Ballesteros (2012): Johnson B-V → Teff. Used for catalog-only stars that
#    have B-V but no BP-RP. Has a pole near B-V ≈ -0.674; clamped to a sane
#    domain so blueward/negative garbage is rejected.
# ---------------------------------------------------------------------------

# Curtis 2020 coefficients (Table 1 / Appendix), BP-RP ascending powers 0..7
_CURTIS2020_COEFFS = (
    -416.585, 39780.0, -84190.5, 85203.9,
    -48225.9, 15598.5, -2694.76, 192.865,
)
_CURTIS_BPRP_MIN = 0.55
_CURTIS_BPRP_MAX = 3.20

def _teff_from_bp_rp_curtis(bp_rp):
    """Gaia (BP-RP)_0 → Teff via Curtis et al. 2020, or None if out of range."""
    if bp_rp is None:
        return None
    try:
        c = float(bp_rp)
    except Exception:
        return None
    if not math.isfinite(c) or c < _CURTIS_BPRP_MIN or c > _CURTIS_BPRP_MAX:
        return None
    T = 0.0
    for i, coeff in enumerate(_CURTIS2020_COEFFS):
        T += coeff * (c ** i)
    if not math.isfinite(T) or T <= 0.0 or T > 60000.0:
        return None
    return float(T)


# Real dwarf B-V bottoms out near -0.33 (hottest O stars). We allow down to
# -0.5 so genuine O/B stars with normal photometric scatter still plot; colours
# bluer than this are unphysical (no star is at B-V = -0.76 or -1.47) and are
# rejected as bad readings. The Teff ceiling below is the real safeguard against
# the Ballesteros pole at B-V ≈ -0.674 inflating temperatures near the edge.
_BV_MIN_VALID = -0.50
_BV_MAX_VALID =  2.00   # Ballesteros upper validity edge

def _ballesteros_teff(bv):
    """Johnson B-V → Teff via Ballesteros 2012, or None if out of valid range."""
    if bv is None:
        return None
    try:
        bv = float(bv)
    except Exception:
        return None
    if not math.isfinite(bv) or bv < _BV_MIN_VALID or bv > _BV_MAX_VALID:
        return None
    d1 = 0.92 * bv + 1.7
    d2 = 0.92 * bv + 0.62
    if abs(d1) < 1e-6 or abs(d2) < 1e-6:
        return None
    T = 4600.0 * (1.0 / d1 + 1.0 / d2)
    if not math.isfinite(T) or T <= 0.0 or T > 100000.0:
        return None
    return float(T)


def _teff_from_color(bp_rp=None, bv=None):
    """Best available colour→Teff. Prefers Gaia BP-RP (Curtis 2020); falls
    back to B-V (Ballesteros). Returns (Teff, source_str) or (None, None)."""
    T = _teff_from_bp_rp_curtis(bp_rp)
    if T is not None:
        return T, "Curtis2020(BP-RP)"
    T = _ballesteros_teff(bv)
    if T is not None:
        return T, "Ballesteros(B-V)"
    return None, None 
 
def _spectral_class_from_teff(T):
    """Return single letter spectral class from Teff."""
    if T is None:
        return "?"
    if T >= 30000: return "O"
    if T >= 10000: return "B"
    if T >=  7500: return "A"
    if T >=  6000: return "F"
    if T >=  5200: return "G"
    if T >=  3700: return "K"
    return "M"
 
 
# Spectral class → distinctive color for the "class color" plot mode
_CLASS_COLORS = {
    "O": "#9bb0ff",   # blue-white
    "B": "#aabfff",   # blue-white
    "A": "#cad7ff",   # white-blue
    "F": "#f8f7ff",   # white
    "G": "#fff4ea",   # yellow-white
    "K": "#ffd2a1",   # orange
    "M": "#ffad51",   # orange-red
    "?": "#888888",
}
 

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QCheckBox, QSpinBox, QDoubleSpinBox, QDialogButtonBox, QWidget,
)
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import QColorDialog
 
 
class HRSettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("H-R Diagram Settings")
        layout = QVBoxLayout(self)
 
        # ── 1) Gaia XP photometry toggle ─────────────────────────────────
        self.use_xp_chk = QCheckBox(
            "Use Gaia XP synthetic photometry (recommended if library installed)")
        self.use_xp_chk.setChecked(True)
        self.use_xp_chk.setToolTip(
            "When checked, B and V magnitudes are synthesised from Gaia XP spectra\n"
            "rather than taken from the SIMBAD catalogue. This gives consistent\n"
            "photometry for every star with an XP spectrum and typically triples\n"
            "or more the number of stars on the diagram.\n\n"
            "Requires the Gaia XP spectral library to be installed.")
        layout.addWidget(self.use_xp_chk)
 
        # ── 2) Teff source ────────────────────────────────────────────────
        layout.addWidget(QLabel("Teff estimation:"))
        self.teff_mode_cb = QComboBox()
        self.teff_mode_cb.addItems([
            "Blackbody fit to XP spectrum (best, requires XP)",
            "Ballesteros B-V formula (classic)",
        ])
        self.teff_mode_cb.setToolTip(
            "Blackbody fit directly fits a Planck function to the XP continuum.\n"
            "More accurate especially for cool/red stars. Falls back to Ballesteros\n"
            "if no XP spectrum is available.")
        layout.addWidget(self.teff_mode_cb)
 
        # ── 3) Star Color Mode ────────────────────────────────────────────
        layout.addWidget(QLabel("Star Color Mode:"))
        self.color_mode_cb = QComboBox()
        self.color_mode_cb.addItems([
            "Realistic (blackbody)",
            "Spectral class (O/B/A/F/G/K/M)",
            "Solid (Custom)",
        ])
        layout.addWidget(self.color_mode_cb)
 
        self.color_btn = QPushButton("Choose Solid Color…")
        self.custom_color = QColor(255, 255, 255)
        self.color_btn.setVisible(False)
        layout.addWidget(self.color_btn)
        self.color_btn.clicked.connect(self._choose_color)
        self.color_mode_cb.currentIndexChanged.connect(
            lambda idx: self.color_btn.setVisible(
                self.color_mode_cb.currentText().startswith("Solid")
            )
        )
 
        # ── 4) Outlier flagging ───────────────────────────────────────────
        self.flag_outliers_chk = QCheckBox(
            "Flag spectral outliers (carbon stars, emission-line, peculiar)")
        self.flag_outliers_chk.setChecked(True)
        self.flag_outliers_chk.setToolTip(
            "Stars whose XP-derived Teff diverges strongly from the B-V prediction\n"
            "are marked with a distinct symbol (triangle) so they stand out as\n"
            "non-standard objects rather than appearing as H-R diagram noise.")
        layout.addWidget(self.flag_outliers_chk)
 
        # ── 5) Background ─────────────────────────────────────────────────
        layout.addWidget(QLabel("Background:"))
        self.bg_mode_cb = QComboBox()
        self.bg_mode_cb.addItems(["HR Diagram Image", "Solid Black"])
        layout.addWidget(self.bg_mode_cb)
 
        # ── 6) Marker Size ────────────────────────────────────────────────
        layout.addWidget(QLabel("Marker Size:"))
        self.marker_size_mode_cb = QComboBox()
        self.marker_size_mode_cb.addItems(["Auto (recommended)", "Manual"])
        layout.addWidget(self.marker_size_mode_cb)
 
        self.marker_size_widget = QWidget()
        ms_layout = QHBoxLayout(self.marker_size_widget)
        ms_layout.setContentsMargins(0, 0, 0, 0)
        ms_layout.addWidget(QLabel("Marker Size:"))
        self.marker_size_spin = QSpinBox()
        self.marker_size_spin.setRange(2, 40)
        self.marker_size_spin.setValue(8)
        ms_layout.addWidget(self.marker_size_spin)
        ms_layout.addStretch(1)
        layout.addWidget(self.marker_size_widget)
        self.marker_size_widget.setVisible(False)
        self.marker_size_mode_cb.currentIndexChanged.connect(
            lambda idx: self.marker_size_widget.setVisible(
                self.marker_size_mode_cb.currentText().startswith("Manual")
            )
        )
 
        # ── 7) Axis Range ─────────────────────────────────────────────────
        layout.addWidget(QLabel("Axis Range:"))
        self.range_mode_cb = QComboBox()
        self.range_mode_cb.addItems(["Default (–0.3→2.25, –9→19)", "Custom"])
        layout.addWidget(self.range_mode_cb)
 
        self.custom_range_widget = QWidget()
        cr_layout = QHBoxLayout(self.custom_range_widget)
        for lbl, attr, val in [
            ("X Min:", "xmin_spin", -0.3),
            ("X Max:", "xmax_spin",  2.25),
            ("Y Min:", "ymin_spin", -9.0),
            ("Y Max:", "ymax_spin", 19.0),
        ]:
            cr_layout.addWidget(QLabel(lbl))
            spin = QDoubleSpinBox()
            spin.setRange(-50.0, 50.0)
            spin.setDecimals(3)
            spin.setValue(val)
            cr_layout.addWidget(spin)
            setattr(self, attr, spin)
        layout.addWidget(self.custom_range_widget)
        self.custom_range_widget.setVisible(False)
        self.range_mode_cb.currentIndexChanged.connect(
            lambda idx: self.custom_range_widget.setVisible(
                self.range_mode_cb.currentText().startswith("Custom")
            )
        )
 
        # ── 8) Show Sun ───────────────────────────────────────────────────
        self.show_sun_cb = QCheckBox("Include Sun on diagram")
        self.show_sun_cb.setChecked(True)
        layout.addWidget(self.show_sun_cb)
        # ── 3D CMD options ────────────────────────────────────────────────
        from PyQt6.QtWidgets import QFrame
        sep_line = QFrame()
        sep_line.setFrameShape(QFrame.Shape.HLine)
        sep_line.setStyleSheet("color: #333;")
        layout.addWidget(sep_line)

        layout.addWidget(QLabel("── 3D Color-Magnitude Diagram ──"))

        self.cmd_3d_btn_chk = QCheckBox("Add '3D CMD' button to output")
        self.cmd_3d_btn_chk.setChecked(True)
        layout.addWidget(self.cmd_3d_btn_chk)

        layout.addWidget(QLabel("Distance axis units:"))
        self.dist_units_cb = QComboBox()
        self.dist_units_cb.addItems(["Parsecs", "Light-years"])
        layout.addWidget(self.dist_units_cb)

        layout.addWidget(QLabel("Distance axis scale:"))
        self.dist_scale_cb = QComboBox()
        self.dist_scale_cb.addItems(["Linear", "Logarithmic"])
        layout.addWidget(self.dist_scale_cb)

        layout.addWidget(QLabel("Distance range:"))
        self.dist_range_cb = QComboBox()
        self.dist_range_cb.addItems(["Auto", "Custom"])
        layout.addWidget(self.dist_range_cb)

        self.dist_range_widget = QWidget()
        dr_layout = QHBoxLayout(self.dist_range_widget)
        dr_layout.setContentsMargins(0, 0, 0, 0)
        dr_layout.addWidget(QLabel("Min:"))
        self.dist_min_spin = QDoubleSpinBox()
        self.dist_min_spin.setRange(0.1, 1e7)
        self.dist_min_spin.setDecimals(1)
        self.dist_min_spin.setValue(0.0)
        dr_layout.addWidget(self.dist_min_spin)
        dr_layout.addWidget(QLabel("Max:"))
        self.dist_max_spin = QDoubleSpinBox()
        self.dist_max_spin.setRange(1.0, 1e7)
        self.dist_max_spin.setDecimals(1)
        self.dist_max_spin.setValue(1000.0)
        dr_layout.addWidget(self.dist_max_spin)
        layout.addWidget(self.dist_range_widget)
        self.dist_range_widget.setVisible(False)
        self.dist_range_cb.currentIndexChanged.connect(
            lambda idx: self.dist_range_widget.setVisible(
                self.dist_range_cb.currentText() == "Custom"
            )
        )
        self._load_settings()
        # ── OK / Cancel ───────────────────────────────────────────────────
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)
 
    def _load_settings(self):
        s = QSettings()
        self.use_xp_chk.setChecked(s.value("HR/use_xp", True, type=bool))
        idx = self.teff_mode_cb.findText(s.value("HR/teff_mode", ""))
        if idx >= 0: self.teff_mode_cb.setCurrentIndex(idx)
        idx = self.color_mode_cb.findText(s.value("HR/color_mode", ""))
        if idx >= 0: self.color_mode_cb.setCurrentIndex(idx)
        self.flag_outliers_chk.setChecked(s.value("HR/flag_outliers", True, type=bool))
        idx = self.bg_mode_cb.findText(s.value("HR/bg_mode", ""))
        if idx >= 0: self.bg_mode_cb.setCurrentIndex(idx)
        idx = self.marker_size_mode_cb.findText(s.value("HR/marker_size_mode", ""))
        if idx >= 0: self.marker_size_mode_cb.setCurrentIndex(idx)
        self.marker_size_spin.setValue(s.value("HR/marker_size", 8, type=int))
        idx = self.range_mode_cb.findText(s.value("HR/range_mode", ""))
        if idx >= 0: self.range_mode_cb.setCurrentIndex(idx)
        self.xmin_spin.setValue(s.value("HR/x_min", -0.3, type=float))
        self.xmax_spin.setValue(s.value("HR/x_max", 2.25, type=float))
        self.ymin_spin.setValue(s.value("HR/y_min", -9.0, type=float))
        self.ymax_spin.setValue(s.value("HR/y_max", 19.0, type=float))
        self.show_sun_cb.setChecked(s.value("HR/show_sun", True, type=bool))
        self.cmd_3d_btn_chk.setChecked(s.value("HR/show_3d_cmd", True, type=bool))
        idx = self.dist_units_cb.findText(s.value("HR/dist_units", ""))
        if idx >= 0: self.dist_units_cb.setCurrentIndex(idx)
        idx = self.dist_scale_cb.findText(s.value("HR/dist_scale", ""))
        if idx >= 0: self.dist_scale_cb.setCurrentIndex(idx)
        idx = self.dist_range_cb.findText(s.value("HR/dist_range", ""))
        if idx >= 0: self.dist_range_cb.setCurrentIndex(idx)
        self.dist_min_spin.setValue(s.value("HR/dist_min", 0.0, type=float))
        self.dist_max_spin.setValue(s.value("HR/dist_max", 1000.0, type=float))

    def _save_settings(self):
        s = QSettings()
        s.setValue("HR/use_xp",           self.use_xp_chk.isChecked())
        s.setValue("HR/teff_mode",         self.teff_mode_cb.currentText())
        s.setValue("HR/color_mode",        self.color_mode_cb.currentText())
        s.setValue("HR/flag_outliers",     self.flag_outliers_chk.isChecked())
        s.setValue("HR/bg_mode",           self.bg_mode_cb.currentText())
        s.setValue("HR/marker_size_mode",  self.marker_size_mode_cb.currentText())
        s.setValue("HR/marker_size",       self.marker_size_spin.value())
        s.setValue("HR/range_mode",        self.range_mode_cb.currentText())
        s.setValue("HR/x_min",             self.xmin_spin.value())
        s.setValue("HR/x_max",             self.xmax_spin.value())
        s.setValue("HR/y_min",             self.ymin_spin.value())
        s.setValue("HR/y_max",             self.ymax_spin.value())
        s.setValue("HR/show_sun",          self.show_sun_cb.isChecked())
        s.setValue("HR/show_3d_cmd",       self.cmd_3d_btn_chk.isChecked())
        s.setValue("HR/dist_units",        self.dist_units_cb.currentText())
        s.setValue("HR/dist_scale",        self.dist_scale_cb.currentText())
        s.setValue("HR/dist_range",        self.dist_range_cb.currentText())
        s.setValue("HR/dist_min",          self.dist_min_spin.value())
        s.setValue("HR/dist_max",          self.dist_max_spin.value())

    def _choose_color(self):
        col = QColorDialog.getColor(self.custom_color, self, "Select Marker Color")
        if col.isValid():
            self.custom_color = col
 
    def getSettings(self):
        if self.exec() == QDialog.DialogCode.Accepted:
            self._save_settings()
            return {
                "use_xp":          self.use_xp_chk.isChecked(),
                "teff_mode":       self.teff_mode_cb.currentText(),
                "color_mode":      self.color_mode_cb.currentText(),
                "custom_color":    self.custom_color,
                "flag_outliers":   self.flag_outliers_chk.isChecked(),
                "bg_mode":         self.bg_mode_cb.currentText(),
                "marker_size_mode": self.marker_size_mode_cb.currentText(),
                "marker_size":     self.marker_size_spin.value(),
                "range_mode":      self.range_mode_cb.currentText(),
                "x_min": self.xmin_spin.value(),
                "x_max": self.xmax_spin.value(),
                "y_min": self.ymin_spin.value(),
                "y_max": self.ymax_spin.value(),
                "show_sun":        self.show_sun_cb.isChecked(),
                "show_3d_cmd":   self.cmd_3d_btn_chk.isChecked(),
                "dist_units":    self.dist_units_cb.currentText(),
                "dist_scale":    self.dist_scale_cb.currentText(),
                "dist_range":    self.dist_range_cb.currentText(),
                "dist_min":      self.dist_min_spin.value(),
                "dist_max":      self.dist_max_spin.value(),                
            }
        return None


class LegendDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Object Type Legend")
        self.swatches = {}
        layout = QVBoxLayout(self)

        # Build one row per category
        for category, color in CATEGORY_TO_COLOR.items():
            row = QHBoxLayout()

            # color swatch
            swatch = QLabel()
            swatch.setFixedSize(16, 16)
            swatch.setStyleSheet(f"background-color: {color.name()}; border:1px solid #000;")
            row.addWidget(swatch)
            self.swatches[category] = swatch

            # category name
            row.addWidget(QLabel(category))

            # edit‐color button
            btn = QPushButton("Edit…")
            btn.clicked.connect(lambda _, cat=category: self.change_color(cat))
            row.addWidget(btn)

            row.addStretch()
            layout.addLayout(row)

        # OK / Cancel buttons
        btn_row = QHBoxLayout()
        ok = QPushButton("OK")
        ok.clicked.connect(self.accept)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        btn_row.addStretch()
        btn_row.addWidget(ok)
        btn_row.addWidget(cancel)
        layout.addLayout(btn_row)

    def change_color(self, category):
        """Open a QColorDialog, update the swatch and CATEGORY_TO_COLOR."""
        initial = CATEGORY_TO_COLOR[category]
        c = QColorDialog.getColor(initial, self, f"Select color for {category}")
        if c.isValid():
            CATEGORY_TO_COLOR[category] = c
            sw = self.swatches[category]
            sw.setStyleSheet(f"background-color: {c.name()}; border:1px solid #000;")

def kelvin_to_rgb(T):
    """Approximate conversion from black‐body temperature (K) to sRGB tuple."""
    # based on Tanner Helland's approximation
    # Clamp input
    T = max(1000, min(T, 40000)) / 100.0
    # red
    if T <= 66:
        r = 255
    else:
        r = 329.698727446 * ((T - 60) ** -0.1332047592)
    # green
    if T <= 66:
        g = 99.4708025861 * math.log(T) - 161.1195681661
    else:
        g = 288.1221695283 * ((T - 60) ** -0.0755148492)
    # blue
    if T >= 66:
        b = 255
    elif T <= 19:
        b = 0
    else:
        b = 138.5177312231 * math.log(T - 10) - 305.0447927307

    # clamp and return CSS‐style rgb()
    def clamp(x): return int(max(0, min(x, 255)))
    return f"rgb({clamp(r)},{clamp(g)},{clamp(b)})"

def resource_path(relative_path):
    """ Get the absolute path to the resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temporary folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# Import centralized widgets
from setiastro.saspro.widgets.spinboxes import CustomSpinBox, CustomDoubleSpinBox


class _NoopSignal:
    def emit(self, *_, **__): pass

class _WIMIAdapterDoc:
    """
    Minimal doc shim so plate_solve_doc_inplace can write into .metadata.
    """
    def __init__(self, image: np.ndarray, metadata: dict | None = None):
        self.image = image
        self.metadata = metadata if isinstance(metadata, dict) else {}
        self.changed = _NoopSignal()

import numpy.ma as ma

def _mask_safe_float(val):
    """
    Convert SIMBAD / Astropy table values to a normal float or None.
    - Returns None for masked, None, or NaN.
    """
    if val is None:
        return None
    if ma.is_masked(val):
        return None
    try:
        f = float(val)
    except Exception:
        return None
    if np.isnan(f):
        return None
    return f

def _adql_quote(s) -> str:
    """Quote a string as an ADQL literal. Doubles embedded single quotes."""
    return "'" + str(s).replace("'", "''") + "'"

def _fmt_mag(v):
    """Format a magnitude for the tree's Mag column; '' for missing/non-numeric."""
    try:
        return f"{float(v):.2f}"
    except (TypeError, ValueError):
        return ""


class MinorBodyDownloadWorker(QThread):
    """
    Background worker to download/update the minor-body catalog.

    Emits:
        finished_ok(db_path: str, version: str, asteroids: int, comets: int)
        failed(error_message: str)
    """
    finished_ok = pyqtSignal(str, str, int, int)   # db_path, version, ast, com
    failed = pyqtSignal(str)

    def __init__(self, data_dir: Path, force_refresh: bool = False, parent=None):
        super().__init__(parent)
        self.data_dir = Path(data_dir)
        self.force_refresh = force_refresh

    def run(self):
        try:
            from setiastro.saspro import minorbodycatalog as mbc
            db_path, manifest = mbc.ensure_minor_body_db(
                data_dir=self.data_dir,
                manifest_url=mbc.MANIFEST_URL,
                force_refresh=self.force_refresh,
            )
            # Emit db path, version and counts so the UI can show nice stats
            self.finished_ok.emit(
                str(db_path),
                str(manifest.version),
                int(manifest.counts_asteroids),
                int(manifest.counts_comets),
            )
        except Exception as e:
            self.failed.emit(str(e))

class MinorBodySearchWorker(QThread):
    """
    Runs the minor-body Skyfield computation in a background thread.

    Emits:
      - finished_ok(list[dict]) on success
      - failed(str) on error
      - progress(int done, int total) for UI updates
    """
    finished_ok = pyqtSignal(list)
    failed = pyqtSignal(str)
    progress = pyqtSignal(int, int)

    def __init__(
        self,
        dialog,
        db_path,
        ra_center,
        dec_center,
        radius_deg,
        obs_datetime,
        H_ast,
        N_ast,
        H_com,
        N_com,
        target_name=None,
    ):
        super().__init__(dialog)
        self.dialog = dialog
        self.db_path = db_path
        self.ra_center = ra_center
        self.dec_center = dec_center
        self.radius_deg = radius_deg
        self.obs_datetime = obs_datetime
        self.H_ast = H_ast
        self.N_ast = N_ast
        self.H_com = H_com
        self.N_com = N_com
        self.target_name = target_name
        self._cancelled = False

    def request_cancel(self):
        self._cancelled = True

    def run(self):
        try:
            def progress_cb(done: int, total: int) -> bool:
                self.progress.emit(done, total)
                return not self._cancelled

            results = self.dialog._query_minor_planets_from_db(
                db_path=self.db_path,
                ra_center=self.ra_center,
                dec_center=self.dec_center,
                radius_deg=self.radius_deg,
                obs_datetime=self.obs_datetime,
                H_ast=self.H_ast,
                N_ast=self.N_ast,
                H_com=self.H_com,
                N_com=self.N_com,
                target_name=self.target_name,
                progress_cb=progress_cb,
            )
            if self._cancelled:
                self.finished_ok.emit([])
            else:
                self.finished_ok.emit(results)
        except Exception as e:
            self.failed.emit(str(e))

def slugify_minor_body_for_3d(name: str) -> str:
    """
    Turn things like '(584) Semiramis' or '584 Semiramis'
    into '584-Semiramis', and fall back to a generic slug.
    """
    if not name:
        return ""

    s = name.replace("\u00a0", " ").strip()  # normalize non-breaking spaces

    # Look for a leading numeric designation, possibly in parentheses:
    #   "(584) Semiramis"  → num=584, rest="Semiramis"
    #   "584 Semiramis"    → num=584, rest="Semiramis"
    m = re.match(r'^\(?\s*([0-9]+)\s*\)?\s*(.*)$', s)
    if m:
        num = m.group(1)
        rest = m.group(2).strip()
        if rest:
            rest_clean = re.sub(r'[^A-Za-z0-9]+', '-', rest).strip('-')
            return f"{num}-{rest_clean}"
        return num  # just the number (edge case)

    # Fallback for comets / weird designations: generic slug
    return re.sub(r'[^A-Za-z0-9]+', '-', s).strip('-')


def open_minor_body_3d_page(name: str, kind: str = "Asteroid") -> None:
    """
    Open the 3d-asteroids page for a minor body.
    Uses /asteroids/ for asteroids and /comets/ for comets.
    """
    if not name:
        return

    slug = slugify_minor_body_for_3d(name)
    if not slug:
        return

    base = "asteroids"
    if kind and str(kind).lower().startswith("comet"):
        base = "comets"

    url = f"https://3d-asteroids.space/{base}/{slug}"
    webbrowser.open(url)


def open_jpl_sbdb_page(name: str, kind: str = "Asteroid") -> None:
    """
    Open JPL's Small-Body Database Lookup for this object — the
    authoritative record (orbit, physical parameters, close approaches,
    and JPL's own orbit viewer).

    The tool takes a free-form identifier via `sstr`, so no slug or
    provisional-designation guessing is needed: a plain number resolves
    an asteroid, and the full designation resolves a comet. One endpoint
    serves both.
    """
    if not name:
        return
    s = name.replace(chr(160), " ").strip()      # normalize non-breaking space
    is_comet = bool(kind and str(kind).lower().startswith("comet"))

    if is_comet:
        # Comets: never reduce to a bare number ('1P' -> 1 would resolve
        # to asteroid Ceres). Pass the designation as-is.
        sstr = s
    elif re.match(r'^\d{4}[ _-][A-Za-z]{1,2}\d*$', s):
        # Unnumbered provisional ('2011 TK5'): the leading 4 digits are a
        # YEAR, not a catalog number — pass the whole designation.
        sstr = s
    else:
        # Numbered asteroid ('(6281) Strnad', '6281 Strnad', '1 Ceres'):
        # the catalog number alone is the least ambiguous identifier.
        m = re.match(r'^\(?\s*(\d+)\s*\)?', s)
        sstr = m.group(1) if m else s

    url = ("https://ssd.jpl.nasa.gov/tools/sbdb_lookup.html#/?sstr="
           + quote(sstr))
    webbrowser.open(url)


def _lookup_minor_body_row(db_path, name: str, kind: str = ""):
    """
    Read one catalog row for `name` straight from the minor-body SQLite,
    read-only, matching on the `designation` column. Tries the table the
    `kind` suggests first, then the other. Returns a plain dict, or None.
    """
    import sqlite3
    from pathlib import Path

    tables = (["comets", "asteroids"]
              if str(kind or "").lower().startswith("comet")
              else ["asteroids", "comets"])
    try:
        uri = f"file:{Path(db_path).as_posix()}?mode=ro"
        conn = sqlite3.connect(uri, uri=True)
    except Exception:
        return None
    try:
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        for tbl in tables:
            try:
                cur.execute(
                    f"SELECT * FROM {tbl} WHERE designation = ? LIMIT 1", (name,))
            except sqlite3.Error:
                continue
            r = cur.fetchone()
            if r is not None:
                return {k: r[k] for k in r.keys()}
        return None
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _open_sas_orbit_explorer(window, name: str, kind: str = "Asteroid") -> None:
    """
    Launch the in-app SASpro Orbit Explorer for a minor body. Needs the
    observation JD and DB path the last minor-body search stashed on the
    window, plus the body's Keplerian elements looked up by designation.
    """
    from PyQt6.QtWidgets import QMessageBox

    if not _HAS_ORBIT_EXPLORER:
        QMessageBox.information(
            window, "Orbit Explorer",
            "The 3D orbit explorer could not be loaded.\n\n"
            f"{_ORBIT_EXPLORER_ERR}\n\n"
            "It needs pyqtgraph.opengl and PyOpenGL (pip install PyOpenGL).")
        return

    jd = getattr(window, "_minor_jd", None)
    db_path = getattr(window, "_minor_db_path", None)
    if jd is None or not db_path:
        QMessageBox.information(
            window, "Orbit Explorer",
            "Run a minor-body search first — I need the observation time it "
            "was computed at to place the orbit.")
        return

    row = _lookup_minor_body_row(db_path, name, kind)
    if row is None:
        QMessageBox.information(
            window, "Orbit Explorer",
            f"Couldn't find {name} in the catalog to read its orbit.")
        return

    el = extract_elements_from_row(row)
    if el is None:
        QMessageBox.information(
            window, "Orbit Explorer",
            f"{name} has no usable orbital elements in the catalog, so its "
            "orbit can't be drawn.")
        return

    H = None
    for k in ("magnitude_H", "H", "absolute_magnitude"):
        if k in row and row[k] not in (None, ""):
            try:
                H = float(row[k])
                break
            except Exception:
                pass

    body = {"designation": name, "kind": (kind or "minor body"),
            "H": H, "elements": el}
    icon = None
    try:
        icon = window.windowIcon()
    except Exception:
        icon = None
    dlg = open_orbit_explorer(window, body, float(jd),
                              settings=getattr(window, "settings", None),
                              icon=icon)
    if dlg is not None:
        # Hold a reference so the non-modal window isn't garbage collected.
        refs = getattr(window, "_orbit_dialogs", None)
        if refs is None:
            refs = window._orbit_dialogs = []
        refs.append(dlg)


def prompt_minor_body_choice(window, name: str, kind: str = "Asteroid") -> None:
    """
    Ask how to explore a minor body, then dispatch. Replaces the old
    straight-to-3d-asteroids double-click: not every object is on that
    site, and the in-app Orbit Explorer works for anything in the local
    catalog.
    """
    from PyQt6.QtWidgets import QMessageBox

    if not name:
        return
    box = QMessageBox(window)
    box.setWindowTitle("Explore Minor Body")
    box.setIcon(QMessageBox.Icon.Question)
    box.setText(f"How would you like to explore {name}?")
    box.setInformativeText(
        "Orbit Explorer draws it in 3D inside SASpro from the local catalog.\n"
        "JPL Small-Body Database is the authoritative record (orbit, physical\n"
        "parameters, close approaches). 3D Model Site is 3d-asteroids.space.")
    b_orbit = box.addButton("SASpro Orbit Explorer", QMessageBox.ButtonRole.AcceptRole)
    b_jpl = box.addButton("JPL Small-Body Database", QMessageBox.ButtonRole.AcceptRole)
    b_model = box.addButton("3D Model Site", QMessageBox.ButtonRole.AcceptRole)
    box.addButton(QMessageBox.StandardButton.Cancel)
    box.setDefaultButton(b_orbit)
    box.exec()
    clicked = box.clickedButton()
    if clicked is b_jpl:
        open_jpl_sbdb_page(name, kind=kind)
    elif clicked is b_model:
        open_minor_body_3d_page(name, kind=kind)
    elif clicked is b_orbit:
        _open_sas_orbit_explorer(window, name, kind=kind)

class _CrosshairOverlay(QWidget):
    """Transparent overlay that draws a crosshair at the viewport center."""
    MODES = ["off", "thin", "full", "gap"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._mode = 0  # 0=off, 1=thin full lines, 2=thick full lines, 3=gap center

    def set_mode(self, mode: int):
        self._mode = mode
        self.update()

    def paintEvent(self, e):
        if self._mode == 0:
            return
        from PyQt6.QtGui import QPainter, QPen
        w, h = self.width(), self.height()
        cx, cy = w // 2, h // 2
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        if self._mode == 1:
            # Thin full crosshair — simple white lines
            pen = QPen(QColor(255, 255, 255, 160), 1, Qt.PenStyle.SolidLine)
            p.setPen(pen)
            p.drawLine(0, cy, w, cy)
            p.drawLine(cx, 0, cx, h)

        elif self._mode == 2:
            # Gap crosshair — yellow lines with gap + center dot
            gap = 20
            pen = QPen(QColor(255, 255, 0, 220), 1, Qt.PenStyle.SolidLine)
            p.setPen(pen)
            p.drawLine(0, cy, cx - gap, cy)
            p.drawLine(cx + gap, cy, w, cy)
            p.drawLine(cx, 0, cx, cy - gap)
            p.drawLine(cx, cy + gap, cx, h)
            p.setBrush(QColor(255, 255, 0, 220))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(cx - 2, cy - 2, 4, 4)

        elif self._mode == 3:
            # Concentric circles + thin crosshair lines
            pen_line = QPen(QColor(255, 255, 255, 120), 1, Qt.PenStyle.SolidLine)
            p.setPen(pen_line)
            p.drawLine(0, cy, w, cy)
            p.drawLine(cx, 0, cx, h)

            pen_circle = QPen(QColor(255, 255, 255, 180), 1, Qt.PenStyle.SolidLine)
            p.setPen(pen_circle)
            p.setBrush(Qt.BrushStyle.NoBrush)
            for r in (30, 60, 100):
                p.drawEllipse(QPointF(cx, cy), r, r)

        p.end()

ATLAS_CATALOG_URL = "https://f005.backblazeb2.com/file/setiastro-atlas/catalog.json"

class AtlasCatalogThread(QThread):
    """Fetch the community atlas catalog.json in the background."""
    finished = pyqtSignal(list)   # list of atlas entries, or [] on failure
 
    def run(self):
        import urllib.request
        import json as _json
 
        for attempt in range(3):
            try:
                with urllib.request.urlopen(ATLAS_CATALOG_URL, timeout=8) as resp:
                    data = _json.loads(resp.read().decode("utf-8"))
                    entries = data if isinstance(data, list) else data.get("entries", [])
                    self.finished.emit(entries)
                    return
            except Exception:
                if attempt < 2:
                    import time
                    time.sleep(1.5)
        # All attempts failed — emit empty list silently
        self.finished.emit([])

class SimbadQueryWorker(QThread):
    """
    Runs the two-step SIMBAD lookup off the GUI thread so Query Simbad
    doesn't freeze WIMI. Emits stage() for live progress text and
    finished_ok(result, extras_dict) on success, failed(msg) on error.
    `cancel()` is cooperative — it is checked between stages/attempts.
    """
    stage        = pyqtSignal(str)                # free-form status text
    attempt_info = pyqtSignal(int, int)           # (current_attempt, max_attempts)
    finished_ok  = pyqtSignal(object, dict)       # (astropy Table or None, extras_dict)
    failed       = pyqtSignal(str)                # error message

    def __init__(self, tap_query: str, sam_url: str, sam_params: dict,
                 max_attempts: int = 5, retry_wait_s: float = 1.0, parent=None):
        super().__init__(parent)
        self._tap_query     = tap_query
        self._sam_url       = sam_url
        self._sam_params    = sam_params
        self._max_attempts  = int(max_attempts)
        self._retry_wait_s  = float(retry_wait_s)
        self._cancel        = False

    def cancel(self):
        self._cancel = True

    def _check_cancel(self):
        if self._cancel:
            raise RuntimeError("Query cancelled by user")

    def run(self):
        try:
            # ——— Stage 1: TAP query with retries ———
            # (cds_health is imported at module level; no local import needed.)
            self.stage.emit("Contacting SIMBAD TAP service…")
            result = None
            last_err = None
            for attempt in range(1, self._max_attempts + 1):
                self._check_cancel()
                self.attempt_info.emit(attempt, self._max_attempts)
                self.stage.emit(
                    f"Querying SIMBAD TAP (attempt {attempt}/{self._max_attempts})…"
                )
                try:
                    result = Simbad.query_tap(self._tap_query)
                    last_err = None
                    cds_health.note_success()
                    break
                except Exception as e:
                    last_err = e
                    # A connection failure means the host is not answering.
                    # Retrying costs a full timeout per attempt to re-learn
                    # something we already know, so stop on the first one.
                    # Server-side errors (5xx, rate-limit) are still retried.
                    if cds_health.note_failure(e, context="simbad/query_tap"):
                        self.failed.emit(
                            "SIMBAD is unreachable (connection failed).\n\n"
                            "CDS appears to be down — further retries would "
                            "only wait out the same timeout.\n\n"
                            f"{type(e).__name__}: {e}"
                        )
                        return
                    if attempt < self._max_attempts:
                        self.stage.emit(
                            f"TAP attempt {attempt} failed ({type(e).__name__}); "
                            f"retrying in {self._retry_wait_s:.0f}s…"
                        )
                        # Cooperative sleep so cancel is responsive
                        slept = 0.0
                        step = 0.1
                        while slept < self._retry_wait_s:
                            if self._cancel:
                                break
                            time.sleep(step)
                            slept += step

            if last_err is not None:
                self.failed.emit(
                    "SIMBAD TAP service unreachable after "
                    f"{self._max_attempts} attempts.\n\nLast error:\n{last_err}"
                )
                return

            self._check_cancel()

            if result is None or len(result) == 0:
                # Empty result is NOT an error — upstream decides what to do
                self.stage.emit("SIMBAD returned no objects in this region.")
                self.finished_ok.emit(None, {})
                return

            self.stage.emit(f"TAP returned {len(result)} rows. Fetching star extras…")

            # ——— Stage 2: sim-sam for FLUX/PLX/SP extras ———
            self._check_cancel()
            extras = {}

            # No stellar types selected -> the caller passed sam_url=None.
            # Nothing to fetch; skip the slowest request in the query.
            if not self._sam_url:
                self.stage.emit("No star types selected; skipping photometry fetch.")
                self._check_cancel()
                self.stage.emit("Merging results…")
                self.finished_ok.emit(result, {})
                return

            try:
                self.stage.emit("Downloading star photometry/parallax (sim-sam)…")
                # (connect, read). 300 s was a single combined timeout — five
                # minutes of nothing when the host is dead. 5 s to establish a
                # connection is generous; 90 s of read covers a genuinely slow
                # VOTable for a wide field.
                resp = requests.get(self._sam_url, params=self._sam_params,
                                    timeout=(5, 90))
                resp.raise_for_status()

                self._check_cancel()
                self.stage.emit("Parsing VOTable response…")
                vot = parse_single_table(BytesIO(resp.content))
                tbl = vot.to_table(use_names_over_ids=True)
                extras = {row["MAIN_ID"]: row for row in tbl}
                self.stage.emit(f"Got extras for {len(extras)} stars.")
            except Exception as e:
                # Non-fatal — the caller will note we have no extras
                self.stage.emit(
                    f"sim-sam extras unavailable ({type(e).__name__}); continuing without."
                )
                extras = {}

            self._check_cancel()
            self.stage.emit("Merging results…")
            self.finished_ok.emit(result, extras)

        except RuntimeError as e:
            # Cancellation path
            if "cancelled" in str(e).lower():
                self.failed.emit("Cancelled.")
            else:
                self.failed.emit(f"{type(e).__name__}: {e}")
        except Exception as e:
            import traceback
            self.failed.emit(f"{type(e).__name__}: {e}\n\n{traceback.format_exc()}")

def _ra_in_atlas(ra_deg: float, dec_deg: float, atlas_entries: list) -> bool:
    """
    Returns True if (ra_deg, dec_deg) falls within the bounding box of any
    atlas entry's four corner coordinates.
 
    Fast enough for thousands of WIMS objects against a small atlas catalog.
    Handles RA wrap-around at 0/360.
    """
    for entry in atlas_entries:
        c_ra  = entry.get("corners_ra",  [])
        c_dec = entry.get("corners_dec", [])
        if len(c_ra) != 4 or len(c_dec) != 4:
            # Fallback: use center + half-FOV bounding box
            ra_c   = entry.get("ra_center",  0.0)
            dec_c  = entry.get("dec_center", 0.0)
            fov_w  = entry.get("fov_w_deg",  0.0)
            fov_h  = entry.get("fov_h_deg",  0.0)
            if abs(dec_deg - dec_c) > fov_h / 2.0:
                continue
            # RA delta with wrap
            dra = abs(ra_deg - ra_c) % 360
            if dra > 180:
                dra = 360 - dra
            if dra <= fov_w / 2.0:
                return True
            continue
 
        dec_min = min(c_dec)
        dec_max = max(c_dec)
        if not (dec_min <= dec_deg <= dec_max):
            continue
 
        ra_min = min(c_ra)
        ra_max = max(c_ra)
        ra_span = ra_max - ra_min
 
        if ra_span > 180:
            # Footprint straddles 0/360 — check outside the gap
            if ra_deg >= ra_min or ra_deg <= ra_max:
                return True
        else:
            if ra_min <= ra_deg <= ra_max:
                return True
 
    return False

# Real dwarf B-V bottoms out near -0.33 (hottest O stars). We allow down to
# -0.5 so genuine O/B stars with normal photometric scatter still plot; colours
# bluer than this are unphysical (no star is at B-V = -0.76 or -1.47) and are
# rejected as bad readings. The Teff ceiling below is the real safeguard against
# the Ballesteros pole at B-V ≈ -0.674 inflating temperatures near the edge.
_BV_MIN_VALID = -0.50
_BV_MAX_VALID =  2.00   # Ballesteros upper validity edge

def _ballesteros_teff(bv):
    """B-V → Teff (Kelvin) via Ballesteros 2012, or None if out of valid range.

    Returns None for colors outside [-0.35, 2.0] or anywhere the formula is
    singular/non-physical, so callers can skip the star instead of plotting a
    nonsense temperature.
    """
    if bv is None:
        return None
    try:
        bv = float(bv)
    except Exception:
        return None
    if not math.isfinite(bv):
        return None
    if bv < _BV_MIN_VALID or bv > _BV_MAX_VALID:
        return None
    d1 = 0.92 * bv + 1.7
    d2 = 0.92 * bv + 0.62
    # Guard both denominators against the pole (d2 is the one that bites in
    # the blue; keep a small margin so we don't return absurd magnitudes near it)
    if abs(d1) < 1e-6 or abs(d2) < 1e-6:
        return None
    T = 4600.0 * (1.0 / d1 + 1.0 / d2)
    if not math.isfinite(T) or T <= 0.0 or T > 60000.0:
        # 60,000 K is already hotter than the hottest real O/WR star; anything
        # above it is the formula misbehaving near the pole.
        return None
    return T

class WIMIDialog(QDialog):
    def __init__(self, parent=None, settings=None, doc_manager=None, wimi_path: Optional[str] = None, wrench_path: Optional[str] = None):
        super().__init__(parent)
        self.setWindowTitle("What's In My Image")
        if wimi_path:
            self.setWindowIcon(QIcon(wimi_path))

        self._doc_manager = doc_manager  # <— we’ll use this to list “views”

        # Track the theme status
        self.is_dark_mode = True
        self.metadata = {}
        self.circle_center = None
        self.circle_radius = 0    
        self.show_names = False  # Boolean to toggle showing names on the main image
        self.show_active_name = False  # Show only the active/selected object's name
        self.max_results = 100  # Default maximum number of query results     
        self.current_tool = None  # Track the active annotation tool
        self.header = Header()
        # store optional original FITS header when available (pre-seed for plate solver)
        self.original_header = None
        self.marker_style = "Circle" 
    
        self.settings = QSettings() 
        self.max_results = int(self.settings.value("wimi/max_results", 100, type=int))
        self.marker_style = self.settings.value("wimi/marker_style", "Circle", type=str)                

        main_layout = QHBoxLayout()

        # Left Column Layout
        left_panel = QVBoxLayout()

        # Load the image using the resource_path function
        wimilogo_path = get_icon_path("wimilogo.png")

        # Create a QLabel to display the logo
        self.logo_label = QLabel()

        # Set the logo image to the label
        logo_pixmap = QPixmap(wimilogo_path)

        # Scale the pixmap to fit within a desired size, maintaining the aspect ratio
        scaled_pixmap = logo_pixmap.scaled(100, 50, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)

        # Set the scaled pixmap to the label
        self.logo_label.setPixmap(scaled_pixmap)

        # Set alignment to center the logo horizontally
        self.logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Optionally, you can set a fixed size for the label (this is for layout purposes)
        #self.logo_label.setFixedSize(200, 100)  # Adjust the size as needed

        # Add the logo_label to your layout
        left_panel.addWidget(self.logo_label)

        # ── Community Sky Atlas banner ──────────────────────────────────────
        self._atlas_entries   = []
        self._atlas_thread    = None

        self._atlas_banner = QFrame()
        self._atlas_banner.setStyleSheet(
            "QFrame { background: #1a2a1a; border: 1px solid #3a6a3a; border-radius: 6px; }"
        )
        self._atlas_banner.setVisible(False)
        atlas_banner_layout = QVBoxLayout(self._atlas_banner)
        atlas_banner_layout.setContentsMargins(10, 8, 10, 8)
        atlas_banner_layout.setSpacing(4)

        self._atlas_banner_label = QLabel("🌌 Community Atlas")
        self._atlas_banner_label.setStyleSheet("color: #8bc88b; font-size: 11px; font-weight: bold;")
        self._atlas_banner_label.setWordWrap(True)
        atlas_banner_layout.addWidget(self._atlas_banner_label)

        self._atlas_banner_btn = QPushButton("View in Sky Atlas →")
        self._atlas_banner_btn.setStyleSheet(
            "QPushButton { background: #2a4a2a; color: #8bc88b; border: 1px solid #3a6a3a; "
            "border-radius: 4px; padding: 4px 10px; font-size: 11px; }"
            "QPushButton:hover { background: #3a5a3a; border-color: #5a9a5a; }"
        )
        self._atlas_banner_btn.clicked.connect(self._open_atlas_at_center)
        atlas_banner_layout.addWidget(self._atlas_banner_btn)

        left_panel.addWidget(self._atlas_banner)
        # ────────────────────────────────────────────────────────────────────

        button_layout = QHBoxLayout()
        
        # Load button
        self.load_button = QPushButton(self.tr("Load Image File"))
        self.load_button.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_FileDialogStart))
        self.load_button.clicked.connect(self.open_image)

        self.load_from_view_btn = QToolButton()
        self.load_from_view_btn.setText(self.tr("Load from View"))
        self.load_from_view_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.load_from_view_btn.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_DirOpenIcon))
        self.load_from_view_menu = QMenu(self)
        self.load_from_view_btn.setMenu(self.load_from_view_menu)
        self.load_from_view_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.load_from_view_menu.aboutToShow.connect(self._refresh_views_menu)
        button_layout.addWidget(self.load_from_view_btn)

        # AutoStretch button
        self.auto_stretch_button = QPushButton(self.tr("AutoStretch"))
        self.auto_stretch_button.clicked.connect(self.toggle_autostretch)

        # Add both buttons to the horizontal layout
        button_layout.addWidget(self.load_button)
        button_layout.addWidget(self.auto_stretch_button)

        # Add the button layout to the left panel
        left_panel.addLayout(button_layout)

        # Create the instruction QLabel for search region
        search_region_instruction_label = QLabel(self.tr("Shift+Click to define a search region"))
        search_region_instruction_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        search_region_instruction_label.setStyleSheet("font-size: 15px; color: gray;")

        # Add this QLabel to your layout at the appropriate position above RA/Dec
        left_panel.addWidget(search_region_instruction_label)  



        # Query Simbad button
        self.query_button = QPushButton(self.tr("Query Simbad"))
        self.query_button.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_DialogApplyButton))
        left_panel.addWidget(self.query_button)
        self.query_button.clicked.connect(lambda: self.query_simbad(self.get_defined_radius()))

        self.legend_button = QPushButton(self.tr("Legend"))
        self.legend_button.clicked.connect(self.show_legend)
        left_panel.addWidget(self.legend_button)

        # Create a horizontal layout for the show names checkbox and clear results button
        show_clear_layout = QHBoxLayout()

        # Create the Show Object Names checkbox
        self.show_names_checkbox = QCheckBox(self.tr("Show Object Names"))
        self.show_names_checkbox.stateChanged.connect(self.toggle_object_names)  # Connect to a function to toggle names
        show_clear_layout.addWidget(self.show_names_checkbox)

        # Create the Clear Results button
        self.clear_results_button = QPushButton(self.tr("Clear Results"))
        self.clear_results_button.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_DialogCloseButton))
        self.clear_results_button.clicked.connect(self.clear_search_results)  # Connect to a function to clear results
        show_clear_layout.addWidget(self.clear_results_button)

        # Add this horizontal layout to the left panel layout (or wherever you want it to appear)
        left_panel.addLayout(show_clear_layout)   

        # Show Active Object Name checkbox -- pops up the name of the currently
        # selected object (clicked in the tree or on the preview) even when
        # "Show Object Names" is off.
        self.show_active_name_checkbox = QCheckBox(self.tr("Show Active Object Name"))
        self.show_active_name_checkbox.stateChanged.connect(self.toggle_active_object_name)
        left_panel.addWidget(self.show_active_name_checkbox)

        # Create a horizontal layout for the two buttons
        button_layout = QHBoxLayout()

        # Show Visible Objects Only button
        self.toggle_visible_objects_button = QPushButton(self.tr("Show Visible Objects Only"))
        self.toggle_visible_objects_button.setCheckable(True)  # Toggle button state
        self.toggle_visible_objects_button.setIcon(QIcon(eye_icon_path))
        self.toggle_visible_objects_button.clicked.connect(self.filter_visible_objects)
        self.toggle_visible_objects_button.setToolTip("Toggle the visibility of objects based on brightness.")
        button_layout.addWidget(self.toggle_visible_objects_button)

        # Save CSV button
        self.save_csv_button = QPushButton(self.tr("Save CSV"))
        self.save_csv_button.setIcon(QIcon(csv_icon_path))
        self.save_csv_button.clicked.connect(self.save_results_as_csv)
        button_layout.addWidget(self.save_csv_button)

        # Add the button layout to the left panel or main layout
        left_panel.addLayout(button_layout)  

        # Advanced Search Button
        self.advanced_search_button = QPushButton(self.tr("Advanced Search"))
        self.advanced_search_button.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_FileDialogDetailedView))
        self.advanced_search_button.setCheckable(True)
        self.advanced_search_button.clicked.connect(self.toggle_advanced_search)
        left_panel.addWidget(self.advanced_search_button)

        # Advanced Search Panel (initially hidden)
        self.advanced_search_panel = QVBoxLayout()
        self.advanced_search_panel_widget = QWidget()
        self.advanced_search_panel_widget.setLayout(self.advanced_search_panel)
        self.advanced_search_panel_widget.setFixedWidth(300)
        self.advanced_search_panel_widget.setVisible(False)  # Hide initially        

        # Status label
        self.status_label = QLabel(self.tr("Status: Ready"))
        left_panel.addWidget(self.status_label)

        # Create a horizontal layout
        button_layout = QHBoxLayout()

        # Copy RA/Dec to Clipboard button
        self.copy_button = QPushButton(self.tr("Copy RA/Dec to Clipboard"), self)
        self.copy_button.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_CommandLink))
        self.copy_button.clicked.connect(self.copy_ra_dec_to_clipboard)
        button_layout.addWidget(self.copy_button)

        button_layout.addWidget(make_help_button("whats_in_my_image", self))

        # Settings button (wrench icon)
        self.settings_button = QPushButton("⚙ Settings")
        self.settings_button.setToolTip("Settings")
        self.settings_button.clicked.connect(self.open_settings_dialog)
        button_layout.addWidget(self.settings_button)

        # Add the horizontal layout to the main layout or the desired parent layout
        left_panel.addLayout(button_layout)
        
         # Save Plate Solved Fits Button
        self.save_plate_solved_button = QPushButton(self.tr("Save Plate Solved Fits"))
        self.save_plate_solved_button.setIcon(QIcon(disk_icon_path))
        self.save_plate_solved_button.clicked.connect(self.save_plate_solved_fits)
        left_panel.addWidget(self.save_plate_solved_button)       

        # RA/Dec Labels
        ra_dec_layout = QHBoxLayout()
        self.ra_label = QLabel(self.tr("RA: N/A"))
        self.dec_label = QLabel(self.tr("Dec: N/A"))
        self.orientation_label = QLabel(self.tr("Orientation: N/A°"))
        ra_dec_layout.addWidget(self.ra_label)
        ra_dec_layout.addWidget(self.dec_label)
        ra_dec_layout.addWidget(self.orientation_label)
        left_panel.addLayout(ra_dec_layout)

        # Mini Preview
        self.mini_preview = QLabel(self.tr("Mini Preview"))
        self.mini_preview.setMaximumSize(300, 300)
        self.mini_preview.mousePressEvent = self.on_mini_preview_press
        self.mini_preview.mouseMoveEvent = self.on_mini_preview_drag
        self.mini_preview.mouseReleaseEvent = self.on_mini_preview_release
        left_panel.addWidget(self.mini_preview)

        # Right Column Layout
        right_panel = QVBoxLayout()

        # Zoom buttons above the main preview
        zoom_controls_layout = QHBoxLayout()
        self.zoom_in_button  = themed_toolbtn("zoom-in",       self.tr("Zoom In"))
        self.zoom_out_button = themed_toolbtn("zoom-out",      self.tr("Zoom Out"))
        self.zoom_100_button = themed_toolbtn("zoom-original", self.tr("1:1"))
        self.zoom_100_button.clicked.connect(self.zoom_100)        
        self.fit_preview_button = themed_toolbtn("zoom-fit-best", self.tr("Fit to Preview"))
        self.zoom_in_button.clicked.connect(self.zoom_in)
        self.zoom_out_button.clicked.connect(self.zoom_out)
        self.fit_preview_button.clicked.connect(self.fit_to_preview)
        zoom_controls_layout.addWidget(self.zoom_in_button)
        zoom_controls_layout.addWidget(self.zoom_out_button)
        zoom_controls_layout.addWidget(self.zoom_100_button)
        zoom_controls_layout.addWidget(self.fit_preview_button)
        zoom_controls_layout.addStretch(1)

        # Crosshair toggle button
        self.crosshair_button = QPushButton("⊕ Crosshair")
        self.crosshair_button.setCheckable(True)
        self.crosshair_button.clicked.connect(self._cycle_crosshair)
        zoom_controls_layout.addWidget(self.crosshair_button)
        zoom_controls_layout.addStretch(1)
        right_panel.addLayout(zoom_controls_layout)

        # Crosshair state: 0=off, 1=thin, 2=full, 3=dot+lines
        self._crosshair_mode = 0
        self._crosshair_overlay = None  # created lazily after main_preview exists

        # Main Preview
        self.main_preview = CustomGraphicsView(self)
        self.main_scene = QGraphicsScene(self.main_preview)
        self.main_preview.setScene(self.main_scene)
        self.main_scene.setItemIndexMethod(QGraphicsScene.ItemIndexMethod.BspTreeIndex)
        self.main_preview.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.SmartViewportUpdate)
        self.main_preview.setOptimizationFlag(QGraphicsView.OptimizationFlag.DontSavePainterState, True)
        self.main_preview.setOptimizationFlag(QGraphicsView.OptimizationFlag.DontAdjustForAntialiasing, True)
        self.main_preview.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        #try:
        #    from PyQt6.QtOpenGLWidgets import QOpenGLWidget  # optional boost
        #    self.main_preview.setViewport(QOpenGLWidget())
        #except Exception:
        #    pass

        # Our marker layer handle
        self._marker_layer = None

        # ---- monkey-patch existing calls on CustomGraphicsView to our fast paths ----
        self.main_preview.set_query_results = lambda results: self._cg_set_query_results_proxy(results)
        self.main_preview.draw_query_results = lambda: self._cg_draw_query_results_proxy()
        self.main_preview.clear_query_results = lambda: self._cg_clear_query_results_proxy()
        self.main_preview.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        right_panel.addWidget(self.main_preview)

        # Save Annotated Image and Save Collage of Objects Buttons in a Horizontal Layout between main image and treebox
        save_buttons_layout = QHBoxLayout()

        # Button to toggle annotation tools section
        self.show_annotations_button = QPushButton(self.tr("Show Annotation Tools"))
        self.show_annotations_button.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_DialogResetButton))
        self.show_annotations_button.clicked.connect(self.toggle_annotation_tools)
        save_buttons_layout.addWidget(self.show_annotations_button)
        
        self.push_annotated_btn = QPushButton(self.tr("Push Annotated to View"))
        self.push_annotated_btn.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_ArrowForward))
        self.push_annotated_btn.clicked.connect(self.push_annotated_to_view)
        save_buttons_layout.addWidget(self.push_annotated_btn)

        self.save_annotated_button = QPushButton(self.tr("Save Annotated Image"))
        self.save_annotated_button.setIcon(QIcon(annotated_path))
        self.save_annotated_button.clicked.connect(self.save_annotated_image)
        save_buttons_layout.addWidget(self.save_annotated_button)
        
        self.save_collage_button = QPushButton(self.tr("Save Collage of Objects"))
        self.save_collage_button.setIcon(QIcon(collage_path))
        self.save_collage_button.clicked.connect(self.save_collage_of_objects)
        save_buttons_layout.addWidget(self.save_collage_button)

        # New 3D View Button
        self.show_3d_view_button = QPushButton(self.tr("3D Distance Model"))
        self.show_3d_view_button.clicked.connect(self.show_3d_model_view)
        self.show_3d_view_button.setIcon(    QApplication.style().standardIcon(QStyle.StandardPixmap.SP_TitleBarNormalButton))
        save_buttons_layout.addWidget(self.show_3d_view_button)

        self.show_hr_button = QPushButton(self.tr("H-R Diagram"))
        # Optionally give it an icon:
        self.show_hr_button.setIcon(QApplication.style().standardIcon(
            QStyle.StandardPixmap.SP_DesktopIcon))
        self.show_hr_button.clicked.connect(self.show_hr_diagram)
        save_buttons_layout.addWidget(self.show_hr_button)

        right_panel.addLayout(save_buttons_layout)        

        # Connect scroll events to update the green box in the mini preview
        # In WIMIDialog.__init__, replace the direct scrollbar connections with debounced ones:
        self._mini_preview_timer = QTimer(self)
        self._mini_preview_timer.setSingleShot(True)
        self._mini_preview_timer.setInterval(150)  # ms after scroll stops
        self._mini_preview_timer.timeout.connect(self.main_preview.update_mini_preview)

        self.main_preview.verticalScrollBar().valueChanged.connect(lambda *_: self._mini_preview_timer.start())
        self.main_preview.horizontalScrollBar().valueChanged.connect(lambda *_: self._mini_preview_timer.start())

        # Create a horizontal layout for the labels
        label_layout = QHBoxLayout()

        # Create the label to display the count of objects
        self.object_count_label = QLabel(self.tr("Objects Found: 0"))

        # Create the label with instructions
        self.instructions_label = QLabel(self.tr("Right Click a Row for More Options"))

        # Add both labels to the horizontal layout
        label_layout.addWidget(self.object_count_label)
        label_layout.addWidget(self.instructions_label)

        # Add the horizontal layout to the main panel layout
        right_panel.addLayout(label_layout)

        self.results_tree = QTreeWidget()
        self.results_tree.setHeaderLabels(["RA", "Dec", "Name", "Diameter", "Type", "Long Type", "Redshift (z)", "Parallax (mas)", "Distance", "Mag"])
        self.results_tree.setFixedHeight(150)
        self.results_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.results_tree.customContextMenuRequested.connect(self.open_context_menu)
        self.results_tree.itemClicked.connect(self.on_tree_item_clicked)
        self.results_tree.itemDoubleClicked.connect(self.on_tree_item_double_clicked)
        self.results_tree.currentItemChanged.connect(self.on_tree_current_item_changed)
        self.results_tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.results_tree.setSortingEnabled(True)
        right_panel.addWidget(self.results_tree)

        self.annotation_buttons = []

        # Annotation Tools Section (initially hidden)
        self.annotation_tools_section = QWidget()
        annotation_tools_layout = QGridLayout(self.annotation_tools_section)

        annotation_instruction_label = QLabel(self.tr("Ctrl+Click to add items, Alt+Click to measure distance"))
        annotation_instruction_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        annotation_instruction_label.setStyleSheet("font-size: 10px; color: gray;")        

        self.draw_ellipse_button = QPushButton(self.tr("Draw Ellipse"))
        self.draw_ellipse_button.tool_name = "Ellipse"
        self.draw_ellipse_button.clicked.connect(lambda: self.set_tool("Ellipse"))
        self.annotation_buttons.append(self.draw_ellipse_button)

        self.freehand_button = QPushButton(self.tr("Freehand (Lasso)"))
        self.freehand_button.tool_name = "Freehand"
        self.freehand_button.clicked.connect(lambda: self.set_tool("Freehand"))
        self.annotation_buttons.append(self.freehand_button)

        self.draw_rectangle_button = QPushButton(self.tr("Draw Rectangle"))
        self.draw_rectangle_button.tool_name = "Rectangle"
        self.draw_rectangle_button.clicked.connect(lambda: self.set_tool("Rectangle"))
        self.annotation_buttons.append(self.draw_rectangle_button)

        self.draw_arrow_button = QPushButton(self.tr("Draw Arrow"))
        self.draw_arrow_button.tool_name = "Arrow"
        self.draw_arrow_button.clicked.connect(lambda: self.set_tool("Arrow"))
        self.annotation_buttons.append(self.draw_arrow_button)

        self.place_compass_button = QPushButton(self.tr("Place Celestial Compass"))
        self.place_compass_button.tool_name = "Compass"
        self.place_compass_button.clicked.connect(lambda: self.set_tool("Compass"))
        self.annotation_buttons.append(self.place_compass_button)

        self.add_text_button = QPushButton(self.tr("Add Text"))
        self.add_text_button.tool_name = "Text"
        self.add_text_button.clicked.connect(lambda: self.set_tool("Text"))
        self.annotation_buttons.append(self.add_text_button)

        # Add Color and Font buttons
        self.color_button = QPushButton(self.tr("Select Color"))
        self.color_button.setIcon(QIcon(colorwheel_path))
        self.color_button.clicked.connect(self.select_color)

        self.font_button = QPushButton(self.tr("Select Font"))
        self.font_button.setIcon(QIcon(font_path))
        self.font_button.clicked.connect(self.select_font)

        # Undo button
        self.undo_button = QPushButton(self.tr("Undo"))
        self.undo_button.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_ArrowLeft))  # Left arrow icon for undo
        self.undo_button.clicked.connect(self.main_preview.undo_annotation)  # Connect to undo_annotation in CustomGraphicsView

        # Clear Annotations button
        self.clear_annotations_button = QPushButton(self.tr("Clear Annotations"))
        self.clear_annotations_button.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_TrashIcon))  # Trash icon
        self.clear_annotations_button.clicked.connect(self.main_preview.clear_annotations)  # Connect to clear_annotations in CustomGraphicsView

        # Delete Selected Object button
        self.delete_selected_object_button = QPushButton(self.tr("Delete Selected Items"))
        self.delete_selected_object_button.setIcon(QApplication.style().standardIcon(QStyle.StandardPixmap.SP_DialogCloseButton))  # Trash icon
        self.delete_selected_object_button.clicked.connect(self.main_preview.delete_selected_objects)

        # Add the instruction label to the top of the grid layout (row 0, spanning multiple columns)
        annotation_tools_layout.addWidget(annotation_instruction_label, 0, 0, 1, 4)  # Span 5 columns to center it

        # Shift all other widgets down by one row
        annotation_tools_layout.addWidget(self.draw_ellipse_button, 1, 0)
        annotation_tools_layout.addWidget(self.freehand_button, 1, 1)
        annotation_tools_layout.addWidget(self.draw_rectangle_button, 2, 0)
        annotation_tools_layout.addWidget(self.draw_arrow_button, 2, 1)
        annotation_tools_layout.addWidget(self.place_compass_button, 3, 0)
        annotation_tools_layout.addWidget(self.add_text_button, 3, 1)
        annotation_tools_layout.addWidget(self.color_button, 4, 0)
        annotation_tools_layout.addWidget(self.font_button, 4, 1)
        annotation_tools_layout.addWidget(self.undo_button, 1, 4)
        annotation_tools_layout.addWidget(self.clear_annotations_button, 2, 4)
        annotation_tools_layout.addWidget(self.delete_selected_object_button, 3, 4)

        self.annotation_tools_section.setVisible(False)  # Initially hidden
        right_panel.addWidget(self.annotation_tools_section)

        # Advanced Search Panel
        self.advanced_param_label = QLabel(self.tr("Advanced Search Parameters"))
        self.advanced_search_panel.addWidget(self.advanced_param_label)

        # TreeWidget for object types
        self.object_tree = QTreeWidget()
        self.object_tree.setHeaderLabels([self.tr("Object Type"), self.tr("Description")])
        self.object_tree.setColumnWidth(0, 150)
        self.object_tree.setSortingEnabled(True)

        # Populate the TreeWidget with object types from otype_long_name_lookup
        for obj_type, description in otype_long_name_lookup.items():
            item = QTreeWidgetItem([obj_type, description])
            item.setCheckState(0, Qt.CheckState.Checked)  # Start with all items unchecked
            self.object_tree.addTopLevelItem(item)

        self.advanced_search_panel.addWidget(self.object_tree)

        # Buttons for toggling selections
        toggle_buttons_layout = QHBoxLayout()

        # Toggle All
        self.toggle_all_button = QPushButton(self.tr("Toggle All"))
        self.toggle_all_button.clicked.connect(self.toggle_all_items)
        toggle_buttons_layout.addWidget(self.toggle_all_button)

        # Save Custom List
        self.save_list_button = QPushButton(self.tr("Save List…"))
        self.save_list_button.clicked.connect(self.save_custom_list)
        toggle_buttons_layout.addWidget(self.save_list_button)

        # Load Custom List
        self.load_list_button = QPushButton(self.tr("Load List…"))
        self.load_list_button.clicked.connect(self.load_custom_list)
        toggle_buttons_layout.addWidget(self.load_list_button)

        self.advanced_search_panel.addLayout(toggle_buttons_layout)   

        # Add Simbad Search buttons below the toggle buttons
        # Local-Gaia augment: when checked, query the astrometric library
        # for stars in the same region and append those without a Simbad
        # match within 10". Silently no-op if no astrometric bands are
        # installed. Persists across sessions.
        self.augment_with_gaia_checkbox = QCheckBox(
            self.tr("Augment search with local Gaia DR3"))
        self.augment_with_gaia_checkbox.setToolTip(
            "Adds Gaia DR3 sources from the local astrometric library that\n"
            "Simbad didn't return. Useful for faint fields where most stars\n"
            "aren't in Simbad. Requires an installed astrometric band (Settings\n"
            "→ Gaia DR3 Library → Astrometry)."
        )
        self.augment_with_gaia_checkbox.setChecked(
            self.settings.value("wimi/augment_with_gaia", False, type=bool))
        self.augment_with_gaia_checkbox.toggled.connect(
            lambda on: self.settings.setValue("wimi/augment_with_gaia", bool(on)))
        self.advanced_search_panel.addWidget(self.augment_with_gaia_checkbox)

        # ─────────────────────────────────────────────────────────────
        # Magnitude limit (post-search filter)
        #
        # Simbad / Vizier / MinorBodies / Gaia-augment all have their own
        # idea of which bands they return (V, B, G, H, g, k, ...), and
        # several catalogs return rows with no magnitude at all. Rather
        # than push a mag constraint into every per-source query (which
        # would mean threading it through five different code paths and
        # relying on each catalog honoring our constraint), we apply the
        # cut once, uniformly, right where results funnel into the tree
        # and marker layer. See _filter_results_by_magnitude.
        #
        # Default is OFF (no limit) so this is a strict opt-in and
        # existing user workflows don't change. When ON, any result
        # with no numeric magnitude in a known field is DROPPED — the
        # user asked for a magnitude limit, so "unknown mag" is treated
        # as "fails the test" rather than silently passing through.
        from PyQt6.QtWidgets import QCheckBox as _QCheckBox  # local alias; QCheckBox is already in scope
        mag_filter_row = QHBoxLayout()
        self.mag_limit_checkbox = QCheckBox(self.tr("Limit by magnitude"))
        self.mag_limit_checkbox.setToolTip(
            "When checked, drop any result fainter than the magnitude\n"
            "below from the tree, markers, and all downstream views.\n"
            "Any result with no magnitude in a known band (Vmag / Bmag /\n"
            "Gmag / mag / H / g / k) is also dropped — if you asked for\n"
            "a magnitude cut, 'unknown' fails it. Default: off."
        )
        self.mag_limit_checkbox.setChecked(
            self.settings.value("wimi/mag_filter_enabled", False, type=bool))
        self.mag_limit_spinbox = QDoubleSpinBox()
        self.mag_limit_spinbox.setDecimals(2)
        self.mag_limit_spinbox.setRange(-5.0, 30.0)       # Sun ≈ -26.7 is irrelevant;
                                                          # realistic apparent-mag range for
                                                          # cataloged non-solar objects
        self.mag_limit_spinbox.setSingleStep(0.5)
        self.mag_limit_spinbox.setValue(
            self.settings.value("wimi/mag_filter_limit", 18.0, type=float))
        self.mag_limit_spinbox.setSuffix(" mag")
        self.mag_limit_spinbox.setToolTip(
            "Drop results with magnitude > this value.\n"
            "Fainter stars have larger magnitudes."
        )
        self.mag_limit_spinbox.setEnabled(self.mag_limit_checkbox.isChecked())

        def _on_mag_filter_toggled(on: bool):
            self.settings.setValue("wimi/mag_filter_enabled", bool(on))
            self.mag_limit_spinbox.setEnabled(bool(on))
            # Re-filter in place so the user sees the change immediately
            # (no need to re-run the search).
            self._reapply_mag_filter_live()

        def _on_mag_filter_value_changed(v: float):
            self.settings.setValue("wimi/mag_filter_limit", float(v))
            if self.mag_limit_checkbox.isChecked():
                self._reapply_mag_filter_live()

        self.mag_limit_checkbox.toggled.connect(_on_mag_filter_toggled)
        self.mag_limit_spinbox.valueChanged.connect(_on_mag_filter_value_changed)

        mag_filter_row.addWidget(self.mag_limit_checkbox)
        mag_filter_row.addWidget(self.mag_limit_spinbox, 1)
        self.advanced_search_panel.addLayout(mag_filter_row)

        search_button_layout = QHBoxLayout()

        self.simbad_defined_region_button = QPushButton(self.tr("Search Defined Region"))
        self.simbad_defined_region_button.clicked.connect(self.search_defined_region)
        search_button_layout.addWidget(self.simbad_defined_region_button)

        self.simbad_entire_image_button = QPushButton(self.tr("Search Entire Image"))
        self.simbad_entire_image_button.clicked.connect(self.search_entire_image)
        search_button_layout.addWidget(self.simbad_entire_image_button)

        self.advanced_search_panel.addLayout(search_button_layout)

        # ─────────────────────────────
        # Minor Planets / Comets block
        # ─────────────────────────────
        self.minor_group = QGroupBox(self.tr("Minor Planets / Comets"))
        minor_layout = QGridLayout(self.minor_group)

        # --- DB info + buttons ---
        self.minor_db_label = QLabel(self.tr("Database: not downloaded"))
        self.minor_db_label.setStyleSheet("font-size: 10px; color: gray;")

        # Main action: automatic download. The little arrow opens a menu with
        # a manual-install path for users hit by macOS SSL cert errors, etc.
        self.btn_minor_download = QToolButton()
        self.btn_minor_download.setText(self.tr("Download Catalog"))
        self.btn_minor_download.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        self.btn_minor_download.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self.btn_minor_download.clicked.connect(self.download_minor_body_catalog)

        _dl_menu = QMenu(self.btn_minor_download)
        _dl_menu.addAction(
            self.tr("Force Re-download…"),
            lambda: self.download_minor_body_catalog(force=True),
        )
        _dl_menu.addSeparator()
        _dl_menu.addAction(
            self.tr("Install from Local File…"),
            self.install_minor_body_catalog_from_file,
        )
        _dl_menu.addAction(
            self.tr("Open Download Page in Browser…"),
            self.open_minor_body_download_page,
        )
        self.btn_minor_download.setMenu(_dl_menu)
        self.btn_minor_download.setToolTip(self.tr(
            "Download the minor-body catalog.\n"
            "Use the ▾ arrow if the automatic download fails "
            "(e.g. macOS SSL certificate errors)."
        ))

        self.btn_minor_search = QPushButton(self.tr("Search Minor Bodies"))
        self.btn_minor_search.clicked.connect(self.perform_minor_body_search)

        # Row 0: status label across full width
        minor_layout.addWidget(self.minor_db_label, 0, 0, 1, 4)

        # Row 1: download + search buttons
        minor_layout.addWidget(self.btn_minor_download, 1, 0, 1, 2)
        minor_layout.addWidget(self.btn_minor_search,   1, 2, 1, 2)

        # --- Search scope (Defined Circle vs Entire Image) ---
        scope_label = QLabel(self.tr("Search scope:"))
        self.minor_scope_combo = QComboBox()
        self.minor_scope_combo.addItems([
            self.tr("Defined Region"),
            self.tr("Entire Image"),
        ])

        minor_layout.addWidget(scope_label,          2, 0)
        minor_layout.addWidget(self.minor_scope_combo, 2, 1, 1, 3)

        # --- Limits row 1: asteroid H_max + max count ---
        ast_H_label = QLabel(self.tr("Asteroid H \u2264"))
        self.minor_ast_H_spin = QDoubleSpinBox()
        self.minor_ast_H_spin.setRange(0.0, 40.0)
        self.minor_ast_H_spin.setDecimals(1)
        self.minor_ast_H_spin.setSingleStep(0.5)
        self.minor_ast_H_spin.setValue(
            float(self.settings.value("wimi/minor/asteroid_H_max", 20.0))
        )

        ast_max_label = QLabel(self.tr("Max asteroids:"))
        self.minor_ast_max_spin = QSpinBox()
        self.minor_ast_max_spin.setRange(100, 2000000)
        self.minor_ast_max_spin.setSingleStep(1000)
        self.minor_ast_max_spin.setValue(
            int(self.settings.value("wimi/minor/asteroid_max", 20000))
        )

        minor_layout.addWidget(ast_H_label,          3, 0)
        minor_layout.addWidget(self.minor_ast_H_spin, 3, 1)
        minor_layout.addWidget(ast_max_label,        3, 2)
        minor_layout.addWidget(self.minor_ast_max_spin, 3, 3)

        # --- Limits row 2: comet H_max + max count ---
        com_H_label = QLabel(self.tr("Comet H \u2264"))
        self.minor_com_H_spin = QDoubleSpinBox()
        self.minor_com_H_spin.setRange(0.0, 40.0)
        self.minor_com_H_spin.setDecimals(1)
        self.minor_com_H_spin.setSingleStep(0.5)
        self.minor_com_H_spin.setValue(
            float(self.settings.value("wimi/minor/comet_H_max", 15.0))
        )

        com_max_label = QLabel(self.tr("Max comets:"))
        self.minor_com_max_spin = QSpinBox()
        self.minor_com_max_spin.setRange(100, 100000)
        self.minor_com_max_spin.setSingleStep(500)
        self.minor_com_max_spin.setValue(
            int(self.settings.value("wimi/minor/comet_max", 5000))
        )

        minor_layout.addWidget(com_H_label,          4, 0)
        minor_layout.addWidget(self.minor_com_H_spin, 4, 1)
        minor_layout.addWidget(com_max_label,        4, 2)
        minor_layout.addWidget(self.minor_com_max_spin, 4, 3)

        # --- Optional specific target (designation / name) ---
        target_label = QLabel(self.tr("Target (optional):"))
        self.minor_target_edit = QLineEdit()
        self.minor_target_edit.setPlaceholderText("e.g. 584, Semiramis, C/2023 A3...")

        minor_layout.addWidget(target_label,          5, 0)
        minor_layout.addWidget(self.minor_target_edit, 5, 1, 1, 3)

        self.minor_count_button = QPushButton(self.tr("Count Objects Brighter Than Limits"))
        self.minor_count_button.setToolTip(
            "Show how many catalog objects are brighter than the selected H limits."
        )
        self.minor_count_button.clicked.connect(self.count_minor_bodies_brighter_than_limits)
        # Put it on its own row spanning all 4 columns
        minor_layout.addWidget(self.minor_count_button, 6, 0, 1, 4)

        # --- Time offset (hours) for ephemerides ---
        time_offset_label = QLabel(self.tr("Time offset (hours):"))
        self.minor_time_offset_spin = QDoubleSpinBox()
        self.minor_time_offset_spin.setRange(-24.0, 24.0)
        self.minor_time_offset_spin.setDecimals(2)
        self.minor_time_offset_spin.setSingleStep(0.25)
        self.minor_time_offset_spin.setValue(
            float(self.settings.value("wimi/minor/time_offset_hours", 0.0))
        )
        self.minor_time_offset_spin.setToolTip(
            "Applied to observation time before computing minor-body ephemerides.\n"
            "Negative = earlier, positive = later."
        )

        minor_layout.addWidget(time_offset_label,          7, 0)
        minor_layout.addWidget(self.minor_time_offset_spin, 7, 1)
        # (optional) span the spin box wider:
        # minor_layout.addWidget(self.minor_time_offset_spin, 7, 1, 1, 3)
        self.advanced_search_panel.addWidget(self.minor_group)


        # Try to pick up an already-downloaded DB on startup
        self._load_minor_db_path()

        # Adding the "Deep Vizier Search" button below the other search buttons
        self.deep_vizier_button = QPushButton(self.tr("Caution - Deep Vizier Search"))
        self.deep_vizier_button.setIcon(QIcon(nuke_path))  # Assuming `nuke_path` is the correct path for the icon
        self.deep_vizier_button.setToolTip("Perform a deep search with Vizier. Caution: May return large datasets.")

        # Connect the button to a placeholder method for the deep Vizier search
        self.deep_vizier_button.clicked.connect(self.perform_deep_vizier_search)

        # Add the Deep Vizier button to the advanced search layout
        self.advanced_search_panel.addWidget(self.deep_vizier_button)

        self.mast_search_button = QPushButton(self.tr("Search M.A.S.T Database"))
        self.mast_search_button.setIcon(QIcon(hubble_path))
        self.mast_search_button.clicked.connect(self.perform_mast_search)
        self.mast_search_button.setToolTip("Search Hubble, JWST, Spitzer, TESS and More.")
        self.advanced_search_panel.addWidget(self.mast_search_button)                        

        # Combine left and right panels
        main_layout.addLayout(left_panel)
        main_layout.addLayout(right_panel)
        main_layout.addWidget(self.advanced_search_panel_widget)
        
        delete_shortcut = QShortcut(QKeySequence.StandardKey.Delete, self.results_tree)
        delete_shortcut.activated.connect(self.main_preview.delete_selected_objects)

        self.setLayout(main_layout)
        self._restore_ui_state()

        self.image_path = None
        self.zoom_level = 1.0
        self.main_image = None
        self.green_box = None
        self.dragging = False
        self.center_ra = None
        self.center_dec = None
        self.pixscale = None
        self.orientation = None
        self.parity = None  
        self.circle_center = None
        self.circle_radius = 0  
        self.results = []
        self._selected_name = None
        self.wcs = None  # Initialize WCS to None
        # Initialize selected color and font with default values
        self.selected_color = QColor(Qt.GlobalColor.red)  # Default annotation color
        self.selected_font = QFont("Arial", 12)  # Default font for text annotations

        # "Show Object Names" label styling — font + colour, independent of
        # the annotation-tools font (which only affects added text). Drawn
        # screen-constant, so the point size is the on-screen size at any
        # zoom. Persisted in QSettings.
        self.name_label_font, self.name_label_color = self._load_name_label_style()

        self.populate_object_tree()

        self._green_box_timer = QTimer(self)
        self._green_box_timer.setSingleShot(True)
        self._green_box_timer.setInterval(50)  # green box can be a bit faster
        self._green_box_timer.timeout.connect(self.update_green_box)

        # Minor-planet bits
        # Minor-body initial state
        self.minor_db_path = self.settings.value(
            "wimi/minorbody_db_path", "", type=str
        )
        self._load_minor_db_path()
        if self.minor_db_path:
            p = Path(self.minor_db_path)
            if p.is_file():
                # Try to read local manifest for nicer label
                try:
                    data_dir = p.parent
                    manifest_path = data_dir / mbc.DEFAULT_MANIFEST_BASENAME
                    manifest = mbc.load_local_manifest(manifest_path)
                    if manifest is not None:
                        ast = f"{manifest.counts_asteroids:,}"
                        com = f"{manifest.counts_comets:,}"
                        self.minor_db_label.setText(
                            f"Database: v{manifest.version} — {ast} asteroids, {com} comets"
                        )
                    else:
                        self.minor_db_label.setText(f"Database: {p.name}")
                except Exception:
                    self.minor_db_label.setText(f"Database: {p.name}")
            else:
                self.minor_db_label.setText("Database: not downloaded")
        else:
            self.minor_db_label.setText("Database: not downloaded")      
        #self._legend_dock = QDockWidget("Object Type Legend", self)
        legend = LegendDialog(self)
        legend.setModal(False)
    
    ATLAS_CATALOG_URL = "https://f005.backblazeb2.com/file/setiastro-atlas/catalog.json"

    def _fetch_atlas_catalog(self):
        if self._atlas_thread is not None and self._atlas_thread.isRunning():
            return
        self._atlas_thread = AtlasCatalogThread(parent=self)
        self._atlas_thread.finished.connect(self._on_wimi_atlas_ready)
        self._atlas_thread.start()


    def _on_wimi_atlas_ready(self, entries):
        self._atlas_entries = entries
        self._check_atlas_overlap()

    def _check_atlas_overlap(self):
        if not self._atlas_entries or self.wcs is None:
            self._atlas_banner.setVisible(False)
            return

        ra  = getattr(self, "center_ra",  None)
        dec = getattr(self, "center_dec", None)
        if ra is None or dec is None:
            self._atlas_banner.setVisible(False)
            return

        hits = [e for e in self._atlas_entries if _ra_in_atlas(ra, dec, [e])]

        count = len(hits)
        if count == 0:
            self._atlas_banner.setVisible(False)
        else:
            plural = "images" if count != 1 else "image"
            self._atlas_banner_label.setText(
                f"🌌 {count} community {plural} overlap this field"
            )
            self._atlas_banner.setVisible(True)

    def _open_atlas_at_center(self):
        import webbrowser
        ra  = getattr(self, "center_ra",  None)
        dec = getattr(self, "center_dec", None)
        if ra is not None and dec is not None:
            webbrowser.open(
                f"https://f005.backblazeb2.com/file/setiastro-atlas/atlas.html"
                f"?ra={ra:.5f}&dec={dec:.5f}"
            )
        else:
            webbrowser.open(
                "https://f005.backblazeb2.com/file/setiastro-atlas/atlas.html"
            )

    def _cycle_crosshair(self):
        self._crosshair_mode = (self._crosshair_mode + 1) % 4

        if self._crosshair_overlay is None:
            self._crosshair_overlay = _CrosshairOverlay(self.main_preview.viewport())
            self._crosshair_overlay.setGeometry(self.main_preview.viewport().rect())
            self._crosshair_overlay.show()
            # Install event filter on viewport to track resize/scroll
            self.main_preview.viewport().installEventFilter(self)

        self._crosshair_overlay.set_mode(self._crosshair_mode)
        self.crosshair_button.setChecked(self._crosshair_mode != 0)
        labels = ["Crosshair: Off", "Crosshair: Thin", "Crosshair: Outlined", "Crosshair: Gap"]
        self.crosshair_button.setToolTip(labels[self._crosshair_mode])

    def eventFilter(self, obj, event):
        if obj is self.main_preview.viewport():
            if event.type() in (
                QEvent.Type.Resize,
                QEvent.Type.Paint,
                QEvent.Type.Move,
            ):
                if self._crosshair_overlay is not None:
                    self._crosshair_overlay.setGeometry(self.main_preview.viewport().rect())
                    self._crosshair_overlay.raise_()
        return super().eventFilter(obj, event)

    def _resize_crosshair_overlay(self):
        """Keep the crosshair overlay sized to the viewport."""
        if self._crosshair_overlay is not None:
            self._crosshair_overlay.setGeometry(self.main_preview.viewport().rect())

    def count_minor_bodies_brighter_than_limits(self):
        """
        Count how many catalog objects are brighter than the current H limits
        (for asteroids and comets), and show the result to the user.

        This is a *global* catalog count, not limited to your image FOV.
        """
        import sqlite3
        from pathlib import Path

        # Ensure DB exists / is configured
        try:
            db_path = self._ensure_minor_planet_db()
        except Exception as e:
            QMessageBox.critical(
                self,
                "Minor-Body Catalog",
                f"Could not access the minor-body database:\n{e}",
            )
            return

        if not db_path:
            QMessageBox.warning(
                self,
                "Minor-Body Catalog",
                "Minor-body database is not available. Please download it first.",
            )
            return

        db_path = Path(db_path)
        if not db_path.is_file():
            QMessageBox.warning(
                self,
                "Minor-Body Catalog",
                f"Minor-body database file not found:\n{db_path}",
            )
            return

        # Read current limits from the UI
        try:
            H_ast = float(self.minor_ast_H_spin.value())
        except Exception:
            H_ast = 20.0
        try:
            H_com = float(self.minor_com_H_spin.value())
        except Exception:
            H_com = 15.0

        ast_count = 0
        com_count = 0

        con = None
        try:
            con = sqlite3.connect(str(db_path))
            cur = con.cursor()

            # ----- Asteroids: use magnitude_H (indexed in the builder) -----
            try:
                cur.execute(
                    "SELECT COUNT(*) FROM asteroids WHERE magnitude_H <= ?",
                    (H_ast,),
                )
                row = cur.fetchone()
                if row and row[0] is not None:
                    ast_count = int(row[0])
            except Exception as e:
                print(f"[MinorBodies] COUNT asteroids failed: {e!r}")

            # ----- Comets: detect magnitude column (g/k/H-style) -----
            try:
                cur.execute("PRAGMA table_info(comets)")
                cols = {r[1] for r in cur.fetchall()}
                mag_col = None
                # Prefer g, then k, then any H-style absolute mag
                for candidate in ("magnitude_g", "magnitude_k",
                                  "absolute_magnitude", "magnitude_H", "H"):
                    if candidate in cols:
                        mag_col = candidate
                        break

                if mag_col is not None:
                    sql = f"SELECT COUNT(*) FROM comets WHERE {mag_col} <= ?"
                    cur.execute(sql, (H_com,))
                    row = cur.fetchone()
                    if row and row[0] is not None:
                        com_count = int(row[0])
                else:
                    print("[MinorBodies] comets table has no usable magnitude column; comet count set to 0")
            except Exception as e:
                print(f"[MinorBodies] COUNT comets failed: {e!r}")

        finally:
            try:
                if con is not None:
                    con.close()
            except Exception:
                pass

        # Build message
        msg_lines = [
            f"Asteroids with H ≤ {H_ast:.1f}: {ast_count:,}",
            f"Comets with H ≤ {H_com:.1f}: {com_count:,}",
            "",
            "Note: This counts objects in the entire catalog,",
            "not just those in your current image field of view.",
        ]
        msg = "\n".join(msg_lines)

        QMessageBox.information(
            self,
            "Minor-Body Catalog Counts",
            msg,
        )

        # Optionally also reflect this in the status bar
        self.status_label.setText(
            f"Minor bodies brighter than limits — Asteroids: {ast_count:,}, "
            f"Comets: {com_count:,}"
        )


    def toggle_object_names(self, state=None):
        self.show_names = self.show_names_checkbox.isChecked() if state is None else bool(state)
        self._ensure_marker_layer()
        if self._marker_layer:
            self._marker_layer.setCacheMode(QGraphicsItem.CacheMode.NoCache)
            self._marker_layer.update(self._marker_layer.boundingRect())
            self.main_scene.invalidate(self.main_scene.sceneRect(), QGraphicsScene.SceneLayer.AllLayers)
            self._marker_layer.setCacheMode(QGraphicsItem.CacheMode.DeviceCoordinateCache)

    def toggle_active_object_name(self, state=None):
        self.show_active_name = (
            self.show_active_name_checkbox.isChecked() if state is None else bool(state)
        )
        self._ensure_marker_layer()
        if self._marker_layer:
            self._marker_layer.setCacheMode(QGraphicsItem.CacheMode.NoCache)
            self._marker_layer.update(self._marker_layer.boundingRect())
            self.main_scene.invalidate(self.main_scene.sceneRect(), QGraphicsScene.SceneLayer.AllLayers)
            self._marker_layer.setCacheMode(QGraphicsItem.CacheMode.DeviceCoordinateCache)

    def _set_selected_name(self, name: Optional[str]):
        self._selected_name = name
        if self._marker_layer:
            self._marker_layer.update()

    def _ensure_marker_layer(self):
        # need a scene and a pixmap
        if getattr(self, "main_scene", None) is None or self.main_image is None:
            return

        w = int(self.main_image.width())
        h = int(self.main_image.height())

        # drop dead/dangling layers
        if getattr(self, "_marker_layer", None) is not None and not _qt_is_alive(self._marker_layer):
            self._marker_layer = None

        if getattr(self, "_marker_layer", None) is None:
            self._marker_layer = MarkerLayer(
                image_w=w, image_h=h,
                show_names_fn=lambda: self.show_names,
                color_fn=lambda: self.selected_color,
                style_fn=lambda: self.marker_style,
                selected_name_fn=lambda: self._selected_name,
                show_active_name_fn=lambda: self.show_active_name,
                name_font_fn=lambda: self.name_label_font,
                name_color_fn=lambda: self.name_label_color,
            )
            self.main_scene.addItem(self._marker_layer)
        else:
            self._marker_layer.resize(w, h)

    def _get_selected_name(self):
        return self._selected_name

    def _set_marker_points_from_results(self):
        self._ensure_marker_layer()
        if not _qt_is_alive(self._marker_layer):
            return
        pts = []
        for obj in getattr(self, "results", []):
            ra, dec = obj.get("ra"), obj.get("dec")
            xy = self.calculate_pixel_from_ra_dec(ra, dec)
            if not xy: continue
            x, y = xy
            if x is None or y is None: continue

            # Compute angular size radius in pixels if available
            radius_px = None
            ellipse = None  # (semi_major_px, semi_minor_px, angle_deg) in scene space, if orientable
            diam = obj.get("diameter")
            if diam not in (None, "N/A", "", "--"):
                try:
                    diam_arcmin = float(diam)  # galdim_majaxis is in arcmin
                    if diam_arcmin > 0 and self.pixscale and self.pixscale > 0:
                        diam_arcsec = diam_arcmin * 60.0
                        radius_px = (diam_arcsec / self.pixscale) / 2.0

                        # Upgrade the circle to a true oriented ellipse when the catalog
                        # gave a minor axis + position angle. PA is a SKY angle (deg,
                        # North->East); map it into image space with a WCS round-trip so
                        # rotation / flip / parity are handled automatically. (An ellipse
                        # is 180-deg symmetric, so the East sign convention is irrelevant.)
                        minor = obj.get("minor_arcmin")
                        pa    = obj.get("pa_deg")
                        if (minor not in (None, "N/A", "", "--")
                                and pa not in (None, "N/A", "", "--")):
                            minor_val = float(minor)
                            pa_val    = float(pa)
                            if minor_val > 0 and minor_val <= diam_arcmin:
                                a_arcsec = diam_arcsec / 2.0
                                dd = (a_arcsec / 3600.0) * math.cos(math.radians(pa_val))
                                dr = ((a_arcsec / 3600.0) * math.sin(math.radians(pa_val))
                                      / max(1e-6, math.cos(math.radians(float(dec)))))
                                tip = self.calculate_pixel_from_ra_dec(float(ra) + dr,
                                                                       float(dec) + dd)
                                if tip and tip[0] is not None and tip[1] is not None:
                                    ang_deg = math.degrees(math.atan2(tip[1] - y, tip[0] - x))
                                    b_px = radius_px * (minor_val / diam_arcmin)
                                    ellipse = (radius_px, b_px, ang_deg)
                except (ValueError, TypeError):
                    radius_px = None
                    ellipse = None

            pts.append({
                "x": float(x), "y": float(y),
                "name": obj.get("name"),
                "color": obj.get("color", QColor(255, 255, 255)),
                "radius_px": radius_px,  # None = use fixed screen size
                "ellipse": ellipse,
            })
        try:
            self._marker_layer.set_points(pts)
        except RuntimeError:
            self._marker_layer = None
            self._ensure_marker_layer()
            if _qt_is_alive(self._marker_layer):
                self._marker_layer.set_points(pts)

    # ---- drop-in replacements (proxies) that your existing code already calls ----
    def _filter_results_to_image(self, results):
        """Drop objects whose pixel position falls outside the loaded image.

        A cone/radius search can return objects that are inside the search
        radius but outside the actual image frame (the circle spills past the
        edges). Those should never populate the tree, markers, collage, etc.
        Requires WCS; if WCS is unavailable we can't test bounds, so we keep
        everything.
        """
        if getattr(self, "wcs", None) is None or self.main_image is None:
            return list(results)
        w = int(self.main_image.width())
        h = int(self.main_image.height())
        kept = []
        for obj in results:
            x, y = self.calculate_pixel_from_ra_dec(obj.get("ra"), obj.get("dec"))
            on_frame = (x is not None and y is not None
                        and 0 <= x < w and 0 <= y < h)
            # Minor bodies are different from a catalog dump: the cone search
            # already narrowed to a handful, each one is individually
            # meaningful, and the object you are hunting often sits just past
            # the sensor edge on the particular frame you loaded (it drifts
            # into frame on another sub). Never silently drop those — keep
            # every minor body that projected to a finite pixel and just flag
            # whether it actually lands on the sensor. Non-minor results keep
            # the strict on-frame-only behaviour.
            if obj.get("_minor_body"):
                if x is None or y is None:
                    continue  # ephemeris failed (NaN) — nothing to show
                obj["_on_frame"] = bool(on_frame)
                kept.append(obj)
                continue
            if x is None or y is None:
                continue  # couldn't project onto the image
            if on_frame:
                kept.append(obj)
        return kept

    @staticmethod
    def _extract_mag_from_result(obj) -> float | None:
        """
        Return the first usable apparent magnitude from an object dict, or None.

        Different sources write different keys:
          - Simbad       -> Vmag (preferred), Bmag
          - MinorBodies  -> mag (comet g/k or asteroid H, pre-decided per source)
          - Gaia augment -> Gmag or gaia_gmag
          - Deep Vizier  -> may use lowercase 'g' / 'r' / 'i' / 'B' / 'V'
            depending on the catalog
          - mag_display  -> a formatted string ('17.42') that any source may
            fill when it had a value; parse as a last resort

        We check keys in rough preference order (V -> B -> G -> generic),
        skip values that aren't finite floats, and return the first hit.
        A pure numeric string ('17.42') or a formatted mag_display ('17.42')
        is also accepted. None means "no usable magnitude in any known field".
        """
        if not isinstance(obj, dict):
            return None
        # Preference order: V band (reddest common), B, G, generic 'mag',
        # minor-body H, SDSS g/r/i. Fall back to the formatted display cell
        # which several code paths populate even when the raw keys aren't.
        keys_in_order = (
            "Vmag", "V", "vmag",
            "Bmag", "B", "bmag",
            "Gmag", "gaia_gmag", "G",
            "mag", "magnitude",
            "H", "magnitude_H",
            "g", "r", "i",
            "mag_display",
        )
        for k in keys_in_order:
            if k not in obj:
                continue
            v = obj[k]
            if v is None:
                continue
            # Catalogs frequently sentinel-fill with "N/A" / "" / NaN
            if isinstance(v, str):
                s = v.strip()
                if not s or s.upper() in ("N/A", "NA", "NONE", "UNKNOWN", "-"):
                    continue
                try:
                    f = float(s)
                except ValueError:
                    continue
            else:
                try:
                    f = float(v)
                except (TypeError, ValueError):
                    continue
            if not math.isfinite(f):
                continue
            # 0.000 exactly is almost always a sentinel for "missing" in
            # Simbad V/B columns (a real V=0 star is a once-in-the-sky
            # object). Skip it like Simbad's own tooling does. If we're
            # looking at the formatted display cell, 0.000 means a true
            # bright object that was written with a leading zero — but
            # the display cell is last-resort so even then skipping is
            # the safer bet.
            if f == 0.0:
                continue
            return f
        return None

    def _filter_results_by_magnitude(self, results):
        """
        Apply the user's magnitude limit to a result list.

        When the "Limit by magnitude" checkbox is off, this is a no-op.
        When on, drops any result whose extracted apparent magnitude is
        either (a) missing / unparseable in every known band, or (b)
        fainter (numerically larger) than the spinbox threshold.

        See `_extract_mag_from_result` for the band-preference logic.
        Called from `_cg_set_query_results_proxy` and from
        `_reapply_mag_filter_live` (which re-filters the last unfiltered
        snapshot in response to UI changes).
        """
        try:
            if not bool(self.mag_limit_checkbox.isChecked()):
                return list(results)
            limit = float(self.mag_limit_spinbox.value())
        except Exception:
            # UI not yet constructed / torn down — fail open rather than
            # silently drop every result from an edge-case code path.
            return list(results)
        kept = []
        for obj in results:
            m = self._extract_mag_from_result(obj)
            if m is None:
                continue
            if m <= limit:
                kept.append(obj)
        return kept

    def _reapply_mag_filter_live(self):
        """
        Re-filter the most recent unfiltered result set in-place in response
        to the user toggling the checkbox or changing the limit. Avoids
        re-querying every catalog just to narrow the result list.

        Replays everything downstream of the fetch:
          - rebuild self.results from the stashed unfiltered snapshot,
            re-applying BOTH the image-bounds filter AND the magnitude cut
          - re-tag categories/colors (same as _cg_set_query_results_proxy)
          - refresh the markers, the tree widget, and the object counter

        No-ops silently if nothing has been searched yet.
        """
        src = getattr(self, "_results_unfiltered", None)
        if not src:
            return
        try:
            results = self._filter_results_to_image(src)
            results = self._filter_results_by_magnitude(results)
            for obj in results:
                short_type = obj.get("short_type", "")
                category = OTYPE_TO_CATEGORY.get(short_type, "Errors & Artefacts")
                obj["category"] = category
                obj["color"] = CATEGORY_TO_COLOR.get(category, QColor(255, 255, 255))
            self.results = results
            self._ensure_marker_layer()
            self._set_marker_points_from_results()
            # Keep the sidebar tree and the object counter in sync too.
            try:
                self.update_results_tree()
            except Exception:
                pass
            try:
                self.update_object_count()
            except Exception:
                pass
            QTimer.singleShot(0, self.update_green_box)
        except Exception as e:
            # Live re-filter failures must never corrupt state — leave the
            # existing self.results in place and surface the error.
            print(f"[WIMI] magnitude re-filter failed: {e}")

    def _cg_set_query_results_proxy(self, results):
        # Keep an UNFILTERED snapshot so toggling the magnitude limit (or
        # changing its value) can re-filter without re-running the search.
        # list() makes a shallow copy — results are dicts so the per-object
        # content is still shared, which is fine for a read-only replay.
        self._results_unfiltered = list(results)
        # Remove anything not actually inside the image frame before it
        # populates the tree / markers / any consumer of self.results.
        results = self._filter_results_to_image(results)
        # Apply the user's magnitude cut (no-op when the checkbox is off).
        # Order matters: image-bounds first (cheap WCS projection), magnitude
        # second (only pays the dict walk for objects we would keep anyway).
        results = self._filter_results_by_magnitude(results)
        for obj in results:
            short_type = obj.get("short_type", "")
            category = OTYPE_TO_CATEGORY.get(short_type, "Errors & Artefacts")
            obj["category"] = category
            obj["color"] = CATEGORY_TO_COLOR.get(category, QColor(255, 255, 255))
        self.results = results

        self._ensure_marker_layer()
        self._set_marker_points_from_results()
        QTimer.singleShot(0, self.update_green_box)

    def _cg_draw_query_results_proxy(self):
        self._ensure_marker_layer()
        self._set_marker_points_from_results()
        if self._marker_layer:
            self._marker_layer.update()
        QTimer.singleShot(0, self.update_green_box)

    def _cg_clear_query_results_proxy(self):
        self.results = []
        if self._marker_layer:
            self._marker_layer.set_points([])
        QTimer.singleShot(0, self.update_green_box)

    def _doc_for_solver(self):
        # Prefer the real pro document if we loaded from a view
        if getattr(self, "_loaded_doc", None) is not None:
            return self._loaded_doc

        # Otherwise build an adapter around the image currently in WIMI
        if getattr(self, "image_data", None) is None:
            return None

        meta = {}
        # pack whatever we already know so ASTAP can seed if possible
        if getattr(self, "original_header", None):
            meta["original_header"] = self.original_header
        if getattr(self, "wcs", None) is not None:
            try:
                meta["wcs_header"] = self.wcs.to_header(relax=True)
            except Exception:
                pass
        return _WIMIAdapterDoc(self.image_data, meta)


    def show_legend(self):
        # keep a persistent reference so it doesn't get garbage-collected
        if not hasattr(self, "_legend_dialog"):
            self._legend_dialog = LegendDialog(self)
            self._legend_dialog.setModal(False)
        self._legend_dialog.show()
        self._legend_dialog.raise_()
        self._legend_dialog.activateWindow()

    def _refresh_views_menu(self):
        self.load_from_view_menu.clear()
        docs = []
        try:
            if self._doc_manager is not None:
                docs = list(self._doc_manager.all_documents())
        except Exception:
            docs = []

        if not docs:
            a = self.load_from_view_menu.addAction("No open views")
            a.setEnabled(False)
            return

        # most-recent last → show newest at bottom (or reverse if you prefer)
        for doc in docs:
            title = getattr(doc, "display_name", lambda: "Untitled")()
            act = self.load_from_view_menu.addAction(title)
            act.triggered.connect(lambda _, d=doc: self._load_from_view(d))

    def _ensure_wcs_on_doc(self, doc) -> bool:
        """
        Return True if WCS already present or successfully solved and written back to doc.metadata.
        Uses the shared plate solver (ASTAP first, then Astrometry.net) and shows status in the UI.
        If the document has no usable seed header, temporarily forces a blind solve for this run.
        """
        meta = getattr(doc, "metadata", {}) or {}
        # already solved?
        if self.check_astrometry_data(meta.get("original_header")) or \
        self.check_astrometry_data(meta.get("wcs_header")):
            return True

        # decide whether to force blind for this one run (no seed header)
        seed_hdr = _as_header(meta.get("original_header") or meta.get("wcs_header"))
        force_blind = (seed_hdr is None)

        mw = _find_main_window(self) or self.parent()
        settings = getattr(mw, "settings", QSettings())

        # status hint
        try:
            if hasattr(self, "status_label"):
                self.status_label.setText("Status: Solving (ASTAP)…")
                QApplication.processEvents()
        except Exception:
            pass

        prev_mode = _get_seed_mode(settings)
        try:
            if force_blind and prev_mode != "none":
                _set_seed_mode(settings, "none")  # blind just for this solve
            ok, _ = plate_solve_doc_inplace(mw, doc, settings)
        finally:
            # restore user preference
            if force_blind and prev_mode != "none":
                _set_seed_mode(settings, prev_mode)

        if ok:
            # double-check we now have WCS on the doc
            meta = getattr(doc, "metadata", {}) or {}
            got = self.check_astrometry_data(meta.get("original_header")) or \
                self.check_astrometry_data(meta.get("wcs_header"))
            try:
                if hasattr(self, "status_label"):
                    self.status_label.setText("Status: Solve complete.")
            except Exception:
                pass
            return bool(got)

        # unified solver already tried ASTAP and Astrometry.net; just report failure
        try:
            QMessageBox.critical(self, "Solve Failed",
                                "Automatic plate solve failed (ASTAP → Astrometry.net).")
            if hasattr(self, "status_label"):
                self.status_label.setText("Status: Solve failed.")
        except Exception:
            pass
        return False

    def populate_object_tree(self):
        self.object_tree.blockSignals(True)
        self.object_tree.clear()

        # 1) Build reverse map: category → list of short codes
        cat_to_types = defaultdict(list)

        # Pre-sort patterns so more specific (longer) come first
        patterns = list(OTYPE_TO_CATEGORY.items())
        patterns.sort(key=lambda x: len(x[0]), reverse=True)

        for code, longname in otype_long_name_lookup.items():
            # first try exact
            cat = OTYPE_TO_CATEGORY.get(code)
            if cat is None:
                # then try wildcard patterns (but skip the lone "*" pattern)
                for pat, candidate_cat in patterns:
                    if any(c in pat for c in "*?") and pat != "*" and fnmatch.fnmatch(code, pat):
                        cat = candidate_cat
                        break
            if cat is None:
                cat = "Errors & Artefacts"
            cat_to_types[cat].append(code)

        # 2) Populate tree
        for category, codes in cat_to_types.items():
            color  = CATEGORY_TO_COLOR.get(category, QColor(200,200,200))
            parent = QTreeWidgetItem(self.object_tree, [category, ""])
            parent.setFlags(parent.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            parent.setCheckState(0, Qt.CheckState.Checked)
            parent.setForeground(0, QBrush(color))
            parent.setFirstColumnSpanned(True)

            for code in sorted(codes):
                desc  = otype_long_name_lookup[code]
                child = QTreeWidgetItem(parent, [code, desc])
                child.setFlags(child.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                child.setCheckState(0, Qt.CheckState.Checked)
                pix = QPixmap(12,12)
                pix.fill(color)
                child.setIcon(0, QIcon(pix))

        self.object_tree.blockSignals(False)

        # wire up a very simple parent→children handler (no partial logic)
        try:
            self.object_tree.itemChanged.disconnect(self.on_object_tree_item_changed)
        except TypeError:
            pass
        self.object_tree.itemChanged.connect(self.on_object_tree_item_changed)


    def get_selected_object_types(self) -> list:
        """
        Return all the otype codes (children) whose checkboxes are checked.
        """
        checked = []
        root = self.object_tree.invisibleRootItem()
        # iterate over each category
        for i in range(root.childCount()):
            category_item = root.child(i)
            # iterate over that category's children
            for j in range(category_item.childCount()):
                child = category_item.child(j)
                if child.checkState(0) == Qt.CheckState.Checked:
                    checked.append(child.text(0))
        return checked


    def update_object_count(self):
        count = self.results_tree.topLevelItemCount()
        self.object_count_label.setText(f"Objects Found: {count}")

    def open_context_menu(self, position):
        from setiastro.saspro.gaia_database import get_library
        import math
        
        item = self.results_tree.itemAt(position)
        if not item:
            return
        
        self.on_tree_item_clicked(item)

        menu = QMenu(self)

        open_website_action = QAction(self.tr("Open Website"), self)
        open_website_action.triggered.connect(
            lambda: self.results_tree.itemDoubleClicked.emit(item, 0))
        menu.addAction(open_website_action)

        zoom_to_object_action = QAction(self.tr("Zoom to Object"), self)
        zoom_to_object_action.triggered.connect(lambda: self.zoom_to_object(item))
        menu.addAction(zoom_to_object_action)

        copy_info_action = QAction(self.tr("Copy Object Information"), self)
        copy_info_action.triggered.connect(lambda: self.copy_object_information(item))
        menu.addAction(copy_info_action)

        # Gaia XP Spectrum
        try:
            lib = get_library()
            has_lib = bool(lib.installed_bands())
        except Exception:
            has_lib = False

        act_spectrum = QAction(self.tr("View Gaia XP Spectrum"), self)
        act_spectrum.triggered.connect(lambda: self._show_gaia_spectrum_for_item(item))
        act_spectrum.setEnabled(has_lib)
        if not has_lib:
            act_spectrum.setToolTip(
                "No Gaia library installed — use Settings → Gaia XP Spectral Library")
        menu.addAction(act_spectrum)

        menu.exec(self.results_tree.viewport().mapToGlobal(position))

    def _show_gaia_spectrum_for_item(self, item):
        from setiastro.saspro.gaia_database import (
            GaiaBulkLibrary, get_library, SpectrumViewerWidget
        )
        import math

        try:
            ra  = float(item.text(0))
            dec = float(item.text(1))
            name = item.text(2)
        except Exception:
            return

        lib = get_library()
        if not lib.installed_bands():
            QMessageBox.information(
                self, "Gaia Library",
                "No Gaia XP spectral library installed.\n"
                "Open Settings → Gaia XP Spectral Library to install bands."
            )
            return

        result = lib.find_nearest(ra, dec, radius_arcsec=3.0)
        if result is None:
            QMessageBox.information(
                self, "No Spectrum",
                f"No Gaia XP spectrum found within 3\" of {name}.\n"
                f"The relevant magnitude band may not be installed."
            )
            return

        source_id, sep = result
        spec = lib.get_spectrum(source_id)
        if spec is None:
            QMessageBox.information(self, "No Spectrum", "Source found but spectrum data missing.")
            return

        # Show in a small popup
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Gaia XP Spectrum — {name}")
        dlg.setMinimumSize(600, 320)
        layout = QVBoxLayout(dlg)
        viewer = SpectrumViewerWidget(dlg)
        layout.addWidget(viewer)
        info = QLabel(f"source_id: {source_id}   separation: {sep:.2f}\"")
        info.setStyleSheet("font-size: 10px; color: #888;")
        layout.addWidget(info)
        btn = QPushButton("Close")
        btn.clicked.connect(dlg.accept)
        layout.addWidget(btn)
        viewer.show_spectrum(spec, title=f"{name}  (G source {source_id})")
        dlg.exec()

    def toggle_autostretch(self):
        if not hasattr(self, 'original_image'):
            # Store the original image the first time AutoStretch is applied
            self.original_image = self.image_data.copy()
        
        # Determine if the image is mono or color based on the number of dimensions
        if self.image_data.ndim == 2:
            # Call stretch_mono_image if the image is mono

            stretched_image = stretch_mono_image(self.image_data, target_median=0.25, normalize=True, no_black_clip=True)
        else:
            # Call stretch_color_image if the image is color

            stretched_image = stretch_color_image(self.image_data, target_median=0.25, linked=False, normalize=True, no_black_clip=True)
        
        # If the AutoStretch is toggled off (using the same button), restore the original image
        if self.auto_stretch_button.text() == "AutoStretch":
            # Store the stretched image and update the button text to indicate it's on
            self.stretched_image = stretched_image
            self.auto_stretch_button.setText("Turn Off AutoStretch")
        else:
            # Revert to the original image and update the button text to indicate it's off
            stretched_image = self.original_image
            self.auto_stretch_button.setText("AutoStretch")
        

        stretched_image = (stretched_image * 255).astype(np.uint8)


        # Update the display with the stretched image (or original if toggled off)

        height, width = stretched_image.shape[:2]
        bytes_per_line = 3 * width

        # Ensure the image has 3 channels (RGB)
        if stretched_image.ndim == 2:
            # OPTIMIZATION: Use cv2.cvtColor instead of np.stack/repeat
            stretched_image = cv2.cvtColor(stretched_image, cv2.COLOR_GRAY2RGB)
        elif stretched_image.shape[2] == 1:
            stretched_image = cv2.cvtColor(stretched_image, cv2.COLOR_GRAY2RGB)



        qimg = QImage(stretched_image.tobytes(), width, height, bytes_per_line, QImage.Format.Format_RGB888)
        if qimg.isNull():
            print("Failed to create QImage")
            return

        pixmap = QPixmap.fromImage(qimg)
        if pixmap.isNull():
            print("Failed to create QPixmap")
            return

        self.main_image = pixmap
        scaled_pixmap = pixmap.scaled(self.mini_preview.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self.mini_preview.setPixmap(scaled_pixmap)

        # Save current view state before swapping the pixmap
        saved_transform = self.main_preview.transform()
        saved_center = self.main_preview.mapToScene(
            self.main_preview.viewport().rect().center()
        )

        self.main_scene.clear()
        self.main_scene.addPixmap(pixmap)
        self._marker_layer = None
        self._ensure_marker_layer()
        self._set_marker_points_from_results()
        self.main_preview.setSceneRect(QRectF(pixmap.rect()))

        # Restore the view exactly as it was, instead of resetting to 1:1 centered.
        # Pad the scene (after the transform is set) so we can pan past the edges,
        # then recenter on the saved center so the padding doesn't shift the view.
        self.main_preview.setTransform(saved_transform)
        self._update_scene_margins()
        self.main_preview.centerOn(saved_center)

        self.update_green_box()

        # Optionally, you can also update any other parts of the UI after stretching the image
        print(f"AutoStretch {'applied to' if self.auto_stretch_button.text() == 'Turn Off AutoStretch' else 'removed from'} the image.")


    def zoom_to_object(self, item):
        """Zoom to the object in the main preview."""
        ra = float(item.text(0))  # Assuming RA is in the first column
        dec = float(item.text(1))  # Assuming Dec is in the second column
        self.main_preview.zoom_to_coordinates(ra, dec)
        

    def copy_object_information(self, item):
        """Copy object information to the clipboard."""
        info = f"RA: {item.text(0)}, Dec: {item.text(1)}, Name: {item.text(2)}, Diameter: {item.text(3)}, Type: {item.text(4)}"
        clipboard = QApplication.clipboard()
        clipboard.setText(info)

    def set_tool(self, tool_name):
        """Sets the current tool and updates button states."""
        self.current_tool = tool_name

        # Reset button styles and highlight the selected button
        for button in self.annotation_buttons:
            if button.tool_name == tool_name:
                button.setStyleSheet("background-color: lightblue;")  # Highlight selected button
            else:
                button.setStyleSheet("")  # Reset other buttons


    def select_color(self):
        """Opens a color dialog to choose annotation color."""
        color = QColorDialog.getColor(self.selected_color, self, "Select Annotation Color")
        if color.isValid():
            self.selected_color = color

    def select_font(self):
        """Opens a font dialog to choose text annotation font."""
        font, ok = QFontDialog.getFont(self.selected_font, self, "Select Annotation Font")
        if ok:
            self.selected_font = font                

    def toggle_annotation_tools(self):
        """Toggle the visibility of the annotation tools section."""
        is_visible = self.annotation_tools_section.isVisible()
        self.annotation_tools_section.setVisible(not is_visible)
        self.show_annotations_button.setText("Hide Annotation Tools" if not is_visible else "Show Annotation Tools")

    def save_plate_solved_fits(self):
        bit_depth, ok = QInputDialog.getItem(
            self, "Select Bit Depth", "Choose the bit depth for the FITS file:",
            ["8-bit", "16-bit", "32-bit"], 0, False
        )
        if not ok: return
        out_path, _ = QFileDialog.getSaveFileName(self, "Save Plate Solved FITS", "", "FITS Files (*.fits *.fit)")
        if not out_path: return
        if self.wcs is None:
            QMessageBox.warning(self, "WCS Data Missing", "WCS header data is not available.")
            return

        img = self.image_data
        # Prepare image data, preserving color if present.
        img = img.astype(np.float32)
        is_color = False
        if img.ndim == 2:
            src = img
        else:
            # If image has >=3 channels, keep the first 3 as RGB
            if img.shape[2] >= 3:
                src = img[..., :3]
                is_color = True
            else:
                # fallback to first plane
                src = img[..., 0]

        # If data seems to be in 0-255 range, scale to 0-1
        try:
            maxv = float(np.nanmax(src))
        except Exception:
            maxv = 0.0
        if maxv > 1.1:
            src = src / 255.0

        # Clip to [0,1]
        src = np.clip(src, 0.0, 1.0)

        # Convert to desired bit depth and arrange axes for multichannel data
        if bit_depth == "8-bit":
            if is_color:
                arr = (src * 255.0).astype(np.uint8)
                # FITS expects axes: (plane, y, x)
                arr = np.transpose(arr, (2, 0, 1))
            else:
                arr = (src * 255.0).astype(np.uint8)
        elif bit_depth == "16-bit":
            if is_color:
                arr = (src * 65535.0).astype(np.uint16)
                arr = np.transpose(arr, (2, 0, 1))
            else:
                arr = (src * 65535.0).astype(np.uint16)
        else:  # 32-bit float
            if is_color:
                arr = src.astype(np.float32)
                arr = np.transpose(arr, (2, 0, 1))
            else:
                arr = src.astype(np.float32)

        hdr = (self.original_header.copy() if getattr(self, 'original_header', None) else fits.Header())
        try:
            hdr.update(self.wcs.to_header(relax=True))
        except Exception:
            pass  # still save whatever we have

        # Let astropy infer NAXIS/BITPIX from data; don’t set them manually
        try:
            fits.writeto(out_path, arr, header=hdr, overwrite=True)
            QMessageBox.information(self, "File Saved", f"FITS file saved as {out_path}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save FITS file: {e}")

    def push_annotated_to_view(self):
        if not self.main_image:
            QMessageBox.warning(self, "No Image", "No image loaded.")
            return
        if self._doc_manager is None:
            QMessageBox.warning(self, "No Document Manager", "Cannot push to view without a document manager.")
            return

        # Render full scene (same as save_annotated_image full mode)
        original_circle_center = self.main_preview.circle_center
        original_circle_radius = self.main_preview.circle_radius
        self.main_preview.circle_center = None
        self.main_preview.circle_radius = 0
        self.main_preview.draw_query_results()

        pixmap = QPixmap(self.main_image.size())
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        self.main_scene.render(painter)
        painter.end()

        self.main_preview.circle_center = original_circle_center
        self.main_preview.circle_radius = original_circle_radius
        self.main_preview.draw_query_results()

        # Convert QPixmap → numpy float32 array, respecting row stride
        qimg = pixmap.toImage().convertToFormat(QImage.Format.Format_RGB888)
        w, h = qimg.width(), qimg.height()
        bytes_per_line = qimg.bytesPerLine()  # may be > w*3 due to padding
        buf = qimg.bits()
        buf.setsize(h * bytes_per_line)
        # Read with actual stride, then slice to true width
        arr = np.frombuffer(buf, dtype=np.uint8).reshape((h, bytes_per_line))
        arr = arr[:, :w * 3].reshape((h, w, 3)).astype(np.float32) / 255.0

        # Push to doc manager
        title = "Annotated Image"
        if self.image_path:
            import os
            title = f"{os.path.splitext(os.path.basename(self.image_path))[0]} [Annotated]"

        try:
            if hasattr(self._doc_manager, "open_array"):
                self._doc_manager.open_array(arr, title=title)
            elif hasattr(self._doc_manager, "open_numpy"):
                self._doc_manager.open_numpy(arr, title=title)
            else:
                self._doc_manager.create_document(image=arr, name=title)
        except Exception as e:
            QMessageBox.critical(self, "Push Failed", f"Failed to push to view:\n{e}")

    def save_annotated_image(self):
        """Save the annotated image as a full or cropped view, excluding the search circle."""
        # Create a custom message box
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Save Annotated Image")
        msg_box.setText("Do you want to save the Full Image or Cropped Only?")
        
        # Add custom buttons
        full_image_button = msg_box.addButton("Save Full", QMessageBox.ButtonRole.AcceptRole)
        cropped_image_button = msg_box.addButton("Save Cropped", QMessageBox.ButtonRole.DestructiveRole)
        msg_box.addButton(QMessageBox.StandardButton.Cancel)

        # Show the message box and get the user's response
        msg_box.exec()

        # Determine the save type based on the selected button
        if msg_box.clickedButton() == full_image_button:
            save_full_image = True
        elif msg_box.clickedButton() == cropped_image_button:
            save_full_image = False
        else:
            return  # User cancelled

        # Open a file dialog to select the file name and format
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Annotated Image",
            "",
            "JPEG (*.jpg *.jpeg);;PNG (*.png);;TIFF (*.tiff *.tif)"
        )
        
        if not file_path:
            return  # User cancelled the save dialog

        # Temporarily disable the search circle in the custom graphics view
        original_circle_center = self.main_preview.circle_center
        original_circle_radius = self.main_preview.circle_radius
        self.main_preview.circle_center = None  # Hide the circle temporarily
        self.main_preview.circle_radius = 0

        # Redraw annotations without the search circle
        self.main_preview.draw_query_results()

        # Create a QPixmap to render the annotations
        if save_full_image:
            # Save the entire main image with annotations
            pixmap = QPixmap(self.main_image.size())
            pixmap.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pixmap)
            self.main_scene.render(painter)  # Render the entire scene without the search circle
        else:
            # Save only the currently visible area (cropped view)
            rect = self.main_preview.viewport().rect()
            scene_rect = self.main_preview.mapToScene(rect).boundingRect()
            pixmap = QPixmap(int(scene_rect.width()), int(scene_rect.height()))
            pixmap.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pixmap)
            self.main_scene.render(painter, QRectF(0, 0, pixmap.width(), pixmap.height()), scene_rect)

        painter.end()  # End QPainter to finalize drawing

        # Restore the search circle in the custom graphics view
        self.main_preview.circle_center = original_circle_center
        self.main_preview.circle_radius = original_circle_radius
        self.main_preview.draw_query_results()  # Redraw the scene with the circle

        # Save the QPixmap as an image file in the selected format
        try:
            if pixmap.save(file_path, file_path.split('.')[-1].upper()):
                QMessageBox.information(self, "Save Successful", f"Annotated image saved as {file_path}")
            else:
                raise Exception("Failed to save image due to format or file path issues.")
        except Exception as e:
            QMessageBox.critical(self, "Save Failed", f"An error occurred while saving the image: {str(e)}")


    def save_collage_of_objects(self):
        """Save a collage of 128x128 pixel patches centered around each object, with dynamically spaced text below."""
        # Options for display
        options = ["Name", "RA", "Dec", "Short Type", "Long Type", "Redshift", "Parallax", "Distance"]

        # Create a custom dialog to select information to display
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Information to Display")
        layout = QVBoxLayout(dialog)
        
        # Add checkboxes for each option
        checkboxes = {}
        for option in options:
            checkbox = QCheckBox(option)
            checkbox.setChecked(True)  # Default to checked
            layout.addWidget(checkbox)
            checkboxes[option] = checkbox

        # Add OK and Cancel buttons
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        layout.addWidget(button_box)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)

        # Show the dialog and get the user's response
        if dialog.exec() == QDialog.DialogCode.Rejected:
            return  # User cancelled

        # Determine which fields to display based on user selection
        selected_fields = [key for key, checkbox in checkboxes.items() if checkbox.isChecked()]

        # Calculate required vertical space for text based on number of selected fields
        text_row_height = 15
        text_block_height = len(selected_fields) * text_row_height
        patch_size = 128
        space_between_patches = max(64, text_block_height + 20)  # Ensure enough space for text between patches

        # Set parameters for collage layout
        number_of_objects = len(self.results)

        if number_of_objects == 0:
            QMessageBox.warning(self, "No Objects", "No objects available to create a collage.")
            return

        # Determine grid size for the collage
        grid_size = math.ceil(math.sqrt(number_of_objects))
        collage_width = patch_size * grid_size + space_between_patches * (grid_size - 1) + 128
        collage_height = patch_size * grid_size + space_between_patches * (grid_size - 1) + 128

        # Create an empty black RGB image for the collage
        collage_image = Image.new("RGB", (collage_width, collage_height), (0, 0, 0))
        draw = ImageDraw.Draw(collage_image)   # <— add this

        # Temporarily disable annotations
        original_show_names = self.show_names
        original_circle_center = self.main_preview.circle_center
        original_circle_radius = self.main_preview.circle_radius
        self.show_names = False
        self.main_preview.circle_center = None
        self.main_preview.circle_radius = 0

        try:
            for i, obj in enumerate(self.results):
                # Calculate position in the grid
                row = i // grid_size
                col = i % grid_size
                offset_x = 64 + col * (patch_size + space_between_patches)
                offset_y = 64 + row * (patch_size + space_between_patches)

                # Calculate pixel coordinates around the object
                ra, dec = obj["ra"], obj["dec"]
                x, y = self.calculate_pixel_from_ra_dec(ra, dec)


                # Crop the relevant area for the object
                rect = QRectF(x - patch_size // 2, y - patch_size // 2, patch_size, patch_size)
                cropped = self.main_image.copy(rect.toRect()).toImage().convertToFormat(QImage.Format.Format_RGB888)

                buf = cropped.bits()
                buf.setsize(cropped.width() * cropped.height() * 3)
                pil_patch = Image.frombytes("RGB", (cropped.width(), cropped.height()), bytes(buf))
                from PIL import Image as _PILImage
                pil_patch = pil_patch.resize((patch_size, patch_size), _PILImage.Resampling.BILINEAR)
                collage_image.paste(pil_patch, (offset_x, offset_y))

                # Font fallback
                try:
                    font = ImageFont.truetype("arial.ttf", 12)
                except Exception:
                    font = ImageFont.load_default()
                text_y = offset_y + patch_size + 5

                for field in selected_fields:
                    # Retrieve data and only display if not "N/A"
                    if field == "Name" and obj.get("name") != "N/A":
                        text = obj["name"]
                    elif field == "RA" and obj.get("ra") is not None:
                        text = f"RA: {obj['ra']:.6f}"
                    elif field == "Dec" and obj.get("dec") is not None:
                        text = f"Dec: {obj['dec']:.6f}"
                    elif field == "Short Type" and obj.get("short_type") != "N/A":
                        text = f"Type: {obj['short_type']}"
                    elif field == "Long Type" and obj.get("long_type") != "N/A":
                        text = f"{obj['long_type']}"
                    elif field == "Redshift":
                        z = _wimi_num_or_none(obj.get("redshift"))
                        if z is None:
                            continue
                        text = f"Redshift: z = {z:.6f}"
                    elif field == "Parallax":
                        plx = _wimi_num_or_none(obj.get("parallax_mas"))
                        if plx is None:
                            continue
                        text = f"Parallax: {plx:.3f} mas"
                    elif field == "Distance":
                        _z, _plx, dist_cell = wimi_result_columns(obj)
                        if dist_cell in ("N/A", "\u2014"):
                            continue
                        text = f"Distance: {dist_cell}"
                    else:
                        continue  # Skip if field is not available or set to "N/A"

                    # Draw the text and increment the Y position
                    draw.text((offset_x + 10, text_y), text, (255, 255, 255), font=font)
                    text_y += text_row_height  # Space between lines

        finally:
            # Restore the original annotation and search circle settings
            self.show_names = original_show_names
            self.main_preview.circle_center = original_circle_center
            self.main_preview.circle_radius = original_circle_radius

        # Save the collage
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Collage of Objects", "", "JPEG (*.jpg *.jpeg);;PNG (*.png);;TIFF (*.tiff *.tif)"
        )

        if file_path:
            collage_image.save(file_path)
            QMessageBox.information(self, "Save Successful", f"Collage saved as {file_path}")


        # Restore the search circle in the custom graphics view
        self.main_preview.circle_center = original_circle_center
        self.main_preview.circle_radius = original_circle_radius

        # Re-sync the fast marker layer without clearing the scene again
        self._ensure_marker_layer()
        self._set_marker_points_from_results()
        if self._marker_layer:
            self._marker_layer.update()

    def show_3d_model_view(self):
        # ─── 0) Engineering‐notation helper ────────────────────────────
        def eng_notation(x):
            if x == 0:
                return "0"
            exp = int(math.floor(math.log10(abs(x)) / 3) * 3)
            val = x / (10 ** exp)
            prefixes = {
                -12: "p", -9: "n", -6: "µ", -3: "m",
                0: "",  3: "k",  6: "M",  9: "G",
                12: "T", 15: "P"
            }
            return f"{val:.2f}{prefixes.get(exp, f'e{exp}')}"

        # ─── 1) Sanity checks ─────────────────────────────────────────
        if not self.results or self.image_data is None:
            QMessageBox.warning(self, "Data Error", "No image or results available.")
            return
        if self.wcs is None:
            QMessageBox.warning(self, "WCS Missing", "WCS data is required to generate the 3D plot.")
            return

        # ─── 2) Get user settings ────────────────────────────────────
        settings = ThreeDSettingsDialog(self).getSettings()
        if not settings:
            return
        (plane_style, max_res, z_option, z_min, z_max,
        z_scale, linear_max, obj_color, custom_col,
        z_height, show_lines, reverse_z) = (
            settings[k] for k in (
                "plane_style","resolution","z_option","z_min","z_max",
                "z_scale","linear_max","object_color","custom_color",
                "z_height","show_lines","reverse_z"
            )
        )

        # ─── 3) Normalize & downsample image ──────────────────────────
        img = self.image_data
        if img.ndim == 2:
            # OPTIMIZATION: Use cv2.cvtColor
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
        img_norm = np.clip((img - img.min())/(np.ptp(img)+1e-8), 0, 1)
        full_h, full_w = img.shape[:2]
        scale = min(max_res/full_h, max_res/full_w, 1.0)
        
        # OPTIMIZATION: Use cv2.resize instead of scipy.ndimage.zoom
        # zoom(img, scale) equivalent to resize(img, None, fx=scale, fy=scale)
        # cv2.resize expects (width, height)
        if scale < 1.0:
            new_w = int(full_w * scale)
            new_h = int(full_h * scale)
            img_ds = cv2.resize(img_norm, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        else:
            img_ds = img_norm
            
        # Ensure 3D dimensionality if it somehow got flattened (cv2.resize keeps channels usually)
        if img_ds.ndim == 2:
             img_ds = cv2.cvtColor(img_ds, cv2.COLOR_GRAY2RGB)
        h_ds, w_ds, _ = img_ds.shape

        # ─── 4) Build plane coordinates ───────────────────────────────
        xs = np.linspace(0, full_w-1, w_ds)
        ys = np.linspace(0, full_h-1, h_ds)
        Xp, Yp = np.meshgrid(xs, ys)
        RA, DEC = self.wcs.pixel_to_world_values(Xp, Yp)
        ra_min, ra_max = float(RA.min()), float(RA.max())
        dec_min, dec_max = float(DEC.min()), float(DEC.max())

        # ─── 5) Gather objects into rows (keep fields together) ───────
        rows = []
        for obj in self.results:
            try:
                # Skip solar-system minor bodies — their AU distances are not
                # meaningful on a light-year axis and distort the plot.
                if obj.get("short_type") == "MP" or obj.get("source", "").lower().startswith("minor"):
                    continue

                name = obj["name"]
                ra   = float(obj["ra"])
                dec  = float(obj["dec"])

                # distance in ly — prefer the canonical numeric field so parallax
                # stars (including augmented local Gaia) are always included.
                plx = _wimi_num_or_none(obj.get("parallax_mas"))

                d_ly = _wimi_num_or_none(obj.get("distance_ly"))
                if d_ly is None and plx is not None and plx > 0:
                    d_ly = (1000.0 / plx) * 3.261563777
                if d_ly is None:
                    # legacy fallback: parse whatever is in comoving_distance
                    raw_cd = str(obj.get("comoving_distance", "")).strip()
                    low = raw_cd.lower()
                    try:
                        if low.endswith("gly"):
                            d_ly = abs(float(raw_cd[:-3].strip())) * 1e9
                        elif low.endswith("pc"):
                            d_ly = abs(float(raw_cd[:-2].strip())) * 3.261563777
                        elif low.endswith("ly"):
                            d_ly = abs(float(raw_cd[:-2].strip()))
                        else:
                            d_ly = abs(float(raw_cd)) * 1e9   # bare number = GLy (legacy)
                    except (ValueError, TypeError):
                        d_ly = None
                if d_ly is None or d_ly <= 0:
                    continue
                d_ly = d_ly + 10.0   # +10 to avoid log10(0)

                zshift = _wimi_num_or_none(obj.get("redshift")) or 0.0

                px, py = self.wcs.world_to_pixel_values(ra, dec)
                if not (0 <= px < full_w and 0 <= py < full_h):
                    continue

                zval = math.log10(d_ly) if z_scale == "Logarithmic" else d_ly
                ra0, dec0 = self.wcs.pixel_to_world_values(px, py)

                # Show parallax for stars, redshift for extragalactic objects.
                if plx is not None and plx > 0:
                    extra_line = f"Parallax: {plx:.3f} mas"
                else:
                    extra_line = f"Redshift: {zshift:.5f}"
                label = (
                    f"<b>{name}</b><br>"
                    f"RA: {ra:.6f}<br>"
                    f"Dec: {dec:.6f}<br>"
                    f"Distance: {eng_notation(d_ly)} ly<br>"
                    f"{extra_line}"
                )
                enc = urllib.parse.quote(name)
                url = (
                    "https://simbad.cds.unistra.fr/simbad/sim-basic?"
                    f"Ident={enc}&submit=SIMBAD+search"
                )

                rows.append(dict(
                    name=name, x=ra0, y=dec0, z=zval, url=url, label=label,
                    px=px, py=py, legend_qcolor=obj.get("color", QColor(128, 128, 128))
                ))
            except Exception:
                continue

        if not rows:
            QMessageBox.warning(self, "No Objects", "No valid distance objects to plot.")
            return

        # ─── 6) Filter rows by finite z (and optional range) ──────────
        rows = [r for r in rows if math.isfinite(r["z"])]
        if not rows:
            QMessageBox.warning(self, "No Objects", "All distance values are invalid.")
            return

        if z_option == "Custom":
            rows = [r for r in rows if z_min <= r["z"] <= z_max]
            if not rows:
                QMessageBox.warning(self, "No Objects", "No objects fall within the custom Z range.")
                return
            plane_z = z_min
            z_range = (z_min, z_max)
        elif z_option == "Min-Max":
            z_vals = np.array([r["z"] for r in rows], dtype=float)
            plane_z = float(np.nanmin(z_vals))
            z_range = (float(np.nanmin(z_vals)), float(np.nanmax(z_vals)))
        else:  # Default
            plane_z = 0
            z_range = None

        if z_scale == "Linear" and z_option == "Default":
            z_range = (0, linear_max)

        # ─── 7) Build image‐plane layer ───────────────────────────────
        if "Grayscale" in plane_style:
            Zp = np.full_like(RA, plane_z)
            plane = go.Surface(
                x=RA, y=DEC, z=Zp,
                surfacecolor=np.mean(img_ds, axis=2),
                colorscale="gray", showscale=False, opacity=1.0,
                contours={"x": {"show": False}, "y": {"show": False}, "z": {"show": False}}
            )
        else:
            flat = (img_ds * 255).astype(int).reshape(-1, 3)
            cols = [f"rgb({r},{g},{b})" for r, g, b in flat]
            plane = go.Scatter3d(
                x=RA.flatten(), y=DEC.flatten(), z=[plane_z] * RA.size,
                mode="markers",
                marker=dict(symbol="square", size=2, line=dict(width=0), color=cols, opacity=1.0),
                hoverinfo="skip", showlegend=False
            )

        # ─── 8) Object colors (after filtering) ───────────────────────
        H, W = img_norm.shape[:2]
        if obj_color == "Image-Based":
            patch_r = 5
            def patch_color(r):
                cx, cy = int(r["px"]), int(r["py"])
                x0, x1 = max(0, cx - patch_r), min(W, cx + patch_r + 1)
                y0, y1 = max(0, cy - patch_r), min(H, cy + patch_r + 1)
                patch = img_norm[y0:y1, x0:x1]
                if patch.size:
                    mr, mg, mb = (patch.reshape(-1, 3).mean(axis=0) * 255).astype(int)
                else:
                    mr = mg = mb = 0
                return f"rgb({mr},{mg},{mb})"
            obj_cols = [patch_color(r) for r in rows]
        elif obj_color == "Legend Color":
            obj_cols = [f"rgb({c.red()},{c.green()},{c.blue()})" for c in (r["legend_qcolor"] for r in rows)]
        elif obj_color == "Solid (Custom)":
            c = custom_col
            obj_cols = [f"rgb({c.red()},{c.green()},{c.blue()})"] * len(rows)
        else:
            obj_cols = ["red"] * len(rows)

        # ─── 9) Build arrays (all same length) and optional lines ─────
        world_xs = [r["x"] for r in rows]
        world_ys = [r["y"] for r in rows]
        zs       = np.array([r["z"] for r in rows], dtype=float)
        labels   = [r["label"] for r in rows]
        urls     = [r["url"] for r in rows]
        names    = [r["name"] for r in rows]

        lines = []
        if show_lines:
            for r in rows:
                lines.append(go.Scatter3d(
                    x=[r["x"], r["x"]], y=[r["y"], r["y"]], z=[plane_z, r["z"]],
                    mode="lines", line=dict(color="gray", width=1),
                    hoverinfo="skip", showlegend=False
                ))

        # ─── 10) Scatter objects ───────────────────────────────────────
        scatter = go.Scatter3d(
            x=world_xs, y=world_ys, z=zs,
            mode="markers",
            marker=dict(size=4, color=obj_cols),
            hovertext=labels, hoverinfo="text",
            customdata=urls, name="Objects"
        )

        # ─── 11) Compose figure ───────────────────────────────────────
        fig = go.Figure(data=[plane] + lines + [scatter])
        scene = dict(
            xaxis_title="RA (deg)",
            xaxis=dict(range=[ra_min, ra_max], autorange=False),
            yaxis_title="Dec (deg)",
            yaxis=dict(range=[dec_max, dec_min], autorange=False),
            aspectmode="manual",
            aspectratio=dict(x=1, y=1, z=z_height),
            zaxis=dict(
                title=("log10(Distance in ly)" if z_scale == "Logarithmic" else "Distance (ly)"),
                tickformat="~s",
                **({"range": list(z_range)} if z_range else {}),
                **({"autorange": "reversed"} if reverse_z else {})
            )
        )
        fig.update_layout(title="3D Distance Model", autosize=True, scene=scene,
                        margin=dict(l=0, r=0, b=0, t=40))

        # ─── 12) Build & inject HTML ───────────────────────────────────
        html = fig.to_html(include_plotlyjs="cdn", full_html=True)
        items = "".join(f'<li><a href="{u}" target="_blank">{n}</a></li>' for n, u in zip(names, urls))
        sidebar = (
            '<div style="padding:10px;font-family:sans-serif;'
            'margin-top:20px;border-top:1px solid #ccc;">'
            '<h3>Objects</h3><ul>' + items + '</ul></div>'
        )
        js = """
        <script>
        var gd = document.getElementsByClassName('plotly-graph-div')[0];
        gd.on('plotly_click', function(e){
            var url = e.points[0].customdata;
            if (url) window.open(url, '_blank');
        });
        </script>
        """
        html = html.replace("</body>", sidebar + js + "</body>")

        # Save & preview
        default = os.path.expanduser("~/3d_distance_model.html")
        fn, _ = QFileDialog.getSaveFileName(self, "Save 3D Plot As", default, "HTML Files (*.html)")
        if fn:
            if not fn.lower().endswith(".html"):
                fn += ".html"
            with open(fn, "w", encoding="utf-8") as f:
                f.write(html)

        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".html", mode="w", encoding="utf-8")
        tmp.write(html); tmp.close()
        webbrowser.open("file://" + tmp.name)

    def show_hr_diagram(self):
        """
        H-R Diagram with optional Gaia XP synthetic photometry.
    
        When 'Use Gaia XP' is selected:
        - B and V are synthesised from XP spectra using Johnson B/V curves
        - Teff is estimated by blackbody fitting to the XP continuum
        - Stars with XP data are colored by spectral class or blackbody color
        - Outliers (carbon stars etc.) are flagged with a distinct symbol
        - Stars without XP fallback to catalog B, V from SIMBAD
        """
        from PIL import Image as _PILImage
        import os, tempfile, webbrowser
        import plotly.graph_objects as go
        from PyQt6.QtWidgets import QFileDialog, QMessageBox
    
        settings = HRSettingsDialog(self).getSettings()
        if settings is None:
            return
    
        use_xp        = settings["use_xp"]
        teff_mode     = settings["teff_mode"]
        use_realistic = settings["color_mode"].startswith("Realistic")
        use_class_col = settings["color_mode"].startswith("Spectral class")
        solid_qcolor  = settings["custom_color"]
        flag_outliers = settings["flag_outliers"]
        use_image_bg  = settings["bg_mode"].startswith("HR Diagram")
        show_sun      = settings["show_sun"]
    
        # Native B−V / abs-mag domain that the background HR image actually spans.
        # The axis may extend past this (brown-dwarf territory); the image stays
        # pinned to its true scale so the main sequence doesn't smear.
        IMG_BV0, IMG_BV1 = -0.3, 2.25
        IMG_Y0,  IMG_Y1  = -9.0, 19.0

        if settings["range_mode"].startswith("Default"):
            x0, x1 = IMG_BV0, IMG_BV1
            y0, y1 = IMG_Y0, IMG_Y1
            auto_extend = True
        else:
            x0 = settings["x_min"];  x1 = settings["x_max"]
            y0 = settings["y_min"];  y1 = settings["y_max"]
            auto_extend = False
    
        # ── Try to get Gaia library ───────────────────────────────────────────
        lib = None
        if use_xp:
            try:
                from setiastro.saspro.gaia_database import get_library
                _lib = get_library()
                if _lib.installed_bands():
                    lib = _lib
                else:
                    lib = None
            except Exception:
                lib = None
            if lib is None:
                QMessageBox.information(
                    self, "Gaia Library",
                    "No Gaia XP library installed — falling back to SIMBAD catalog photometry.\n"
                    "Install bands via Settings → Gaia XP Spectral Library for best results.")
    
        # ── Build stellar data ────────────────────────────────────────────────
        # We'll build from self.results (all objects from SIMBAD) so we can
        # attempt XP lookup for every one, not just those that already had B/V.
        # Parallax for absolute magnitude still comes from query_results.
    
        # Build a quick lookup from name → query_results entry (has parallax etc.)
        qr_by_name = {}
        for obj in getattr(self, "query_results", []):
            nm = obj.get("name")
            if nm:
                qr_by_name[nm] = obj
    
        B_list, V_list, Mv_list = [], [], []
        bv_list = []   # explicit per-star B-V color (real color, never a sentinel)
        names_list, teff_list, spec_list = [], [], []
        is_outlier = []
        used_xp_list = []
        # Stars rejected for unphysical colour (bluer than the stellar locus /
        # past the Ballesteros pole). Kept aside so we can list them for the
        # user to investigate rather than silently dropping them.
        rejected_color = []   # list of dicts: name, bv, bp_rp
    
        # Pre-build filter arrays on the standard grid (done once)
        _b_tp_grid = np.interp(_WL_GRID, _B_WL, _B_TP, left=0.0, right=0.0)
        _v_tp_grid = np.interp(_WL_GRID, _V_WL, _V_TP, left=0.0, right=0.0)
    
        source_objects = getattr(self, "results", [])
        if not source_objects:
            # Fall back to query_results if results isn't populated
            source_objects = getattr(self, "query_results", [])
    
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            for obj in source_objects:
                name = obj.get("name", "")
                ra   = obj.get("ra")
                dec  = obj.get("dec")
    
                # Parallax — from qr_by_name or obj itself
                qr  = qr_by_name.get(name, obj)

                # Local Gaia astrometric augment carries no photometric colour:
                # that catalog has G + parallax only (bp_rp is NULL), so the only
                # available B−V is XP-synthesised. For the faint red dwarfs this
                # population is made of, the synthesis is dominated by near-zero
                # blue flux and lands them at implausible B−V ≈ 2.5–3, smeared
                # against the right edge. Plotting a colour we don't trust is worse
                # than leaving them off — they still appear in the 3D distance
                # model, which only needs parallax.
                if (obj.get("source") or qr.get("source")) == "GaiaLocal":
                    continue

                plx = None
                for k in ("parallax_mas", "PLX_VALUE", "plx"):
                    v = qr.get(k)
                    if v is not None:
                        try:
                            plx = float(v)
                            if plx > 0:
                                break
                        except Exception:
                            plx = None
                if plx is None or plx <= 0:
                    continue
    
                dist_pc = 1000.0 / plx
    
                # ── Try XP path ───────────────────────────────────────────────
                xp_used  = False
                B = V = Teff = None
                bv = None       # explicit B-V color (catalog or XP synth)
                bp_rp = None    # Gaia BP-RP color (XP synth, or catalog G+... if available)
                outlier = False
    
                if lib is not None and ra is not None and dec is not None:
                    try:
                        match = lib.find_nearest(float(ra), float(dec), radius_arcsec=3.0)
                        if match is not None:
                            source_id, sep_arcsec = match
                            spec = lib.get_spectrum(source_id)
                            if spec is not None and spec.flux is not None:
                                wl_nm  = np.asarray(spec.wavelengths, dtype=np.float64)
                                fl_arr = np.asarray(spec.flux,        dtype=np.float64)
                                if wl_nm[0] > wl_nm[-1]:
                                    wl_nm  = wl_nm[::-1]
                                    fl_arr = fl_arr[::-1]

                                # Synthetic Gaia BP-RP color (preferred) and B-V.
                                bp_rp_synth = _synth_bp_rp_from_xp(fl_arr, wl_nm)
                                bv_synth    = _synth_bv_from_xp(fl_arr, wl_nm)
                                if bp_rp_synth is not None and math.isfinite(bp_rp_synth):
                                    bp_rp = float(bp_rp_synth)
                                if bv_synth is not None and math.isfinite(bv_synth):
                                    # Carry color explicitly; leave B and V None so the
                                    # display never shows a fake V=0.000 for an XP star.
                                    bv = float(bv_synth)
                                if bp_rp is not None or bv is not None:
                                    xp_used = True
    
                                # Teff from XP spectrum
                                if "Blackbody" in teff_mode:
                                    Teff = _blackbody_teff_from_xp(fl_arr, wl_nm)
    
                                # Outlier detection: compare B-V-derived Teff with
                                # blackbody Teff — large divergence = peculiar star
                                if flag_outliers and Teff is not None:
                                    T_col, _ = _teff_from_color(bp_rp=bp_rp, bv=bv)
                                    if T_col is not None:
                                        ratio = Teff / T_col if T_col > 0 else 1.0
                                        outlier = ratio < 0.5 or ratio > 2.0
                    except Exception:
                        pass  # fall through to catalog

                # ── Catalog fallback ──────────────────────────────────────────
                # Only if the XP path did not already give us a color.
                if bv is None:
                    try:
                        B = float(qr.get("Bmag"))
                        V = float(qr.get("Vmag"))
                        if not (math.isfinite(B) and math.isfinite(V)):
                            B = V = None
                        # Guard against placeholder zeros: a catalog star with
                        # Bmag or Vmag reported as exactly 0.000 is almost
                        # certainly a "no value returned" filler, not a real
                        # magnitude (a true V=0 star like Vega is a once-in-the-
                        # sky rarity and won't be in a typical field). Reject so
                        # it isn't plotted with a garbage B-V color.
                        elif B == 0.0 or V == 0.0:
                            B = V = None
                        else:
                            bv = B - V
                    except Exception:
                        B = V = None

                # Need a color to place the star horizontally.
                if bv is None:
                    continue
    
                # ── Teff from colour ──────────────────────────────────────────
                # Prefer the Gaia-native Curtis 2020 BP-RP relation (XP path);
                # fall back to Ballesteros B-V for catalog-only stars. Both are
                # domain-clamped, so unphysical/blueward colours and pole cases
                # return None and the star is dropped rather than plotted with a
                # million-K or negative temperature.
                if Teff is None:
                    Teff, _teff_src = _teff_from_color(bp_rp=bp_rp, bv=bv)

                # No usable temperature → the colour is outside every relation's
                # physical domain (bluer than the stellar locus, past the
                # Ballesteros pole, etc.). Don't plot it, but record it so the
                # user can see what was flagged and investigate it themselves.
                if Teff is None:
                    # Only log it as "unphysical colour" if we actually had a
                    # colour to judge — a star with no colour at all was already
                    # dropped earlier for missing photometry, not for being weird.
                    if bp_rp is not None or bv is not None:
                        rejected_color.append({
                            "name":  name,
                            "bv":    bv,
                            "bp_rp": bp_rp,
                        })
                    continue
    
                # ── Absolute magnitude ────────────────────────────────────────
                # Use catalog Vmag for absolute magnitude — always
                # XP is only used for B-V color and Teff
                Vmag_catalog = None
                try:
                    Vmag_catalog = float(qr.get("Vmag"))
                    if not math.isfinite(Vmag_catalog):
                        Vmag_catalog = None
                except Exception:
                    pass

                if Vmag_catalog is None:
                    # Fall back to Gaia G mag as approximate V
                    try:
                        Vmag_catalog = float(qr.get("Gmag") or qr.get("gaia_gmag"))
                    except Exception:
                        pass

                if Vmag_catalog is None:
                    continue   # can't place on diagram without an apparent magnitude

                absV = Vmag_catalog - (5 * math.log10(dist_pc) - 5)
    
                spec_class = _spectral_class_from_teff(Teff)
    
                B_list.append(B);  V_list.append(V);  Mv_list.append(absV)
                bv_list.append(bv)
                teff_list.append(Teff);  names_list.append(name)
                spec_list.append(spec_class);  is_outlier.append(outlier)
                used_xp_list.append(xp_used)
    
        finally:
            QApplication.restoreOverrideCursor()
    
        if not B_list:
            QMessageBox.warning(self, "Insufficient Data",
                "No stars with usable photometry found.\n"
                "Run a SIMBAD query first, and install the Gaia XP library for best results.")
            return
    
        bv_arr   = np.array(bv_list, dtype=float)
        Mv_arr   = np.array(Mv_list)
        teff_arr = np.array(teff_list)
        n_xp     = sum(used_xp_list)
        n_total  = len(B_list)

        # ── Auto-extend axes so no star falls off the plot ────────────────────
        # Gaia XP classifies well past B−V = 2.25 (into brown-dwarf territory),
        # so widen the window when needed. The right edge never drops below 2.25.
        if auto_extend and bv_arr.size:
            pad_x, pad_y = 0.15, 0.5
            bv_hi = float(np.nanmax(bv_arr)); bv_lo = float(np.nanmin(bv_arr))
            mv_hi = float(np.nanmax(Mv_arr)); mv_lo = float(np.nanmin(Mv_arr))
            if bv_hi + pad_x > x1:
                x1 = math.ceil((bv_hi + pad_x) * 4.0) / 4.0   # round up to 0.25
            if bv_lo - pad_x < x0:
                x0 = math.floor((bv_lo - pad_x) * 4.0) / 4.0
            # y-axis is drawn inverted (range = [y1, y0]); keep faint/bright ends in view
            if mv_hi + pad_y > y1:
                y1 = math.ceil(mv_hi + pad_y)
            if mv_lo - pad_y < y0:
                y0 = math.floor(mv_lo - pad_y)
    
        # ── Colors ───────────────────────────────────────────────────────────
        if use_realistic:
            colors = [kelvin_to_rgb(T) for T in teff_arr]
        elif use_class_col:
            colors = [_CLASS_COLORS.get(s, "#888888") for s in spec_list]
        else:
            hex_c  = solid_qcolor.name()
            colors = [hex_c] * n_total
    
        # ── Hover text & URLs ─────────────────────────────────────────────────
        hover_texts, urls = [], []
        for nm, b, v, bvc, m, T, sc, xp in zip(names_list, B_list, V_list, bv_arr,
                                        Mv_arr, teff_arr, spec_list, used_xp_list):
            src = "Gaia XP" if xp else "catalog"
            # For XP stars we only have the B-V color (synthesized from the
            # spectrum), not separate B and V, so show the color alone rather
            # than a misleading V=0.000. Catalog stars show all three.
            if b is not None and v is not None:
                phot_line = f"B: {b:.3f}  V: {v:.3f}  B-V: {bvc:.3f}"
            else:
                phot_line = f"B-V: {bvc:.3f}"
            hover_texts.append(
                f"<b>{nm}</b><br>"
                f"{phot_line}<br>"
                f"Abs V: {m:.2f}<br>"
                f"Teff: {int(T):,} K  ({sc})<br>"
                f"Source: {src}"
            )
            enc = urllib.parse.quote(nm)
            urls.append(
                f"https://simbad.cds.unistra.fr/simbad/sim-basic?Ident={enc}&submit=SIMBAD+search"
            )
    
        # ── Marker sizes ─────────────────────────────────────────────────────
        if settings["marker_size_mode"].startswith("Auto"):
            marker_size = max(4, min(12, int(round(120 / max(1, math.sqrt(n_total))))))
        else:
            marker_size = int(settings["marker_size"])
    
        # ── Split normal vs outlier ───────────────────────────────────────────
        norm_idx = [i for i, o in enumerate(is_outlier) if not o]
        out_idx  = [i for i, o in enumerate(is_outlier) if o]
    
        traces = []
    
        def _subset(idx, symbol, name_legend, size_mult=1.0):
            if not idx:
                return
            bv_s  = bv_arr[idx];  mv_s = Mv_arr[idx]
            col_s = [colors[i] for i in idx]
            ht_s  = [hover_texts[i] for i in idx]
            url_s = [urls[i] for i in idx]
            sz    = max(3, int(marker_size * size_mult))
            traces.append(go.Scatter(
                x=bv_s, y=mv_s, mode="markers",
                marker=dict(color=col_s, size=sz, symbol=symbol,
                            opacity=0.80, line=dict(width=0)),
                hovertext=ht_s, customdata=url_s,
                name=name_legend,
            ))
    
        _subset(norm_idx, "circle",           f"Stars ({len(norm_idx)})")
        _subset(out_idx,  "triangle-up-open", f"Outliers ({len(out_idx)})", size_mult=1.4)
    
        fig = go.Figure(traces)
    
        # ── Radius iso-lines ─────────────────────────────────────────────────
        bv_grid = np.linspace(x0, x1, 300)
        T_grid  = 4600.0 * (1/(0.92*bv_grid+1.7) + 1/(0.92*bv_grid+0.62))
        T_sun   = 5772.0
        gray_colors = ["#444","#666","#888","#aaa","#ccc","#eee"]
        for R_rs, gc in zip([0.01, 0.1, 1.0, 10.0, 100.0, 1000.0], gray_colors):
            L = R_rs**2 * (T_grid / T_sun)**4
            MV_line = 4.83 - 2.5 * np.log10(np.maximum(L, 1e-30))
            fig.add_trace(go.Scatter(
                x=bv_grid, y=MV_line, mode="lines",
                line=dict(color=gc, dash="dash"),
                name=f"R = {R_rs:g} R⊙", hoverinfo="none",
            ))
    
        # ── Sun marker ───────────────────────────────────────────────────────
        if show_sun:
            sun_sz = max(18, marker_size + 10)
            fig.add_trace(go.Scatter(
                x=[0.66], y=[4.8], mode="markers+text",
                marker=dict(color="gold", size=sun_sz, symbol="star"),
                name="Sun", hoverinfo="skip",
            ))
    
        # ── Spectral class color legend (sidebar annotation) ─────────────────
        class_legend_html = ""
        if use_class_col:
            swatches = "".join(
                f'<span style="display:inline-block;width:14px;height:14px;'
                f'background:{col};border-radius:2px;margin-right:4px;'
                f'vertical-align:middle"></span>{cls}&nbsp;&nbsp;'
                for cls, col in _CLASS_COLORS.items() if cls != "?"
            )
            class_legend_html = (
                f'<div style="margin-top:8px;font-size:12px;color:#ccc;">'
                f'Spectral class:&nbsp;{swatches}</div>'
            )
    
        # ── Axis ticks ───────────────────────────────────────────────────────
        base_ticks = [-0.3, 0.0, 0.5, 1.0, 1.5, 2.0, 2.25]
        bv_ticks = [t for t in base_ticks if x0 - 1e-9 <= t <= x1 + 1e-9]
        # extend past 2.25 toward the brown-dwarf end in 0.5 steps
        t = 2.5
        while t <= x1 + 1e-9:
            bv_ticks.append(round(t, 2)); t += 0.5
        # extend blueward past -0.3 if the window grew that way
        t = -0.5
        while t >= x0 - 1e-9:
            bv_ticks.insert(0, round(t, 2)); t -= 0.5
        bv_ticks = sorted(set(bv_ticks))
        t_ticks  = [4600.0*(1/(0.92*x+1.7)+1/(0.92*x+0.62)) for x in bv_ticks]
        tick_lbl = [f"{x:.2f}<br>{int(t):,} K" for x, t in zip(bv_ticks, t_ticks)]
    
        fig.update_xaxes(
            title_text="B−V color (mag) ↔ Teff",
            tickvals=bv_ticks, ticktext=tick_lbl,
            tickfont_color="white", title_font=dict(color="white"),
            gridcolor="gray", zerolinecolor="gray", range=[x0, x1],
        )
        fig.update_yaxes(
            title_text="Absolute V magnitude (mag)",
            range=[y1, y0], autorange=False,
            tickfont_color="white", title_font=dict(color="white"),
            gridcolor="gray", zerolinecolor="gray",
        )
    
        if use_image_bg:
            from setiastro.saspro.resources import hrdiagram_path
            pil_img = _PILImage.open(hrdiagram_path)
            if auto_extend:
                # Pin the reference image to its true B−V/mag scale; any extended
                # region beyond it (e.g. brown dwarfs past 2.25) stays blank.
                ix, iy   = IMG_BV0, IMG_Y0
                isx, isy = (IMG_BV1 - IMG_BV0), (IMG_Y1 - IMG_Y0)
            else:
                ix, iy   = x0, y0
                isx, isy = (x1 - x0), (y1 - y0)
            fig.add_layout_image(dict(
                source=pil_img, xref="x", yref="y",
                x=ix, y=iy, sizex=isx, sizey=isy,
                xanchor="left", yanchor="top",
                sizing="stretch", opacity=1.0, layer="below",
            ))
    
        fig.update_layout(
            title=dict(
                text=(
                    f"Hertzsprung–Russell Diagram  ·  {n_total} stars  "
                    f"({'Gaia XP synthetic + catalog' if n_xp > 0 else 'catalog photometry'})"
                    f"  ·  {n_xp} XP / {n_total-n_xp} catalog"
                    + (f"  ·  {len(rejected_color)} rejected (unphysical colour)"
                       if rejected_color else "")
                ),
                font_color="white",
            ),
            plot_bgcolor="rgba(0,0,0,0)" if use_image_bg else "black",
            paper_bgcolor="black",
            margin=dict(l=40, r=20, t=60, b=60),
        )
    
        # ── Sidebar + click handler ───────────────────────────────────────────
        items = "".join(
            f'<li><a href="{u}" style="color:cyan" target="_blank">{n}</a></li>'
            for n, u in zip(names_list, urls)
        )

        # Rejected-colour section: stars dropped because their colour is
        # unphysical (bluer than the stellar locus / past the Ballesteros pole).
        # These are almost always bad photometry, blends, reddening errors, or
        # peculiar atmospheres — worth a professional's suspicion, not a silent
        # drop. We list them with their colour and a SIMBAD link so the user can
        # investigate the source themselves.
        rejected_html = ""
        if rejected_color:
            def _fmt_col(v):
                return f"{v:+.3f}" if isinstance(v, (int, float)) else "—"
            rej_items = "".join(
                f'<li><a href="https://simbad.cds.unistra.fr/simbad/sim-basic'
                f'?Ident={urllib.parse.quote(r["name"])}&submit=SIMBAD+search" '
                f'style="color:#ff9a9a" target="_blank">{r["name"]}</a>'
                f'<span style="color:#888;font-size:11px;">'
                f'&nbsp;&nbsp;B−V {_fmt_col(r["bv"])}'
                f'&nbsp;·&nbsp;BP−RP {_fmt_col(r["bp_rp"])}</span></li>'
                for r in rejected_color
            )
            rejected_html = (
                '<div style="margin-top:14px;padding-top:10px;'
                'border-top:1px dashed #663333;">'
                f'<h3 style="color:#ff9a9a;">Unphysical colour '
                f'({len(rejected_color)})</h3>'
                '<div style="font-size:11px;color:#aaa;margin-bottom:6px;">'
                'Dropped from the diagram: colour bluer than any real star '
                '(past the B−V ≈ −0.67 blackbody limit). Usually bad photometry, '
                'a blend, reddening error, or a peculiar atmosphere — inspect the '
                'source before trusting it.</div>'
                '<ul>' + rej_items + '</ul></div>'
            )

        sidebar = (
            '<div style="padding:10px;font-family:sans-serif;'
            'border-top:1px solid #444;background:black;color:white;">'
            f'<h3>Stars ({n_total})</h3>'
            f'{class_legend_html}'
            '<ul>' + items + '</ul>'
            + rejected_html +
            '</div>'
        )
        js = """
        <script>
        var gd = document.getElementsByClassName('plotly-graph-div')[0];
        gd.on('plotly_click', function(e){
            var url = e.points[0].customdata;
            if(url) window.open(url,'_blank');
        });
        </script>
        """
    
        html = fig.to_html(include_plotlyjs="cdn", full_html=True)
        html = html.replace("</body>", sidebar + js + "</body>")
    
        default = os.path.join(os.path.expanduser("~"), "hr_diagram.html")
        fn, _ = QFileDialog.getSaveFileName(self, "Save H-R Diagram As",
                                            default, "HTML Files (*.html)")
        if fn:
            if not fn.lower().endswith(".html"):
                fn += ".html"
            with open(fn, "w", encoding="utf-8") as f:
                f.write(html)
    
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".html",
                                        mode="w", encoding="utf-8")
        tmp.write(html); tmp.close()

        if settings.get("show_3d_cmd"):
            self._cmd_3d_data = {
                "bv":    bv_arr.tolist(),
                "mv":    Mv_arr.tolist(),
                "names": names_list,
                "urls":  urls,
                "teff":  teff_arr.tolist(),
                "spec":  spec_list,
                "colors": colors,
                "plx":   [qr_by_name.get(n, {}).get("parallax_mas") for n in names_list],
                "settings": settings,
            }
            # Add a 3D CMD button to the HR diagram HTML
            cmd_btn_html = (
                '<div style="text-align:center;margin:10px;">'
                '<button onclick="window.open(\'cmd3d.html\')" '
                'style="background:#1a4f2a;color:#e8f8ee;border:1px solid #2a8040;'
                'border-radius:4px;padding:8px 20px;font-size:13px;cursor:pointer;">'
                '🌌 Open 3D CMD</button></div>'
            )
            html = html.replace("</body>", cmd_btn_html + "</body>")

        import webbrowser
        webbrowser.open("file://" + tmp.name)

        if settings.get("show_3d_cmd") and hasattr(self, "_cmd_3d_data"):
            from PyQt6.QtCore import QTimer
            QTimer.singleShot(500, lambda: self.show_3d_cmd(self._cmd_3d_data))

    def show_3d_cmd(self, data: dict):
        import os, tempfile, webbrowser, math
        import plotly.graph_objects as go

        settings  = data["settings"]
        bv        = data["bv"]
        mv        = data["mv"]
        names     = data["names"]
        urls      = data["urls"]
        teff      = data["teff"]
        spec      = data["spec"]
        colors    = data["colors"]
        plx_list  = data["plx"]

        use_ly     = settings["dist_units"] == "Light-years"
        use_log    = settings["dist_scale"] == "Logarithmic"
        custom_rng = settings["dist_range"] == "Custom"
        dist_min   = settings["dist_min"]
        dist_max   = settings["dist_max"]

        PC_TO_LY = 3.261563777

        # Build distance values, filter out bad parallaxes
        pts = []
        for i, plx in enumerate(plx_list):
            try:
                plx_f = float(plx)
                if plx_f <= 0:
                    continue
                dist_pc = 1000.0 / plx_f
                dist    = dist_pc * PC_TO_LY if use_ly else dist_pc
                pts.append({
                    "bv":    bv[i],
                    "mv":    mv[i],
                    "dist":  dist,
                    "name":  names[i],
                    "url":   urls[i],
                    "teff":  teff[i],
                    "spec":  spec[i],
                    "color": colors[i],
                })
            except Exception:
                continue

        if not pts:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "3D CMD",
                "No stars with valid parallax distances available.")
            return

        # Apply distance range filter
        if custom_rng:
            pts = [p for p in pts if dist_min <= p["dist"] <= dist_max]
        if not pts:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "3D CMD",
                "No stars within the specified distance range.")
            return

        dist_unit_label = "Distance (ly)" if use_ly else "Distance (pc)"

        xs     = [p["bv"]   for p in pts]
        ys     = [p["mv"]   for p in pts]
        zs     = [p["dist"] for p in pts]
        cols   = [p["color"] for p in pts]
        dist_label = "ly" if use_ly else "pc"
        hovers = [
            f"<b>{p['name']}</b><br>"
            f"B-V: {p['bv']:.3f}<br>"
            f"Abs V: {p['mv']:.2f}<br>"
            f"Distance: {p['dist']:.1f} {dist_label}<br>"
            f"Teff: {int(p['teff']):,} K  ({p['spec']})"
            for p in pts
        ]
        custom = [p["url"] for p in pts]

        scatter = go.Scatter3d(
            x=xs, y=ys, z=zs,
            mode="markers",
            marker=dict(
                color=cols,
                size=4,
                opacity=0.85,
                line=dict(width=0),
            ),
            hovertext=hovers,
            hoverinfo="text",
            customdata=custom,
            name=f"Stars ({len(pts)})",
        )

        # Distance iso-planes — faint reference planes at round distances
        dist_vals = sorted(set(p["dist"] for p in pts))
        d_min_act = min(dist_vals)
        d_max_act = max(dist_vals)

        # Pick 4-5 nice round reference distances
        import numpy as np
        if use_log:
            ref_dists = np.logspace(
                math.log10(max(d_min_act, 1)),
                math.log10(d_max_act),
                5
            ).tolist()
        else:
            ref_dists = np.linspace(d_min_act, d_max_act, 5).tolist()

        bv_range = [min(xs) - 0.1, max(xs) + 0.1]
        mv_range = [min(ys) - 0.5, max(ys) + 0.5]

        ref_planes = []
        for rd in ref_dists:
            rd_label = f"{rd:.0f} {'ly' if use_ly else 'pc'}"
            ref_planes.append(go.Scatter3d(
                x=[bv_range[0], bv_range[1], bv_range[1], bv_range[0]],
                y=[mv_range[0], mv_range[0], mv_range[1], mv_range[1]],
                z=[rd, rd, rd, rd],
                mode="lines",
                line=dict(color="rgba(255,255,255,0.12)", width=1),
                hoverinfo="skip",
                showlegend=False,
                name=rd_label,
            ))

        fig = go.Figure([scatter] + ref_planes)

        z_axis = dict(
            title=dist_unit_label,
            gridcolor="rgba(255,255,255,0.15)",
            showbackground=True,
            backgroundcolor="rgb(5,5,15)",
        )
        if use_log:
            z_axis["type"] = "log"
        if custom_rng:
            z_axis["range"] = [
                math.log10(dist_min) if use_log else dist_min,
                math.log10(dist_max) if use_log else dist_max,
            ]

        fig.update_layout(
            title=dict(
                text=f"3D Color-Magnitude Diagram  ·  {len(pts)} stars",
                font=dict(color="white"),
            ),
            paper_bgcolor="rgb(5,5,15)",
            scene=dict(
                xaxis=dict(
                    title="B-V color index",
                    gridcolor="rgba(255,255,255,0.15)",
                    showbackground=True,
                    backgroundcolor="rgb(5,5,15)",
                    tickfont=dict(color="white"),
                    title_font=dict(color="white"),
                ),
                yaxis=dict(
                    title="Absolute V magnitude",
                    autorange="reversed",
                    gridcolor="rgba(255,255,255,0.15)",
                    showbackground=True,
                    backgroundcolor="rgb(5,5,15)",
                    tickfont=dict(color="white"),
                    title_font=dict(color="white"),
                ),
                zaxis={**z_axis,
                    "tickfont": dict(color="white"),
                    "title_font": dict(color="white")},
                aspectmode="manual",
                aspectratio=dict(x=1.2, y=1.0, z=1.0),
                bgcolor="rgb(5,5,15)",
            ),
            margin=dict(l=0, r=0, b=0, t=50),
        )

        js = """
        <script>
        var gd = document.getElementsByClassName('plotly-graph-div')[0];
        gd.on('plotly_click', function(e){
            var url = e.points[0].customdata;
            if(url) window.open(url,'_blank');
        });
        </script>
        """

        html = fig.to_html(include_plotlyjs="cdn", full_html=True)
        html = html.replace("</body>", js + "</body>")

        tmp = tempfile.NamedTemporaryFile(
            delete=False, suffix=".html", mode="w", encoding="utf-8")
        tmp.write(html)
        tmp.close()
        webbrowser.open("file://" + tmp.name)

    def search_defined_region(self):
        """Perform a Simbad search for the defined region and filter by selected object types."""
        selected_types = self.get_selected_object_types()
        if not selected_types:
            QMessageBox.warning(self, "No Object Types Selected", "Please select at least one object type.")
            return

        # Calculate the radius in degrees for the defined region (circle radius)
        radius_deg = self.get_defined_radius()

        # Perform the Simbad search in the defined region with the calculated radius
        self.query_simbad(radius_deg)


    def search_entire_image(self):
        """Search the entire image using Simbad with selected object types."""
        selected_types = self.get_selected_object_types()  # Get selected types from the advanced search panel
        if not selected_types:
            QMessageBox.warning(self, "No Object Types Selected", "Please select at least one object type.")
            return

        # Calculate radius as the distance from the image center to a corner
        width, height = self.main_image.width(), self.main_image.height()
        center_x, center_y = width / 2, height / 2
        corner_x, corner_y = width, height  # Bottom-right corner
        # Calculate distance in pixels from center to corner
        radius_px = np.sqrt((corner_x - center_x) ** 2 + (corner_y - center_y) ** 2)
        # Convert radius from pixels to degrees
        radius_deg = float((radius_px * self.pixscale) / 3600.0)

        # Automatically set circle_center and circle_radius for the entire image
        self.circle_center = QPointF(center_x, center_y)  # Assuming QPointF is used
        self.circle_radius = radius_px  # Set this to allow the check in `query_simbad`

        # Perform the query with the calculated radius
        self.query_simbad(radius_deg, max_results=100000)


    def _iterate_leaf_items(self):
        """Yield every otype (child) under every category parent."""
        root = self.object_tree.invisibleRootItem()
        for i in range(root.childCount()):
            parent = root.child(i)
            for j in range(parent.childCount()):
                yield parent.child(j)


    def _update_parent_states(self):
        """Parents become checked if any child is checked, else unchecked."""
        root = self.object_tree.invisibleRootItem()
        for i in range(root.childCount()):
            parent = root.child(i)
            # if any child checked → parent checked, else unchecked
            any_checked = any(
                parent.child(j).checkState(0) == Qt.CheckState.Checked
                for j in range(parent.childCount())
            )
            parent.setCheckState(0, Qt.CheckState.Checked if any_checked else Qt.CheckState.Unchecked)


    def on_object_tree_item_changed(self, item, column):
        # parent toggled → mirror to all children
        if item.childCount() > 0:
            state = item.checkState(0)
            blocker = QSignalBlocker(self.object_tree)
            for i in range(item.childCount()):
                item.child(i).setCheckState(0, state)
            blocker.unblock()
        # child toggled → recompute only its parent
        else:
            parent = item.parent()
            if not parent:
                return
            # parent checked if any child is
            any_checked = any(
                parent.child(i).checkState(0) == Qt.CheckState.Checked
                for i in range(parent.childCount())
            )
            blocker = QSignalBlocker(self.object_tree)
            parent.setCheckState(0, Qt.CheckState.Checked if any_checked else Qt.CheckState.Unchecked)
            blocker.unblock()


    def toggle_all_items(self):
        """Check/uncheck all otype leaf items."""
        leaves      = list(self._iterate_leaf_items())
        all_checked = all(li.checkState(0) == Qt.CheckState.Checked for li in leaves)
        new_state   = Qt.CheckState.Unchecked if all_checked else Qt.CheckState.Checked

        blocker = QSignalBlocker(self.object_tree)
        for li in leaves:
            li.setCheckState(0, new_state)
        blocker.unblock()

        self._update_parent_states()


    def save_custom_list(self):
        """
        Serializes the currently checked otypes to a .json file.
        """
        types = self.get_selected_object_types()
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Custom Type List",
            "",
            "JSON Files (*.json)"
        )
        if not path:
            return
        if not path.lower().endswith(".json"):
            path += ".json"
        try:
            with open(path, "w") as f:
                json.dump(types, f, indent=2)
            self.status_label.setText(f"👍 Saved list to {os.path.basename(path)}")
        except Exception as e:
            QMessageBox.critical(self, "Save Failed", str(e))


    def load_custom_list(self):
        """
        Reads a .json of otype codes and re-checks only those.
        """
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Load Custom Type List",
            "",
            "JSON Files (*.json)"
        )
        if not path:
            return

        try:
            with open(path, "r") as f:
                types = set(json.load(f))
        except Exception as e:
            QMessageBox.critical(self, "Load Failed", str(e))
            return

        # block signals so we don't recurse
        blocker = QSignalBlocker(self.object_tree)
        for li in self._iterate_leaf_items():
            li.setCheckState(
                0,
                Qt.CheckState.Checked if li.text(0) in types else Qt.CheckState.Unchecked
            )
        blocker.unblock()

        # now update parents
        self._update_parent_states()
        self.status_label.setText(f"📂 Loaded list from {os.path.basename(path)}")

    def toggle_advanced_search(self):
        """Toggle the visibility of the advanced search panel."""
        is_visible = self.advanced_search_panel_widget.isVisible()
        self.advanced_search_panel_widget.setVisible(not is_visible)

    def save_results_as_csv(self):
        """
        Save the results from the TreeWidget as CSV.

        - Always writes all columns currently shown in self.results_tree.
        - If self.query_results is present (Simbad star query), append extra
        stellar columns (B, V, B-V, Abs V, parallax, distance, spectral type, source)
        matched by name.
        """
        path, _ = QFileDialog.getSaveFileName(
            self, "Save CSV", "", "CSV Files (*.csv)"
        )
        if not path:
            return
        if not path.lower().endswith(".csv"):
            path += ".csv"

        tree = self.results_tree
        if tree.topLevelItemCount() == 0:
            QMessageBox.information(self, "No Data", "There are no results to save.")
            return

        # --- 1) Base headers from the tree itself (old behaviour) ---
        col_count = tree.columnCount()
        header_item = tree.headerItem()
        base_headers = [
            header_item.text(c) if header_item is not None else f"Col{c}"
            for c in range(col_count)
        ]

        # Find which column is the "name" column (to match against query_results)
        name_col = None
        for idx, lbl in enumerate(base_headers):
            txt = (lbl or "").strip().lower()
            if txt in ("name", "object", "main id", "id"):
                name_col = idx
                break

        # --- 2) Build a map from name → rich SIMBAD dict (if present) ---
        extra_by_name = {}
        qr = getattr(self, "query_results", None)
        if isinstance(qr, list):
            for obj in qr:
                nm = obj.get("name")
                if not nm:
                    continue
                # if duplicates exist, first wins; good enough for our CSV
                extra_by_name.setdefault(nm, obj)

        # Helper for float formatting
        def fmt(x, nd=6):
            import numpy as _np
            if isinstance(x, (int, float)) and _np.isfinite(x):
                return f"{x:.{nd}f}"
            return "" if x is None else str(x)

        # Extra headers only if we actually have extra data
        extra_headers = []
        if extra_by_name:
            extra_headers = [
                "B mag",
                "V mag",
                "B-V",
                "Absolute V mag",
                "Parallax (mas)",
                "Distance (pc)",
                "Distance (ly)",
                "Spectral Type",
                "Source",
            ]

        with open(path, mode='w', newline='', encoding="utf-8") as file:
            writer = csv.writer(file)

            # Write combined header row
            writer.writerow(base_headers + extra_headers)

            # --- 3) Write one row per tree item, augmenting with extra data if we have it ---
            for i in range(tree.topLevelItemCount()):
                item = tree.topLevelItem(i)
                row_data = [item.text(col) for col in range(col_count)]

                extra_row = []
                if extra_headers and name_col is not None:
                    obj_name = row_data[name_col]
                    obj = extra_by_name.get(obj_name)

                    if obj:
                        Bmag = obj.get("Bmag")
                        Vmag = obj.get("Vmag")
                        absV = obj.get("absolute_mag")
                        plx  = obj.get("parallax_mas")
                        spec = obj.get("spectral_type", "")
                        src  = obj.get("source", "")

                        # Derived quantities
                        if isinstance(Bmag, (int, float)) and isinstance(Vmag, (int, float)):
                            b_minus_v = Bmag - Vmag
                        else:
                            b_minus_v = None

                        dist_pc = dist_ly = None
                        if isinstance(plx, (int, float)) and plx > 0:
                            dist_pc = 1000.0 / plx
                            dist_ly = dist_pc * 3.261563777

                        extra_row = [
                            fmt(Bmag),
                            fmt(Vmag),
                            fmt(b_minus_v),
                            fmt(absV),
                            fmt(plx),
                            fmt(dist_pc),
                            fmt(dist_ly),
                            spec or "",
                            src or "",
                        ]
                    else:
                        # No extra data for this row → keep columns blank
                        extra_row = [""] * len(extra_headers)

                writer.writerow(row_data + extra_row)

        QMessageBox.information(self, "CSV Saved",
                                f"Results successfully saved to {path}")


      

    def filter_visible_objects(self):
        """Filter objects based on visibility threshold."""
        if not self.main_image:  # Ensure there's an image loaded
            QMessageBox.warning(self, "No Image", "Please load an image first.")
            return

        n = 0.2  # Threshold multiplier, adjust as needed
        median, std_dev = self.calculate_image_statistics(self.main_image)

        # Remove objects below threshold from results
        filtered_results = []
        for obj in self.results:
            if self.is_marker_visible(obj, median, std_dev, n):
                filtered_results.append(obj)

        # Update the results and redraw the markers
        self.results = filtered_results
        self.main_preview.results = filtered_results
        self.update_results_tree()
        self.main_preview.draw_query_results()

    def calculate_image_statistics(self, image):
        """Calculate median and standard deviation for a grayscale image efficiently using OpenCV."""
        
        # Convert QPixmap to QImage if necessary
        qimage = image.toImage()

        # Convert QImage to a format compatible with OpenCV
        width = qimage.width()
        height = qimage.height()
        ptr = qimage.bits()
        ptr.setsize(height * width * 4)  # 4 channels (RGBA)
        img_array = np.array(ptr).reshape(height, width, 4)  # Convert to RGBA array

        # Convert to grayscale for analysis
        gray_image = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)

        # Calculate median and standard deviation
        median = np.median(gray_image)
        _, std_dev = cv2.meanStdDev(gray_image)

        return median, std_dev[0][0]  # std_dev returns a 2D array, so we extract the single value
    
    def is_marker_visible(self, marker, median, std_dev, n):
        """Check if the marker's brightness is above the threshold."""
        threshold = median + n * std_dev
        check_size = 8  # Define a 4x4 region around the marker

        # Convert QPixmap to QImage to access pixel colors
        image = self.main_image.toImage()

        # Get marker coordinates in pixel space
        ra, dec = marker.get('ra'), marker.get('dec')
        if ra is not None and dec is not None:
            x, y = self.calculate_pixel_from_ra_dec(ra, dec)
            if x is None or y is None:
                return False  # Skip marker if it can't be converted to pixels
        else:
            return False

        # Calculate brightness in a 4x4 region around marker coordinates
        brightness_values = []
        for dx in range(-check_size // 2, check_size // 2):
            for dy in range(-check_size // 2, check_size // 2):
                px = x + dx
                py = y + dy
                if 0 <= px < image.width() and 0 <= py < image.height():
                    color = image.pixelColor(px, py)  # Get color from QImage
                    brightness = color.value() if color.isValid() else 0  # Adjust for grayscale
                    brightness_values.append(brightness)

        if brightness_values:
            average_brightness = sum(brightness_values) / len(brightness_values)
            return average_brightness > threshold
        else:
            return False



    def update_results_tree(self):
        """Refresh the TreeWidget to reflect current results."""
        self.results_tree.clear()
        for obj in self.results:
            z_cell, plx_cell, dist_cell = wimi_result_columns(obj)
            item = QTreeWidgetItem([
                str(obj['ra']),
                str(obj['dec']),
                obj['name'],
                str(obj.get('diameter_display', obj['diameter'])),
                obj['short_type'],
                obj['long_type'],
                z_cell,
                plx_cell,
                dist_cell,
                str(obj.get('mag_display', '')),
            ])
            self.results_tree.addTopLevelItem(item)

    # Function to clear search results and remove markers
    def clear_search_results(self):
        """Clear the search results and remove all markers."""
        self.results_tree.clear()        # Clear the results from the tree
        self.results = []                # Clear the results list
        self.main_preview.results = []   # Clear results from the main preview
        self.main_preview.selected_object = None
        self.main_preview.draw_query_results()  # Redraw the main image without markers
        self.status_label.setText("Results cleared.")

    def on_tree_current_item_changed(self, current, previous):
        """Keep arrow-key navigation in sync with the main preview, same as a click."""
        if current is None:
            return
        object_name = current.text(2)

        selected_object = next(
            (obj for obj in self.results if obj.get("name") == object_name), None
        )
        if selected_object:
            # Set directly instead of calling main_preview.select_object,
            # which toggles and would deselect on a normal click (itemClicked
            # already calls select_object for that path).
            self.main_preview.selected_object = selected_object
            self.selected_object = selected_object
            self._set_selected_name(selected_object.get("name"))
            self.main_preview.draw_query_results()
            self.main_preview.update_mini_preview()

    def on_tree_item_clicked(self, item):
        """Handle item click in the TreeWidget to highlight the associated object."""
        object_name = item.text(2)

        # Find the object in results
        selected_object = next(
            (obj for obj in self.results if obj.get("name") == object_name), None
        )

        if selected_object:
            # Update the preview directly. Do NOT call main_preview.select_object()
            # here: it calls results_tree.setCurrentItem(), which collapses a
            # Shift/Ctrl multi-selection down to just the row that was clicked.
            self.selected_object = selected_object
            self.main_preview.selected_object = selected_object
            self._set_selected_name(selected_object.get("name"))
            self.main_preview.draw_query_results()
            self.main_preview.update_mini_preview() 
            
    def on_tree_item_double_clicked(self, item):
        """Handle double-click event on a TreeWidget item to open SIMBAD or NED URL based on source."""
        object_name = item.text(2)  # Assuming 'Name' is in the third column

        # parse only if float() fails
        def parse_value(txt):
            try:
                return float(txt)
            except ValueError:
                parts = txt.strip().split()
                if len(parts) == 3:
                    a, b, c = parts
                    sign = -1 if a.startswith('-') else 1
                    return sign * (abs(float(a)) + float(b)/60 + float(c)/3600)
                raise

        ra  = parse_value(item.text(0).strip())
        dec = parse_value(item.text(1).strip())

        # lookup, falling back to string→float only on failure
        def get_parsed(result, key):
            try:
                return float(result[key])
            except ValueError:
                return parse_value(result[key])

        def _close(a, b, tol=1e-6):
            return abs(a - b) <= tol

        entry = next(
            (r for r in self.query_results
            if _close(get_parsed(r, 'ra'), ra) and _close(get_parsed(r, 'dec'), dec)),
            None
        )
        source = (entry.get('source') if entry else 'Simbad') or 'Simbad'
        print(f"[DEBUG] Matched source: {source!r}")  # ← debug print

        s = source.strip().lower()
        # --- Minor-body rows (local MinorDB results) → choose how to explore ----
        if s.startswith("minordb"):
            kind = (entry.get("long_type") if entry else "") or ""
            # 'kind' will usually be "Asteroid" or "Comet"
            prompt_minor_body_choice(self, object_name, kind=kind)
            return
        
        if s == "simbad" and object_name:
            encoded = quote(object_name)
            webbrowser.open(
                f"https://simbad.cds.unistra.fr/simbad/sim-basic?"
                f"Ident={encoded}&submit=SIMBAD+search"
            )

        elif "viz" in s:   # catches 'Vizier', etc.
            radius   = 5/60  # arcminutes
            dec_sign = "%2B" if dec >= 0 else "-"
            webbrowser.open(
                f"http://ned.ipac.caltech.edu/conesearch?"
                f"search_type=Near%20Position%20Search&"
                f"ra={ra:.6f}d&"
                f"dec={dec_sign}{abs(dec):.6f}d&"
                f"radius={radius:.3f}&"
                "in_csys=Equatorial&in_equinox=J2000.0"
            )

        elif s == "mast":
            webbrowser.open(
                f"https://mast.stsci.edu/portal/Mashup/Clients/Mast/Portal.html?"
                f"searchQuery={ra}%2C{dec}%2Cradius%3D0.0006"
            )
           

    def copy_ra_dec_to_clipboard(self):
        """Copy the currently displayed RA and Dec to the clipboard."""
        # Access the RA and Dec labels directly
        ra_text = self.ra_label.text()
        dec_text = self.dec_label.text()
        
        # Combine RA and Dec text for clipboard
        clipboard_text = f"{ra_text}, {dec_text}"
        
        clipboard = QApplication.instance().clipboard()
        clipboard.setText(clipboard_text)
        
        QMessageBox.information(self, "Copied", "Current RA/Dec copied to clipboard!")
    
    def _load_from_view(self, doc):
        """
        Accepts a pro.doc_manager.ImageDocument and loads:
        - image pixels
        - best-available astrometric solution:
            1) metadata['wcs_header'] (preferred if present)
            2) metadata['original_header'] if it contains WCS
            3) XISF metadata (image_meta/file_meta) converted into a FITS-like header
        """
        if doc is None or getattr(doc, "image", None) is None:
            QMessageBox.information(self, "Load from View", "That view has no image data.")
            return

        self._loaded_doc = doc 

        # 1) show pixels
        self._set_image_from_array(doc.image)

        # 2) pick a header
        meta = dict(getattr(doc, "metadata", {}) or {})
        header = None

        # Keep this view's SASpro metadata reachable for the observation-time
        # lookup. SASpro carries DATE-OBS / DATE-LOC / EXPTIME in the image
        # metadata (FITSKeywords), and a plate solve updates that same
        # metadata, so the timestamp is already here — there is no need to go
        # digging for a separate original_header. Also drop any cached
        # observation time so the newly loaded view is re-read rather than
        # reusing the previous image's timestamp.
        self._loaded_meta = meta
        self.observation_datetime = None

        # prefer an explicit WCS header saved by a solver
        if "wcs_header" in meta and meta["wcs_header"]:
            header = meta["wcs_header"]

        # otherwise try the original FITS header (if present and looks like WCS)
        orig_hdr = meta.get("original_header")
        if header is None and self.check_astrometry_data(orig_hdr):
            header = orig_hdr

        # otherwise try to synthesize from XISF metadata we may have stored
        if header is None:
            xim = meta.get("image_meta") or meta.get("XISF") or {}
            try:
                candidate = self.construct_fits_header_from_xisf(xim) if xim else None
            except Exception:
                candidate = None
            if candidate and self.check_astrometry_data(candidate):
                header = candidate

        if header is None:
            QMessageBox.information(self, "Blind Solve", "No WCS found.\nPerforming blind solve…")
            if not self._ensure_wcs_on_doc(doc):
                self.wcs = None
                self.status_label.setText("Status: Loaded view (no WCS) — auto-solve failed.")
                return
            # refresh from doc after solving
            meta = dict(getattr(doc, "metadata", {}) or {})
            header = meta.get("wcs_header") or meta.get("original_header")

        # 3) initialize WCS if we found/created a header
        if header is not None:
            try:
                header = self._sanitize_wcs_header(header)
                self.initialize_wcs_from_header(header)
                self.status_label.setText("Status: Loaded view with astrometric solution.")
                QTimer.singleShot(0, self._fetch_atlas_catalog)
            except Exception as e:
                self.wcs = None
                self.status_label.setText(f"Status: Loaded view (no valid WCS) — {e}")
        else:
            self.wcs = None
            self.status_label.setText("Status: Loaded view (no astrometric solution found).")

    def _set_image_from_array(self, arr: np.ndarray):
        self.image_data = arr
        img = arr
        if img is None:
            return
        # float32 [0..1] → uint8
        if img.dtype != np.uint8:
            img = np.clip(img, 0.0, 1.0)
            if img.ndim == 2:
                img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
            img = (img * 255.0).astype(np.uint8)
        elif img.ndim == 2:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)

        h, w = img.shape[:2]
        bytes_per_line = 3 * w
        qimg = QImage(img.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
        pm = QPixmap.fromImage(qimg)

        self.main_image = pm
        if self.main_scene is None:
            self.main_scene = QGraphicsScene(self)
            self.main_preview.setScene(self.main_scene)
        self.main_scene.clear()
        self.main_scene.addPixmap(pm)
        self.main_preview.setSceneRect(QRectF(pm.rect()))
        self.main_preview.resetTransform()
        self._update_scene_margins()
        self.main_preview.centerOn(self.main_scene.sceneRect().center())


        self._ensure_marker_layer()
        # If you already have results from a prior query, show them over the new image:
        self._set_marker_points_from_results()
        # keep your mini-preview sync code if you have it
        if hasattr(self, "mini_preview") and self.mini_preview is not None:
            scaled = pm.scaled(self.mini_preview.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            self.mini_preview.setPixmap(scaled)

        # Fit to preview after layout settles so viewport size is accurate
        QTimer.singleShot(0, lambda: (self.fit_to_preview(), self.update_green_box()))


    @pyqtSlot()
    def open_image(self):
        """Slot for the “Load...” button — always pops up the file dialog."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Image", "", 
            "Images (*.png *.jpg *.jpeg *.tif *.tiff *.fit *.fits *.xisf)"
        )
        if path:
            self._load_image(path)

    def load_image_path(self, path: str):
        """Call this when you already know the filename."""
        if path:
            self._load_image(path)

    @staticmethod
    def _clean_wcs_value(v):
        """
        Repair a single header value. Handles the bad-card-slice leak where a
        numeric value keeps its '=' separator and padding, e.g.
        ' =      3473.8688852069'. Strips the stray '=', quotes and whitespace
        and returns a number when the value clearly is one; otherwise returns
        the original string untouched (so CTYPE1='RA---TAN' is preserved).
        """
        import numpy as np
        if isinstance(v, (bool, int, float, np.integer, np.floating)) or v is None:
            return v
        s = str(v).strip()
        if (s.startswith("'") and s.endswith("'")) or (s.startswith('"') and s.endswith('"')):
            s = s[1:-1].strip()
        if s.startswith("="):
            s = s[1:].strip()
        try:
            if s.lstrip("+-").isdigit():
                return int(s)
            return float(s)
        except Exception:
            return str(v)

    def _normalize_wcs_header(self, header):
        """
        Coerce any header-like (fits.Header, dict, snapshot dict, or raw string)
        into a clean fits.Header, repairing malformed values along the way.
        Never raises; returns a (possibly empty) fits.Header.
        """
        from astropy.io import fits

        if isinstance(header, str):
            h = None
            for sep in ("\n", ""):
                try:
                    parsed = fits.Header.fromstring(header, sep=sep)
                    if len(parsed) > 0:
                        h = parsed
                        break
                except Exception:
                    h = None
            if not isinstance(h, fits.Header):
                h = fits.Header()

        elif isinstance(header, dict):
            fmt = header.get("format")
            h = fits.Header()
            if fmt == "fits-cards" and isinstance(header.get("cards"), list):
                for card in header["cards"]:
                    try:
                        k = str(card[0]).strip()
                        if not k:
                            continue
                        val = self._clean_wcs_value(card[1])
                        cm = str(card[2]) if len(card) > 2 else ""
                        h[k] = (val, cm)
                    except Exception:
                        continue
                return h
            src = header.get("items") if (fmt == "dict" and isinstance(header.get("items"), dict)) else header
            for k, v in src.items():
                try:
                    kk = str(k).strip()
                    if not kk or kk in ("format", "items", "cards", "text"):
                        continue
                    h[kk] = self._clean_wcs_value(v)
                except Exception:
                    continue
            return h

        elif isinstance(header, fits.Header):
            h = header.copy()
        else:
            return fits.Header()

        # Value-repair pass (fixes the stray '=' leak on an already-built Header)
        for key in list(h.keys()):
            if not key or key in ("COMMENT", "HISTORY"):
                continue
            try:
                cur = h[key]
            except Exception:
                continue
            if not isinstance(cur, str):
                continue
            cleaned = self._clean_wcs_value(cur)
            if cleaned != cur:
                try:
                    h[key] = cleaned
                except Exception:
                    pass

        return h

    def _sanitize_wcs_header(self, header):
        """
        Coerce WCS/SIP keywords to proper numeric types and fix common SIP issues.
        If SIP remains inconsistent, drop SIP keywords so astropy WCS can still load.
        """
        from copy import deepcopy
        import numpy as np

        hdr = self._normalize_wcs_header(header)

        def _to_int(key):
            if key in hdr:
                try:
                    v = hdr[key]
                    if isinstance(v, (int, np.integer)):
                        return
                    # handle strings like '2' or '2.0'
                    hdr[key] = int(float(str(v).strip().strip("'\"")))
                except Exception:
                    # if it's garbage, remove it so we can fall back cleanly
                    del hdr[key]

        def _to_float(key):
            if key in hdr:
                try:
                    v = hdr[key]
                    if isinstance(v, (float, int, np.floating, np.integer)):
                        hdr[key] = float(v)
                    else:
                        hdr[key] = float(str(v).strip().strip("'\""))
                except Exception:
                    # if it's truly bad, just leave it; astropy may ignore it
                    pass

        # 1) Ensure core integer fields
        for k in ("NAXIS", "NAXIS1", "NAXIS2", "A_ORDER", "B_ORDER", "AP_ORDER", "BP_ORDER"):
            _to_int(k)

        # 2) Mirror missing A/B order if only one is present
        a_order = hdr.get("A_ORDER")
        b_order = hdr.get("B_ORDER")
        if (a_order is None) ^ (b_order is None):
            try:
                val = int(a_order if a_order is not None else b_order)
                hdr["A_ORDER"] = val
                hdr["B_ORDER"] = val
            except Exception:
                # will be handled by SIP drop step below
                pass

        # 3) Coerce SIP coefficients to float
        for key in list(hdr.keys()):
            if key in ("A_ORDER", "B_ORDER", "AP_ORDER", "BP_ORDER"):
                continue
            if key.startswith(("A_", "B_", "AP_", "BP_")):
                try:
                    _to_float(key)
                except Exception:
                    # if a specific coeff is junk, remove it
                    try:
                        del hdr[key]
                    except Exception:
                        pass

        # 4) Coerce standard WCS numeric keywords to float
        for key in list(hdr.keys()):
            if key.startswith(("CD", "PC", "CDELT", "CRVAL", "CRPIX", "CROTA")) or key in ("EQUINOX", "EPOCH", "LONPOLE", "LATPOLE"):
                _to_float(key)

        # 5) If SIP is still inconsistent, drop SIP so WCS loads without distortion
        a_order = hdr.get("A_ORDER")
        b_order = hdr.get("B_ORDER")
        sip_ok = (a_order is not None and b_order is not None)
        if not sip_ok:
            for key in list(hdr.keys()):
                if key in ("A_ORDER", "B_ORDER", "AP_ORDER", "BP_ORDER") or key.startswith(("A_", "B_", "AP_", "BP_")):
                    del hdr[key]
            # Also remove "-SIP" tag from CTYPE if present to avoid implying SIP
            for c in ("CTYPE1", "CTYPE2"):
                if c in hdr and isinstance(hdr[c], str) and "SIP" in hdr[c]:
                    hdr[c] = hdr[c].replace("-SIP", "")

        return hdr

    def _load_image(self, path: str):
        """
        Load pixels and WCS like _load_from_view:
        1) use embedded WCS if present and valid
        2) try to synthesize from XISF metadata
        3) otherwise auto-solve (ASTAP → Astrometry.net)
        """
        img_array, original_header, bit_depth, is_mono = load_image(path)
        self.image_path = path
        if img_array is None:
            QMessageBox.warning(self, "Open Image", "Could not load the selected file.")
            return

        # persist basics
        self.image_data = img_array
        self.original_header = original_header
        # A fresh file: forget any cached observation time and view metadata
        # so the time is re-read from THIS file's header, not the last one.
        self.observation_datetime = None
        self._loaded_meta = None
        self.bit_depth = bit_depth
        self.is_mono = is_mono

        # 1) show pixels (same renderer used by _load_from_view)
        self._set_image_from_array(img_array)

        # 2) choose a header using the same order as _load_from_view
        header = None

        # prefer an explicit/embedded WCS header (from FITS or what load_image provided)
        if self.check_astrometry_data(original_header):
            header = original_header

        # otherwise try to synthesize from XISF metadata
        if header is None and path.lower().endswith(".xisf"):
            xisf_meta = self.extract_xisf_metadata(path)
            try:
                candidate = self.construct_fits_header_from_xisf(xisf_meta) if xisf_meta else None
            except Exception:
                candidate = None
            if candidate and self.check_astrometry_data(candidate):
                header = candidate

        # 3) if we found/created a header → sanitize and init WCS
        if header is not None:
            try:
                header = self._sanitize_wcs_header(header)
                self.initialize_wcs_from_header(header)
                self.status_label.setText("Status: Loaded image with astrometric solution.")
                return
            except Exception as e:
                # embedded header present but unusable → fall through to auto-solve
                self.wcs = None
                self.status_label.setText(f"Status: Embedded WCS invalid — {e}. Attempting auto-solve…")
                QApplication.processEvents()

        # 4) no valid WCS → follow the same auto-solve path as _load_from_view
        #    (ASTAP first; if that fails, Astrometry.net)
        self.status_label.setText("Status: No WCS found. Performing auto-solve…")
        QMessageBox.information(self, "Auto-Solve", "No astrometric solution found.\nPerforming auto-solve…")
        QApplication.processEvents()


        doc = self._doc_for_solver()  # returns the view doc if present, else adapter around image_data
        if doc is None:
            QMessageBox.warning(self, "Auto-Solve", "No image loaded.")
            return

        mw = _find_main_window(self) or self.parent()
        settings = getattr(mw, "settings", QSettings())

        prev_mode = _get_seed_mode(settings)
        try:
            # ensure it’s blind for this first solve
            _set_seed_mode(settings, "none")
            ok, res = plate_solve_doc_inplace(mw, doc, settings)
        finally:
            _set_seed_mode(settings, prev_mode)

        if ok:
            meta = getattr(doc, "metadata", {}) or {}
            hdr = meta.get("wcs_header") or meta.get("original_header")
            try:
                if hdr is None:
                    raise RuntimeError("Solver returned no header.")
                self.initialize_wcs_from_header(hdr)
                self.status_label.setText("Status: Blind solve succeeded.")
            except Exception as e:
                self.status_label.setText(f"Status: WCS init failed — {e}")
                QMessageBox.warning(self, "Apply WCS", f"Solve succeeded but WCS init failed: {e}")
        else:
            self.status_label.setText(f"Status: Blind solve failed — {res}")
            QMessageBox.critical(self, "Auto-Solve Failed", str(res))

    def extract_xisf_metadata(self, xisf_path):
        """
        Extract metadata from a .xisf file, focusing on WCS and essential image properties.
        """
        try:
            # Load the XISF file
            xisf = XISF(xisf_path)
            
            # Extract file and image metadata
            self.file_meta = xisf.get_file_metadata()
            self.image_meta = xisf.get_images_metadata()[0]  # Get metadata for the first image
            return self.image_meta
        except Exception as e:
            print(f"Error reading XISF metadata: {e}")
            return None

    def initialize_wcs_from_header(self, header):
        """ Initialize WCS data from a FITS header or constructed XISF header """
        from astropy.io import fits

        # Always keep a clean fits.Header on self.header. Repairs cards whose
        # values leaked a stray '=' from bad card slicing upstream, e.g.
        # CRPIX1 stored as the string ' =      3473.8688852069'.
        self.header = self._normalize_wcs_header(header)

        try:
            # Build WCS — request naxis=2 but also guard against color cubes
            # that report 3+ axes even when naxis=2 is specified
            wcs_raw = WCS(self.header, naxis=2, relax=True)
            if wcs_raw.naxis > 2:
                self.wcs = wcs_raw.celestial
            else:
                self.wcs = wcs_raw

            # Sanity-check: celestial may still return a non-2D WCS on weird headers
            if self.wcs.naxis != 2:
                raise ValueError(
                    f"Could not reduce WCS to 2 celestial axes (got {self.wcs.naxis})."
                )

            # Pixel scale
            from astropy.wcs.utils import proj_plane_pixel_scales
            scales = proj_plane_pixel_scales(self.wcs) * 3600.0   # arcsec/pixel
            self.pixscale = float(np.mean(scales))

            # Reference coordinate — crval may have >2 elements on a reduced WCS
            crval = self.wcs.wcs.crval
            self.center_ra  = float(crval[0])
            self.center_dec = float(crval[1])

            self.wcs_header = self.wcs.to_header(relax=True)
            self.print_corner_coordinates()

            # Debugging
            print(f"Header CROTA2 Value: {header.get('CROTA2', 'Not Found')}")

            # Orientation
            def _cd_orientation(hdr):
                c11 = hdr.get("CD1_1"); c12 = hdr.get("CD1_2")
                c21 = hdr.get("CD2_1"); c22 = hdr.get("CD2_2")
                pc11 = hdr.get("PC1_1"); pc12 = hdr.get("PC1_2")
                pc21 = hdr.get("PC2_1"); pc22 = hdr.get("PC2_2")
                if None not in (c11, c12, c21, c22):
                    return np.degrees(np.arctan2(-c12, c11))
                if None not in (pc11, pc12, pc21, pc22):
                    cdelt1 = float(hdr.get("CDELT1", 1.0))
                    return np.degrees(np.arctan2(-pc12 * cdelt1, pc11 * cdelt1))
                return None

            if 'CROTA2' in self.header:
                try:
                    self.orientation = float(self.header['CROTA2'])
                except Exception:
                    self.orientation = _cd_orientation(self.header)
            else:
                self.orientation = _cd_orientation(self.header)

            if self.orientation is not None:
                try:
                    self.orientation = float(self.orientation)
                    print(f"Orientation: {self.orientation:.2f}°")
                    self.orientation_label.setText(f"Orientation: {self.orientation:.2f}°")
                except (ValueError, TypeError):
                    print("Final conversion failed. Orientation is not a float.")
                    self.orientation_label.setText("Orientation: N/A")
            else:
                print("Orientation is None.")
                self.orientation_label.setText("Orientation: N/A")

            print(f"WCS data loaded: RA={self.center_ra}, Dec={self.center_dec}, "
                  f"Pixel Scale={self.pixscale} arcsec/px")

            QTimer.singleShot(0, self._fetch_atlas_catalog)

        except ValueError as e:
            raise ValueError(f"WCS initialization error: {e}")

    def construct_fits_header_from_xisf(self, xisf_meta):
        """ Convert XISF metadata to a FITS header compatible with WCS """
        header = fits.Header()

        # numeric‐only keys (everything except CTYPE1/2)
        numeric_keys = {
            "CRPIX1", "CRPIX2", "CRVAL1", "CRVAL2",
            "CDELT1", "CDELT2", "A_ORDER", "B_ORDER",
            "AP_ORDER", "BP_ORDER"
        }

        for keyword, entries in xisf_meta.get('FITSKeywords', {}).items():
            for entry in entries:
                if 'value' not in entry:
                    continue
                val = entry['value']
                if keyword in ("CTYPE1", "CTYPE2"):
                    # always a string
                    header[keyword] = val
                elif keyword in numeric_keys:
                    # try integer, then float
                    try:
                        header[keyword] = int(val)
                    except (ValueError, TypeError):
                        header[keyword] = float(val)
                else:
                    # anything else just store raw
                    header[keyword] = val

        # ensure CTYPEs exist
        header.setdefault('CTYPE1', 'RA---TAN')
        header.setdefault('CTYPE2', 'DEC--TAN')

        # Add SIP distortion suffix if SIP coefficients are present
        if any(key in header for key in ["A_ORDER", "B_ORDER", "AP_ORDER", "BP_ORDER"]):
            header['CTYPE1'] = 'RA---TAN-SIP'
            header['CTYPE2'] = 'DEC--TAN-SIP'

        # Set default reference pixel to the center of the image
        header.setdefault('CRPIX1', self.image_data.shape[1] / 2)
        header.setdefault('CRPIX2', self.image_data.shape[0] / 2)

        # Retrieve RA and DEC values if available
        if 'RA' in xisf_meta['FITSKeywords']:
            header['CRVAL1'] = float(xisf_meta['FITSKeywords']['RA'][0]['value'])  # Reference RA
        if 'DEC' in xisf_meta['FITSKeywords']:
            header['CRVAL2'] = float(xisf_meta['FITSKeywords']['DEC'][0]['value'])  # Reference DEC

        # Calculate pixel scale if focal length and pixel size are available
        if 'FOCALLEN' in xisf_meta['FITSKeywords'] and 'XPIXSZ' in xisf_meta['FITSKeywords']:
            focal_length = float(xisf_meta['FITSKeywords']['FOCALLEN'][0]['value'])  # in mm
            pixel_size = float(xisf_meta['FITSKeywords']['XPIXSZ'][0]['value'])  # in μm
            pixel_scale = (pixel_size * 206.265) / focal_length  # arcsec/pixel
            header['CDELT1'] = -pixel_scale / 3600.0
            header['CDELT2'] = pixel_scale / 3600.0
        else:
            header['CDELT1'] = -2.77778e-4  # ~1 arcsecond/pixel
            header['CDELT2'] = 2.77778e-4

        # Populate CD matrix using the XISF LinearTransformationMatrix if available
        if 'XISFProperties' in xisf_meta and 'PCL:AstrometricSolution:LinearTransformationMatrix' in xisf_meta['XISFProperties']:
            linear_transform = xisf_meta['XISFProperties']['PCL:AstrometricSolution:LinearTransformationMatrix']['value']
            header['CD1_1'] = linear_transform[0][0]
            header['CD1_2'] = linear_transform[0][1]
            header['CD2_1'] = linear_transform[1][0]
            header['CD2_2'] = linear_transform[1][1]
        else:
            # Use pixel scale for CD matrix if no linear transformation is defined
            header['CD1_1'] = header['CDELT1']
            header['CD1_2'] = 0.0
            header['CD2_1'] = 0.0
            header['CD2_2'] = header['CDELT2']

        # Ensure numeric types for SIP distortion keywords if present
        sip_keywords = ["A_ORDER", "B_ORDER", "AP_ORDER", "BP_ORDER"]
        for sip_key in sip_keywords:
            if sip_key in xisf_meta['XISFProperties']:
                try:
                    value = xisf_meta['XISFProperties'][sip_key]['value']
                    header[sip_key] = int(value) if isinstance(value, str) and value.isdigit() else float(value)
                except ValueError:
                    pass  # Ignore any invalid conversion

        return header

    def print_corner_coordinates(self):
        """Print the RA/Dec coordinates of the four corners of the image for debugging purposes."""
        if not hasattr(self, 'wcs'):
            print("WCS data is incomplete, cannot calculate corner coordinates.")
            return

        width = self.main_image.width()
        height = self.main_image.height()

        # Define the corner coordinates
        corners = {
            "Top-Left": (0, 0),
            "Top-Right": (width, 0),
            "Bottom-Left": (0, height),
            "Bottom-Right": (width, height)
        }

        print("Corner RA/Dec coordinates:")
        for corner_name, (x, y) in corners.items():
            ra, dec = self.calculate_ra_dec_from_pixel(x, y)
            ra_hms = self.convert_ra_to_hms(ra)
            dec_dms = self.convert_dec_to_dms(dec)
            print(f"{corner_name}: RA={ra_hms}, Dec={dec_dms}")

    def calculate_ra_dec_from_pixel(self, x, y):
        if not hasattr(self, 'wcs') or self.wcs is None:
            return None, None
        ra, dec = self.wcs.pixel_to_world_values(x, y)
        return float(ra), float(dec)
                        


    def update_ra_dec_from_mouse(self, event):
        """Update RA and Dec based on mouse position over the main preview."""
        if self.main_image and self.wcs:
            pos = self.main_preview.mapToScene(event.pos())
            x, y = int(pos.x()), int(pos.y())

            if 0 <= x < self.main_image.width() and 0 <= y < self.main_image.height():
                ra, dec = self.calculate_ra_dec_from_pixel(x, y)
                ra_hms = self.convert_ra_to_hms(ra)
                dec_dms = self.convert_dec_to_dms(dec)

                # Update RA/Dec labels
                self.ra_label.setText(f"RA: {ra_hms}")
                self.dec_label.setText(f"Dec: {dec_dms}")

                # --- 🔍 Debugging Output ---
                #print(f"Current Orientation Type: {type(self.orientation)}, Value: {self.orientation}")

                # ✅ Ensure `self.orientation` is a float before formatting
                if self.orientation is not None:
                    try:
                        self.orientation = float(self.orientation)  # Final safeguard conversion
                        self.orientation_label.setText(f"Orientation: {self.orientation:.2f}°")
                    except (ValueError, TypeError):
                        print(f"Failed to format orientation: {self.orientation}")
                        self.orientation_label.setText("Orientation: N/A")
                else:
                    self.orientation_label.setText("Orientation: N/A")
        else:
            self.ra_label.setText("RA: N/A")
            self.dec_label.setText("Dec: N/A")
            self.orientation_label.setText("Orientation: N/A")



    def convert_ra_to_hms(self, ra_deg):
        """Convert Right Ascension in degrees to Hours:Minutes:Seconds format."""
        ra_hours = ra_deg / 15.0  # Convert degrees to hours
        hours = int(ra_hours)
        minutes = int((ra_hours - hours) * 60)
        seconds = (ra_hours - hours - minutes / 60.0) * 3600
        return f"{hours:02d}h{minutes:02d}m{seconds:05.2f}s"

    def convert_dec_to_dms(self, dec_deg):
        """Convert Declination in degrees to Degrees:Minutes:Seconds format."""
        sign = "-" if dec_deg < 0 else "+"
        dec_deg = abs(dec_deg)
        degrees = int(dec_deg)
        minutes = int((dec_deg - degrees) * 60)
        seconds = (dec_deg - degrees - minutes / 60.0) * 3600
        degree_symbol = "\u00B0"
        return f"{sign}{degrees:02d}{degree_symbol}{minutes:02d}m{seconds:05.2f}s"                 

    def check_astrometry_data(self, header_like) -> bool:
        if header_like is None:
            return False
        try:
            h = header_like  # fits.Header is Mapping-like, dict is fine
            has_ctypes = ("CTYPE1" in h) and ("CTYPE2" in h)
            has_crval  = ("CRVAL1" in h) and ("CRVAL2" in h)
            has_scale  = ("CD1_1" in h) or ("CDELT1" in h) or ("PC1_1" in h)
            return bool(has_ctypes or (has_crval and has_scale))
        except Exception:
            return False


    def _settings(self) -> QSettings:
        return getattr(self, "settings", None) or QSettings()

    # ─────────────────────────────────────────
    # Minor-planet DB path via QSettings
    # ─────────────────────────────────────────
    def _minor_settings(self) -> QSettings:
        return getattr(self, "settings", None) or QSettings()

    # ─────────────────────────────────────────
    # Minor-planet DB path via QSettings
    # ─────────────────────────────────────────
    def _load_minor_db_path(self) -> str:
        """Load cached DB path from QSettings and update the label."""
        from pathlib import Path
        from setiastro.saspro import minorbodycatalog as mbc

        path = self.settings.value("wimi/minorbody_db_path", "", type=str)
        self.minor_db_path = path or ""

        if not hasattr(self, "minor_db_label"):
            return self.minor_db_path

        if not path:
            self.minor_db_label.setText("Database: not downloaded")
            return self.minor_db_path

        p = Path(path)
        if not p.is_file():
            self.minor_db_label.setText("Database: not downloaded")
            return self.minor_db_path

        # Try to load local manifest to show version + counts
        manifest_path = p.parent / mbc.DEFAULT_MANIFEST_BASENAME
        manifest = mbc.load_local_manifest(manifest_path)

        if manifest is not None:
            ast = f"{manifest.counts_asteroids:,}"
            com = f"{manifest.counts_comets:,}"
            self.minor_db_label.setText(
                f"Database: v{manifest.version} — {ast} asteroids, {com} comets"
            )
        else:
            self.minor_db_label.setText(f"Database: {p.name}")

        return self.minor_db_path

    def _save_minor_db_path(self, path: str) -> None:
        """Save DB path to QSettings and update label."""
        self.settings.setValue("wimi/minorbody_db_path", path)
        self.settings.sync()
        self.minor_db_path = path
        self._load_minor_db_path()   # reuse logic to update label

    def install_minor_body_catalog_from_file(self) -> None:
        """
        Install a user-provided minor-body SQLite DB. Workaround for
        environments where the automatic download fails — most commonly
        macOS Python hitting SSL: CERTIFICATE_VERIFY_FAILED because it
        can't find a CA bundle.

        Users download the .sqlite in a browser (which uses the system
        trust store) and then point us at it here.
        """
        from pathlib import Path
        from setiastro.saspro import minorbodycatalog as mbc

        src_path, _ = QFileDialog.getOpenFileName(
            self,
            self.tr("Select minor-body SQLite file"),
            "",
            self.tr("SQLite databases (*.sqlite *.db);;All files (*)"),
        )
        if not src_path:
            return

        data_dir = self._minorbody_data_dir()

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        self.status_label.setText("Status: Installing minor-body catalog…")
        try:
            db_path, manifest = mbc.install_local_db_file(
                src_path=Path(src_path),
                data_dir=data_dir,
            )
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            self.status_label.setText("Status: Minor-body catalog install failed.")
            QMessageBox.critical(
                self,
                self.tr("Minor-Body Catalog Error"),
                self.tr("Failed to install minor-body catalog:\n{err}").format(err=exc),
            )
            return
        finally:
            QApplication.restoreOverrideCursor()

        self._save_minor_db_path(str(db_path))

        ast = f"{manifest.counts_asteroids:,}"
        com = f"{manifest.counts_comets:,}"
        self.status_label.setText("Status: Minor-body catalog ready.")
        QMessageBox.information(
            self,
            self.tr("Minor-Body Catalog"),
            self.tr(
                "Minor-body catalog installed from local file.\n"
                "Version: {ver}\n"
                "Asteroids: {ast}\n"
                "Comets: {com}"
            ).format(ver=manifest.version, ast=ast, com=com),
        )

    def open_minor_body_download_page(self) -> None:
        """Open the GitHub releases page so the user can download the .sqlite manually."""
        from setiastro.saspro import minorbodycatalog as mbc
        QMessageBox.information(
            self,
            self.tr("Manual Download"),
            self.tr(
                "Your browser will open the SASpro minor-body releases page.\n\n"
                "Download the '{name}' asset from the latest release, then use\n"
                "'Install from Local File…' from the ▾ menu next to Download Catalog."
            ).format(name=mbc.DEFAULT_DB_BASENAME),
        )
        webbrowser.open(mbc.RELEASES_PAGE_URL)

    def download_minor_body_catalog(self, force: bool = False) -> None:
        """
        Download or update the minor-body SQLite DB using pro.minorbodycatalog,
        showing a progress UI while it runs.

        Shift-clicking the button sets force=True (handled in the click slot).
        """
        from PyQt6.QtCore import QEventLoop
        from setiastro.saspro import minorbodycatalog as mbc

        data_dir = self._minorbody_data_dir()

        # Disable the button while downloading
        if hasattr(self, "btn_minor_download"):
            self.btn_minor_download.setEnabled(False)

        self.status_label.setText("Status: Downloading minor-body catalog…")
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        dlg = QProgressDialog(
            "Downloading minor-body catalog…\n"
            "This may take a minute ~350MB file.",
            "",
            0,
            0,
            self,
        )
        dlg.setWindowTitle("Minor-Body Catalog")
        dlg.setWindowModality(Qt.WindowModality.ApplicationModal)
        dlg.setAutoClose(False)
        dlg.setAutoReset(False)
        dlg.setCancelButton(None)
        dlg.show()

        worker = MinorBodyDownloadWorker(
            data_dir=data_dir,
            force_refresh=force,
            parent=self,
        )

        result = {
            "ok": False,
            "db_path": "",
            "version": "",
            "ast": 0,
            "com": 0,
            "error": "",
        }

        loop = QEventLoop()

        def _on_ok(db_path: str, version: str, asteroids: int, comets: int):
            result["ok"] = True
            result["db_path"] = db_path
            result["version"] = version
            result["ast"] = asteroids
            result["com"] = comets
            loop.quit()

        def _on_fail(msg: str):
            result["ok"] = False
            result["error"] = msg
            loop.quit()

        worker.finished_ok.connect(_on_ok)
        worker.failed.connect(_on_fail)
        worker.finished.connect(loop.quit)

        worker.start()
        loop.exec()

        dlg.close()
        QApplication.restoreOverrideCursor()

        if hasattr(self, "btn_minor_download"):
            self.btn_minor_download.setEnabled(True)

        if not result["ok"]:
            self.status_label.setText("Status: Minor-body catalog download failed.")
            msg = result["error"] or "Unknown error."
            QMessageBox.critical(
                self,
                "Minor-Body Catalog Error",
                f"Failed to download minor-body catalog:\n{msg}",
            )
            return

        # Success
        self._save_minor_db_path(result["db_path"])

        ast = f"{result['ast']:,}"
        com = f"{result['com']:,}"

        self.status_label.setText("Status: Minor-body catalog ready.")
        QMessageBox.information(
            self,
            "Minor-Body Catalog",
            f"Minor-body catalog downloaded/updated successfully.\n"
            f"Version: {result['version']}\n"
            f"Asteroids: {ast}\n"
            f"Comets: {com}",
        )

    def _ensure_minor_planet_db(self) -> str | None:
        """
        Ensure the minor-body SQLite DB exists.

        Returns:
            Path string to the DB, or None if the user cancels or download fails.
        """
        from pathlib import Path

        # 1) If we already know the path and it exists, just reuse it.
        p_str = getattr(self, "minor_db_path", "") or self.settings.value(
            "wimi/minorbody_db_path", "", type=str
        )
        if p_str:
            p = Path(p_str)
            if p.is_file():
                self.minor_db_path = p_str
                return p_str

        # 2) Ask user to download / update
        reply = QMessageBox.question(
            self,
            "Minor-Body Catalog",
            "The minor-body catalog is not available.\n"
            "Do you want to download or update it now?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return None

        # This will check manifest and only re-download if needed
        self.download_minor_body_catalog(force=False)

        p_str = getattr(self, "minor_db_path", "")
        if p_str and Path(p_str).is_file():
            return p_str

        QMessageBox.critical(
            self,
            "Minor-Body Catalog",
            "Failed to download or locate the minor-body database.",
        )
        return None


    # ------------------------------------------------------------------
    # Minor-body helpers
    # ------------------------------------------------------------------
    def _minorbody_data_dir(self) -> Path:
        """
        Return the per-user data directory for the minor-body catalog.

        Uses QStandardPaths.AppDataLocation so it automatically maps to:
          - Windows: %LOCALAPPDATA%/SetiAstroSuitePro (or similar)
          - macOS:   ~/Library/Application Support/SetiAstroSuitePro
          - Linux:   ~/.local/share/SetiAstroSuitePro
        and then a 'minor_bodies' subfolder.
        """
        base = QStandardPaths.writableLocation(
            QStandardPaths.StandardLocation.AppDataLocation
        )
        base_path = Path(base) if base else Path.home() / ".saspro"
        data_dir = base_path / "minor_bodies"
        data_dir.mkdir(parents=True, exist_ok=True)
        return data_dir

    def _get_full_fov_center_and_radius_deg(self):
        """
        Compute (RA, Dec) at the image center and a radius (deg)
        that roughly covers the whole image (center to a corner).

        Returns (ra_center, dec_center, radius_deg) or (None, None, None)
        on failure.
        """
        if self.main_image is None or self.wcs is None or self.pixscale is None:
            return None, None, None

        try:
            # self.main_image is a QImage here (like in search_entire_image)
            width  = self.main_image.width()
            height = self.main_image.height()

            cx = width  / 2.0
            cy = height / 2.0

            ra_center, dec_center = self.calculate_ra_dec_from_pixel(cx, cy)
            if ra_center is None or dec_center is None:
                return None, None, None

            # pixel radius from center to bottom-right corner (same idea as SIMBAD)
            corner_x, corner_y = width, height
            dx = corner_x - cx
            dy = corner_y - cy
            radius_px = float((dx * dx + dy * dy) ** 0.5)

            # convert pixel radius to degrees using pixscale (arcsec/pixel)
            radius_deg = float((radius_px * self.pixscale) / 3600.0)

            return ra_center, dec_center, radius_deg
        except Exception:
            return None, None, None

    # ─────────────────────────────────────────
    # SASpro metadata keyword access
    # ─────────────────────────────────────────
    def _build_metadata_kw(self):
        """
        Return a `_kw(*names)` getter over the current view's SASpro metadata.

        SASpro keeps the camera's FITS keywords (DATE-OBS, DATE-LOC, SITELAT,
        SITELONG, EXPTIME, …) in the document's image metadata (FITSKeywords),
        and a plate solve updates that same metadata. The getter checks that
        store first, then any FITS Header fallbacks (wcs_header, a direct-file
        original header, the live WCS header). First finite value wins.
        """
        kw_dicts = []    # XISF-style FITSKeywords dicts (SASpro's own store)
        headers  = []    # FITS Header / mapping fallbacks

        meta = getattr(self, "_loaded_meta", None)
        if isinstance(meta, dict):
            for mk in ("image_meta", "file_meta", "XISF"):
                mm = meta.get(mk)
                if isinstance(mm, dict) and isinstance(mm.get("FITSKeywords"), dict):
                    kw_dicts.append(mm["FITSKeywords"])
            for hk in ("original_header", "wcs_header"):
                if meta.get(hk) is not None:
                    headers.append(meta[hk])
        # Direct-file-open path keeps these on self.
        im = getattr(self, "image_meta", None)
        if isinstance(im, dict) and isinstance(im.get("FITSKeywords"), dict):
            kw_dicts.append(im["FITSKeywords"])
        oh = getattr(self, "original_header", None)
        if oh is not None:
            headers.append(oh)
        w = getattr(self, "wcs", None)
        if w is not None:
            try:
                headers.append(w.to_header(relax=True))
            except Exception:
                pass

        def _kw(*names):
            """First value for any of `names`, metadata store before headers."""
            for d in kw_dicts:
                for n in names:
                    ent = d.get(n)
                    if not ent:
                        continue
                    try:
                        v = (ent[0].get("value")
                             if isinstance(ent, (list, tuple)) else ent)
                    except Exception:
                        v = None
                    if v not in (None, ""):
                        return v
            for h in headers:
                for n in names:
                    try:
                        if n in h and h[n] not in (None, ""):
                            return h[n]
                    except Exception:
                        continue
            return None

        return _kw

    def _observer_site(self):
        """
        Observer location (lat_deg, lon_deg, elev_m) for the topocentric
        parallax correction, or None.

        The camera already recorded where it was standing — SGP/NINA write
        SITELAT / SITELONG (space-separated sexagesimal, the sign belongs to
        the WHOLE value) and SITEELEV — so read it straight from the SASpro
        metadata. Falls back to the site saved in Settings. Without it the
        ephemeris is geocentric, which is up to ~18" off on a close object.
        """
        _kw = self._build_metadata_kw()
        lat = _wimi_parse_sexagesimal(_kw("SITELAT", "LAT-OBS", "OBSGEO-B", "LATITUDE"))
        lon = _wimi_parse_sexagesimal(_kw("SITELONG", "LONG-OBS", "OBSGEO-L", "LONGITUD"))
        elev = None
        try:
            ev = _kw("SITEELEV", "ALT-OBS", "OBSGEO-H", "ELEVATIO")
            elev = float(ev) if ev not in (None, "") else None
        except Exception:
            elev = None

        # Fall back to a site stored in Settings (same keys the Hunter uses).
        if (lat is None or lon is None) and getattr(self, "settings", None) is not None:
            try:
                s_lat = self.settings.value("site/latitude_deg", None)
                s_lon = self.settings.value("site/longitude_deg", None)
                if s_lat not in (None, "") and s_lon not in (None, ""):
                    lat = float(s_lat)
                    lon = float(s_lon)
                    if elev is None:
                        s_elev = self.settings.value("site/elevation_m", 0.0)
                        elev = float(s_elev) if s_elev not in (None, "") else 0.0
            except Exception:
                pass

        if lat is None or lon is None:
            return None
        if not (-90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0):
            return None
        return (float(lat), float(lon), float(elev or 0.0))

    # ─────────────────────────────────────────
    # Observation datetime helpers
    # ─────────────────────────────────────────
    def _get_observation_datetime_from_header(self):
        """
        Observation time (UTC) from the SASpro image metadata.

        SASpro keeps the camera's FITS keywords (DATE-OBS, DATE-LOC,
        EXPTIME, …) in the document metadata, and a plate solve updates
        that same metadata — so the timestamp is already attached to the
        view; there is no need to go digging for a separate original
        header. DATE-OBS is UTC by the FITS standard, and a DATE-LOC card
        beside it is the LOCAL wall-clock time, which confirms the DATE-OBS
        really is UTC (NINA, SGP and ACP all write the pair). We read the
        keywords here, evaluate at mid-exposure, and never run DATE-OBS
        through a timezone conversion.

        Returns a naive UTC datetime, or None (the caller then prompts).
        """
        _kw = self._build_metadata_kw()
        w = getattr(self, "wcs", None)

        # exposure length, for the mid-exposure shift
        try:
            exptime = float(_kw("EXPTIME", "EXPOSURE", "EXPOSURE_TIME") or 0.0)
        except Exception:
            exptime = 0.0

        # DATE-OBS (UTC) [+ TIME-OBS], then MJD-OBS, WCS dateobs, JD
        t = None
        source = None
        d = _kw("DATE-OBS", "DATE_OBS")
        if d is not None:
            s = str(d).strip()
            if "T" not in s:
                tv = _kw("TIME-OBS", "TIME_OBS")
                if tv:
                    s = f"{s}T{str(tv).strip()}"
            for fmt in ("isot", None):
                try:
                    t = (Time(s, format=fmt, scale="utc") if fmt
                         else Time(s, scale="utc"))
                    break
                except Exception:
                    t = None
            if t is not None:
                dloc = _kw("DATE-LOC", "DATE_LOC", "LOCALTIM")
                confirmed = bool(dloc) and str(dloc).strip() != s
                source = ("DATE-OBS (UTC — DATE-LOC present separately)"
                          if confirmed else "DATE-OBS (UTC)")
        if t is None:
            mjd = _kw("MJD-OBS", "MJD_OBS")
            if mjd is not None:
                try:
                    t = Time(float(mjd), format="mjd", scale="utc")
                    source = "MJD-OBS (UTC)"
                except Exception:
                    t = None
        if t is None and w is not None:
            try:
                do = getattr(getattr(w, "wcs", None), "dateobs", None)
                if do:
                    t = Time(str(do),
                             format=("isot" if "T" in str(do) else "iso"),
                             scale="utc")
                    source = "WCS DATE-OBS (UTC)"
            except Exception:
                t = None
        if t is None:
            jd = _kw("JD", "JD-OBS")
            if jd is not None:
                try:
                    t = Time(float(jd), format="jd", scale="utc")
                    source = "JD (UTC)"
                except Exception:
                    t = None
        if t is None:
            self._obs_time_source = None
            return None

        dt = t.to_datetime()                 # naive, UTC
        if exptime > 0:
            dt = dt + timedelta(seconds=exptime / 2.0)
        self._obs_time_source = source
        print(f"[WIMI] Observation time from {source}: {dt.isoformat()} "
              f"(mid-exposure, exptime={exptime:g}s)")
        return dt


    def _prompt_for_observation_datetime(self):
        from PyQt6.QtWidgets import QDialog, QFormLayout, QDialogButtonBox, QComboBox
        from PyQt6.QtCore import QDateTime
        import pytz

        dialog = QDialog(self)
        dialog.setWindowTitle("Observation Date & Time")

        layout = QFormLayout(dialog)
        lbl = QLabel(
            "This image's metadata has no observation date/time "
            "(no DATE-OBS / MJD-OBS / JD).\n"
            "Enter the midpoint of the exposure. Astro capture software "
            "writes DATE-OBS in UTC, so leave the timezone on UTC unless "
            "you know this value was recorded in local time."
        )
        lbl.setWordWrap(True)
        layout.addRow(lbl)

        dt_edit = QDateTimeEdit(dialog)
        dt_edit.setCalendarPopup(True)
        dt_edit.setDisplayFormat("yyyy-MM-dd HH:mm:ss")
        dt_edit.setDateTime(QDateTime.currentDateTime())  # local time as default
        layout.addRow("Date & Time:", dt_edit)

        tz_combo = QComboBox(dialog)
        # Common timezones first, then all
        common = [
            "UTC",
            "US/Eastern", "US/Central", "US/Mountain", "US/Pacific",
            "US/Alaska", "US/Hawaii",
            "Europe/London", "Europe/Paris", "Europe/Berlin",
            "Australia/Sydney", "Australia/Perth",
            "Asia/Tokyo", "Asia/Shanghai", "Asia/Kolkata",
        ]
        all_tz = sorted(pytz.all_timezones)
        # Put common ones at top with a separator
        tz_combo.addItems(common)
        tz_combo.insertSeparator(len(common))
        tz_combo.addItems([t for t in all_tz if t not in common])
        # Default to UTC. FITS DATE-OBS is UTC by the standard, so UTC is the
        # right assumption for a hand-entered exposure midpoint too — we do
        # NOT pre-select the computer's local zone (that was the old
        # behaviour, and it silently shifted correct UTC entries by the local
        # offset, forcing the user to hunt for "Universal" in the list).
        tz_combo.setCurrentText("UTC")

        layout.addRow("Timezone:", tz_combo)

        utc_preview = QLabel("UTC: —")
        utc_preview.setStyleSheet("color: #aaa; font-size: 11px;")
        layout.addRow(utc_preview)

        def _update_preview():
            try:
                tz = pytz.timezone(tz_combo.currentText())
                qdt = dt_edit.dateTime().toPyDateTime()
                local_dt = tz.localize(qdt)
                utc_dt = local_dt.astimezone(pytz.utc)
                utc_preview.setText(f"UTC: {utc_dt.strftime('%Y-%m-%d %H:%M:%S')}")
            except Exception:
                utc_preview.setText("UTC: —")

        dt_edit.dateTimeChanged.connect(_update_preview)
        tz_combo.currentTextChanged.connect(_update_preview)
        _update_preview()

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel
        )
        layout.addWidget(buttons)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            try:
                tz = pytz.timezone(tz_combo.currentText())
                qdt = dt_edit.dateTime().toPyDateTime()
                local_dt = tz.localize(qdt)
                utc_dt = local_dt.astimezone(pytz.utc)
                return utc_dt.replace(tzinfo=None)  # naive UTC for downstream
            except Exception:
                return None
        return None

    def _get_or_prompt_observation_datetime(self):
        """
        Returns a Python datetime for the observation. Uses:
        1) cached self.observation_datetime
        2) header (DATE-OBS / TIME-OBS / MJD-OBS / JD)
        3) prompt the user
        """
        # Cached?
        if getattr(self, "observation_datetime", None) is not None:
            return self.observation_datetime

        # Try header
        dt = self._get_observation_datetime_from_header()
        if dt is None:
            dt = self._prompt_for_observation_datetime()
        self.observation_datetime = dt
        return dt

    def perform_minor_body_search(self, mode: str = "circle"):
        """
        Search local minor-planet/comet database in either:

        - the current WCS-defined search circle (mode="circle"), or
        - the entire image FOV (mode="full").

        Uses the observation date/time from header or prompt.
        """
        # Scope from combo overrides the default 'mode' argument
        if hasattr(self, "minor_scope_combo"):
            scope = self.minor_scope_combo.currentText()
            if "Entire" in scope:
                mode = "full"
            else:
                mode = "circle"

        # Persist current minor-body settings so they survive restarts
        self.settings.setValue("wimi/minor/asteroid_H_max", self.minor_ast_H_spin.value())
        self.settings.setValue("wimi/minor/asteroid_max", self.minor_ast_max_spin.value())
        self.settings.setValue("wimi/minor/comet_H_max", self.minor_com_H_spin.value())
        self.settings.setValue("wimi/minor/comet_max", self.minor_com_max_spin.value())
        self.settings.setValue(
            "wimi/minor/time_offset_hours",
            self.minor_time_offset_spin.value()
        )
        # Optional specific target from UI (designation or name)
        target_name: str | None = None
        if hasattr(self, "minor_target_edit") and self.minor_target_edit is not None:
            t = self.minor_target_edit.text().strip()
            if t:
                target_name = t

        # Need WCS + pixscale for either mode
        if self.wcs is None or self.pixscale is None:
            QMessageBox.warning(
                self,
                "No WCS",
                "No valid WCS/pixel scale is available. Please solve the image first."
            )
            return

        # 1) Determine center + radius
        if mode == "full":
            ra_center, dec_center, radius_deg = self._get_full_fov_center_and_radius_deg()
            if ra_center is None or radius_deg is None:
                QMessageBox.warning(
                    self,
                    "Minor-Body Search",
                    "Could not determine the field of view for this image."
                )
                return
        else:
            # Default: use the defined search circle
            if not self.circle_center or self.circle_radius <= 0:
                QMessageBox.warning(
                    self,
                    "No Search Area",
                    "Please define a search circle by Shift-clicking and dragging."
                )
                return

            ra_center, dec_center = self.calculate_ra_dec_from_pixel(
                self.circle_center.x(), self.circle_center.y()
            )
            if ra_center is None or dec_center is None:
                QMessageBox.warning(
                    self,
                    "Invalid Coordinates",
                    "Could not determine the RA/Dec of the circle center."
                )
                return

            # radius in degrees from circle radius (pixels) and pixscale (arcsec/pixel)
            radius_deg = float((self.circle_radius * self.pixscale) / 3600.0)

        # 2) Observation datetime
        obs_dt = self._get_or_prompt_observation_datetime()
        if obs_dt is None:
            QMessageBox.information(
                self,
                "Minor-Body Search",
                "No observation date/time specified; search cancelled."
            )
            return

        # 3) DB path
        db_path = self._ensure_minor_planet_db()
        if not db_path:
            return

        # Read numeric limits once (in UI thread)
        try:
            H_ast = float(self.minor_ast_H_spin.value())
        except Exception:
            H_ast = 20.0
        try:
            N_ast = int(self.minor_ast_max_spin.value())
        except Exception:
            N_ast = 50000
        try:
            H_com = float(self.minor_com_H_spin.value())
        except Exception:
            H_com = 15.0
        try:
            N_com = int(self.minor_com_max_spin.value())
        except Exception:
            N_com = 5000

        # Optional: target name (e.g. "Semiramis")
        target_filter = None
        if hasattr(self, "minor_target_edit"):
            t = self.minor_target_edit.text().strip()
            if t:
                target_filter = t

        # 4) Run query in a worker thread with a progress dialog
        prog = QProgressDialog(
            "Computing minor-body ephemerides...\n"
            "This may take awhile...",
            "Cancel",
            0,
            0,
            self,
        )
        prog.setWindowTitle("Minor-Body Search")
        prog.setWindowModality(Qt.WindowModality.ApplicationModal)
        prog.setAutoClose(True)
        prog.setAutoReset(True)
        # We show() the dialog ourselves below. Leaving a non-zero minimum
        # duration makes QProgressDialog keep restarting its internal reveal
        # timer on every setValue() -- once elapsed passes that duration the
        # interval goes negative and Qt spams "negative intervals aren't
        # allowed". 0 makes it consider itself shown on the first update.
        prog.setMinimumDuration(0)
        prog.show()

        worker = MinorBodySearchWorker(
            dialog=self,
            db_path=db_path,
            ra_center=ra_center,
            dec_center=dec_center,
            radius_deg=radius_deg,
            obs_datetime=obs_dt,
            H_ast=H_ast,
            N_ast=N_ast,
            H_com=H_com,
            N_com=N_com,
            target_name=target_filter,
        )

        loop = QEventLoop()
        container = {"results": None, "error": None}

        def on_progress(done: int, total: int):
            if total <= 0:
                # Indeterminate: leave it busy, don't push values.
                if prog.maximum() != 0:
                    prog.setMaximum(0)
                return
            if prog.maximum() != total:
                prog.setMaximum(total)
            prog.setValue(done)

        def on_ok(results: list):
            container["results"] = results
            loop.quit()

        def on_fail(msg: str):
            container["error"] = msg
            loop.quit()

        def on_cancel():
            worker.request_cancel()

        worker.progress.connect(on_progress)
        worker.finished_ok.connect(on_ok)
        worker.failed.connect(on_fail)
        prog.canceled.connect(on_cancel)

        worker.start()
        loop.exec()
        prog.close()

        if container["error"] is not None:
            QMessageBox.critical(self, "Minor-Body Search", f"Query failed:\n{container['error']}")
            return

        results = container["results"] or []


        if not results:
            where = "the specified region" if mode == "circle" else "the image field of view"
            extra = ""
            if target_name:
                extra = f"\n(Target '{target_name}' not found in the catalog subset.)"
            QMessageBox.information(
                self,
                "Minor-Body Search",
                f"No minor planets or comets found in {where} at the given time.{extra}"
            )
            return

        # 5) Populate tree & overlay
        self.results_tree.clear()
        query_results = []

        # Image size, so we can tell the user which bodies actually fall on
        # the sensor vs just past its edge at this frame's time.
        try:
            img_w = int(self.main_image.width())
            img_h = int(self.main_image.height())
        except Exception:
            img_w = img_h = 0
        n_on = n_off = 0

        for r in results:
            ra  = float(r["ra"])
            dec = float(r["dec"])
            if not (math.isfinite(ra) and math.isfinite(dec)):
                continue  # ephemeris failed to converge for this body
            name  = r.get("name", r.get("designation", "N/A"))
            mag   = r.get("mag", "N/A")
            qtype = r.get("type", "Minor body")
            dist  = r.get("distance", "N/A")   # AU or whatever you decide
            src   = r.get("source", "MinorDB")

            dist_num = _wimi_num_or_none(dist)
            dist_disp = f"{dist_num:g} AU" if dist_num is not None else "N/A"

            # On- or off-sensor at this frame's observation time?
            px, py = self.calculate_pixel_from_ra_dec(ra, dec)
            on_frame = (px is not None and py is not None
                        and img_w > 0 and img_h > 0
                        and 0 <= px < img_w and 0 <= py < img_h)
            if on_frame:
                n_on += 1
            else:
                n_off += 1
            long_type = qtype if on_frame else f"{qtype} — off-frame"

            query_results.append({
                "ra": ra,
                "dec": dec,
                "name": name,
                "diameter": "N/A",              # minor bodies carry no angular size here
                "mag_display": _fmt_mag(mag),   # apparent magnitude -> Mag column
                "short_type": "MP",
                "long_type": long_type,
                "redshift": "N/A",          # not meaningful for minor bodies
                "parallax_mas": "N/A",
                "comoving_distance": dist,  # kept as-is (AU) for any legacy reader
                "distance_display": dist_disp,
                "source": src,
                # Flag so _filter_results_to_image keeps this row even when it
                # lands off the sensor, instead of silently culling it.
                "_minor_body": True,
                "_on_frame": on_frame,
            })

        self.main_preview.set_query_results(query_results)
        self.query_results = query_results
        self.update_results_tree()
        self.update_object_count()

        # Tell the user what was found, and crucially that some bodies are in
        # the field but just past the frame edge at THIS frame's time — load
        # the sub where the object has drifted into frame to see it on-image.
        total_mb = n_on + n_off
        if total_mb:
            msg = f"{total_mb} minor bod{'y' if total_mb == 1 else 'ies'} in field"
            if n_off:
                msg += f" — {n_on} on-frame, {n_off} just off the sensor edge"
            self.status_label.setText("Status: " + msg + ".")

    def _query_minor_planets_from_db(
        self,
        db_path,
        ra_center,
        dec_center,
        radius_deg,
        obs_datetime,
        H_ast: float,
        N_ast: int,
        H_com: float,
        N_com: int,
        target_name: str | None = None,
        progress_cb=None,
    ):
        """
        Query the local minor-body DB using MinorBodyCatalog + Skyfield.

        Returns list of dicts:
            ra, dec, name, mag, type, distance, source, designation
        """
        from pathlib import Path
        from astropy.time import Time
        import pandas as pd
        import sqlite3
        from setiastro.saspro import minorbodycatalog as mbc

        db_path = Path(db_path)
        if not db_path.is_file():
            raise FileNotFoundError(f"Minor-body DB not found: {db_path}")

        # --- Apply user-configurable time offset (hours), if any ---
        offset_hours = 0.0
        if hasattr(self, "minor_time_offset_spin"):
            try:
                offset_hours = float(self.minor_time_offset_spin.value())
            except Exception:
                offset_hours = 0.0

        if offset_hours != 0.0:
            obs_datetime = obs_datetime + timedelta(hours=offset_hours)
            print(
                f"[MinorBodies] applying time offset {offset_hours:+.2f} h, "
                f"effective obs_datetime = {obs_datetime.isoformat()}"
            )


        # 1) Convert observation datetime to JD
        jd = Time(obs_datetime).jd

        # Stash the exact epoch and DB file this search used, so a later
        # double-click can open the in-app Orbit Explorer placed at the
        # same instant and read the clicked body's elements by designation.
        self._minor_jd = float(jd)
        self._minor_db_path = str(db_path)

        print(
            f"[MinorBodies] Search: RA={ra_center:.6f} deg  "
            f"Dec={dec_center:.6f} deg  radius={radius_deg:.4f} deg  JD={jd:.6f}"
        )
        print(f"[MinorBodies] DB path: {db_path}")

        # ------------------------------------------------------------------
        # Branch 1: targeted search (Search by Name) → direct SQL LIKE
        # ------------------------------------------------------------------
        ast_df = None
        com_df = None

        if target_name:
            like = f"%{target_name.strip()}%"
            print(f"[MinorBodies] targeted search for {target_name!r} via direct SQL LIKE")

            with sqlite3.connect(str(db_path)) as con:
                # Introspect available columns
                ast_cols = {row[1] for row in con.execute("PRAGMA table_info(asteroids);")}
                com_cols = {row[1] for row in con.execute("PRAGMA table_info(comets);")}

                # ---- asteroids ----
                ast_where = []
                ast_params = []
                if "designation" in ast_cols:
                    ast_where.append("designation LIKE ?")
                    ast_params.append(like)
                if "designation_packed" in ast_cols:
                    ast_where.append("designation_packed LIKE ?")
                    ast_params.append(like)

                if ast_where:
                    ast_sql = (
                        "SELECT * FROM asteroids "
                        f"WHERE {' OR '.join(ast_where)} "
                        "LIMIT 5000;"
                    )
                    ast_df = pd.read_sql(ast_sql, con, params=ast_params)
                else:
                    print("[MinorBodies] no designation columns in asteroids table")
                    ast_df = pd.DataFrame()

                # ---- comets ----
                com_where = []
                com_params = []
                if "designation" in com_cols:
                    com_where.append("designation LIKE ?")
                    com_params.append(like)
                if "designation_packed" in com_cols:
                    com_where.append("designation_packed LIKE ?")
                    com_params.append(like)

                if com_where:
                    com_sql = (
                        "SELECT * FROM comets "
                        f"WHERE {' OR '.join(com_where)} "
                        "LIMIT 2000;"
                    )
                    com_df = pd.read_sql(com_sql, con, params=com_params)
                else:
                    print("[MinorBodies] no designation columns in comets table")
                    com_df = pd.DataFrame()

            print(
                f"[MinorBodies] targeted SQL results: "
                f"asteroids={len(ast_df)}, comets={len(com_df)}"
            )

            if ast_df.empty and com_df.empty:
                print("[MinorBodies] target not found in SQLite tables; returning [].")
                return []

        # ------------------------------------------------------------------
        # Branch 2: normal “brightness-limited” search (no target_name)
        # ------------------------------------------------------------------
        else:
            print(
                f"[MinorBodies] user limits: "
                f"Asteroids H<={H_ast}, max={N_ast}; "
                f"Comets H<={H_com}, max={N_com}"
            )

            cat = mbc.MinorBodyCatalog(db_path)

            try:
                ast_df = cat.get_bright_asteroids(H_max=H_ast, limit=N_ast)
            except Exception as e:
                print(f"[MinorBodies] get_bright_asteroids FAILED: {e!r}")
                ast_df = None

            try:
                com_df = cat.get_bright_comets(H_max=H_com, limit=N_com)
            except Exception as e:
                print(f"[MinorBodies] get_bright_comets FAILED: {e!r}")
                com_df = None

            n_ast = len(ast_df) if ast_df is not None else 0
            n_com = len(com_df) if com_df is not None else 0
            print(
                f"[MinorBodies] bright subset (no target filter): "
                f"asteroids={n_ast}, comets={n_com}"
            )

            if (ast_df is None or ast_df.empty) and (com_df is None or com_df.empty):
                print("[MinorBodies] NO rows to compute positions for, returning [].")
                return []

        # ------------------------------------------------------------------
        # Common path from here down (we now have ast_df/com_df)
        # ------------------------------------------------------------------
        cat = mbc.MinorBodyCatalog(db_path)

        # ---------- Build designation / magnitude maps ----------
        asteroid_designations: set[str] = set()
        comet_designations: set[str] = set()
        asteroid_mag: dict[str, float] = {}
        comet_mag: dict[str, float] = {}

        if ast_df is not None and len(ast_df):
            mag_keys_ast = ("magnitude_H", "H", "absolute_magnitude")
            for _, row in ast_df.iterrows():
                desig = row.get("designation", "") or row.get("name", "")
                if not desig:
                    continue
                asteroid_designations.add(desig)

                mag_val = None
                for mk in mag_keys_ast:
                    if mk in row and row[mk] is not None:
                        try:
                            mag_val = float(row[mk])
                        except Exception:
                            mag_val = None
                        break
                if mag_val is not None:
                    asteroid_mag[desig] = mag_val

        if com_df is not None and len(com_df):
            mag_keys_com = ("absolute_magnitude", "magnitude_H", "H")
            for _, row in com_df.iterrows():
                desig = row.get("designation", "") or row.get("name", "")
                if not desig:
                    continue
                comet_designations.add(desig)

                mag_val = None
                for mk in mag_keys_com:
                    if mk in row and row[mk] is not None:
                        try:
                            mag_val = float(row[mk])
                        except Exception:
                            mag_val = None
                        break
                if mag_val is not None:
                    comet_mag[desig] = mag_val

        # --- Combine into a single DataFrame for Skyfield ---
        frames: list[pd.DataFrame] = []
        if ast_df is not None and len(ast_df):
            frames.append(ast_df)
        if com_df is not None and len(com_df):
            frames.append(com_df)

        if not frames:
            print("[MinorBodies] NO rows to compute positions for after mapping; returning [].")
            return []

        rows_df = pd.concat(frames, ignore_index=True)
        total_rows = len(rows_df)
        print(f"[MinorBodies] total candidate rows sent to Skyfield: {total_rows}")
        print(f"[MinorBodies] columns in candidate DataFrame: {list(rows_df.columns)}")

        # ---------- progress callback ----------
        if progress_cb is None:
            def progress_cb(done: int, total: int) -> bool:
                return True

        # Observer site (topocentric parallax). Read from the image metadata
        # (SITELAT/SITELONG/SITEELEV), falling back to Settings. Without it
        # the ephemeris is geocentric — up to ~18" off on a close object.
        site = self._observer_site()
        if site is not None:
            print(f"[MinorBodies] observer site: lat={site[0]:.5f} "
                  f"lon={site[1]:.5f} elev={site[2]:.0f} m (topocentric)")
        else:
            print("[MinorBodies] no observer site in metadata or Settings — "
                  "geocentric positions")

        # 4) Compute positions with Skyfield at this JD
        print(
            f"[MinorBodies] compute_positions_skyfield: sending {total_rows} rows, jd={jd}"
        )
        positions = cat.compute_positions_astropy(
            asteroid_rows=rows_df,
            jd=jd,
            ephemeris_path=str(self._minorbody_data_dir()),
            topocentric=site,
            progress_cb=progress_cb,
            debug=True,
        )

        print(f"[MinorBodies] positions returned from Skyfield: {len(positions)}")

        # 5) Filter to cone
        results: list[dict[str, object]] = []
        kept = 0

        for pos in positions:
            ra = float(pos["ra_deg"])
            dec = float(pos["dec_deg"])
            ang = self.calculate_angular_distance(ra_center, dec_center, ra, dec)
            if ang > radius_deg:
                continue

            # Debug: check pixel conversion
            px, py = self.calculate_pixel_from_ra_dec(ra, dec)
            print(f"[MinorBodies] {pos.get('designation','')} "
                  f"ra={ra:.4f} dec={dec:.4f} → pixel x={px} y={py} "
                  f"image size={self.main_image.width()}x{self.main_image.height()}")

            kept += 1
            desig = pos.get("designation", "") or "Unknown"

            if desig in asteroid_designations:
                kind = "Asteroid"
                mag = asteroid_mag.get(desig, "N/A")
            elif desig in comet_designations:
                kind = "Comet"
                mag = comet_mag.get(desig, "N/A")
            else:
                kind = "Minor body"
                mag = "N/A"

            results.append(
                {
                    "ra": ra,
                    "dec": dec,
                    "name": desig,
                    "designation": desig,
                    "mag": mag,
                    "type": kind,
                    "distance": pos.get("distance_au", "N/A"),
                    "source": "MinorDB",
                }
            )

        print(f"[MinorBodies] objects inside cone: {kept}")
        return results

    def calculate_pixel_from_ra_dec(self, ra, dec):
        """Convert RA/Dec to pixel coordinates using the WCS data."""
        if not hasattr(self, "wcs") or self.wcs is None:
            print("WCS not initialized.")
            return None, None

        try:
            x, y = self.wcs.world_to_pixel_values(float(ra), float(dec))
        except Exception:
            # fallback: try via SkyCoord in case world_to_pixel_values also fails
            try:
                wcs2d = self.wcs.celestial if self.wcs.naxis > 2 else self.wcs
                sky_coord = SkyCoord(ra, dec, unit=(u.deg, u.deg), frame="icrs")
                x, y = wcs2d.world_to_pixel(sky_coord)
            except Exception as e:
                print(f"world_to_pixel failed for RA={ra}, Dec={dec}: {e}")
                return None, None

        x_val = float(np.asarray(x).ravel()[0])
        y_val = float(np.asarray(y).ravel()[0])

        if not np.isfinite(x_val) or not np.isfinite(y_val):
            return None, None

        return int(round(x_val)), int(round(y_val))

    #If originally a fits file update the header
    def update_fits_with_wcs(self, filepath, calibration_data):
        if not filepath.lower().endswith(('.fits', '.fit', '.fts', '.fits.gz', '.fit.gz', '.fts.gz', '.fz')):
            print("File is not a FITS file. Skipping WCS header update.")
            return

        print("Updating image with calibration data:", calibration_data)
        with fits.open(filepath, mode='update') as hdul:
            header = hdul[0].header
            header['CTYPE1'] = 'RA---TAN'
            header['CTYPE2'] = 'DEC--TAN'
            header['CRVAL1'] = calibration_data['ra']
            header['CRVAL2'] = calibration_data['dec']
            header['CRPIX1'] = hdul[0].data.shape[1] / 2
            header['CRPIX2'] = hdul[0].data.shape[0] / 2
            scale = calibration_data['pixscale'] / 3600
            orientation = np.radians(calibration_data['orientation'])
            header['CD1_1'] = -scale * np.cos(orientation)
            header['CD1_2'] = scale * np.sin(orientation)
            header['CD2_1'] = -scale * np.sin(orientation)
            header['CD2_2'] = -scale * np.cos(orientation)
            header['RADECSYS'] = 'ICRS'

    def on_mini_preview_press(self, event):
        # Set dragging flag and scroll the main preview to the position in the mini preview.
        self.dragging = True
        self.scroll_main_preview_to_mini_position(event)

    def on_mini_preview_drag(self, event):
        # Scroll to the new position while dragging in the mini preview.
        if self.dragging:
            self.scroll_main_preview_to_mini_position(event)

    def on_mini_preview_release(self, event):
        # Stop dragging
        self.dragging = False

    def scroll_main_preview_to_mini_position(self, event):
        """Scrolls the main preview to the corresponding position based on the mini preview click."""
        if self.main_image:
            # Get the click position in the mini preview
            click_x = event.pos().x()
            click_y = event.pos().y()

            mini_w = self.mini_preview.width()
            mini_h = self.mini_preview.height()
            img_w = self.main_image.width()
            img_h = self.main_image.height()
            if mini_w <= 0 or mini_h <= 0 or img_w <= 0 or img_h <= 0:
                return

            # The mini preview draws the image aspect-fit and centered (letterboxed),
            # matching update_green_box(). Invert that mapping so a click lands on the
            # correct image pixel regardless of the (now padded) scene rect.
            scale = min(mini_w / img_w, mini_h / img_h)
            scaled_w = img_w * scale
            scaled_h = img_h * scale
            x_off = (mini_w - scaled_w) / 2.0
            y_off = (mini_h - scaled_h) / 2.0

            image_x = (click_x - x_off) / scale
            image_y = (click_y - y_off) / scale

            # Clamp to the image so clicks in the letterbox margins stay in-bounds
            image_x = max(0.0, min(float(img_w), image_x))
            image_y = max(0.0, min(float(img_h), image_y))

            # Center the main preview on the calculated position
            self.main_preview.centerOn(image_x, image_y)

            # Update the green box after scrolling
            self.main_preview.update_mini_preview()

    def update_green_box(self):
        if not self.main_image:
            return

        mini_w = self.mini_preview.width()
        mini_h = self.mini_preview.height()
        if mini_w <= 0 or mini_h <= 0:
            return

        img_w = self.main_image.width()
        img_h = self.main_image.height()

        scale = min(mini_w / img_w, mini_h / img_h)
        scaled_w = int(img_w * scale)
        scaled_h = int(img_h * scale)

        # Force marker layer to render uncached so scene.render() captures it
        if self._marker_layer is not None and _qt_is_alive(self._marker_layer):
            self._marker_layer.setCacheMode(QGraphicsItem.CacheMode.NoCache)

        pixmap = QPixmap(mini_w, mini_h)
        pixmap.fill(Qt.GlobalColor.black)
        painter = QPainter(pixmap)
        x_off = (mini_w - scaled_w) // 2
        y_off = (mini_h - scaled_h) // 2
        target_rect = QRectF(x_off, y_off, scaled_w, scaled_h)
        source_rect = QRectF(0, 0, img_w, img_h)
        self.main_scene.render(painter, target_rect, source_rect)
        painter.end()

        # Restore device coordinate cache for performance
        if self._marker_layer is not None and _qt_is_alive(self._marker_layer):
            self._marker_layer.setCacheMode(QGraphicsItem.CacheMode.DeviceCoordinateCache)

        # Draw green box showing the current viewport
        factor_x = scaled_w / img_w
        factor_y = scaled_h / img_h

        view_rect = self.main_preview.mapToScene(self.main_preview.viewport().rect()).boundingRect()
        img_rect = QRectF(0, 0, img_w, img_h)
        clamped = view_rect.intersected(img_rect)

        painter2 = QPainter(pixmap)
        if clamped.width() < img_w or clamped.height() < img_h:
            green_box_rect = QRectF(
                x_off + clamped.x() * factor_x,
                y_off + clamped.y() * factor_y,
                clamped.width() * factor_x,
                clamped.height() * factor_y
            )
            pen = QPen(QColor(0, 255, 0), 2)
            painter2.setPen(pen)
            painter2.drawRect(green_box_rect)
        painter2.end()

        self.mini_preview.setPixmap(pixmap)

    @staticmethod
    def calculate_angular_distance(ra1, dec1, ra2, dec2):
        # Convert degrees to radians
        ra1, dec1, ra2, dec2 = map(math.radians, [ra1, dec1, ra2, dec2])

        # Haversine formula for angular distance
        delta_ra = ra2 - ra1
        delta_dec = dec2 - dec1
        a = (math.sin(delta_dec / 2) ** 2 +
            math.cos(dec1) * math.cos(dec2) * math.sin(delta_ra / 2) ** 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        angular_distance = math.degrees(c)
        return angular_distance
    
    @staticmethod
    def format_distance_as_dms(angle):
        degrees = int(angle)
        minutes = int((angle - degrees) * 60)
        seconds = (angle - degrees - minutes / 60) * 3600
        return f"{degrees}° {minutes}' {seconds:.2f}\""


    def wheel_zoom(self, event):
        if event.angleDelta().y() > 0:
            self.zoom_in()
        else:
            self.zoom_out()

    def zoom_100(self):
        """Reset to 1:1 zoom (one image pixel = one screen pixel)."""
        if not self.main_image:
            return
        self.zoom_level = 1.0
        self.main_preview.resetTransform()
        self.main_preview.setTransform(QTransform().scale(1.0, 1.0))
        self._update_scene_margins()
        self.main_preview.centerOn(self.main_scene.sceneRect().center())
        self.update_green_box()

    def _update_scene_margins(self):
        """Pad the scene rect with a margin around the image.

        QGraphicsView clamps the viewport to the scene rect, so with the rect
        set tight to the image you can't pan past the edges and centerOn() can't
        center objects near the border. We add a margin (in scene units) of at
        least half a viewport on each side so any image pixel -- including edge
        objects -- can be centered, while capping the margin so a zoomed-out
        view doesn't get runaway overscroll.
        """
        view = getattr(self, "main_preview", None)
        img = getattr(self, "main_image", None)
        if view is None or img is None:
            return
        iw = float(img.width())
        ih = float(img.height())
        if iw <= 0 or ih <= 0:
            return
        try:
            scale = float(view.transform().m11())
        except Exception:
            scale = 1.0
        if not scale or scale <= 0:
            scale = 1.0
        vp = view.viewport()
        mx = min(vp.width() / (2.0 * scale), iw)
        my = min(vp.height() / (2.0 * scale), ih)
        view.setSceneRect(QRectF(-mx, -my, iw + 2.0 * mx, ih + 2.0 * my))

    def zoom_in(self):
        self.zoom_level *= 1.2
        self.main_preview.setTransform(QTransform().scale(self.zoom_level, self.zoom_level))
        self._update_scene_margins()
        self.update_green_box()
        

    def zoom_out(self):
        self.zoom_level /= 1.2
        self.main_preview.setTransform(QTransform().scale(self.zoom_level, self.zoom_level))
        self._update_scene_margins()
        self.update_green_box()

    def fit_to_preview(self):
        """Fit the image to the current viewport size."""
        if not self.main_image:
            return
        vp = self.main_preview.viewport()
        vp_w = max(1, vp.width())
        vp_h = max(1, vp.height())
        img_w = max(1, self.main_image.width())
        img_h = max(1, self.main_image.height())
        scale = min(vp_w / img_w, vp_h / img_h)
        self.zoom_level = scale
        self.main_preview.resetTransform()
        self.main_preview.setTransform(QTransform().scale(scale, scale))
        self._update_scene_margins()
        self.main_preview.centerOn(self.main_scene.sceneRect().center())
        self.update_green_box()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_scene_margins()
        self.update_green_box()
        self._resize_crosshair_overlay()


    def compute_pixscale(self):
        """
        Computes the pixel scale (arcsec/pixel) from WCS if possible,
        otherwise falls back to header CD keywords.
        """
        from astropy.wcs.utils import proj_plane_pixel_scales

        # Prefer WCS-derived scale
        if getattr(self, "wcs", None) is not None:
            try:
                scales = proj_plane_pixel_scales(self.wcs) * 3600.0  # arcsec/pixel
                pixscale = float(np.mean(scales))
                print("Calculated pixscale from WCS:", pixscale)
                return pixscale
            except Exception as e:
                print("Error calculating pixscale from WCS:", e)

        # Fallback: CD matrix
        try:
            cd1_1 = float(self.header.get('CD1_1', 0))
            cd1_2 = float(self.header.get('CD1_2', 0))
            pixscale = math.sqrt(cd1_1**2 + cd1_2**2) * 3600.0
            print("Calculated pixscale from header:", pixscale)
            return pixscale
        except Exception as e:
            print("Error calculating pixscale from header:", e)
            return None


    def update_circle_data(self):
        """Updates the status based on the circle's center and radius."""
        if self.circle_center and self.circle_radius > 0:
            # Make sure we have a valid pixscale.
            if self.pixscale is None:
                self.pixscale = self.compute_pixscale()
                if self.pixscale is None:
                    self.status_label.setText("No pixscale available for radius calculation.")
                    print("Warning: Pixscale is None. Cannot calculate radius in arcminutes.")
                    return

            # Convert circle center to RA/Dec and radius to arcminutes.
            ra, dec = self.calculate_ra_dec_from_pixel(self.circle_center.x(), self.circle_center.y())
            radius_arcmin = self.circle_radius * self.pixscale / 60.0  # from arcsec to arcmin
            self.status_label.setText(
                f"Circle set at center RA={ra:.6f}, Dec={dec:.6f}, radius={radius_arcmin:.2f} arcmin"
            )
        else:
            self.status_label.setText("No search area defined.")



    def get_defined_radius(self):
        """Calculate radius in degrees for the defined region (circle radius)."""
        if self.circle_radius <= 0:
            return 0
        return float((self.circle_radius * self.pixscale) / 3600.0)


    def _augment_results_with_local_gaia(
        self,
        query_results: list,
        ra_center: float,
        dec_center: float,
        radius_deg: float,
    ) -> list:
        """
        Append local Gaia DR3 astrometric-library sources to a Simbad results
        set. Skips sources within 10" of an existing Simbad result (Simbad
        wins on collision; 10" tolerance absorbs high-PM J2000↔J2016 drift).
        Silently no-op if no astrometric band is installed.
        """
        if not getattr(self, "augment_with_gaia_checkbox", None) \
                or not self.augment_with_gaia_checkbox.isChecked():
            return query_results

        try:
            from setiastro.saspro.gaia_database import get_astro_library
        except Exception as e:
            print(f"[WIMI/Gaia] astrometric library import failed: {e}")
            return query_results

        try:
            astro_lib = get_astro_library()
            if not astro_lib.installed_bands():
                return query_results
        except Exception as e:
            print(f"[WIMI/Gaia] astrometric library open failed: {e}")
            return query_results

        # Bounding box around the search circle. RA span widens with dec.
        cosd = max(1e-6, abs(math.cos(math.radians(dec_center))))
        ra_lo = (ra_center - radius_deg / cosd) % 360.0
        ra_hi = (ra_center + radius_deg / cosd) % 360.0
        dec_lo = max(-90.0, dec_center - radius_deg)
        dec_hi = min( 90.0, dec_center + radius_deg)

        try:
            stars = astro_lib.find_stars_in_box(ra_lo, ra_hi, dec_lo, dec_hi)
        except Exception as e:
            print(f"[WIMI/Gaia] find_stars_in_box failed: {e}")
            return query_results
        if not stars:
            return query_results

        # 10" Simbad-collision filter using a KDTree in tangent-plane arcsec.
        # (Skips the O(N·M) all-pairs loop that would eat wide-field runs.)
        import numpy as np
        DUP_ARCSEC = 10.0
        keep_mask = np.ones(len(stars), dtype=bool)
        if query_results:
            try:
                from scipy.spatial import cKDTree
                s_ra  = np.array([q["ra"]  for q in query_results
                                  if isinstance(q.get("ra"),  (int, float))
                                  and isinstance(q.get("dec"), (int, float))],
                                 dtype=np.float64)
                s_dec = np.array([q["dec"] for q in query_results
                                  if isinstance(q.get("ra"),  (int, float))
                                  and isinstance(q.get("dec"), (int, float))],
                                 dtype=np.float64)
                if len(s_ra) > 0:
                    # Local tangent-plane: 1° dec = 3600", 1° ra = 3600·cos(dec)".
                    cosd_c = max(1e-6, math.cos(math.radians(dec_center)))
                    s_xy = np.column_stack([
                        ((s_ra - ra_center) * cosd_c) * 3600.0,
                        ( s_dec - dec_center)          * 3600.0,
                    ])
                    tree = cKDTree(s_xy)
                    g_ra  = np.array([s.ra  for s in stars], dtype=np.float64)
                    g_dec = np.array([s.dec for s in stars], dtype=np.float64)
                    g_xy = np.column_stack([
                        ((g_ra - ra_center) * cosd_c) * 3600.0,
                        ( g_dec - dec_center)         * 3600.0,
                    ])
                    d, _ = tree.query(g_xy, k=1,
                                      distance_upper_bound=DUP_ARCSEC)
                    keep_mask = ~np.isfinite(d)
            except Exception as e:
                print(f"[WIMI/Gaia] dupe filter fell back to naive: {e}")

        # Circle clip (find_stars_in_box returns a box; the search is a circle).
        added = 0
        for s, keep in zip(stars, keep_mask):
            if not keep:
                continue
            d_ra  = (s.ra - ra_center) * cosd
            d_dec =  s.dec - dec_center
            if (d_ra * d_ra + d_dec * d_dec) > (radius_deg * radius_deg):
                continue

            plx = float(s.parallax) if s.parallax is not None else None
            dist_pc = None
            if plx is not None and plx > 0.1:
                dist_pc = 1000.0 / plx        # mas → pc
            absG = None
            if dist_pc is not None and s.gmag is not None:
                try:
                    absG = float(s.gmag) - 5.0 * (math.log10(dist_pc) - 1.0)
                except Exception:
                    absG = None

            name = f"Gaia DR3 {int(s.source_id)}"
            dist_ly_val = (dist_pc * 3.261563777) if dist_pc is not None else "N/A"

            # Row is rendered by update_results_tree() from the dict below, so the
            # columns always line up with the header (RA, Dec, Name, ..., z, plx, dist).
            query_results.append({
                "ra": float(s.ra), "dec": float(s.dec),
                "name": name,
                "diameter": "N/A",
                "diameter_unit": "arcmin",
                "short_type": "*",
                "long_type": "Star (Gaia DR3)",
                "redshift": "N/A",
                "comoving_distance":
                    f"{dist_pc:.2f} pc" if dist_pc is not None else "N/A",
                "distance_ly": dist_ly_val,
                "source": "GaiaLocal",
                "Bmag": "N/A", "Vmag": "N/A",
                "parallax_mas": plx if plx is not None else "N/A",
                "spectral_type": "N/A",
                "absolute_mag": absG if absG is not None else "N/A",
            })
            added += 1

        print(f"[WIMI/Gaia] augmented Simbad results with "
              f"{added} local Gaia sources (from {len(stars)} in box)")
        return query_results

    def query_simbad(self, radius_deg, max_results=None):
        """Two-step SIMBAD lookup, run in a worker thread with a live progress dialog."""
        max_results = max_results if max_results is not None else self.max_results

        # ——— 1) Validate inputs (unchanged) ———
        if not self.circle_center or self.circle_radius <= 0:
            QMessageBox.warning(self, "No Search Area",
                                "Please define a search circle by Shift-clicking and dragging.")
            return

        ra_center, dec_center = self.calculate_ra_dec_from_pixel(
            self.circle_center.x(), self.circle_center.y()
        )
        if ra_center is None or dec_center is None:
            QMessageBox.warning(self, "Invalid Coordinates",
                                "Could not determine the RA/Dec of the circle center.")
            return

        selected_types = self.get_selected_object_types()
        if not selected_types:
            QMessageBox.warning(self, "No Object Types Selected",
                                "Please select at least one object type.")
            return

        # ——— 1b) CDS preflight ———
        # SIMBAD is not optional here the way it is in SFCC/SSSC — it IS the
        # query. So probe (hard 4 s deadline, falls over to the Harvard
        # mirror) and tell the user plainly rather than spending minutes of
        # retries to reach the same conclusion.
        self.status_label.setText("Status: Checking SIMBAD availability…")
        QApplication.processEvents()
        if not cds_health.simbad_available(
                status_cb=lambda m: (self.status_label.setText(f"Status: {m}"),
                                     QApplication.processEvents())):
            self.status_label.setText("Status: SIMBAD unavailable.")
            QMessageBox.warning(
                self, "SIMBAD Unavailable",
                "SIMBAD is not responding on either CDS mirror.\n\n"
                f"{cds_health.status_text()}\n\n"
                "CDS (Strasbourg) has scheduled and unscheduled outages; "
                "check https://cds.unistra.fr/ and try again later.\n\n"
                "Minor-body search and the local Gaia DR3 augment both work "
                "offline and are unaffected.")
            return
        simbad_host = _configure_simbad_endpoint()

        # ——— 2) Build TAP + sim-sam requests ———
        #
        # Push the otype selection into ADQL instead of filtering after the
        # fact. This is a correctness fix, not just a speed one: TOP N is
        # applied by SIMBAD BEFORE our client-side filter ran, so asking for
        # (say) nebulae only in a star-rich field would fill all N rows with
        # stars, drop every one of them locally, and report "No objects
        # found" while the nebulae sat unreturned in the cone.
        #
        # basic.otype is the same column the client filter compared against,
        # so this is the identical predicate evaluated server-side — no
        # hierarchy semantics change. When everything is checked (the default)
        # the clause is omitted entirely rather than emitting ~200 redundant
        # literals.
        _all_leaf_types = {li.text(0) for li in self._iterate_leaf_items()}
        _sel_types = set(selected_types)
        if _sel_types and _sel_types != _all_leaf_types:
            _codes = ",".join(_adql_quote(c) for c in sorted(_sel_types))
            otype_clause = f"\n                AND otype IN ({_codes})"
        else:
            otype_clause = ""

        tap_query = f"""
            SELECT TOP {max_results}
                ra, dec, main_id,
                rvz_redshift, otype, galdim_majaxis, galdim_minaxis,
                galdim_angle
            FROM basic
            WHERE CONTAINS(
                POINT('ICRS', basic.ra, basic.dec),
                CIRCLE('ICRS', {ra_center}, {dec_center}, {radius_deg})
            ) = 1{otype_clause}
        """

        star_codes = [
            "*","V*","Pe*","HB*","Y*O","Ae*","Em*","Be*","BS*","RG*","AB*",
            "C*","S*","sg*","s*r","s*y","s*b","HS*","pA*","WD*","LM*","BD*",
            "N*","OH*","TT*","WR*","PM*","HV*","C?*","Pec?","Y*?","TT?","C*?",
            "S*?","OH?","WR?","Be?","Ae?","HB?","RB?","sg?","s?r","s?y","s?b",
            "pA?","BS?","HS?","WD?",
            "**","EB*","Ce*","Ce?","cC*","**?",
            "EB?","Sy?","CV?","No?","XB?","LX?","HX?","RR?","WV?","LP?","Mi?"
        ]
        # Narrow the stellar-extras fetch to the star types actually selected.
        # sim-sam is the slowest leg of the query (it's the one carrying the
        # 90 s read timeout), and it exists only to attach B/V/parallax to
        # STARS. If the user asked for nebulae only there are no stars to
        # attach anything to, so skip the request entirely rather than
        # download a VOTable we then discard.
        if _sel_types != _all_leaf_types:
            star_codes = [c for c in star_codes if c in _sel_types]

        if not star_codes:
            sam_url = None
            sam_params = {}
        else:
            ra_str  = f"{ra_center:.8f}"
            dec_str = f"{dec_center:+.8f}"
            rad_str = f"{radius_deg:.8f}d"
            region_crit = f"region(CIRCLE,{ra_str} {dec_str},{rad_str})"
            codes_list  = ",".join(_adql_quote(c) for c in star_codes)
            otype_crit  = f"otypes in ({codes_list})"
            criteria    = f"{region_crit}&{otype_crit}"

            # Use whichever mirror answered the probe, so the TAP call and the
            # sim-sam extras call don't end up split across two hosts.
            sam_url = f"https://{simbad_host}/simbad/sim-sam"
            sam_params = {
                "Criteria":      criteria,
                "OutputMode":    "LIST",
                "maxObject":     str(max_results),
                "output.format": "votable",
                "output.params": ",".join([
                    "MAIN_ID","RA","DEC",
                    "FLUX(B)","FLUX(V)",
                    "PLX_VALUE","RVZ_REDSHIFT",
                    "OTYPE","SP_TYPE"
                ])
            }

        # ——— 3) Progress dialog + worker + event loop (same pattern as minor-body) ———
        prog = QProgressDialog(
            "Preparing SIMBAD query…",
            "Cancel",
            0, 0,  # indeterminate; worker switches to determinate per-attempt
            self,
        )
        prog.setWindowTitle("Query SIMBAD")
        prog.setWindowModality(Qt.WindowModality.ApplicationModal)
        prog.setAutoClose(True)
        prog.setAutoReset(True)
        prog.setMinimumDuration(0)
        prog.setMinimumWidth(420)
        prog.show()

        worker = SimbadQueryWorker(
            tap_query=tap_query,
            sam_url=sam_url,
            sam_params=sam_params,
            max_attempts=5,
            retry_wait_s=1.0,
            parent=self,
        )

        loop = QEventLoop()
        container = {"result": None, "extras": None, "error": None, "empty": False}

        def on_stage(msg: str):
            try:
                prog.setLabelText(msg)
            except Exception:
                pass

        def on_attempt(cur: int, total: int):
            # Flash the window title with retry count
            try:
                prog.setWindowTitle(f"Query SIMBAD — attempt {cur}/{total}")
            except Exception:
                pass

        def on_ok(result, extras: dict):
            if result is None:
                container["empty"] = True
            else:
                container["result"] = result
            container["extras"] = extras or {}
            loop.quit()

        def on_fail(msg: str):
            container["error"] = msg
            loop.quit()

        def on_cancel():
            worker.cancel()
            # Don't quit loop here — wait for worker to actually finish

        worker.stage.connect(on_stage)
        worker.attempt_info.connect(on_attempt)
        worker.finished_ok.connect(on_ok)
        worker.failed.connect(on_fail)
        prog.canceled.connect(on_cancel)

        worker.start()
        loop.exec()

        # Ensure worker is fully done
        if worker.isRunning():
            worker.wait(2000)

        # Keep `prog` alive — we'll reuse it for the parse/draw stages below.
        # It only closes after everything is done (or on cancel/error).

        # ——— 4) Handle outcome ———
        if container["error"] is not None:
            # Cancellation shows a quieter message
            if container["error"].strip().lower().startswith("cancelled"):
                return
            QMessageBox.warning(self, "SIMBAD Query Failed", container["error"])
            return

        if container["empty"]:
            self.results_tree.clear()
            query_results = self._augment_results_with_local_gaia(
                [], ra_center, dec_center, radius_deg)
            if not query_results:
                QMessageBox.information(
                    self, "No Results",
                    "No objects found in the specified area."
                )
            self.main_preview.set_query_results(query_results)
            self.query_results = query_results
            self.update_results_tree()
            self.update_object_count()
            return

        result = container["result"]
        extras = container["extras"]

        # ——— 5) Merge rows with live progress ———
        n_total = int(len(result))
        prog.setLabelText(f"Parsing SIMBAD rows (0 / {n_total})…")
        prog.setMaximum(max(1, n_total))
        prog.setValue(0)
        QApplication.processEvents()

        self.results_tree.clear()
        query_results = []

        # Cancellation check helper
        def _cancelled():
            return prog.wasCanceled()

        # Throttle processEvents() — calling it every row is itself slow
        tick = max(1, n_total // 100)   # ~100 UI updates total

        for i, row in enumerate(result):
            if _cancelled():
                prog.close()
                return

            name       = row["main_id"]
            short_type = row["otype"]
            if short_type in selected_types:
                ra, dec = float(row["ra"]), float(row["dec"])
                diam_raw = row.get("galdim_majaxis")
                diam_arcmin = _mask_safe_float(diam_raw)
                minor_arcmin = _mask_safe_float(row.get("galdim_minaxis"))
                pa_deg       = _mask_safe_float(row.get("galdim_angle"))
                diam = diam_arcmin if diam_arcmin is not None else "N/A"

                rz_raw   = row["rvz_redshift"]
                red_z    = _mask_safe_float(rz_raw)

                extra = extras.get(name, {})
                Bmag  = _mask_safe_float(extra.get("FLUX_B"))
                Vmag  = _mask_safe_float(extra.get("FLUX_V"))
                plx   = _mask_safe_float(extra.get("PLX_VALUE"))
                spec  = extra.get("SP_TYPE")

                if plx is not None and plx > 0.0:
                    pv = plx
                    dist_pc  = 1000.0 / pv
                    dist_ly  = dist_pc * 3.261563777
                    distance = round(dist_ly / 1e9, 9)
                    z_val    = "N/A"
                    plx_val  = pv
                    dist_ly_val = dist_ly
                else:
                    z_val    = red_z if red_z is not None else "N/A"
                    plx_val  = "N/A"
                    if isinstance(z_val, (int, float)):
                        distance = calculate_comoving_distance(z_val)
                        if distance is None:
                            distance    = "N/A"
                            dist_ly_val = "N/A"
                        else:
                            dist_ly_val = float(distance) * 1e9
                    else:
                        distance    = "N/A"
                        dist_ly_val = "N/A"

                absV = None
                if Vmag is not None and plx is not None and plx > 0:
                    absV = Vmag - (5 * np.log10(1000.0 / plx) - 5)

                long_type = otype_long_name_lookup.get(short_type, short_type)

                if diam_arcmin is not None:
                    if diam_arcmin >= 1.0:
                        diam_display = f"{diam_arcmin:.2f}'"
                    else:
                        diam_display = f"{diam_arcmin * 60.0:.1f}\""
                else:
                    diam_display = "N/A"

                query_results.append({
                    'ra': ra, 'dec': dec, 'name': name,
                    'diameter': diam,
                    'minor_arcmin': minor_arcmin,
                    'pa_deg': pa_deg,
                    'diameter_display': diam_display,
                    'diameter_unit': 'arcmin',
                    'short_type': short_type,
                    'long_type': long_type,
                    'redshift': z_val,
                    'comoving_distance': distance,
                    'distance_ly': dist_ly_val,
                    'source': "Simbad",
                    'Bmag': Bmag, 'Vmag': Vmag,
                    'mag_display': (_fmt_mag(Vmag) or _fmt_mag(Bmag)),
                    'parallax_mas': plx_val,
                    'spectral_type': spec,
                    'absolute_mag': absV
                })

            # Progress update (throttled)
            if (i + 1) % tick == 0 or (i + 1) == n_total:
                prog.setValue(i + 1)
                prog.setLabelText(f"Parsing SIMBAD rows ({i + 1} / {n_total})…")
                QApplication.processEvents()

        # ——— 6) Gaia augmentation ———
        if _cancelled():
            prog.close()
            return

        prog.setMaximum(0)   # indeterminate while augmenting
        prog.setValue(0)
        prog.setLabelText("Augmenting with local Gaia DR3 (if enabled)…")
        QApplication.processEvents()

        try:
            query_results = self._augment_results_with_local_gaia(
                query_results, ra_center, dec_center, radius_deg)
        except Exception as _ae:
            prog.setLabelText(f"Gaia augment failed ({type(_ae).__name__}); continuing…")
            QApplication.processEvents()

        if _cancelled():
            prog.close()
            return

        # ——— 7) Hand off to main preview (marker draw) ———
        n_final = len(query_results)
        prog.setLabelText(f"Drawing {n_final} markers on image…")
        QApplication.processEvents()

        self.main_preview.set_query_results(query_results)
        self.query_results = query_results

        if _cancelled():
            prog.close()
            return

        # ——— 8) Populate results tree with batched inserts + progress ———
        # QTreeWidget.addTopLevelItem is O(n) per call with sorting enabled.
        # Disable updates + sorting during bulk insert for a big speedup, and
        # use the batched addTopLevelItems API.
        prog.setMaximum(max(1, n_final))
        prog.setValue(0)
        prog.setLabelText(f"Populating results table (0 / {n_final})…")
        QApplication.processEvents()

        tree = self.results_tree
        tree.setUpdatesEnabled(False)
        was_sorting = tree.isSortingEnabled()
        tree.setSortingEnabled(False)
        try:
            tree.clear()
            batch = []
            batch_size = 500
            for i, obj in enumerate(query_results):
                if _cancelled():
                    break
                z_cell, plx_cell, dist_cell = wimi_result_columns(obj)
                item = QTreeWidgetItem([
                    str(obj['ra']),
                    str(obj['dec']),
                    obj['name'],
                    str(obj.get('diameter_display', obj['diameter'])),
                    obj['short_type'],
                    obj['long_type'],
                    z_cell,
                    plx_cell,
                    dist_cell,
                    str(obj.get('mag_display', '')),
                ])
                batch.append(item)
                if len(batch) >= batch_size or (i + 1) == n_final:
                    tree.addTopLevelItems(batch)
                    batch = []
                    prog.setValue(i + 1)
                    prog.setLabelText(f"Populating results table ({i + 1} / {n_final})…")
                    QApplication.processEvents()
            if batch and not _cancelled():
                tree.addTopLevelItems(batch)
        finally:
            tree.setSortingEnabled(was_sorting)
            tree.setUpdatesEnabled(True)

        # ——— 9) Final counts & close ———
        prog.setLabelText("Finalizing…")
        QApplication.processEvents()
        self.update_object_count()

        try:
            prog.close()
        except Exception:
            pass

        # Now that the otype filter runs server-side, hitting TOP N means
        # "there are more objects of this type in the cone than you asked
        # for" — actionable, unlike before when the cap was mostly consumed
        # by rows the client filter was about to throw away.
        if n_total >= max_results:
            self.status_label.setText(
                f"Status: showing the first {max_results:,} matches — there "
                f"may be more. Raise Max Results in Settings.")

        # STOP HERE. Everything below this point is the pre-worker synchronous
        # implementation, kept by accident when the threaded path was added.
        # Without this return it re-ran the entire query — a second
        # Simbad.query_tap retry loop and a second 300 s requests.get — on the
        # GUI thread, with no progress dialog and no cancel. That is the "WIMI
        # hangs forever" report. The dead block below can be deleted outright.
        return




    def perform_deep_vizier_search(self):
        CATALOG_NAMES = {
            "J/ApJS/199/26":    "2MRS",
            "VII/259/6dfgs":    "6dF Galaxy Survey",
            "V/147/sdss12":     "SDSS DR12",
            "VII/250/2dfgrs":   "2dFGRS",
            "J/MNRAS/474/3875": "GAMA DR3",
            "VII/291/gladep":   "GLADE+",
            "VII/237":          "HyperLEDA",
            "VII/221/psc":      "IRAS PSCz",
            "II/246":           "2MASS PSC",
            "I/350/gaiaedr3":   "Gaia EDR3",
            "I/322A":           "UCAC4",
            "V/154":            "Pan-STARRS 1",
        }        
        """Perform a Vizier catalog search and parse results, querying redshift surveys first."""
        if not self.circle_center or self.circle_radius <= 0:
            QMessageBox.warning(self, "No Search Area",
                                "Please define a search circle by Shift-clicking and dragging.")
            return

        # Convert center to RA/Dec
        ra_center, dec_center = self.calculate_ra_dec_from_pixel(
            self.circle_center.x(), self.circle_center.y()
        )
        if ra_center is None or dec_center is None:
            QMessageBox.warning(self, "Invalid Coordinates",
                                "Could not determine the RA/Dec of the circle center.")
            return

        radius_arcmin = float((self.circle_radius * self.pixscale) / 60.0)

        # Query true-redshift surveys first
        catalog_ids = [
            # 1) Major spectroscopic redshift surveys
            "J/ApJS/199/26",     # 2MASS Redshift Survey (2MRS)
            "VII/259/6dfgs",     # 6dF Galaxy Survey
            "V/147/sdss12",      # SDSS DR12 spectroscopic
            "VII/250/2dfgrs",    # 2dF Galaxy Redshift Survey (2dFGRS)
            "J/MNRAS/474/3875",  # GAMA DR3

            # 2) Meta-catalogs & composites
            "VII/291/gladep",    # GLADE+
            "VII/237",           # HyperLEDA
            "VII/221/psc",       # IRAS PSCz

            # 3) Photometric & astrometric surveys
            "II/246",            # 2MASS PSC
            "I/350/gaiaedr3",    # Gaia EDR3
            "I/322A",            # UCAC4
            "V/154"              # Pan-STARRS 1
        ]


        coord = SkyCoord(ra_center, dec_center, unit="deg")
        unique_entries = {}

        # VizieR is a CDS service and goes down with SIMBAD, so the same
        # breaker covers it. This loop hits 12 catalogs sequentially on the
        # GUI thread with no timeout — during an outage that is 12 full TCP
        # timeouts with a frozen window. Probe once, bound the per-query
        # timeout, and abandon the loop the moment the breaker opens.
        if not cds_health.simbad_available(
                status_cb=lambda m: (self.status_label.setText(f"Status: {m}"),
                                     QApplication.processEvents())):
            self.status_label.setText("Status: CDS unavailable.")
            QMessageBox.warning(
                self, "CDS Unavailable",
                "VizieR (CDS, Strasbourg) is not responding.\n\n"
                f"{cds_health.status_text()}\n\n"
                "The deep VizieR search needs the CDS archive. "
                "Try again later.")
            return
        try:
            Vizier.TIMEOUT = 45
        except Exception:
            pass
        _vz_budget = cds_health.Budget(150.0)

        try:
            for catalog_id in catalog_ids:
                if _vz_budget.expired() or not cds_health.simbad_available():
                    self.status_label.setText(
                        "Status: CDS unavailable — VizieR search stopped early.")
                    QApplication.processEvents()
                    break
                self.status_label.setText(
                    "Status: VizieR — querying "
                    f"{CATALOG_NAMES.get(catalog_id, catalog_id)}…")
                QApplication.processEvents()
                try:
                    result = Vizier.query_region(
                        coord, radius=radius_arcmin * u.arcmin, catalog=catalog_id
                    )
                except Exception as e:
                    if cds_health.note_failure(e, context=f"vizier/{catalog_id}"):
                        self.status_label.setText(
                            "Status: VizieR unreachable — stopping search.")
                        QApplication.processEvents()
                        break
                    continue   # this one catalog failed; try the rest
                if not result:
                    continue

                for row in result[0]:
                    # RA / Dec
                    ra = row.get("RAJ2000", row.get("RA_ICRS", None))
                    dec = row.get("DEJ2000", row.get("DE_ICRS", None))
                    if ra is None or dec is None:
                        continue
                    ra_str, dec_str = str(ra), str(dec)
                    key = (ra_str, dec_str)

                    # Name & types
                    name       = str(row.get("_2MASS", "") or row.get("Source", "") or row.get("SDSS12", ""))
                    type_short = CATALOG_NAMES.get(catalog_id, catalog_id)
                    long_type  = str(row.get("SpType", "N/A"))
                    diameter   = catalog_id

                    # ——— robust redshift/parallax parsing ———
                    # Redshift, parallax and distance are tracked separately so the
                    # tree can show them in their own columns.
                    redshift = "N/A"
                    parallax_val = "N/A"
                    comoving_distance = "N/A"
                    dist_ly_val = "N/A"

                    z_col = next((c for c in ("cz", "z", "zhelio", "zcmb", "zph")
                                  if c in row.colnames), None)
                    if z_col is not None:
                        raw = row[z_col]
                        try:
                            zval = float(raw)
                            if np.isnan(zval):
                                raise ValueError
                            if z_col == "cz":          # cz is in km/s
                                zval = zval / 299792.458
                            cg = calculate_comoving_distance(zval)   # GLy, or None if z<0
                            redshift = f"{zval:.6f}"
                            if cg is not None:
                                comoving_distance = f"{cg:.5f} GLy"
                                dist_ly_val = float(cg) * 1e9
                        except Exception:
                            redshift = str(raw)

                    elif "Plx" in row.colnames:
                        raw = row["Plx"]
                        try:
                            pv = abs(float(raw))
                            if pv <= 0 or np.isnan(pv):
                                raise ValueError
                            dist_ly_val = 1000.0 / pv * 3.2615637769
                            parallax_val = pv
                            comoving_distance = f"{dist_ly_val:.5f} Ly"
                        except Exception:
                            redshift = str(raw)
                    # ——— end parsing block ———

                    # Duplicate handling: first entry wins, SDSS overrides Pan-STARRS
                    if key not in unique_entries:
                        unique_entries[key] = {
                            "ra": ra_str,
                            "dec": dec_str,
                            "name": name,
                            "diameter": diameter,
                            "short_type": type_short,
                            "long_type": long_type,
                            "redshift": redshift,
                            "parallax_mas": parallax_val,
                            "comoving_distance": comoving_distance,
                            "distance_ly": dist_ly_val,
                            "source": "Vizier"
                        }
                    else:
                        existing = unique_entries[key]["diameter"]
                        if existing == "V/154" and diameter == "V/147/sdss12":
                            unique_entries[key].update({
                                "name": name,
                                "diameter": diameter,
                                "short_type": type_short,
                                "long_type": long_type,
                                "redshift": redshift,
                                "parallax_mas": parallax_val,
                                "comoving_distance": comoving_distance,
                                "distance_ly": dist_ly_val,
                                "source": "Vizier"
                            })

            # Hand off; the tree is rebuilt from these dicts by update_results_tree().
            all_results = list(unique_entries.values())
            self.main_preview.set_query_results(all_results)
            self.query_results = all_results
            self.update_results_tree()
            self.update_object_count()

        except Exception as err:
            QMessageBox.critical(self, "Vizier Search Failed", f"Failed to query Vizier: {err}")



    def perform_mast_search(self):
        """Perform a MAST cone search in the user-defined region using astroquery."""
        if not self.circle_center or self.circle_radius <= 0:
            QMessageBox.warning(self, "No Search Area", "Please define a search circle by Shift-clicking and dragging.")
            return

        # Calculate RA and Dec for the center point
        ra_center, dec_center = self.calculate_ra_dec_from_pixel(self.circle_center.x(), self.circle_center.y())
        if ra_center is None or dec_center is None:
            QMessageBox.warning(self, "Invalid Coordinates", "Could not determine the RA/Dec of the circle center.")
            return

        # Convert radius from arcseconds to degrees (MAST uses degrees)
        search_radius_deg = float((self.circle_radius * self.pixscale) / 3600.0)  # Convert to degrees
        ra_center = float(ra_center)  # Ensure it's a regular float
        dec_center = float(dec_center)  # Ensure it's a regular float

        try:
            # Perform the MAST cone search using Mast.mast_query for the 'Mast.Caom.Cone' service
            observations = Mast.mast_query(
                'Mast.Caom.Cone',
                ra=ra_center,
                dec=dec_center,
                radius=search_radius_deg
            )

            # Limit the results to the first 100 rows
            limited_observations = observations[:100]

            if len(observations) == 0:
                QMessageBox.information(self, "No Results", "No objects found in the specified area on MAST.")
                return

            # Clear previous results
            self.results_tree.clear()
            query_results = []

            #sasprocess each observation in the results
            for obj in limited_observations:

                def safe_get(value):
                    return "N/A" if np.ma.is_masked(value) else str(value)


                ra = safe_get(obj.get("s_ra", "N/A"))
                dec = safe_get(obj.get("s_dec", "N/A"))
                target_name = safe_get(obj.get("target_name", "N/A"))
                instrument = safe_get(obj.get("instrument_name", "N/A"))
                jpeg_url = safe_get(obj.get("dataURL", "N/A"))  # Adjust URL field as needed

                # Append full details as a dictionary to query_results;
                # the tree is rebuilt from these by update_results_tree().
                query_results.append({
                    'ra': ra,
                    'dec': dec,
                    'name': target_name,
                    'diameter': instrument,
                    'short_type': "N/A",
                    'long_type': jpeg_url,
                    'redshift': "N/A",
                    'parallax_mas': "N/A",
                    'comoving_distance': "N/A",
                    'distance_ly': "N/A",
                    'source': "Mast"
                })

            # Set query results in the CustomGraphicsView for display
            self.main_preview.set_query_results(query_results)
            self.query_results = query_results  # Keep a reference to results in MainWindow
            self.update_results_tree()
            self.update_object_count()

        except Exception as e:
            QMessageBox.critical(self, "MAST Query Failed", f"Failed to query MAST: {str(e)}")

    def toggle_show_names(self, state):
        """Toggle showing/hiding names on the main image."""
        self.show_names = state == Qt.CheckState.Checked
        self.main_preview.draw_query_results()  # Redraw with or without names

    def clear_results(self):
        """Clear the search results and remove markers from the main image."""
        self.results_tree.clear()
        self.main_preview.clear_query_results()
        self.status_label.setText("Results cleared.")

    def _load_name_label_style(self):
        """Load the Show-Object-Names label font + colour from QSettings."""
        s = getattr(self, "settings", None) or QSettings()
        font = QFont("Arial", 12)
        try:
            fs = s.value("wimi/name_label_font", "", type=str)
            if fs:
                f = QFont()
                if f.fromString(fs):
                    font = f
        except Exception:
            pass
        color = QColor(255, 255, 255)
        try:
            cs = s.value("wimi/name_label_color", "", type=str)
            if cs:
                c = QColor(cs)
                if c.isValid():
                    color = c
        except Exception:
            pass
        return font, color

    def _save_name_label_style(self):
        """Persist the current Show-Object-Names label font + colour."""
        s = getattr(self, "settings", None) or QSettings()
        try:
            s.setValue("wimi/name_label_font", self.name_label_font.toString())
            s.setValue("wimi/name_label_color",
                       self.name_label_color.name(QColor.NameFormat.HexArgb))
        except Exception:
            pass

    def open_settings_dialog(self):
        """Open settings dialog to adjust max results and marker type."""
        dialog = QDialog(self)
        dialog.setWindowTitle("Settings")
        layout = QFormLayout(dialog)

        # --- Max Results (use native QSpinBox) ---
        max_results_spinbox = QSpinBox(dialog)
        max_results_spinbox.setRange(1, 100000)
        max_results_spinbox.setSingleStep(1)

        # Safely resolve current value (handles int, str, numpy scalar, or accidental method)
        cur = getattr(self, "max_results", 1000)
        if callable(cur):
            try:
                cur = cur()
            except Exception:
                cur = 1000
        try:
            cur = int(cur)
        except Exception:
            cur = 1000
        cur = max(1, min(100000, cur))
        max_results_spinbox.setValue(cur)

        layout.addRow("Max Results:", max_results_spinbox)

        # --- Marker Style ---
        marker_style_combo = QComboBox(dialog)
        marker_style_combo.addItems(["Circle", "Crosshair"])
        marker_style_combo.setCurrentText(getattr(self, "marker_style", "Circle"))
        layout.addRow("Marker Style:", marker_style_combo)

        # --- Object-name label font + colour ----------------------------
        # Separate from the annotation-tools font (which only styles added
        # text). Edits a working copy; committed on OK.
        state = {
            "font": QFont(self.name_label_font),
            "color": QColor(self.name_label_color),
        }

        preview = QLabel("Sample  (6281) Strnad", dialog)
        preview.setAutoFillBackground(True)
        preview.setMinimumHeight(34)
        preview.setFrameShape(QFrame.Shape.StyledPanel)
        preview.setAlignment(Qt.AlignmentFlag.AlignCenter)

        def _refresh_preview():
            f = QFont(state["font"])
            # Clamp the on-canvas point size into something legible in this
            # little swatch, without changing the stored size.
            f.setPointSizeF(max(8.0, min(22.0, f.pointSizeF() if f.pointSizeF() > 0 else 12.0)))
            preview.setFont(f)
            pal = preview.palette()
            pal.setColor(QPalette.ColorRole.WindowText, state["color"])
            pal.setColor(QPalette.ColorRole.Window, QColor(40, 40, 40))
            preview.setPalette(pal)
            fnt = state["font"]
            bits = [fnt.family(),
                    f"{(fnt.pointSizeF() if fnt.pointSizeF() > 0 else fnt.pixelSize()):g} pt"]
            if fnt.bold():
                bits.append("Bold")
            if fnt.italic():
                bits.append("Italic")
            font_btn.setText("  ".join(bits))

        font_btn = QPushButton(dialog)
        font_btn.setToolTip("Family, size and style of the object-name labels")

        def _pick_font():
            f, ok = QFontDialog.getFont(state["font"], dialog, "Object Name Font")
            if ok:
                state["font"] = f
                _refresh_preview()
        font_btn.clicked.connect(_pick_font)

        color_btn = QPushButton("Colour…", dialog)
        color_btn.setToolTip("Colour of the object-name labels")

        def _pick_color():
            c = QColorDialog.getColor(
                state["color"], dialog, "Object Name Colour",
                QColorDialog.ColorDialogOption.ShowAlphaChannel)
            if c.isValid():
                state["color"] = c
                _refresh_preview()
        color_btn.clicked.connect(_pick_color)

        layout.addRow("Object Name Font:", font_btn)
        layout.addRow("Object Name Colour:", color_btn)
        layout.addRow("Preview:", preview)
        _refresh_preview()

        # --- Force Blind Solve ---
        force_blind_solve_button = QPushButton("Force Blind Solve", dialog)
        force_blind_solve_button.clicked.connect(self.force_blind_solve)
        layout.addRow(force_blind_solve_button)

        # --- OK / Cancel ---
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=dialog
        )

        def _accept():
            # Commit the label style first, then the rest (which repaints).
            self.name_label_font = QFont(state["font"])
            self.name_label_color = QColor(state["color"])
            self._save_name_label_style()
            self.update_settings(
                max_results_spinbox.value(),
                marker_style_combo.currentText(),
                dialog,
            )

        buttons.accepted.connect(_accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)

        dialog.setLayout(layout)
        dialog.exec()


    def update_settings(self, max_results: int, marker_style: str, dialog: QDialog):
        """Update settings based on dialog input."""
        self.max_results = int(max_results)
        self.marker_style = str(marker_style)
        s = QSettings()
        s.setValue("wimi/max_results", self.max_results)
        s.setValue("wimi/marker_style", self.marker_style)
        self.main_preview.draw_query_results()
        dialog.accept()

    def force_blind_solve(self):
        doc = self._doc_for_solver()
        if doc is None:
            QMessageBox.information(self, "Force Blind Solve", "No image is loaded.")
            return

        mw = _find_main_window(self) or self.parent()
        settings = getattr(mw, "settings", QSettings())

        prev_mode = _get_seed_mode(settings)
        try:
            _set_seed_mode(settings, "none")  # blind for this one call
            ok, res = plate_solve_doc_inplace(mw, doc, settings)
        finally:
            _set_seed_mode(settings, prev_mode)  # restore user preference

        if ok:
            # Pull the header the solver just wrote and reflect it into WIMI
            meta = getattr(doc, "metadata", {}) or {}
            hdr = meta.get("wcs_header") or meta.get("original_header")
            try:
                if hdr is not None:
                    self.initialize_wcs_from_header(hdr)
                    self.status_label.setText("Status: Blind solve succeeded.")
                    QMessageBox.information(self, "Blind Solve", "Astrometric solution applied successfully.")
                else:
                    raise RuntimeError("Solver returned no header.")
            except Exception as e:
                QMessageBox.warning(self, "Apply WCS", f"Solve succeeded but WCS init failed: {e}")
                self.status_label.setText(f"Status: WCS init failed — {e}")
        else:
            QMessageBox.critical(self, "Blind Solve Failed", str(res))
            self.status_label.setText(f"Status: Blind solve failed — {res}")

    def _restore_ui_state(self):
        """
        Restore persisted dialog geometry/state for WIMI.
        """
        try:
            g = self.settings.value("wimi/window_geometry", None)
            if g is not None:
                self.restoreGeometry(g)
        except Exception:
            pass


    def _save_ui_state(self):
        """
        Save persisted dialog geometry/state for WIMI.
        """
        try:
            self.settings.setValue("wimi/window_geometry", self.saveGeometry())
            self.settings.sync()
        except Exception:
            pass


    def closeEvent(self, event):
        try:
            self._save_ui_state()
        except Exception:
            pass
        super().closeEvent(event)

# Function to calculate comoving radial distance (in Gly)
def _wimi_parse_sexagesimal(val):
    """
    Parse 'DD MM SS.SS', '-DD:MM:SS', '+DD MM SS' or a plain decimal into
    degrees.

    SGP/NINA write SITELAT/SITELONG as space-separated sexagesimal, and the
    sign belongs to the WHOLE value rather than just the degrees field —
    treating '-90 11 44.16' as -90 + 11/60 + 44/3600 puts the observer in
    the wrong place by over 20 arcminutes of longitude.
    """
    if val is None:
        return None
    if isinstance(val, bool):
        return None
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).strip()
    if not s:
        return None
    try:
        return float(s)                      # already decimal
    except ValueError:
        pass
    neg = s.startswith("-")
    parts = [p for p in s.replace(":", " ").replace(",", " ").split() if p]
    try:
        nums = [abs(float(p)) for p in parts]
    except ValueError:
        return None
    if not nums:
        return None
    deg = nums[0]
    if len(nums) > 1:
        deg += nums[1] / 60.0
    if len(nums) > 2:
        deg += nums[2] / 3600.0
    return -deg if neg else deg


def _wimi_num_or_none(x):
    """Best-effort float. Returns None for None/masked/'N/A'/'--'/non-numeric/non-finite."""
    if x is None:
        return None
    if isinstance(x, bool):
        return None
    if isinstance(x, (int, float)):
        return float(x) if np.isfinite(x) else None
    try:
        if ma.is_masked(x):
            return None
    except Exception:
        pass
    s = str(x).strip()
    if s == "" or s == "--" or s.upper() == "N/A":
        return None
    try:
        v = float(s)
    except ValueError:
        return None
    return v if np.isfinite(v) else None


def format_distance_ly(d_ly):
    """Adaptive light-year distance string so nearby stars don't read as 0.000005 GLy.

    Picks the unit that keeps the number human-readable: Gly / Mly / kly / ly.
    """
    d = _wimi_num_or_none(d_ly)
    if d is None or d <= 0:
        return "N/A"
    if d >= 1e9:
        return f"{d / 1e9:.3f} Gly"
    if d >= 1e6:
        return f"{d / 1e6:.2f} Mly"
    if d >= 1e3:
        return f"{d / 1e3:.2f} kly"
    return f"{d:.1f} ly"


def wimi_result_columns(obj):
    """Return (redshift_cell, parallax_cell, distance_cell) display strings for a result dict.

    Redshift and parallax are shown in separate columns; distance uses an adaptive
    unit. Tolerant of legacy fields where a parallax was stored under 'redshift' and
    distance under 'comoving_distance' (in GLy).
    """
    z = _wimi_num_or_none(obj.get("redshift"))
    plx = _wimi_num_or_none(obj.get("parallax_mas"))

    z_cell = f"z = {z:.6f}" if z is not None else "\u2014"
    plx_cell = f"{plx:.3f}" if plx is not None else "\u2014"

    # Explicit display override wins (e.g. minor bodies quoted in AU).
    disp = obj.get("distance_display")
    if disp:
        dist_cell = str(disp)
    else:
        d_ly = _wimi_num_or_none(obj.get("distance_ly"))
        if d_ly is None:
            # Fall back to parallax, then to legacy comoving_distance (GLy).
            if plx is not None and plx > 0:
                d_ly = (1000.0 / plx) * 3.261563777
            else:
                cg = _wimi_num_or_none(obj.get("comoving_distance"))
                d_ly = cg * 1e9 if cg is not None else None
        dist_cell = format_distance_ly(d_ly)
    return z_cell, plx_cell, dist_cell


def calculate_comoving_distance(z):
    # A negative value is a blueshift (peculiar motion toward us), not a
    # cosmological recession — a comoving distance is meaningless there, so
    # omit it rather than folding the sign away with abs(). Callers treat
    # None as "no distance".
    if z is None or z < 0:
        return None
    # Initialize variables
    WR = 4.165E-5 / ((H0 / 100) ** 2)  # Omega radiation
    WK = 1 - WM - WV - WR  # Omega curvature
    az = 1.0 / (1 + z)
    n = 1000  # number of points in integration

    # Comoving radial distance
    DCMR = 0.0
    for i in range(n):
        a = az + (1 - az) * (i + 0.5) / n
        adot = sqrt(WK + (WM / a) + (WR / (a ** 2)) + (WV * a ** 2))
        DCMR += 1 / (a * adot)
    
    DCMR = (1 - az) * DCMR / n
    DCMR_Gly = (c / H0) * DCMR * Mpc_to_Gly

    return round(DCMR_Gly, 6)  # Round to three decimal places for display

def calculate_orientation(header):
    """Calculate orientation from CD or PC matrix."""
    cd1_1 = header.get('CD1_1')
    cd1_2 = header.get('CD1_2')
    cd2_1 = header.get('CD2_1')
    cd2_2 = header.get('CD2_2')

    if all(v is not None for v in [cd1_1, cd1_2, cd2_1, cd2_2]):
        orientation = (np.degrees(np.arctan2(cd1_2, cd1_1)) + 180) % 360
        return orientation

    # Try PC matrix fallback
    pc1_1 = header.get('PC1_1')
    pc1_2 = header.get('PC1_2')
    cdelt1 = header.get('CDELT1')
    cdelt2 = header.get('CDELT2')

    if pc1_1 is not None and pc1_2 is not None and cdelt1 is not None and cdelt2 is not None:
        cd1_1 = pc1_1 * cdelt1
        cd1_2 = pc1_2 * cdelt1
        orientation = (np.degrees(np.arctan2(cd1_2, cd1_1)) + 180) % 360
        return orientation

    print("CD or PC matrix not found in header.")
    return None