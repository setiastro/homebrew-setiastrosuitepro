#saspro/blink_comparator_pro.py
# thread safe version
from __future__ import annotations

from setiastro.saspro.main_helpers import non_blocking_sleep

# ⬇️ keep your existing imports used by the code you pasted
import os
import re
import sys
import time
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed

from typing import Optional, List
from collections import defaultdict
# Qt
from PyQt6.QtCore import Qt, QTimer, QEvent, QPointF, QRectF, pyqtSignal, QSettings, QPoint, QCoreApplication, QByteArray
from PyQt6.QtGui import (QAction, QIcon, QImage, QPixmap, QBrush, QColor, QPalette,
                         QKeySequence, QWheelEvent, QShortcut, QDoubleValidator, QIntValidator)
from PyQt6.QtWidgets import (
    QWidget, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QToolButton,
    QTreeWidget, QTreeWidgetItem, QFileDialog, QMessageBox, QProgressBar, QSizePolicy,
    QAbstractItemView, QMenu, QSplitter, QStyle, QScrollArea, QSlider, QDoubleSpinBox, QSpinBox, QProgressDialog, QComboBox, QLineEdit, QApplication, QGridLayout, QCheckBox, QInputDialog,
    QMdiArea, QDialogButtonBox, QHeaderView, QButtonGroup, QRadioButton
)
from bisect import bisect_right
# 3rd-party (your code already expects these)
import gc
import cv2
import sep

# psutil is bundled, but the memory guard degrades to a no-op without it
# rather than refusing to load frames it cannot measure.
try:
    import psutil
except Exception:
    psutil = None
sep.set_extract_pixstack(20000000)
import pyqtgraph as pg
from collections import OrderedDict
from setiastro.saspro.legacy.image_manager import load_image

from setiastro.saspro.imageops.stretch import stretch_color_image, stretch_mono_image
from setiastro.saspro.bayer_utils import (
    detect_bayer_pattern,
    detect_bayer_offsets_and_roworder,
)
from setiastro.saspro.cosmicclarity_engines.satellite_engine import (
    get_satellite_models,
    satellite_remove_image,
    satellite_detect_tiles,
    artifact_group_key,
    ArtifactMapBuilder,
)
from setiastro.saspro.legacy.numba_utils import debayer_raw_fast, debayer_fits_fast
from setiastro.saspro.widgets.themed_buttons import themed_toolbtn
from setiastro.saspro.help_support import make_help_button

from setiastro.saspro.star_metrics import measure_stars_sep
from setiastro.saspro.blink_fast_read import (
    read_downsampled, probe_header, MIN_STEP as _FAST_MIN_STEP,
)
from setiastro.saspro.blink_stream import FrameCache, prefetch_window

def _try_raise_fd_limit() -> None:
    """Silently raise RLIMIT_NOFILE soft limit to the hard cap (Unix only)."""
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        if hard == resource.RLIM_INFINITY:
            target = max(soft, 65536)
        else:
            target = hard
        if target > soft:
            resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
    except Exception:
        pass

_try_raise_fd_limit()

def _blink_thread_safety_mode() -> str:
    """Return 'safe' or 'fast'. QSettings 'blink/thread_safety' may be:
       'auto' (default) -> safe iff numba's resolved threading layer is not
                           threadsafe (workqueue), fast otherwise
       'safe'           -> force serialized numba + conservative workers
       'fast'           -> force concurrent numba + aggressive workers"""
    try:
        mode = QSettings().value("blink/thread_safety", "auto", type=str) or "auto"
    except Exception:
        mode = "auto"
    mode = str(mode).strip().lower()
    if mode not in ("auto", "safe", "fast"):
        mode = "auto"
    if mode == "auto":
        # The real hazard is the resolved threading layer, not the OS: any box
        # whose numba fell back to the non-threadsafe 'workqueue' layer aborts
        # under the parallel loader (StellarMate/Linux and macOS alike). Key off
        # that, falling back to the old darwin guess only while the layer is
        # still unknown (i.e. before warmup has run a parallel region).
        try:
            from setiastro.saspro.legacy.numba_utils import numba_threading_layer_unsafe
            unsafe = numba_threading_layer_unsafe()
        except Exception:
            unsafe = None
        if unsafe is None:
            return "safe" if sys.platform == "darwin" else "fast"
        return "safe" if unsafe else "fast"
    return mode


def _blink_apply_thread_safety() -> str:
    """Push the current mode into numba_utils so debayer calls made by our load
    workers use the right locking behavior. Returns 'safe' / 'fast'."""
    mode = _blink_thread_safety_mode()
    try:
        from setiastro.saspro.legacy.numba_utils import set_numba_parallel_serialize
        set_numba_parallel_serialize(mode == "safe")
    except Exception:
        pass
    return mode


def _blink_wait_for_numba_layer(timeout: float = 20.0) -> None:
    """Block (pumping the UI) until numba_warmup has resolved and recorded the
    threading layer.

    The lazy NUMBA_PARALLEL_LOCK decides serialize-vs-concurrent from numba's
    *resolved* layer, which numba_warmup records only after its background
    compile finishes. If a user opens Blink and loads before that completes, the
    layer is still unknown and the decision falls back to an OS guess
    (fast/no-op on Linux) — the exact path that aborts on a workqueue box. So we
    wait here, before fanning out. Idempotent and best-effort: any failure just
    returns and lets loadImages' pathological-case fallback take over."""
    try:
        from setiastro.saspro.numba_warmup import (
            start_background_warmup, wait_for_warmup, is_warmup_done,
        )
    except Exception:
        return
    try:
        if is_warmup_done():
            return
        start_background_warmup()  # idempotent; no-op if already running
        deadline = time.monotonic() + float(timeout)
        while not is_warmup_done() and time.monotonic() < deadline:
            wait_for_warmup(timeout=0.1)
            try:
                QApplication.processEvents()
            except Exception:
                pass
    except Exception:
        pass


def _blink_fast_read_enabled() -> bool:
    """Kill switch for the strided FITS/XISF reader (QSettings 'blink/fast_read').

    On by default. It only ever changes 1:4 and 1:8 loads; the reader declines
    anything it cannot reproduce faithfully, so turning this off should only
    ever cost speed. Exposed so a user hitting something odd on their own data
    can rule it out without a rebuild.
    """
    try:
        return bool(QSettings().value("blink/fast_read", True, type=bool))
    except Exception:
        return True


def _blink_cfa_mode() -> str:
    """How the strided reader should treat one-shot-colour frames.

    "color" (the default) keeps Blink's core behaviour -- CFA frames stay
    colour -- by reading a quad-aligned subsample and debayering the small
    mosaic instead of the full frame. "luminance" skips the debayer entirely
    and hands back a balanced grey plane.
    """
    try:
        keep = bool(QSettings().value("blink/cfa_color", True, type=bool))
    except Exception:
        keep = True
    return "color" if keep else "luminance"


def _blink_stream_enabled() -> bool:
    """PreLoad (False) or Stream (True), from QSettings 'blink/stream'.

    PreLoad is the historical behaviour: decode every frame on open and hold
    it. Stream scans headers only and decodes a frame when you look at it.
    """
    try:
        return bool(QSettings().value("blink/stream", False, type=bool))
    except Exception:
        return False


def _blink_stream_budget_bytes() -> int:
    """How much decoded imagery Stream mode keeps resident, in bytes."""
    try:
        mb = int(QSettings().value("blink/stream_budget_mb", 1024, type=int))
    except Exception:
        mb = 1024
    return max(64, mb) << 20


def _blink_storage_dtype():
    """Blink stores stretched, clipped display data -- uint16, always.

    The old RAM tier picked float32 above 32 GB and uint8 below 16 GB. Both
    ends were wrong, and for the same reason: the array has already been
    stretched and clipped to [0,1], and the only thing that re-expands it is
    _aggressive_display_boost, whose steepest slope is k/arcsinh(k) = 2.07x
    at k = 3.7 * 1.25.

      float32  16.7M levels -> ~8.1M surviving the boost, for an 8-bit
               display. Measured against uint16 on a stretched frame, the
               final 8-bit display frame differs by at most 1 LSB on 0.4% of
               pixels, with the same count of distinct levels. Two bytes a
               pixel for nothing anyone can see.

      uint8    255 levels -> ~123 surviving the boost, which is BELOW the 255
               the display wants. Measured: 65% of pixels differ from the
               float32 reference, and the frame carries 73 distinct levels
               where float32 carries 136 -- visible banding. The low-RAM tier
               was quietly degrading the exact stretch people turn on to
               inspect faint detail, on the machines least able to spare the
               quality.

    uint16 is the only width that is neither lossy nor wasteful, and it halves
    Blink's footprint on any machine that used to get float32 (a 6000x4000
    frame goes 96 MB -> 48 MB; 500 of them, 48 GB -> 24 GB). The real memory
    lever is the 1:2 / 1:4 / 1:8 buttons, which cut 4x / 16x / 64x.
    """
    return np.uint16


def _blink_mem_guard_enabled() -> bool:
    """Kill switch for the PreLoad memory guard (QSettings 'blink/mem_guard').

    On by default. Off means PreLoad behaves exactly as it did before the
    guard existed, including running the machine out of memory -- which is
    occasionally what someone with a lot of swap actually wants.
    """
    try:
        return bool(QSettings().value("blink/mem_guard", True, type=bool))
    except Exception:
        return True


def _blink_mem_headroom_frac() -> float:
    """Fraction of currently-available RAM PreLoad may plan to fill.

    0.70 leaves three tenths of what is free right now for the OS, the rest of
    SASpro, and the decode working set. Raising it toward 1.0 trades safety
    margin for the ability to PreLoad bigger folders.
    """
    try:
        v = float(QSettings().value("blink/mem_headroom", 0.70, type=float))
    except Exception:
        v = 0.70
    return min(0.95, max(0.10, v))


def _blink_available_bytes():
    """``(available, total)`` physical memory, or ``(None, None)`` if unknown.

    'available' rather than 'free' on purpose: free excludes reclaimable page
    cache, which would read as catastrophically low on any machine that has
    been reading FITS files all evening.
    """
    if psutil is None:
        return None, None
    try:
        vm = psutil.virtual_memory()
        return int(vm.available), int(vm.total)
    except Exception:
        return None, None


def _blink_fmt_bytes(n) -> str:
    """Bytes as something that fits in a sentence."""
    try:
        n = float(n)
    except Exception:
        return "?"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024.0 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} TB"


_BLINK_PROBE_SAMPLE = 12


def _blink_estimate_frame_bytes(paths, load_scale, *, itemsize=2,
                                sample=_BLINK_PROBE_SAMPLE):
    """Mean STORED bytes per frame, from a sample of cheap header probes.

    Returns ``(bytes_per_frame, probed_count)``, or ``(None, 0)`` when nothing
    in the sample reports a geometry. FITS and XISF both answer from a header
    block in well under a millisecond; TIFF / PNG / RAW have no cheap size at
    all, and those loads fall to the in-flight guard instead.

    Channels are counted the way ``_load_one_image`` will end up STORING them,
    not the way they sit on disk: NAXIS3=3 stays three, and a BAYERPAT frame
    becomes three through the debayer -- unless the luminance CFA mode collapses
    it, which only applies where the strided reader engages.

    The mean, not the max: for the usual one-camera folder they are the same
    number, and for a mixed folder the mean is the honest estimator of the total
    while the max would push people into Stream who did not need to be there.
    """
    n = len(paths)
    if n == 0:
        return None, 0

    k = min(int(sample), n)
    if k <= 1:
        idxs = [0]
    else:
        idxs = sorted({int(round(i * (n - 1) / (k - 1))) for i in range(k)})

    scale = max(1, int(load_scale or 1))
    cfa_luma = (_blink_cfa_mode() == "luminance" and scale >= _FAST_MIN_STEP)

    sizes = []
    for i in idxs:
        try:
            hdr, wh = probe_header(paths[i])
        except Exception:
            continue
        if not wh:
            continue
        try:
            w, h = int(wh[0]), int(wh[1])
        except Exception:
            continue
        if w <= 0 or h <= 0:
            continue

        ch = 1
        try:
            if hdr is not None:
                naxis = int(hdr.get("NAXIS", 2) or 2)
                naxis3 = int(hdr.get("NAXIS3", 1) or 1)
                if naxis == 3 and naxis3 == 3:
                    ch = 3
                elif str(hdr.get("BAYERPAT", "") or "").strip():
                    ch = 1 if cfa_luma else 3
        except Exception:
            ch = 1

        sizes.append(max(1, h // scale) * max(1, w // scale) * ch * itemsize)

    if not sizes:
        return None, 0
    return int(sum(sizes) / len(sizes)), len(sizes)


def _clamp(v, lo, hi):
    return lo if v < lo else (hi if v > hi else v)


def _zoom_box_rect(pix_w, pix_h, disp_x, disp_y, disp_w, disp_h,
                   norm_cx, norm_cy, crop_w_src, crop_h_src,
                   hscroll, vscroll):
    """Viewport rect for the zoom-box overlay, as (x, y, w, h) or None.

    Everything is mapped through the rect the scaled pixmap ACTUALLY occupies
    (disp_*), not through the label. The scroll area is widgetResizable, so
    once the image is smaller than the viewport Qt stretches the label out to
    the viewport and centres the pixmap in it. Label space and image space
    then disagree on both scale and origin, which is what made the box drift
    off the image and turn into a tall thin sliver: the old code divided the
    label's width by the image's width for the x scale and the label's height
    by the image's height for the y scale, and with a letterboxed image those
    two ratios are nothing alike.

    crop_*_src is the zoom panel's view size in SOURCE pixels, so the box
    shrinks as you zoom out -- that is correct, the panel really is showing
    that much less of the frame relative to what you can see. It is capped at
    the image so a far-out zoom cannot draw a box bigger than the picture.
    """
    if pix_w <= 0 or pix_h <= 0 or disp_w <= 0 or disp_h <= 0:
        return None
    sx = disp_w / float(pix_w)
    sy = disp_h / float(pix_h)
    bw = min(float(crop_w_src) * sx, disp_w)
    bh = min(float(crop_h_src) * sy, disp_h)
    cx = disp_x + _clamp(norm_cx, 0.0, 1.0) * disp_w
    cy = disp_y + _clamp(norm_cy, 0.0, 1.0) * disp_h
    x = _clamp(cx - bw / 2.0, disp_x, disp_x + disp_w - bw)
    y = _clamp(cy - bh / 2.0, disp_y, disp_y + disp_h - bh)
    return (x - hscroll, y - vscroll, bw, bh)


def _norm_from_viewport_pos(vx, vy, disp_x, disp_y, disp_w, disp_h,
                            hscroll, vscroll):
    """Viewport point -> normalized image coords, through the displayed rect.

    Inverse of the mapping in _zoom_box_rect. A click in the letterbox around
    a zoomed-out image clamps to the nearest edge of the image rather than
    reporting a position outside it.
    """
    if disp_w <= 0 or disp_h <= 0:
        return 0.5, 0.5
    lx = vx + hscroll
    ly = vy + vscroll
    return (_clamp((lx - disp_x) / float(disp_w), 0.0, 1.0),
            _clamp((ly - disp_y) / float(disp_h), 0.0, 1.0))


def _percentile_scale(arr, lo=0.5, hi=99.5):
    a = np.asarray(arr, dtype=np.float32)
    p1 = np.nanpercentile(a, lo)
    p2 = np.nanpercentile(a, hi)
    if not np.isfinite(p1) or not np.isfinite(p2) or p2 <= p1:
        return np.clip(a, 0.0, 1.0)
    return np.clip((a - p1) / (p2 - p1), 0.0, 1.0)


# ── Robust FITS header parsing for temperature & exposure ──────────────────
# Mirrors the Stacking Suite's tolerant reads so Blink / Blink Metrics see the
# same temps and exposures the stacker does: many keyword spellings, and string
# values carrying units ("-10 C", "300 s", EXIF "1/125").

# Actual-sensor temps first; the cooler SETPOINT (SET-TEMP) is the last resort,
# matching the stacker's "prefer CCD-TEMP over SET-TEMP". DET-TEMP and common
# variants are included so detectors that only write those are read.
_BLINK_TEMP_KEYS = (
    "CCD-TEMP", "CCDTEMP", "CCD_TEMP",
    "DET-TEMP", "DETTEMP", "DET_TEMP",
    "SENSOR-TEMP", "SENSORTEMP", "SENSOR_TEMP",
    "CAMTEMP", "CAM-TEMP", "TEMPERAT", "TEMP",
    "SET-TEMP", "SETTEMP", "SET_TEMP", "SETPOINT",
)

_BLINK_EXP_KEYS = (
    "EXPTIME", "EXPOSURE", "XPOSURE",
    "EXP-TIME", "EXP_TIME", "EXPTIMES",
    "ITIME", "INTTIME", "EXP",
)


def _blink_hdr_get(hdr, key):
    """Header .get that works on an astropy Header or a plain dict."""
    if hdr is None:
        return None
    try:
        if key in hdr:
            return hdr[key]
    except Exception:
        pass
    try:
        return hdr.get(key, None)
    except Exception:
        return None


def _blink_key_float(hdr, key):
    """Float value for one key, tolerant of unit-carrying strings and simple
    EXIF fractions. Returns None when absent or unparseable."""
    v = _blink_hdr_get(hdr, key)
    if v is None:
        return None
    try:
        if isinstance(v, bool):
            return None
        if isinstance(v, (int, float)):
            f = float(v)
            return f if np.isfinite(f) else None
        s = str(v).strip()
        if not s:
            return None
        s = s.replace("\u2212", "-")          # unicode minus -> ASCII
        s = s.replace("\u00b0", "").replace("\u00ba", "")  # degree marks
        low = s.lower()
        for _u in ("seconds", "second", "secs", "sec"):
            if low.endswith(_u):
                s = s[: -len(_u)]
                break
        s = s.rstrip()
        # trailing 's'/'c' unit, tolerating a space before it ("300 s", "-10 C"),
        # but only when a number-like token precedes it (never mangle text values)
        if s and s[-1] in ("s", "S", "c", "C"):
            _s2 = s[:-1].rstrip()
            if _s2 and (_s2[-1].isdigit() or _s2[-1] == "."):
                s = _s2
        s = s.strip()
        if not s:
            return None
        if "/" in s:                            # EXIF shutter fraction "1/125"
            top, bot = s.split("/", 1)
            f = float(top) / float(bot)
        else:
            f = float(s)
        return f if np.isfinite(f) else None
    except Exception:
        return None


def _blink_hdr_temp_c(hdr):
    """Sensor temperature (deg C) from the first present temp keyword, or None."""
    for _k in _BLINK_TEMP_KEYS:
        f = _blink_key_float(hdr, _k)
        if f is not None:
            return f
    return None


def _blink_hdr_exptime(hdr):
    """Exposure time (seconds) from the first present exposure keyword, or None."""
    for _k in _BLINK_EXP_KEYS:
        f = _blink_key_float(hdr, _k)
        if f is not None and f > 0:
            return f
    return None


def _blink_exposure_label(hdr):
    """Canonical exposure label for tree grouping/display ('300s', '1.5s'), or
    'Unknown'. Normalizes 300, '300.0' and '300 s' into one bucket."""
    f = _blink_hdr_exptime(hdr)
    if f is None:
        return "Unknown"
    if abs(f - round(f)) < 1e-6:
        return f"{int(round(f))}s"
    return f"{f:.3f}".rstrip("0").rstrip(".") + "s"


# ⬇️ your SASv2 classes — paste them unchanged (Qt6 compatible already)
class MetricsPanel(QWidget):
    """2×2 grid with clickable dots and draggable thresholds."""
    pointClicked = pyqtSignal(int, int)
    thresholdChanged = pyqtSignal(int, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        grid = QGridLayout()
        layout.addLayout(grid)

        # Stream-mode hooks, injected by BlinkTab.show_metrics. pixel_loader
        # is idx -> ndarray|None and decodes a frame just in time; shape_hint
        # is idx -> (h, w) for the worker heuristic. Both None in PreLoad.
        self.pixel_loader = None
        self.shape_hint = None

        # caching slots
        self._orig_images = None       # last list passed
        self.metrics_data = None       # list of 7 numpy arrays
        self.flags = None              # list of bools
        self._threshold_initialized = [False]*7
        self._last_group_id = None
        self._open_previews = []
        self._show_guides = True  # default on (or False if you prefer)

        self.plots, self.scats, self.lines = [], [], []
        self.median_lines = []
        self.sigma_lines = []
        self.sigma1_lines = []  
        self.sigma2_lines = []  
        titles = [
            self.tr("FWHM (px)"),
            self.tr("Eccentricity"),
            self.tr("Background"),
            self.tr("Star Count"),
            self.tr("Weighted Score"),
            self.tr("Sensor Temp (°C)"),
            self.tr("Bg Rate (ADU/s)"),
        ]

        # Layout: 3 cols × 3 rows
        # Col 0: FWHM (row 0), Background (row 1), Sensor Temp (row 2)
        # Col 1: Eccentricity (row 0), Star Count (row 1), Bg Rate (row 2)
        # Col 2: Weighted Score (rows 0-2, rowspan 3)
        grid_positions = [
            (0, 0),   # FWHM
            (0, 1),   # Eccentricity
            (1, 0),   # Background
            (1, 1),   # Star Count
            (0, 2),   # Weighted Score — will use rowspan=3
            (2, 0),   # Sensor Temp (°C)
            (2, 1),   # Bg Rate (ADU/s)
        ]

        for idx, (title, (grow, gcol)) in enumerate(zip(titles, grid_positions)):
            pw = pg.PlotWidget()
            pw.setTitle(title)
            pw.showGrid(x=True, y=True, alpha=0.3)
            pw.getPlotItem().getViewBox().setBackgroundColor(
                self.palette().color(self.backgroundRole())
            )

            scat = pg.ScatterPlotItem(pen=pg.mkPen(None),
                                      brush=pg.mkBrush(100, 100, 255, 200),
                                      size=8)
            scat.sigClicked.connect(lambda plot, pts, m=idx: self._on_point_click(m, pts))
            pw.addItem(scat)

            line = pg.InfiniteLine(pos=0, angle=0, movable=True,
                                   pen=pg.mkPen('r', width=2))
            line.sigPositionChangeFinished.connect(
                lambda ln, m=idx: self._on_line_move(m, ln))
            pw.addItem(line)

            median_ln = pg.InfiniteLine(pos=0, angle=0, movable=False,
                                        pen=pg.mkPen((220, 220, 220, 170), width=1,
                                                     style=Qt.PenStyle.DashLine))
            # 3σ — red
            sigma_lo = pg.InfiniteLine(pos=0, angle=0, movable=False,
                                    pen=pg.mkPen((220, 50, 50, 120), width=1,
                                                    style=Qt.PenStyle.DashLine))
            sigma_hi = pg.InfiniteLine(pos=0, angle=0, movable=False,
                                    pen=pg.mkPen((220, 50, 50, 120), width=1,
                                                    style=Qt.PenStyle.DashLine))

            # 2σ — orange
            sigma2_lo = pg.InfiniteLine(pos=0, angle=0, movable=False,
                                        pen=pg.mkPen((255, 140, 0, 120), width=1,
                                                    style=Qt.PenStyle.DashLine))
            sigma2_hi = pg.InfiniteLine(pos=0, angle=0, movable=False,
                                        pen=pg.mkPen((255, 140, 0, 120), width=1,
                                                    style=Qt.PenStyle.DashLine))

            # 1σ — yellow
            sigma1_lo = pg.InfiniteLine(pos=0, angle=0, movable=False,
                                        pen=pg.mkPen((255, 220, 50, 120), width=1,
                                                    style=Qt.PenStyle.DashLine))
            sigma1_hi = pg.InfiniteLine(pos=0, angle=0, movable=False,
                                        pen=pg.mkPen((255, 220, 50, 120), width=1,
                                                    style=Qt.PenStyle.DashLine))
            median_ln.setZValue(-10)

            pw.addItem(median_ln)

            for ln in (sigma_lo, sigma_hi, sigma2_lo, sigma2_hi, sigma1_lo, sigma1_hi):
                ln.setZValue(-10)
                pw.addItem(ln)
                ln.hide()

            self.sigma_lines.append((sigma_lo, sigma_hi))
            self.sigma2_lines.append((sigma2_lo, sigma2_hi))
            self.sigma1_lines.append((sigma1_lo, sigma1_hi))

            self.median_lines.append(median_ln)


            # Weighted Score spans all rows in col 2
            if idx == 4:
                grid.addWidget(pw, grow, gcol, 3, 1)
            else:
                grid.addWidget(pw, grow, gcol)

            self.plots.append(pw)
            self.scats.append(scat)
            self.lines.append(line)

    def set_guides_visible(self, on: bool):
        self._show_guides = bool(on)

        if not self._show_guides:
            # ✅ hide immediately
            if hasattr(self, "median_lines"):
                for ln in self.median_lines:
                    ln.hide()
            if hasattr(self, "sigma_lines"):
                for lo, hi in self.sigma_lines:
                    lo.hide()
                    hi.hide()
                for lo, hi in self.sigma2_lines:
                    lo.hide(); hi.hide()
                for lo, hi in self.sigma1_lines:
                    lo.hide(); hi.hide()                    
            return

        # ✅ turning ON: recompute/restore based on what’s currently plotted
        self._refresh_guides_from_current_plot()

    def _refresh_guides_from_current_plot(self):
        """Recompute/position guide lines using current plot data (if any)."""
        if not getattr(self, "_show_guides", True):
            return
        if not hasattr(self, "median_lines") or not hasattr(self, "sigma_lines"):
            return
        # Use the scatter data already in each panel
        for m, scat in enumerate(self.scats):
            x, y = scat.getData()[:2]
            if y is None or len(y) == 0:
                self.median_lines[m].hide()
                lo, hi = self.sigma_lines[m]
                lo.hide(); hi.hide()
                continue

            med, sig = self._median_and_robust_sigma(np.asarray(y, dtype=np.float32))
            mline = self.median_lines[m]
            lo_ln, hi_ln = self.sigma_lines[m]

            if np.isfinite(med):
                mline.setPos(med); mline.show()
            else:
                mline.hide()

            if np.isfinite(med) and np.isfinite(sig) and sig > 0:
                # 3σ (existing)
                lo_ln.setPos(med - 3.0 * sig); hi_ln.setPos(med + 3.0 * sig)
                lo_ln.show(); hi_ln.show()
                # 2σ
                lo2, hi2 = self.sigma2_lines[m]
                lo2.setPos(med - 2.0 * sig); hi2.setPos(med + 2.0 * sig)
                lo2.show(); hi2.show()
                # 1σ
                lo1, hi1 = self.sigma1_lines[m]
                lo1.setPos(med - 1.0 * sig); hi1.setPos(med + 1.0 * sig)
                lo1.show(); hi1.show()
            else:
                lo_ln.hide(); hi_ln.hide()


    @staticmethod
    def _median_and_robust_sigma(y: np.ndarray):
        """Return (median, sigma) using MAD-based robust sigma. Ignores NaN/Inf."""
        y = np.asarray(y, dtype=np.float32)
        finite = np.isfinite(y)
        if not finite.any():
            return np.nan, np.nan
        v = y[finite]
        med = float(np.nanmedian(v))
        mad = float(np.nanmedian(np.abs(v - med)))
        sigma = 1.4826 * mad  # robust sigma estimate
        return med, float(sigma)


    @staticmethod
    def _compute_one(i_entry):
        import cv2
        import sep
        import numpy as np
        import math

        # (idx, entry) in PreLoad; (idx, entry, loader) in Stream, where
        # loader(idx) -> ndarray|None decodes the frame just in time and is
        # expected to have already folded header/bit_depth/orig_background
        # back onto the entry before it returns.
        if len(i_entry) == 3:
            idx, entry, loader = i_entry
        else:
            (idx, entry), loader = i_entry, None
        img = entry.get("image_data", None)
        if img is None and loader is not None:
            try:
                img = loader(idx)
            except Exception as e:
                print(f"[Blink] metrics load failed for index {idx}: {e}")
                img = None
        load_scale = int(entry.get("load_scale", 1))

        BAD_FWHM = 30.0
        BAD_ECC  = 1.0

        # QA metrics for the extended MetricsPanel. Sensor temp and
        # OFFSET-corrected bg rate. Both from header only; nothing
        # derived from light-frame content itself. Amp glow was
        # removed in v3 because on light frames it's indistinguishable
        # from LP gradient, moon glow, nebulosity, and vignette
        # residual -- corner-vs-corner picks all of them up as one
        # blended number.
        _hdr = entry.get("header", {}) or {}
        _bd  = entry.get("bit_depth", None)
        _orig_bg = entry.get("orig_background", np.nan)

        def _hget(*keys):
            for _k in keys:
                if _k in _hdr:
                    _v = _hdr[_k]
                    try:
                        _f = float(_v)
                    except (TypeError, ValueError):
                        continue
                    if np.isfinite(_f):
                        return _f
            return float("nan")

        _tc = _blink_hdr_temp_c(_hdr)
        _temp_c  = _tc if _tc is not None else float("nan")
        _et = _blink_hdr_exptime(_hdr)
        _exptime = _et if _et is not None else float("nan")
        _offset  = _hget("OFFSET", "BIAS")
        # Many acquisition tools (SGP with default templates observed;
        # some ASCOM drivers) don't write OFFSET or BIAS to the FITS
        # header. Fall back to 0 rather than reporting NaN: the
        # missing pedestal is a per-SESSION constant, so within-
        # session RELATIVE ordering of frames by Bg Rate is preserved
        # (which is what blink uses for culling). Only the absolute
        # ADU/s value is inflated by OFFSET_adu / exptime.
        if not np.isfinite(_offset):
            _offset = 0.0

        # OFFSET-corrected bg rate (ADU/s). orig_background is
        # normalized [0,1] on pre-stretch data; scale by
        # (2**bit_depth - 1) to ADU, subtract the OFFSET pedestal
        # (0 when not in header -- see fallback above), divide by
        # exposure. Note the header name is often "BIAS" but on CMOS
        # there is no true bias frame -- CDS eliminates any sensor
        # reset pedestal -- so this is really OFFSET subtraction.
        # bit_depth from load_image can be an int (16), a numpy int,
        # a float, or a human-readable string like "16-bit" / "16 bit"
        # depending on which loader path the file went through. Extract
        # the leading integer so all forms work; the plain int(_bd)
        # that shipped in v1 raised ValueError on "16-bit" and left
        # every frame's bg_rate NaN silently (caught by the outer
        # except).
        _bd_bits = None
        if _bd is not None:
            try:
                _bd_bits = int(_bd)
            except (TypeError, ValueError):
                try:
                    import re as _re_bd
                    _m_bd = _re_bd.match(r"\s*(\d+)", str(_bd))
                    if _m_bd:
                        _bd_bits = int(_m_bd.group(1))
                except Exception:
                    _bd_bits = None

        _bg_rate = float("nan")
        try:
            if (_bd_bits is not None and np.isfinite(_orig_bg) and _orig_bg > 0
                    and np.isfinite(_exptime) and _exptime > 0):
                _depth_scale = float((1 << _bd_bits) - 1)
                if _depth_scale > 0:
                    _bg_adu  = float(_orig_bg) * _depth_scale
                    _bg_corr = _bg_adu - float(_offset)
                    if _bg_corr > 0:
                        _bg_rate = _bg_corr / float(_exptime)
        except Exception:
            _bg_rate = float("nan")

        try:
            if img is None:
                orig_back = entry.get("orig_background", np.nan)
                return idx, BAD_FWHM, BAD_ECC, orig_back, 0, 0.0, _temp_c, _bg_rate

            data = np.asarray(img)
            h0, w0 = data.shape[:2]

            if data.ndim == 3:
                data = data.mean(axis=2)

            if data.dtype == np.uint8:
                data = data.astype(np.float32) / 255.0
            elif data.dtype == np.uint16:
                data = data.astype(np.float32) / 65535.0
            else:
                data = data.astype(np.float32, copy=False)

            if not np.isfinite(data).all():
                data = np.nan_to_num(data, nan=0.0, posinf=1.0, neginf=0.0).astype(np.float32, copy=False)

            new_w = max(16, int(w0 // 2))
            new_h = max(16, int(h0 // 2))
            ds = cv2.resize(data, (new_w, new_h), interpolation=cv2.INTER_AREA).astype(np.float32, copy=False)

            bkg = sep.Background(ds)
            back = bkg.back()
            try:
                gr = float(bkg.globalrms)
            except Exception:
                try:
                    gr = float(np.nanmedian(np.asarray(bkg.rms(), dtype=np.float32)))
                except Exception:
                    gr = np.nan
            if not np.isfinite(gr) or gr <= 0:
                gr = None

            candidates = [
                (7.0, 4),
                (5.0, 4),
                (4.0, 3),
                (3.5, 2),
            ]
            cat = None
            for thr, minarea in candidates:
                try:
                    cat = sep.extract(
                        ds - back,
                        thresh=float(thr),
                        err=gr,
                        minarea=int(minarea),
                        clean=True,
                        deblend_nthresh=32,
                    )
                except Exception:
                    cat = None
                if cat is not None and len(cat) > 0:
                    break

            if cat is None or len(cat) == 0:
                orig_back = entry.get("orig_background", np.nan)
                return idx, BAD_FWHM, BAD_ECC, orig_back, 0, 0.0, _temp_c, _bg_rate

            a = np.maximum(cat["a"].astype(np.float32, copy=False), 1e-12)
            b = np.maximum(cat["b"].astype(np.float32, copy=False), 0.0)

            sig = np.sqrt(a * b).astype(np.float32, copy=False)
            fwhm_ds = float(np.nanmedian(2.3548 * sig))
            fwhm = fwhm_ds * 2.0 * load_scale

            q = np.clip(b / a, 0.0, 1.0)
            e_true = np.sqrt(np.maximum(0.0, 1.0 - q * q))
            ecc = float(np.nanmedian(e_true))

            star_cnt = int(len(cat))
            orig_back = entry.get("orig_background", np.nan)

            bg = float(orig_back) if np.isfinite(orig_back) and orig_back > 0 else 1e-6
            bg_clamped  = float(min(max(bg, 0.0), 1.0))
            ecc_clamped = float(min(max(ecc, 0.0), 1.0))
            ecc_term    = 1.0 - ecc_clamped
            bg_term     = (2.0 / (math.sqrt(bg_clamped) + 1.0)) - 1.0
            weighted_score = float(star_cnt) * ecc_term * bg_term if star_cnt > 0 else 0.0

            return idx, fwhm, ecc, orig_back, star_cnt, weighted_score, _temp_c, _bg_rate

        except Exception:
            orig_back = entry.get("orig_background", np.nan)
            return idx, BAD_FWHM, BAD_ECC, orig_back, 0, 0.0, _temp_c, _bg_rate



    def compute_all_metrics(self, loaded_images, loader=None,
                            shape_hint=None) -> bool:
        """
        Run SEP over the full list in parallel using threads and cache results.
        Uses *downsampled* SEP for speed + lower RAM.
        Returns True if metrics were computed, False if user canceled.

        ``loader`` is Stream mode's just-in-time decoder, loader(idx) ->
        ndarray|None. When given, frames are loaded, measured and released one
        at a time instead of having to be resident up front; the measurements
        are what persist. ``shape_hint`` is a callable idx -> (h, w) used for
        the worker-count heuristic, since in Stream mode there is no frame to
        measure before the run starts.
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed
        import os
        import numpy as np
        from PyQt6.QtCore import Qt
        from PyQt6.QtWidgets import QProgressDialog, QApplication

        if loader is None:
            loader = self.pixel_loader
        if shape_hint is None:
            shape_hint = self.shape_hint

        n = len(loaded_images)
        if n == 0:
            self._orig_images = []
            self.metrics_data = [np.array([])] * 7
            self.flags = []
            self._threshold_initialized = [False] * 7
            return True

        # ----------------------------
        # 1) Allocate result arrays
        # ----------------------------
        m0 = np.full(n, np.nan, dtype=np.float32)  # FWHM (full-res px units)
        m1 = np.full(n, np.nan, dtype=np.float32)  # Eccentricity
        m2 = np.full(n, np.nan, dtype=np.float32)  # Background (cached)
        m3 = np.full(n, np.nan, dtype=np.float32)  # Star count
        m4 = np.full(n, np.nan, dtype=np.float32)  # Weighted score        
        m5 = np.full(n, np.nan, dtype=np.float32)  # Sensor temp (°C, header)
        m6 = np.full(n, np.nan, dtype=np.float32)  # Bg rate (ADU/s, OFFSET-corrected)
        flags = [e.get("flagged", False) for e in loaded_images]

        # ----------------------------
        # 2) Progress dialog (Cancel)
        # ----------------------------
        prog = QProgressDialog(
            self.tr("Loading and measuring frames…") if loader is not None
            else self.tr("Computing frame metrics…"),
            self.tr("Cancel"), 0, n, self)
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(0)
        prog.setValue(0)
        prog.show()
        QApplication.processEvents()

        cpu = os.cpu_count() or 1

        # ----------------------------
        # 3) Worker sizing by contention-aware heuristic
        # ----------------------------
        #sasprofiling shows SEP's internal C allocator serializes under heavy
        # threading on large images — more workers = more contention = slower
        # wall time. RAM is not the constraint; allocator lock contention is.
        # Empirically 4-6 workers is the sweet spot for bin-2 downsampled frames.
        _first = loaded_images[0].get("image_data")
        if _first is not None:
            h0, w0 = _first.shape[:2]
        elif shape_hint is not None:
            h0, w0 = shape_hint(0)
        else:
            h0, w0 = 2048, 2048
        ds_pixels = (h0 // 2) * (w0 // 2)

        if ds_pixels > 8_000_000:       # >8MP downsampled (e.g. 5644x8288 -> ~11.7MP)
            workers = min(4, cpu)
        elif ds_pixels > 4_000_000:     # >4MP downsampled
            workers = min(6, cpu)
        elif ds_pixels > 1_000_000:     # >1MP downsampled
            workers = min(8, cpu)
        else:                           # small frames, contention minimal
            workers = min(12, cpu)

        workers = max(1, workers)

        if loader is not None:
            # Streaming: decoding dominates, and every in-flight frame is a
            # full-resolution array held at once. Keep the fan-out tight so
            # peak memory stays near workers x frame size rather than n x it.
            workers = max(1, min(workers, 4))
            tasks = [(i, loaded_images[i], loader) for i in range(n)]
        else:
            tasks = [(i, loaded_images[i]) for i in range(n)]
        done = 0
        canceled = False

        try:
            with ThreadPoolExecutor(max_workers=workers) as exe:
                futures = {exe.submit(self._compute_one, t): t[0] for t in tasks}
                for fut in as_completed(futures):
                    if prog.wasCanceled():
                        canceled = True
                        break

                    try:
                        idx, fwhm, ecc, orig_back, star_cnt, weighted_score, temp_c, bg_rate = fut.result()
                    except Exception:
                        idx = futures.get(fut, 0)
                        fwhm, ecc, orig_back, star_cnt, weighted_score = np.nan, np.nan, np.nan, 0, 0.0
                        temp_c, bg_rate = np.nan, np.nan

                    if 0 <= idx < n:
                        m0[idx] = fwhm
                        m1[idx] = ecc
                        m2[idx] = orig_back
                        m3[idx] = float(star_cnt)
                        m4[idx] = float(weighted_score)
                        m5[idx] = float(temp_c)
                        m6[idx] = float(bg_rate)

                    done += 1
                    prog.setValue(done)
                    QApplication.processEvents()
        finally:
            prog.close()

        if canceled:
            # IMPORTANT: leave caches alone; caller handles clear/return
            return False

        # ----------------------------
        # 4) Stash results
        # ----------------------------
        self._orig_images = loaded_images
        self.metrics_data = [m0, m1, m2, m3, m4, m5, m6]
        self.flags = flags
        self._threshold_initialized = [False] * 7
        return True

    def plot(self, loaded_images, indices=None):
        """
        Plot metrics for loaded_images.
        If indices is given (list/array of ints), only those frames are shown.
        """
        # empty clear
        if not loaded_images:
            self.metrics_data = None
            for pw, scat, line in zip(self.plots, self.scats, self.lines):
                scat.setData(x=[], y=[])
                line.setPos(0)
                pw.getPlotItem().getViewBox().update()
                pw.repaint()

            # ✅ hide guides too
            if hasattr(self, "median_lines"):
                for ln in self.median_lines:
                    ln.hide()
            if hasattr(self, "sigma_lines"):
                for lo, hi in self.sigma_lines:
                    lo.hide()
                    hi.hide()
                for lo, hi in self.sigma2_lines:
                    lo.hide(); hi.hide()
                for lo, hi in self.sigma1_lines:
                    lo.hide(); hi.hide()                    
            return

        # compute & cache on first call or new image list
        if self._orig_images is not loaded_images or self.metrics_data is None:
            ok = self.compute_all_metrics(loaded_images)
            if not ok or self.metrics_data is None:
                # user declined/canceled -> clear plots and exit cleanly
                for pw, scat, line in zip(self.plots, self.scats, self.lines):
                    scat.setData(x=[], y=[])
                    line.setPos(0)
                    pw.getPlotItem().getViewBox().update()
                    pw.repaint()
                return


        # default to all indices
        if indices is None:
            indices = np.arange(len(loaded_images), dtype=int)

        # store for later recoloring
        self._cur_indices = np.array(indices, dtype=int)

        x = np.arange(len(indices))

        for m, (pw, scat, line) in enumerate(zip(self.plots, self.scats, self.lines)):
            arr = self.metrics_data[m]
            y   = arr[indices]

            brushes = [
                pg.mkBrush(255,0,0,200) if self.flags[idx] else pg.mkBrush(100,100,255,200)
                for idx in indices
            ]
            scat.setData(x=x, y=y, brush=brushes, pen=pg.mkPen(None), size=8)

            # --- update dashed reference lines (median + ±3σ) ---
            if getattr(self, "_show_guides", True):
                try:
                    med, sig = self._median_and_robust_sigma(y)
                    mline = self.median_lines[m]
                    lo_ln, hi_ln = self.sigma_lines[m]

                    if np.isfinite(med):
                        mline.setPos(med)
                        mline.show()
                    else:
                        mline.hide()

                    if np.isfinite(med) and np.isfinite(sig) and sig > 0:
                        lo = med - 3.0 * sig
                        hi = med + 3.0 * sig
                        if m == 3:
                            lo = max(0.0, lo)
                        lo_ln.setPos(lo); hi_ln.setPos(hi)
                        lo_ln.show(); hi_ln.show()
                    else:
                        lo_ln.hide(); hi_ln.hide()
                except Exception:
                    if hasattr(self, "median_lines") and m < len(self.median_lines):
                        self.median_lines[m].hide()
                        a, b = self.sigma_lines[m]
                        a.hide(); b.hide()
            else:
                # guides disabled -> force-hide
                if hasattr(self, "median_lines") and m < len(self.median_lines):
                    self.median_lines[m].hide()
                    a, b = self.sigma_lines[m]
                    a.hide(); b.hide()


            # initialize threshold line once
            # initialize threshold line if this is a new group and no saved threshold
            if not self._threshold_initialized[m]:
                # NaN guard: any of the new metrics (Sensor Temp, Amp
                # Glow, Bg Rate) can be all-NaN for a group when the
                # underlying header field is missing on every frame.
                # np.nanmax on all-NaN returns NaN with a warning and
                # pyqtgraph then crashes in transformAngle rounding
                # NaN to int. Force finite; park the line at 0 and let
                # the user drag it once real data is present.
                with np.errstate(all="ignore"):
                    mx = np.nanmax(y) if len(y) else np.nan
                    mn = np.nanmin(y) if len(y) else np.nan
                if not (np.isfinite(mx) and np.isfinite(mn)):
                    line.setPos(0.0)
                else:
                    span = (mx - mn) if mx != mn else 1.0
                    # Higher = worse for FWHM/Ecc/Bg/SensorTemp/BgRate
                    # (m in 0,1,2,5,6): a warmer sensor means more dark
                    # current / thermal noise, so treat it like the other
                    # higher-is-worse metrics. Park the line just above the
                    # data so nothing flags on open; drag DOWN to flag.
                    # Lower = worse for Star Count / Weighted Score (m in 3,4).
                    line.setPos((mx + 0.05 * span) if m in (0, 1, 2, 5, 6) else 0)
                self._threshold_initialized[m] = True

    def _refresh_scatter_colors(self):
        if not hasattr(self, "_cur_indices") or self._cur_indices is None:
            # default to all indices
            self._cur_indices = np.arange(len(self.flags or []), dtype=int)

        for scat in self.scats:
            x, y = scat.getData()[:2]
            brushes = []
            for xi in x:
                li = int(xi)
                gi = self._cur_indices[li] if 0 <= li < len(self._cur_indices) else 0
                brushes.append(pg.mkBrush(255,0,0,200) if (self.flags and gi < len(self.flags) and self.flags[gi])
                            else pg.mkBrush(100,100,255,200))
            scat.setData(x=x, y=y, brush=brushes)

    def remove_frames(self, removed_idx: List[int]):
        """
        Drop frames from cached arrays and flags (no recomputation).
        removed_idx: global indices in the *old* ordering.
        """
        if self.metrics_data is None or not removed_idx:
            return
        import numpy as _np
        removed = _np.unique(_np.asarray(removed_idx, dtype=int))
        n = len(self.flags or [])
        if n == 0:
            return
        keep = _np.ones(n, dtype=bool)
        keep[removed[removed < n]] = False

        # shrink cached arrays and flags
        self.metrics_data = [arr[keep] for arr in self.metrics_data]
        if self.flags is not None:
            self.flags = list(_np.asarray(self.flags)[keep])

    def refresh_colors_and_status(self):
        """Recolor dots based on self.flags; caller should also update the window status."""
        self._refresh_scatter_colors()

    def _on_point_click(self, metric_idx, points):
        for pt in points:
            # local index on the currently plotted subset
            li = int(round(pt.pos().x()))

            # map to global index
            if hasattr(self, "_cur_indices") and self._cur_indices is not None and 0 <= li < len(self._cur_indices):
                gi = int(self._cur_indices[li])
            else:
                gi = li  # fallback (e.g., "All")

            mods = QApplication.keyboardModifiers()
            if mods & Qt.KeyboardModifier.ShiftModifier:
                # preview the correct global frame
                entry  = self._orig_images[gi]
                img    = entry.get('image_data')
                if img is None and self.pixel_loader is not None:
                    img = self.pixel_loader(gi)
                if img is None:
                    continue
                is_mono= entry.get('is_mono', False)
                dlg = ImagePreviewDialog(img, is_mono)
                dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
                dlg.show()
                self._open_previews.append(dlg)
                dlg.destroyed.connect(lambda _=None, d=dlg:
                    self._open_previews.remove(d) if d in self._open_previews else None)
            else:
                # emit the correct global frame index so Blink flags the right leaf
                self.pointClicked.emit(metric_idx, gi)

    def _on_line_move(self, metric_idx, line):
        self.thresholdChanged.emit(metric_idx, line.value())

class MetricsWindow(QWidget):
    def __init__(self, parent=None):
        # Plain top-level window — no WindowStaysOnTopHint. That flag forces
        # the window above EVERY application on the OS, not just SASpro's
        # main window, which is not what we want. A normal Window flag still
        # keeps it as its own window (so it won't get hidden inside the MDI
        # area on macOS), but respects normal OS focus/z-order rules.
        super().__init__(parent, Qt.WindowType.Window)
        self._thresholds_per_group: dict[str, List[float|None]] = {}
        self.setWindowTitle(self.tr("Frame Metrics"))
        self.resize(900, 780)

        vbox = QVBoxLayout(self)

        # ← **new** instructions label
        instr = QLabel(self.tr(
            "Instructions:\n"
            " • Use the filter dropdown to restrict by FILTER.\n"
            " • Click a dot to flag/unflag a frame.\n"
            " • Shift-click a dot to preview the image.\n"
            " • Drag the red lines to set thresholds."
        ),
            self
        )
        instr.setWordWrap(True)
        instr.setStyleSheet("color: #ccc; font-size: 12px;")
        vbox.addWidget(instr)
        self.chk_guides = QCheckBox(self.tr("Show median and ±3σ guides"), self)
        self.chk_guides.setChecked(True)  # default on
        self.chk_guides.toggled.connect(self._on_toggle_guides)
        vbox.addWidget(self.chk_guides)
        # → filter selector
        self.group_combo = QComboBox(self)

        # display text is translated, internal data is stable
        self.group_combo.addItem(self.tr("All"), "__ALL__")
        self.group_combo.currentIndexChanged.connect(self._on_group_change_index)
        vbox.addWidget(self.group_combo)

        # → the 2×2 metrics panel
        self.metrics_panel = MetricsPanel(self)
        vbox.addWidget(self.metrics_panel)

        # keep status up‐to‐date when things happen
        self.metrics_panel.thresholdChanged.connect(self._update_status)
        self.metrics_panel.pointClicked   .connect(self._update_status)

        # ← status label
        self.status_label = QLabel("", self)
        vbox.addWidget(self.status_label)

        # internal storage
        self._all_images = []
        self._current_indices: Optional[List[int]] = None

    def _on_toggle_guides(self, on: bool):
        if hasattr(self, "metrics_panel") and self.metrics_panel is not None:
            self.metrics_panel.set_guides_visible(on)

    def _current_group_id(self) -> str:
        gid = self.group_combo.currentData()
        return gid if isinstance(gid, str) else "__ALL__"

    def _on_group_change_index(self, _idx: int):
        gid = self._current_group_id()

        if gid == "__ALL__":
            self._current_indices = self._order_all
        else:
            filt = gid
            self._current_indices = [
                i for i in self._order_all
                if (self._all_images[i].get('header', {}) or {}).get('FILTER', 'Unknown') == filt
            ]

        # Reset so plot() will auto-init lines for this group's data range
        self.metrics_panel._threshold_initialized = [False] * 7

        # Restore saved thresholds for this group (overrides auto-init if saved)
        self._apply_thresholds(gid)
        self.metrics_panel.plot(self._all_images, indices=self._current_indices)

    def _update_status(self, *args):
        """Recompute and show: Flagged Items X / Y (Z%).  Robust to stale indices."""
        flags = getattr(self.metrics_panel, "flags", []) or []
        nflags = len(flags)

        # what subset are we currently looking at?
        idxs = self._current_indices if self._current_indices is not None else range(nflags)

        total = 0
        flagged_cnt = 0

        for i in idxs:
            # i can be np.int64 or a stale index from before a move/delete
            j = int(i)
            if 0 <= j < nflags:
                total += 1
                if flags[j]:
                    flagged_cnt += 1
            else:
                # stale index → just skip it
                continue

        pct = (flagged_cnt / total * 100.0) if total else 0.0
        self.status_label.setText(self.tr("Flagged Items {0}/{1}  ({2:.1f}%)").format(flagged_cnt, total, pct))


    def set_images(self, loaded_images, order=None):
        self._all_images = loaded_images
        self._order_all = list(order) if order is not None else list(range(len(loaded_images)))

        # ─── rebuild the combo-list of FILTER groups ─────────────
        self.group_combo.blockSignals(True)
        self.group_combo.clear()
        self.group_combo.addItem(self.tr("All"), "__ALL__")

        seen = set()
        for entry in loaded_images:
            filt = (entry.get('header', {}) or {}).get('FILTER', 'Unknown')
            if filt not in seen:
                seen.add(filt)
                self.group_combo.addItem(filt, filt)  # display=filt, id=filt (stable)
        self.group_combo.blockSignals(False)

        # ─── reset & seed per-group thresholds ────────────────────
        self._thresholds_per_group.clear()
        self._thresholds_per_group["__ALL__"] = [None]*7
        for entry in loaded_images:
            filt = (entry.get('header', {}) or {}).get('FILTER', 'Unknown')
            self._thresholds_per_group.setdefault(filt, [None]*7)


        # ─── compute & cache all metrics once ────────────────────
        self.metrics_panel.compute_all_metrics(self._all_images)

        # ─── show “All” by default and plot ───────────────────────
        self._current_indices = self._order_all
        self._apply_thresholds("__ALL__")
        self.metrics_panel.plot(self._all_images, indices=self._current_indices)
        self.metrics_panel.set_guides_visible(self.chk_guides.isChecked())
        self._update_status()

    def _reindex_list_after_remove(self, lst: List[int] | None, removed: List[int]) -> List[int] | None:
        """Return lst with removed indices dropped and others shifted."""
        if lst is None:
            return None
        from bisect import bisect_right
        removed = sorted(set(int(i) for i in removed))
        rset = set(removed)
        def new_idx(old):
            return old - bisect_right(removed, old)
        return [new_idx(i) for i in lst if i not in rset]

    def _rebuild_groups_from_images(self):
        """Rebuild the FILTER combobox from current _all_images, keep current if possible."""
        cur = self.group_combo.currentText()
        self.group_combo.blockSignals(True)
        self.group_combo.clear()
        self.group_combo.addItem(self.tr("All"))
        seen = set()
        for entry in self._all_images:
            filt = (entry.get('header', {}) or {}).get('FILTER', 'Unknown')
            if filt not in seen:
                self.group_combo.addItem(filt)
                seen.add(filt)
        self.group_combo.blockSignals(False)
        # restore selection if still valid
        idx = self.group_combo.findText(cur)
        if idx >= 0:
            self.group_combo.setCurrentIndex(idx)
        else:
            self.group_combo.setCurrentIndex(0)

    def remove_indices(self, removed: List[int]):
        """
        Called when some frames were deleted/moved out of the list.
        Does NOT recompute metrics. Just trims cached arrays and re-plots.

        Robust against:
        - removed indices referring to the old list (out of range)
        - metrics_panel arrays being a different length than _all_images
        - stale _order_all / _current_indices containing out-of-bounds indices
        """
        if not removed:
            return

        # Unique + int
        removed = sorted({int(i) for i in removed})

        # ---- 1) Trim metrics panel caches SAFELY ----
        # Prefer panel's current frame count, because it represents the arrays we must slice.
        n_panel = getattr(self.metrics_panel, "n_frames", None)
        if callable(n_panel):
            n_panel = n_panel()
        if not isinstance(n_panel, int) or n_panel <= 0:
            # fallback: infer from metrics_data if present
            md = getattr(self.metrics_panel, "metrics_data", None)
            if md is not None and len(md) and md[0] is not None:
                try:
                    n_panel = int(len(md[0]))
                except Exception:
                    n_panel = 0
            else:
                n_panel = 0

        if n_panel > 0:
            removed_panel = [i for i in removed if 0 <= i < n_panel]
            if removed_panel:
                self.metrics_panel.remove_frames(removed_panel)
        # else: panel has nothing (or isn't initialized) — just continue with ordering cleanup

        # ---- 2) Update ordering arrays with the SAME removed set (but clamp later) ----
        self._order_all = self._reindex_list_after_remove(self._order_all, removed)
        if self._current_indices is not None:
            self._current_indices = self._reindex_list_after_remove(self._current_indices, removed)

        # ---- 3) Rebuild groups (filters may have disappeared) ----
        self._rebuild_groups_from_images()

        # ---- 4) Plot with VALID indices only ----
        n_imgs = len(self._all_images) if self._all_images is not None else 0

        def _sanitize_indices(ixs):
            if not ixs:
                return []
            out = []
            seen = set()
            for i in ixs:
                try:
                    ii = int(i)
                except Exception:
                    continue
                if 0 <= ii < n_imgs and ii not in seen:
                    seen.add(ii)
                    out.append(ii)
            return out

        indices = self._current_indices if self._current_indices is not None else self._order_all
        indices = _sanitize_indices(indices)

        # If the current group became empty, fall back to "all"
        if not indices and n_imgs:
            indices = list(range(n_imgs))
            self._current_indices = indices  # optional: keeps UI consistent

        self.metrics_panel.plot(self._all_images, indices=indices)

        # ---- 5) Recolor & status ----
        self.metrics_panel.refresh_colors_and_status()
        self._update_status()


    def _on_panel_threshold_change(self, metric_idx: int, new_val: float):
        grp = self._current_group_id()
        thr_list = self._thresholds_per_group.setdefault(grp, [None] * 7)
        while len(thr_list) < 7:
            thr_list.append(None)
        thr_list[metric_idx] = new_val

    def _apply_thresholds(self, group_id: str):
        saved = self._thresholds_per_group.get(group_id, [None] * 7)
        for idx, line in enumerate(self.metrics_panel.lines):
            if idx < len(saved) and saved[idx] is not None:
                line.setPos(saved[idx])
                self.metrics_panel._threshold_initialized[idx] = True  # mark as set, skip auto-init


    def update_metrics(self, loaded_images, order=None):
        """
        Refresh the metrics UI.

        - If this is a genuinely new image set, recompute from scratch.
        - If the same logical set is still in use and only ordering changed,
        just replot using cached metrics.
        """
        if self.metrics_panel.metrics_data is None or len(getattr(self, "_all_images", [])) != len(loaded_images):
            self.set_images(loaded_images, order=order)
            return

        self._all_images = loaded_images
        if order is not None:
            self._order_all = list(order)

        # Rebuild the current subset from the currently selected group id
        gid = self._current_group_id()
        if gid == "__ALL__":
            self._current_indices = self._order_all
        else:
            self._current_indices = [
                i for i in self._order_all
                if (self._all_images[i].get('header', {}) or {}).get('FILTER', 'Unknown') == gid
            ]

        self._apply_thresholds(gid)
        self.metrics_panel.plot(self._all_images, indices=self._current_indices)
        self.metrics_panel.set_guides_visible(self.chk_guides.isChecked())
        self._update_status()

class BlinkComparatorPro(QDialog):
    sendToStacking = pyqtSignal(list, str)

    def __init__(self, doc_manager=None, parent=None):
        super().__init__(parent)
        self.doc_manager = doc_manager
        self.setWindowTitle(self.tr("Blink Comparator"))
        self.resize(1200, 700)

        self.tab = BlinkTab(doc_manager=self.doc_manager, parent=self)
        layout = QVBoxLayout(self)
        layout.addWidget(self.tab)
        self.setLayout(layout)

        self.tab.sendToStacking.connect(self.sendToStacking)

        self._geom_restored = False  # <- NEW

    # --- NEW ---
    def _restore_window_geometry(self):
        try:
            s = QSettings()
            # Dedicated key so this (unused in current wiring, but kept
            # for legacy callers) doesn't collide with BlinkTab's
            # top-level geometry save.
            g = s.value("blink/dialog_window_geometry", None)
            if g is not None:
                self.restoreGeometry(g)
        except Exception:
            pass

    def _save_window_geometry(self):
        try:
            s = QSettings()
            s.setValue("blink/dialog_window_geometry", self.saveGeometry())
        except Exception:
            pass

    def showEvent(self, ev):
        super().showEvent(ev)

        if not self._geom_restored:
            self._geom_restored = True

            def _after_restore():
                self._restore_window_geometry()
                # If you also persist splitter (below), it restores itself in BlinkTab

            QTimer.singleShot(0, _after_restore)

    def closeEvent(self, e):
        try:
            self._save_window_geometry()
        except Exception:
            pass

        try:
            if self.tab:
                self.tab._save_tree_header_state()
        except Exception:
            pass

        super().closeEvent(e)

class _ZoomRectOverlay(QWidget):
    """Transparent overlay that draws a rectangle showing the zoom panel's crop region."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._rect = None  # QRectF in widget coords

    def set_rect(self, rect):
        """rect is a QRectF in this widget's coordinate space."""
        self._rect = rect
        self.update()

    def paintEvent(self, e):
        if not self._rect:
            return
        from PyQt6.QtGui import QPainter, QPen
        p = QPainter(self)
        pen = QPen(QColor(255, 200, 0, 220))   # yellow-ish
        pen.setWidth(2)
        pen.setStyle(Qt.PenStyle.SolidLine)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRect(self._rect.toRect())
        p.end()

class _BlinkZoomPanel(QWidget):
    """
    A compact panel showing a zoomed crop of the current blink image.
    Updated by BlinkTab._update_zoom_panel(pixmap, norm_cx, norm_cy).
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumWidth(250)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        # Toolbar row
        ctrl = QHBoxLayout()
        lbl = QLabel("Zoom:")
        lbl.setStyleSheet("font-size: 11px;")
        ctrl.addWidget(lbl)

        self.factor_combo = QComboBox()
        self.factor_combo.addItems(["2×", "4×", "8×", "16×"])
        self.factor_combo.setCurrentIndex(1)   # default 4×
        self.factor_combo.setFixedWidth(56)
        self.factor_combo.currentIndexChanged.connect(self._on_factor_changed)
        ctrl.addWidget(self.factor_combo)
        ctrl.addStretch(1)

        self.lock_btn = QPushButton("🔒 Lock")
        self.lock_btn.setCheckable(True)
        self.lock_btn.setFixedWidth(64)
        self.lock_btn.setToolTip("Lock zoom position (stop following mouse)")
        self.lock_btn.setStyleSheet("font-size: 10px; padding: 2px 4px;")
        ctrl.addWidget(self.lock_btn)
        layout.addLayout(ctrl)

        # Zoom image label
        self.zoom_label = QLabel()
        self.zoom_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.zoom_label.setStyleSheet(
            "border: 1px solid #555; border-radius: 4px; background: #1a1a1a;"
        )
        self.zoom_label.setSizePolicy(
            QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred
        )
        self.zoom_label.setMinimumSize(100, 100)
        layout.addWidget(self.zoom_label, stretch=1) 

        # Coords label
        self.coords_label = QLabel("")
        self.coords_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.coords_label.setStyleSheet("font-size: 10px; color: #888;")
        layout.addWidget(self.coords_label)

        self._source_pixmap: QPixmap | None = None
        self._norm_cx = 0.5
        self._norm_cy = 0.5
        self._factors = [2, 4, 8, 16]
        self._factor = 4

    def _on_factor_changed(self, idx):
        self._factor = self._factors[idx]
        self._redraw()

    def set_source(self, pixmap: QPixmap | None,
                   norm_cx: float, norm_cy: float,
                   px_x: int | None = None, px_y: int | None = None):
        """Called by BlinkTab with the full-res pixmap and normalized center."""
        if self.lock_btn.isChecked():
            return
        self._source_pixmap = pixmap
        self._norm_cx = float(norm_cx)
        self._norm_cy = float(norm_cy)
        if px_x is not None and px_y is not None:
            self.coords_label.setText(f"({px_x}, {px_y})")
        self._redraw()

    def _redraw(self):
        pix = self._source_pixmap
        if pix is None or pix.isNull():
            self.zoom_label.clear()
            return

        pw = pix.width()
        ph = pix.height()
        if pw == 0 or ph == 0:
            return

        panel_w = max(1, self.zoom_label.width())
        panel_h = max(1, self.zoom_label.height())

        if panel_w < 32 or panel_h < 32:   # ← guard: not usably sized yet
            return

        crop_w = max(16, int(panel_w / self._factor))
        crop_h = max(16, int(panel_h / self._factor))

        cx = int(self._norm_cx * pw)
        cy = int(self._norm_cy * ph)

        x0 = max(0, min(cx - crop_w // 2, pw - crop_w))
        y0 = max(0, min(cy - crop_h // 2, ph - crop_h))

        actual_w = min(crop_w, pw - x0)
        actual_h = min(crop_h, ph - y0)
        if actual_w <= 0 or actual_h <= 0:
            return

        crop = pix.copy(x0, y0, actual_w, actual_h)
        if crop.isNull():
            return

        scaled = crop.scaled(
            panel_w, panel_h,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        if not scaled.isNull():
            self.zoom_label.setPixmap(scaled)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if hasattr(self, "_zoom_rect_overlay") and hasattr(self, "scroll_area"):
            self._zoom_rect_overlay.setGeometry(self.scroll_area.viewport().rect())
        if hasattr(self, "_update_zoom_panel_to_viewport_center"):
            QTimer.singleShot(0, self._update_zoom_panel_to_viewport_center)

# ---------------------------------------------------------------------------
# Numeric-aware tree item so clicking a metric header (Star Count, FWHM,
# Ecc, BG, Score, Temp, BG/s) sorts the tree numerically instead of
# lexicographically. This is a purely VISUAL reorder — self.image_paths
# and self.loaded_images stay in their canonical order; metrics are
# resolved via UserRole on column 0, not tree row index.
# ---------------------------------------------------------------------------
class _BlinkSortItem(QTreeWidgetItem):
    @staticmethod
    def _natkey(s):
        return [int(t) if t.isdigit() else t.lower()
                for t in re.split(r"(\d+)", s or "")]

    def _is_group(self):
        # Non-leaf rows are the Object:/Filter:/Exposure: headers.
        return self.childCount() > 0

    def __lt__(self, other):
        tree = self.treeWidget()
        col = tree.sortColumn() if tree is not None else 0

        # Group rows always sort by their column-0 label regardless of
        # which column the user clicked. Keeps Object/Filter/Exposure
        # headers in stable natural order while leaves sort by metric.
        if self._is_group() or getattr(other, "_is_group", lambda: False)():
            return self._natkey(self.text(0)) < self._natkey(other.text(0))

        a = (self.text(col) or "").strip().lstrip("⚠️ ").strip()
        b = (other.text(col) or "").strip().lstrip("⚠️ ").strip()

        # Empty metric cells always sort to the bottom in ascending so
        # un-measured frames don't push good ones off the top.
        if a == "" and b == "":
            return self._natkey(self.text(0)) < self._natkey(other.text(0))
        if a == "":
            return False
        if b == "":
            return True

        # Filename (0) and the Sat flag (1) sort naturally as text.
        if col in (0, 1):
            return self._natkey(a) < self._natkey(b)

        # Metric columns (2..8) parse as float; fall back to text
        # natural sort if parsing fails (defensive).
        try:
            return float(a) < float(b)
        except (TypeError, ValueError):
            return self._natkey(a) < self._natkey(b)


class BlinkTab(QWidget):
    imagesChanged = pyqtSignal(int)
    sendToStacking = pyqtSignal(list, str)
    def __init__(self, image_manager=None, doc_manager=None, parent=None):
        super().__init__(parent)

        self.image_paths = []  # Store the file paths of loaded images
        self.loaded_images = []  # Store the image objects (as numpy arrays)
        self.image_labels = []  # Store corresponding file names for the TreeWidget
        self.doc_manager = doc_manager        # ⬅️ new
        self.image_manager = image_manager            # ⬅️ ensure we don't use it
        self.metrics_window: Optional[MetricsWindow] = None
        self.zoom_level = 0.5  # Default zoom level
        self.dragging = False  # Track whether the mouse is dragging
        self.last_mouse_pos = None  # Store the last mouse position

        # Restore persisted UI settings BEFORE initUI() so widgets seed
        # from the right values.
        _s = QSettings()
        try:
            self.aggressive_stretch_enabled = bool(
                _s.value("blink/aggressive_stretch", False, type=bool)
            )
        except Exception:
            self.aggressive_stretch_enabled = False

        try:
            _fps = float(_s.value("blink/play_fps", 1.0, type=float))
        except Exception:
            _fps = 1.0
        self.play_fps = max(0.1, min(10.0, _fps))

        try:
            self._auto_fit = bool(_s.value("blink/auto_fit", False, type=bool))
        except Exception:
            self._auto_fit = False

        self.current_sigma = 3.7
        self.current_pixmap = None
        self._last_preview_name = None
        self._pending_preview_timer = QTimer(self)
        self._pending_preview_timer.setSingleShot(True)
        self._pending_preview_timer.setInterval(40)  # 40–80ms is plenty
        self._pending_preview_item = None
        self._pending_preview_timer.timeout.connect(self._do_preview_update)
        self._view_center_norm = None
        self._zoom_pinned_norm = None  # (norm_cx, norm_cy) set by right-click

        # --- Stream mode state -------------------------------------------
        # In Stream mode entries carry header/metrics but image_data is None;
        # pixels live in this cache, keyed by file path. None in PreLoad mode.
        self._stream_cache: Optional[FrameCache] = None
        self._stream_dir = 1            # +1 forward, -1 back; drives prefetch
        try:
            self._stream_mode = bool(
                _s.value("blink/stream", False, type=bool))
        except Exception:
            self._stream_mode = False

        self.initUI()
        self.init_shortcuts()

        # Sync the aggressive-stretch button to the restored flag so the
        # UI matches what we'll actually render.
        try:
            self.aggressive_button.blockSignals(True)
            self.aggressive_button.setChecked(self.aggressive_stretch_enabled)
            self.aggressive_button.blockSignals(False)
        except Exception:
            pass

        self._geom_restored = False  # <- NEW

    # ------------------------------------------------------------------
    # Stream mode: demand loading
    # ------------------------------------------------------------------
    def _ensure_stream_cache(self):
        """The FrameCache for Stream mode, created on first use."""
        if self._stream_cache is None:
            self._stream_cache = FrameCache(
                self._stream_load_payload,
                budget_bytes=_blink_stream_budget_bytes(),
            )
        return self._stream_cache

    def _stream_load_payload(self, path):
        """Decode one frame for the cache. Runs on a cache worker thread.

        Returns ``(stored, meta)``. Only ``stored`` is big; the meta is small
        and gets folded back into the entry permanently, so a frame that has
        been looked at once keeps its header, bit depth and background even
        after its pixels are evicted.
        """
        _p, hdr, bit_depth, is_mono, stored, back = self._load_one_image(
            path, _blink_storage_dtype(), self._load_scale)
        return stored, {
            "header": hdr or {},
            "bit_depth": bit_depth,
            "is_mono": is_mono,
            "orig_background": back,
            "load_scale": self._load_scale,
        }

    def _absorb_stream_meta(self, idx, meta):
        """Fold a freshly loaded frame's small metadata into its entry."""
        if not (0 <= idx < len(self.loaded_images)) or not meta:
            return
        entry = self.loaded_images[idx]
        for key in ("header", "bit_depth", "is_mono", "orig_background",
                    "load_scale"):
            if key in meta:
                entry[key] = meta[key]

    def _pixels_for(self, idx, *, prefetch=True):
        """Decoded pixels for a frame, in either mode. None if unavailable.

        PreLoad just hands back what is already held. Stream goes to the cache,
        blocking on a decode if this frame is not resident, and queues the next
        few in the current travel direction so playback does not stall.
        """
        if not (0 <= idx < len(self.loaded_images)):
            return None
        entry = self.loaded_images[idx]
        stored = entry.get("image_data")
        if stored is not None:
            return stored
        if not self._stream_mode:
            return None

        cache = self._ensure_stream_cache()
        path = entry.get("file_path")
        if not path:
            return None

        ahead = ()
        if prefetch:
            ahead = tuple(prefetch_window(self.image_paths, idx, self._stream_dir))
        try:
            payload = cache.get(path, prefetch=ahead)
        except Exception as e:
            print(f"[Blink] stream load failed for {path}: {e}")
            return None
        if payload is None:
            return None
        stored, meta = payload
        self._absorb_stream_meta(idx, meta)
        return stored

    def _metrics_pixels(self, idx):
        """Pixels for a metrics worker. Decodes on the calling thread.

        Deliberately NOT routed through the FrameCache: its pool is two
        threads wide, so every metrics worker would funnel through it, and a
        measurement sweep would evict the frames the user is actually looking
        at in favour of frames measured and dropped a moment later. A resident
        frame is still reused.
        """
        if not (0 <= idx < len(self.loaded_images)):
            return None
        entry = self.loaded_images[idx]
        stored = entry.get("image_data")
        if stored is not None:
            return stored
        path = entry.get("file_path")
        if not path:
            return None
        cache = self._stream_cache
        if cache is not None:
            payload = cache.peek(path)
            if payload is not None:
                self._absorb_stream_meta(idx, payload[1])
                return payload[0]
        stored, meta = self._stream_load_payload(path)
        self._absorb_stream_meta(idx, meta)
        return stored

    def _frame_shape_hint(self, idx):
        """(height, width) of the STORED frame, without decoding it.

        Used where code needs the display geometry but not the pixels -- the
        metrics worker heuristic and the satellite overlay mask. Falls back
        through: resident pixels, the probed header, then a mid-size guess.
        """
        if not (0 <= idx < len(self.loaded_images)):
            return (2048, 2048)
        entry = self.loaded_images[idx]
        stored = entry.get("image_data")
        if stored is not None:
            return tuple(int(v) for v in stored.shape[:2])
        wh = entry.get("probe_wh")
        scale = max(1, int(entry.get("load_scale", self._load_scale) or 1))
        if wh:
            w, h = wh
            return (max(1, int(h) // scale), max(1, int(w) // scale))
        hdr = entry.get("header") or {}
        try:
            w = int(hdr["NAXIS1"]); h = int(hdr["NAXIS2"])
            return (max(1, h // scale), max(1, w // scale))
        except Exception:
            pass
        return (2048, 2048)

    def _set_stream_mode(self, on: bool):
        """Switch PreLoad <-> Stream.

        Asymmetric on purpose, so neither direction surprises anyone:
        switching TO Stream drops resident pixels immediately (instant memory
        back, frames reload on demand), while switching to PreLoad applies on
        the next load rather than silently decoding hundreds of frames.
        """
        on = bool(on)
        if on == self._stream_mode:
            return
        self._stream_mode = on
        try:
            QSettings().setValue("blink/stream", on)
        except Exception:
            pass

        if on and self.loaded_images:
            for entry in self.loaded_images:
                entry["image_data"] = None
            self._ensure_stream_cache()
            self.loading_label.setText(self.tr(
                "Streaming: frames load when you select them."))
            cur = self.fileTree.currentItem()
            if cur is not None and cur.childCount() == 0:
                self._last_preview_name = None
                self.on_item_clicked(cur, 0)
        elif not on and self.loaded_images:
            self.loading_label.setText(self.tr(
                "PreLoad applies on the next load."))

    # ------------------------------------------------------------------
    # Memory guard: keep PreLoad from running the machine out of RAM
    # ------------------------------------------------------------------
    def _force_stream_mode(self, title: str, text: str, *, ask: bool = False) -> bool:
        """Switch to Stream because PreLoad will not fit. True if switched.

        ``ask`` is for the pre-flight check, where nothing has been decoded yet
        and the estimate can legitimately be wrong -- a machine with plenty of
        swap, or a container that misreports available memory. The in-flight
        guard never asks: by the time it fires the memory is already going.
        """
        if ask:
            btn = QMessageBox.question(
                self, title,
                text + "\n\n" + self.tr("Switch to Stream mode?"),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes,
            )
            if btn != QMessageBox.StandardButton.Yes:
                print("[Blink] memory guard declined by user; PreLoading anyway")
                return False
        else:
            QMessageBox.warning(self, title, text)

        self._set_stream_mode(True)
        # Sync the radios without re-entering _set_stream_mode through the
        # toggled connection.
        for rb, state in ((self.rb_stream, True), (self.rb_preload, False)):
            try:
                rb.blockSignals(True)
                rb.setChecked(state)
            except Exception:
                pass
            finally:
                try:
                    rb.blockSignals(False)
                except Exception:
                    pass
        return True

    def _preflight_stream_switch(self, file_paths, *, appending: bool) -> bool:
        """Estimate the PreLoad before decoding anything. True if we switched.

        Costs a dozen header probes. Returns False -- meaning carry on with
        PreLoad -- when the guard is off, memory is unknown, the formats cannot
        be probed, the estimate fits, or the user overrode the offer.
        """
        self._mem_per_frame_hint = None
        if self._stream_mode or not _blink_mem_guard_enabled():
            return False

        avail, _total = _blink_available_bytes()
        if not avail:
            return False

        per_frame, probed = _blink_estimate_frame_bytes(
            file_paths, self._load_scale)
        if not per_frame:
            return False        # unprobeable: the in-flight guard covers it
        self._mem_per_frame_hint = per_frame

        # Frames already resident still occupy the same RAM.
        held = 0
        if appending:
            for entry in self.loaded_images:
                arr = entry.get("image_data")
                held += int(getattr(arr, "nbytes", 0) or 0)

        n = len(file_paths)
        need = per_frame * n + held
        budget = int(avail * _blink_mem_headroom_frac())
        if need <= budget:
            return False

        print(f"[Blink] memory guard: {n} frames x "
              f"{_blink_fmt_bytes(per_frame)} (probed {probed}) = "
              f"{_blink_fmt_bytes(need)}, budget {_blink_fmt_bytes(budget)} "
              f"of {_blink_fmt_bytes(avail)} available")

        return self._force_stream_mode(
            self.tr("Not enough memory to PreLoad"),
            self.tr(
                "PreLoading these {n} frames at 1:{scale} needs about {need} "
                "of memory, and only {avail} is free right now. Loading them "
                "all would very likely have the system kill SASpro.\n\n"
                "Stream mode opens the folder immediately and decodes each "
                "frame as you select it, so memory stays flat no matter how "
                "many subs there are.\n\n"
                "To PreLoad instead: free some memory, or pick a smaller "
                "\"Load at:\" setting (1:2 quarters the cost, 1:4 sixteenths "
                "it)."
            ).format(n=n, scale=max(1, int(self._load_scale or 1)),
                     need=_blink_fmt_bytes(need),
                     avail=_blink_fmt_bytes(avail)),
            ask=True,
        )

    def _mem_worker_cap(self, per_frame_bytes):
        """Pool width that the decode working set can afford, or None.

        Each worker holds the full-resolution frame as float32 plus copies
        through the debayer and the stretch, which dwarfs the uint16 frame it
        finally stores. Sixty of those at once is its own OOM, reached before
        the in-flight projection has three frames to extrapolate from.

        Deliberately conservative: at 1:4 and 1:8 the strided reader usually
        never materializes a full-resolution frame at all, but it is allowed to
        decline per file and fall through to the full read, so the bound has to
        assume the expensive path.
        """
        if not _blink_mem_guard_enabled() or not per_frame_bytes:
            return None
        avail, _total = _blink_available_bytes()
        if not avail:
            return None

        scale = max(1, int(self._load_scale or 1))
        working = int(per_frame_bytes) * (scale * scale) * 2 * 3
        if working <= 0:
            return None
        return max(1, int((avail * 0.5) // working))

    def _mem_trip(self, bytes_so_far: int, done: int, total: int):
        """Reason to abandon this PreLoad, or None to carry on.

        Two conditions. The projection stops the load while the memory is still
        there, which is the whole point -- waiting for 'available' to actually
        run out means racing the OOM killer. The floor is the backstop for when
        the projection is wrong, including every format that could not be
        pre-flighted.
        """
        if not _blink_mem_guard_enabled():
            return None
        avail, total_ram = _blink_available_bytes()
        if not avail:
            return None

        floor = max(512 << 20, int((total_ram or 0) * 0.08))
        if avail <= floor:
            return "floor"

        if done >= 3 and total > done:
            per = bytes_so_far / float(done)
            remaining_need = per * (total - done)
            if remaining_need > int(avail * _blink_mem_headroom_frac()):
                return "projection"
        return None

    def _mem_abandon_preload(self, reason: str, done: int, total: int):
        """Tell the user why their PreLoad became a Stream."""
        avail, _total = _blink_available_bytes()
        print(f"[Blink] memory guard tripped ({reason}) after {done}/{total} "
              f"frames; {_blink_fmt_bytes(avail)} available")

        if reason == "floor":
            why = self.tr(
                "Memory ran low after {done} of {total} frames ({avail} left)."
            ).format(done=done, total=total, avail=_blink_fmt_bytes(avail))
        else:
            why = self.tr(
                "After {done} of {total} frames it was clear the rest would "
                "not fit in the {avail} still available."
            ).format(done=done, total=total, avail=_blink_fmt_bytes(avail))

        self._force_stream_mode(
            self.tr("Switched to Stream to avoid running out of memory"),
            why + "\n\n" + self.tr(
                "Blink released the frames it had decoded and switched to "
                "Stream, which decodes each frame as you select it. Nothing "
                "was lost -- every frame is still listed.\n\n"
                "For a PreLoad of this folder, use a smaller \"Load at:\" "
                "setting or free some memory first."
            ),
        )

    def _shutdown_stream_cache(self):
        if self._stream_cache is not None:
            try:
                self._stream_cache.shutdown()
            except Exception:
                pass
            self._stream_cache = None

    # --- NEW ---
    def _top_level_window(self):
        """Return the top-level window hosting this widget (dialog, MDI
        subwindow or main window). Falls back to self when embedded weirdly.
        Geometry save/restore must target this, not the embedded widget."""
        try:
            w = self.window()
            return w if w is not None else self
        except Exception:
            return self

    def _restore_window_geometry(self):
        try:
            s = QSettings()
            g = s.value("blink/tab_window_geometry", None)   # widget-specific
            if g is not None:
                self._top_level_window().restoreGeometry(g)
        except Exception:
            pass

    def _save_window_geometry(self):
        try:
            s = QSettings()
            s.setValue("blink/tab_window_geometry",
                       self._top_level_window().saveGeometry())
        except Exception:
            pass

    def _save_main_splitter_state(self, *_):
        try:
            if hasattr(self, "main_splitter") and self.main_splitter is not None:
                QSettings().setValue("blink/main_splitter_state",
                                     self.main_splitter.saveState())
        except Exception:
            pass

    def _restore_main_splitter_state(self):
        try:
            if not hasattr(self, "main_splitter") or self.main_splitter is None:
                return
            state = QSettings().value("blink/main_splitter_state", None)
            if state is not None:
                self.main_splitter.restoreState(state)
                sizes = self.main_splitter.sizes()
                # sanity fallback: don't let a bad save collapse a pane
                if len(sizes) >= 2 and (sizes[0] < 120 or sizes[1] < 200):
                    self.main_splitter.setSizes([300, 900])
        except Exception:
            pass

    def _last_folder(self) -> str:
        try:
            s = QSettings()
            return s.value("blink/last_folder", "", type=str) or ""
        except Exception:
            return ""

    def _save_last_folder(self, path: str):
        try:
            folder = os.path.dirname(path) if os.path.isfile(path) else path
            if folder and os.path.isdir(folder):
                QSettings().setValue("blink/last_folder", folder)
        except Exception:
            pass

    def showEvent(self, ev):
        super().showEvent(ev)

        if not self._geom_restored:
            self._geom_restored = True

            def _after_restore():
                self._restore_window_geometry()
                self._restore_main_splitter_state()

            QTimer.singleShot(0, _after_restore)

        # Restore zoom panel visibility
        try:
            s = QSettings()
            visible = s.value("blink/zoom_panel_visible", True, type=bool)
            self._zoom_panel.setVisible(visible)
            self.zoom_panel_btn.setText(
                self.tr("Hide Zoom Panel") if visible else self.tr("Show Zoom Panel")
            )
        except Exception:
            pass

    def hideEvent(self, ev):
        # Persist on hide too — some hosts (MDI subwindow, custom close
        # paths) swallow closeEvent, so leaning only on close loses state.
        try:
            self._save_window_geometry()
            self._save_main_splitter_state()
            self._save_tree_header_state()
        except Exception:
            pass
        super().hideEvent(ev)

    def closeEvent(self, e):
        self._save_window_geometry()
        self._save_main_splitter_state()
        self._save_tree_header_state()
        self._shutdown_stream_cache()

        try:
            if self.metrics_window is not None:
                self.metrics_window.close()
                self.metrics_window = None
        except Exception:
            pass

        super().closeEvent(e)

    def initUI(self):
        main_layout = QHBoxLayout(self)


        # Create a QSplitter to allow resizing between left and right panels
        splitter = QSplitter(Qt.Orientation.Horizontal, self)
        self.main_splitter = splitter  # keep a reference so we can persist its state

        # Left Column for the file loading and TreeView
        left_widget = QWidget(self)
        left_layout = QVBoxLayout(left_widget)

        # --------------------
        # Instruction Label
        # --------------------
        instruction_text = self.tr("Press 'F' to flag/unflag an image.\nRight-click on an image in the list for more options.")
        self.instruction_label = QLabel(instruction_text, self)
        self.instruction_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.instruction_label.setWordWrap(True)
        self.instruction_label.setStyleSheet("font-weight: bold;")  # Optional: Make the text bold for emphasis

        self.instruction_label.setStyleSheet(f"""
            QLabel {{
                font-weight: bold;
            }}
        """)

        # Add the instruction label to the left layout at the top
        left_layout.addWidget(self.instruction_label)

        # Horizontal layout for "Select Images" and "Select Directory" buttons
        button_layout = QHBoxLayout()

        # "Select Images" Button
        self.fileButton = QPushButton(self.tr('Select Images'), self)
        self.fileButton.clicked.connect(self.openFileDialog)
        button_layout.addWidget(self.fileButton)

        # "Select Directory" Button
        self.dirButton = QPushButton(self.tr('Select Directory'), self)
        self.dirButton.clicked.connect(self.openDirectoryDialog)
        button_layout.addWidget(self.dirButton)

        self.addButton = QPushButton(self.tr("Add Additional"), self)
        self.addButton.clicked.connect(self.addAdditionalImages)
        button_layout.addWidget(self.addButton)

        left_layout.addLayout(button_layout)

        # After creating all buttons, add resolution row
        res_layout = QHBoxLayout()
        res_lbl = QLabel(self.tr("Load at:"), self)
        res_lbl.setStyleSheet("font-size: 11px;")
        res_layout.addWidget(res_lbl)

        self._load_scale = 1  # default 1:1
        self._res_group = QButtonGroup(self)

        for label, scale in [("1:1", 1), ("1:2", 2), ("1:4", 4), ("1:8", 8)]:
            rb = QRadioButton(self.tr(label), self)
            rb.setChecked(scale == 1)
            rb.setProperty("scale", scale)
            self._res_group.addButton(rb)
            res_layout.addWidget(rb)

        saved_scale = int(QSettings().value("blink/load_scale", 1, type=int))
        self._load_scale = saved_scale
        for btn in self._res_group.buttons():
            if btn.property("scale") == saved_scale:
                btn.setChecked(True)
                break

        # NOW connect — lambda only fires on user clicks, not setChecked
        self._res_group.buttonClicked.connect(
            lambda btn: (
                setattr(self, "_load_scale", btn.property("scale")),
                QSettings().setValue("blink/load_scale", btn.property("scale")),
            )
        )
        res_layout.addStretch(1)
        left_layout.addLayout(res_layout)

        # PreLoad | Stream
        mode_row = QHBoxLayout()
        mode_lbl = QLabel(self.tr("Frames:"), self)
        mode_lbl.setStyleSheet("font-size: 11px;")
        mode_row.addWidget(mode_lbl)

        self._mode_group = QButtonGroup(self)
        self.rb_preload = QRadioButton(self.tr("PreLoad"), self)
        self.rb_stream = QRadioButton(self.tr("Stream"), self)
        self.rb_preload.setToolTip(self.tr(
            "PreLoad: decode every frame when the folder is opened and keep it\n"
            "in memory. Slowest to open, instant to blink. This is how Blink\n"
            "has always worked."))
        self.rb_stream.setToolTip(self.tr(
            "Stream: scan headers only on open, then decode a frame when you\n"
            "select it. The folder appears immediately and memory stays flat\n"
            "no matter how many subs there are; each frame costs one read the\n"
            "first time you look at it. Recently viewed frames stay cached and\n"
            "the next few in your direction of travel are fetched ahead, so\n"
            "playback stays smooth.\n"
            "\n"
            "Interactive Metrics streams too: it loads, measures and releases\n"
            "each frame in turn rather than needing them all resident.\n"
            "\n"
            "Switching to Stream frees memory immediately. Switching back to\n"
            "PreLoad takes effect on the next load."))
        self._mode_group.addButton(self.rb_preload)
        self._mode_group.addButton(self.rb_stream)
        self.rb_preload.setChecked(not self._stream_mode)
        self.rb_stream.setChecked(self._stream_mode)
        self.rb_stream.toggled.connect(self._set_stream_mode)
        mode_row.addWidget(self.rb_preload)
        mode_row.addWidget(self.rb_stream)
        mode_row.addStretch(1)
        left_layout.addLayout(mode_row)

        # CFA handling for the strided 1:4 / 1:8 reader.
        self.chk_cfa_color = QCheckBox(self.tr("Keep color on CFA frames"), self)
        self.chk_cfa_color.setToolTip(self.tr(
            "Checked (default): one-shot color frames stay in color at 1:4 and\n"
            "1:8. Blink reads a quad-aligned subsample straight off disk and\n"
            "debayers the small frame instead of the full one.\n"
            "\n"
            "Unchecked: CFA frames are averaged to a grey luminance preview and\n"
            "the debayer never runs. This is the slower of the two -- it reads\n"
            "twice as many rows to build the same size frame -- but it is the\n"
            "option that touches no numba code at all, so it is worth trying if\n"
            "you hit a threading problem during loads.\n"
            "\n"
            "Mono frames are unaffected either way. Takes effect on the next\n"
            "load, like the resolution buttons above."))
        try:
            self.chk_cfa_color.setChecked(
                bool(QSettings().value("blink/cfa_color", True, type=bool)))
        except Exception:
            self.chk_cfa_color.setChecked(True)
        self.chk_cfa_color.toggled.connect(
            lambda on: QSettings().setValue("blink/cfa_color", bool(on)))
        left_layout.addWidget(self.chk_cfa_color)

        self.metrics_button = QPushButton(self.tr("Interactive Metrics && Culling"), self)
        self.metrics_button.clicked.connect(self.show_metrics)
        left_layout.addWidget(self.metrics_button)
        sat_row = QHBoxLayout()
        self.sat_detect_btn = QPushButton(self.tr("Detect Satellite Trails"), self)
        self.sat_detect_btn.setToolTip(self.tr(
            "Runs the Cosmic Clarity satellite detection model on all loaded images.\n"
            "Images with detected trails are flagged in the Sat column.\n"
            "This is a quick pre-pass that may produce false positives, especially large diffraction spikes,\n"
            "but can help identify problematic frames before stacking."
        ))
        self.sat_detect_btn.clicked.connect(self._detect_satellite_trails)
        sat_row.addWidget(self.sat_detect_btn, stretch=1)

        sat_mode_lbl = QLabel(self.tr("Mode:"), self)
        sat_mode_lbl.setStyleSheet("font-size: 11px;")
        sat_row.addWidget(sat_mode_lbl)

        self.sat_mode_combo = QComboBox(self)
        self.sat_mode_combo.addItem(self.tr("Fast"), "fast")
        self.sat_mode_combo.addItem(self.tr("Highlight trails (slower)"), "full")
        self.sat_mode_combo.setToolTip(self.tr(
            "Fast: runs only the detection models — quickly marks images with trails in the Sat column.\n"
            "Highlight trails: runs the full satellite-removal pipeline and paints the trail bright green\n"
            "in the preview so you can see exactly where it is. Significantly slower, especially on frames\n"
            "that actually contain trails."
        ))
        try:
            saved_mode = QSettings().value("blink/sat_detect_mode", "fast", type=str) or "fast"
        except Exception:
            saved_mode = "fast"
        _mi = self.sat_mode_combo.findData(saved_mode)
        if _mi < 0:
            _mi = 0
        self.sat_mode_combo.setCurrentIndex(_mi)
        self.sat_mode_combo.currentIndexChanged.connect(self._on_sat_mode_changed)
        sat_row.addWidget(self.sat_mode_combo)

        # Small wrench button for advanced satellite-detection settings
        # (edge-exclusion pixels, max worker threads).
        self.sat_settings_btn = QToolButton(self)
        self.sat_settings_btn.setText("🔧")
        self.sat_settings_btn.setToolTip(self.tr(
            "Advanced satellite detection settings — amp-glow edge filter\n"
            "and concurrent worker count."
        ))
        self.sat_settings_btn.setAutoRaise(True)
        self.sat_settings_btn.clicked.connect(self._open_sat_settings_dialog)
        sat_row.addWidget(self.sat_settings_btn)

        left_layout.addLayout(sat_row)
        push_row = QHBoxLayout()
        self.send_lights_btn = QPushButton(self.tr("→ Stacking: Lights"), self)
        self.send_lights_btn.setToolTip(self.tr("Send selected (or all) blink files to the Stacking Suite → Light tab"))
        self.send_lights_btn.clicked.connect(self._send_to_stacking_lights)
        push_row.addWidget(self.send_lights_btn)

        self.send_integ_btn = QPushButton(self.tr("→ Stacking: Integration"), self)
        self.send_integ_btn.setToolTip(self.tr("Send selected (or all) blink files to the Stacking Suite → Image Integration tab"))
        self.send_integ_btn.clicked.connect(self._send_to_stacking_integration)
        push_row.addWidget(self.send_integ_btn)

        self.stacking_settings_btn = QPushButton(self.tr("⚙ Stacking Settings"), self)
        self.stacking_settings_btn.setToolTip(self.tr(
            "Edit stacking suite settings (saved immediately, "
            "but Stacking Suite must be restarted separately if "
            "directory or precision changed)"))
        self.stacking_settings_btn.clicked.connect(self._open_stacking_settings_from_blink)
        push_row.addWidget(self.stacking_settings_btn)

        left_layout.addLayout(push_row)

        # Playback controls (left arrow, play, pause, right arrow)
        playback_controls_layout = QHBoxLayout()

        # Left Arrow Button
        self.left_arrow_button = QPushButton(self)
        self.left_arrow_button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ArrowLeft))
        self.left_arrow_button.clicked.connect(self.previous_item)
        playback_controls_layout.addWidget(self.left_arrow_button)

        # Play Button
        self.play_button = QPushButton(self)
        self.play_button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay))
        self.play_button.clicked.connect(self.start_playback)
        playback_controls_layout.addWidget(self.play_button)

        # Pause Button
        self.pause_button = QPushButton(self)
        self.pause_button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPause))
        self.pause_button.clicked.connect(self.stop_playback)
        playback_controls_layout.addWidget(self.pause_button)

        # Right Arrow Button
        self.right_arrow_button = QPushButton(self)
        self.right_arrow_button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ArrowRight))
        self.right_arrow_button.clicked.connect(self.next_item)
        playback_controls_layout.addWidget(self.right_arrow_button)

        left_layout.addLayout(playback_controls_layout)

        # ----- Playback speed controls -----
        # ----- Playback speed controls (0.1–10.0 fps) -----
        speed_layout = QHBoxLayout()

        speed_label = QLabel(self.tr("Speed:"), self)
        speed_layout.addWidget(speed_label)

        # Slider maps 1..100 -> 0.1..10.0 fps
        self.speed_slider = QSlider(Qt.Orientation.Horizontal, self)
        self.speed_slider.setRange(1, 100)
        self.speed_slider.setValue(int(round(self.play_fps * 10)))  # play_fps is float
        self.speed_slider.setTickPosition(QSlider.TickPosition.NoTicks)
        self.speed_slider.setToolTip(self.tr("Playback speed (0.1–10.0 fps)"))
        speed_layout.addWidget(self.speed_slider, 1)

        # Custom float spin (your class)
        self.speed_spin = CustomDoubleSpinBox(
            minimum=0.1, maximum=10.0, initial=self.play_fps, step=0.1, parent=self
        )
        speed_layout.addWidget(self.speed_spin)

        # IMPORTANT: remove any old direct connects like:
        # self.speed_slider.valueChanged.connect(self.speed_spin.setValue)
        # self.speed_spin.valueChanged.connect(self.speed_slider.setValue)

        # Use lambdas to cast types correctly
        self.speed_slider.valueChanged.connect(lambda v: self.speed_spin.setValue(v / 10.0))          # int -> float
        self.speed_spin.valueChanged.connect(lambda f: self.speed_slider.setValue(int(round(f * 10))))  # float -> int

        self.speed_slider.valueChanged.connect(self._apply_playback_interval)
        self.speed_spin.valueChanged.connect(self._apply_playback_interval)

        left_layout.addLayout(speed_layout)

        self.export_button = QPushButton(self.tr("Export Video…"), self)
        self.export_button.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_DialogSaveButton))
        self.export_button.clicked.connect(self.export_blink_video)
        left_layout.addWidget(self.export_button)
        # ── Tree filter ──────────────────────────────────────────────
        filter_row = QHBoxLayout()
        filter_lbl = QLabel(self.tr("Show:"), self)
        filter_lbl.setStyleSheet("font-size: 11px;")
        filter_row.addWidget(filter_lbl)

        self.tree_filter_combo = QComboBox(self)
        self.tree_filter_combo.addItem(self.tr("All"),           "all")
        self.tree_filter_combo.addItem(self.tr("Sat Detected"),  "sat")
        self.tree_filter_combo.addItem(self.tr("Flagged Only"),  "flagged")
        self.tree_filter_combo.addItem(self.tr("Clean Only"),    "clean")
        self.tree_filter_combo.setFixedWidth(140)
        # Restore previous filter selection (silently, before wiring the
        # change handler so we don't trigger a redundant filter pass).
        try:
            saved_filter = QSettings().value("blink/tree_filter", "all", type=str)
            _fi = self.tree_filter_combo.findData(saved_filter)
            if _fi >= 0:
                self.tree_filter_combo.blockSignals(True)
                self.tree_filter_combo.setCurrentIndex(_fi)
                self.tree_filter_combo.blockSignals(False)
        except Exception:
            pass
        self.tree_filter_combo.currentIndexChanged.connect(self._apply_tree_filter)
        filter_row.addWidget(self.tree_filter_combo)
        filter_row.addStretch(1)
        left_layout.addLayout(filter_row)
        # Tree view for file names
        self.fileTree = QTreeWidget(self)
        self.fileTree.setColumnCount(9)
        self.fileTree.setColumnCount(9)
        self.fileTree.setHeaderLabels([
            self.tr("Image Files"),
            self.tr("Sat"),
            self.tr("Stars"),
            self.tr("FWHM"),
            self.tr("Ecc"),
            self.tr("BG"),
            self.tr("Score"),
            self.tr("Temp"),
            self.tr("BG/s"),
        ])

        for c in (1, 2, 3, 4, 5, 6, 7, 8):
            self.fileTree.headerItem().setTextAlignment(c, Qt.AlignmentFlag.AlignCenter)

        self.fileTree.setColumnWidth(0, 450)
        self.fileTree.setColumnWidth(1, 35)
        self.fileTree.setColumnWidth(2, 55)
        self.fileTree.setColumnWidth(3, 55)
        self.fileTree.setColumnWidth(4, 55)
        self.fileTree.setColumnWidth(5, 55)
        self.fileTree.setColumnWidth(6, 60)   # Score (Weighted Score)
        self.fileTree.setColumnWidth(7, 50)   # Temp (°C from header)
        self.fileTree.setColumnWidth(8, 65)   # BG/s (ADU/s, OFFSET-corrected)
        self.fileTree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)  # Allow multiple selections
        #self.fileTree.itemClicked.connect(self.on_item_clicked)
        self.fileTree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.fileTree.customContextMenuRequested.connect(self.on_right_click)
        self.fileTree.currentItemChanged.connect(self._on_current_item_changed_safe)
        self.fileTree.setStyleSheet("""
                QTreeWidget::item:selected {
                    background-color: #3a75c4;  /* Blue background for selected items */
                    color: #ffffff;  /* White text color */
                }
            """)
        hdr = self.fileTree.header()
        hdr.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        hdr.setStretchLastSection(False)

        # restore last saved widths/order
        self._restore_tree_header_state()

        # save whenever user resizes/moves columns
        hdr.sectionResized.connect(lambda *_: self._save_tree_header_state())
        hdr.sectionMoved.connect(lambda *_: self._save_tree_header_state())

        # --- Clickable column sorting ---------------------------------
        # Leaves are _BlinkSortItem; its __lt__ parses metric columns
        # as floats so clicking Stars/FWHM/BG/etc. sorts numerically.
        # Purely visual — master lists stay in canonical order.
        self.fileTree.setSortingEnabled(True)
        hdr.setSectionsClickable(True)
        hdr.setSortIndicatorShown(True)
        # Default to column 0 ascending (filename natural order). If the
        # user restored a saved state with a different indicator, that
        # wins — restoreState sets it before this line is reached.
        if hdr.sortIndicatorSection() < 0:
            hdr.setSortIndicator(0, Qt.SortOrder.AscendingOrder)
        hdr.sortIndicatorChanged.connect(self._on_tree_sort_changed)

        left_layout.addWidget(self.fileTree)

        # "Clear Flags" Button
        self.clearFlagsButton = QPushButton(self.tr('Clear Flags'), self)
        self.clearFlagsButton.clicked.connect(self.clearFlags)
        left_layout.addWidget(self.clearFlagsButton)

        # "Clear Images" Button
        clear_row = QHBoxLayout()
        self.removeSelectedButton = QPushButton(self.tr('Remove Selected'), self)
        self.removeSelectedButton.clicked.connect(self.remove_items_from_list)
        clear_row.addWidget(self.removeSelectedButton)

        self.clearButton = QPushButton(self.tr('Clear Images'), self)
        self.clearButton.clicked.connect(self.clearImages)
        clear_row.addWidget(self.clearButton)
        left_layout.addLayout(clear_row)

        # Add progress bar
        self.progress_bar = QProgressBar(self)
        self.progress_bar.setRange(0, 100)
        left_layout.addWidget(self.progress_bar)

        # Add loading message label
        self.loading_label = QLabel(self.tr("Loading images..."), self)
        left_layout.addWidget(self.loading_label)
        self.imagesChanged.emit(len(self.loaded_images)) 

        # Set the layout for the left widget
        left_widget.setLayout(left_layout)

        # Add the left widget to the splitter
        splitter.addWidget(left_widget)

        # Right Column for Image Preview
        # Right side: splitter between full preview and zoom panel
        right_splitter = QSplitter(Qt.Orientation.Horizontal, self)

        # --- Full preview pane (existing) ---
        preview_widget = QWidget(self)
        right_layout = QVBoxLayout(preview_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)

        zoom_controls_layout = QHBoxLayout()
        self.zoom_in_btn  = themed_toolbtn("zoom-in", self.tr("Zoom In"))
        self.zoom_out_btn = themed_toolbtn("zoom-out", self.tr("Zoom Out"))
        self.fit_btn      = themed_toolbtn("zoom-fit-best", self.tr("Fit to Preview"))
        self.zoom_in_btn.clicked.connect(self.zoom_in)
        self.zoom_out_btn.clicked.connect(self.zoom_out)
        self.fit_btn.clicked.connect(self.fit_to_preview)
        zoom_controls_layout.addWidget(self.zoom_in_btn)
        zoom_controls_layout.addWidget(self.zoom_out_btn)
        zoom_controls_layout.addWidget(self.fit_btn)
        zoom_controls_layout.addStretch(1)

        zoom_hint = QLabel(self.tr("  ⓘ Right-click image to pin zoom box"), self)
        zoom_hint.setStyleSheet("font-size: 10px; color: #888;")
        zoom_controls_layout.addWidget(zoom_hint)

        right_layout.addLayout(zoom_controls_layout)
        zoom_controls_layout.addStretch(1)

        self.aggressive_button = QPushButton(self.tr("Aggressive Stretch"), self)
        self.aggressive_button.setCheckable(True)
        self.aggressive_button.clicked.connect(self.toggle_aggressive)
        zoom_controls_layout.addWidget(self.aggressive_button)
        
        self.zoom_panel_btn = QPushButton(self.tr("Hide Zoom Panel"), self)
        self.zoom_panel_btn.setCheckable(True)
        self.zoom_panel_btn.setChecked(False)
        self.zoom_panel_btn.setFixedWidth(110)
        self.zoom_panel_btn.clicked.connect(self._toggle_zoom_panel)
        zoom_controls_layout.addWidget(self.zoom_panel_btn)
        self.btn_doc_help = make_help_button("blink", self)
        zoom_controls_layout.addWidget(self.btn_doc_help)
        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll_area.viewport().installEventFilter(self)
        self.preview_label = QLabel(self)
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scroll_area.setWidget(self.preview_label)
        right_layout.addWidget(self.scroll_area)
        # Zoom rect overlay sits on top of the scroll area viewport
        self._zoom_rect_overlay = _ZoomRectOverlay(self.scroll_area.viewport())
        self._zoom_rect_overlay.setGeometry(self.scroll_area.viewport().rect())
        self._zoom_rect_overlay.show()
        right_splitter.addWidget(preview_widget)

        # --- Zoom panel (new) ---
        self._zoom_panel = _BlinkZoomPanel(self)
        right_splitter.addWidget(self._zoom_panel)

        # Restore splitter state; default: zoom panel ~300px
        right_splitter.setSizes([700, 300])
        self._right_splitter = right_splitter

        try:
            s = QSettings()
            state = s.value("blink/zoom_splitter_state", None)
            if state is not None:
                right_splitter.restoreState(state)
                # Sanity check: if zoom panel collapsed too small, reset to default
                sizes = right_splitter.sizes()
                if len(sizes) >= 2 and sizes[1] < 200:
                    right_splitter.setSizes([700, 300])
        except Exception:
            pass

        right_splitter.splitterMoved.connect(self._save_zoom_splitter_state)

        splitter.addWidget(left_widget)
        splitter.addWidget(right_splitter)
        splitter.setSizes([300, 900])  # fallback default; _restore_main_splitter_state wins
        splitter.splitterMoved.connect(self._save_main_splitter_state)

        # Add the splitter to the main layout
        main_layout.addWidget(splitter)

        # Set the main layout for the widget
        self.setLayout(main_layout)

        # Initialize playback timer
        self.playback_timer = QTimer(self)
        self._apply_playback_interval()
        self.playback_timer.timeout.connect(self.next_item)

        self.fileTree.selectionModel().selectionChanged.connect(self.on_selection_changed)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self._zoom_panel.lock_btn.toggled.connect(self._on_zoom_lock_toggled)
        self.scroll_area.horizontalScrollBar().valueChanged.connect(
            lambda _: (self._capture_view_center_norm(), 
                       self._update_zoom_panel_to_viewport_center())
        )
        self.scroll_area.verticalScrollBar().valueChanged.connect(
            lambda _: (self._capture_view_center_norm(),
                       self._update_zoom_panel_to_viewport_center())
        )
        self.imagesChanged.connect(self._update_loaded_count_label)
        self._apply_button_palette()

    def _apply_button_palette(self):
        """
        Apply subtle color tints to button groups for visual hierarchy.
        Uses rgba backgrounds so they work on both dark and light themes.
        Text color is NOT set — inherits from theme so it always readable.
        """

        # ── Analysis / AI tools — teal accent ──────────────────────
        _teal = """
            QPushButton {
                background-color: rgba(0, 150, 136, 0.25);
                border: 1px solid rgba(0, 150, 136, 0.5);
                border-radius: 4px;
                padding: 3px 8px;
            }
            QPushButton:hover {
                background-color: rgba(0, 150, 136, 0.40);
                border: 1px solid rgba(0, 150, 136, 0.75);
            }
            QPushButton:pressed {
                background-color: rgba(0, 150, 136, 0.55);
            }
        """
        self.metrics_button.setStyleSheet(_teal)
        self.sat_detect_btn.setStyleSheet(_teal)

        # ── Stacking export — blue accent ───────────────────────────
        _blue = """
            QPushButton {
                background-color: rgba(30, 120, 200, 0.22);
                border: 1px solid rgba(30, 120, 200, 0.45);
                border-radius: 4px;
                padding: 3px 8px;
            }
            QPushButton:hover {
                background-color: rgba(30, 120, 200, 0.38);
                border: 1px solid rgba(30, 120, 200, 0.70);
            }
            QPushButton:pressed {
                background-color: rgba(30, 120, 200, 0.52);
            }
        """
        self.send_lights_btn.setStyleSheet(_blue)
        self.send_integ_btn.setStyleSheet(_blue)

        # ── Settings — neutral with a slight warm tint ──────────────
        _neutral = """
            QPushButton {
                background-color: rgba(150, 130, 80, 0.20);
                border: 1px solid rgba(150, 130, 80, 0.40);
                border-radius: 4px;
                padding: 3px 8px;
            }
            QPushButton:hover {
                background-color: rgba(150, 130, 80, 0.35);
                border: 1px solid rgba(150, 130, 80, 0.60);
            }
            QPushButton:pressed {
                background-color: rgba(150, 130, 80, 0.48);
            }
        """
        self.stacking_settings_btn.setStyleSheet(_neutral)

        # ── Destructive / management — red tint ─────────────────────
        _red = """
            QPushButton {
                background-color: rgba(200, 60, 60, 0.18);
                border: 1px solid rgba(200, 60, 60, 0.38);
                border-radius: 4px;
                padding: 3px 8px;
            }
            QPushButton:hover {
                background-color: rgba(200, 60, 60, 0.32);
                border: 1px solid rgba(200, 60, 60, 0.60);
            }
            QPushButton:pressed {
                background-color: rgba(200, 60, 60, 0.48);
            }
        """
        self.clearFlagsButton.setStyleSheet(_red)
        self.clearButton.setStyleSheet(_red)

        # Remove Selected is destructive but less permanent than Clear Images
        _red_mild = """
            QPushButton {
                background-color: rgba(200, 60, 60, 0.12);
                border: 1px solid rgba(200, 60, 60, 0.28);
                border-radius: 4px;
                padding: 3px 8px;
            }
            QPushButton:hover {
                background-color: rgba(200, 60, 60, 0.24);
                border: 1px solid rgba(200, 60, 60, 0.48);
            }
            QPushButton:pressed {
                background-color: rgba(200, 60, 60, 0.38);
            }
        """
        self.removeSelectedButton.setStyleSheet(_red_mild)

        # ── Export video — purple tint, it's a creative output ──────
        _purple = """
            QPushButton {
                background-color: rgba(120, 80, 180, 0.20);
                border: 1px solid rgba(120, 80, 180, 0.42);
                border-radius: 4px;
                padding: 3px 8px;
            }
            QPushButton:hover {
                background-color: rgba(120, 80, 180, 0.35);
                border: 1px solid rgba(120, 80, 180, 0.65);
            }
            QPushButton:pressed {
                background-color: rgba(120, 80, 180, 0.50);
            }
        """
        self.export_button.setStyleSheet(_purple)

        # ── Aggressive stretch toggle — amber when checked ───────────
        self.aggressive_button.setStyleSheet("""
            QPushButton {
                background-color: rgba(180, 120, 0, 0.18);
                border: 1px solid rgba(180, 120, 0, 0.38);
                border-radius: 4px;
                padding: 3px 8px;
            }
            QPushButton:hover {
                background-color: rgba(180, 120, 0, 0.32);
                border: 1px solid rgba(180, 120, 0, 0.58);
            }
            QPushButton:checked {
                background-color: rgba(218, 165, 0, 0.50);
                border: 1px solid rgba(218, 165, 0, 0.85);
                font-weight: 600;
            }
            QPushButton:checked:hover {
                background-color: rgba(218, 165, 0, 0.65);
            }
        """)

    def _apply_tree_filter(self):
        """Show/hide leaf items based on the filter combo without touching list order."""
        mode = self.tree_filter_combo.currentData()

        # Persist filter choice so it's remembered across sessions.
        try:
            QSettings().setValue("blink/tree_filter", mode)
        except Exception:
            pass

        # sat_detected is tri-state: True (trail), False (checked, clean),
        # None (never checked, or the check failed). Before any detection run
        # everything is None, so "Clean Only" has to accept None or it would
        # be empty. Once a run has happened, a None frame is one we could NOT
        # check — it must not be presented as clean.
        any_sat_run = any(
            e.get("sat_detected") is not None for e in self.loaded_images
        )

        for item in self.get_all_leaf_items():
            idx = self._leaf_index(item)
            if idx is None:
                show = True
            else:
                entry = self.loaded_images[idx]
                flagged    = bool(entry.get("flagged", False))
                sat        = entry.get("sat_detected", None)

                if mode == "all":
                    show = True
                elif mode == "sat":
                    show = (sat is True)
                elif mode == "flagged":
                    show = flagged
                elif mode == "clean":
                    if any_sat_run:
                        show = (not flagged) and (sat is False)
                    else:
                        show = (not flagged)
                else:
                    show = True

            item.setHidden(not show)

        # Hide parent group items that have no visible children
        self._update_group_item_visibility()

    def _update_group_item_visibility(self):
        """Hide Object/Filter/Exposure group headers that have no visible leaf children."""
        def _any_visible(parent):
            for i in range(parent.childCount()):
                child = parent.child(i)
                if child.childCount() == 0:
                    if not child.isHidden():
                        return True
                else:
                    if _any_visible(child):
                        return True
            return False

        root = self.fileTree.invisibleRootItem()
        for i in range(root.childCount()):
            obj_item = root.child(i)
            obj_visible = _any_visible(obj_item)
            obj_item.setHidden(not obj_visible)
            for j in range(obj_item.childCount()):
                filt_item = obj_item.child(j)
                filt_visible = _any_visible(filt_item)
                filt_item.setHidden(not filt_visible)
                for k in range(filt_item.childCount()):
                    exp_item = filt_item.child(k)
                    exp_item.setHidden(not _any_visible(exp_item))

    def _open_stacking_settings_from_blink(self):
        """
        Open the Stacking Suite settings dialog directly.
        No live Stacking Suite instance needed — settings are read/written
        via QSettings so they persist regardless.
        """
        try:
            from setiastro.saspro.stacking_suite import StackingSuiteDialog
            mw = self._main_window()
            # Instantiate a minimal instance just to host the settings dialog
            stacking = StackingSuiteDialog.__new__(StackingSuiteDialog)
            stacking.__init__(parent=mw)
            stacking.open_stacking_settings(origin="blink")
        except Exception as e:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(self, self.tr("Stacking Settings"),
                self.tr("Could not open Stacking Settings:\n{0}").format(str(e)))

    def _toggle_zoom_panel(self):
        visible = not self._zoom_panel.isVisible()
        self._zoom_panel.setVisible(visible)
        self.zoom_panel_btn.setText(
            self.tr("Hide Zoom Panel") if visible else self.tr("Show Zoom Panel")
        )
        if not visible and hasattr(self, "_zoom_rect_overlay"):
            self._zoom_rect_overlay.set_rect(None)
        elif visible:
            # Force repaint of zoom panel and overlay rect on show
            QTimer.singleShot(0, self._update_zoom_panel_to_viewport_center)
        try:
            s = QSettings()
            s.setValue("blink/zoom_panel_visible", visible)
        except Exception:
            pass

    def resizeEvent(self, e):
            super().resizeEvent(e)
            if hasattr(self, "_zoom_rect_overlay") and hasattr(self, "scroll_area"):
                self._zoom_rect_overlay.setGeometry(self.scroll_area.viewport().rect())

    def _save_zoom_splitter_state(self, *_):
        try:
            s = QSettings()
            s.setValue("blink/zoom_splitter_state", self._right_splitter.saveState())
        except Exception:
            pass
        if hasattr(self, "_zoom_rect_overlay") and hasattr(self, "scroll_area"):
            self._zoom_rect_overlay.setGeometry(self.scroll_area.viewport().rect())
        QTimer.singleShot(0, self._update_zoom_panel_to_viewport_center)

    def _on_zoom_lock_toggled(self, checked: bool):
        if not checked:
            # Unlocking — clear pin, resume viewport-center tracking
            self._zoom_pinned_norm = None
            self._update_zoom_panel_to_viewport_center()

    @staticmethod
    def _ensure_float01(img):
        """
        Convert to float32 and force into [0..1] using:
        - if min < 0: subtract min
        - if max > 1: divide by max
        Works for mono or RGB. Handles NaN/Inf safely.
        """
        arr = np.asarray(img, dtype=np.float32)

        finite = np.isfinite(arr)
        if not finite.any():
            return np.zeros_like(arr, dtype=np.float32)

        mn = float(arr[finite].min())
        if mn < 0.0:
            arr = arr - mn

        # recompute after possible shift
        finite = np.isfinite(arr)
        mx = float(arr[finite].max()) if finite.any() else 0.0
        if mx > 1.0:
            if mx > 0.0:
                arr = arr / mx

        return np.clip(arr, 0.0, 1.0)

    def _restore_tree_header_state(self):
        try:
            s = QSettings()
            hdr = self.fileTree.header()
            state = s.value("blink/tree_header_state_v2", None)
            if state is not None:
                hdr.restoreState(state)
        except Exception:
            pass

    def _save_tree_header_state(self):
        try:
            s = QSettings()
            hdr = self.fileTree.header()
            s.setValue("blink/tree_header_state_v2", hdr.saveState())
        except Exception:
            pass

    def _on_tree_sort_changed(self, *_):
        """User clicked a column header. The tree reorders itself via
        _BlinkSortItem.__lt__; we just need to keep the Metrics window's
        dot order aligned with the new visual order.

        Deferred to the next event-loop tick: sortIndicatorChanged can
        fire *before* Qt's internal sort slot runs, depending on slot
        connection order, so reading _tree_order_indices() synchronously
        would hand the metrics panel the pre-click order. singleShot(0)
        waits until the sort has definitely completed."""
        try:
            self._save_tree_header_state()
        except Exception:
            pass
        QTimer.singleShot(0, self._push_tree_order_to_metrics)

    def _push_tree_order_to_metrics(self):
        if self.metrics_window and self.metrics_window.isVisible():
            try:
                self.metrics_window.update_metrics(
                    self.loaded_images, order=self._tree_order_indices()
                )
            except Exception:
                pass

    class _TreeBulkUpdate:
        """Context manager: pauses sorting during bulk tree mutations so
        every setText/addChild doesn't trigger a resort. Nestable."""
        def __init__(self, tree):
            self._tree = tree
            self._was = False
        def __enter__(self):
            self._was = self._tree.isSortingEnabled()
            self._tree.setSortingEnabled(False)
            return self
        def __exit__(self, exc_type, exc, tb):
            self._tree.setSortingEnabled(self._was)
            return False

    def _tree_bulk_update(self):
        return BlinkTab._TreeBulkUpdate(self.fileTree)

    def _aggressive_display_boost(self, x01: np.ndarray, strength: float = 3.7) -> np.ndarray:
        """
        Stronger display stretch on top of an already stretched image.
        Input/Output are float32 in [0..1].
        Fast path: min/max normalize + arcsinh on a downsampled working copy,
        then apply the scalar parameters to the full array without per-pixel arcsinh.
        """
        x = np.asarray(x01, dtype=np.float32)

        mn = float(x.min())
        mx = float(x.max())
        if mx <= mn + 1e-8:
            return x

        # Normalize to [0,1]
        y = (x - mn) * (1.0 / (mx - mn))

        # Asinh boost — avoid per-pixel arcsinh by using the closed-form
        # scalar precompute: arcsinh(k*y)/arcsinh(k)
        # Since arcsinh(k) is a scalar we only compute it once.
        # For the per-pixel part, replace arcsinh(k*y) with log(k*y + sqrt((k*y)^2 + 1))
        # which numpy computes as a single fused op via np.arcsinh — BUT we avoid
        # the overhead by working in-place and skipping nan_to_num/clip on clean data.
        k = max(1.0, float(strength) * 1.25)
        ak = float(np.arcsinh(k))  # scalar, computed once

        np.multiply(y, k, out=y)         # y = k*y  in-place
        np.arcsinh(y, out=y)             # y = arcsinh(k*y)  in-place
        y *= (1.0 / ak)                  # y /= arcsinh(k)  in-place

        np.clip(y, 0.0, 1.0, out=y)
        return y

    # --------------------------------------------
    # NEW: collect paths & emit to stacking
    # --------------------------------------------
    def _collect_paths_for_stacking(self) -> list[str]:
        """
        Priority:
        1) if user has rows selected in the tree → use those
        2) else → use all loaded image_paths
        """
        paths: list[str] = []

        selected_items = self.fileTree.selectedItems()
        if selected_items:
            for it in selected_items:
                p = it.data(0, Qt.ItemDataRole.UserRole)
                if not p:
                    # some code uses text as path, fall back
                    p = it.text(0)
                if p:
                    paths.append(p)
        else:
            # no selection → send all
            for p in self.image_paths:
                if p:
                    paths.append(p)

        # de-dup, keep order
        seen = set()
        unique_paths = []
        for p in paths:
            if p not in seen:
                seen.add(p)
                unique_paths.append(p)
        return unique_paths

    def _send_to_stacking_lights(self):
        paths = self._collect_paths_for_stacking()
        if not paths:
            QMessageBox.information(self, self.tr("No images"), self.tr("There are no images to send."))
            return
        self.sendToStacking.emit(paths, "lights")

    def _send_to_stacking_integration(self):
        paths = self._collect_paths_for_stacking()
        if not paths:
            QMessageBox.information(self, self.tr("No images"), self.tr("There are no images to send."))
            return
        self.sendToStacking.emit(paths, "integration")


    def export_blink_video(self):
        """Export the blink sequence to a video. Defaults to all frames in current tree order."""
        # Ensure we have frames
        leaves = self.get_all_leaf_items()
        if not leaves:
            QMessageBox.information(self, self.tr("No Images"), self.tr("Load images before exporting."))
            return

        # Ask options first (size, fps, selection scope)
        opts = self._ask_video_options(default_fps=float(self.play_fps))
        if opts is None:
            return
        target_w, target_h = opts["size"]
        fps = max(0.1, min(60.0, float(opts["fps"])))
        only_selected = bool(opts.get("only_selected", False))

        # Decide frame order
        if only_selected:
            sel_leaves = [it for it in self.fileTree.selectedItems() if it.childCount() == 0]
            if not sel_leaves:
                QMessageBox.information(self, self.tr("No Selection"), self.tr("No individual frames selected."))
                return
            names = {it.text(0).lstrip("⚠️ ").strip() for it in sel_leaves}
            order = [i for i in self._tree_order_indices()
                    if os.path.basename(self.image_paths[i]) in names]
        else:
            order = self._tree_order_indices()

        if not order:
            QMessageBox.information(self, self.tr("No Frames"), self.tr("Nothing to export."))
            return

        if len(order) < 2:
            ret = QMessageBox.question(
                self, self.tr("Only one frame"),
                self.tr("You're about to export a video with a single frame. Continue?"),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if ret != QMessageBox.StandardButton.Yes:
                return

        # Ask where to save
        out_path, _ = QFileDialog.getSaveFileName(
            self, self.tr("Export Blink Video"), "blink.mp4", self.tr("Video (*.mp4 *.avi)")
        )
        if not out_path:
            return
        # Let _open_video_writer_portable decide the real extension; we pass requested
        writer, out_path, backend = self._open_video_writer_portable(out_path, (target_w, target_h), fps)
        if writer is None:
            QMessageBox.critical(self, self.tr("Export"),
                self.tr("No compatible video codec found.\n\n"
                "Tip: install FFmpeg or `pip install imageio[ffmpeg]` for a portable fallback.")
            )
            return

        #sasprogress UI
        prog = QProgressDialog(self.tr("Rendering video…"), self.tr("Cancel"), 0, len(order), self)
        prog.setWindowTitle(self.tr("Export Blink Video"))
        prog.setAutoClose(True)
        prog.setMinimumDuration(300)

        using_imageio = (backend == "imageio-ffmpeg")
        frames_written = 0

        try:
            for i, idx in enumerate(order):
                if prog.wasCanceled():
                    break

                entry = self.loaded_images[idx]
                f = self._make_display_frame(
                    entry, stored=self._pixels_for(idx, prefetch=False))
                if f is None:
                    continue                      # unreadable frame: skip it

                # Ensure 3-channel RGB
                if f.ndim == 2:
                    f = cv2.cvtColor(f, cv2.COLOR_GRAY2RGB)

                # Letterbox into target (keep aspect)
                tw, th = (target_w, target_h)
                h, w = f.shape[:2]
                s = min(tw / float(w), th / float(h))
                nw, nh = max(1, int(round(w * s))), max(1, int(round(h * s)))
                resized = cv2.resize(f, (nw, nh), interpolation=cv2.INTER_AREA)
                rgb_canvas = np.zeros((th, tw, 3), dtype=np.uint8)
                x0, y0 = (tw - nw) // 2, (th - nh) // 2
                rgb_canvas[y0:y0+nh, x0:x0+nw] = resized

                if using_imageio:
                    writer.append_data(rgb_canvas)  # RGB
                else:
                    writer.write(cv2.cvtColor(rgb_canvas, cv2.COLOR_RGB2BGR))  # BGR
                frames_written += 1

                prog.setValue(i + 1)
                QApplication.processEvents()
        finally:
            try:
                writer.close() if using_imageio else writer.release()
            except Exception:
                pass

        if prog.wasCanceled():
            try:
                os.remove(out_path)
            except Exception:
                pass
            QMessageBox.information(self, self.tr("Export"), self.tr("Export canceled."))
            return

        if frames_written == 0:
            QMessageBox.critical(self, self.tr("Export"), self.tr("No frames were written (codec/back-end issue?)."))
            return

        QMessageBox.information(self, self.tr("Export"), self.tr("Saved: {0}\nFrames: {1} @ {2} fps").format(out_path, frames_written, fps))



    def _ask_video_options(self, default_fps: float):
        """Options dialog for size, fps, and whether to limit to current selection."""
        dlg = QDialog(self)
        dlg.setWindowTitle(self.tr("Video Options"))
        layout = QGridLayout(dlg)

        # Size
        layout.addWidget(QLabel(self.tr("Size:")), 0, 0)
        size_combo = QComboBox(dlg)
        size_combo.addItem("HD 1280×720", (1280, 720))
        size_combo.addItem("Full HD 1920×1080", (1920, 1080))
        size_combo.addItem("Square 1080×1080", (1080, 1080))
        size_combo.setCurrentIndex(0)
        layout.addWidget(size_combo, 0, 1)

        # FPS
        layout.addWidget(QLabel(self.tr("FPS:")), 1, 0)
        fps_edit = QDoubleSpinBox(dlg)
        fps_edit.setRange(0.1, 60.0)
        fps_edit.setDecimals(2)
        fps_edit.setSingleStep(0.1)
        fps_edit.setValue(float(default_fps))
        layout.addWidget(fps_edit, 1, 1)

        # Only selected?
        only_selected = QCheckBox(self.tr("Export only selected frames"), dlg)
        only_selected.setChecked(False)  # default: export everything in tree order
        layout.addWidget(only_selected, 2, 0, 1, 2)

        # Buttons
        btns = QHBoxLayout()
        ok = QPushButton(self.tr("OK"), dlg); cancel = QPushButton(self.tr("Cancel"), dlg)
        ok.clicked.connect(dlg.accept); cancel.clicked.connect(dlg.reject)
        btns.addWidget(ok); btns.addWidget(cancel)
        layout.addLayout(btns, 3, 0, 1, 2)

        if dlg.exec() != QDialog.DialogCode.Accepted:
            return None
        return {
            "size": size_combo.currentData(),
            "fps": fps_edit.value(),
            "only_selected": only_selected.isChecked()
        }



    def _make_display_frame(self, entry, stored=None):
        # `stored` lets a caller pass pixels that are not held on the entry,
        # which is the normal case in Stream mode.
        if stored is None:
            stored = entry.get('image_data')
        if stored is None:
            return None
        use_aggr = bool(self.aggressive_stretch_enabled)

        if not use_aggr:
            if stored.dtype == np.uint8:
                frame = stored
            elif stored.dtype == np.uint16:
                frame = (stored >> 8).astype(np.uint8)
            else:
                # ✅ display-only normalization for float / weird ranges
                f01 = self._ensure_float01(stored)
                frame = (f01 * 255.0).astype(np.uint8)
            return self._paint_sat_overlay(frame, entry)

        base01 = self._as_float01(stored)

        if base01.ndim == 2:
            disp01 = self._aggressive_display_boost(base01, strength=self.current_sigma)
        else:
            lum = base01.mean(axis=2).astype(np.float32)
            lum_boost = self._aggressive_display_boost(lum, strength=self.current_sigma)
            gain = lum_boost / (lum + 1e-6)
            disp01 = np.clip(base01 * gain[..., None], 0.0, 1.0)

        frame = (disp01 * 255.0).astype(np.uint8)
        return self._paint_sat_overlay(frame, entry)

    def _paint_sat_overlay(self, frame_u8: np.ndarray, entry: dict) -> np.ndarray:
        """
        If the entry has a satellite-trail overlay mask (2D bool, same HxW as
        stored image_data), paint those pixels bright green (0,255,0) on the
        display frame. Mono frames are promoted to RGB so the overlay reads
        as actual green rather than a luminance change.
        """
        mask = entry.get("sat_overlay_mask", None)
        if mask is None:
            return frame_u8

        try:
            m = np.asarray(mask, dtype=bool)
        except Exception:
            return frame_u8

        if m.size == 0 or not m.any():
            return frame_u8

        # Shape sanity vs the display frame
        fh, fw = frame_u8.shape[:2]
        if m.shape[:2] != (fh, fw):
            # Mismatch — don't risk painting the wrong pixels
            return frame_u8

        #saspromote mono to RGB so we can draw green
        if frame_u8.ndim == 2:
            frame_rgb = np.stack([frame_u8, frame_u8, frame_u8], axis=-1)
        elif frame_u8.ndim == 3 and frame_u8.shape[2] == 1:
            frame_rgb = np.repeat(frame_u8, 3, axis=2)
        else:
            frame_rgb = frame_u8.copy()

        if frame_rgb.dtype != np.uint8:
            frame_rgb = frame_rgb.astype(np.uint8)

        # Bright green overlay
        frame_rgb[m, 0] = 0
        frame_rgb[m, 1] = 255
        frame_rgb[m, 2] = 0
        return frame_rgb



    def _fit_letterbox(self, frame_bgr_or_rgb, target_size):
        """
        Fit 'frame' into target_size with letterboxing (black borders).
        Accepts uint8, shape (H,W,3). Returns BGR uint8 (H_t,W_t,3).
        """
        tw, th = target_size
        h, w = frame_bgr_or_rgb.shape[:2]
        # Compute scale to fit inside
        s = min(tw / float(w), th / float(h))
        nw, nh = max(1, int(round(w * s))), max(1, int(round(h * s)))

        # Resize (OpenCV uses BGR—this function doesn’t swap channels)
        resized = cv2.resize(frame_bgr_or_rgb, (nw, nh), interpolation=cv2.INTER_AREA)

        # Pad into target
        out = np.zeros((th, tw, 3), dtype=np.uint8)
        x0 = (tw - nw) // 2
        y0 = (th - nh) // 2
        out[y0:y0+nh, x0:x0+nw] = resized if resized.ndim == 3 else cv2.cvtColor(resized, cv2.COLOR_GRAY2BGR)
        return out

    def _open_video_writer_portable(self, requested_path: str, size: tuple[int, int], fps: float):
        """
        Try several (container, fourcc) combos that work across platforms.
        Returns (writer, out_path, backend_name). If OpenCV fails, tries imageio-ffmpeg.
        Never writes a probe frame, so no accidental extra first frame.
        """
        tw, th = size
        candidates = [
            (".mp4", "mp4v", "OpenCV-mp4v"),
            (".mp4", "avc1", "OpenCV-avc1"),   # H.264 if available
            (".mp4", "H264", "OpenCV-H264"),
            (".avi", "MJPG", "OpenCV-MJPG"),
            (".avi", "XVID", "OpenCV-XVID"),
        ]
        base, _ = os.path.splitext(requested_path)

        # Try OpenCV containers/codecs first (without writing a test frame)
        for ext, fourcc_tag, label in candidates:
            out_path = base + ext
            fourcc = cv2.VideoWriter_fourcc(*fourcc_tag)

            # open/close once to check the container initialization
            vw = cv2.VideoWriter(out_path, fourcc, float(fps), (tw, th))
            ok = vw.isOpened()
            try:
                vw.release()
            except Exception:
                pass

            # some backends leave a tiny stub — clean it up before the real open
            try:
                if os.path.exists(out_path) and os.path.getsize(out_path) < 1024:
                    os.remove(out_path)
            except Exception:
                pass

            if ok:
                vw2 = cv2.VideoWriter(out_path, fourcc, float(fps), (tw, th))
                if vw2.isOpened():
                    return vw2, out_path, label

        # Fallback: imageio-ffmpeg (portable, needs imageio[ffmpeg])
        try:
            import imageio
            writer = imageio.get_writer(base + ".mp4", fps=float(fps), macro_block_size=None)  # expects RGB frames
            return writer, base + ".mp4", "imageio-ffmpeg"
        except Exception:
            return None, None, None




    def _update_loaded_count_label(self, n: int):
        # pluralize nicely
        self.loading_label.setText(self.tr("Loaded {0} image{1}.").format(n, 's' if n != 1 else ''))

    def _apply_playback_interval(self, *_):
        # read from custom spin if present (support both .value() and .value attribute)
        fps = float(getattr(self, "play_fps", 1.0))

        if hasattr(self, "speed_spin") and self.speed_spin is not None:
            try:
                v = getattr(self.speed_spin, "value", None)
                if callable(v):
                    fps = float(v())          # QDoubleSpinBox-style
                elif v is not None:
                    fps = float(v)            # CustomDoubleSpinBox stores numeric attribute
                else:
                    # last-resort: try Qt API name
                    fps = float(self.speed_spin.value())
            except Exception:
                # fall back to existing play_fps
                pass

        fps = max(0.1, min(10.0, fps))
        self.play_fps = fps

        if hasattr(self, "playback_timer") and self.playback_timer is not None:
            self.playback_timer.setInterval(int(round(1000.0 / fps)))  # 0.1 fps -> 10000 ms

        # Persist so the choice survives across sessions.
        try:
            QSettings().setValue("blink/play_fps", float(fps))
        except Exception:
            pass


    def _on_current_item_changed_safe(self, current, previous):
        if not current:
            return

        # If mouse is down, defer a bit, but DO NOT capture the item
        if QApplication.mouseButtons() != Qt.MouseButton.NoButton:
            QTimer.singleShot(120, self._center_if_no_mouse)
            return

        # Defer to allow selection to settle, then ensure the *current* item is visible
        QTimer.singleShot(0, self._ensure_current_visible)

    def _ensure_current_visible(self):
        item = self.fileTree.currentItem()
        if item is not None:
            self.fileTree.scrollToItem(item, QAbstractItemView.ScrollHint.EnsureVisible)

    def _center_if_no_mouse(self):
        if QApplication.mouseButtons() == Qt.MouseButton.NoButton:
            item = self.fileTree.currentItem()
            if item is not None:
                self.fileTree.scrollToItem(item, QAbstractItemView.ScrollHint.EnsureVisible)

    def _leaf_path(self, item: QTreeWidgetItem) -> str | None:
        """Return full path for a leaf item, preferring UserRole; fallback to basename match."""
        if not item or item.childCount() > 0:
            return None

        p = item.data(0, Qt.ItemDataRole.UserRole)
        if p and isinstance(p, str):
            return p

        # fallback: basename match (legacy items)
        name = item.text(0).lstrip("⚠️ ").strip()
        if not name:
            return None
        return next((x for x in self.image_paths if os.path.basename(x) == name), None)


    def _leaf_index(self, item: QTreeWidgetItem) -> int | None:
        """Return index into image_paths/loaded_images for a leaf item."""
        p = self._leaf_path(item)
        if not p:
            return None
        try:
            return self.image_paths.index(p)
        except ValueError:
            return None


    def _set_leaf_display(self, item: QTreeWidgetItem, *, base_name: str, flagged: bool, full_path: str):
        """Update a leaf item's text + UserRole consistently."""
        disp = base_name
        if flagged:
            disp = f"⚠️ {disp}"
        item.setText(0, disp)
        item.setData(0, Qt.ItemDataRole.UserRole, full_path)


    def clearFlags(self):
        """Clear all flagged states, update tree icons & metrics."""
        # 1) Reset internal flag state
        for entry in self.loaded_images:
            entry['flagged'] = False

        # 2) Update tree widget: strip any "⚠️ " prefix and reset color
        normal = self.fileTree.palette().color(QPalette.ColorRole.WindowText)
        for item in self.get_all_leaf_items():
            name = item.text(0).lstrip("⚠️ ")
            item.setText(0, name)
            item.setForeground(0, QBrush(normal))

        # 3) If metrics window is open, refresh its dots & status
        if self.metrics_window:
            panel = self.metrics_window.metrics_panel
            panel.flags = [False] * len(self.loaded_images)
            panel._refresh_scatter_colors()
            # update the "Flagged Items X/Y" label
            self.metrics_window._update_status()

    #    ----    metrics to leaves    ----
    def _update_tree_metrics_columns(self):
        if not self.metrics_window:
            return
        panel = getattr(self.metrics_window, "metrics_panel", None)
        if not panel or panel.metrics_data is None:
            return

        metrics = panel.metrics_data
        m0, m1, m2, m3 = metrics[0], metrics[1], metrics[2], metrics[3]
        m4 = metrics[4]  # Weighted Score
        m5 = metrics[5]  # Sensor Temp (°C from header)
        m6 = metrics[6]  # Bg Rate (ADU/s, OFFSET-corrected)
        n = min(len(self.loaded_images), len(m0), len(m1), len(m2), len(m3),
                len(m4), len(m5), len(m6))

        def fmt_f(x):
            return "" if (x is None or not np.isfinite(x)) else f"{float(x):.2f}"

        def fmt_i(x):
            try:
                xi = int(round(float(x)))
                return "" if xi < 0 else str(xi)
            except Exception:
                return ""

        with self._tree_bulk_update():
            for item in self.get_all_leaf_items():
                idx = self._leaf_index(item)
                if idx is None or idx < 0 or idx >= n:
                    continue

                # Sat column (1) — from sat_detected
                if idx < len(self.loaded_images):
                    detected = self.loaded_images[idx].get("sat_detected", None)
                    if detected is True:
                        item.setText(1, "⚠")
                        item.setForeground(1, QBrush(QColor(255, 160, 0)))
                        item.setTextAlignment(1, Qt.AlignmentFlag.AlignCenter)
                    elif detected is False:
                        item.setText(1, "✓")
                        item.setForeground(1, QBrush(QColor(100, 200, 100)))
                        item.setTextAlignment(1, Qt.AlignmentFlag.AlignCenter)

                # Stars (2), FWHM (3), Ecc (4), BG (5), Score (6), Temp (7), BG/s (8)
                item.setText(2, fmt_i(m3[idx]))
                item.setText(3, fmt_f(m0[idx]))
                item.setText(4, fmt_f(m1[idx]))
                item.setText(5, fmt_f(m2[idx]))
                item.setText(6, fmt_f(m4[idx]))
                item.setText(7, fmt_f(m5[idx]))
                item.setText(8, fmt_f(m6[idx]))

                for c in (2, 3, 4, 5, 6, 7, 8):
                    item.setTextAlignment(c, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)

        # After metrics are populated, re-apply the current sort indicator
        # so a column the user had sorted stays sorted with the new values.
        try:
            hdr = self.fileTree.header()
            self.fileTree.sortItems(hdr.sortIndicatorSection(),
                                    hdr.sortIndicatorOrder())
        except Exception:
            pass
        # Defer the metrics-window order sync for the same reason as the
        # header click: let Qt's sort pass settle before reading order.
        QTimer.singleShot(0, self._push_tree_order_to_metrics)
    # inside BlinkTab
    def _sync_metrics_flags(self):
        if self.metrics_window:
            panel = self.metrics_window.metrics_panel
            panel.flags = [entry['flagged'] for entry in self.loaded_images]
            panel._refresh_scatter_colors()
            # after a move/delete, current_indices might be stale → refresh text safely
            self.metrics_window._update_status()

    def _on_sat_mode_changed(self, _idx: int):
        """Persist the Sat-detect mode selection to QSettings."""
        try:
            mode = self.sat_mode_combo.currentData() or "fast"
            QSettings().setValue("blink/sat_detect_mode", str(mode))
        except Exception:
            pass

    def _sat_detect_mode(self) -> str:
        try:
            m = self.sat_mode_combo.currentData()
            return str(m) if m in ("fast", "full") else "fast"
        except Exception:
            return "fast"

    def _sat_detect_workers(self) -> int:
        """Current max concurrent satellite-detection workers."""
        try:
            v = int(QSettings().value(
                "blink/sat_detect_workers",
                int(getattr(self, "SAT_DETECT_MAX_WORKERS", 2)),
                type=int,
            ))
            return max(1, min(8, v))
        except Exception:
            return int(getattr(self, "SAT_DETECT_MAX_WORKERS", 2))

    def _open_sat_settings_dialog(self):
        """Small popover dialog for the advanced satellite-detection knobs."""
        dlg = QDialog(self)
        dlg.setWindowTitle(self.tr("Satellite Detection Settings"))
        dlg.setModal(True)

        layout = QGridLayout(dlg)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setHorizontalSpacing(12)
        layout.setVerticalSpacing(10)

        # ── Edge exclusion ───────────────────────────────────────────────
        edge_lbl = QLabel(self.tr("Ignore edges within:"), dlg)
        edge_spin = QSpinBox(dlg)
        edge_spin.setRange(0, 2048)
        edge_spin.setSingleStep(16)
        edge_spin.setSuffix(" px")
        edge_spin.setValue(self._sat_edge_exclusion_px())
        edge_spin.setToolTip(self.tr(
            "Pixels from each image edge to ignore for satellite trail detection.\n"
            "Amp glow near the sensor border reads as a bright streak that the\n"
            "detection models often flag as a trail — widen this to suppress\n"
            "those false positives. Default 128 px. Set to 0 to disable the\n"
            "edge filter. Applies to both Fast and Highlight modes."
        ))

        edge_help = QLabel(self.tr(
            "Hides amp-glow / sensor-edge false positives."
        ), dlg)
        edge_help.setStyleSheet("font-size: 10px; color: palette(mid);")
        edge_help.setWordWrap(True)

        layout.addWidget(edge_lbl, 0, 0)
        layout.addWidget(edge_spin, 0, 1)
        layout.addWidget(edge_help, 1, 0, 1, 2)

        # ── Worker threads ───────────────────────────────────────────────
        workers_lbl = QLabel(self.tr("Concurrent workers:"), dlg)
        workers_spin = QSpinBox(dlg)
        workers_spin.setRange(1, 8)
        workers_spin.setValue(self._sat_detect_workers())
        workers_spin.setToolTip(self.tr(
            "Number of images LOADED AND PREPARED in parallel.\n"
            "\n"
            "GPU inference itself is always serialized — one image at a time,\n"
            "regardless of this value. Interleaving GPU work from several\n"
            "threads onto one device is what causes DirectML adapter resets,\n"
            "so this knob deliberately does not parallelize it.\n"
            "\n"
            "Raising it overlaps file reads, stretching and tiling with the\n"
            "inference that is already running. Each worker holds a full-res\n"
            "frame in RAM. Default 2. Drop to 1 if you are short on memory."
        ))

        workers_help = QLabel(self.tr(
            "Overlaps file loading with inference. GPU work is always serialized."
        ), dlg)
        workers_help.setStyleSheet("font-size: 10px; color: palette(mid);")
        workers_help.setWordWrap(True)

        layout.addWidget(workers_lbl, 2, 0)
        layout.addWidget(workers_spin, 2, 1)
        layout.addWidget(workers_help, 3, 0, 1, 2)

        # ── OK / Cancel ──────────────────────────────────────────────────
        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        ok_btn = QPushButton(self.tr("OK"), dlg)
        cancel_btn = QPushButton(self.tr("Cancel"), dlg)
        ok_btn.setDefault(True)
        ok_btn.clicked.connect(dlg.accept)
        cancel_btn.clicked.connect(dlg.reject)
        btn_row.addWidget(ok_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row, 4, 0, 1, 2)

        dlg.setMinimumWidth(340)

        if dlg.exec() == QDialog.DialogCode.Accepted:
            try:
                QSettings().setValue(
                    "blink/sat_edge_exclusion_px", int(edge_spin.value())
                )
                QSettings().setValue(
                    "blink/sat_detect_workers", int(workers_spin.value())
                )
            except Exception as e:
                print(f"[Sat settings] Save failed: {e}")

    def _detect_satellite_trails(self):
        """
        Dispatcher: pick fast detection-only or full pipeline based on the
        Mode combo next to the button. "Full" mode shows a one-time warning
        the first time it is used, with a 'don't show again' option.
        """
        if not self.loaded_images:
            QMessageBox.information(self, self.tr("No Images"),
                                    self.tr("Load images before running satellite detection."))
            return

        mode = self._sat_detect_mode()

        if mode == "full":
            # Show one-time warning about slower runtime unless user has
            # already acknowledged it.
            try:
                skip_warn = bool(QSettings().value(
                    "blink/sat_full_warning_dismissed", False, type=bool))
            except Exception:
                skip_warn = False

            if not skip_warn:
                mb = QMessageBox(self)
                mb.setIcon(QMessageBox.Icon.Warning)
                mb.setWindowTitle(self.tr("Highlight Trails — Slower"))
                mb.setText(self.tr(
                    "'Highlight trails' runs the full satellite-removal pipeline on every "
                    "image. On frames with detected trails it also runs the NAFNet removal "
                    "model, which is significantly slower than the Fast detection-only pass "
                    "— expect several seconds to a minute per flagged frame depending on "
                    "your GPU."
                ))
                mb.setInformativeText(self.tr(
                    "Continue? The trail pixels will be painted bright green in the preview."))

                cb = QCheckBox(self.tr("Don't show this warning again"), mb)
                mb.setCheckBox(cb)

                mb.setStandardButtons(
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                mb.setDefaultButton(QMessageBox.StandardButton.Yes)

                resp = mb.exec()

                if cb.isChecked():
                    try:
                        QSettings().setValue(
                            "blink/sat_full_warning_dismissed", True)
                    except Exception:
                        pass

                if resp != QMessageBox.StandardButton.Yes:
                    return

            self._run_sat_detect_full()
        else:
            self._run_sat_detect_fast()

    # Max concurrent GPU inference workers for satellite detection. Each
    # worker holds one full-res raw image in RAM and its own activation
    # tensors on the GPU, so 2 is a safe balance between throughput and
    # VRAM/RAM pressure. Bump to 3 if your GPU and RAM can take it.
    SAT_DETECT_MAX_WORKERS = 2

    # Pixels from each image edge to IGNORE for satellite trail detection.
    # Amp glow typically lives in the outermost ring of the sensor and reads
    # as a bright streak that both detection models love to flag. Set to 0
    # to disable the edge filter entirely. Tunable at runtime via QSettings
    # key "blink/sat_edge_exclusion_px" per sensor.
    SAT_EDGE_EXCLUSION_PX = 128

    def _sat_edge_exclusion_px(self) -> int:
        """How many pixels from each image edge to ignore for satellite detection."""
        try:
            v = int(QSettings().value(
                "blink/sat_edge_exclusion_px",
                int(self.SAT_EDGE_EXCLUSION_PX),
                type=int,
            ))
            return max(0, v)
        except Exception:
            return int(self.SAT_EDGE_EXCLUSION_PX)

    @staticmethod
    def _apply_edge_exclusion_to_mask(mask_full: np.ndarray, edge_px: int) -> np.ndarray:
        """
        Zero out mask pixels within edge_px of any image edge, in-place-safe.
        Returns the (possibly modified) mask. Used in Highlight mode so amp
        glow near the sensor edge doesn't get painted green.
        """
        if edge_px <= 0 or mask_full is None:
            return mask_full
        m = np.asarray(mask_full, dtype=bool)
        if m.ndim != 2 or m.size == 0:
            return m
        H, W = m.shape
        # Make a writable copy to avoid mutating caller's array
        out = m.copy()
        # Only apply if the image is large enough to leave an interior
        if H > 2 * edge_px:
            out[:edge_px, :] = False
            out[-edge_px:, :] = False
        else:
            # Image is thinner than 2× exclusion — zero the whole thing
            out[:, :] = False
            return out
        if W > 2 * edge_px:
            out[:, :edge_px] = False
            out[:, -edge_px:] = False
        else:
            out[:, :] = False
        return out

    def _sat_mask_to_display_size(self, mask_full: np.ndarray, target_hw: tuple) -> np.ndarray:
        """
        Downsample a full-resolution 2D bool trail mask to the stored
        display image dimensions. OR-reduction over each block so a
        single hot pixel still appears green at any load_scale.
        """
        try:
            m = np.asarray(mask_full, dtype=bool)
            th, tw = int(target_hw[0]), int(target_hw[1])
            if m.ndim != 2 or th <= 0 or tw <= 0:
                return np.zeros((th, tw), dtype=bool)
            if m.shape == (th, tw):
                return m

            # cv2.resize on uint8 (0/255) with INTER_AREA averages blocks;
            # any block containing a True pixel produces a non-zero result,
            # so > 0 recovers OR-reduction.
            src = m.astype(np.uint8) * 255
            resized = cv2.resize(src, (tw, th), interpolation=cv2.INTER_AREA)
            return (resized > 0)
        except Exception as e:
            print(f"[Sat detect] Mask downsample failed: {e}")
            try:
                return np.zeros((int(target_hw[0]), int(target_hw[1])), dtype=bool)
            except Exception:
                return None

    def _sat_group_key(self, idx: int, shape_hw) -> tuple:
        """Which frames may be pooled for the fixed-pattern statistic.

        Amp glow and diffraction spikes belong to ONE rig in ONE configuration.
        Delegates to the engine so Blink, the Cosmic Clarity batch and
        Calibrate_Lights all use a single definition.
        """
        return artifact_group_key(
            self.loaded_images[idx].get("header", {}) or {}, shape_hw
        )

    def _sat_scan_frames(self, models, *, border_size, compat, prog,
                         abort_evt, device_err, max_workers, label):
        """
        THE satellite detection scan. There is exactly one of these.

        Fast mode IS this and nothing else. Highlight mode runs this as its
        pass 1 and then removes only what survives. Keeping it in one place is
        the point: when this existed twice the two copies drifted by a single
        parameter and Highlight silently stopped rejecting fixed-pattern tiles
        while Fast kept working.

        Does three things:
          1. detect every interior tile of every loaded frame (GPU work is
             serialized inside the engine; the threads overlap I/O and prep),
          2. build the per-group fixed-pattern map and reject tiles that keep
             appearing in the same sensor position,
          3. write the final sat_detected state for every frame.

        Writes nothing to disk, so cancelling is free.

        Returns a dict with:
          scanned    {idx: all passing tiles}
          survivors  {idx: REAL trail tiles, fixed-pattern already removed}
          n_art_tiles, n_cleared, n_unknown, canceled
        """
        import concurrent.futures as cf
        from setiastro.saspro.cosmicclarity_engines._backend_guard import (
            DeviceLostError,
            safe_exception_str as _safe_exc,
        )

        n_images = len(self.loaded_images)
        per_frame: dict = {}
        n_unknown = 0
        completed = 0
        canceled = False

        def _worker(idx: int, file_path: str):
            """Returns (idx, tiles, shape_hw). tiles is the list of passing
            (y0,x0,h,w) rects — possibly empty — or None for UNKNOWN."""
            if abort_evt.is_set():
                return (idx, None, None)
            try:
                from setiastro.saspro.legacy.image_manager import load_image
                raw_image, _h, _b, _m = load_image(file_path)
                if raw_image is None:
                    return (idx, None, None)
            except Exception as e:
                print(f"[Sat detect] Load failed for {file_path}: {e}")
                return (idx, None, None)

            if abort_evt.is_set():
                return (idx, None, None)

            shape_hw = tuple(int(v) for v in np.asarray(raw_image).shape[:2])
            try:
                tiles = satellite_detect_tiles(
                    raw_image, models,
                    chunk_size=256,
                    # MUST be 0. The map is tested back against whole tiles, so
                    # the grid has to be fixed and non-overlapping: a fixed
                    # artifact then lands in the SAME tile every frame and the
                    # mask comes out as that whole tile. On an overlapping grid
                    # it lands in a different subset each frame and the mask
                    # shrinks to the sliver where those subsets intersect —
                    # too small to veto anything.
                    overlap=0,
                    border_size=border_size,
                    temp_stretch=True, target_median=0.25,
                    compatibility_mode=compat,
                    # No early exit: the map needs every tile, or the counts
                    # skew toward whichever tiles get scanned first.
                    stop_after=None,
                    status_cb=lambda _m: None,
                )
                return (idx, list(tiles), shape_hw)
            except DeviceLostError as e:
                if not device_err:
                    device_err.append(_safe_exc(e))
                abort_evt.set()
                return (idx, None, None)
            except Exception as e:
                print(f"[Sat detect] Inference failed on {file_path}: {e}")
                return (idx, None, None)

        # Built explicitly rather than with `with`: ThreadPoolExecutor.__exit__
        # calls shutdown(wait=True), which blocks the GUI thread with no event
        # loop. If a worker is wedged in a driver call that is a permanent
        # freeze — the "hang with no further console output".
        ex = cf.ThreadPoolExecutor(max_workers=max_workers)
        try:
            futures = {
                ex.submit(_worker, i, self.loaded_images[i]["file_path"]): i
                for i in range(n_images)
            }
            pending = set(futures)
            while pending:
                if prog.wasCanceled():
                    canceled = True
                    abort_evt.set()
                    for f in pending:
                        f.cancel()
                    break
                if abort_evt.is_set():
                    for f in pending:
                        f.cancel()

                done, pending = cf.wait(pending, timeout=0.1,
                                        return_when=cf.FIRST_COMPLETED)
                for fut in done:
                    if fut.cancelled():
                        completed += 1
                        n_unknown += 1
                        continue
                    try:
                        idx, tiles, shape_hw = fut.result()
                    except Exception as e:
                        print(f"[Sat detect] Worker exception: {e}")
                        idx = futures.get(fut, -1)
                        tiles, shape_hw = None, None

                    if 0 <= idx < n_images:
                        if tiles is None or shape_hw is None:
                            self.loaded_images[idx]["sat_detected"] = None
                            n_unknown += 1
                        else:
                            per_frame[idx] = (tiles, shape_hw)
                    completed += 1

                prog.setValue(completed)
                prog.setLabelText(self.tr(
                    "{0}: {1} of {2} ({3} with hits so far)"
                ).format(label, completed, n_images,
                         sum(1 for t in per_frame.values() if t[0])))
                QApplication.processEvents()
        finally:
            try:
                ex.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                ex.shutdown(wait=False)

        # ── Fixed-pattern rejection (no GPU, pure counting) ─────────────────
        # Counting / thresholding / clean-vs-real splitting lives in the
        # engine so Blink, the CC batch and Calibrate_Lights share ONE copy.
        survivors: dict = {}
        n_art_tiles = 0
        n_cleared = 0
        if per_frame and not canceled and not device_err:
            builder = ArtifactMapBuilder()
            for idx, (tiles, hw) in per_frame.items():
                builder.add(idx, self.loaded_images[idx].get("header", {}) or {},
                            hw, tiles)
            clean, survivors, n_art_tiles = builder.finalize(
                status_cb=lambda m: print(f"[Sat detect] {m}"))
            n_cleared = sum(1 for i in clean if per_frame[i][0])
        else:
            # Scan did not complete: trust the raw hits, veto nothing.
            survivors = {i: t for i, (t, _hw) in per_frame.items() if t}

        for idx in per_frame:
            self.loaded_images[idx]["sat_detected"] = bool(idx in survivors)

        print(f"[Sat detect] Scan done: {len(per_frame)} checked, "
              f"{sum(1 for t in per_frame.values() if t[0])} with hits, "
              f"{n_art_tiles} fixed-pattern tile(s) ignored, "
              f"{n_cleared} frame(s) cleared, {len(survivors)} with real trails.")

        return {
            "scanned": {i: t for i, (t, _hw) in per_frame.items()},
            "survivors": survivors,
            "n_art_tiles": n_art_tiles,
            "n_cleared": n_cleared,
            "n_unknown": n_unknown,
            "canceled": canceled,
        }

    def _sat_begin(self, title: str):
        """Shared setup for both modes: progress dialog, models, snapshotted
        settings. Returns None when the models could not be loaded."""
        import threading as _th

        n_images = len(self.loaded_images)
        prog = QProgressDialog(
            self.tr("Loading satellite detection model…"),
            self.tr("Cancel"), 0, max(1, n_images), self,
        )
        prog.setWindowTitle(title)
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(0)
        prog.setMinimumWidth(420)
        prog.setValue(0)
        prog.show()
        QApplication.processEvents()

        try:
            models = get_satellite_models(
                use_gpu=True, status_cb=lambda m: print(f"[Sat] {m}"))
        except Exception as e:
            prog.close()
            QMessageBox.critical(
                self, self.tr("Model Load Error"),
                self.tr("Could not load satellite detection model:\n{0}").format(e))
            return None

        # Stale overlays from a previous run must not outlive it.
        for entry in self.loaded_images:
            entry.pop("sat_overlay_mask", None)

        try:
            compat = bool(QSettings().value("cc/gpu_compat_mode", False, type=bool))
        except Exception:
            compat = False

        # Guard against processEvents() re-entrancy starting a second run.
        try:
            self.sat_detect_btn.setEnabled(False)
        except Exception:
            pass

        return {
            "models": models,
            "prog": prog,
            "border_size": max(16, self._sat_edge_exclusion_px()),
            "compat": compat,
            "abort_evt": _th.Event(),
            "device_err": [],
            "max_workers": self._sat_detect_workers(),
            "n_images": n_images,
        }

    def _sat_finish(self, ctx):
        """Close the dialog, re-enable the button, refresh the tree/preview."""
        try:
            ctx["prog"].close()
        except Exception:
            pass
        try:
            self.sat_detect_btn.setEnabled(True)
        except Exception:
            pass

        self._update_tree_sat_column()
        try:
            cur = self.fileTree.currentItem()
            if cur is not None and cur.childCount() == 0:
                self._last_preview_name = None
                self.on_item_clicked(cur, 0)
        except Exception:
            pass

    def _sat_report_device_loss(self, device_err, *, modified: bool):
        """Poison DirectML process-wide and tell the user plainly."""
        from setiastro.saspro.cosmicclarity_engines._backend_guard import (
            disable_dml as _disable_dml,
        )
        try:
            _disable_dml("Adapter was removed or hung during satellite detection.",
                         status_cb=lambda m: print(f"[Sat] {m}"))
        except Exception:
            pass
        _what = (self.tr("Frames that were not checked are left blank in the Sat "
                         "column — they have NOT been marked clean.")
                 if modified else
                 self.tr("No images were modified."))
        QMessageBox.critical(
            self, self.tr("GPU Device Lost"),
            self.tr(
                "The graphics adapter was reset or removed during satellite "
                "detection:\n\n{0}\n\n{1}\n\n"
                "GPU acceleration has been disabled for the rest of this session. "
                "Re-run to continue on the CPU, or restart SASpro to try the GPU "
                "again."
            ).format(device_err[0], _what)
        )

    def _run_sat_detect_fast(self):
        """
        Fast mode: run the scan, report what it found. Nothing else.

        A lost adapter ABORTS the run; frames with no answer are left UNKNOWN
        (blank Sat cell) rather than recorded as clean.
        """
        ctx = self._sat_begin(self.tr("Satellite Trail Detection (Fast)"))
        if ctx is None:
            return

        res = self._sat_scan_frames(
            ctx["models"], border_size=ctx["border_size"], compat=ctx["compat"],
            prog=ctx["prog"], abort_evt=ctx["abort_evt"],
            device_err=ctx["device_err"], max_workers=ctx["max_workers"],
            label=self.tr("Scanning"),
        )
        self._sat_finish(ctx)

        if ctx["device_err"]:
            self._sat_report_device_loss(ctx["device_err"], modified=False)
            return
        if res["canceled"]:
            return

        n_detected = len(res["survivors"])
        _art = ""
        if res["n_art_tiles"]:
            _art = self.tr(
                "\nFixed-pattern filter: {0} tile(s) ignored as diffraction spikes "
                "or amp glow; {1} frame(s) cleared because that was their only "
                "evidence.\n"
            ).format(res["n_art_tiles"], res["n_cleared"])

        QMessageBox.information(
            self, self.tr("Satellite Detection Complete"),
            self.tr(
                "Checked {0} image{1}.\n"
                "{2} potential satellite trail{3} detected.\n"
                "{4} could not be checked.\n"
            ).format(ctx["n_images"], "s" if ctx["n_images"] != 1 else "",
                     n_detected, "s" if n_detected != 1 else "",
                     res["n_unknown"])
            + _art
            + self.tr(
                "\nImages with trails are marked ⚠ in the Sat column.\n"
                "Use 'F' or click a dot in Metrics to flag for culling.\n\n"
                "Tip: switch Mode to 'Highlight trails' to see the trail "
                "pixels painted green in the preview."
            )
        )

    def _run_sat_detect_full(self):
        """
        Highlight mode = the Fast scan, then removal on what survived it.

        Pass 1 is literally _sat_scan_frames — the same code Fast runs, so the
        two modes cannot disagree about which frames or tiles hold real trails.
        Pass 2 then loads ONLY the surviving frames and hands the engine their
        surviving tiles as detect_tiles, so it runs no detection of its own and
        pushes only those tiles through NAFNet.
        """
        import concurrent.futures as cf

        ctx = self._sat_begin(self.tr("Satellite Trail Detection (Highlight)"))
        if ctx is None:
            return
        models = ctx["models"]
        prog = ctx["prog"]
        abort_evt = ctx["abort_evt"]
        device_err = ctx["device_err"]
        n_images = ctx["n_images"]

        # ── PASS 1 — the Fast scan, verbatim ────────────────────────────────
        res = self._sat_scan_frames(
            models, border_size=ctx["border_size"], compat=ctx["compat"],
            prog=prog, abort_evt=abort_evt, device_err=device_err,
            max_workers=ctx["max_workers"],
            label=self.tr("Pass 1 of 2 — scanning"),
        )

        if device_err or res["canceled"]:
            # Pass 1 wrote nothing, so there is nothing to unwind.
            self._sat_finish(ctx)
            if device_err:
                self._sat_report_device_loss(device_err, modified=False)
            return

        survivors = res["survivors"]
        n_pass2 = len(survivors)

        # ── PASS 2 — removal, only the surviving frames and tiles ───────────
        SAT_MODE = "full"
        SAT_CLIP_TRAIL = True
        SAT_SENSITIVITY = 0.10
        SAT_TEMP_STRETCH = True
        SAT_TARGET_MEDIAN = 0.25
        edge_excl_px = ctx["border_size"]

        prog.setValue(0)
        try:
            prog.setMaximum(max(1, n_pass2))
        except Exception:
            pass

        job_specs = []
        for idx in sorted(survivors):
            # The overlay mask is stored at DISPLAY size. In Stream mode the
            # pixels may not be resident, so take the geometry from the header
            # rather than forcing a decode we do not otherwise need.
            job_specs.append((idx, self.loaded_images[idx]["file_path"],
                              self._frame_shape_hint(idx)))

        def _worker(idx: int, file_path, stored_hw):
            """Removal for one surviving frame. Returns (idx, mask_display)."""
            if abort_evt.is_set():
                return (idx, None)
            try:
                from setiastro.saspro.legacy.image_manager import load_image
                raw_image, _h, _b, _m = load_image(file_path)
                if raw_image is None:
                    return (idx, None)
            except Exception as e:
                print(f"[Sat detect] Load failed for {file_path}: {e}")
                return (idx, None)

            if abort_evt.is_set():
                return (idx, None)

            try:
                _out, _detected, trail_mask_full = satellite_remove_image(
                    raw_image,
                    models=models,
                    mode=SAT_MODE,
                    clip_trail=SAT_CLIP_TRAIL,
                    sensitivity=SAT_SENSITIVITY,
                    temp_stretch=SAT_TEMP_STRETCH,
                    target_median=SAT_TARGET_MEDIAN,
                    return_mask=True,
                    progress_cb=None,
                    # Pass 1's surviving tiles. The engine runs NO detection.
                    detect_tiles=survivors.get(idx),
                    status_cb=lambda _m: None,
                )
            except Exception as e:
                from setiastro.saspro.cosmicclarity_engines._backend_guard import (
                    is_device_lost_error as _is_lost,
                    safe_exception_str as _exc,
                )
                if _is_lost(e):
                    if not device_err:
                        device_err.append(_exc(e))
                    abort_evt.set()
                    return (idx, None)
                print(f"[Sat detect] Pipeline failed on {file_path}: {e}")
                return (idx, None)

            trail_mask_full = self._apply_edge_exclusion_to_mask(
                trail_mask_full, edge_excl_px)
            if trail_mask_full is None or not trail_mask_full.any():
                return (idx, None)
            mask_display = self._sat_mask_to_display_size(trail_mask_full, stored_hw)
            if mask_display is None or not mask_display.any():
                return (idx, None)
            return (idx, mask_display)

        completed = 0
        ex = cf.ThreadPoolExecutor(max_workers=ctx["max_workers"])
        try:
            futures = {ex.submit(_worker, i, fp, hw): i for (i, fp, hw) in job_specs}
            pending = set(futures)
            while pending:
                if prog.wasCanceled():
                    abort_evt.set()
                    for f in pending:
                        f.cancel()
                    break
                if abort_evt.is_set():
                    for f in pending:
                        f.cancel()

                done, pending = cf.wait(pending, timeout=0.1,
                                        return_when=cf.FIRST_COMPLETED)
                for fut in done:
                    if not fut.cancelled():
                        try:
                            idx, mask = fut.result()
                            if mask is not None and 0 <= idx < n_images:
                                self.loaded_images[idx]["sat_overlay_mask"] = mask
                        except Exception as e:
                            print(f"[Sat detect] Worker exception: {e}")
                    completed += 1

                prog.setValue(completed)
                prog.setLabelText(self.tr(
                    "Pass 2 of 2 — removing trails: {0} of {1}"
                ).format(completed, n_pass2))
                QApplication.processEvents()
        finally:
            try:
                ex.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                ex.shutdown(wait=False)

        self._sat_finish(ctx)

        if device_err:
            self._sat_report_device_loss(device_err, modified=True)
            return

        _art = ""
        if res["n_art_tiles"]:
            _art = self.tr(
                "\nFixed-pattern filter: {0} tile(s) ignored as diffraction spikes "
                "or amp glow; {1} frame(s) cleared because that was their only "
                "evidence, so pass 2 only had to process {2}.\n"
            ).format(res["n_art_tiles"], res["n_cleared"], n_pass2)

        QMessageBox.information(
            self, self.tr("Satellite Detection Complete"),
            self.tr(
                "Checked {0} image{1}.\n"
                "{2} potential satellite trail{3} detected.\n"
                "{4} could not be checked.\n"
            ).format(n_images, "s" if n_images != 1 else "",
                     n_pass2, "s" if n_pass2 != 1 else "",
                     res["n_unknown"])
            + _art
            + self.tr(
                "\nImages with trails are marked ⚠ in the Sat column and\n"
                "the trail pixels are highlighted in bright green in the preview.\n"
                "Use 'F' or click a dot in Metrics to flag for culling."
            )
        )

    def _update_tree_sat_column(self):
        for item in self.get_all_leaf_items():
            idx = self._leaf_index(item)
            if idx is None or idx < 0 or idx >= len(self.loaded_images):
                continue
            detected = self.loaded_images[idx].get("sat_detected", None)
            if detected is True:
                item.setText(1, "⚠")
                item.setForeground(1, QBrush(QColor(255, 160, 0)))
                item.setTextAlignment(1, Qt.AlignmentFlag.AlignCenter)
            elif detected is False:
                item.setText(1, "✓")
                item.setForeground(1, QBrush(QColor(100, 200, 100)))
                item.setTextAlignment(1, Qt.AlignmentFlag.AlignCenter)
            else:
                item.setText(1, "")
        if hasattr(self, "tree_filter_combo"):
            self._apply_tree_filter()

    def addAdditionalImages(self):
        """Let the user pick more images to append to the blink list."""
        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            self.tr("Add Additional Images"),
            self._last_folder(),
            self.tr("Images (*.png *.jpg *.jpeg *.tif *.tiff *.fits *.fit *.fts *.fits.gz *.fit.gz *.fts.gz *.fz *.xisf *.cr2 *.cr3 *.nef *.arw *.dng *.raf *.orf *.rw2 *.pef);;All Files (*)")
        )
        if file_paths:
            self._save_last_folder(file_paths[0])        
        # filter out duplicates
        new_paths = [p for p in file_paths if p not in self.image_paths]
        if not new_paths:
            QMessageBox.information(self, self.tr("No New Images"), self.tr("No new images selected or already loaded."))
            return
        self._appendImages(new_paths)

    def _appendImages(self, file_paths):
        # decide dtype exactly as in loadImages
        target_dtype = _blink_storage_dtype()

        if self._stream_mode:
            self._stream_scan(
                sorted(file_paths,
                       key=lambda p: self._natural_key(os.path.basename(p))),
                append=True)
            return

        # Appending counts the resident frames against the budget too.
        if self._preflight_stream_switch(file_paths, appending=True):
            self._stream_scan(
                sorted(file_paths,
                       key=lambda p: self._natural_key(os.path.basename(p))),
                append=True)
            return

        total_new = len(file_paths)
        self.progress_bar.setRange(0, total_new)
        self.progress_bar.setValue(0)
        QApplication.processEvents()

        # Throttle UI updates so paints aren't starved when total_new is large.
        # Aim for ~100 updates over the whole load regardless of file count.
        step = max(1, total_new // 100)
        # Hoisted so the memory guard can hand the unprocessed tail to
        # _stream_scan if it has to bail part way through.
        ordered = sorted(file_paths,
                         key=lambda p: self._natural_key(os.path.basename(p)))
        mem_bytes = 0
        mem_last_check = time.monotonic()

        for i, path in enumerate(ordered):
            try:
                _, hdr, bit_depth, is_mono, stored, back = self._load_one_image(path, target_dtype, self._load_scale)
            except Exception as e:
                print(f"Failed to load {path}: {e}")
                continue

            # append to our master lists
            self.image_paths.append(path)
            self.loaded_images.append({
                'file_path':      path,
                'image_data':     stored,
                'header':         hdr or {},
                'bit_depth':      bit_depth,
                'is_mono':        is_mono,
                'flagged':        False,
                'orig_background': back,
                'load_scale':      self._load_scale,
            })

            # and add it into the tree under the correct object/filter/exp
            self.add_item_to_tree(path)

            # throttled progress update
            done = i + 1
            if done == total_new or (done % step) == 0:
                self.progress_bar.setValue(done)
                QApplication.processEvents()

            # Same guard as the parallel path. Switching to Stream drops the
            # pixels of everything already appended, which is exactly what
            # needs to happen here, and the tail is streamed instead.
            mem_bytes += int(getattr(stored, "nbytes", 0) or 0)
            _now = time.monotonic()
            if _now - mem_last_check >= 0.25:
                mem_last_check = _now
                trip = self._mem_trip(mem_bytes, done, total_new)
                if trip:
                    # Release the pixels BEFORE putting a dialog on screen: Qt
                    # needs memory of its own to draw one, and _set_stream_mode
                    # would not free these until after it was dismissed.
                    for entry in self.loaded_images:
                        entry["image_data"] = None
                    gc.collect()
                    self._mem_abandon_preload(trip, done, total_new)
                    tail = ordered[done:]
                    if tail:
                        self._stream_scan(tail, append=True)
                    else:
                        self._rebuild_tree_from_loaded()
                        self.imagesChanged.emit(len(self.loaded_images))
                    return

        # update status
        self.loading_label.setText(self.tr("Loaded {0} images.").format(len(self.loaded_images)))
        if self.metrics_window and self.metrics_window.isVisible():
            self.metrics_window.update_metrics(self.loaded_images, order=self._tree_order_indices())
        self._update_tree_metrics_columns()
        self.imagesChanged.emit(len(self.loaded_images))

        # Honor persisted Fit preference: auto-select the first leaf
        # (which triggers a deferred fit) so the user sees their saved
        # view mode without having to click a frame first.
        if getattr(self, "_auto_fit", False):
            QTimer.singleShot(0, self._auto_select_first_leaf_after_load)

    def show_metrics(self):
        if self.metrics_window is None:
            # Parent to BlinkTab so this stays in the same window hierarchy
            # as Blink — closes/hides along with Blink instead of becoming
            # its own orphaned top-level window.
            self.metrics_window = MetricsWindow(parent=self)
            mp = self.metrics_window.metrics_panel

            # Wire metrics interactions back to BlinkTab so clicking a dot
            # flags/unflags the corresponding frame, and dragging a
            # threshold line re-evaluates flags for all frames against it.
            mp.pointClicked.connect(self.on_metrics_point)
            mp.thresholdChanged.connect(self.on_threshold_change)

        # In Stream mode the panel has to be able to pull pixels itself:
        # measuring streams frame by frame, and shift-click previews a frame
        # whose pixels may have been evicted.
        mp = self.metrics_window.metrics_panel
        mp.pixel_loader = self._metrics_pixels if self._stream_mode else None
        mp.shape_hint = self._frame_shape_hint if self._stream_mode else None

        order = self._tree_order_indices()
        self.metrics_window.set_images(self.loaded_images, order=order)

        panel = self.metrics_window.metrics_panel

        # --- restore thresholds into the UI instead of overwriting saved state ---

        self.metrics_window.show()
        self.metrics_window.raise_()
        self._update_tree_metrics_columns()


    def on_metrics_point(self, metric_idx, frame_idx):
        item = self.get_tree_item_for_index(frame_idx)
        if not item:
            return
        self._toggle_flag_on_item(item)  

    def _as_float01(self, arr):
        """Convert any stored dtype to float32 in [0..1], with safety normalization."""
        if arr.dtype == np.uint8:
            out = arr.astype(np.float32) / 255.0
            return out

        if arr.dtype == np.uint16:
            out = arr.astype(np.float32) / 65535.0
            return out

        # float path (or anything else): normalize if needed
        out = np.asarray(arr, dtype=np.float32)

        if out.size == 0:
            return out

        # handle NaNs/Infs early
        out = np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)

        mn = float(out.min())
        if mn < 0.0:
            out = out - mn  # shift so min becomes 0

        mx = float(out.max())
        if mx > 1.0 and mx > 0.0:
            out = out / mx  # scale so max becomes 1

        return np.clip(out, 0.0, 1.0)

    def on_threshold_change(self, metric_idx, threshold):
        panel = self.metrics_window.metrics_panel
        if panel.metrics_data is None:
            return

        group_id = self.metrics_window._current_group_id()

        # Save into MetricsWindow's dict — single source of truth
        thr_list = self.metrics_window._thresholds_per_group.setdefault(group_id, [None] * 7)
        while len(thr_list) < 7:
            thr_list.append(None)
        thr_list[metric_idx] = threshold

        # Re-evaluate ALL frames using ALL groups' thresholds cumulatively.
        # A frame is flagged if ANY group whose threshold covers it triggers.
        # Start clean: unflag everything, then re-apply all saved thresholds.
        for entry in self.loaded_images:
            entry['flagged'] = False

        for gid, thr_list in self.metrics_window._thresholds_per_group.items():
            if gid == "__ALL__":
                indices = range(len(self.loaded_images))
            else:
                indices = [
                    i for i, e in enumerate(self.loaded_images)
                    if (e.get('header', {}) or {}).get('FILTER', 'Unknown') == gid
                ]

            for i in indices:
                if self.loaded_images[i]['flagged']:
                    continue  # already flagged, skip further checks
                for m, thr in enumerate(thr_list):
                    if thr is None:
                        continue
                    if m >= len(panel.metrics_data):
                        continue
                    val = panel.metrics_data[m][i]
                    if np.isnan(val):
                        continue
                    if (m in (0, 1, 2, 5, 6) and val > thr) or (m in (3, 4) and val < thr):
                        self.loaded_images[i]['flagged'] = True
                        break

        # Update tree visuals for all frames
        RED = Qt.GlobalColor.red
        normal = self.fileTree.palette().color(QPalette.ColorRole.WindowText)
        for i, entry in enumerate(self.loaded_images):
            item = self.get_tree_item_for_index(i)
            if not item:
                continue
            name = item.text(0).lstrip("⚠️ ")
            if entry['flagged']:
                item.setText(0, f"⚠️ {name}")
                item.setForeground(0, QBrush(RED))
            else:
                item.setText(0, name)
                item.setForeground(0, QBrush(normal))

        panel.flags = [e['flagged'] for e in self.loaded_images]
        panel._refresh_scatter_colors()
        self.metrics_window._update_status()

    def _rebuild_tree_from_loaded(self):
        # Reset filter to All on rebuild so nothing gets stranded hidden
        if hasattr(self, "tree_filter_combo"):
            self.tree_filter_combo.blockSignals(True)
            self.tree_filter_combo.setCurrentIndex(0)
            self.tree_filter_combo.blockSignals(False)
        from collections import defaultdict

        with self._tree_bulk_update():
            self.fileTree.clear()

            grouped = defaultdict(list)
            for entry in self.loaded_images:
                hdr = entry.get('header', {}) or {}
                obj = hdr.get('OBJECT', 'Unknown')
                fil = hdr.get('FILTER', 'Unknown')
                exp = _blink_exposure_label(hdr)
                grouped[(obj, fil, exp)].append(entry['file_path'])

            for key, paths in grouped.items():
                paths.sort(key=lambda p: self._natural_key(os.path.basename(p)))

            by_object = defaultdict(lambda: defaultdict(dict))
            for (obj, fil, exp), paths in grouped.items():
                by_object[obj][fil][exp] = paths

            for obj in sorted(by_object, key=lambda o: o.lower()):
                obj_item = _BlinkSortItem([self.tr("Object: {0}").format(obj)])
                self.fileTree.addTopLevelItem(obj_item)
                obj_item.setExpanded(True)

                for fil in sorted(by_object[obj], key=lambda f: f.lower()):
                    filt_item = _BlinkSortItem([self.tr("Filter: {0}").format(fil)])
                    obj_item.addChild(filt_item)
                    filt_item.setExpanded(True)

                    for exp in sorted(by_object[obj][fil], key=lambda e: str(e).lower()):
                        exp_item = _BlinkSortItem([self.tr("Exposure: {0}").format(exp)])
                        filt_item.addChild(exp_item)
                        exp_item.setExpanded(True)

                        for p in by_object[obj][fil][exp]:
                            leaf = _BlinkSortItem([os.path.basename(p), "", "", "", "", ""])
                            leaf.setData(0, Qt.ItemDataRole.UserRole, p)
                            exp_item.addChild(leaf)

            # Re-apply flagged styling
            RED = Qt.GlobalColor.red
            normal = self.fileTree.palette().color(QPalette.ColorRole.WindowText)

            for idx, entry in enumerate(self.loaded_images):
                item = self.get_tree_item_for_index(idx)
                if not item:
                    continue
                base = os.path.basename(self.image_paths[idx])
                if entry.get("flagged", False):
                    item.setText(0, f"⚠️ {base}")
                    item.setForeground(0, QBrush(RED))
                else:
                    item.setText(0, base)
                    item.setForeground(0, QBrush(normal))

        # After re-enabling sort, metric columns may need the current
        # sort indicator applied against freshly-rebuilt rows.
        try:
            hdr = self.fileTree.header()
            self.fileTree.sortItems(hdr.sortIndicatorSection(),
                                    hdr.sortIndicatorOrder())
        except Exception:
            pass


    def _after_list_changed(self, removed_indices: List[int] | None = None):
        if self._stream_cache is not None:
            self._stream_cache.retain(self.image_paths)
        self._rebuild_tree_from_loaded()
        self.imagesChanged.emit(len(self.loaded_images))

        if self.metrics_window and self.metrics_window.isVisible():
            order = self._tree_order_indices()

            if removed_indices:
                self.metrics_window._all_images = self.loaded_images
                self.metrics_window.remove_indices(list(removed_indices))
                self.metrics_window._order_all = list(order)
                self.metrics_window.update_metrics(self.loaded_images, order=order)
            else:
                self.metrics_window.update_metrics(self.loaded_images, order=order)

            self._sync_metrics_flags()

        # ← Move this to AFTER metrics are updated so arrays are aligned
        self._update_tree_metrics_columns()
        if hasattr(self, "tree_filter_combo"):
            self._apply_tree_filter()

    def get_tree_item_for_index(self, idx):
        target_path = self.image_paths[idx]
        for item in self.get_all_leaf_items():
            p = item.data(0, Qt.ItemDataRole.UserRole)
            if p == target_path:
                return item
        return None


    def compute_metric(self, metric_idx, entry):
        """Recompute a single metric for one image.  Use cached orig_background for metric 2."""
        # metric 2 is the pre-stretch background we already computed
        if metric_idx == 2:
            return entry.get('orig_background', np.nan)

        # otherwise rebuild a float32 [0..1] array from whatever dtype we stored
        # (no callers today, but it must not be a trap in Stream mode, where
        # an entry legitimately carries no pixels)
        img = entry.get('image_data')
        if img is None:
            return np.nan
        if img.dtype == np.uint8:
            data = img.astype(np.float32)/255.0
        elif img.dtype == np.uint16:
            data = img.astype(np.float32)/65535.0
        else:
            data = np.asarray(img, dtype=np.float32)
        if data.ndim == 3:
            data = data.mean(axis=2)

        # run SEP for the other metrics
        bkg = sep.Background(data)
        back, gr, rr = bkg.back(), bkg.globalback, bkg.globalrms
        cat = sep.extract(data - back, 5.0, err=gr, minarea=9)
        if len(cat)==0:
            return np.nan

        sig = np.sqrt(cat['a']*cat['b'])
        if metric_idx == 0:
            return np.nanmedian(2.3548*sig)
        elif metric_idx == 1:
            return np.nanmedian(1 - (cat['b']/cat['a']))
        else:  # metric_idx == 3 (star count)
            return len(cat)


    def init_shortcuts(self):
        """Initialize keyboard shortcuts."""
        toggle_shortcut = QShortcut(QKeySequence("Space"), self.fileTree)
        def _toggle_play():
            if self.playback_timer.isActive():
                self.stop_playback()
            else:
                self.start_playback()
        toggle_shortcut.activated.connect(_toggle_play)        
        # Create a shortcut for the "F" key to flag images
        flag_shortcut = QShortcut(QKeySequence("F"), self.fileTree)
        flag_shortcut.activated.connect(self.flag_current_image)

    def openDirectoryDialog(self):
        """Allow users to select a directory and load all images within it recursively."""
        directory = QFileDialog.getExistingDirectory(self, self.tr("Select Directory"), self._last_folder())
        if directory:
            self._save_last_folder(directory)
        if directory:
            # Supported image extensions
            supported_extensions = (
                '.png', '.tif', '.tiff', '.fits', '.fit', '.fts',
                '.fits.gz', '.fit.gz', '.fts.gz', '.fz',
                '.xisf', '.cr2', '.nef', '.arw', '.dng', '.raf',
                '.orf', '.rw2', '.pef', '.jpg', '.jpeg'
            )

            # Collect all image file paths recursively
            new_file_paths = []
            for root, _, files in os.walk(directory):
                for file in sorted(files, key=str.lower):  # 🔹 Sort alphabetically (case-insensitive)
                    if file.lower().endswith(supported_extensions):
                        full_path = os.path.join(root, file)
                        if full_path not in self.image_paths:  # Avoid duplicates
                            new_file_paths.append(full_path)

            if new_file_paths:
                self.loadImages(new_file_paths)
            else:
                QMessageBox.information(self, self.tr("No Images Found"), self.tr("No supported image files were found in the selected directory."))


    def clearImages(self):
        """Clear all loaded images and reset the tree view."""
        confirmation = QMessageBox.question(
            self,
            self.tr("Clear All Images"),
            self.tr("Are you sure you want to clear all loaded images?"),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if confirmation == QMessageBox.StandardButton.Yes:
            self.stop_playback()
            self.image_paths.clear()
            self.loaded_images.clear()
            self.image_labels.clear()
            self.fileTree.clear()
            if self._stream_cache is not None:
                self._stream_cache.clear()
            self.preview_label.clear()
            self.preview_label.setText(self.tr('No image selected.'))
            self.current_pixmap = None
            self.progress_bar.setValue(0)
            self.loading_label.setText(self.tr("Loading images..."))
            self.imagesChanged.emit(len(self.loaded_images)) 

            # (legacy) if you still have this, you can delete it:
            # self.thresholds = [None, None, None, None]

            # also reset the metrics panel (if it’s open)
            if self.metrics_window is not None:
                mp = self.metrics_window.metrics_panel
                # clear out old data & reset flags / thresholds
                mp.metrics_data = None
                mp._threshold_initialized = [False]*7
                for scat in mp.scats:
                    scat.clear()
                for line in mp.lines:
                    line.setPos(0)

                # clear per‐group threshold storage
                self.metrics_window._thresholds_per_group.clear()

        # finally, tell the MetricsWindow to fully re‐init with no images
        if self.metrics_window is not None:
            self.metrics_window.update_metrics([])
   
    @staticmethod
    def _load_one_image(file_path: str, target_dtype, load_scale: int = 1):
        # 1) Fast path: plain FITS / XISF at 1:4 or 1:8 is read strided,
        #    straight to the downsampled frame -- no full-resolution read, no
        #    full-resolution debayer, no cv2.resize. A CFA frame comes back as
        #    a quad-aligned MOSAIC in colour mode, which still goes through the
        #    normal debayer, just on a frame 16x or 64x smaller.
        #
        #    read_downsampled returns None for anything it cannot reproduce
        #    exactly as load_image would (compressed or gzipped containers,
        #    the FITS dtypes load_image min-max normalizes, 1:1 and 1:2,
        #    BOTTOM-UP CFA in colour mode), and we fall through below.
        fast = None
        if load_scale > 1 and _blink_fast_read_enabled():
            try:
                fast = read_downsampled(file_path, load_scale,
                                        cfa_mode=_blink_cfa_mode())
            except Exception as e:
                print(f"[Blink] strided read failed for {file_path}: {e}")
                fast = None

        if fast is not None:
            image, header, bit_depth, needs_debayer = fast
            if needs_debayer:
                # Same debayer the full-resolution path uses, on the small
                # mosaic. BAYERPAT and the CFA phase were preserved by the
                # reader precisely so this call stays correct.
                image = BlinkTab.debayer_image(image, file_path, header)
            is_color_after_debayer = (image.ndim == 3 and image.shape[2] >= 3)
        else:
            # 1b) load
            image, header, bit_depth, is_mono = load_image(file_path)
            if image is None or image.size == 0:
                msg = QCoreApplication.translate("BlinkTab", "Empty image")
                raise ValueError(msg)

            # 2) optional debayer
            if is_mono:
                image = BlinkTab.debayer_image(image, file_path, header)

            is_color_after_debayer = (image.ndim == 3 and image.shape[2] >= 3)

            # 3) optional downsample BEFORE stretch (cheaper to stretch small)
            if load_scale > 1:
                h, w = image.shape[:2]
                new_h = max(1, h // load_scale)
                new_w = max(1, w // load_scale)
                image = cv2.resize(image, (new_w, new_h),
                                   interpolation=cv2.INTER_AREA)

        # 4) measure pre-stretch background on (possibly downsampled) mono plane
        data = np.asarray(image, dtype=np.float32)
        if data.ndim == 3:
            data = data.mean(axis=2)
        bkg = sep.Background(data)
        global_back = bkg.globalback

        # 5) stretch — rest unchanged
        target_med = 0.25
        if is_color_after_debayer:
            stretched = stretch_color_image(image, target_med, linked=False,
                                            no_black_clip=True)
        else:
            stretched = stretch_mono_image(image, target_med,
                                           no_black_clip=True)

        clipped = np.clip(stretched, 0.0, 1.0)
        if target_dtype is np.uint8:
            stored = (clipped * 255).astype(np.uint8)
        elif target_dtype is np.uint16:
            stored = (clipped * 65535).astype(np.uint16)
        else:
            stored = clipped.astype(np.float32)

        is_mono_final = not is_color_after_debayer
        return file_path, header, bit_depth, is_mono_final, stored, global_back

    @staticmethod
    def debayer_image(image, file_path, header):
        """
        Debayer a mono mosaic into RGB using SASpro's canonical debayer_array,
        which is the same core the Debayer dialog and stacking pipeline use.
        It owns the ROWORDER=BOTTOM-UP flip-in / flip-out, so we don't have to.
        """
        _ = file_path
        arr = np.asarray(image)
        if arr.ndim != 2:
            return image

        try:
            bayer_pattern = detect_bayer_pattern(header, image_shape=arr.shape)
        except Exception:
            bayer_pattern = None
        if not bayer_pattern:
            return image

        try:
            _xoff, _yoff, roworder = detect_bayer_offsets_and_roworder(header)
        except Exception:
            roworder = ""

        try:
            # Local import avoids any import-time cycle between blink and debayer.
            from setiastro.saspro.debayer import debayer_array
            return debayer_array(
                arr,
                pattern=bayer_pattern,
                roworder=roworder,
                method="edge",
                cfa_drizzle=False,
            )
        except Exception:
            # Last-ditch fallback: raw kernel with no orientation correction.
            # Better a slightly-wrong preview than a crashed loader.
            return debayer_raw_fast(arr, bayer_pattern=bayer_pattern)

    @staticmethod
    def _natural_key(path: str):
        """
        Split a filename into text and integer chunks so that 
        “…_2.fit” sorts before “…_10.fit”.
        """
        name = os.path.basename(path)
        return [int(tok) if tok.isdigit() else tok.lower()
                for tok in re.split(r'(\d+)', name)]

    def loadImages(self, file_paths):
        # 0) early out
        if not file_paths:
            return

        # ---------- NEW: natural sort the list of filenames ----------
        file_paths = sorted(file_paths, key=lambda p: self._natural_key(os.path.basename(p)))

        # 1) pick storage dtype (see _blink_storage_dtype: always uint16)
        target_dtype = _blink_storage_dtype()

        if self._stream_mode:
            self._stream_scan(file_paths, append=False)
            return

        # Would PreLoading this folder run the machine out of memory? Asked
        # before anything is decoded; may switch us into Stream.
        if self._preflight_stream_switch(file_paths, appending=False):
            self._stream_scan(file_paths, append=False)
            return

        total = len(file_paths)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        QApplication.processEvents()

        self.image_paths.clear()
        self.loaded_images.clear()
        self.fileTree.clear()

        # ---------- NEW: Retry-aware parallel load ----------
        MAX_RETRIES = 2
        RETRY_DELAY = 2
        remaining = list(file_paths)
        completed = []
        attempt = 0
        last_pct = -1

        # Memory guard state. mem_bytes is what the decoded frames have
        # actually cost, which beats any estimate once frames start landing.
        mem_bytes = 0
        mem_tripped = None
        mem_last_check = time.monotonic()
        futures = {}

        # Make sure numba's threading layer is resolved & recorded before we
        # fan out — otherwise the lock's decision falls back to an OS guess
        # (fast/no-op on Linux), which is the concurrent-access abort path.
        _blink_wait_for_numba_layer()

        # Apply platform / QSettings thread-safety mode once, before the pool.
        _mode = _blink_apply_thread_safety()

        # Pathological fallback: if warmup still hasn't resolved the layer
        # (e.g. it timed out on a very slow machine), don't gamble on a possible
        # workqueue box — serialize this load. Better slow than aborted.
        try:
            from setiastro.saspro.legacy.numba_utils import (
                numba_threading_layer_unsafe, set_numba_parallel_serialize,
            )
            if numba_threading_layer_unsafe() is None:
                set_numba_parallel_serialize(True)
                _mode = "safe"
        except Exception:
            pass

        while remaining and attempt <= MAX_RETRIES:

            total_cpus = os.cpu_count() or 1
            if _mode == "safe":
                # macOS / forced-safe: FITS read + numba debayer are serialized,
                # so extra threads only add seek/mmap contention with no
                # throughput gain, and widen the window for the races we've
                # locked around. Cap conservatively.
                max_workers = max(1, min(total_cpus - 1, 8))
            else:
                # Fast path (original pre-thread-safety behavior): reserve ~25%
                # of cores (capped at 4) for the GUI/OS, then scale out to the
                # rest, capped at 60.
                reserved_cpus = min(4, max(1, int(total_cpus * 0.25)))
                max_workers = max(1, min(total_cpus - reserved_cpus, 60))

            # The decoders' own working set can OOM before a single frame has
            # been stored, so the pool is sized against free RAM as well as CPU.
            _cap = self._mem_worker_cap(getattr(self, "_mem_per_frame_hint", None))
            if _cap is not None and _cap < max_workers:
                print(f"[Blink] memory guard: pool {max_workers} -> {_cap} workers")
                max_workers = _cap

            futures = {}
            failed = []

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                for path in remaining:
                    futures[executor.submit(
                        self._load_one_image, path, target_dtype, self._load_scale
                    )] = path
                for fut in as_completed(futures):
                    path = futures[fut]
                    try:
                        result = fut.result()
                        completed.append(result)
                        # result[4] is the stored frame
                        mem_bytes += int(getattr(result[4], "nbytes", 0) or 0)
                        done = len(completed)
                        pct = int(100 * done / total)
                        if pct != last_pct:
                            self.progress_bar.setValue(pct)
                            QApplication.processEvents()
                            last_pct = pct
                    except Exception as e:
                        print(f"[WARN][Attempt {attempt}] Failed to load {path}: {e}")
                        failed.append(path)

                    # Throttled: virtual_memory() is a syscall and this loop
                    # runs once per frame.
                    _now = time.monotonic()
                    if _now - mem_last_check >= 0.25:
                        mem_last_check = _now
                        mem_tripped = self._mem_trip(mem_bytes, len(completed), total)
                        if mem_tripped:
                            # Cancel what has not started. The handful already
                            # running will finish and be dropped unread.
                            executor.shutdown(wait=False, cancel_futures=True)
                            break

            if mem_tripped:
                break

            remaining = failed
            attempt += 1
            if remaining:
                print(f"[Retry] {len(remaining)} images will be retried after {RETRY_DELAY}s...")
                non_blocking_sleep(RETRY_DELAY)

        if mem_tripped:
            # Drop the decoded frames. The futures hold references too, so
            # clearing `completed` alone would free nothing.
            done_n = len(completed)
            completed.clear()
            futures.clear()
            gc.collect()
            self._mem_abandon_preload(mem_tripped, done_n, total)
            self._stream_scan(file_paths, append=False)
            return

        if remaining:
            print(f"[FAILURE] These files failed to load after {MAX_RETRIES} retries:")
            for path in remaining:
                print(f"  - {path}")

        # ---------- Unpack completed results ----------
        for path, header, bit_depth, is_mono, stored, back in completed:
            header = header or {}
            self.image_paths.append(path)
            self.loaded_images.append({
                'file_path':      path,
                'image_data':     stored,
                'header':         header,
                'bit_depth':      bit_depth,
                'is_mono':        is_mono,
                'flagged':        False,
                'orig_background': back,
                'load_scale':      self._load_scale,
            })

        # 3) rebuild object/filter/exposure tree
        grouped = defaultdict(list)
        for entry in self.loaded_images:
            hdr = entry['header']
            obj = hdr.get('OBJECT', 'Unknown')
            filt = hdr.get('FILTER', 'Unknown')
            exp = _blink_exposure_label(hdr)
            grouped[(obj, filt, exp)].append(entry['file_path'])

        for key, paths in grouped.items():
            paths.sort(key=lambda p: self._natural_key(os.path.basename(p)))
        by_object = defaultdict(lambda: defaultdict(dict))
        for (obj, filt, exp), paths in grouped.items():
            by_object[obj][filt][exp] = paths

        with self._tree_bulk_update():
            for obj in sorted(by_object, key=lambda o: o.lower()):
                obj_item = _BlinkSortItem([f"Object: {obj}"])
                self.fileTree.addTopLevelItem(obj_item)
                obj_item.setExpanded(True)

                for filt in sorted(by_object[obj], key=lambda f: f.lower()):
                    filt_item = _BlinkSortItem([f"Filter: {filt}"])
                    obj_item.addChild(filt_item)
                    filt_item.setExpanded(True)

                    for exp in sorted(by_object[obj][filt], key=lambda e: str(e).lower()):
                        exp_item = _BlinkSortItem([f"Exposure: {exp}"])
                        filt_item.addChild(exp_item)
                        exp_item.setExpanded(True)

                        for p in by_object[obj][filt][exp]:
                            leaf = _BlinkSortItem([os.path.basename(p), "", "", "", "", ""])
                            leaf.setData(0, Qt.ItemDataRole.UserRole, p)
                            exp_item.addChild(leaf)

        try:
            hdr = self.fileTree.header()
            self.fileTree.sortItems(hdr.sortIndicatorSection(),
                                    hdr.sortIndicatorOrder())
        except Exception:
            pass

        self.loading_label.setText(self.tr("Loaded {0} images.").format(len(self.loaded_images)))
        self.progress_bar.setValue(100)
        self.imagesChanged.emit(len(self.loaded_images))
        if self.metrics_window and self.metrics_window.isVisible():
            self.metrics_window.update_metrics(self.loaded_images, order=self._tree_order_indices())

        # Honor persisted Fit preference: auto-select the first leaf
        # (which triggers a deferred fit) so the user sees their saved
        # view mode without having to click a frame first.
        if getattr(self, "_auto_fit", False):
            QTimer.singleShot(0, self._auto_select_first_leaf_after_load)


    def _stream_scan(self, file_paths, *, append: bool):
        """Stream mode's open: read headers, build the tree, decode nothing.

        Entries are created with image_data=None. Everything the tree and the
        metric columns need before a frame is viewed comes from probe_header;
        a format with no cheap header lands under "Object: Unknown" until it
        is first opened, at which point its real header replaces the blank.
        """
        if not append:
            self.image_paths.clear()
            self.loaded_images.clear()
            self.fileTree.clear()
            if self._stream_cache is not None:
                self._stream_cache.clear()

        # The cache decodes on worker threads, so the same numba threading
        # guard the parallel PreLoad path uses applies here too.
        _blink_wait_for_numba_layer()
        _blink_apply_thread_safety()
        self._ensure_stream_cache()

        total = len(file_paths)
        self.progress_bar.setRange(0, max(1, total))
        self.progress_bar.setValue(0)
        QApplication.processEvents()
        step = max(1, total // 100)

        added = 0
        for i, path in enumerate(file_paths):
            if append and path in self.image_paths:
                continue
            hdr, wh = probe_header(path)
            self.image_paths.append(path)
            self.loaded_images.append({
                'file_path':       path,
                'image_data':      None,      # decoded on demand
                'header':          hdr or {},
                'probe_wh':        wh,        # (w, h) before load_scale
                'bit_depth':       None,
                'is_mono':         None,
                'flagged':         False,
                'orig_background': np.nan,
                'load_scale':      self._load_scale,
            })
            added += 1
            done = i + 1
            if done == total or (done % step) == 0:
                self.progress_bar.setValue(done)
                QApplication.processEvents()

        self.progress_bar.setValue(max(1, total))
        self._rebuild_tree_from_loaded()
        self.imagesChanged.emit(len(self.loaded_images))
        self.loading_label.setText(self.tr(
            "Streaming {0} frame{1} — frames load when you select them.").format(
                len(self.loaded_images), 's' if len(self.loaded_images) != 1 else ''))

        if self.metrics_window and self.metrics_window.isVisible():
            self.metrics_window.update_metrics(
                self.loaded_images, order=self._tree_order_indices())

        if getattr(self, "_auto_fit", False) or added:
            QTimer.singleShot(0, self._auto_select_first_leaf_after_load)

    def findTopLevelItemByName(self, name):
        """Find a top-level item in the tree by its name."""
        for index in range(self.fileTree.topLevelItemCount()):
            item = self.fileTree.topLevelItem(index)
            if item.text(0) == name:
                return item
        return None

    def findChildItemByName(self, parent, name):
        """Find a child item under a given parent by its name."""
        for index in range(parent.childCount()):
            child = parent.child(index)
            if child.text(0) == name:
                return child
        return None


    def _toggle_flag_on_item(self, item: QTreeWidgetItem, *, sync_metrics: bool = True):
        idx = self._leaf_index(item)
        if idx is None:
            return

        entry = self.loaded_images[idx]
        entry['flagged'] = not bool(entry.get('flagged', False))

        RED = Qt.GlobalColor.red
        normal_color = self.fileTree.palette().color(QPalette.ColorRole.WindowText)

        base = os.path.basename(self.image_paths[idx])

        if entry['flagged']:
            item.setText(0, f"⚠️ {base}")
            item.setForeground(0, QBrush(RED))
        else:
            item.setText(0, base)
            item.setForeground(0, QBrush(normal_color))

        # Keep UserRole correct (in case this was a legacy leaf)
        item.setData(0, Qt.ItemDataRole.UserRole, self.image_paths[idx])

        if sync_metrics:
            self._sync_metrics_flags()

    def flag_current_image(self):
        item = self.fileTree.currentItem()
        if not item:
            QMessageBox.warning(self, self.tr("No Selection"), self.tr("No image is currently selected to flag."))
            return
        self._toggle_flag_on_item(item)   # ← this now updates the metrics panel too
        self.next_item()


    def on_current_item_changed(self, current, previous):
        """Ensure the selected item is visible by scrolling to it."""
        if current:
            self.fileTree.scrollToItem(current, QAbstractItemView.ScrollHint.PositionAtCenter)

    def previous_item(self):
        """Select the previous item in the TreeWidget."""
        self._stream_dir = -1
        current_item = self.fileTree.currentItem()
        if current_item:
            all_items = self.get_all_leaf_items()
            current_index = all_items.index(current_item)
            if current_index > 0:
                previous_item = all_items[current_index - 1]
            else:
                previous_item = all_items[-1]  # Loop back to the last item
            self.fileTree.setCurrentItem(previous_item)
            #self.on_item_clicked(previous_item, 0)  # Update the preview

    def next_item(self):
        """Select the next item in the TreeWidget, looping back to the first item if at the end."""
        self._stream_dir = 1
        current_item = self.fileTree.currentItem()
        if current_item:
            # Get all leaf items
            all_items = self.get_all_leaf_items()

            # Check if the current item is in the leaf items
            try:
                current_index = all_items.index(current_item)
            except ValueError:
                # If the current item is not a leaf, move to the first leaf item
                print("Current item is not a leaf. Selecting the first leaf item.")
                if all_items:
                    next_item = all_items[0]
                    self.fileTree.setCurrentItem(next_item)
                    self.on_item_clicked(next_item, 0)
                return

            # Select the next leaf item or loop back to the first
            if current_index < len(all_items) - 1:
                next_item = all_items[current_index + 1]
            else:
                next_item = all_items[0]  # Loop back to the first item

            self.fileTree.setCurrentItem(next_item)
            #self.on_item_clicked(next_item, 0)  # Update the preview
        else:
            print("No current item selected.")

    def get_all_leaf_items(self):
        """Get a flat list of all leaf items (actual files) in the TreeWidget."""
        def recurse(parent):
            items = []
            for index in range(parent.childCount()):
                child = parent.child(index)
                if child.childCount() == 0:  # It's a leaf item
                    items.append(child)
                else:
                    items.extend(recurse(child))
            return items

        root = self.fileTree.invisibleRootItem()
        return recurse(root)

    def start_playback(self):
        """Start playing through the items in the TreeWidget."""
        if self.playback_timer.isActive():
            return

        leaves = self.get_all_leaf_items()
        if not leaves:
            QMessageBox.information(self, self.tr("No Images"), self.tr("Load some images first."))
            return

        # Ensure a current leaf item is selected
        cur = self.fileTree.currentItem()
        if cur is None or cur.childCount() > 0:
            self.fileTree.setCurrentItem(leaves[0])

        # Honor current fps setting
        self._apply_playback_interval()
        self.playback_timer.start()

    def stop_playback(self):
        """Stop playing through the items."""
        if self.playback_timer.isActive():
            self.playback_timer.stop()


    def openFileDialog(self):
        """Allow users to select multiple images and add them to the existing list."""
        file_paths, _ = QFileDialog.getOpenFileNames(
            self,
            self.tr("Open Images"),
            self._last_folder(),
            self.tr("Images (*.png *.tif *.tiff *.fits *.fit *.fts *.fits.gz *.fit.gz *.fts.gz *.fz *.xisf *.cr2 *.cr3 *.nef *.arw *.dng *.raf *.orf *.rw2 *.pef *.jpg *.jpeg);;All Files (*)")
        )
        if file_paths:
            self._save_last_folder(file_paths[0])        
        # Filter out already loaded images to prevent duplicates
        new_file_paths = [path for path in file_paths if path not in self.image_paths]

        if new_file_paths:
            self.loadImages(new_file_paths)
        else:
            QMessageBox.information(self, self.tr("No New Images"), self.tr("No new images were selected or all selected images are already loaded."))


    def debayer_fits(self, image_data, bayer_pattern):
        """Debayer a FITS image using a basic Bayer pattern (2x2)."""
        if bayer_pattern == 'RGGB':
            # RGGB Bayer pattern
            r = image_data[::2, ::2]  # Red
            g1 = image_data[::2, 1::2]  # Green 1
            g2 = image_data[1::2, ::2]  # Green 2
            b = image_data[1::2, 1::2]  # Blue

            # Average green channels
            g = (g1 + g2) / 2
            return np.stack([r, g, b], axis=-1)

        elif bayer_pattern == 'BGGR':
            # BGGR Bayer pattern
            b = image_data[::2, ::2]  # Blue
            g1 = image_data[::2, 1::2]  # Green 1
            g2 = image_data[1::2, ::2]  # Green 2
            r = image_data[1::2, 1::2]  # Red

            # Average green channels
            g = (g1 + g2) / 2
            return np.stack([r, g, b], axis=-1)

        elif bayer_pattern == 'GRBG':
            # GRBG Bayer pattern
            g1 = image_data[::2, ::2]  # Green 1
            r = image_data[::2, 1::2]  # Red
            b = image_data[1::2, ::2]  # Blue
            g2 = image_data[1::2, 1::2]  # Green 2

            # Average green channels
            g = (g1 + g2) / 2
            return np.stack([r, g, b], axis=-1)

        elif bayer_pattern == 'GBRG':
            # GBRG Bayer pattern
            g1 = image_data[::2, ::2]  # Green 1
            b = image_data[::2, 1::2]  # Blue
            r = image_data[1::2, ::2]  # Red
            g2 = image_data[1::2, 1::2]  # Green 2

            # Average green channels
            g = (g1 + g2) / 2
            return np.stack([r, g, b], axis=-1)

        else:
            raise ValueError(self.tr("Unsupported Bayer pattern: {0}").format(bayer_pattern))

    def remove_item_from_tree(self, file_path):
        """Remove a specific item from the tree view based on file path."""
        file_name = os.path.basename(file_path)
        root = self.fileTree.invisibleRootItem()

        def recurse(parent):
            for index in range(parent.childCount()):
                child = parent.child(index)
                if child.text(0).endswith(file_name):
                    parent.removeChild(child)
                    return True
                if recurse(child):
                    return True
            return False

        recurse(root)

    def add_item_to_tree(self, file_path):
        """Add a specific item to the tree view based on file path."""
        # Extract metadata for grouping
        image_entry = next((img for img in self.loaded_images if img['file_path'] == file_path), None)
        if not image_entry:
            return

        header = image_entry['header']
        object_name = header.get('OBJECT', 'Unknown') if header else 'Unknown'
        filter_name = header.get('FILTER', 'Unknown') if header else 'Unknown'
        exposure_time = _blink_exposure_label(header) if header else 'Unknown'

        # Group images by filter and exposure time
        group_key = (object_name, filter_name, exposure_time)

        with self._tree_bulk_update():
            # Find or create the object item
            object_item = self.findTopLevelItemByName(f"Object: {object_name}")
            if not object_item:
                object_item = _BlinkSortItem([f"Object: {object_name}"])
                self.fileTree.addTopLevelItem(object_item)
                object_item.setExpanded(True)

            # Find or create the filter item
            filter_item = self.findChildItemByName(object_item, f"Filter: {filter_name}")
            if not filter_item:
                filter_item = _BlinkSortItem([f"Filter: {filter_name}"])
                object_item.addChild(filter_item)
                filter_item.setExpanded(True)

            # Find or create the exposure item
            exposure_item = self.findChildItemByName(filter_item, f"Exposure: {exposure_time}")
            if not exposure_item:
                exposure_item = _BlinkSortItem([f"Exposure: {exposure_time}"])
                filter_item.addChild(exposure_item)
                exposure_item.setExpanded(True)

            # Add the file item
            file_name = os.path.basename(file_path)
            item = _BlinkSortItem([file_name, "", "", "", "", ""])
            item.setData(0, Qt.ItemDataRole.UserRole, file_path)
            exposure_item.addChild(item)

    def _tree_order_indices(self) -> list[int]:
        """Return the indices of loaded_images in the exact order the Tree shows."""
        order = []
        for leaf in self.get_all_leaf_items():
            path = leaf.data(0, Qt.ItemDataRole.UserRole)
            if not path:
                # fallback by basename if old items exist
                name = leaf.text(0).lstrip("⚠️ ").strip()
                path = next((p for p in self.image_paths if os.path.basename(p) == name), None)
            if path and path in self.image_paths:
                order.append(self.image_paths.index(path))
        return order

    def debayer_raw(self, raw_image_data, bayer_pattern="RGGB"):
        """Debayer a RAW image based on the Bayer pattern, ensuring even dimensions."""
        H, W = raw_image_data.shape
        # Crop to even dimensions if necessary
        if H % 2 != 0:
            raw_image_data = raw_image_data[:H-1, :]
        if W % 2 != 0:
            raw_image_data = raw_image_data[:, :W-1]
        
        if bayer_pattern == 'RGGB':
            r = raw_image_data[::2, ::2]      # Red
            g1 = raw_image_data[::2, 1::2]     # Green 1
            g2 = raw_image_data[1::2, ::2]     # Green 2
            b = raw_image_data[1::2, 1::2]     # Blue

            # Average green channels
            g = (g1 + g2) / 2
            return np.stack([r, g, b], axis=-1)
        elif bayer_pattern == 'BGGR':
            b = raw_image_data[::2, ::2]      # Blue
            g1 = raw_image_data[::2, 1::2]     # Green 1
            g2 = raw_image_data[1::2, ::2]     # Green 2
            r = raw_image_data[1::2, 1::2]     # Red

            g = (g1 + g2) / 2
            return np.stack([r, g, b], axis=-1)
        elif bayer_pattern == 'GRBG':
            g1 = raw_image_data[::2, ::2]     # Green 1
            r = raw_image_data[::2, 1::2]      # Red
            b = raw_image_data[1::2, ::2]      # Blue
            g2 = raw_image_data[1::2, 1::2]     # Green 2

            g = (g1 + g2) / 2
            return np.stack([r, g, b], axis=-1)
        elif bayer_pattern == 'GBRG':
            g1 = raw_image_data[::2, ::2]     # Green 1
            b = raw_image_data[::2, 1::2]      # Blue
            r = raw_image_data[1::2, ::2]      # Red
            g2 = raw_image_data[1::2, 1::2]     # Green 2

            g = (g1 + g2) / 2
            return np.stack([r, g, b], axis=-1)
        else:
            raise ValueError(self.tr("Unsupported Bayer pattern: {0}").format(bayer_pattern))

    

    def on_item_clicked(self, item, column):
        self.fileTree.setFocus()
        if not item or item.childCount() > 0:
            return

        file_path = self._leaf_path(item)
        if not file_path:
            return

        self._capture_view_center_norm()

        try:
            idx = self.image_paths.index(file_path)
        except ValueError:
            return

        entry = self.loaded_images[idx]

        # Stream mode decodes here, on demand. Say so before blocking: on a
        # big frame this is a visible pause, and silence reads as a hang.
        stored = entry.get('image_data')
        if stored is None and self._stream_mode:
            self.loading_label.setText(self.tr("Loading {0}…").format(
                os.path.basename(file_path)))
            QApplication.processEvents()
            stored = self._pixels_for(idx)
            self._update_loaded_count_label(len(self.loaded_images))

        # ✅ single source of truth (handles aggressive + mono + color)
        disp8 = self._make_display_frame(entry, stored=stored)
        if disp8 is None:
            self.preview_label.setText(self.tr("Could not load this frame."))
            self.current_pixmap = None
            return

        qimage = self.convert_to_qimage(disp8)
        self.current_pixmap = QPixmap.fromImage(qimage)
        # If the user asked for Fit (persisted) we recompute fit for this
        # image — zoom levels don't carry sensibly between images of
        # different pixel sizes, so fit-on-switch is what people usually
        # want when they've clicked Fit once.
        #
        # On the FIRST image after Blink reopens with a persisted Fit
        # preference, the scroll area viewport may not have reached its
        # final restored-geometry size yet, so an inline fit would snap
        # to the wrong ratio. We fit immediately (right ratio in the
        # steady state) AND again on the next event-loop tick (fixes
        # the first-open case where the viewport only settles after
        # this call returns). The second fit is a no-op when the
        # viewport didn't change.
        if getattr(self, "_auto_fit", False):
            self.fit_to_preview(_from_auto=True)
            QTimer.singleShot(0, lambda: self.fit_to_preview(_from_auto=True)
                              if self.current_pixmap else None)
        else:
            self.apply_zoom()


    def _capture_view_center_norm(self):
        """Remember the current viewport center as a fraction of the content size."""
        sa = self.scroll_area
        vp = sa.viewport()
        content_w = max(1, self.preview_label.width())
        content_h = max(1, self.preview_label.height())
        if content_w <= 1 or content_h <= 1:
            return
        hbar = sa.horizontalScrollBar()
        vbar = sa.verticalScrollBar()
        cx = hbar.value() + vp.width()  / 2.0
        cy = vbar.value() + vp.height() / 2.0
        self._view_center_norm = (cx / content_w, cy / content_h)

    def _restore_view_center_norm(self):
        """Restore the viewport center captured earlier (if any)."""
        if not self._view_center_norm:
            return
        sa = self.scroll_area
        vp = sa.viewport()
        content_w = max(1, self.preview_label.width())
        content_h = max(1, self.preview_label.height())
        cx = self._view_center_norm[0] * content_w
        cy = self._view_center_norm[1] * content_h
        hbar = sa.horizontalScrollBar()
        vbar = sa.verticalScrollBar()
        h_target = int(round(cx - vp.width()  / 2.0))
        v_target = int(round(cy - vp.height() / 2.0))
        h_target = max(hbar.minimum(), min(hbar.maximum(), h_target))
        v_target = max(vbar.minimum(), min(vbar.maximum(), v_target))
        # Set after layout settles to avoid fighting size changes
        QTimer.singleShot(0, lambda: (hbar.setValue(h_target), vbar.setValue(v_target)))

    def apply_zoom(self):
        if not self.current_pixmap:
            return

        had_content = (self.preview_label.pixmap() is not None) and (self.preview_label.width() > 0)
        if had_content:
            self._capture_view_center_norm()
        else:
            self._view_center_norm = (0.5, 0.5)

        base_w = self.current_pixmap.width()
        base_h = self.current_pixmap.height()
        scaled_w = max(1, int(round(base_w * self.zoom_level)))
        scaled_h = max(1, int(round(base_h * self.zoom_level)))

        scaled = self.current_pixmap.scaled(
            scaled_w, scaled_h,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self.preview_label.setPixmap(scaled)
        self.preview_label.resize(scaled.size())
        self._restore_view_center_norm()

        # Update zoom panel to viewport center after layout settles
        QTimer.singleShot(0, self._update_zoom_panel_to_viewport_center)

    def wheelEvent(self, event: QWheelEvent):
        # Only zoom if the cursor is genuinely over the preview scroll area's
        # viewport. Wheel events that bubble up from the file tree (at its
        # scroll boundary), buttons, spinboxes, or any other left-column widget
        # must NOT zoom the preview.
        #
        # We must use GLOBAL coordinates mapped into the viewport. Comparing
        # event.position() against self.scroll_area.geometry() is wrong: the
        # scroll area lives several widgets deep (preview_widget → right_splitter
        # → splitter → self), so its geometry() is in preview_widget's coordinate
        # space, not BlinkTab's. The two never line up correctly, which is why the
        # previous guard let left-column wheel events fall through to zoom.
        try:
            gp = event.globalPosition().toPoint()
        except AttributeError:
            gp = event.globalPos()

        vp = getattr(self, "scroll_area", None)
        vp = vp.viewport() if vp is not None else None
        if vp is not None and vp.rect().contains(vp.mapFromGlobal(gp)):
            self._wheel_zoom(event)
            event.accept()
        else:
            event.ignore()


    def _set_auto_fit(self, on: bool):
        """Set the auto-fit-on-switch preference and persist it."""
        self._auto_fit = bool(on)
        try:
            QSettings().setValue("blink/auto_fit", self._auto_fit)
        except Exception:
            pass

    def _auto_select_first_leaf_after_load(self):
        """After images finish loading, auto-select the first leaf if nothing
        is current. Needed because Blink doesn't preview anything until the
        user clicks a leaf, so a persisted Fit preference has no image to
        apply to. Calling on_item_clicked (via setCurrentItem's signal path)
        gives us the first pixmap, and that method's deferred fit then
        settles into the correct ratio against the final viewport size."""
        try:
            cur = self.fileTree.currentItem()
            if cur is not None and cur.childCount() == 0:
                return  # user already has something selected
            leaves = self.get_all_leaf_items()
            if not leaves:
                return
            first = leaves[0]
            self.fileTree.setCurrentItem(first)
            # setCurrentItem routes through _on_current_item_changed_safe
            # which uses a tiny timer, so defer our own click too to let
            # it land, and defer the whole chain so the viewport has its
            # final size when fit_to_preview runs.
            QTimer.singleShot(0, lambda: self.on_item_clicked(first, 0))
        except Exception:
            pass

    def zoom_in(self):
        """Increase the zoom level and refresh the image."""
        self.zoom_level = min(self.zoom_level * 1.2, 3.0)  # Cap at 3x
        # User took manual control — stop auto-fitting on image switch.
        self._set_auto_fit(False)
        self.apply_zoom()


    def zoom_out(self):
        """Decrease the zoom level and refresh the image."""
        self.zoom_level = max(self.zoom_level / 1.2, 0.05)  # Cap at 0.2x
        # User took manual control — stop auto-fitting on image switch.
        self._set_auto_fit(False)
        self.apply_zoom()


    def fit_to_preview(self, _from_auto: bool = False):
        """Adjust the zoom level so the image fits within the QScrollArea viewport.
        When the user clicks the Fit button we also turn on auto-fit so new
        images stay fit-sized on switch. Internal auto-fit callers pass
        _from_auto=True so we don't flip the pref on ourselves."""
        if self.current_pixmap:
            # Get the size of the QScrollArea's viewport
            viewport_size = self.scroll_area.viewport().size()
            pixmap_size = self.current_pixmap.size()

            # Calculate the zoom level required to fit the pixmap in the QScrollArea viewport
            width_ratio = viewport_size.width() / pixmap_size.width()
            height_ratio = viewport_size.height() / pixmap_size.height()
            self.zoom_level = min(width_ratio, height_ratio)

            # Apply the zoom level
            self.apply_zoom()
            # User click on Fit means "keep fitting new images too" —
            # persist it so it sticks across sessions.
            if not _from_auto:
                self._set_auto_fit(True)
        else:
            print("No image loaded. Cannot fit to preview.")
            QMessageBox.warning(self, self.tr("Warning"), self.tr("No image loaded. Cannot fit to preview."))

    def _is_leaf(self, item: Optional[QTreeWidgetItem]) -> bool:
        return bool(item and item.childCount() == 0)

    def on_right_click(self, pos):
        item = self.fileTree.itemAt(pos)
        if not self._is_leaf(item):
            # Optional: expand/collapse-only menu, or just ignore
            return

        menu = QMenu(self)

        push_action = QAction(self.tr("Open in Document Window"), self)
        push_action.triggered.connect(lambda: self.push_to_docs(item))
        menu.addAction(push_action)

        rename_action = QAction(self.tr("Rename"), self)
        rename_action.triggered.connect(lambda: self.rename_item(item))
        menu.addAction(rename_action)

        # 🔹 NEW: batch rename selected
        batch_rename_action = QAction(self.tr("Batch Rename Selected…"), self)
        batch_rename_action.triggered.connect(self.batch_rename_items)
        menu.addAction(batch_rename_action)

        move_action = QAction(self.tr("Move Selected Items"), self)
        move_action.triggered.connect(self.move_items)
        menu.addAction(move_action)

        delete_action = QAction(self.tr("Delete Selected Items"), self)
        delete_action.triggered.connect(self.delete_items)
        menu.addAction(delete_action)

        menu.addSeparator()

        batch_delete_action = QAction(self.tr("Delete All Flagged Images"), self)
        batch_delete_action.triggered.connect(self.batch_delete_flagged_images)
        menu.addAction(batch_delete_action)

        batch_move_action = QAction(self.tr("Move All Flagged Images"), self)
        batch_move_action.triggered.connect(self.batch_move_flagged_images)
        menu.addAction(batch_move_action)

        # 🔹 NEW: rename all flagged images
        rename_flagged_action = QAction(self.tr("Rename Flagged Images…"), self)
        rename_flagged_action.triggered.connect(self.rename_flagged_images)
        menu.addAction(rename_flagged_action)
        menu.addSeparator()

        flag_sat_action = QAction(self.tr("Flag All Satellite Detections"), self)
        flag_sat_action.triggered.connect(self._flag_all_satellite_detections)
        # grey out if no sat detection has been run yet
        any_sat_run = any(e.get("sat_detected") is not None for e in self.loaded_images)
        flag_sat_action.setEnabled(any_sat_run)
        menu.addAction(flag_sat_action)
        menu.addSeparator()

        send_lights_act = QAction(self.tr("Send to Stacking → Lights"), self)
        send_lights_act.triggered.connect(self._send_to_stacking_lights)
        menu.addAction(send_lights_act)

        send_integ_act = QAction(self.tr("Send to Stacking → Integration"), self)
        send_integ_act.triggered.connect(self._send_to_stacking_integration)
        menu.addAction(send_integ_act)

        menu.addSeparator()

        remove_action = QAction(self.tr("Remove Selected from List"), self)
        remove_action.triggered.connect(self.remove_items_from_list)
        menu.addAction(remove_action)        
        
        menu.exec(self.fileTree.mapToGlobal(pos))

    def _flag_all_satellite_detections(self):
        """Flag all images that have a confirmed satellite trail detection."""
        flagged = 0
        RED = Qt.GlobalColor.red
        normal = self.fileTree.palette().color(QPalette.ColorRole.WindowText)

        for idx, entry in enumerate(self.loaded_images):
            if entry.get("sat_detected") is not True:
                continue
            if entry.get("flagged"):
                continue  # already flagged, skip

            entry["flagged"] = True
            flagged += 1

            item = self.get_tree_item_for_index(idx)
            if item:
                base = os.path.basename(self.image_paths[idx])
                item.setText(0, f"⚠️ {base}")
                item.setForeground(0, QBrush(RED))
                item.setData(0, Qt.ItemDataRole.UserRole, self.image_paths[idx])

        if flagged == 0:
            QMessageBox.information(self, self.tr("Flag Satellite Detections"),
                self.tr("No unflagged satellite detections found."))
            return

        self._sync_metrics_flags()
        QMessageBox.information(self, self.tr("Flag Satellite Detections"),
            self.tr("Flagged {0} image{1} with satellite trails.").format(
                flagged, "s" if flagged != 1 else ""))

    def remove_items_from_list(self):
        """Remove selected images from the blink session without touching files on disk."""
        selected_items = [it for it in self.fileTree.selectedItems() if it and it.childCount() == 0]
        if not selected_items:
            QMessageBox.warning(self, self.tr("Warning"), self.tr("No individual image items selected for removal."))
            return

        # Snapshot indices first before any mutation
        triplets = []
        for it in selected_items:
            p = self._leaf_path(it)
            if not p:
                continue
            try:
                idx = self.image_paths.index(p)
            except ValueError:
                continue
            triplets.append((idx, p, it))

        if not triplets:
            return

        removed_indices = []
        for idx, path, it in triplets:
            removed_indices.append(idx)
            # Remove leaf from tree immediately
            parent = it.parent() or self.fileTree.invisibleRootItem()
            parent.removeChild(it)

        # Purge arrays descending so indices stay valid
        for idx in sorted(set(removed_indices), reverse=True):
            if 0 <= idx < len(self.image_paths):
                del self.image_paths[idx]
            if 0 <= idx < len(self.loaded_images):
                del self.loaded_images[idx]

        # Clear preview if it was showing one of the removed images
        self.preview_label.clear()
        self.preview_label.setText(self.tr("No image selected."))
        self.current_pixmap = None

        self._after_list_changed(sorted(set(removed_indices)))

    def push_to_docs(self, item: QTreeWidgetItem):
        """
        Push the currently selected blink leaf image into DocManager as a new document,
        preserving all original metadata (original_header, meta, bit_depth, is_mono, etc.)
        and swapping ONLY the numpy image array.
        """
        if not item or item.childCount() > 0:
            return

        # --- Resolve full path safely (UserRole-first) ---
        file_path = item.data(0, Qt.ItemDataRole.UserRole)
        if not file_path or not isinstance(file_path, str):
            # legacy fallback: try to map by displayed name
            file_name = item.text(0).lstrip("⚠️ ").strip()
            file_path = next((p for p in self.image_paths if os.path.basename(p) == file_name), None)

        if not file_path:
            return

        try:
            idx = self.image_paths.index(file_path)
        except ValueError:
            return

        entry = self.loaded_images[idx]

        # --- Find main window + doc manager ---
        mw = self._main_window()
        dm = self.doc_manager or (getattr(mw, "docman", None) if mw else None)
        if not mw or not dm:
            QMessageBox.warning(self, self.tr("Document Manager"), self.tr("Main window or DocManager not available."))
            return

        # --- Build the swapped payload (image replaced, metadata preserved) ---
        # Whatever you're storing as entry['image_data'] (uint16/float/etc), normalize to float01 for display pipeline.
        # If your DocManager expects native dtype instead, swap _as_float01 for your native image.
        _px = self._pixels_for(idx, prefetch=False)
        if _px is None:
            QMessageBox.warning(self, self.tr("Document Manager"),
                                self.tr("Could not load the pixels for this frame."))
            return
        np_image_f01 = self._as_float01(_px).astype(np.float32, copy=False)

        # Preserve your full load_image return structure as much as possible:
        # load_image returns: image, original_header, bit_depth, is_mono, meta
        original_header = entry.get("original_header", entry.get("header", None))
        bit_depth       = entry.get("bit_depth", None)
        is_mono         = entry.get("is_mono", None)
        meta            = entry.get("meta", {})

        # Keep meta dict style your app uses; add source tag without clobbering
        if isinstance(meta, dict):
            meta = dict(meta)
            meta.setdefault("source", "BlinkComparatorPro")
            meta.setdefault("file_path", file_path)

        # This is the "all the other stuff" you wanted preserved
        payload = {
            "file_path": file_path,
            "original_header": original_header,
            "bit_depth": bit_depth,
            "is_mono": is_mono,
            "meta": meta,
            "source": "BlinkComparatorPro",
        }

        title = os.path.basename(file_path)

        # --- Create document using whatever DocManager API exists ---
        doc = None
        try:
            # Preferred: if you have a method that mirrors open_file/load_image shape
            if hasattr(dm, "open_from_load_image"):
                # (image, original_header, bit_depth, is_mono, meta)
                doc = dm.open_from_load_image(np_image_f01, original_header, bit_depth, is_mono, meta, title=title)

            elif hasattr(dm, "open_array"):
                # Some of your code expects metadata in doc.metadata; pass payload whole
                doc = dm.open_array(np_image_f01, metadata=payload, title=title)

            elif hasattr(dm, "open_numpy"):
                doc = dm.open_numpy(np_image_f01, metadata=payload, title=title)

            elif hasattr(dm, "create_document"):
                # Try both signatures
                try:
                    doc = dm.create_document(image=np_image_f01, metadata=payload, name=title)
                except TypeError:
                    doc = dm.create_document(np_image_f01, payload, title)

            else:
                raise AttributeError("DocManager lacks a known creation method")

        except Exception as e:
            QMessageBox.critical(self, self.tr("Doc Manager"), self.tr("Failed to create document:\n{0}").format(e))
            return

        if doc is None:
            QMessageBox.critical(self, self.tr("Doc Manager"), self.tr("DocManager returned no document."))
            return

        # --- Hand off to DocManager flow (DocManager should trigger MDI + window creation) ---
        try:
            # If your architecture already auto-spawns windows on documentAdded,
            # you should NOT call mw._spawn_subwindow_for(doc) here.
            if hasattr(dm, "add_document"):
                dm.add_document(doc)
            elif hasattr(dm, "register_document"):
                dm.register_document(doc)
            else:
                # If open_array/open_numpy already registers the doc internally, do nothing.
                pass

            # If you *must* spawn manually (older path), keep as fallback
            if hasattr(mw, "_spawn_subwindow_for"):
                mw._spawn_subwindow_for(doc)

            if hasattr(mw, "_log"):
                mw._log(f"Blink → opened '{title}' as new document")

        except Exception as e:
            QMessageBox.critical(self, self.tr("UI"), self.tr("Failed to open subwindow:\n{0}").format(e))



    # optional shim to keep any old calls working
    def push_image_to_manager(self, item):
        self.push_to_docs(item)



    def rename_item(self, item: QTreeWidgetItem):
        if not item or item.childCount() > 0:
            return

        idx = self._leaf_index(item)
        if idx is None:
            return

        old_path = self.image_paths[idx]
        old_base = os.path.basename(old_path)

        new_name, ok = QInputDialog.getText(
            self,
            self.tr("Rename Image"),
            self.tr("Enter new name:"),
            text=old_base
        )
        if not ok:
            return

        new_name = (new_name or "").strip()
        if not new_name:
            return

        new_path = os.path.join(os.path.dirname(old_path), new_name)

        # Avoid overwrite
        if os.path.exists(new_path):
            QMessageBox.critical(self, self.tr("Error"), self.tr("A file with that name already exists."))
            return

        try:
            os.rename(old_path, new_path)
        except Exception as e:
            QMessageBox.critical(self, self.tr("Error"), self.tr("Failed to rename the file: {0}").format(e))
            return

        # Update internal structures
        if self._stream_cache is not None:
            self._stream_cache.invalidate(old_path)
        self.image_paths[idx] = new_path
        self.loaded_images[idx]['file_path'] = new_path

        # Update the leaf item
        flagged = bool(self.loaded_images[idx].get("flagged", False))
        self._set_leaf_display(item, base_name=new_name, flagged=flagged, full_path=new_path)

        # Rebuild so natural sort stays correct and groups update
        self._after_list_changed()
        self._sync_metrics_flags()


    def rename_flagged_images(self):
        """Prefix all *flagged* images on disk and in the tree."""
        # Collect indices of flagged frames
        flagged_indices = [i for i, e in enumerate(self.loaded_images)
                           if e.get("flagged", False)]

        if not flagged_indices:
            QMessageBox.information(
                self,
                self.tr("Rename Flagged Images"),
                self.tr("There are no flagged images to rename.")
            )
            return

        # Small dialog like in your mockup: just a prefix field
        dlg = QDialog(self)
        dlg.setWindowTitle(self.tr("Rename flagged images"))
        layout = QVBoxLayout(dlg)

        layout.addWidget(QLabel(self.tr("Prefix to add to flagged image filenames:"), dlg))

        prefix_edit = QLineEdit(dlg)
        prefix_edit.setText("Bad_")  # sensible default
        layout.addWidget(prefix_edit)

        btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=dlg,
        )
        btn_box.accepted.connect(dlg.accept)
        btn_box.rejected.connect(dlg.reject)
        layout.addWidget(btn_box)

        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        prefix = prefix_edit.text()
        if prefix is None:
            prefix = ""
        prefix = prefix.strip()
        if not prefix:
            # Allow empty but warn – otherwise user may be confused
            ret = QMessageBox.question(
                self,
                self.tr("No Prefix"),
                self.tr("No prefix entered. This will not change any filenames.\n\n"
                "Continue anyway?"),
                QMessageBox.StandardButton.Yes | QDialogButtonBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if ret != QMessageBox.StandardButton.Yes:
                return

        successes = 0
        failures = []

        for idx in flagged_indices:
            old_path = self.image_paths[idx]
            directory, base = os.path.split(old_path)

            new_base = f"{prefix}{base}"
            new_path = os.path.join(directory, new_base)

            # Skip if unchanged
            if new_path == old_path:
                continue

            # Avoid overwriting an existing file
            if os.path.exists(new_path):
                failures.append((old_path, "target already exists"))
                continue

            try:
                os.rename(old_path, new_path)
            except Exception as e:
                failures.append((old_path, str(e)))
                continue

            # Update internal paths
            if self._stream_cache is not None:
                self._stream_cache.invalidate(old_path)
            self.image_paths[idx] = new_path
            self.loaded_images[idx]["file_path"] = new_path

            # Update tree item text + UserRole data
            item = self.get_tree_item_for_index(idx)
            if item is not None:
                # preserve ⚠️ prefix
                disp_name = new_base
                if self.loaded_images[idx].get("flagged", False):
                    disp_name = f"⚠️ {disp_name}"
                item.setText(0, disp_name)
                item.setData(0, Qt.ItemDataRole.UserRole, new_path)

            successes += 1

        # Rebuild tree so new names are naturally re-sorted, keep flags
        self._after_list_changed()
        # Also sync the metrics panel flags/colors
        self._sync_metrics_flags()

        msg = self.tr("Renamed {0} flagged image{1}.").format(successes, 's' if successes != 1 else '')
        if failures:
            msg += self.tr("\n\n{0} file(s) could not be renamed:").format(len(failures))
            for old, err in failures[:10]:  # don’t spam too hard
                msg += f"\n• {os.path.basename(old)} – {err}"

        QMessageBox.information(self, self.tr("Rename Flagged Images"), msg)


    def batch_rename_items(self):
        """Batch rename selected leaf items by adding a prefix and/or suffix."""
        selected_items = [it for it in self.fileTree.selectedItems() if it and it.childCount() == 0]
        if not selected_items:
            QMessageBox.warning(self, self.tr("Warning"), self.tr("No individual image items selected for renaming."))
            return

        dialog = QDialog(self)
        dialog.setWindowTitle(self.tr("Batch Rename"))
        dialog_layout = QVBoxLayout(dialog)

        dialog_layout.addWidget(QLabel(self.tr("Enter a prefix or suffix to rename selected files:"), dialog))

        form_layout = QHBoxLayout()
        prefix_field = QLineEdit(dialog)
        prefix_field.setPlaceholderText(self.tr("Prefix"))
        form_layout.addWidget(prefix_field)

        mid_label = QLabel(self.tr("filename"), dialog)
        mid_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        form_layout.addWidget(mid_label)

        suffix_field = QLineEdit(dialog)
        suffix_field.setPlaceholderText(self.tr("Suffix"))
        form_layout.addWidget(suffix_field)
        dialog_layout.addLayout(form_layout)

        btns = QHBoxLayout()
        ok_button = QPushButton(self.tr("OK"), dialog)
        cancel_button = QPushButton(self.tr("Cancel"), dialog)
        ok_button.clicked.connect(dialog.accept)
        cancel_button.clicked.connect(dialog.reject)
        btns.addWidget(ok_button)
        btns.addWidget(cancel_button)
        dialog_layout.addLayout(btns)

        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        prefix = (prefix_field.text() or "").strip()
        suffix = (suffix_field.text() or "").strip()

        if not prefix and not suffix:
            QMessageBox.information(self, self.tr("Batch Rename"), self.tr("No prefix or suffix entered. Nothing to do."))
            return

        renamed = 0
        failures = []

        # Work on indices so we can update lists safely
        indices = []
        for it in selected_items:
            idx = self._leaf_index(it)
            if idx is not None:
                indices.append((idx, it))

        for idx, it in indices:
            old_path = self.image_paths[idx]
            directory, base = os.path.split(old_path)

            new_base = f"{prefix}{base}{suffix}"
            new_path = os.path.join(directory, new_base)

            if new_path == old_path:
                continue

            if os.path.exists(new_path):
                failures.append((old_path, self.tr("target already exists")))
                continue

            try:
                os.rename(old_path, new_path)
            except Exception as e:
                failures.append((old_path, str(e)))
                continue

            # Update internal lists
            if self._stream_cache is not None:
                self._stream_cache.invalidate(old_path)
            self.image_paths[idx] = new_path
            self.loaded_images[idx]["file_path"] = new_path

            # Update leaf item
            flagged = bool(self.loaded_images[idx].get("flagged", False))
            self._set_leaf_display(it, base_name=new_base, flagged=flagged, full_path=new_path)

            renamed += 1

        # Rebuild so group headers + natural order stay correct
        self._after_list_changed()
        self._sync_metrics_flags()

        msg = self.tr("Batch renamed {0} file{1}.").format(renamed, "s" if renamed != 1 else "")
        if failures:
            msg += self.tr("\n\n{0} file(s) failed:").format(len(failures))
            for old, err in failures[:10]:
                msg += f"\n• {os.path.basename(old)} – {err}"
        QMessageBox.information(self, self.tr("Batch Rename"), msg)


    def batch_delete_flagged_images(self):
        """Delete all flagged images."""
        flagged_images = [img for img in self.loaded_images if img['flagged']]
        
        if not flagged_images:
            QMessageBox.information(self, self.tr("No Flagged Images"), self.tr("There are no flagged images to delete."))
            return

        confirmation = QMessageBox.question(
            self,
            self.tr("Confirm Batch Deletion"),
            self.tr("Are you sure you want to permanently delete {0} flagged images? This action is irreversible.").format(len(flagged_images)),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if confirmation == QMessageBox.StandardButton.Yes:
            removed_indices = []
            # snapshot the indices before mutation
            for img in flagged_images:
                try:
                    removed_indices.append(self.image_paths.index(img['file_path']))
                except ValueError:
                    pass

            # perform deletions
            for img in flagged_images:
                file_path = img['file_path']
                try:
                    os.remove(file_path)
                except Exception as e:
                    ...
                # remove from structures
                if file_path in self.image_paths:
                    self.image_paths.remove(file_path)
                if img in self.loaded_images:
                    self.loaded_images.remove(img)
                self.remove_item_from_tree(file_path)

            QMessageBox.information(self, self.tr("Batch Deletion"), self.tr("Deleted {0} flagged images.").format(len(removed_indices)))

            # 🔁 refresh tree + metrics (no recompute)
            self._after_list_changed(removed_indices)

    def batch_move_flagged_images(self):
        """Move all flagged images to a selected directory AND remove them from the blink list."""
        flagged_indices = [i for i, e in enumerate(self.loaded_images) if e.get("flagged", False)]
        if not flagged_indices:
            QMessageBox.information(self, self.tr("No Flagged Images"), self.tr("There are no flagged images to move."))
            return

        destination_dir = QFileDialog.getExistingDirectory(self, self.tr("Select Destination Folder"), "")
        if not destination_dir:
            return

        failures = []

        # Move first (use current paths from indices)
        for i in flagged_indices:
            src_path = self.image_paths[i]
            dest_path = os.path.join(destination_dir, os.path.basename(src_path))
            try:
                os.rename(src_path, dest_path)
            except Exception as e:
                failures.append((src_path, str(e)))

        # Remove from lists ONLY if move succeeded
        # Build a set of indices to remove: those that did NOT fail
        failed_src = {p for p, _ in failures}
        removed_indices = [i for i in flagged_indices if self.image_paths[i] not in failed_src]

        removed_indices = sorted(set(removed_indices), reverse=True)
        for idx in removed_indices:
            if 0 <= idx < len(self.image_paths):
                del self.image_paths[idx]
            if 0 <= idx < len(self.loaded_images):
                del self.loaded_images[idx]

        if removed_indices:
            self._after_list_changed(removed_indices)

        if failures:
            msg = self.tr("Moved {0} flagged file(s). {1} failed:").format(len(removed_indices), len(failures))
            for p, err in failures[:10]:
                msg += f"\n• {os.path.basename(p)} – {err}"
            QMessageBox.warning(self, self.tr("Batch Move"), msg)
        else:
            QMessageBox.information(self, self.tr("Batch Move"), self.tr("Moved and removed {0} flagged image(s).").format(len(removed_indices)))


    def move_items(self):
        """Move selected leaf images to a selected directory AND remove them from the blink list."""
        selected_items = [it for it in self.fileTree.selectedItems() if it and it.childCount() == 0]
        if not selected_items:
            QMessageBox.warning(self, self.tr("Warning"), self.tr("No individual image items selected for moving."))
            return

        new_dir = QFileDialog.getExistingDirectory(self, self.tr("Select Destination Folder"), "")
        if not new_dir:
            return

        removed_indices = []
        failures = []

        # Collect (idx, old_path, item) first to avoid index drift
        triplets = []
        for it in selected_items:
            p = self._leaf_path(it)
            if not p:
                continue
            try:
                idx = self.image_paths.index(p)
            except ValueError:
                continue
            triplets.append((idx, p, it))

        for idx, old_path, it in triplets:
            base = os.path.basename(old_path)
            new_path = os.path.join(new_dir, base)
            try:
                os.rename(old_path, new_path)
            except Exception as e:
                failures.append((old_path, str(e)))
                continue

            removed_indices.append(idx)

            # remove leaf from tree immediately (optional; _after_list_changed will rebuild anyway)
            #parent = it.parent() or self.fileTree.invisibleRootItem()
            #parent.removeChild(it)

        # Purge arrays descending
        removed_indices = sorted(set(removed_indices), reverse=True)
        for idx in removed_indices:
            if 0 <= idx < len(self.image_paths):
                del self.image_paths[idx]
            if 0 <= idx < len(self.loaded_images):
                del self.loaded_images[idx]

        if removed_indices:
            self._after_list_changed(removed_indices)

        if failures:
            msg = self.tr("Moved {0} file(s). {1} failed:").format(len(removed_indices), len(failures))
            for old, err in failures[:10]:
                msg += f"\n• {os.path.basename(old)} – {err}"
            QMessageBox.warning(self, self.tr("Move Selected Items"), msg)
        else:
            QMessageBox.information(self, self.tr("Move Selected Items"), self.tr("Moved and removed {0} item(s).").format(len(removed_indices)))

    def _pick_focus_after_removal(self, removed_paths):
        """Pick a leaf path to focus after `removed_paths` are deleted.

        Looks at the CURRENT tree order (before rebuild), finds the first
        surviving leaf after the last removed one, and falls back to the
        last surviving leaf before the first removed one. Returns None if
        the entire tree would be empty.
        """
        try:
            all_leaves = self.get_all_leaf_items()
            removed_set = set(removed_paths)
            # Build an ordered list of (path, is_removed) in tree order.
            ordered = []
            for leaf in all_leaves:
                p = leaf.data(0, Qt.ItemDataRole.UserRole)
                if not p:
                    # fall back to _leaf_path if UserRole isn't set
                    p = self._leaf_path(leaf)
                if p:
                    ordered.append((p, p in removed_set))
            if not ordered:
                return None
            # Index of the last removed one in tree order.
            last_removed_pos = -1
            first_removed_pos = -1
            for i, (_, rm) in enumerate(ordered):
                if rm:
                    if first_removed_pos < 0:
                        first_removed_pos = i
                    last_removed_pos = i
            if last_removed_pos < 0:
                return None  # nothing to remove, caller shouldn't have called us
            # Look for first surviving leaf AFTER the last removed one.
            for i in range(last_removed_pos + 1, len(ordered)):
                p, rm = ordered[i]
                if not rm:
                    return p
            # Fall back: last surviving leaf BEFORE the first removed one.
            for i in range(first_removed_pos - 1, -1, -1):
                p, rm = ordered[i]
                if not rm:
                    return p
            return None
        except Exception:
            return None

    def delete_items(self):
        """Delete selected leaf images from disk and remove them from the blink list."""
        selected_items = [it for it in self.fileTree.selectedItems() if it and it.childCount() == 0]
        if not selected_items:
            QMessageBox.warning(self, self.tr("Warning"), self.tr("No individual image items selected for deletion."))
            return

        reply = QMessageBox.question(
            self,
            self.tr("Confirm Deletion"),
            self.tr("Are you sure you want to permanently delete {0} selected images? This action is irreversible.").format(len(selected_items)),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        removed_indices = []
        failures = []

        # Snapshot first
        triplets = []
        for it in selected_items:
            p = self._leaf_path(it)
            if not p:
                continue
            try:
                idx = self.image_paths.index(p)
            except ValueError:
                continue
            triplets.append((idx, p, it))

        # Snapshot the paths we're about to remove and the scroll state,
        # BEFORE the tree is cleared and rebuilt. _after_list_changed()
        # calls fileTree.clear() which otherwise snaps the view to the
        # top and loses the current item.
        selected_paths = [p for (_, p, _) in triplets]
        focus_target_path = self._pick_focus_after_removal(selected_paths)
        try:
            saved_vscroll = self.fileTree.verticalScrollBar().value()
            saved_hscroll = self.fileTree.horizontalScrollBar().value()
        except Exception:
            saved_vscroll = 0
            saved_hscroll = 0

        for idx, path, it in triplets:
            try:
                os.remove(path)
            except Exception as e:
                failures.append((path, str(e)))
                continue

            removed_indices.append(idx)

            # remove from tree immediately (optional)
            parent = it.parent() or self.fileTree.invisibleRootItem()
            parent.removeChild(it)

        # Purge arrays descending
        removed_indices = sorted(set(removed_indices), reverse=True)
        for idx in removed_indices:
            if 0 <= idx < len(self.image_paths):
                del self.image_paths[idx]
            if 0 <= idx < len(self.loaded_images):
                del self.loaded_images[idx]

        # Clear preview safely (we may replace it below with the new current)
        self.preview_label.clear()
        self.preview_label.setText(self.tr("No image selected."))
        self.current_pixmap = None

        if removed_indices:
            self._after_list_changed(removed_indices)

        # Restore the view: select the next surviving neighbor (which
        # also updates the preview), and scroll it into view. If no
        # survivors, just restore the raw scroll position. Deferred so
        # the rebuild's deferred metrics push and sort pass have landed.
        def _restore_view():
            try:
                new_item = None
                if focus_target_path:
                    for leaf in self.get_all_leaf_items():
                        p = leaf.data(0, Qt.ItemDataRole.UserRole) \
                            or self._leaf_path(leaf)
                        if p == focus_target_path:
                            new_item = leaf
                            break
                if new_item is not None:
                    self.fileTree.setCurrentItem(new_item)
                    self.on_item_clicked(new_item, 0)
                    self.fileTree.scrollToItem(
                        new_item,
                        QAbstractItemView.ScrollHint.PositionAtCenter,
                    )
                else:
                    # Fallback: at least restore raw scroll position.
                    self.fileTree.verticalScrollBar().setValue(saved_vscroll)
                    self.fileTree.horizontalScrollBar().setValue(saved_hscroll)
            except Exception:
                pass
        QTimer.singleShot(0, _restore_view)

        if failures:
            msg = self.tr("Deleted {0} file(s). {1} failed:").format(len(removed_indices), len(failures))
            for p, err in failures[:10]:
                msg += f"\n• {os.path.basename(p)} – {err}"
            QMessageBox.warning(self, self.tr("Delete Selected Items"), msg)
        else:
            QMessageBox.information(self, self.tr("Delete Selected Items"), self.tr("Deleted {0} item(s).").format(len(removed_indices)))

    def _wheel_zoom(self, event: QWheelEvent):
        """Zoom from wheel/trackpad and keep the view centered consistently."""
        # Smooth trackpad support first
        dy = event.pixelDelta().y()

        if dy != 0:
            abs_dy = abs(dy)
            ctrl_down = bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier)

            if abs_dy <= 3:
                base_factor = 1.012 if ctrl_down else 1.010
            elif abs_dy <= 10:
                base_factor = 1.025 if ctrl_down else 1.020
            else:
                base_factor = 1.040 if ctrl_down else 1.030

            factor = base_factor if dy > 0 else 1.0 / base_factor
        else:
            dy = event.angleDelta().y()
            if dy == 0:
                event.accept()
                return

            ctrl_down = bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier)
            step = 1.20 if ctrl_down else 1.15
            factor = step if dy > 0 else 1.0 / step

        old_zoom = float(self.zoom_level)
        new_zoom = max(0.05, min(old_zoom * factor, 3.0))

        if abs(new_zoom - old_zoom) < 1e-6:
            event.accept()
            return

        self.zoom_level = new_zoom
        # Manual zoom via wheel/trackpad — stop auto-fitting on image switch.
        self._set_auto_fit(False)
        self.apply_zoom()
        event.accept()

    def _display_rect(self):
        """Where the scaled pixmap actually sits inside preview_label.

        Returns (x, y, w, h) in label coordinates, or None. QLabel centres a
        pixmap smaller than itself (AlignCenter), and because the scroll area
        is widgetResizable the label is never smaller than the viewport -- so
        as soon as you zoom out past "fills the viewport", the image occupies
        a centred sub-rectangle of the label rather than the whole thing.
        """
        pix = self.preview_label.pixmap()
        if pix is None or pix.isNull():
            return None
        dpr = float(pix.devicePixelRatio() or 1.0) or 1.0
        pw = pix.width() / dpr
        ph = pix.height() / dpr
        lw = float(self.preview_label.width())
        lh = float(self.preview_label.height())
        x0 = max(0.0, (lw - pw) / 2.0)
        y0 = max(0.0, (lh - ph) / 2.0)
        return (x0, y0, pw, ph)

    def _apply_zoom_at_norm(self, norm_cx, norm_cy):
        """Push normalized coords to zoom panel and update overlay rect."""
        # If zoom panel is hidden, clear overlay and bail
        if not self._zoom_panel.isVisible():
            self._zoom_rect_overlay.set_rect(None)
            return

        if not self.current_pixmap or self.current_pixmap.isNull():
            return

        src_x = int(norm_cx * self.current_pixmap.width())
        src_y = int(norm_cy * self.current_pixmap.height())

        zp = self._zoom_panel
        zp._source_pixmap = self.current_pixmap
        zp._norm_cx = float(norm_cx)
        zp._norm_cy = float(norm_cy)
        zp.coords_label.setText(f"({src_x}, {src_y})")
        zp._redraw()

        if not hasattr(self, "_zoom_rect_overlay"):
            return

        disp = self._display_rect()
        if disp is None:
            self._zoom_rect_overlay.set_rect(None)
            return
        disp_x, disp_y, disp_w, disp_h = disp

        hbar = self.scroll_area.horizontalScrollBar()
        vbar = self.scroll_area.verticalScrollBar()

        factor = zp._factor
        panel_w = max(1, zp.zoom_label.width())
        panel_h = max(1, zp.zoom_label.height())

        crop_w_src = max(16, int(panel_w / factor))
        crop_h_src = max(16, int(panel_h / factor))

        rect = _zoom_box_rect(
            self.current_pixmap.width(), self.current_pixmap.height(),
            disp_x, disp_y, disp_w, disp_h,
            norm_cx, norm_cy, crop_w_src, crop_h_src,
            hbar.value(), vbar.value(),
        )
        if rect is None:
            self._zoom_rect_overlay.set_rect(None)
            return
        self._zoom_rect_overlay.set_rect(QRectF(*rect))

    def _center_zoom_to_viewport_pos(self, viewport_pos):
        """Right-click: pin the zoom box to this position and lock it there."""
        if not self.current_pixmap or self.current_pixmap.isNull():
            return
        if not hasattr(self, "_zoom_panel"):
            return

        disp = self._display_rect()
        if disp is None:
            return
        disp_x, disp_y, disp_w, disp_h = disp

        hbar = self.scroll_area.horizontalScrollBar()
        vbar = self.scroll_area.verticalScrollBar()

        norm_cx, norm_cy = _norm_from_viewport_pos(
            viewport_pos.x(), viewport_pos.y(),
            disp_x, disp_y, disp_w, disp_h,
            hbar.value(), vbar.value(),
        )

        # Store the pin in normalized image coords
        self._zoom_pinned_norm = (norm_cx, norm_cy)

        # Lock the zoom panel so set_source respects the pin
        self._zoom_panel.lock_btn.setChecked(True)

        self._apply_zoom_at_norm(norm_cx, norm_cy)

    def _update_zoom_panel_to_viewport_center(self):
        """Update zoom panel — use pinned position if set, otherwise viewport center."""
        if not self.current_pixmap or self.current_pixmap.isNull():
            return
        if not hasattr(self, "_zoom_panel"):
            return

        if self._zoom_pinned_norm is not None:
            # Use pinned position — same spot across image switches
            norm_cx, norm_cy = self._zoom_pinned_norm
        else:
            # Default: whatever the centre of the viewport is sitting over.
            # Mapped through the displayed image rect, so a zoomed-out image
            # reports its own centre instead of the label's.
            disp = self._display_rect()
            if disp is None:
                return
            sa = self.scroll_area
            vp = sa.viewport()
            norm_cx, norm_cy = _norm_from_viewport_pos(
                vp.width() / 2.0, vp.height() / 2.0,
                disp[0], disp[1], disp[2], disp[3],
                sa.horizontalScrollBar().value(),
                sa.verticalScrollBar().value(),
            )

        self._apply_zoom_at_norm(norm_cx, norm_cy)

    def eventFilter(self, source, event):
        if source == self.scroll_area.viewport():
            if event.type() == QEvent.Type.Wheel:
                self._wheel_zoom(event)
                return True

            if event.type() == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
                self.dragging = True
                self.last_mouse_pos = event.pos()
                return True

            elif event.type() == QEvent.Type.MouseMove and self.dragging:
                delta = event.pos() - self.last_mouse_pos
                self.scroll_area.horizontalScrollBar().setValue(
                    self.scroll_area.horizontalScrollBar().value() - delta.x()
                )
                self.scroll_area.verticalScrollBar().setValue(
                    self.scroll_area.verticalScrollBar().value() - delta.y()
                )
                self.last_mouse_pos = event.pos()
                return True
            elif event.type() == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.RightButton:
                # Right-click: center zoom box on this position
                self._center_zoom_to_viewport_pos(event.pos())
                return True
            elif event.type() == QEvent.Type.MouseButtonRelease and event.button() == Qt.MouseButton.LeftButton:
                self.dragging = False
                self._capture_view_center_norm()
                return True

        return super().eventFilter(source, event)
    
    def on_selection_changed(self, selected, deselected):
        items = self.fileTree.selectedItems()
        if not items:
            return
        item = items[0]

        try:
            if item.childCount() > 0:
                return
            name = item.text(0).lstrip("⚠️ ").strip()
        except RuntimeError:
            return

        if self._last_preview_name == name:
            return

        self._pending_preview_item = item
        self._pending_preview_timer.start()

    def _do_preview_update(self):
        item = self._pending_preview_item
        if item is None:
            return
        try:
            if item.treeWidget() is None:
                return
            cur = self.fileTree.currentItem()
            if cur is not item:
                return
            name = item.text(0).lstrip("⚠️ ").strip()
            self._last_preview_name = name
            self.on_item_clicked(item, 0)
        except RuntimeError:
            # C++ object already deleted — nothing to do
            self._pending_preview_item = None

    def toggle_aggressive(self):
        self.aggressive_stretch_enabled = self.aggressive_button.isChecked()
        try:
            QSettings().setValue("blink/aggressive_stretch",
                                 bool(self.aggressive_stretch_enabled))
        except Exception:
            pass
        cur = self.fileTree.currentItem()
        if cur:
            self._last_preview_name = None
            if self.aggressive_stretch_enabled:
                self.loading_label.setText(self.tr("Applying aggressive stretch…"))
                QApplication.processEvents()
            self.on_item_clicked(cur, 0)
            if self.aggressive_stretch_enabled:
                self._update_loaded_count_label(len(self.loaded_images))

    def convert_to_qimage(self, img_array):
        if img_array.dtype == np.uint8:
            arr8 = img_array
        elif img_array.dtype == np.uint16:
            arr8 = (img_array.astype(np.float32) / 65535.0 * 255.0).clip(0,255).astype(np.uint8)
        else:
            # ✅ display-only normalize floats outside 0..1
            f01 = self._ensure_float01(img_array)
            arr8 = (f01 * 255.0).astype(np.uint8)

        h, w = arr8.shape[:2]
        buffer = arr8.tobytes()

        if arr8.ndim == 3:
            # RGB
            return QImage(buffer, w, h, 3*w, QImage.Format.Format_RGB888)
        else:
            # grayscale
            return QImage(buffer, w, h, w, QImage.Format.Format_Grayscale8)

    def _main_window(self):
        w = self
        from PyQt6.QtWidgets import QMainWindow, QApplication
        while w is not None and not isinstance(w, QMainWindow):
            w = w.parentWidget()
        if w is not None:
            return w
        # fallback: scan toplevels
        for tlw in QApplication.topLevelWidgets():
            if isinstance(tlw, QMainWindow):
                return tlw
        return None

# Import centralized widgets
from setiastro.saspro.widgets.spinboxes import CustomSpinBox, CustomDoubleSpinBox
from setiastro.saspro.widgets.preview_dialogs import ImagePreviewDialog


BlinkComparatorPro = BlinkTab

class BlinkComparatorPro(BlinkTab):
    """Alias class so the main app can import a SASpro-named tool."""
    pass