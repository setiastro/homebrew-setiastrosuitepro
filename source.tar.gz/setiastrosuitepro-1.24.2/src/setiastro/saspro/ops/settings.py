# src.setiastro.saspro.ops.settings.py
from PyQt6.QtWidgets import (
QLineEdit, QDialogButtonBox, QFileDialog, QDialog, QPushButton, QFormLayout,QApplication, QMenu, QScrollArea, QSizePolicy,
    QHBoxLayout, QVBoxLayout, QWidget, QCheckBox, QComboBox, QSpinBox, QDoubleSpinBox, QLabel, QColorDialog, QFontDialog, QSlider)
from PyQt6.QtCore import QSettings, Qt
from PyQt6.QtGui import QAction, QGuiApplication
from setiastro.saspro.accel_installer import current_backend
import sys, platform
from PyQt6.QtWidgets import QToolButton, QProgressDialog
from PyQt6.QtCore import QThread
# i18n support
from setiastro.saspro.i18n import get_available_languages, get_saved_language, save_language
from setiastro.saspro.icon_packs import (
    DEFAULT_PACK, available_icon_packs, get_saved_icon_pack, save_icon_pack, user_packs_dir,
)
from setiastro.saspro.color_space_manager import (
    COLOR_SPACES,
    DEFAULT_COLOR_SPACE,
    DEFAULT_VIEWPORT_MODE,
    VIEWPORT_MODE_UNMANAGED,
    get_color_space_options,
    get_profile_search_directories,
    get_viewport_color_mode_from_settings,
    get_working_color_space_from_settings,
    is_profile_available,
    set_viewport_color_mode_to_settings,
    set_working_color_space_to_settings,
)
import importlib.util
import importlib.metadata
import webbrowser
import shutil
import subprocess
import os
from pathlib import Path
from PyQt6.QtCore import QStandardPaths, pyqtSignal


# QSettings keys for the minor-body catalog. Kept module-level and used
# verbatim so Settings, WIMI and the Supernova/Asteroid Hunter all point
# at the SAME database rather than each maintaining its own.
#
#   wimi/minorbody_db_path   — absolute path to the .sqlite (WIMI reads this)
#   wimi/minorbody_data_dir  — the folder it lives in (the Hunter reads THIS)
#
# WIMI historically only ever wrote the first key and computed the folder
# on the fly, while the Hunter only ever read the second. The result was
# that downloading in WIMI left the Hunter's key empty, so the Hunter fell
# back to a different folder (~/.saspro_minor_bodies) and silently
# re-downloaded its own 350 MB copy. Writing both keys here, to one
# canonical location, makes a single download serve every tool.
MINORBODY_DB_PATH_KEY = "wimi/minorbody_db_path"
MINORBODY_DATA_DIR_KEY = "wimi/minorbody_data_dir"


def minorbody_data_dir(settings: "QSettings | None" = None) -> Path:
    """
    Canonical per-user folder for the minor-body catalog.

    Uses QStandardPaths.AppDataLocation so it lands in the platform's
    normal place:
      Windows: %LOCALAPPDATA%/SetiAstroSuitePro/minor_bodies
      macOS:   ~/Library/Application Support/SetiAstroSuitePro/minor_bodies
      Linux:   ~/.local/share/SetiAstroSuitePro/minor_bodies

    When a QSettings is supplied the resolved path is written to
    MINORBODY_DATA_DIR_KEY, which is the key the Hunter reads. Computing
    it in one place and persisting it there is what keeps the tools in
    sync — this is the half WIMI never did.
    """
    base = QStandardPaths.writableLocation(
        QStandardPaths.StandardLocation.AppDataLocation
    )
    base_path = Path(base) if base else Path.home() / ".saspro"
    data_dir = base_path / "minor_bodies"
    try:
        data_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    if settings is not None:
        try:
            settings.setValue(MINORBODY_DATA_DIR_KEY, str(data_dir))
        except Exception:
            pass
    return data_dir


class MinorBodyDownloadWorker(QThread):
    """
    Background download/update of the minor-body catalog.

    Emits finished_ok(db_path, version, asteroids, comets) on success and
    failed(error_message) otherwise. Ported out of WIMI so the updater can
    live in Settings without dragging the rest of the WIMI dialog along.
    """
    finished_ok = pyqtSignal(str, str, int, int)
    failed = pyqtSignal(str)

    def __init__(self, data_dir: Path, force_refresh: bool = False, parent=None):
        super().__init__(parent)
        self.data_dir = Path(data_dir)
        self.force_refresh = force_refresh

    def run(self):
        try:
            from setiastro.saspro import minorbodycatalog as mbc
            db_path, manifest = mbc.ensure_minor_body_db(
                data_dir=self.data_dir,
                manifest_url=mbc.MANIFEST_URL,
                force_refresh=self.force_refresh,
            )
            self.finished_ok.emit(
                str(db_path),
                str(manifest.version),
                int(manifest.counts_asteroids),
                int(manifest.counts_comets),
            )
        except Exception as e:
            self.failed.emit(str(e))


class MinorBodyUpdateCheckWorker(QThread):
    """
    Non-blocking "is there a newer catalog?" check.

    Fetches ONLY the small JSON manifest (not the 350 MB database) and
    compares its version to the local one. Emits
    result(update_available, remote_version, local_version). Any failure
    — offline, DNS, SSL, timeout — resolves to "no update, stay quiet":
    a version badge is a convenience, never worth an error dialog or a
    scary header when the user simply has no connection.

    The comparison is deliberately "versions differ", not "remote > local":
    that is exactly the condition ensure_minor_body_db() uses to decide
    whether clicking Update would actually fetch anything, so the badge
    can never promise an update the button won't perform.
    """
    result = pyqtSignal(bool, str, str)   # update_available, remote_ver, local_ver

    def __init__(self, data_dir: Path, parent=None):
        super().__init__(parent)
        self.data_dir = Path(data_dir)

    def run(self):
        try:
            from setiastro.saspro import minorbodycatalog as mbc
            local_ver = ""
            try:
                lm = mbc.load_local_manifest(
                    self.data_dir / mbc.DEFAULT_MANIFEST_BASENAME)
                if lm is not None:
                    local_ver = str(lm.version)
            except Exception:
                local_ver = ""

            remote_ver = ""
            try:
                rm = mbc.fetch_remote_manifest(mbc.MANIFEST_URL)
                remote_ver = str(rm.version)
            except Exception:
                remote_ver = ""

            avail = bool(local_ver) and bool(remote_ver) and (remote_ver != local_ver)
            self.result.emit(avail, remote_ver, local_ver)
        except Exception:
            self.result.emit(False, "", "")


class SettingsDialog(QDialog):
    """
    Simple settings UI for external executable paths + WIMS defaults.
    Values are persisted via the provided QSettings instance.
    """
    def __init__(self, parent, settings: QSettings):
        super().__init__(parent)
        self.setWindowTitle(self.tr("Preferences"))
        self.settings = settings

        # Background minor-body update-check thread (lazily started on show).
        self._mb_check_thread = None

        # Ensure we don't delete on close, so we can cache it
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)

        # ---- Existing fields (paths, checkboxes, etc.) ----
        self.le_graxpert = QLineEdit()

        self.le_starnet  = QLineEdit()
        self.le_astap    = QLineEdit()

        self.chk_updates_startup = QCheckBox(self.tr("Check for updates on startup"))

        self.le_updates_url = QLineEdit()
        self.le_updates_url.setPlaceholderText("Raw JSON URL (advanced)")
        self.le_updates_url.setMinimumWidth(240)

        btn_reset_updates_url = QPushButton(self.tr("Reset"))
        btn_reset_updates_url.setToolTip(self.tr("Restore default updates URL"))
        btn_reset_updates_url.clicked.connect(
            lambda: self.le_updates_url.setText(
                "https://raw.githubusercontent.com/setiastro/setiastrosuitepro/main/updates.json"
            )
        )

        # Optional: “Check Now…” button
        self.btn_check_now = QPushButton(self.tr("Check Now…"))
        self.btn_check_now.setToolTip(self.tr("Run an update check immediately"))
        self.btn_check_now.setVisible(hasattr(parent, "_check_for_updates_async"))
        self.btn_check_now.clicked.connect(self._check_updates_now_clicked)

        self.chk_save_shortcuts = QCheckBox(self.tr("Save desktop shortcuts on exit"))
        self.chk_open_all_hdus = QCheckBox(self.tr("Open All detected HDUs"))
        self.chk_open_all_hdus.setToolTip(self.tr(
            "When checked, opening a FITS or XISF file also opens extra HDUs "
            "(weights, rejection maps, other image layers, tables).\n"
            "Uncheck to open the Primary image only."
        ))

        self.chk_smart_view_naming = QCheckBox(self.tr("Smart view naming"))
        self.chk_smart_view_naming.setToolTip(self.tr(
            "When checked, newly loaded views are named from the FITS header,\n"
            "e.g. 'ngc660galaxy_G' from OBJECT=ngc660galaxy + FILTER=G, instead\n"
            "of using the raw filename like\n"
            "'MasterLight_ngc660galaxy_G_-_180s_G121_8307x5657_65stacked'.\n\n"
            "Uncheck to show the full filename as the view title (previous\n"
            "behaviour). Only affects new loads — existing open views keep\n"
            "their current titles."
        ))

        self.cb_theme = QComboBox()
        # Order: Dark, Gray, Light, System, Custom
        self.cb_theme.addItems(["Dark", "Gray", "Light", "System", "Custom"])

        # "Customize…" button for custom theme
        self.btn_theme_custom = QPushButton(self.tr("Customize…"))
        self.btn_theme_custom.setToolTip(self.tr("Edit custom colors and font"))
        self.btn_theme_custom.clicked.connect(self._open_theme_editor)

        # Keep button enabled state in sync with combo
        self.cb_theme.currentIndexChanged.connect(self._on_theme_changed)

        # ---- Language selector ----
        self.cb_language = QComboBox()
        self._lang_codes = list(get_available_languages().keys())   # ["en", "it", "fr", "es"]
        self._lang_names = list(get_available_languages().values()) # ["English", "Italiano", ...]
        self.cb_language.addItems(self._lang_names)
        self._initial_language = "en"  # placeholder, set in refresh_ui

        btn_grax  = QPushButton(self.tr("Browse…")); btn_grax.clicked.connect(lambda: self._browse_into(self.le_graxpert))
        btn_star  = QPushButton(self.tr("Browse…")); btn_star.clicked.connect(lambda: self._browse_into(self.le_starnet))
        btn_astap = QPushButton(self.tr("Browse…")); btn_astap.clicked.connect(lambda: self._browse_into(self.le_astap))

        # Path rows
        row_grax = QHBoxLayout()
        row_grax.setContentsMargins(0, 0, 0, 0)
        row_grax.addWidget(self.le_graxpert, 1)
        row_grax.addWidget(btn_grax)

        row_star = QHBoxLayout()
        row_star.setContentsMargins(0, 0, 0, 0)
        row_star.addWidget(self.le_starnet, 1)
        row_star.addWidget(btn_star)

        row_astap = QHBoxLayout()
        row_astap.setContentsMargins(0, 0, 0, 0)
        row_astap.addWidget(self.le_astap, 1)
        row_astap.addWidget(btn_astap)

        self.le_astrometry = QLineEdit()
        self.le_astrometry.setEchoMode(QLineEdit.EchoMode.Password)

        self.chk_autostretch_24bit = QCheckBox(self.tr("High-quality autostretch (24-bit; slower)"))
        self.chk_autostretch_24bit.setToolTip(self.tr("Compute autostretch on a 24-bit histogram (smoother gradients)."))

        self.chk_smooth_zoom_settle = QCheckBox(self.tr("Smooth zoom final redraw (higher quality when zoom stops)"))
        self.chk_smooth_zoom_settle.setToolTip(self.tr(
            "When enabled, zooming is fast while scrolling, then a single high-quality redraw occurs after you stop zooming.\n"
            "Disable if you prefer maximum responsiveness or older GPUs/CPUs."
        ))

        self.slider_bg_opacity = QSlider(Qt.Orientation.Horizontal)
        self.slider_bg_opacity.setRange(0, 100)
        self._initial_bg_opacity = 50

        self.lbl_bg_opacity_val = QLabel("50%")
        self.lbl_bg_opacity_val.setFixedWidth(48)

        def _on_opacity_changed(val):
            self.lbl_bg_opacity_val.setText(f"{val}%")
            # Update in real time
            self.settings.setValue("display/bg_opacity", val)
            self.settings.sync()
            p = self.parent()
            if p and hasattr(p, "mdi") and hasattr(p.mdi, "viewport"):
                p.mdi.viewport().update()

        self.slider_bg_opacity.valueChanged.connect(_on_opacity_changed)

        row_bg_opacity = QHBoxLayout()
        row_bg_opacity.setContentsMargins(0, 0, 0, 0)
        row_bg_opacity.addWidget(self.slider_bg_opacity, 1)
        row_bg_opacity.addWidget(self.lbl_bg_opacity_val)
        w_bg_opacity = QWidget()
        w_bg_opacity.setLayout(row_bg_opacity)

        # ---- Custom background: choose/clear preview ----
        self.le_bg_path = QLineEdit()
        self.le_bg_path.setReadOnly(True)
        self.le_bg_path.setMinimumWidth(240)
        self._initial_bg_path = ""

        btn_choose_bg = QPushButton(self.tr("Choose Background…"))
        btn_choose_bg.setToolTip(self.tr("Pick a PNG or JPG to use as the application background"))
        btn_choose_bg.clicked.connect(self._choose_background_clicked)

        btn_clear_bg = QPushButton(self.tr("Clear"))
        btn_clear_bg.setToolTip(self.tr("Remove custom background and restore default"))
        btn_clear_bg.clicked.connect(self._clear_background_clicked)

        row_bg_image = QHBoxLayout()
        row_bg_image.setContentsMargins(0, 0, 0, 0)
        row_bg_image.addWidget(self.le_bg_path, 1)
        row_bg_image.addWidget(btn_choose_bg)
        row_bg_image.addWidget(btn_clear_bg)
        w_bg_image = QWidget()
        w_bg_image.setLayout(row_bg_image)

        # ─────────────────────────────────────────────────────────────────────
        # MAIN LAYOUT (SCROLLABLE + RESPONSIVE)
        # ─────────────────────────────────────────────────────────────────────
        root = QVBoxLayout(self)

        # Scroll area prevents clipping on smaller displays
        self._scroll = QScrollArea(self)
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        root.addWidget(self._scroll, 1)

        # Content widget inside scroll area
        self._scroll_content = QWidget()
        self._scroll.setWidget(self._scroll_content)

        self._scroll_root = QVBoxLayout(self._scroll_content)
        self._scroll_root.setContentsMargins(0, 0, 0, 0)
        self._scroll_root.setSpacing(0)

        # Row container that will hold either:
        # - two widgets side-by-side
        # - or a single stacked layout on narrow width
        self._cols_layout = QHBoxLayout()
        self._cols_layout.setContentsMargins(0, 0, 0, 0)
        self._cols_layout.setSpacing(0)
        self._scroll_root.addLayout(self._cols_layout)

        # Column wrapper widgets (so we can reflow them responsively)
        self._left_col_widget = QWidget()
        self._right_col_widget = QWidget()

        left_col = QFormLayout(self._left_col_widget)
        right_col = QFormLayout(self._right_col_widget)

        self.left_col = left_col
        self.right_col = right_col

        for f in (left_col, right_col):
            f.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
            # Wrap long rows instead of clipping
            f.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
            f.setFormAlignment(Qt.AlignmentFlag.AlignTop)
            f.setLabelAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            f.setHorizontalSpacing(10)
            f.setVerticalSpacing(8)

        # ---- Left column: Paths & Integrations ----
        left_col.addRow(QLabel(self.tr("<b>Paths & Integrations</b>")))

        w = QWidget(); w.setLayout(row_grax)
        left_col.addRow(self.tr("GraXpert executable:"), w)

        w = QWidget(); w.setLayout(row_star)
        left_col.addRow(self.tr("StarNet executable:"), w)

        w = QWidget(); w.setLayout(row_astap)
        left_col.addRow(self.tr("ASTAP executable:"), w)

        left_col.addRow(self.tr("Astrometry.net API key:"), self.le_astrometry)
        left_col.addRow(self.chk_save_shortcuts)
        left_col.addRow(self.chk_open_all_hdus)
        left_col.addRow(self.chk_smart_view_naming)

        row_theme = QHBoxLayout()
        row_theme.setContentsMargins(0, 0, 0, 0)
        row_theme.addWidget(self.cb_theme, 1)
        row_theme.addWidget(self.btn_theme_custom)
        w_theme = QWidget()
        w_theme.setLayout(row_theme)
        left_col.addRow(self.tr("Theme:"), w_theme)

        left_col.addRow(self.tr("Language:"), self.cb_language)

        # ---- Display ----
        left_col.addRow(QLabel(self.tr("<b>Display</b>")))
        left_col.addRow(self.chk_autostretch_24bit)
        left_col.addRow(
            "",
            QLabel(self.tr("• ON  = 24-bit (best gradient smoothness, slower)\n"
                        "• OFF = 12-bit (faster, still high quality)"))
        )        
        left_col.addRow(self.chk_smooth_zoom_settle)
        left_col.addRow(self.tr("Background Opacity:"), w_bg_opacity)
        left_col.addRow(self.tr("Background Image:"), w_bg_image)
        self.sp_icon_size = QSpinBox()
        self.sp_icon_size.setRange(16, 64)
        self.sp_icon_size.setSingleStep(4)
        self.sp_icon_size.setSuffix(" px")
        self.sp_icon_size.setToolTip(self.tr("Toolbar icon size in pixels (default: 24)"))
        left_col.addRow(self.tr("Toolbar Icon Size:"), self.sp_icon_size)

        self.cb_icon_pack = QComboBox()
        self.cb_icon_pack.setToolTip(self.tr(
            "Alternate artwork for the application's icons. "
            "Icons a pack doesn't include keep their default look."
        ))
        btn_icon_pack_folder = QPushButton(self.tr("Open Folder…"))
        btn_icon_pack_folder.setToolTip(self.tr("Add an icon pack by placing its folder here"))
        btn_icon_pack_folder.clicked.connect(self._open_icon_packs_folder)
        row_icon_pack = QHBoxLayout()
        row_icon_pack.setContentsMargins(0, 0, 0, 0)
        row_icon_pack.addWidget(self.cb_icon_pack, 1)
        row_icon_pack.addWidget(btn_icon_pack_folder)
        w_icon_pack = QWidget()
        w_icon_pack.setLayout(row_icon_pack)
        left_col.addRow(self.tr("Icon Pack:"), w_icon_pack)

        self.cb_color_space = QComboBox()
        self._color_space_keys = []
        for info in get_color_space_options():
            self._color_space_keys.append(info.key)
            self.cb_color_space.addItem(self._color_space_label(info.key), info.key)
            idx = self.cb_color_space.count() - 1
            self.cb_color_space.setItemData(idx, self._color_space_description(info.key), Qt.ItemDataRole.ToolTipRole)
        self.cb_color_space.setToolTip(self.tr(
            "Working color space for image display and default export tagging."
        ))
        left_col.addRow(self.tr("Working Color Space:"), self.cb_color_space)

        self.cb_viewport_color_mode = QComboBox()
        viewport_mode_keys = [VIEWPORT_MODE_UNMANAGED]
        viewport_mode_keys.extend(info.key for info in get_color_space_options())
        for key in viewport_mode_keys:
            self.cb_viewport_color_mode.addItem(self._viewport_color_mode_label(key), key)
            idx = self.cb_viewport_color_mode.count() - 1
            self.cb_viewport_color_mode.setItemData(
                idx,
                self._viewport_color_mode_description(key),
                Qt.ItemDataRole.ToolTipRole,
            )
        self.cb_viewport_color_mode.setToolTip(self.tr(
            "How image viewports apply color profile information before display."
        ))
        left_col.addRow(self.tr("Viewport Color Management:"), self.cb_viewport_color_mode)

        # ---- Pixel Readout (Loupe) ----
        left_col.addRow(QLabel(self.tr("<b>Pixel Readout (Loupe)</b>")))

        self.chk_loupe_info = QCheckBox(self.tr("Show RGB / coordinates in zoom preview"))
        self.chk_loupe_info.setToolTip(self.tr(
            "Show the probed RGB (or K) value and, when a WCS is present,\n"
            "the celestial coordinates inside the Space+click zoom preview."))
        left_col.addRow(self.chk_loupe_info)

        self.sp_loupe_size = QSpinBox()
        self.sp_loupe_size.setRange(121, 601)
        self.sp_loupe_size.setSingleStep(20)
        self.sp_loupe_size.setSuffix(" px")
        self.sp_loupe_size.setToolTip(self.tr(
            "Size of the zoom preview window (default: 161).\n"
            "Bump this up on 4K / 8K displays. Rounded to an odd number."))
        left_col.addRow(self.tr("Zoom Preview Size:"), self.sp_loupe_size)

        self.sp_loupe_patch = QSpinBox()
        self.sp_loupe_patch.setRange(9, 41)
        self.sp_loupe_patch.setSingleStep(2)
        self.sp_loupe_patch.setSuffix(" px")
        self.sp_loupe_patch.setToolTip(self.tr(
            "How many source pixels the preview samples across (default: 17).\n"
            "Smaller = more magnified; larger = wider field. Odd numbers only."))
        left_col.addRow(self.tr("Zoom Sample Window:"), self.sp_loupe_patch)

        self.sp_loupe_font = QSpinBox()
        self.sp_loupe_font.setRange(7, 24)
        self.sp_loupe_font.setSingleStep(1)
        self.sp_loupe_font.setSuffix(" pt")
        self.sp_loupe_font.setToolTip(self.tr(
            "Maximum font size for the readout text (default: 10).\n"
            "Text auto-shrinks to fit the preview width."))
        left_col.addRow(self.tr("Readout Font Size:"), self.sp_loupe_font)

        left_col.addRow(
            "",
            QLabel(self.tr("Changes apply to image views opened afterward."))
        )

        # ---- Acceleration ----
        right_col.addRow(QLabel(self.tr("<b>Acceleration</b>")))

        # Backend/deps/pref/install split into multi-line compact box (much better on small widths)
        self.backend_label = QLabel(self.tr("Backend: {0}").format(current_backend()))

        self.accel_deps_label = QLabel()
        self.accel_deps_label.setTextFormat(Qt.TextFormat.RichText)
        self.accel_deps_label.setStyleSheet("color:#888;")
        self.accel_deps_label.setToolTip(self.tr("Installed acceleration-related Python packages"))
        self.accel_deps_label.setWordWrap(True)
        self.accel_deps_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        # preference combo
        self.cb_accel_pref = QComboBox()
        self._accel_items = [
            (self.tr("Auto (recommended)"), "auto"),
            (self.tr("CUDA (NVIDIA)"), "cuda"),
        ]
 
        # Linux AMD ROCm
        if platform.system() == "Linux":
            self._accel_items.append((self.tr("ROCm (AMD on Linux)"), "rocm"))
 
        # Intel XPU (Windows/Linux)
        if platform.system() in ("Windows", "Linux"):
            self._accel_items.append((self.tr("Intel XPU (Arc/Xe)"), "xpu"))
 
        # DirectML (Windows only)
        if platform.system() == "Windows":
            self._accel_items.append((self.tr("DirectML (Windows AMD/Intel)"), "directml"))
 
        # Apple MPS is handled automatically by runtime_torch for macOS arm64;
        # we surface it here as an explicit option so users can force it.
        if platform.system() == "Darwin" and (
            "arm64" in platform.machine().lower() or "aarch64" in platform.machine().lower()
        ):
            self._accel_items.append((self.tr("Apple Silicon GPU (MPS)"), "cuda"))
 
        self._accel_items.append((self.tr("CPU only"), "cpu"))



        self.cb_accel_pref.clear()
        for label, _key in self._accel_items:
            self.cb_accel_pref.addItem(label)
        self.cb_accel_pref.currentIndexChanged.connect(self._accel_pref_changed)

        self.install_accel_btn = QPushButton(self.tr("Install/Repair Hardware Acceleration…"))

        gpu_help_btn = QToolButton()
        gpu_help_btn.setText("?")
        gpu_help_btn.setToolTip(self.tr("If hardware acceleration is still not being used — click for fix steps"))
        gpu_help_btn.clicked.connect(self._show_gpu_accel_fix_help)

        accel_box = QVBoxLayout()
        accel_box.setContentsMargins(0, 0, 0, 0)
        accel_box.setSpacing(6)

        accel_row_top = QHBoxLayout()
        accel_row_top.setContentsMargins(0, 0, 0, 0)
        accel_row_top.addWidget(self.backend_label)
        accel_row_top.addStretch(1)
        accel_row_top.addWidget(gpu_help_btn)

        accel_row_pref = QHBoxLayout()
        accel_row_pref.setContentsMargins(0, 0, 0, 0)
        accel_row_pref.addWidget(QLabel(self.tr("Preference:")))
        accel_row_pref.addWidget(self.cb_accel_pref, 1)
        accel_row_pref.addWidget(self.install_accel_btn)

        accel_box.addLayout(accel_row_top)
        accel_box.addWidget(self.accel_deps_label)
        accel_box.addLayout(accel_row_pref)

        w_accel = QWidget()
        w_accel.setLayout(accel_box)
        right_col.addRow(w_accel)

        # ---- Right column: AI Models ----
        right_col.addRow(QLabel(self.tr("<b>AI Models</b>")))

        self.lbl_models_status = QLabel(self.tr("Status: (unknown)"))
        self.lbl_models_status.setStyleSheet("color:#888;")
        self.lbl_models_status.setWordWrap(True)
        self.lbl_models_status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        right_col.addRow(self.lbl_models_status)

        self.btn_models_update = QPushButton(self.tr("Download/Update Models…"))
        self.btn_models_update.clicked.connect(self._models_update_clicked)

        self.btn_models_install_zip = QPushButton(self.tr("Install from ZIP…"))
        self.btn_models_install_zip.setToolTip(self.tr("Use a manually downloaded models .zip file"))
        self.btn_models_install_zip.clicked.connect(self._models_install_from_zip_clicked)

        self.btn_models_open_drive = QPushButton(self.tr("Open Drive…"))
        self.btn_models_open_drive.setToolTip(self.tr("Download models (Primary/Backup/GitHub mirror)"))
        self.btn_models_open_drive.clicked.connect(self._models_open_drive_clicked)

        # Break wide model-buttons row into 2 rows
        models_box = QVBoxLayout()
        models_box.setContentsMargins(0, 0, 0, 0)
        models_box.setSpacing(6)

        # Top row: one big primary action
        row_models_top = QHBoxLayout()
        row_models_top.setContentsMargins(0, 0, 0, 0)
        row_models_top.addWidget(self.btn_models_update, 1)

        # Bottom row: secondary actions side-by-side
        row_models_bottom = QHBoxLayout()
        row_models_bottom.setContentsMargins(0, 0, 0, 0)
        row_models_bottom.addWidget(self.btn_models_open_drive)
        row_models_bottom.addWidget(self.btn_models_install_zip)
        row_models_bottom.addStretch(1)

        models_box.addLayout(row_models_top)
        models_box.addLayout(row_models_bottom)

        w_models = QWidget()
        w_models.setLayout(models_box)
        right_col.addRow(w_models)
        # ---- Gaia XP Spectral Library ----
        right_col.addRow(QLabel(self.tr("<b>Gaia XP Spectral Library</b>")))

        self.lbl_gaia_status = QLabel(self.tr("Status: (unknown)"))
        self.lbl_gaia_status.setStyleSheet("color:#888;")
        self.lbl_gaia_status.setWordWrap(True)
        self.lbl_gaia_status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        right_col.addRow(self.lbl_gaia_status)

        self.btn_gaia_open = QPushButton(self.tr("Open Gaia Database…"))
        self.btn_gaia_open.setToolTip(self.tr("Manage installed Gaia XP spectral library groups"))
        self.btn_gaia_open.clicked.connect(self._open_gaia_database_clicked)
        right_col.addRow(self.btn_gaia_open)

        # ---- Minor-Body Catalog (asteroids + comets) ----
        # Header kept as an instance attribute so the background update
        # check can append an "Update available" badge to it.
        self.lbl_minorbody_header = QLabel(self.tr("<b>Minor-Body Catalog</b>"))
        self.lbl_minorbody_header.setTextFormat(Qt.TextFormat.RichText)
        right_col.addRow(self.lbl_minorbody_header)

        self.lbl_minorbody_status = QLabel(self.tr("Status: (unknown)"))
        self.lbl_minorbody_status.setStyleSheet("color:#888;")
        self.lbl_minorbody_status.setWordWrap(True)
        self.lbl_minorbody_status.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse)
        right_col.addRow(self.lbl_minorbody_status)

        # Primary action: Download / Update. The MPC catalog refreshes
        # roughly monthly (its element epoch rolls over), so this is a
        # recurring action, not a one-time install — hence it lives in
        # Settings next to the other data-library managers rather than
        # buried in the hunting tool.
        self.btn_minorbody_update = QPushButton(self.tr("Download / Update Catalog"))
        self.btn_minorbody_update.setToolTip(self.tr(
            "Fetch the latest asteroid + comet orbital elements (~350 MB).\n"
            "Only downloads when the published version is newer than what\n"
            "you already have."))
        self.btn_minorbody_update.clicked.connect(
            lambda: self._download_minorbody_clicked(force=False))

        # Secondary actions live behind a ▾ menu so the common case stays
        # a single obvious button.
        self.btn_minorbody_menu = QToolButton()
        self.btn_minorbody_menu.setText("▾")
        self.btn_minorbody_menu.setPopupMode(
            QToolButton.ToolButtonPopupMode.InstantPopup)
        _mb_menu = QMenu(self.btn_minorbody_menu)
        _act_force = _mb_menu.addAction(self.tr("Force Re-download…"))
        _act_force.triggered.connect(
            lambda: self._download_minorbody_clicked(force=True))
        _act_install = _mb_menu.addAction(self.tr("Install from Local File…"))
        _act_install.triggered.connect(self._install_minorbody_from_file)
        _mb_menu.addSeparator()
        _act_page = _mb_menu.addAction(self.tr("Open Releases Page…"))
        _act_page.triggered.connect(self._open_minorbody_releases)
        _act_folder = _mb_menu.addAction(self.tr("Open Catalog Folder…"))
        _act_folder.triggered.connect(self._open_minorbody_folder)
        self.btn_minorbody_menu.setMenu(_mb_menu)

        _row_mb = QHBoxLayout()
        _row_mb.setContentsMargins(0, 0, 0, 0)
        _row_mb.addWidget(self.btn_minorbody_update, 1)
        _row_mb.addWidget(self.btn_minorbody_menu)
        _w_mb = QWidget()
        _w_mb.setLayout(_row_mb)
        right_col.addRow(_w_mb)

        # ---- RA/Dec Overlay ----
        right_col.addRow(QLabel(self.tr("<b>RA/Dec Overlay</b>")))
        self.chk_wcs_enabled = QCheckBox(self.tr("Show RA/Dec grid"))
        right_col.addRow(self.chk_wcs_enabled)

        self.cb_wcs_mode = QComboBox(); self.cb_wcs_mode.addItems(["Auto", "Fixed spacing"])
        self.cb_wcs_unit = QComboBox(); self.cb_wcs_unit.addItems(["deg", "arcmin"])

        self.sp_wcs_step = QDoubleSpinBox()
        self.sp_wcs_step.setDecimals(3)
        self.sp_wcs_step.setRange(0.001, 90.0)

        def _sync_suffix():
            self.sp_wcs_step.setSuffix(" °" if self.cb_wcs_unit.currentIndex() == 0 else " arcmin")
        _sync_suffix()

        self.cb_wcs_unit.currentIndexChanged.connect(_sync_suffix)
        self.cb_wcs_mode.currentIndexChanged.connect(lambda i: self.sp_wcs_step.setEnabled(i == 1))

        row_wcs = QHBoxLayout()
        row_wcs.setContentsMargins(0, 0, 0, 0)
        row_wcs.addWidget(QLabel(self.tr("Mode:")))
        row_wcs.addWidget(self.cb_wcs_mode)
        row_wcs.addSpacing(8)
        row_wcs.addWidget(QLabel(self.tr("Step:")))
        row_wcs.addWidget(self.sp_wcs_step, 1)
        row_wcs.addWidget(self.cb_wcs_unit)

        _w = QWidget()
        _w.setLayout(row_wcs)
        right_col.addRow(_w)

        # ---- Updates ----
        right_col.addRow(QLabel(self.tr("<b>Updates</b>")))
        right_col.addRow(self.chk_updates_startup)

        # Split updates URL row into field + buttons rows (avoids giant horizontal line)
        updates_box = QVBoxLayout()
        updates_box.setContentsMargins(0, 0, 0, 0)
        updates_box.setSpacing(6)
        updates_box.addWidget(self.le_updates_url)

        row_updates_btns = QHBoxLayout()
        row_updates_btns.setContentsMargins(0, 0, 0, 0)
        row_updates_btns.addWidget(btn_reset_updates_url)
        row_updates_btns.addWidget(self.btn_check_now)
        row_updates_btns.addStretch(1)
        updates_box.addLayout(row_updates_btns)

        w_updates = QWidget()
        w_updates.setLayout(updates_box)
        right_col.addRow(self.tr("Updates JSON URL:"), w_updates)

        # ---- Put columns into responsive container (initially)
        self._cols_layout.addWidget(self._left_col_widget, 1)
        self._cols_layout.addSpacing(16)
        self._cols_layout.addWidget(self._right_col_widget, 1)

        # ---- Buttons (fixed at bottom, not inside scroll) ----
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self._save_and_accept)
        btns.rejected.connect(self.reject)
        root.addWidget(btns)

        # Connect accel install button after widget exists
        self.install_accel_btn.clicked.connect(self._install_or_update_accel)

        # Reasonable initial size, clamped to available screen
        self.setSizeGripEnabled(True)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)

        screen = QGuiApplication.primaryScreen()
        if screen:
            avail = screen.availableGeometry()
            w = min(1200, max(900, int(avail.width() * 0.92)))
            h = min(680,  max(680, int(avail.height() * 0.88)))
            self.resize(w, h)
        else:
            self.resize(1200, 680)

        # Initial load
        self.refresh_ui()

        # Apply responsive layout once after widgets are built
        self._layout_mode = None
        self._update_responsive_layout()

    def _open_gaia_database_clicked(self):
        from setiastro.saspro.gaia_database import open_gaia_database_dialog
        dlg = open_gaia_database_dialog(parent=self)
        try:
            dlg.library_changed.connect(self._refresh_gaia_status)
        except Exception:
            pass

    def _refresh_gaia_status(self):
        try:
            from setiastro.saspro.gaia_database import GROUP_DEFS, get_library_dir
            lib_dir = get_library_dir()
            n_installed = sum(
                1 for g in GROUP_DEFS
                if all((lib_dir / f).exists() for f in g.filenames)
            )
            n_partial = sum(
                1 for g in GROUP_DEFS
                if any((lib_dir / f).exists() for f in g.filenames)
                and not all((lib_dir / f).exists() for f in g.filenames)
            )
            total_mb = sum(
                (lib_dir / f).stat().st_size / (1024 * 1024)
                for g in GROUP_DEFS for f in g.filenames
                if (lib_dir / f).exists()
            )
            size_str = f"{total_mb/1024:.1f} GB" if total_mb >= 1024 else f"{total_mb:.0f} MB"

            lines = [self.tr("{0}/{1} groups installed  ·  {2} on disk").format(
                n_installed, len(GROUP_DEFS), size_str)]
            if n_partial:
                lines.append(self.tr("{0} group(s) partially installed").format(n_partial))
            lines.append(self.tr("Location: {0}").format(str(lib_dir)))

            self.lbl_gaia_status.setText("\n".join(lines))
        except Exception as e:
            self.lbl_gaia_status.setText(self.tr("Status: error reading library ({0})").format(e))

    # ------------------------------------------------------------------
    # Minor-body catalog
    # ------------------------------------------------------------------

    def _minorbody_data_dir(self) -> Path:
        """Canonical folder, and persist it so WIMI + Hunter agree."""
        return minorbody_data_dir(self.settings)

    def _refresh_minorbody_status(self):
        """
        Show the installed catalog's version, counts and how stale its
        orbital elements are. The freshness line is the one that matters:
        two-body propagation drifts with the gap from the element epoch,
        so a catalog months old will visibly mis-mark fast movers, and a
        number on screen turns 'the markers are a bit off' into 'oh, it's
        140 days old'.
        """
        try:
            from setiastro.saspro import minorbodycatalog as mbc
        except Exception as e:
            self.lbl_minorbody_status.setText(
                self.tr("Status: catalog module unavailable ({0})").format(e))
            return

        path = self.settings.value(MINORBODY_DB_PATH_KEY, "", type=str)
        if not path:
            # Nothing cached: probe the canonical folder anyway, in case a
            # file is present from a prior version that never wrote the key.
            cand = self._minorbody_data_dir() / mbc.DEFAULT_DB_BASENAME
            path = str(cand) if cand.is_file() else ""

        if not path or not Path(path).is_file():
            self.lbl_minorbody_status.setText(
                self.tr("Not installed — click Download / Update Catalog."))
            return

        p = Path(path)
        lines = []
        manifest_path = p.parent / mbc.DEFAULT_MANIFEST_BASENAME
        manifest = mbc.load_local_manifest(manifest_path)
        if manifest is not None:
            lines.append(self.tr("Version {0} — {1:,} asteroids, {2:,} comets").format(
                manifest.version, manifest.counts_asteroids, manifest.counts_comets))
            # Manifest schema v2 carries epoch-freshness stats; show them
            # when present, without hard-depending on them.
            try:
                fresh = (manifest.raw or {}).get("epoch_freshness", {})
                ast = fresh.get("asteroids", {})
                med = ast.get("median_days")
                if med is not None:
                    age_txt = (f"{med/365.25:.1f} yr" if med >= 400
                               else f"{med:.0f} days")
                    note = ""
                    if med > 180:
                        note = self.tr("  — consider updating")
                    lines.append(self.tr(
                        "Asteroid elements ~{0} old{1}").format(age_txt, note))
            except Exception:
                pass
        else:
            lines.append(self.tr("Installed: {0}").format(p.name))

        try:
            size_mb = p.stat().st_size / (1024 * 1024)
            lines.append(self.tr("{0:.0f} MB  ·  {1}").format(size_mb, str(p.parent)))
        except Exception:
            lines.append(str(p.parent))

        self.lbl_minorbody_status.setText("\n".join(lines))

    def _set_minorbody_db_path(self, db_path: str):
        """Persist the resolved DB path + folder for every tool to find."""
        self.settings.setValue(MINORBODY_DB_PATH_KEY, db_path)
        try:
            self.settings.setValue(MINORBODY_DATA_DIR_KEY, str(Path(db_path).parent))
        except Exception:
            pass
        self.settings.sync()

    def _download_minorbody_clicked(self, force: bool = False):
        from PyQt6.QtWidgets import QMessageBox
        from PyQt6.QtCore import QEventLoop

        data_dir = self._minorbody_data_dir()

        self.btn_minorbody_update.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)

        dlg = QProgressDialog(
            self.tr("Downloading minor-body catalog…\n"
                    "This may take a minute (~350 MB)."),
            "", 0, 0, self)
        dlg.setWindowTitle(self.tr("Minor-Body Catalog"))
        dlg.setWindowModality(Qt.WindowModality.ApplicationModal)
        dlg.setAutoClose(False)
        dlg.setAutoReset(False)
        dlg.setCancelButton(None)
        dlg.show()

        result = {"ok": False, "db_path": "", "version": "",
                  "ast": 0, "com": 0, "error": ""}
        loop = QEventLoop()

        def _on_ok(db_path, version, ast, com):
            result.update(ok=True, db_path=db_path, version=version,
                          ast=ast, com=com)
            loop.quit()

        def _on_fail(msg):
            result.update(ok=False, error=msg)
            loop.quit()

        worker = MinorBodyDownloadWorker(data_dir, force_refresh=force, parent=self)
        worker.finished_ok.connect(_on_ok)
        worker.failed.connect(_on_fail)
        worker.finished.connect(loop.quit)
        worker.start()
        loop.exec()

        dlg.close()
        QApplication.restoreOverrideCursor()
        self.btn_minorbody_update.setEnabled(True)

        if not result["ok"]:
            self._refresh_minorbody_status()
            QMessageBox.critical(
                self, self.tr("Minor-Body Catalog Error"),
                self.tr("Failed to download minor-body catalog:\n{0}\n\n"
                        "If this is an SSL error (common on macOS), use the ▾ menu\n"
                        "→ Open Releases Page to download the .sqlite in a browser,\n"
                        "then ▾ → Install from Local File.").format(
                            result["error"] or self.tr("Unknown error.")))
            return

        self._set_minorbody_db_path(result["db_path"])
        self._refresh_minorbody_status()
        QMessageBox.information(
            self, self.tr("Minor-Body Catalog"),
            self.tr("Catalog ready.\nVersion: {0}\nAsteroids: {1:,}\n"
                    "Comets: {2:,}").format(
                        result["version"], result["ast"], result["com"]))

    def _install_minorbody_from_file(self):
        from PyQt6.QtWidgets import QMessageBox, QFileDialog
        from setiastro.saspro import minorbodycatalog as mbc

        src_path, _ = QFileDialog.getOpenFileName(
            self, self.tr("Select minor-body SQLite file"), "",
            self.tr("SQLite databases (*.sqlite *.db);;All files (*)"))
        if not src_path:
            return

        data_dir = self._minorbody_data_dir()
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            db_path, manifest = mbc.install_local_db_file(
                src_path=Path(src_path), data_dir=data_dir)
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            self._refresh_minorbody_status()
            QMessageBox.critical(
                self, self.tr("Minor-Body Catalog Error"),
                self.tr("Failed to install minor-body catalog:\n{0}").format(exc))
            return
        finally:
            QApplication.restoreOverrideCursor()

        self._set_minorbody_db_path(str(db_path))
        self._refresh_minorbody_status()
        QMessageBox.information(
            self, self.tr("Minor-Body Catalog"),
            self.tr("Catalog installed from local file.\nVersion: {0}\n"
                    "Asteroids: {1:,}\nComets: {2:,}").format(
                        manifest.version, manifest.counts_asteroids,
                        manifest.counts_comets))

    def _open_minorbody_releases(self):
        from PyQt6.QtWidgets import QMessageBox
        from setiastro.saspro import minorbodycatalog as mbc
        QMessageBox.information(
            self, self.tr("Manual Download"),
            self.tr("Your browser will open the SASpro minor-body releases page.\n\n"
                    "Download the '{0}' asset from the latest release, then use\n"
                    "▾ → Install from Local File.").format(mbc.DEFAULT_DB_BASENAME))
        try:
            webbrowser.open(mbc.RELEASES_PAGE_URL)
        except Exception:
            pass

    def _open_icon_packs_folder(self):
        folder = user_packs_dir()
        try:
            folder.mkdir(parents=True, exist_ok=True)
            if sys.platform.startswith("win"):
                os.startfile(str(folder))  # noqa: S606
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except Exception:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.information(self, self.tr("Icon Packs Folder"), str(folder))

    def _refresh_icon_packs(self):
        """List installed packs, keeping a selected pack even if it has been removed."""
        selected = get_saved_icon_pack()
        self.cb_icon_pack.clear()
        self.cb_icon_pack.addItem(self.tr("Default"), DEFAULT_PACK)
        names = list(available_icon_packs())
        if selected != DEFAULT_PACK and selected not in names:
            names.append(selected)
        for name in names:
            self.cb_icon_pack.addItem(name, name)
        self.cb_icon_pack.setCurrentIndex(self.cb_icon_pack.findData(selected))

    def _open_minorbody_folder(self):
        folder = self._minorbody_data_dir()
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(folder))  # noqa: S606
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except Exception:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.information(
                self, self.tr("Catalog Folder"), str(folder))

    def _start_minorbody_update_check(self):
        """
        Kick off the background version check, unless one is already
        running or there is nothing installed to compare against (the
        status line already says "not installed" in that case, so a badge
        would be noise).
        """
        if getattr(self, "_mb_check_thread", None) is not None:
            if self._mb_check_thread.isRunning():
                return
        if not self.settings.value(MINORBODY_DB_PATH_KEY, "", type=str):
            cand = self._minorbody_data_dir()
            try:
                from setiastro.saspro import minorbodycatalog as mbc
                if not (cand / mbc.DEFAULT_DB_BASENAME).is_file():
                    return
            except Exception:
                return
        self._mb_check_thread = MinorBodyUpdateCheckWorker(
            self._minorbody_data_dir(), parent=self)
        self._mb_check_thread.result.connect(self._on_minorbody_update_check)
        self._mb_check_thread.finished.connect(self._mb_check_thread.deleteLater)

        def _clear():
            self._mb_check_thread = None
        self._mb_check_thread.finished.connect(_clear)
        self._mb_check_thread.start()

    def _on_minorbody_update_check(self, available: bool,
                                   remote_ver: str, local_ver: str):
        if available:
            self.lbl_minorbody_header.setText(self.tr(
                "<b>Minor-Body Catalog</b> "
                "<span style='color:#e0a030;'>— Update available ({0})</span>"
            ).format(remote_ver))
            self.lbl_minorbody_header.setToolTip(self.tr(
                "Installed: {0}   Available: {1}\n"
                "Click Download / Update Catalog to get it.").format(
                    local_ver or self.tr("unknown"), remote_ver))
            # A subtle nudge on the button itself, so someone who scrolled
            # past the header still sees there is something to do.
            self.btn_minorbody_update.setText(
                self.tr("Download / Update Catalog  ⬤"))
        else:
            self.lbl_minorbody_header.setText(self.tr("<b>Minor-Body Catalog</b>"))
            self.lbl_minorbody_header.setToolTip("")
            self.btn_minorbody_update.setText(self.tr("Download / Update Catalog"))

    def showEvent(self, event):
        super().showEvent(event)
        self._update_responsive_layout()
        # Fire-and-forget: check for a newer catalog whenever Settings
        # opens. Non-blocking, silent on failure — see the worker.
        try:
            self._start_minorbody_update_check()
        except Exception:
            pass


    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_responsive_layout()


    def _update_responsive_layout(self):
        """
        Reflow columns based on current dialog width:
        - wide: left + right columns side-by-side
        - narrow: stack right column under left column
        """
        # Tune threshold as needed; ~1180 works well for your control density
        narrow = self.width() < 1180
        mode = "stacked" if narrow else "two_col"

        if getattr(self, "_layout_mode", None) == mode:
            return
        self._layout_mode = mode

        # Clear current contents of _cols_layout without destroying widgets
        while self._cols_layout.count():
            item = self._cols_layout.takeAt(0)
            # intentionally no deleteLater; widgets/layouts are reused

        if narrow:
            stack = QVBoxLayout()
            stack.setContentsMargins(0, 0, 0, 0)
            stack.setSpacing(12)
            stack.addWidget(self._left_col_widget)
            stack.addWidget(self._right_col_widget)
            stack.addStretch(1)
            self._cols_layout.addLayout(stack, 1)
        else:
            self._cols_layout.addWidget(self._left_col_widget, 1)
            self._cols_layout.addSpacing(16)
            self._cols_layout.addWidget(self._right_col_widget, 1)

    def _color_space_label(self, key: str) -> str:
        if key == "DisplayP3":
            return self.tr("Display P3")
        if key == "AdobeRGB":
            return self.tr("Adobe RGB (1998)")
        if key == "ProPhotoRGB":
            return self.tr("ProPhoto RGB")
        if key == "sRGB":
            return self.tr("sRGB")
        return str(key)

    def _color_space_description(self, key: str) -> str:
        if key == "DisplayP3":
            return self.tr("Wide-gamut color space with D65 white point and P3 primaries.")
        if key == "AdobeRGB":
            return self.tr("Wide-gamut photography color space using Adobe RGB (1998) primaries.")
        if key == "ProPhotoRGB":
            return self.tr("Very wide-gamut color space for professional color workflows.")
        if key == "sRGB":
            return self.tr("Standard RGB color space for web sharing and broad compatibility.")
        return str(key)

    def _viewport_color_mode_label(self, key: str) -> str:
        if key == VIEWPORT_MODE_UNMANAGED:
            return self.tr("Unmanaged (Legacy)")
        if key in COLOR_SPACES:
            return self._color_space_label(key)
        return str(key)

    def _viewport_color_mode_description(self, key: str) -> str:
        if key == VIEWPORT_MODE_UNMANAGED:
            return self.tr("Legacy viewport rendering. RGB values are sent to Qt without color profile tagging or conversion.")
        if key in COLOR_SPACES:
            return self.tr(
                "Convert temporary viewport images from the working color space to {target} before display."
            ).format(target=self._color_space_label(key))
        return str(key)

    def _missing_profile_message(self, key: str) -> str:
        info = COLOR_SPACES.get(key)
        names = ", ".join(info.profile_names[:4]) if info is not None else str(key)
        dirs = "\n".join(f"- {path}" for path in get_profile_search_directories())
        return self.tr(
            "{profile} ICC profile was not found.\n\n"
            "Expected names include: {names}\n\n"
            "SASpro checks these locations:\n{dirs}\n\n"
            "Display and export tagging will fall back to sRGB until the profile is installed."
        ).format(profile=self._color_space_label(key), names=names, dirs=dirs)

    def _models_open_drive_clicked(self):
        PRIMARY_FOLDER = "https://drive.google.com/drive/folders/1-fktZb3I9l-mQimJX2fZAmJCBj_t0yAF?usp=drive_link"
        BACKUP_FOLDER  = "https://drive.google.com/drive/folders/1j46RV6touQtOmtxkhdFWGm_LQKwEpTl9?usp=drive_link"
        GITHUB_RELEASE = "https://github.com/setiastro/setiastrosuitepro/releases/tag/benchmarkFIT"

        menu = QMenu(self)
        act_primary = menu.addAction(self.tr("Primary (Google Drive)"))
        act_backup  = menu.addAction(self.tr("Backup (Google Drive)"))
        menu.addSeparator()
        act_gh      = menu.addAction(self.tr("GitHub Release Page (no quota limit)"))

        chosen = menu.exec(self.btn_models_open_drive.mapToGlobal(self.btn_models_open_drive.rect().bottomLeft()))
        if chosen == act_primary:
            webbrowser.open(PRIMARY_FOLDER)
        elif chosen == act_backup:
            webbrowser.open(BACKUP_FOLDER)
        elif chosen == act_gh:
            webbrowser.open(GITHUB_RELEASE)

    def start_models_update(self):
        self._models_update_clicked()

    def _models_install_from_zip_clicked(self):
        from PyQt6.QtWidgets import QFileDialog, QMessageBox, QProgressDialog
        from PyQt6.QtCore import Qt, QThread
        import os

        zip_path, _ = QFileDialog.getOpenFileName(
            self,
            self.tr("Select models ZIP"),
            "",
            self.tr("ZIP files (*.zip);;All files (*)")
        )
        if not zip_path:
            return

        if not os.path.exists(zip_path):
            QMessageBox.warning(self, self.tr("Models"), self.tr("File not found."))
            return

        self.btn_models_update.setEnabled(False)
        self.btn_models_install_zip.setEnabled(False)

        pd = QProgressDialog(self.tr("Preparing…"), self.tr("Cancel"), 0, 0, self)
        pd.setWindowTitle(self.tr("Installing Models"))
        pd.setWindowModality(Qt.WindowModality.ApplicationModal)
        pd.setAutoClose(True)
        pd.setMinimumDuration(0)
        pd.show()

        from setiastro.saspro.model_workers import ModelsInstallZipWorker

        self._models_thread = QThread(self)
        self._models_worker = ModelsInstallZipWorker(zip_path)
        self._models_worker.moveToThread(self._models_thread)

        self._models_thread.started.connect(self._models_worker.run, Qt.ConnectionType.QueuedConnection)
        self._models_worker.progress.connect(pd.setLabelText, Qt.ConnectionType.QueuedConnection)

        def _cancel():
            if self._models_thread.isRunning():
                self._models_thread.requestInterruption()
        pd.canceled.connect(_cancel, Qt.ConnectionType.QueuedConnection)

        def _done(ok: bool, msg: str):
            pd.reset()
            pd.deleteLater()

            self._models_thread.quit()
            self._models_thread.wait()

            self.btn_models_update.setEnabled(True)
            self.btn_models_install_zip.setEnabled(True)
            self._refresh_models_status()

            if ok:
                QMessageBox.information(self, self.tr("Models"), self.tr("✅ {0}").format(msg))
            else:
                QMessageBox.warning(self, self.tr("Models"), self.tr("❌ {0}").format(msg))

        self._models_worker.finished.connect(_done, Qt.ConnectionType.QueuedConnection)
        self._models_thread.finished.connect(self._models_worker.deleteLater, Qt.ConnectionType.QueuedConnection)
        self._models_thread.finished.connect(self._models_thread.deleteLater, Qt.ConnectionType.QueuedConnection)

        self._models_thread.start()

    def _models_update_clicked(self):
        from PyQt6.QtWidgets import QMessageBox, QProgressDialog
        from PyQt6.QtCore import Qt, QThread

        # NOTE: these must be FILE links or file IDs, not folder links.
        PRIMARY  = "https://drive.google.com/file/d/1d0wQr8Oau9UH3IalMW5anC0_oddxBjh3/view?usp=drive_link"
        BACKUP   = "https://drive.google.com/file/d/1XgqKNd8iBgV3LW8CfzGyS4jigxsxIf86/view?usp=drive_link"
        TERTIARY = "https://github.com/setiastro/setiastrosuitepro/releases/download/benchmarkFIT/SASPro_Models_AI4.zip"

        self.btn_models_update.setEnabled(False)
        self.btn_models_install_zip.setEnabled(False)  # optional but nice consistency

        pd = QProgressDialog(self.tr("Preparing…"), self.tr("Cancel"), 0, 0, self)
        pd.setWindowTitle(self.tr("Updating Models"))
        pd.setWindowModality(Qt.WindowModality.ApplicationModal)
        pd.setAutoClose(True)
        pd.setMinimumDuration(0)
        pd.show()

        from setiastro.saspro.model_workers import ModelsDownloadWorker

        self._models_thread = QThread(self)

        # Define callbacks BEFORE passing them into the worker
        def should_cancel():
            return self._models_thread.isInterruptionRequested()

        def _cancel():
            if self._models_thread.isRunning():
                self._models_thread.requestInterruption()

        WALKING_PRIMARY  = "https://drive.google.com/file/d/1yAn5gc6KVmkADvhKn-QKNNuDXSgAz1pY/view?usp=sharing"
        WALKING_BACKUP   = "https://drive.google.com/file/d/1IEB9xosEA0JPGc-L5gDfueJoFYYXN_67/view?usp=sharing"
        WALKING_TERTIARY = "https://github.com/setiastro/setiastrosuitepro/releases/download/benchmarkFIT/SASPro_Models_AI4_Walking.zip"

        CORRECT_PRIMARY  = "https://drive.google.com/file/d/11Qb6C46OlJG7rmKM-zOPCkzN4xbRsvIc/view?usp=sharing"
        CORRECT_BACKUP   = "https://drive.google.com/file/d/1XgqKNd8iBgV3LW8CfzGyS4jigxsxIf86/view?usp=sharing"
        CORRECT_TERTIARY = "https://github.com/setiastro/setiastrosuitepro/releases/download/benchmarkFIT/SASPro_Models_AI4_Correct.zip"

        CORRECT_V2_PRIMARY  = "https://drive.google.com/file/d/1HJYiYoH3r5EbFMgE6v1mRkz1_LnXuHOR/view?usp=sharing"
        CORRECT_V2_BACKUP   = "https://drive.google.com/file/d/1kquTombkmjxLPycbyYhDtap4U4IUt7Pl/view?usp=sharing"
        CORRECT_V2_TERTIARY = "https://github.com/setiastro/setiastrosuitepro/releases/download/benchmarkFIT/SASPro_Models_AI4_CorrectV2.zip"

        self._models_worker = ModelsDownloadWorker(
            PRIMARY, BACKUP, TERTIARY,
            expected_sha256=None,
            should_cancel=should_cancel,
            walking_zip_url=WALKING_PRIMARY,
            walking_zip_backup=WALKING_BACKUP,
            walking_zip_tertiary=WALKING_TERTIARY,
            correct_zip_url=CORRECT_PRIMARY,
            correct_zip_backup=CORRECT_BACKUP,
            correct_zip_tertiary=CORRECT_TERTIARY,
            correct_v2_zip_url=CORRECT_V2_PRIMARY,
            correct_v2_zip_backup=CORRECT_V2_BACKUP,
            correct_v2_zip_tertiary=CORRECT_V2_TERTIARY,
        )
        self._models_worker.moveToThread(self._models_thread)

        self._models_thread.started.connect(self._models_worker.run, Qt.ConnectionType.QueuedConnection)
        self._models_worker.progress.connect(pd.setLabelText, Qt.ConnectionType.QueuedConnection)
        pd.canceled.connect(_cancel, Qt.ConnectionType.QueuedConnection)

        def _done(ok: bool, msg: str):
            pd.reset()
            pd.deleteLater()

            self._models_thread.quit()
            self._models_thread.wait()

            self.btn_models_update.setEnabled(True)
            self.btn_models_install_zip.setEnabled(True)
            self._refresh_models_status()

            if ok:
                QMessageBox.information(self, self.tr("Models"), self.tr("✅ {0}").format(msg))
            else:
                QMessageBox.warning(self, self.tr("Models"), self.tr("❌ {0}").format(msg))

        self._models_worker.finished.connect(_done, Qt.ConnectionType.QueuedConnection)
        self._models_thread.finished.connect(self._models_worker.deleteLater, Qt.ConnectionType.QueuedConnection)
        self._models_thread.finished.connect(self._models_thread.deleteLater, Qt.ConnectionType.QueuedConnection)

        self._models_thread.start()

    def _refresh_models_status(self):
        from setiastro.saspro.model_manager import read_installed_manifest, models_root
        import os

        m = read_installed_manifest()
        models_dir = models_root()

        if not m:
            self.lbl_models_status.setText(self.tr("Status: not installed"))
            return

        src = (m.get("source") or "").strip()
        ref = (m.get("source_ref") or "").strip()
        sha = (m.get("sha256") or "").strip()

        if not src:
            src = "google_drive" if m.get("file_id") else (m.get("source") or "unknown")
        if not ref:
            ref = (m.get("file_id") or m.get("file") or "").strip()

        src_label = {
            "google_drive": "Google Drive",
            "http": "GitHub/HTTP",
            "manual_zip": "Manual ZIP",
        }.get(src, src or "Unknown")

        lines = [
            self.tr("Status: installed"),
            self.tr("Location: {0}").format(models_dir),
        ]

        if ref:
            lines.append(self.tr("Source: {0}").format(src_label))
            lines.append(self.tr("Ref: {0}").format(ref))

        if sha:
            lines.append(self.tr("SHA256: {0}").format(sha[:12] + "…"))

        # Check walking noise supplement separately (files on disk, not in manifest)
        walking_files = [
            "deep_denoise_mono_AI4_1w.pth",
            "deep_denoise_color_AI4_1w.pth",
        ]
        walking_present = all(
            os.path.exists(os.path.join(models_dir, f)) for f in walking_files
        )
        if walking_present:
            lines.append(self.tr("Walking Noise models: ✅ installed"))
        else:
            lines.append(self.tr("Walking Noise models: — not installed"))

        # Check aberration correction model
        from setiastro.saspro.model_manager import check_correct_model_available
        # Check V1 aberration correction model
        correct_v1_on_disk = os.path.exists(os.path.join(models_dir, "deep_correct_stellar_AI4.pth"))
        if correct_v1_on_disk:
            lines.append(self.tr("Aberration Correction V1 model: ✅ installed"))
        else:
            lines.append(self.tr("Aberration Correction V1 model: — not installed"))

        # Check V2 aberration correction model
        from setiastro.saspro.model_manager import check_correct_v2_model_available
        correct_v2_on_disk = os.path.exists(os.path.join(models_dir, "deep_correct_stellar_V2_AI4.pth"))
        if correct_v2_on_disk:
            lines.append(self.tr("Aberration Correction V2 model: ✅ installed"))
        else:
            correct_v2_available = check_correct_v2_model_available()
            if correct_v2_available:
                lines.append(self.tr("Aberration Correction V2 model: — not installed (available — click Download/Update Models)"))
            else:
                lines.append(self.tr("Aberration Correction V2 model: — not yet released"))

        self.lbl_models_status.setText("\n".join(lines))
        self.lbl_models_status.setStyleSheet("color:#888;")

    def _accel_pref_changed(self, idx: int):
        key = "auto"
        if 0 <= idx < len(getattr(self, "_accel_items", [])):
            key = (self._accel_items[idx][1] or "auto").lower()
        self.settings.setValue("accel/preferred_backend", key)
        self.settings.sync()


    def _show_gpu_accel_fix_help(self):
        from PyQt6.QtWidgets import QMessageBox
        QMessageBox.information(
            self, self.tr("Hardware Acceleration Help"),
            self.tr(
                "If hardware acceleration is not being used:\n"
                " • Click Install/Repair Hardware Acceleration…\n"
                " • Restart SAS Pro\n"
                " • On NVIDIA systems, verify drivers and that 'nvidia-smi' works.\n"
                " • On macOS Apple Silicon, use Auto or Apple Silicon GPU (MPS path).\n"
                " • On Linux AMD systems, select ROCm and ensure ROCm-compatible drivers/runtime are installed.\n"
                " • On Intel Arc/Xe systems, select Intel XPU.\n"
                " • On Windows non-NVIDIA, DirectML may be used.\n"
            )
        )

    def _pkg_status(self, dist_name: str, import_name: str | None = None) -> tuple[bool, str]:
        """
        Returns (installed?, display_text). Does NOT import the module.
        dist_name  = pip distribution name used for version lookup (e.g., 'torchvision')
        import_name = python import name used for find_spec (e.g., 'torch_directml')
        """
        mod = import_name or dist_name.replace("-", "_")
        present = importlib.util.find_spec(mod) is not None

        ver = ""
        if present:
            try:
                ver = importlib.metadata.version(dist_name)
            except importlib.metadata.PackageNotFoundError:
                # Sometimes dist name differs; fall back to "installed" without version
                ver = ""
            except Exception:
                ver = ""

        if present:
            return True, (f"✅ {ver}" if ver else "✅ installed")
        return False, "— not installed"


    def _format_accel_deps_text(self) -> str:
        try:
            from setiastro.saspro.runtime_torch import add_runtime_to_sys_path
            add_runtime_to_sys_path(status_cb=lambda *_: None)
        except Exception:
            pass

        torch_ok, torch_txt = self._pkg_status("torch", "torch")
        dml_ok, dml_txt     = self._pkg_status("torch-directml", "torch_directml")
        tv_ok, tv_txt       = self._pkg_status("torchvision", "torchvision")
        ta_ok, ta_txt       = self._pkg_status("torchaudio", "torchaudio")

        lines = [
            f"Torch: <b>{torch_txt}</b>",
            f"TorchVision: <b>{tv_txt}</b>",
        ]

        # torchaudio is installed best-effort and required by no SASpro tool —
        # only surface it when actually present, so its absence never reads as a
        #sasproblem (mirrors the optional Torch-DirectML line below).
        if ta_ok:
            lines.append(f"TorchAudio: <b>{ta_txt}</b>")

        if dml_ok:
            lines.append(f"Torch-DirectML: <b>{dml_txt}</b>")

        return "<br>".join(lines)

    def _run_capture(self, cmd: list[str]) -> tuple[int, str]:
        """Run a command and return (returncode, combined_output)."""
        try:
            r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            return r.returncode, (r.stdout or "")
        except Exception as e:
            return 999, str(e)

    def _probe_python_version(self, cmd: list[str]) -> tuple[bool, tuple[int, int] | None, str]:
        """
        Try to execute cmd and read sys.version_info.major/minor.
        Returns (ok, (maj,min) or None, display_string).
        """
        code = "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
        rc, out = self._run_capture(cmd + ["-c", code])
        if rc != 0:
            return False, None, (out.strip() or "failed")

        s = (out.strip().splitlines()[-1] if out.strip() else "")
        try:
            maj_s, min_s = s.split(".", 1)
            ver = (int(maj_s), int(min_s))
            return True, ver, s
        except Exception:
            return False, None, s or "unknown"

    def _find_python_cmd_for_minor(self, minor: int) -> tuple[list[str] | None, str]:
        """
        Find a runnable Python 3.minor on this system.
        Returns (cmd_list_or_None, info_string).
        Delegates to runtime_torch helper when available.
        """
        try:
            from setiastro.saspro.runtime_torch import _find_system_python_cmd_for_minor
            cmd = _find_system_python_cmd_for_minor(minor)
            if cmd:
                return cmd, f"Found: {' '.join(cmd)}"
            return None, f"python3.{minor} not found"
        except Exception as e:
            return None, f"probe error: {e}"


    def _find_python312_cmd(self) -> tuple[list[str] | None, str]:
        """
        Find a runnable Python 3.12 command on this system.
        Returns (cmd or None, info_text).
        """
        sysname = platform.system()

        # Windows: prefer py launcher
        if sysname == "Windows":
            candidates = [
                ["py", "-3.12"],
                ["python3.12"],
                ["python", "-3.12"],
            ]
            for cmd in candidates:
                ok, ver, disp = self._probe_python_version(cmd)
                if ok and ver == (3, 12):
                    return cmd, f"{' '.join(cmd)} -> {disp}"
            return None, "No runnable Python 3.12 found via 'py -3.12' or python3.12."

        # macOS: common Homebrew locations + PATH
        if sysname == "Darwin":
            candidates = [
                ["/opt/homebrew/bin/python3.12"],
                ["/usr/local/bin/python3.12"],
                ["/usr/bin/python3.12"],
                ["python3.12"],
            ]
            for cmd in candidates:
                exe = cmd[0]
                if exe.startswith("/") and not os.path.exists(exe):
                    continue
                ok, ver, disp = self._probe_python_version(cmd)
                if ok and ver == (3, 12):
                    return cmd, f"{' '.join(cmd)} -> {disp}"
            return None, "No runnable Python 3.12 found (Homebrew/PATH)."

        # Linux: exhaustive search across common install locations
        tried: list[str] = []

        # 1. Standard PATH name (apt, dnf, pacman, etc.)
        for cmd in [["python3.12"], ["python3"], ["python"]]:
            tried.append(" ".join(cmd))
            ok, ver, disp = self._probe_python_version(cmd)
            if ok and ver == (3, 12):
                return cmd, f"{' '.join(cmd)} -> {disp}"

        # 2. Common absolute paths (distro package managers)
        abs_candidates = [
            "/usr/bin/python3.12",
            "/usr/local/bin/python3.12",
            "/usr/lib/python3.12/bin/python3.12",
            "/opt/python3.12/bin/python3.12",
            "/opt/python/3.12/bin/python3.12",
        ]
        for exe in abs_candidates:
            tried.append(exe)
            if not os.path.isfile(exe):
                continue
            cmd = [exe]
            ok, ver, disp = self._probe_python_version(cmd)
            if ok and ver == (3, 12):
                return cmd, f"{exe} -> {disp}"

        # 3. pyenv shims / versions
        pyenv_root = os.environ.get("PYENV_ROOT", os.path.expanduser("~/.pyenv"))
        pyenv_shim = os.path.join(pyenv_root, "shims", "python3.12")
        if os.path.isfile(pyenv_shim):
            tried.append(pyenv_shim)
            ok, ver, disp = self._probe_python_version([pyenv_shim])
            if ok and ver == (3, 12):
                return [pyenv_shim], f"{pyenv_shim} -> {disp}"

        # Also scan pyenv versions/ directly (shim may not be set up)
        pyenv_versions = os.path.join(pyenv_root, "versions")
        if os.path.isdir(pyenv_versions):
            for entry in sorted(os.listdir(pyenv_versions)):
                if not entry.startswith("3.12"):
                    continue
                exe = os.path.join(pyenv_versions, entry, "bin", "python3.12")
                if not os.path.isfile(exe):
                    exe = os.path.join(pyenv_versions, entry, "bin", "python3")
                if not os.path.isfile(exe):
                    continue
                tried.append(exe)
                ok, ver, disp = self._probe_python_version([exe])
                if ok and ver == (3, 12):
                    return [exe], f"{exe} -> {disp}"

        # 4. conda / mamba environments
        for conda_root_var in ("CONDA_ROOT", "MAMBA_ROOT_PREFIX"):
            conda_root = os.environ.get(conda_root_var, "")
            if not conda_root:
                continue
            for env_dir in [conda_root, os.path.join(conda_root, "envs")]:
                if not os.path.isdir(env_dir):
                    continue
                for entry in sorted(os.listdir(env_dir)):
                    exe = os.path.join(env_dir, entry, "bin", "python3.12")
                    if not os.path.isfile(exe):
                        continue
                    tried.append(exe)
                    ok, ver, disp = self._probe_python_version([exe])
                    if ok and ver == (3, 12):
                        return [exe], f"{exe} -> {disp}"

        # Also check common fixed conda roots even without env vars
        for conda_root in [
            os.path.expanduser("~/miniconda3"),
            os.path.expanduser("~/anaconda3"),
            os.path.expanduser("~/mambaforge"),
            "/opt/conda",
            "/opt/miniconda3",
            "/opt/anaconda3",
        ]:
            for subpath in ["bin/python3.12", "envs"]:
                full = os.path.join(conda_root, subpath)
                if subpath == "bin/python3.12":
                    if not os.path.isfile(full):
                        continue
                    tried.append(full)
                    ok, ver, disp = self._probe_python_version([full])
                    if ok and ver == (3, 12):
                        return [full], f"{full} -> {disp}"
                elif os.path.isdir(full):
                    for entry in sorted(os.listdir(full)):
                        exe = os.path.join(full, entry, "bin", "python3.12")
                        if not os.path.isfile(exe):
                            continue
                        tried.append(exe)
                        ok, ver, disp = self._probe_python_version([exe])
                        if ok and ver == (3, 12):
                            return [exe], f"{exe} -> {disp}"

        tried_str = ", ".join(tried[:10]) + ("…" if len(tried) > 10 else "")
        return None, f"No runnable python3.12 found in PATH or common locations.\nTried: {tried_str}"

    def _gate_python_for_accel_install(self) -> bool:
        """
        Torch is imported in-process, so the runtime venv must be built with a
        Python whose major.minor matches THIS process. In a frozen build that is
        the embedded interpreter and cannot change, so a matching *system* Python
        is required to build the venv (the frozen exe can't).
        """
        from PyQt6.QtWidgets import QMessageBox
        from setiastro.saspro.runtime_torch import _SUPPORTED_PY_MINORS

        host = sys.version_info
        running = f"{host.major}.{host.minor}"
        frozen = bool(getattr(sys, "frozen", False))

        # Is the embedded/host minor one we ship wheels for at all?
        if host.major != 3 or host.minor not in _SUPPORTED_PY_MINORS:
            supported = ", ".join(f"3.{m}" for m in sorted(_SUPPORTED_PY_MINORS))
            QMessageBox.warning(
                self, self.tr("Unsupported Python Version"),
                self.tr(
                    "This build embeds Python {running}, which the GPU runtime does "
                    "not support. Supported: {supported}."
                ).format(running=running, supported=supported),
            )
            return False

        # Source run: the running interpreter builds AND imports the venv -> matches.
        if not frozen:
            return True

        # Frozen: need a SYSTEM Python 3.{host.minor} to build the venv. It must
        # match exactly — 3.13/3.14 wheels can never load into a 3.12 process.
        cmd, info = self._find_python_cmd_for_minor(host.minor)
        if cmd is not None:
            return True

        QMessageBox.warning(
            self,
            self.tr("Python {0} required for GPU acceleration").format(running),
            self.tr(
                "SAS Pro's bundled interpreter is Python {running}. The GPU runtime "
                "loads inside this same interpreter, so it must be built with a "
                "matching Python {running}. Packages built for other versions "
                "(3.13, 3.14, …) cannot load into a {running} process.\n\n"
                "No Python {running} was found on this system. Install it and relaunch:\n\n"
                "Windows:  py install {running}   (then check 'py -{running}' works)\n"
                "macOS:    brew install python@{running}\n"
                "Linux:    install python{running} from your package manager"
            ).format(running=running),
        )
        return False


    def _install_or_update_accel(self):
        # Single hard-stop gate
        if not self._gate_python_for_accel_install():
            self.backend_label.setText(self.tr("Backend: CPU (Python 3.12/3.13/3.14 required)"))
            return

        from PyQt6.QtWidgets import QMessageBox

        warn = QMessageBox(self)
        warn.setIcon(QMessageBox.Icon.Warning)
        warn.setWindowTitle(self.tr("Install GPU Acceleration"))
        warn.setText(self.tr("This process may appear stalled for several minutes."))
        warn.setInformativeText(self.tr(
            "SAS Pro is downloading and installing very large PyTorch runtime packages "
            "(often around 2.5 GB total).\n\n"
            "Do NOT close SAS Pro.\n"
            "Do NOT cancel the install.\n"
            "Do NOT force-stop the process, even if it looks hung.\n\n"
            "Interrupting installation can corrupt the runtime environment and require "
            "a full reinstall of Hardware Acceleration."
        ))
        btn_install = warn.addButton(self.tr("I Understand — Install/Repair"), QMessageBox.ButtonRole.AcceptRole)
        warn.addButton(QMessageBox.StandardButton.Cancel)
        warn.setDefaultButton(btn_install)
        warn.exec()

        if warn.clickedButton() is not btn_install:
            return

        from PyQt6.QtWidgets import QMessageBox, QProgressDialog
        from PyQt6.QtCore import Qt, QThread
        from setiastro.saspro.accel_installer import current_backend
        from setiastro.saspro.accel_workers import AccelInstallWorker

        self.install_accel_btn.setEnabled(False)
        self.backend_label.setText(self.tr("Backend: installing…"))

        # Read preference using the dynamic accel list
        pref_key = "auto"
        try:
            idx = int(self.cb_accel_pref.currentIndex())
            if 0 <= idx < len(self._accel_items):
                pref_key = (self._accel_items[idx][1] or "auto").lower()
        except Exception:
            pref_key = (self.settings.value("accel/preferred_backend", "auto", type=str) or "auto").lower()

        self._accel_pd = QProgressDialog(self)
        self._accel_pd.setWindowTitle(self.tr("Installing Hardware Acceleration — Do Not Interrupt"))
        self._accel_pd.setWindowModality(Qt.WindowModality.ApplicationModal)
        self._accel_pd.setRange(0, 0)  # busy / indeterminate
        self._accel_pd.setCancelButton(None)  # <- no cancel button
        self._accel_pd.setAutoClose(False)
        self._accel_pd.setAutoReset(False)
        self._accel_pd.setMinimumDuration(0)
        self._accel_pd.setMinimumWidth(560)

        # remove close button too
        flags = self._accel_pd.windowFlags()
        flags &= ~Qt.WindowType.WindowCloseButtonHint
        self._accel_pd.setWindowFlags(flags)

        self._accel_warning_text = self.tr(
            "⚠️ IMPORTANT:\n"
            "Do NOT close SAS Pro or interrupt this process.\n"
            "Hardware Acceleration installs very large PyTorch runtime packages and may appear hung.\n"
            "This is normal.\n\n"
        )

        self._accel_pd.setLabelText(self._accel_warning_text + self.tr("Preparing runtime…"))
        self._accel_pd.show()

        self._accel_thread = QThread(self)
        self._accel_worker = AccelInstallWorker(prefer_gpu=True, preferred_backend=pref_key)
        self._accel_worker.moveToThread(self._accel_thread)

        self._accel_thread.started.connect(self._accel_worker.run, Qt.ConnectionType.QueuedConnection)
        def _set_accel_progress(msg: str):
            if getattr(self, "_accel_pd", None):
                self._accel_pd.setLabelText(self._accel_warning_text + str(msg))

        self._accel_worker.progress.connect(_set_accel_progress, Qt.ConnectionType.QueuedConnection)

        def _done(ok: bool, msg: str):
            if getattr(self, "_accel_pd", None):
                self._accel_pd.reset()
                self._accel_pd.deleteLater()
                self._accel_pd = None

            self._accel_thread.quit()
            self._accel_thread.wait()

            self.install_accel_btn.setEnabled(True)
            self.backend_label.setText(self.tr("Backend: {0}").format(current_backend()))
            try:
                self.accel_deps_label.setText(self._format_accel_deps_text())
            except Exception:
                pass

            if ok:
                QMessageBox.information(self, self.tr("Acceleration"), self.tr("✅ {0}").format(msg))
            elif "Hardware Acceleration installed successfully" in msg:
                # Fresh install succeeded but in-process import was skipped —
                # this is expected on some Python 3.14 builds. Show as success.
                QMessageBox.information(
                    self,
                    self.tr("Acceleration"),
                    self.tr("✅ Hardware Acceleration installed successfully.\n\n"
                            "Please restart SASpro to activate GPU acceleration.")
                )
            else:
                QMessageBox.warning(self, self.tr("Acceleration"), self.tr("❌ {0}").format(msg))

        self._accel_worker.finished.connect(_done, Qt.ConnectionType.QueuedConnection)
        self._accel_thread.finished.connect(self._accel_worker.deleteLater, Qt.ConnectionType.QueuedConnection)
        self._accel_thread.finished.connect(self._accel_thread.deleteLater, Qt.ConnectionType.QueuedConnection)

        self._accel_thread.start()


    def refresh_ui(self):
        """
        Reloads all settings from self.settings and updates the UI widgets.
        Call this before showing the cached dialog to ensure it matches current state.
        """
        # Updates
        self.chk_updates_startup.setChecked(
            self.settings.value("updates/check_on_startup", True, type=bool)
        )
        self.le_updates_url.setText(
            self.settings.value(
                "updates/url",
                "https://raw.githubusercontent.com/setiastro/setiastrosuitepro/main/updates.json",
                type=str
            )
        )
        
        # Shortcuts
        # Always re-enable model buttons on refresh — guards against stuck state
        # from a previous download that crashed before its _done callback fired
        self.btn_models_update.setEnabled(True)
        self.btn_models_install_zip.setEnabled(True)

        # Shortcuts
        self.chk_save_shortcuts.setChecked(
            self.settings.value("shortcuts/save_on_exit", True, type=bool)
        )
        self.chk_open_all_hdus.setChecked(
            self.settings.value("files/open_auxiliary_images", True, type=bool)
        )
        # Default True — the smart name is almost always what the user wants.
        # Uncheck to fall back to the raw filename as the view title.
        self.chk_smart_view_naming.setChecked(
            self.settings.value("files/smart_view_naming", True, type=bool)
        )
        
        # Theme
        theme_val = (self.settings.value("ui/theme", "system", type=str) or "system").lower()
        index_map = {"dark": 0, "gray": 1, "light": 2, "system": 3, "custom": 4}
        self.cb_theme.setCurrentIndex(index_map.get(theme_val, 2))
        self.btn_theme_custom.setEnabled(theme_val == "custom")
        
        # Language
        current_lang = get_saved_language()
        try:
            lang_idx = self._lang_codes.index(current_lang)
        except ValueError:
            lang_idx = 0
            # fallback to whatever is first or default
            if "en" in self._lang_codes:
                lang_idx = self._lang_codes.index("en")
        
        self.cb_language.blockSignals(True)
        self.cb_language.setCurrentIndex(lang_idx)
        self.cb_language.blockSignals(False)
        self._initial_language = current_lang  # Track for restart notification
        
        # Path fields
        self.le_graxpert.setText(self.settings.value("paths/graxpert", "", type=str))

        self.le_starnet.setText(self.settings.value("paths/starnet", "", type=str))
        self.le_astap.setText(self.settings.value("paths/astap", "", type=str))
        self.le_astrometry.setText(self.settings.value("api/astrometry_key", "", type=str))

        # Display
        self.chk_autostretch_24bit.setChecked(
            self.settings.value("display/autostretch_24bit", True, type=bool)
        )
        self.chk_smooth_zoom_settle.setChecked(
            self.settings.value("display/smooth_zoom_settle", True, type=bool)
        )
        current_opacity = self.settings.value("display/bg_opacity", 50, type=int)
        self.slider_bg_opacity.blockSignals(True)
        self.slider_bg_opacity.setValue(current_opacity)
        self.slider_bg_opacity.blockSignals(False)
        self.lbl_bg_opacity_val.setText(f"{current_opacity}%")
        self._initial_bg_opacity = int(current_opacity) # For cancel/revert

        self.sp_icon_size.setValue(self.settings.value("toolbar/icon_size", 24, type=int))
        self._refresh_icon_packs()

        current_color_space = get_working_color_space_from_settings(self.settings)
        cs_idx = self.cb_color_space.findData(current_color_space)
        if cs_idx < 0:
            cs_idx = self.cb_color_space.findData(DEFAULT_COLOR_SPACE)
        if cs_idx >= 0:
            self.cb_color_space.setCurrentIndex(cs_idx)

        current_viewport_mode = get_viewport_color_mode_from_settings(self.settings)
        viewport_idx = self.cb_viewport_color_mode.findData(current_viewport_mode)
        if viewport_idx < 0:
            viewport_idx = self.cb_viewport_color_mode.findData(DEFAULT_VIEWPORT_MODE)
        if viewport_idx >= 0:
            self.cb_viewport_color_mode.setCurrentIndex(viewport_idx)

        # Pixel readout (loupe)
        self.chk_loupe_info.setChecked(self.settings.value("loupe/show_info", True, type=bool))
        self.sp_loupe_size.setValue(int(self.settings.value("loupe/size", 161, type=int)))
        self.sp_loupe_patch.setValue(int(self.settings.value("loupe/patch", 17, type=int)))
        self.sp_loupe_font.setValue(int(self.settings.value("loupe/info_font_pt", 10, type=int)))
        
        # Custom background
        self._initial_bg_path = self.settings.value("ui/custom_background", "", type=str) or ""
        self.le_bg_path.setText(self._initial_bg_path)
        
        # RA/Dec Overlay
        self.chk_wcs_enabled.setChecked(self.settings.value("wcs_grid/enabled", True, type=bool))
        
        self.cb_wcs_mode.blockSignals(True)
        self.cb_wcs_mode.setCurrentIndex(
            0 if (self.settings.value("wcs_grid/mode", "auto", type=str) == "auto") else 1
        )
        self.cb_wcs_mode.blockSignals(False)
        
        self.cb_wcs_unit.blockSignals(True)
        self.cb_wcs_unit.setCurrentIndex(
            0 if (self.settings.value("wcs_grid/step_unit", "deg", type=str) == "deg") else 1
        )
        self.cb_wcs_unit.blockSignals(False)
        
        self.sp_wcs_step.setValue(self.settings.value("wcs_grid/step_value", 1.0, type=float))
        self.sp_wcs_step.setEnabled(self.cb_wcs_mode.currentIndex() == 1)
        self.sp_wcs_step.setSuffix(" °" if self.cb_wcs_unit.currentIndex() == 0 else " arcmin")

        pref = (self.settings.value("accel/preferred_backend", "auto", type=str) or "auto").lower()
        idx = next((i for i, (_lbl, key) in enumerate(self._accel_items) if key == pref), 0)
        self.cb_accel_pref.setCurrentIndex(idx)

        from setiastro.saspro.accel_installer import current_backend
        self.backend_label.setText(self.tr("Backend: {0}").format(current_backend()))
        try:
            self.accel_deps_label.setText(self._format_accel_deps_text())
        except Exception:
            self.accel_deps_label.setText(self.tr("Torch: — unknown"))
        try:
            self._refresh_models_status()
        except Exception:
            pass
        try:
            self._refresh_models_status()
        except Exception:
            pass
        try:
            self._refresh_gaia_status()
        except Exception:
            pass
        try:
            self._refresh_minorbody_status()
        except Exception:
            pass
        
    def reject(self):
        """User cancelled: restore the original background opacity (revert live changes)."""
        try:
            # Restore saved original value
            self.settings.setValue("display/bg_opacity", int(self._initial_bg_opacity))
            self.settings.sync()
            # Ask parent to redraw with restored value
            parent = self.parent()
            if parent:
                # restore original custom background (may be empty)
                try:
                    # If there was an initial custom background, restore it; otherwise clear.
                    if self._initial_bg_path:
                        if hasattr(parent, "_apply_custom_background"):
                            parent._apply_custom_background(self._initial_bg_path)
                    else:
                        # Avoid calling _apply_custom_background("") which shows a warning
                        if hasattr(parent, "_clear_custom_background"):
                            parent._clear_custom_background()
                        elif hasattr(parent, "_apply_custom_background"):
                            parent._apply_custom_background("")
                except Exception:
                    pass
                # update MDI viewport/redraw
                try:
                    if hasattr(parent, "mdi") and hasattr(parent.mdi, "viewport"):
                        parent.mdi.viewport().update()
                except Exception:
                    pass
        except Exception:
            pass
        super().reject()


    # ----------------- helpers -----------------
    def _browse_into(self, lineedit: QLineEdit):
        path, _ = QFileDialog.getOpenFileName(self, "Select Executable", "", "Executables (*)")
        if path:
            lineedit.setText(path)

    def _browse_dir(self, lineedit: QLineEdit):
        path = QFileDialog.getExistingDirectory(self, "Select Folder", "")
        if path:
            lineedit.setText(path)

    def _check_updates_now_clicked(self):
        """Persist update settings, then ask the main window to run an interactive check (if available)."""
        self.settings.setValue("updates/check_on_startup", self.chk_updates_startup.isChecked())
        self.settings.setValue("updates/url", self.le_updates_url.text().strip())
        self.settings.sync()

        parent = self.parent()
        if parent and hasattr(parent, "_check_for_updates_async"):
            try:
                parent._check_for_updates_async(interactive=True)
            except Exception:
                pass

    def _choose_background_clicked(self):
        """Open a file picker and apply a custom background image for the app."""
        path, _ = QFileDialog.getOpenFileName(self, "Select background image", "", "Images (*.png *.jpg *.jpeg)")
        if not path:
            return
        try:
            # Do NOT persist yet — just update UI and preview via parent.
            self.le_bg_path.setText(path)
            parent = self.parent()
            if parent and hasattr(parent, "_apply_custom_background"):
                try:
                    parent._apply_custom_background(path)
                except Exception:
                    pass
        except Exception:
            pass

    def _clear_background_clicked(self):
        """Clear persisted custom background and ask main window to restore defaults."""
        try:
            # Do NOT modify settings yet — clear preview and let Save apply
            self.le_bg_path.setText("")
            parent = self.parent()
            if parent:
                # request parent to clear preview/background for now
                try:
                    if hasattr(parent, "_clear_custom_background"):
                        parent._clear_custom_background()
                    elif hasattr(parent, "_apply_custom_background"):
                        parent._apply_custom_background("")
                except Exception:
                    pass
        except Exception:
            pass

    def _on_theme_changed(self, idx: int):
        # Enable the "Customize…" button only when Custom is selected
        text = self.cb_theme.currentText().lower()
        self.btn_theme_custom.setEnabled(text == "custom")

    def _open_theme_editor(self):
        from PyQt6.QtWidgets import QDialog
        dlg = ThemeEditorDialog(self, self.settings)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            # If user saved a custom theme, make sure "Custom" is selected
            self.cb_theme.setCurrentIndex(4)  # Custom


    def _save_and_accept(self):
        # Paths / Integrations
        self.settings.setValue("paths/graxpert", self.le_graxpert.text().strip())

        self.settings.setValue("paths/starnet", self.le_starnet.text().strip())
        self.settings.setValue("paths/astap", self.le_astap.text().strip())
        self.settings.setValue("shortcuts/save_on_exit", self.chk_save_shortcuts.isChecked())
        self.settings.setValue("files/open_auxiliary_images", self.chk_open_all_hdus.isChecked())
        self.settings.setValue("files/smart_view_naming", self.chk_smart_view_naming.isChecked())
        self.settings.setValue("api/astrometry_key", self.le_astrometry.text().strip())

        # RA/Dec Overlay
        self.settings.setValue("wcs_grid/enabled", self.chk_wcs_enabled.isChecked())
        self.settings.setValue("wcs_grid/mode", "auto" if self.cb_wcs_mode.currentIndex() == 0 else "fixed")
        self.settings.setValue("wcs_grid/step_unit", "deg" if self.cb_wcs_unit.currentIndex() == 0 else "arcmin")
        self.settings.setValue("wcs_grid/step_value", float(self.sp_wcs_step.value()))


        # Updates + Display
        self.settings.setValue("updates/check_on_startup", self.chk_updates_startup.isChecked())
        self.settings.setValue("updates/url", self.le_updates_url.text().strip())
        self.settings.setValue("display/autostretch_24bit", self.chk_autostretch_24bit.isChecked())
        self.settings.setValue("display/smooth_zoom_settle", self.chk_smooth_zoom_settle.isChecked())

        # Pixel readout (loupe) — force odd size/patch for a symmetric crosshair
        self.settings.setValue("loupe/show_info", self.chk_loupe_info.isChecked())
        _lsz = int(self.sp_loupe_size.value())
        if _lsz % 2 == 0:
            _lsz += 1
        self.settings.setValue("loupe/size", _lsz)
        _lpatch = int(self.sp_loupe_patch.value())
        if _lpatch % 2 == 0:
            _lpatch += 1
        self.settings.setValue("loupe/patch", _lpatch)
        self.settings.setValue("loupe/info_font_pt", int(self.sp_loupe_font.value()))

        # accel preference (dynamic)
        pref_idx = int(self.cb_accel_pref.currentIndex())
        pref_key = "auto"
        if 0 <= pref_idx < len(getattr(self, "_accel_items", [])):
            pref_key = (self._accel_items[pref_idx][1] or "auto").lower()
        self.settings.setValue("accel/preferred_backend", pref_key)

        # Custom background: persist the chosen path (empty -> remove)
        bg_path = (self.le_bg_path.text() or "").strip()
        if bg_path:
            self.settings.setValue("ui/custom_background", bg_path)
        else:
            try:
                self.settings.remove("ui/custom_background")
            except Exception:
                self.settings.setValue("ui/custom_background", "")

        # bg_opacity is already saved in real-time by _on_opacity_changed()

        old_color_space = get_working_color_space_from_settings(self.settings)
        new_color_space = self.cb_color_space.currentData() or DEFAULT_COLOR_SPACE
        set_working_color_space_to_settings(new_color_space, self.settings)
        old_viewport_mode = get_viewport_color_mode_from_settings(self.settings)
        new_viewport_mode = self.cb_viewport_color_mode.currentData() or DEFAULT_VIEWPORT_MODE
        set_viewport_color_mode_to_settings(new_viewport_mode, self.settings)
        color_space_changed = new_color_space != old_color_space or new_viewport_mode != old_viewport_mode
        if new_color_space != "sRGB" and not is_profile_available(new_color_space):
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(
                self,
                self.tr("Color profile not found"),
                self._missing_profile_message(new_color_space),
            )

        # Theme
        idx = max(0, self.cb_theme.currentIndex())
        if idx == 0:
            theme_val = "dark"
        elif idx == 1:
            theme_val = "gray"
        elif idx == 2:
            theme_val = "light"
        elif idx == 3:
            theme_val = "system"
        else:
            theme_val = "custom"
        self.settings.setValue("ui/theme", theme_val)

        # Language
        lang_idx = self.cb_language.currentIndex()
        new_lang = self._lang_codes[lang_idx] if 0 <= lang_idx < len(self._lang_codes) else "en"
        save_language(new_lang)
        
        # Apply language change immediately if changed
        if new_lang != self._initial_language:
            from PyQt6.QtWidgets import QMessageBox
            
            QMessageBox.information(
                self,
                self.tr("Restart required"),
                self.tr("Language changed. Please manually restart the application to apply the new language.")
            )

        self.settings.sync()

        # Apply now if the parent knows how
        p = self.parent()
        if p and hasattr(p, "apply_theme_from_settings"):
            try:
                p.apply_theme_from_settings()
            except Exception:
                pass
        
        if hasattr(p, "mdi") and hasattr(p.mdi, "viewport"):
                p.mdi.viewport().update()
        if p and hasattr(p, "apply_display_settings_to_open_views"):
            try:
                p.apply_display_settings_to_open_views(force_rebuild=color_space_changed)
            except Exception:
                pass
        try:
            self.settings.remove("paths/cosmic_clarity")
        except Exception:
            pass

        self.settings.setValue("toolbar/icon_size", int(self.sp_icon_size.value()))

        new_icon_pack = self.cb_icon_pack.currentData()
        if new_icon_pack != get_saved_icon_pack():
            save_icon_pack(new_icon_pack)
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.information(
                self,
                self.tr("Restart required"),
                self.tr("Icon pack changed. Please restart the application to apply it.")
            )

        # Apply live
        p = self.parent()
        if p and hasattr(p, "_apply_toolbar_icon_size"):
            try:
                p._apply_toolbar_icon_size()
            except Exception:
                pass

        self.accept()

from PyQt6.QtGui import QColor, QFont


class ThemeEditorDialog(QDialog):
    """
    Simple "Custom Theme" editor: lets the user pick main colors and a UI font.
    Colors are stored in QSettings as hex strings (e.g. '#404040').
    """
    def __init__(self, parent, settings: QSettings):
        super().__init__(parent)
        self.settings = settings
        self.setWindowTitle("Custom Theme")
        self.colors: dict[str, QColor] = {}
        self.font_str: str = self.settings.value("ui/custom/font", "", type=str) or ""

        form = QFormLayout(self)

        # Helper: add color pickers for key roles
        self._add_color_picker(form, "Window / Panels",   "ui/custom/window",   QColor(40, 40, 40))
        self._add_color_picker(form, "Base (Editors)",    "ui/custom/base",     QColor(24, 24, 24))
        self._add_color_picker(form, "Alternate Base",    "ui/custom/altbase",  QColor(32, 32, 32))
        self._add_color_picker(form, "Text",              "ui/custom/text",     QColor(230, 230, 230))
        self._add_color_picker(form, "Buttons",           "ui/custom/button",   QColor(40, 40, 40))
        self._add_color_picker(form, "Highlight / Accent","ui/custom/highlight",QColor(30, 144, 255))
        self._add_color_picker(form, "Link",              "ui/custom/link",     QColor(120, 170, 255))
        self._add_color_picker(form, "Visited Link",      "ui/custom/link_visited", QColor(180, 150, 255))

        # Font picker
        self.btn_font = QPushButton("Choose…")
        self.btn_font.clicked.connect(self._pick_font)
        form.addRow("UI Font:", self.btn_font)

        # Buttons
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
            parent=self
        )
        btns.accepted.connect(self._save_and_accept)
        btns.rejected.connect(self.reject)
        form.addRow(btns)

    # ---------- helpers ----------

    def _add_color_picker(self, form: QFormLayout, label_text: str,
                          key: str, default: QColor):
        # Load from settings or default
        stored = self.settings.value(key, default.name(), type=str)
        color = QColor(stored) if stored else default
        self.colors[key] = color

        btn = QPushButton(color.name())
        btn.setMinimumWidth(90)
        btn.setStyleSheet(f"background-color: {color.name()}; color: #ffffff;")
        btn.clicked.connect(lambda _=False, k=key, b=btn: self._pick_color(k, b))

        form.addRow(label_text + ":", btn)

    def _pick_color(self, key: str, button: QPushButton):
        initial = self.colors.get(key, QColor("#404040"))
        col = QColorDialog.getColor(initial, self, "Select Color")
        if col.isValid():
            self.colors[key] = col
            button.setText(col.name())
            button.setStyleSheet(f"background-color: {col.name()}; color: #ffffff;")

    from PyQt6.QtGui import QFont
    from PyQt6.QtWidgets import QFontDialog

    def _pick_font(self):
        # Load previous font if we have one
        base_str = self.settings.value("ui/custom_font", "", type=str)
        base_font = QFont()
        if base_str:
            try:
                base_font.fromString(base_str)
            except Exception:
                pass

        # ✅ NOTE: (font, ok) — NOT (ok, font)
        font, ok = QFontDialog.getFont(base_font, self, "Select UI Font")
        if not ok:
            return  # user cancelled

        # Store and update preview
        self.font_str = font.toString()
        self.settings.setValue("ui/custom_font", self.font_str)
        self.settings.sync()

        # If you have a label/button to show the chosen font:
        try:
            self.font_button.setText(f"{font.family()}, {font.pointSize()} pt")
        except Exception:
            pass

        # Re-apply theme so the new font takes effect
        parent = self.parent()
        if parent and hasattr(parent, "apply_theme_from_settings"):
            try:
                parent.apply_theme_from_settings()
            except Exception:
                pass

    def _save_and_accept(self):
        # Persist colors
        for key, col in self.colors.items():
            self.settings.setValue(key, col.name())

        # Persist font if chosen
        if self.font_str:
            self.settings.setValue("ui/custom/font", self.font_str)

        self.settings.sync()
        self.accept()