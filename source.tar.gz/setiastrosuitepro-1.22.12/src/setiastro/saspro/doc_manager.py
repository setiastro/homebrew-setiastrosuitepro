# saspro/doc_manager.py
from __future__ import annotations
from PyQt6.QtCore import QObject, pyqtSignal, Qt, QTimer
from PyQt6.QtWidgets import QApplication, QMessageBox
import os
import re
import numpy as np
from setiastro.saspro.xisf import XISF as XISFReader
from astropy.io import fits  # local import; optional dep
from setiastro.saspro.legacy.image_manager import load_image as legacy_load_image, save_image as legacy_save_image
from setiastro.saspro.legacy.image_manager import list_fits_extensions, load_fits_extension
import uuid
from setiastro.saspro.legacy.image_manager import attach_wcs_to_metadata  # or wherever you put it
from astropy.wcs import WCS  # only if not already imported in this module
from setiastro.saspro.debug_utils import debug_dump_metadata

# Memory utilities for lazy loading and caching
try:
    from setiastro.saspro.memory_utils import get_thumbnail_cache, LazyImage
except ImportError:
    get_thumbnail_cache = None
    LazyImage = None

from setiastro.saspro.swap_manager import get_swap_manager
from setiastro.saspro.widgets.image_utils import ensure_contiguous
from typing import Any

# --- WCS DEBUGGING ------------------------------------------------------
_DEBUG_WCS = False  # flip to False when you’re done debugging

def _debug_log_wcs_context(context: str, meta_or_hdr):
    """
    Tiny helper to print key WCS bits:
      - NAXIS1/2
      - CRPIX1/2
      - CRVAL1/2
      - CDELT / CD if present
    Works if you pass either a metadata dict or a FITS-like header dict.
    """
    if not _DEBUG_WCS:
        return

    # Try to resolve a header from a metadata dict
    hdr = None
    if isinstance(meta_or_hdr, dict):
        # metadata dict with possible header keys
        hdr = (meta_or_hdr.get("original_header")
               or meta_or_hdr.get("fits_header")
               or meta_or_hdr.get("header"))
        if hdr is None:
            # maybe you passed the header dict directly
            hdr = meta_or_hdr
    else:
        hdr = meta_or_hdr

    if hdr is None:
        print(f"[WCS DEBUG] {context}: no header found")
        return

    # Normalize dict-like header
    if hasattr(hdr, "keys"):  # astropy Header or dict
        try:
            keys = list(hdr.keys())
        except Exception:
            keys = []
    else:
        print(f"[WCS DEBUG] {context}: header is non-mapping type {type(hdr)}")
        return

    def _get(k, default=None):
        try:
            return hdr.get(k, default)
        except Exception:
            try:
                return hdr[k]
            except Exception:
                return default

    naxis1 = _get("NAXIS1")
    naxis2 = _get("NAXIS2")
    crpix1 = _get("CRPIX1")
    crpix2 = _get("CRPIX2")
    crval1 = _get("CRVAL1")
    crval2 = _get("CRVAL2")

    cd11   = _get("CD1_1")
    cd12   = _get("CD1_2")
    cd21   = _get("CD2_1")
    cd22   = _get("CD2_2")
    cdelt1 = _get("CDELT1")
    cdelt2 = _get("CDELT2")

    print(f"[WCS DEBUG] {context}:")
    print(f"  NAXIS1={naxis1}  NAXIS2={naxis2}")
    print(f"  CRPIX1={crpix1}  CRPIX2={crpix2}")
    print(f"  CRVAL1={crval1}  CRVAL2={crval2}")
    if any(v is not None for v in (cd11, cd12, cd21, cd22)):
        print(f"  CD = [[{cd11}, {cd12}], [{cd21}, {cd22}]]")
    if cdelt1 is not None or cdelt2 is not None:
        print(f"  CDELT1={cdelt1}  CDELT2={cdelt2}")
    print("")

_DEBUG_UNDO = False  # set True while chasing the GraXpert crash


def _debug_log_undo(context: str, **info):
    """
    Lightweight logger for undo/redo/update activity.
    Safe: never raises, even if repr() is weird.
    """
    if not _DEBUG_UNDO:
        return
    try:
        bits = []
        for k, v in info.items():
            try:
                s = str(v)
            except Exception:
                try:
                    s = repr(v)
                except Exception:
                    s = f"<unrepr {type(v)}>"
            bits.append(f"{k}={s}")
        print(f"[UNDO DEBUG] {context}: " + ", ".join(bits))
    except Exception as e:
        # Last-resort safety – don't let logging itself kill us
        try:
            print(f"[UNDO DEBUG] {context}: <logging failed: {e}>")
        except Exception:
            pass

from setiastro.saspro.file_utils import _normalize_ext

def _normalize_image_01(arr: np.ndarray) -> np.ndarray:
    """
    Normalize an image to [0,1] in-place-ish:

      1. If min < 0  → shift so min becomes 0.
      2. Then if max > 1 → divide by max.

    NaNs/Infs are ignored when computing min/max.
    Returns float32 array.
    """
    if arr is None:
        return arr

    a = np.asarray(arr, dtype=np.float32)
    finite = np.isfinite(a)
    if not finite.any():
        # completely bogus; give back zeros
        return np.zeros_like(a, dtype=np.float32)

    # Step 1: shift up if we have negatives
    min_val = a[finite].min()
    if min_val < 0.0:
        a = a - min_val
        finite = np.isfinite(a)

    # Step 2: scale down if we exceed 1
    max_val = a[finite].max()
    if max_val > 1.0 and max_val > 0.0:
        a = a / max_val

    return a

# ---------------------------------------------------------------------
# Metadata stratification: sticky (WCS / plate-solve) and identity keys.
# ---------------------------------------------------------------------
# The undo/redo stack stores a full metadata snapshot per state, but not
# every metadata key is state-shaped. Some keys — WCS / plate-solve results
# — are "sticky": they belong to the document as a whole, not to any one
# pixel snapshot. Others — target name, acquisition time, telescope, filter
# — are "identity": they never vary with processing.
#
# When the user runs undo/redo we still restore the frozen state metadata
# from the tuple (so per-state values like step_name, _replay etc. come
# back), but we then overlay the current strata so sticky+identity keys
# survive the restore. This is what lets you plate-solve at an early undo
# state and have the WCS carry forward through redo, matching how
# PixInsight handles WCS across processing history.
#
# NOTE: geometry-changing operations (crop, rotate, resample) will need
# to transform the sticky WCS to remain valid. That is a separate
# migration step — see ImageDocument.apply_geometry_transform() for the
# entry point. Until each such tool is updated, we deliberately keep
# individual FITS WCS keys (CRPIX*, CD*_*, CRVAL*, …) OUT of the sticky
# set so that undo past a crop still restores the correct per-state
# snapshot for those cards.
_STICKY_KEYS: frozenset[str] = frozenset({
    "wcs",                    # astropy.wcs.WCS object, if cached
    "wcs_header",             # fits.Header carrying the solved WCS
    "is_solved",              # bool: plate-solve success flag
    "plate_solve_source",     # e.g. "astap", "astrometry.net"
    "plate_solve_time",       # timestamp / ISO string
    "roi_wcs_header",         # ROI-cropped WCS header (preview docs)
    "__header_snapshot__",    # JSON-safe serialised header snapshot
})

# Identity keys are matched case-insensitively against the FITS convention.
_IDENTITY_KEYS_UPPER: frozenset[str] = frozenset({
    "OBJECT", "TARGET", "OBJNAME",
    "DATE-OBS", "DATE_OBS", "DATE", "MJD-OBS", "MJD_OBS", "JD",
    "TELESCOP", "TELESCOPE", "INSTRUME", "INSTRUMENT", "DETECTOR",
    "FILTER", "FILTNAM", "FILTNAME",
    "EXPTIME", "EXPOSURE",
    "XPIXSZ", "YPIXSZ", "PIXSIZE1", "PIXSIZE2",
    "FOCALLEN",
    "GAIN", "EGAIN", "ELECTRONS", "RDNOISE", "READNOIS",
    "OFFSET", "CCDTEMP", "CCD-TEMP", "SETTEMP", "SET-TEMP",
    "RA", "DEC", "OBJCTRA", "OBJCTDEC",
    "SITELAT", "SITELONG", "SITEELEV",
    "OBSGEO-L", "OBSGEO-B", "OBSGEO-H",
    "OBSERVER", "CREATOR", "SWCREATE", "ORIGIN",
    "AIRMASS", "ALTITUDE", "AZIMUTH",
    "IMAGETYP", "FRAME", "BAYERPAT", "XBAYROFF", "YBAYROFF",
    "MOUNT",
})

# Case-sensitive SASpro identity keys (non-FITS).
_IDENTITY_KEYS_EXACT: frozenset[str] = frozenset({
    "display_name",           # user-visible title
    "file_meta",              # source-file metadata block
})


def _is_sticky_key(key) -> bool:
    """True if the metadata key represents document-level sticky state."""
    return isinstance(key, str) and key in _STICKY_KEYS


def _is_identity_key(key) -> bool:
    """True if the metadata key represents invariant document identity."""
    if not isinstance(key, str):
        return False
    if key in _IDENTITY_KEYS_EXACT:
        return True
    return key.upper() in _IDENTITY_KEYS_UPPER


# ---- Replay-capture audit (opt-in) ----------------------------------
# Finds tools that don't yet self-identify for the replay/bundle system.
#
# Flip _REPLAY_AUDIT_MODE to turn it on WITHOUT an env var:
#     ""    -> off
#     "1"   -> log only problem captures (missing / empty preset)
#     "all" -> also log OK captures
# An env var, if set, overrides the constant (handy in an IDE run config).
# Optional: set a log file path in _REPLAY_AUDIT_FILE (or the env var).
# ---- Replay-capture audit (opt-in) ----------------------------------
# Flip this to True, run SASpro, click Apply once in each tool, read console.
REPLAY_AUDIT = True   # <-- set False when done

_REPLAY_AUDIT_SEEN: set = set()

def _replay_audit(step_name, marker) -> None:
    if not REPLAY_AUDIT:
        return
    try:
        label = str(step_name or "").strip() or "<no step_name>"
        if marker is None:
            verdict, cid, detail = "NO-MARKER", "-", "no command_id and no preset recovered"
        else:
            cid = marker.get("command_id") or "-"
            if marker.get("preset"):
                verdict, detail = "OK", "captured with preset"
            elif marker.get("cid_explicit"):
                verdict, detail = "EMPTY-PRESET", "explicit command_id, empty preset (fine if parameterless)"
            else:
                verdict, detail = "NAME-ONLY", "resolved by name only, NO preset captured"

        key = (label.lower(), verdict)
        if key in _REPLAY_AUDIT_SEEN:
            return
        _REPLAY_AUDIT_SEEN.add(key)

        #print(f"[REPLAY-AUDIT] {verdict:12} cid={str(cid):22} step={label!r}  ({detail})", flush=True)
    except Exception:
        pass

_REPLAY_ROUTING_KEYS = ("command_id", "cid", "preset", "preset_dict")

def _strip_replay_keys(md):
    """Return a shallow copy of md without replay-routing keys.

    These are captured into the undo tuple's _replay marker at apply time and
    must NOT persist in live metadata — otherwise the NEXT tool (geometry,
    convo, …), which builds its edit metadata by copying doc.metadata,
    inherits a stale command_id/preset and gets mislabelled as that tool.
    """
    if not md or not any(k in md for k in _REPLAY_ROUTING_KEYS):
        return md
    clean = dict(md)
    for k in _REPLAY_ROUTING_KEYS:
        clean.pop(k, None)
    return clean

def _make_replay_marker(metadata: dict | None, step_name: str) -> dict | None:
    """
    Build a compact 'replay marker' for a just-applied edit so History Explorer
    can rebuild an exact command payload later (and so Function Bundles can be
    created from a document's history).

    Returns {"step_name", "command_id", "preset", "cid_explicit"} or None.

    Mirrors _RoiViewDocument._preview_commands capture:
      1. Prefer an explicit command_id + preset carried in the edit metadata.
      2. Otherwise recover the preset from the app's _last_headless_command,
         matching on normalized command_id (set by _handle_command_drop at the
         moment the op runs).

    The *preset* is the valuable, otherwise-unrecoverable payload we rescue.
    The command_id is best-effort; History Explorer canonicalizes it against
    its display-name table when this marker was only name-derived
    (cid_explicit=False).
    """
    try:
        from setiastro.saspro.command_ids import normalize_command_id
    except Exception:
        def normalize_command_id(s):
            return (s or "").strip().lower().replace(" ", "_")

    md = dict(metadata or {})

    explicit_cid = md.get("command_id") or md.get("cid")
    raw_cid = explicit_cid or md.get("step_name") or step_name or ""
    raw_cid = str(raw_cid).strip()
    if not raw_cid:
        return None

    cid = normalize_command_id(raw_cid)

    preset = md.get("preset") or md.get("preset_dict") or {}
    try:
        preset = dict(preset)
    except Exception:
        preset = {}

    if not preset:
        try:
            from PyQt6.QtWidgets import QApplication
            app = QApplication.instance()
            if app is not None:
                for widget in app.topLevelWidgets():
                    last = getattr(widget, "_last_headless_command", None)
                    if not isinstance(last, dict):
                        continue
                    last_cid = normalize_command_id(str(last.get("command_id") or ""))
                    if last_cid and last_cid == cid:
                        preset = dict(last.get("preset") or {})
                        break
        except Exception:
            pass
    # Only record a marker when we captured real signal: an explicit command
    # id, or a recovered preset. Otherwise leave the snapshot unmarked so the
    # legacy heuristics can still run.
    if not explicit_cid and not preset:
        return None
    return {
        "step_name": str(step_name or raw_cid),
        "command_id": cid,
        "preset": preset,
        "cid_explicit": bool(explicit_cid),
    }

_ALLOWED_DEPTHS = {
    "png":  {"8-bit"},
    "jpg":  {"8-bit"},
    "fits": ["8-bit", "16-bit", "32-bit unsigned", "32-bit floating point"],
    "fit":  ["8-bit", "16-bit", "32-bit unsigned", "32-bit floating point"],
    "tif":  {"8-bit", "16-bit", "32-bit unsigned", "32-bit floating point"},
    "xisf": {"16-bit", "32-bit unsigned", "32-bit floating point"},
    "psb":  {"16-bit", "32-bit floating point"},
    "webp": ["8-bit"],
    # SYQ Core 1: u8 / u16 / f32 (SASpro is f32-internal; no u32 or f64 export).
    "syq":  {"8-bit", "16-bit", "32-bit floating point"},
}

class TableDocument(QObject):
    changed = pyqtSignal()

    def __init__(self, rows: list[list], headers: list[str], metadata: dict | None = None, parent=None):
        super().__init__(parent)
        self.rows = rows              # list of list (2D) for QAbstractTableModel
        self.headers = headers        # list of column names
        self.metadata = dict(metadata or {})
        self._undo = []
        self._redo = []

    def display_name(self) -> str:
        dn = self.metadata.get("display_name")
        if dn:
            return dn
        p = self.metadata.get("file_path")
        return os.path.basename(p) if p else "Untitled Table"

    def can_undo(self) -> bool: return False
    def can_redo(self) -> bool: return False
    def last_undo_name(self) -> str | None: return None
    def last_redo_name(self) -> str | None: return None
    def undo(self) -> str | None: return None
    def redo(self) -> str | None: return None

class ImageDocument(QObject):
    changed = pyqtSignal()

    def __init__(self, image: np.ndarray, metadata: dict | None = None, parent=None):
        super().__init__(parent)
        self.image = image
        self.metadata = dict(metadata or {})
        self.mask = None
        # _undo / _redo now store tuples: (swap_id: str, metadata: dict, step_name: str)
        self._undo: list[tuple[str, dict, str]] = []
        self._redo: list[tuple[str, dict, str]] = []        
        self.masks: dict[str, np.ndarray] = {}
        self.active_mask_id: str | None = None
        self.uid = uuid.uuid4().hex  # stable identity for DnD, layers, masks, etc.

        # NEW: operation log — list of simple dicts
        # Each entry: {
        #   "id": str,
        #   "step": str,
        #   "params": dict,
        #   "roi": (x,y,w,h) | None,
        #   "source": "full" | "roi",
        #   "ts": float
        # }
        self._op_log: list[dict] = []
        # Playhead index into _op_log. Points at the position where the NEXT
        # recorded op will land. undo/redo move it back/forward; a new edit
        # from a mid-log position truncates the "future" branch (matching the
        # linear-undo model already used for _redo).
        self._op_log_playhead: int = 0

        # ---- Stratified metadata stores -------------------------------
        # These hold WCS / plate-solve data (_sticky_meta) and acquisition
        # invariants (_identity_meta) independently of the per-state undo
        # snapshots, so plate-solve results survive undo/redo across
        # WCS-invariant operations (color cal, sharpen, denoise, star
        # removal, stretch, …). See _sync_strata_from_metadata /
        # _overlay_strata_onto_metadata below.
        self._sticky_meta: dict = {}
        self._identity_meta: dict = {}
        #saspromote anything the caller already put in metadata (e.g. from a
        # freshly-loaded file: OBJECT, DATE-OBS, wcs_header, …).
        try:
            self._sync_strata_from_metadata()
        except Exception:
            pass

        # Track unsaved changes explicitly
        self.dirty: bool = False
        
        # Copy-on-write support: if this document shares image data with another,
        # _cow_source holds reference to the source. On first write (apply_edit),
        # we copy the image data and clear _cow_source.
        self._cow_source: 'ImageDocument | None' = None
    # --- history helpers (NEW) ---
    # --- operation log helpers (NEW) -----------------------------------
    def record_operation(
        self,
        step_name: str,
        params: dict | None = None,
        roi: tuple[int, int, int, int] | None = None,
        source: str = "full",
    ) -> str:
        """
        Append a param-record for this edit. This is *lightweight* metadata
        used for replaying ROI recipes etc; it does NOT affect undo/redo.

        Honours _op_log_playhead: if the playhead is behind the log tail
        (user is mid-undo), the "future" branch is truncated first — the
        same linear-undo model that apply_edit uses for _redo.
        """
        import time as _time
        # Truncate the future branch if we were mid-log after undo.
        ph = max(0, min(self._op_log_playhead, len(self._op_log)))
        if ph < len(self._op_log):
            del self._op_log[ph:]
        op_id = uuid.uuid4().hex
        entry = {
            "id": op_id,
            "step": step_name or "Edit",
            "params": _dm_json_sanitize(params or {}),
            "roi": tuple(roi) if roi else None,
            "source": str(source or "full"),
            "ts": float(_time.time()),
        }
        self._op_log.append(entry)
        self._op_log_playhead = len(self._op_log)
        return op_id

    def get_operation_log(self) -> list[dict]:
        """
        Return a copy of the operation log, respecting the undo/redo
        playhead — entries beyond the playhead are the "future" branch
        that would be discarded on the next edit and are hidden from the
        default view. Use get_full_operation_log() to see everything.
        """
        ph = max(0, min(self._op_log_playhead, len(self._op_log)))
        return list(self._op_log[:ph])

    def get_full_operation_log(self) -> list[dict]:
        """Return the full log including entries past the playhead."""
        return list(self._op_log)

    def clear_operation_log(self):
        """Clear the operation log (does not touch pixel history)."""
        self._op_log.clear()
        self._op_log_playhead = 0

    # --- metadata strata helpers (WCS / plate-solve survival) ----------
    def _sync_strata_from_metadata(self, source: dict | None = None):
        """
        Scan `source` (default: self.metadata) and promote any sticky /
        identity keys into the corresponding stratum store. Safe to call
        multiple times; safe on partial dicts (e.g. the incoming metadata=
        arg of apply_edit).

        Tools that mutate self.metadata directly (bypassing apply_edit)
        can call sync_strata_from_metadata() to make sure their sticky /
        identity keys are captured before the next undo/redo.
        """
        src = source if source is not None else getattr(self, "metadata", None)
        if not isinstance(src, dict):
            return
        for k, v in src.items():
            if _is_sticky_key(k):
                self._sticky_meta[k] = v
            elif _is_identity_key(k):
                self._identity_meta[k] = v

    def sync_strata_from_metadata(self):
        """Public alias for _sync_strata_from_metadata."""
        self._sync_strata_from_metadata()

    def _overlay_strata_onto_metadata(self):
        """
        Overlay identity then sticky onto self.metadata. Called after
        undo/redo restores a frozen snapshot — so document-level keys
        survive the restore. Sticky wins over identity where they overlap
        (they should be disjoint sets, but sticky is 'more current'
        semantically).
        """
        if not isinstance(getattr(self, "metadata", None), dict):
            return
        if self._identity_meta:
            for k, v in self._identity_meta.items():
                self.metadata[k] = v
        if self._sticky_meta:
            for k, v in self._sticky_meta.items():
                self.metadata[k] = v

    def set_wcs(self, hdr_like, *, source: str | None = None, wcs_obj=None):
        """
        Attach a plate-solve result to this document as sticky metadata.

        `hdr_like` should be a fits.Header (or a plain dict of WCS keys),
        `wcs_obj` optionally an astropy.wcs.WCS. The result is stored in
        _sticky_meta so it will survive undo/redo across WCS-invariant
        operations. Also mirrored to self.metadata so current code paths
        that read doc.metadata["wcs_header"] etc. see it immediately.
        """
        if hdr_like is None and wcs_obj is None:
            return
        if hdr_like is not None:
            self._sticky_meta["wcs_header"] = hdr_like
        if wcs_obj is not None:
            self._sticky_meta["wcs"] = wcs_obj
        self._sticky_meta["is_solved"] = True
        if source:
            self._sticky_meta["plate_solve_source"] = source
        # Mirror to live self.metadata for immediate consumers.
        md = getattr(self, "metadata", None)
        if isinstance(md, dict):
            if hdr_like is not None:
                md["wcs_header"] = hdr_like
            if wcs_obj is not None:
                md["wcs"] = wcs_obj
            md["is_solved"] = True
            if source:
                md["plate_solve_source"] = source
        try:
            self.changed.emit()
        except Exception:
            pass

    def clear_wcs(self):
        """Drop sticky WCS (for operations that fundamentally invalidate it)."""
        _keys = ("wcs", "wcs_header", "is_solved",
                 "plate_solve_source", "plate_solve_time",
                 "__header_snapshot__")
        for k in _keys:
            self._sticky_meta.pop(k, None)
            md = getattr(self, "metadata", None)
            if isinstance(md, dict):
                md.pop(k, None)

    def apply_geometry_transform(self, wcs_transform):
        """
        Entry point for crop / rotate / resample tools to keep the sticky
        WCS valid across a geometry change.

        `wcs_transform` is a callable taking the current sticky WCS
        payload (dict or fits.Header) and returning the new one, e.g.::

            def crop_transform(hdr):
                new = dict(hdr) if not hasattr(hdr, 'copy') else hdr.copy()
                new['CRPIX1'] = float(new.get('CRPIX1', 0)) - x_offset
                new['CRPIX2'] = float(new.get('CRPIX2', 0)) - y_offset
                return new

        NOTE: this is a stub for the WCS_TRANSFORM migration described in
        the stratification design. Once a tool implements it, the
        (before, after) pair should also be recorded on the tool's undo
        record so undo/redo can invert the transform. Until then, undo
        past a geometry change may leave the sticky WCS reflecting the
        post-transform pixel grid — the same class of bug as today.
        """
        if not callable(wcs_transform):
            return
        for key in ("wcs_header", "wcs", "roi_wcs_header"):
            if key in self._sticky_meta:
                try:
                    new_val = wcs_transform(self._sticky_meta[key])
                    if new_val is not None:
                        self._sticky_meta[key] = new_val
                        md = getattr(self, "metadata", None)
                        if isinstance(md, dict):
                            md[key] = new_val
                except Exception as e:
                    print(f"[ImageDocument] geometry transform failed for {key}: {e}")


    def can_undo(self) -> bool:
        return bool(self._undo)

    def can_redo(self) -> bool:
        return bool(self._redo)

    def last_undo_name(self) -> str | None:
        return self._undo[-1][2] if self._undo else None

    def last_redo_name(self) -> str | None:
        return self._redo[-1][2] if self._redo else None


    def add_mask(self, mask: Any, mask_id: str | None = None, make_active: bool = True) -> str:
        """
        Store a mask on this document.

        - `mask` can be a numpy array or any mask-like object.
        - If `mask_id` is None, a random UUID is generated.
        - Returns the mask_id used.
        """
        if mask_id is None:
            mask_id = getattr(mask, "id", None) or uuid.uuid4().hex

        # If it's an array, normalize to float32; otherwise just store as-is.
        try:
            arr = np.asarray(mask, dtype=np.float32)
            self.masks[mask_id] = arr
        except Exception:
            self.masks[mask_id] = mask

        if make_active:
            self.active_mask_id = mask_id

        return mask_id

    def remove_mask(self, mask_id: str):
        self.masks.pop(mask_id, None)
        if self.active_mask_id == mask_id:
            self.active_mask_id = None

    def get_active_mask(self):
        return self.masks.get(self.active_mask_id) if self.active_mask_id else None

    def close(self):
        """
        Free all resources held by this document:
        - delete swap states for undo/redo
        - clear undo/redo stacks
        - drop in-memory image array and any in-memory history
        - clear heavy metadata (headers/WCS)
        - clear any cached previews/pixmaps
        - disconnect signals to help break reference cycles
        """
        # --- 0) Stop emitting while we tear down (best-effort) --------------
        try:
            self.blockSignals(True)
        except Exception:
            pass

        # --- 1) Swap cleanup (your existing logic) --------------------------
        try:
            sm = get_swap_manager()
        except Exception:
            sm = None

        # Undo stack
        try:
            for item in list(getattr(self, "_undo", [])):
                try:
                    swap_id = item[0]  # (swap_id, ..., ...)
                except Exception:
                    swap_id = None
                if sm is not None and swap_id is not None:
                    try:
                        sm.delete_state(swap_id)
                    except Exception:
                        pass
            getattr(self, "_undo", []).clear()
        except Exception:
            pass

        # Redo stack
        try:
            for item in list(getattr(self, "_redo", [])):
                try:
                    swap_id = item[0]
                except Exception:
                    swap_id = None
                if sm is not None and swap_id is not None:
                    try:
                        sm.delete_state(swap_id)
                    except Exception:
                        pass
            getattr(self, "_redo", []).clear()
        except Exception:
            pass

        # ROI preview stacks if you have them (your code uses _pundo/_predo on ROI docs)
        for attr in ("_pundo", "_predo"):
            try:
                lst = getattr(self, attr, None)
                if isinstance(lst, list):
                    # If these also store swap states, delete them too (safe even if not)
                    if sm is not None:
                        for item in list(lst):
                            try:
                                swap_id = item[0]
                            except Exception:
                                swap_id = None
                            if swap_id is not None:
                                try:
                                    sm.delete_state(swap_id)
                                except Exception:
                                    pass
                    lst.clear()
            except Exception:
                pass

        # --- 2) Drop the big in-memory image --------------------------------
        # This is what actually frees the 2–10GB allocations (assuming no other refs).
        try:
            self.image = None
        except Exception:
            pass

        # --- 3) Clear metadata that can keep large objects alive -------------
        # fits.Header/WCS objects aren't huge like the image, but they can keep references
        # and add up; also helps break cycles.
        try:
            md = getattr(self, "metadata", None)
            if isinstance(md, dict):
                for k in ("wcs", "original_header", "fits_header", "wcs_header", "header"):
                    md.pop(k, None)
                # If you keep derived/cached headers anywhere:
                for k in ("_header_snapshot", "_wcs_snapshot", "roi_wcs_header"):
                    md.pop(k, None)
        except Exception:
            pass

        # --- 4) Clear any preview/pixmap/qimage caches -----------------------
        # Adjust these attr names to match what your view/doc uses.
        for attr in ("_qimage_cache", "_pixmap_cache", "_preview_cache", "_render_cache"):
            try:
                v = getattr(self, attr, None)
                if isinstance(v, dict):
                    v.clear()
                setattr(self, attr, None)
            except Exception:
                pass

        # --- 5) Disconnect signals (helps Qt reference cycles) ---------------
        # If you connect doc.changed to closures (like ROI docs do), this helps.
        try:
            self.changed.disconnect()
        except Exception:
            pass

        # If you have other signals, disconnect them similarly:
        for sig_name in ("imageChanged", "metadataChanged"):
            try:
                sig = getattr(self, sig_name, None)
                if sig is not None:
                    sig.disconnect()
            except Exception:
                pass

        # --- 6) Allow signals again (optional) -------------------------------
        try:
            self.blockSignals(False)
        except Exception:
            pass


    def __del__(self):
        # Fallback cleanup if close() wasn't called (though explicit close is better)
        try:
            self.close()
        except Exception:
            pass


    # in class ImageDocument
    def apply_edit(self, new_image: np.ndarray, metadata: dict | None = None, step_name: str = "Edit"):
        """
        Smart edit:
        - If this is an ROI view (has _roi_info), paste back into parent and emit region update.
        - Else: push history on self and emit full-image update.
        - IMPORTANT: merge metadata without nuking FITS/WCS headers.
        """
        import numpy as np

        def _merge_meta(old_meta: dict | None, new_meta: dict | None, step_name: str):
            """
            Merge new_meta into old_meta but preserve critical header fields
            unless they are explicitly overridden with non-None values.
            """
            old = dict(old_meta or {})
            incoming = dict(new_meta or {})

            critical_keys = (
                "original_header",
                "fits_header",
                "wcs_header",
                "file_meta",
                "image_meta",
            )

            # Preserve critical keys unless caller *deliberately* overrides
            for k in critical_keys:
                if k in incoming:
                    if incoming[k] is not None:
                        old[k] = incoming[k]
                # if not in incoming → leave old value alone

            # Merge all remaining keys normally
            for k, v in incoming.items():
                if k in critical_keys:
                    continue
                old[k] = v

            if step_name:
                old.setdefault("step_name", step_name)
            return old

        # ------ ROI-aware branch (auto-pasteback) ------
        roi_info = getattr(self, "_roi_info", None)
        if roi_info:
            parent = roi_info.get("parent_doc")
            roi = roi_info.get("roi")
            if isinstance(parent, ImageDocument) and (getattr(parent, "image", None) is not None) and roi:
                x, y, w, h = map(int, roi)

                img = np.asarray(new_image)
                if img.dtype != np.float32:
                    img = img.astype(np.float32, copy=False)

                base = np.asarray(parent.image)
                if img.shape[:2] != (h, w):
                    raise ValueError(f"Edited preview shape {img.shape[:2]} does not match ROI {(h, w)}")

                # shape reconciliation
                if base.ndim == 2 and img.ndim == 3 and img.shape[2] == 1:
                    img = img[..., 0]
                if base.ndim == 3 and img.ndim == 2:
                    img = np.repeat(img[..., None], base.shape[2], axis=2)

                new_full = base.copy()
                new_full[y:y + h, x:x + w] = img

                # NEW: capture any sticky/identity keys the caller may have
                # written directly to parent.metadata since the last edit
                # (e.g. a plate solve) BEFORE we snapshot for undo, so they
                # don't get lost when future undos restore this snapshot.
                try:
                    if hasattr(parent, "_sync_strata_from_metadata"):
                        parent._sync_strata_from_metadata()
                except Exception:
                    pass

                # push onto the PARENT’s history
                if metadata:
                    parent.metadata = _merge_meta(parent.metadata, _strip_replay_keys(metadata), step_name)
                else:
                    parent.metadata.setdefault("step_name", step_name)

                # NEW: promote sticky/identity keys just merged in from the
                # incoming metadata (e.g. wcs_header from plate solve, or
                # DATE-OBS refreshed from a fresh header).
                try:
                    if hasattr(parent, "_sync_strata_from_metadata"):
                        parent._sync_strata_from_metadata()
                except Exception:
                    pass

                sm = get_swap_manager()
                sid = sm.save_state(parent.image)
                if sid:
                    _meta_snap = parent.metadata.copy()
                    _rp = _make_replay_marker(metadata, step_name)
                    _replay_audit(step_name, _rp)
                    if _rp is not None:
                        _meta_snap["_replay"] = _rp
                    else:
                        _meta_snap.pop("_replay", None)
                    parent._undo.append((sid, _meta_snap, step_name))
                    sm.pin_state(sid)
                    parent._pin_last_undos(keep=5)

                # Clear redo stack and delete files (unpin first)
                for old_sid, _, _ in parent._redo:
                    sm.unpin_state(old_sid)
                    sm.delete_state(old_sid)
                parent._redo.clear()

                parent.image = new_full
                parent.dirty = True
                parent.changed.emit()

                #dm = getattr(self, "_doc_manager", None) or getattr(parent, "_doc_manager", None)
                #try:
                #    if dm is not None and hasattr(dm, "imageRegionUpdated"):
                #        dm.imageRegionUpdated.emit(parent, (x, y, w, h))
                #except Exception:
                #    print(f"[DocManager] Failed to emit imageRegionUpdated for ROI.")
                return  # done

        # ------ Normal (full-image) branch ------

        # Copy-on-write
        if self._cow_source is not None and self.image is not None:
            self.image = self.image.copy()
            self._cow_source = None

        if self.image is not None:
            # NEW: capture any sticky/identity keys the caller wrote
            # directly to self.metadata since the last edit (e.g. a plate
            # solve that bypasses apply_edit) BEFORE we snapshot for undo.
            # Without this, the snapshot below is fine but future undos
            # that restore it would not preserve the newly-set sticky keys.
            try:
                self._sync_strata_from_metadata()
            except Exception:
                pass

            # snapshot current image + metadata for undo
            try:
                curr = np.asarray(self.image, dtype=np.float32)
                curr = ensure_contiguous(curr)

                sm = get_swap_manager()
                sid = sm.save_state(curr)

                _debug_log_undo(
                    "ImageDocument.apply_edit.snapshot",
                    doc_id=id(self),
                    name=getattr(self, "display_name", lambda: "<no-name>")(),
                    curr_shape=getattr(curr, "shape", None),
                    undo_len_before=len(self._undo),
                    redo_len_before=len(self._redo),
                    step_name=step_name,
                    swap_id=sid
                )
                if sid:
                    _meta_snap = self.metadata.copy()
                    _rp = _make_replay_marker(metadata, step_name)
                    _replay_audit(step_name, _rp)
                    if _rp is not None:
                        _meta_snap["_replay"] = _rp
                    else:
                        _meta_snap.pop("_replay", None)
                    self._undo.append((sid, _meta_snap, step_name))
                    sm.pin_state(sid)
                    self._pin_last_undos(keep=5)
            except Exception as e:
                print(f"[ImageDocument] apply_edit: failed to snapshot current image for undo: {e}")

            # Clear redo stack and delete files (unpin first)
            sm = get_swap_manager()
            for old_sid, _, _ in self._redo:
                sm.unpin_state(old_sid)
                sm.delete_state(old_sid)
            self._redo.clear()

        # --- header-safe metadata merge ---
        if metadata:
            self.metadata = _merge_meta(self.metadata, _strip_replay_keys(metadata), step_name)
        else:
            self.metadata.setdefault("step_name", step_name)

        # NEW: promote sticky/identity keys just merged in from the incoming
        # metadata. This is how, e.g., plate-solve results delivered via
        # apply_edit(metadata={"wcs_header": hdr, ...}) end up in
        # _sticky_meta and survive later undo/redo.
        try:
            self._sync_strata_from_metadata()
        except Exception:
            pass

        # normalize new image
        img = np.asarray(new_image, dtype=np.float32)
        if img.size == 0:
            raise ValueError("apply_edit: new image is empty")

        img = ensure_contiguous(img)

        _debug_log_undo(
            "ImageDocument.apply_edit.apply",
            doc_id=id(self),
            name=getattr(self, "display_name", lambda: "<no-name>")(),
            new_shape=getattr(img, "shape", None),
            undo_len_after=len(self._undo),
            redo_len_after=len(self._redo),
            step_name=step_name,
        )

        self.image = img
        self.dirty = True
        self.changed.emit()

        #dm = getattr(self, "_doc_manager", None)
        #try:
        #    if dm is not None and hasattr(dm, "imageRegionUpdated"):
        #        dm.imageRegionUpdated.emit(self, None)
        #except Exception:
        #    pass


    def undo(self) -> str | None:
        # Extra-safe: if stack is empty, bail early.
        if not self._undo:
            _debug_log_undo(
                "ImageDocument.undo.empty_stack",
                doc_id=id(self),
                name=getattr(self, "display_name", lambda: "<no-name>")(),
            )
            return None

        _debug_log_undo(
            "ImageDocument.undo.entry",
            doc_id=id(self),
            name=getattr(self, "display_name", lambda: "<no-name>")(),
            undo_len=len(self._undo),
            redo_len=len(self._redo),
            top_step=self._undo[-1][2] if self._undo else None,
        )

        sm = get_swap_manager()

        # NEW: capture any sticky/identity keys currently in self.metadata
        # (including anything a tool set directly since the last apply_edit
        # — e.g. plate solve) so they get promoted to _sticky_meta /
        # _identity_meta BEFORE we blow away self.metadata with a frozen
        # snapshot below.
        try:
            self._sync_strata_from_metadata()
        except Exception:
            pass

        # Pop with an extra guard in case something cleared _undo between
        # the check above and this call (re-entrancy / threading).
        try:
            prev_sid, prev_meta, name = self._undo.pop()
        except IndexError:
            _debug_log_undo(
                "ImageDocument.undo.pop_index_error",
                doc_id=id(self),
                name=getattr(self, "display_name", lambda: "<no-name>")(),
                undo_len=len(self._undo),
                redo_len=len(self._redo),
            )
            return None

        # Consume previous image from swap (exactly once)
        sm.unpin_state(prev_sid)
        prev_img = sm.load_state(prev_sid)
        sm.delete_state(prev_sid)

        # Re-pin last N undos after pop
        self._pin_last_undos(keep=5)

        if prev_img is None:
            print(f"[ImageDocument] undo: failed to load swap state {prev_sid}")
            return None

        # Normalize previous image before using it
        import numpy as np
        try:
            prev_arr = np.asarray(prev_img, dtype=np.float32)
            if prev_arr.size == 0:
                raise ValueError("undo: previous image is empty")
            prev_arr = np.ascontiguousarray(prev_arr)
        except Exception as e:
            print(f"[ImageDocument] undo: invalid prev_img in stack ({type(prev_img)}): {e}")
            return None

        _debug_log_undo(
            "ImageDocument.undo.normalized_prev",
            doc_id=id(self),
            name=getattr(self, "display_name", lambda: "<no-name>")(),
            prev_shape=getattr(prev_arr, "shape", None),
            prev_dtype=getattr(prev_arr, "dtype", None),
            step_name=name,
            meta_step=prev_meta.get("step_name", None) if isinstance(prev_meta, dict) else None,
        )

        # Snapshot current state for redo (best-effort)
        curr_img = self.image
        curr_meta = self.metadata
        try:
            if curr_img is not None:
                curr_arr = np.asarray(curr_img, dtype=np.float32)
                curr_arr = np.ascontiguousarray(curr_arr)

                # Save to swap for Redo
                sid = sm.save_state(curr_arr)
                if sid:
                    self._redo.append((sid, dict(curr_meta), name))
                    # optional: pin redo states if you want them extra snappy
                    # sm.pin_state(sid)
            else:
                pass
        except Exception as e:
            print(f"[ImageDocument] undo: failed to snapshot current image for redo: {e}")

        _debug_log_undo(
            "ImageDocument.undo.before_apply",
            doc_id=id(self),
            name=getattr(self, "display_name", lambda: "<no-name>")(),
            curr_shape=getattr(curr_img, "shape", None) if curr_img is not None else None,
            curr_dtype=getattr(curr_img, "dtype", None) if curr_img is not None else None,
        )

        self.image = prev_arr
        self.metadata = dict(prev_meta or {})
        # NEW: overlay sticky (WCS / plate-solve) and identity keys so they
        # survive the snapshot restore. This is what makes plate-solve
        # results carry through undo/redo across WCS-invariant operations.
        try:
            self._overlay_strata_onto_metadata()
        except Exception:
            pass
        # NEW: move op-log playhead back one step (bounded at 0).
        if self._op_log_playhead > 0:
            self._op_log_playhead -= 1
        self.dirty = True
        try:
            self.changed.emit()
        except Exception:
            pass

        _debug_log_undo(
            "ImageDocument.undo.after_apply",
            doc_id=id(self),
            name=getattr(self, "display_name", lambda: "<no-name>")(),
            new_shape=getattr(self.image, "shape", None),
            new_dtype=getattr(self.image, "dtype", None),
            undo_len=len(self._undo),
            redo_len=len(self._redo),
        )
        return name


    def redo(self) -> str | None:
        if not self._redo:
            return None

        _debug_log_undo(
            "ImageDocument.redo.entry",
            doc_id=id(self),
            name=getattr(self, "display_name", lambda: "<no-name>")(),
            redo_len=len(self._redo),
            undo_len=len(self._undo),
            top_step=self._redo[-1][2] if self._redo else None,
        )

        sm = get_swap_manager()

        # NEW: capture any sticky/identity keys currently in self.metadata
        # (e.g. a plate solve done at this intermediate state) before we
        # overwrite self.metadata with the redo snapshot below.
        try:
            self._sync_strata_from_metadata()
        except Exception:
            pass

        nxt_sid, nxt_meta, name = self._redo.pop()

        # Consume next image from swap (exactly once)
        sm.unpin_state(nxt_sid)
        nxt_img = sm.load_state(nxt_sid)
        sm.delete_state(nxt_sid)

        if nxt_img is None:
            print(f"[ImageDocument] redo: failed to load swap state {nxt_sid}")
            return None

        # Normalize next image before using it
        import numpy as np
        try:
            nxt_arr = np.asarray(nxt_img, dtype=np.float32)
            if nxt_arr.size == 0:
                raise ValueError("redo: next image is empty")
            nxt_arr = np.ascontiguousarray(nxt_arr)
        except Exception as e:
            print(f"[ImageDocument] redo: invalid nxt_img in stack ({type(nxt_img)}): {e}")
            return None

        _debug_log_undo(
            "ImageDocument.redo.normalized_next",
            doc_id=id(self),
            name=getattr(self, "display_name", lambda: "<no-name>")(),
            nxt_shape=getattr(nxt_arr, "shape", None),
            nxt_dtype=getattr(nxt_arr, "dtype", None),
            step_name=name,
            meta_step=nxt_meta.get("step_name", None) if isinstance(nxt_meta, dict) else None,
        )

        # Snapshot current state for undo (best-effort)
        curr_img = self.image
        curr_meta = self.metadata
        try:
            if curr_img is not None:
                curr_arr = np.asarray(curr_img, dtype=np.float32)
                curr_arr = np.ascontiguousarray(curr_arr)

                # Save current to swap for Undo
                sid = sm.save_state(curr_arr)
                if sid:
                    self._undo.append((sid, dict(curr_meta), name))
                    sm.pin_state(sid)
            else:
                pass
        except Exception as e:
            print(f"[ImageDocument] redo: failed to snapshot current image for undo: {e}")

        # Re-pin last N undos after pushing
        self._pin_last_undos(keep=5)

        _debug_log_undo(
            "ImageDocument.redo.before_apply",
            doc_id=id(self),
            name=getattr(self, "display_name", lambda: "<no-name>")(),
            curr_shape=getattr(curr_img, "shape", None) if curr_img is not None else None,
            curr_dtype=getattr(curr_img, "dtype", None) if curr_img is not None else None,
        )

        self.image = nxt_arr
        self.metadata = dict(nxt_meta or {})
        # NEW: overlay sticky/identity so plate-solve results and identity
        # keys survive the snapshot restore on redo.
        try:
            self._overlay_strata_onto_metadata()
        except Exception:
            pass
        # NEW: advance op-log playhead (bounded at len(_op_log)).
        if self._op_log_playhead < len(self._op_log):
            self._op_log_playhead += 1
        self.dirty = True
        try:
            self.changed.emit()
        except Exception:
            pass

        _debug_log_undo(
            "ImageDocument.redo.after_apply",
            doc_id=id(self),
            name=getattr(self, "display_name", lambda: "<no-name>")(),
            new_shape=getattr(self.image, "shape", None),
            new_dtype=getattr(self.image, "dtype", None),
            undo_len=len(self._undo),
            redo_len=len(self._redo),
        )

        return name

    def _pin_last_undos(self, keep: int = 5):
        sm = get_swap_manager()

        # Pin the last `keep` undo swap_ids (most recent)
        undo = list(getattr(self, "_undo", []))
        for i, item in enumerate(undo):
            sid = item[0] if item else None
            if not sid:
                continue
            if i >= len(undo) - keep:
                sm.pin_state(sid)
            else:
                sm.unpin_state(sid)

    # existing methods unchanged below...
    def set_image(self, img: np.ndarray, metadata: dict | None = None, step_name: str = "Edit"):
        """
        Treat set_image as an editing operation that records history.
        (History previews and “Restore from History” call this.)
        """
        self.apply_edit(img, metadata or {}, step_name=step_name)

    
    # --- Add to ImageDocument (public history helpers) -------------------

    def get_undo_stack(self):
        """
        Oldest → newest *before* current image.
        Returns [(swap_id, meta, name), ...]
        """
        out = []
        for sid, meta, name in self._undo:
            out.append((sid, meta or {}, name or "Unnamed"))
        return out

    def display_name(self) -> str:
        # Prefer an explicit display name if set
        dn = self.metadata.get("display_name")
        if dn:
            return dn
        p = self.metadata.get("file_path")
        return os.path.basename(p) if p else "Untitled"


def _dm_json_sanitize(obj):
    """Tiny, local JSON sanitizer: keeps size small & avoids numpy/astropy weirdness."""
    import numpy as _np
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    if isinstance(obj, dict):
        return {str(k): _dm_json_sanitize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_dm_json_sanitize(x) for x in obj]
    # numpy array → small placeholder
    try:
        if isinstance(obj, _np.ndarray):
            return {"__nd__": True, "shape": list(obj.shape), "dtype": str(obj.dtype)}
        # numpy scalar
        if hasattr(obj, "item"):
            return obj.item()
    except Exception:
        pass
    try:
        return repr(obj)
    except Exception:
        return str(type(obj))

def _compute_cropped_wcs(parent_hdr_like: dict | "fits.Header",
                         x: int, y: int, w: int, h: int):
    """
    Returns a plain dict WCS header reflecting a pure pixel crop by (x,y,w,h).
    Keeps CD/CDELT/PC/CRVAL as-is and shifts CRPIX by (+/-) the crop offset.
    Also sets NAXIS1/2 to (w,h) and records custom CROPX/CROPY.
    """
    try:
        from astropy.io.fits import Header  # type: ignore
    except Exception:
        Header = None  # type: ignore

    # Normalize to a dict of key->value (no comments needed for the drag payload)
    if Header is not None and isinstance(parent_hdr_like, Header):
        base = {k: parent_hdr_like.get(k) for k in parent_hdr_like.keys()}
    elif isinstance(parent_hdr_like, dict):
        # If it’s an XISF-like dict, try to pull a FITSKeywords block first
        fk = parent_hdr_like.get("FITSKeywords")
        if isinstance(fk, dict) and fk:
            base = {}
            for k, arr in fk.items():
                try:
                    base[k] = (arr or [{}])[0].get("value", None)
                except Exception:
                    pass
        else:
            base = dict(parent_hdr_like)
    else:
        base = {}

    # Shift CRPIX by the crop offset (ROI origin is (x,y) in full-image pixels)
    crpix1 = base.get("CRPIX1")
    crpix2 = base.get("CRPIX2")
    if isinstance(crpix1, (int, float)) and isinstance(crpix2, (int, float)):
        new_crpix1 = float(crpix1) - float(x)
        new_crpix2 = float(crpix2) - float(y)
        base["CRPIX1"] = new_crpix1
        base["CRPIX2"] = new_crpix2
    else:
        new_crpix1 = crpix1
        new_crpix2 = crpix2

    # Update image size keys
    base["NAXIS1"] = int(w)
    base["NAXIS2"] = int(h)

    # Optional helpful tags
    base["CROPX"] = int(x)
    base["CROPY"] = int(y)
    base["SASKIND"] = "ROI-CROP"

    # DEBUG: show how CRPIX changed for this crop
    if _DEBUG_WCS:
        print(f"[WCS DEBUG] _compute_cropped_wcs: roi=({x},{y},{w},{h})")
        print(f"  CRPIX1: {crpix1} -> {new_crpix1}")
        print(f"  CRPIX2: {crpix2} -> {new_crpix2}")
        print("")

    return base

import logging

log = logging.getLogger(__name__)

def _pick_header_for_save(meta: dict) -> fits.Header | None:
    """
    Choose the best header to write to disk.

    Priority:
        1. 'wcs_header'      – if you stash a solved header here
        2. 'fits_header'     – common name after ASTAP / plate solve
        3. 'original_header' – whatever came from disk
        4. 'header'          – older code paths
    """
    if not isinstance(meta, dict):
        return None

    for key in ("wcs_header", "fits_header", "original_header", "header"):
        hdr = meta.get(key)
        if isinstance(hdr, fits.Header):
            log.debug("[_pick_header_for_save] using %s (%d cards)", key, len(hdr))
            return hdr

    log.debug("[_pick_header_for_save] no fits.Header found in metadata; "
              "will let legacy_save_image fall back.")
    return None

def _snapshot_header_for_metadata(meta: dict):
    """
    If meta contains a header under common keys, add a JSON-safe snapshot at
    meta["__header_snapshot__"] so viewers/project IO never choke.
    """
    if not isinstance(meta, dict):
        return
    if "__header_snapshot__" in meta:
        return

    hdr = (meta.get("original_header")
           or meta.get("fits_header")
           or meta.get("header"))

    if hdr is None:
        return

    snap = None

    # Try astropy Header (without hard dependency)
    try:
        from astropy.io.fits import Header  # type: ignore
    except Exception:
        Header = None  # type: ignore

    try:
        if Header is not None and isinstance(hdr, Header):
            cards = []
            for k in hdr.keys():
                try:
                    val = hdr[k]
                except Exception:
                    val = ""
                try:
                    cmt = hdr.comments[k] if hasattr(hdr, "comments") else ""
                except Exception:
                    cmt = ""
                cards.append([str(k), _dm_json_sanitize(val), str(cmt)])
            snap = {"format": "fits-cards", "cards": cards}
        elif isinstance(hdr, dict):
            # Already a dict-like header (e.g., XISF style)
            snap = {"format": "dict",
                    "items": {str(k): _dm_json_sanitize(v) for k, v in hdr.items()}}
        else:
            # Last resort string
            snap = {"format": "repr", "text": repr(hdr)}
    except Exception:
        try:
            snap = {"format": "repr", "text": str(hdr)}
        except Exception:
            snap = None

    if snap:
        meta["__header_snapshot__"] = snap

def _safe_str(x) -> str:
    try:
        return str(x)
    except Exception:
        try:
            return repr(x)
        except Exception:
            return "<unrepr>"

def _fits_table_to_csv(hdu, out_csv_path: str, max_rows: int = 250000):
    """
    Convert a FITS (Bin)Table HDU to CSV. Returns the CSV path.
    Limits to max_rows to avoid giant dumps.
    """
    try:
        data = hdu.data
        if data is None:
            raise RuntimeError("No table data")

        # Astropy table→numpy recarray is fine; iterate to strings
        rec = np.asarray(data)
        nrows = int(rec.shape[0]) if rec.ndim >= 1 else 0
        if nrows == 0:
            # write headers only
            names = [str(n) for n in (getattr(data, "names", None) or [])]
            with open(out_csv_path, "w", encoding="utf-8", newline="") as f:
                if names:
                    f.write(",".join(names) + "\n")
            return out_csv_path

        # Column names (fallback to numeric if missing)
        names = list(getattr(data, "names", [])) or [f"C{i+1}" for i in range(rec.shape[1] if rec.ndim == 2 else len(rec.dtype.names or []))]

        import csv
        with open(out_csv_path, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow([_safe_str(n) for n in names])

            # Decide how to iterate rows depending on structured vs 2D numeric
            if rec.dtype.names:  # structured/record array
                for ri in range(min(nrows, max_rows)):
                    row = rec[ri]
                    w.writerow([_safe_str(row[name]) for name in rec.dtype.names])
            else:
                # plain 2D numeric table
                if rec.ndim == 1:
                    for ri in range(min(nrows, max_rows)):
                        w.writerow([_safe_str(rec[ri])])
                else:
                    for ri in range(min(nrows, max_rows)):
                        w.writerow([_safe_str(x) for x in rec[ri]])

        return out_csv_path
    except Exception as e:
        raise

def _fits_table_to_rows_headers(hdu, max_rows: int = 500000) -> tuple[list[list], list[str]]:
    """
    Convert a FITS (Bin)Table/Table HDU to (rows, headers).
    Handles vector-per-cell columns by unpacking them into one row per element.
    """
    import re as _re

    data = hdu.data
    if data is None:
        return [], []

    rec = np.asarray(data)
    names = list(getattr(data, "names", [])) or (
        list(rec.dtype.names) if rec.dtype.names else
        [f"C{i+1}" for i in range(rec.shape[1] if rec.ndim == 2 else 1)]
    )

    # ── Helper: try to parse a cell value into a 1-D float array ──────────
    def _try_parse_vector(val) -> np.ndarray | None:
        """
        Returns a float64 1-D ndarray if val is a vector/array-like, else None.
        Handles:
          - np.ndarray with ndim >= 1 and size > 1
          - stringified numpy arrays like "[1.0 2.0 3.0]"
          - lists/tuples of numbers
        """
        # Already an array
        if isinstance(val, np.ndarray):
            flat = val.ravel()
            if flat.size > 1:
                try:
                    return flat.astype(np.float64)
                except Exception:
                    return None
            return None

        # String that looks like a numpy array repr
        if isinstance(val, str):
            s = val.strip()
            if s.startswith('[') and s.endswith(']'):
                # Strip brackets, replace newlines/extra whitespace, split on whitespace
                inner = s[1:-1].replace('\n', ' ')
                parts = _re.split(r'\s+', inner.strip())
                try:
                    arr = np.array([float(p) for p in parts if p], dtype=np.float64)
                    if arr.size > 1:
                        return arr
                except Exception:
                    pass
            return None

        # List or tuple
        if isinstance(val, (list, tuple)):
            try:
                arr = np.array(val, dtype=np.float64).ravel()
                if arr.size > 1:
                    return arr
            except Exception:
                pass

        return None

    # ── Pull raw rows from the record array ───────────────────────────────
    nrows = int(rec.shape[0]) if rec.ndim >= 1 else 0
    nrows = min(nrows, max_rows)

    raw_rows = []
    if rec.dtype.names:
        for ri in range(nrows):
            row = rec[ri]
            raw_rows.append([row[name] for name in rec.dtype.names])
    else:
        if rec.ndim == 1:
            for ri in range(nrows):
                raw_rows.append([rec[ri]])
        else:
            for ri in range(nrows):
                raw_rows.append(list(rec[ri]))

    if not raw_rows:
        return [], [str(n) for n in names]

    # ── Detect vector-in-cell columns using the first row ─────────────────
    n_cols = len(raw_rows[0])
    col_vectors = {}  # col_index -> np.ndarray (the parsed vector for row 0)

    for ci in range(n_cols):
        vec = _try_parse_vector(raw_rows[0][ci])
        if vec is not None:
            col_vectors[ci] = vec

    # ── If ANY column is a vector, unpack the whole table ─────────────────
    if col_vectors:
        # Use the length of the first vector column as the reference length
        ref_ci = next(iter(col_vectors))
        ref_len = col_vectors[ref_ci].size

        # Build per-column arrays (parse all rows for vector cols, broadcast scalars)
        col_arrays = []
        for ci in range(n_cols):
            if ci in col_vectors:
                # Parse every row for this vector column
                parsed_rows = []
                for ri, raw_row in enumerate(raw_rows):
                    v = _try_parse_vector(raw_row[ci])
                    if v is not None and v.size == ref_len:
                        parsed_rows.append(v)
                    else:
                        parsed_rows.append(np.full(ref_len, np.nan, dtype=np.float64))
                # Stack: shape (nrows_original, ref_len) → flatten to (nrows_original * ref_len,)
                col_arrays.append(np.concatenate(parsed_rows))
            else:
                # Scalar column: repeat each value ref_len times
                scalars = []
                for raw_row in raw_rows:
                    cell = raw_row[ci]
                    try:
                        val = float(cell)
                    except Exception:
                        val = _safe_str(cell)
                    scalars.extend([val] * ref_len)
                col_arrays.append(scalars)

        # Transpose from column-major to row-major
        total_rows = len(col_arrays[0])
        total_rows = min(total_rows, max_rows)
        out_rows = []
        for ri in range(total_rows):
            out_rows.append([
                (float(col_arrays[ci][ri]) if isinstance(col_arrays[ci][ri], (int, float, np.floating, np.integer))
                 else _safe_str(col_arrays[ci][ri]))
                for ci in range(n_cols)
            ])

        return out_rows, [str(n) for n in names]

    # ── Scalar table: original path ───────────────────────────────────────
    out_rows = []
    for raw_row in raw_rows:
        out_rows.append([_safe_str(v) for v in raw_row])

    return out_rows, [str(n) for n in names]

_shown_raw_preview_paths: set[str] = set()
_raw_preview_boxes: list[QMessageBox] = []  # prevent GC while shown

def _show_raw_preview_warning_nonmodal(path: str):
    parent = QApplication.activeWindow()
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Warning)
    box.setWindowTitle("RAW preview loaded")
    box.setText(
        "Linear RAW decoding failed for:\n"
        f"{path}\n\n"
        "Showing the camera’s embedded JPEG preview instead "
        "(8-bit, non-linear). Some processing tools may be limited."
    )
    box.setStandardButtons(QMessageBox.StandardButton.Ok)
    box.setWindowModality(Qt.WindowModality.NonModal)  # ← fix here
    box.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

    _raw_preview_boxes.append(box)
    box.finished.connect(lambda _=None, b=box: _raw_preview_boxes.remove(b))
    box.show()

def maybe_warn_raw_preview(path: str, header):
    if not header or not bool(header.get("RAW_PREV", False)):
        return
    if path in _shown_raw_preview_paths:
        return
    _shown_raw_preview_paths.add(path)
    QTimer.singleShot(0, lambda p=path: _show_raw_preview_warning_nonmodal(p))

_np = np

class _RoiViewDocument(ImageDocument):
    def __init__(self, parent_doc: ImageDocument, roi: tuple[int,int,int,int], name_suffix: str = " (Preview)"):
        x, y, w, h = roi
        meta = dict(parent_doc.metadata or {})
        base = parent_doc.display_name()
        meta["display_name"] = f"{base}{name_suffix}"
        meta.setdefault("image_meta", {})
        meta["image_meta"] = dict(meta["image_meta"], readonly=True, view_kind="roi-preview")

        super().__init__(_np.zeros((max(1,h), max(1,w), 3), dtype=_np.float32), meta, parent=parent_doc.parent())

        self._parent_doc = parent_doc
        self._roi = ( x, y, w, h )
        self._roi_info = {"parent_doc": parent_doc, "roi": tuple(self._roi)}
        self.metadata["_roi_bounds"] = tuple(self._roi)
        imi = dict(self.metadata.get("image_meta") or {})
        imi.update({"roi": tuple(self._roi), "view_kind": "roi-preview"})
        self.metadata["image_meta"] = imi

        # build and store an ROI-shifted WCS header snapshot to use if detached
        try:
            phdr = (parent_doc.metadata.get("original_header")
                    or parent_doc.metadata.get("fits_header")
                    or parent_doc.metadata.get("header"))
            rx, ry, rw, rh = self._roi
            roi_wcs = _compute_cropped_wcs(phdr, rx, ry, rw, rh)
            self.metadata["roi_wcs_header"] = roi_wcs  # plain dict, drop-in safe

            # 🔴 KEY FIX: for a standalone ROI doc, treat this cropped WCS
            # as the "original_header" so view-drops / duplicates inherit it.
            if phdr is not None:
                # optional: preserve the full parent header
                self.metadata.setdefault("parent_full_header", phdr)
            self.metadata["original_header"] = roi_wcs
            try:
                from .doc_manager import _snapshot_header_for_metadata  # if you move it, adjust import
            except Exception:
                _snapshot_header_for_metadata = None

            try:
                if _snapshot_header_for_metadata is not None:
                    _snapshot_header_for_metadata(self.metadata)
            except Exception:
                pass

            # DEBUG: log parent vs ROI WCS
            if _DEBUG_WCS:
                base_name = parent_doc.display_name() if hasattr(parent_doc, "display_name") else "<parent>"
                print(f"[WCS DEBUG] _RoiViewDocument.__init__: parent='{base_name}' roi={self._roi}")
                _debug_log_wcs_context("  parent_header", phdr)
                _debug_log_wcs_context("  roi_header", self.metadata)
        except Exception as e:
            if _DEBUG_WCS:
                print(f"[WCS DEBUG] _RoiViewDocument.__init__ exception: {e}")
            pass
        self.metadata["image_meta"] = imi
        # NEW: transient preview overlay for this ROI (None means "show parent slice")
        self._preview_override: _np.ndarray | None = None

        self._pundo: list[tuple[_np.ndarray, dict, str]] = []  # (img, meta, name)
        self._predo: list[tuple[_np.ndarray, dict, str]] = []  # (img, meta, name)

        # NEW: promote sticky keys (roi_wcs_header, original_header, ...)
        # that we assigned directly to self.metadata above, so they survive
        # this doc's local preview undo/redo.
        try:
            self._sync_strata_from_metadata()
        except Exception:
            pass

    @property
    def image(self):
        p = self._parent_doc
        if p is None or getattr(p, "image", None) is None:
            return None
        x, y, w, h = self._roi
        # If a preview override exists, show it; else show the live parent slice
        return self._preview_override if self._preview_override is not None else p.image[y:y+h, x:x+w]

    @image.setter
    def image(self, _val):
        # ignore: writes should use DocManager(update/commit) paths
        pass


    def commit_to_parent(self, new_image: _np.ndarray | None = None,
                        metadata: dict | None = None, step_name: str = "Edit"):
        """
        Paste current preview (or provided new_image) back into the parent image
        with proper undo and region repaint.
        """
        parent = getattr(self, "_parent_doc", None)
        if parent is None or parent.image is None:
            return

        x, y, w, h = self._roi
        # choose source
        src = new_image
        if src is None:
            src = self._preview_override if self._preview_override is not None else parent.image[y:y+h, x:x+w]

        img = _np.asarray(src, dtype=_np.float32, copy=False)
        base = parent.image

        # channel reconciliation
        if base.ndim == 2 and img.ndim == 3 and img.shape[2] == 1:
            img = img[..., 0]
        if base.ndim == 3 and img.ndim == 2:
            img = _np.repeat(img[..., None], base.shape[2], axis=2)
        if img.shape[:2] != (h, w):
            raise ValueError(f"Commit shape {img.shape[:2]} does not match ROI {(h, w)}")

        # push undo on parent and paste
        _meta_snap = parent.metadata.copy()
        _rp = _make_replay_marker(metadata, step_name)
        _replay_audit(step_name, _rp)
        if _rp is not None:
            _meta_snap["_replay"] = _rp
        else:
            _meta_snap.pop("_replay", None)
        parent._undo.append((base.copy(), _meta_snap, step_name))
        parent._redo.clear()
        if metadata: parent.metadata.update(_strip_replay_keys(metadata))
        parent.metadata.setdefault("step_name", step_name)

        new_full = base.copy()
        new_full[y:y+h, x:x+w] = img
        parent.image = new_full
        try: parent.changed.emit()
        except Exception as e:
            import logging
            logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")

        # notify region update + repaint
        dm = getattr(self, "_doc_manager", None) or getattr(parent, "_doc_manager", None)
        if dm is not None:
            try: dm.imageRegionUpdated.emit(parent, (x, y, w, h))
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")


    # --- helper to snapshot what's currently visible in the Preview
    def _current_preview_copy(self) -> _np.ndarray:
        img = self.image  #sasproperty: returns override or parent slice
        if img is None:
            return _np.zeros((1, 1), dtype=_np.float32)
        arr = _np.asarray(img, dtype=_np.float32)
        return _np.ascontiguousarray(arr)

    # === KEEP YOUR WORKING BODY; only 3 added lines are marked "NEW" ===
    def apply_edit(self, new_image, metadata=None, step_name="Edit"):
        x, y, w, h = self._roi
        img = np.asarray(new_image, dtype=np.float32, copy=False)
        base = self._parent_doc.image

        _debug_log_undo(
            "_RoiViewDocument.apply_edit.entry",
            roi=(x, y, w, h),
            parent_id=id(self._parent_doc) if self._parent_doc is not None else None,
            roi_doc_id=id(self),
            new_shape=getattr(img, "shape", None),
            step_name=step_name,
            pundo_len=len(self._pundo),
            predo_len=len(self._predo),
        )
        if base is not None:
            if base.ndim == 2 and img.ndim == 3 and img.shape[2] == 1:
                img = img[..., 0]
            if base.ndim == 3 and img.ndim == 2:
                img = np.repeat(img[..., None], base.shape[2], axis=2)
        if img.shape[:2] != (h, w):
            raise ValueError(f"Preview edit shape {img.shape[:2]} != ROI {(h, w)}")
        
        img = np.ascontiguousarray(img) 

        # snapshot current visible preview for local undo
        self._pundo.append((self._current_preview_copy(), dict(self.metadata), step_name))
        self._predo.clear()
        if not hasattr(self, "_preview_commands"):
            self._preview_commands = []
        md = dict(metadata or {})

        cid = (md.get("command_id") or md.get("step_name") or step_name or "").strip()

        from setiastro.saspro.command_ids import normalize_command_id
        normalized_cid = normalize_command_id(cid)

        preset = dict(md.get("preset") or {})

        # If preset is empty, try to pull it from the main window's last headless command
        # Tools like Cosmic Clarity and Curves store params there, not in apply_edit metadata
        if not preset:
            try:
                # Walk up to find the main window via the parent doc
                import gc
                from PyQt6.QtWidgets import QApplication
                app = QApplication.instance()
                if app is not None:
                    for widget in app.topLevelWidgets():
                        last = getattr(widget, "_last_headless_command", None)
                        if last is not None:
                            last_cid = normalize_command_id(
                                str(last.get("command_id") or "")
                            )
                            if last_cid == normalized_cid:
                                preset = dict(last.get("preset") or {})
                                break
            except Exception:
                pass

        self._preview_commands.append({
            "step": step_name or cid,
            "command_id": normalized_cid,
            "preset": preset,
        })
        self._preview_override = img
        _debug_log_undo(
            "_RoiViewDocument.apply_edit.after",
            roi=(x, y, w, h),
            preview_shape=getattr(self._preview_override, "shape", None),
            pundo_len=len(self._pundo),
            predo_len=len(self._predo),
            step_name=step_name,
        )

        if metadata:
            self.metadata.update(_strip_replay_keys(metadata))
        self.metadata.setdefault("step_name", step_name)

        # NEW: promote sticky/identity keys just merged in, so they
        # survive this ROI doc's local preview undo/redo.
        try:
            self._sync_strata_from_metadata()
        except Exception:
            pass

        # 1) notify ROI listeners (e.g. the main window via _on_roi_changed)
        try:
            self.changed.emit()
        except Exception:
            pass

        # 2) optionally: tell DocManager "ROI preview changed" using base doc + ROI
        dm = getattr(self, "_doc_manager", None)
        if dm is not None and hasattr(dm, "previewRepaintRequested"):
            try:
                dm.previewRepaintRequested.emit(self._parent_doc, self._roi)
            except Exception:
                pass



    def _parent(self):
        return getattr(self, "_parent_doc", None)

    def can_undo(self) -> bool:
        # Prefer local preview history if present
        if self._pundo:
            return True
        # Otherwise mirror parent’s history
        p = getattr(self, "_parent_doc", None)
        if p is not None and hasattr(p, "can_undo"):
            try:
                return bool(p.can_undo())
            except Exception:
                return False
        return False

    def can_redo(self) -> bool:
        if self._predo:
            return True
        p = getattr(self, "_parent_doc", None)
        if p is not None and hasattr(p, "can_redo"):
            try:
                return bool(p.can_redo())
            except Exception:
                return False
        return False

    def last_undo_name(self) -> str | None:
        if self._pundo:
            return self._pundo[-1][2]
        p = getattr(self, "_parent_doc", None)
        if p is not None and hasattr(p, "last_undo_name"):
            try:
                return p.last_undo_name()
            except Exception:
                return None
        return None

    def last_redo_name(self) -> str | None:
        if self._predo:
            return self._predo[-1][2]
        p = getattr(self, "_parent_doc", None)
        if p is not None and hasattr(p, "last_redo_name"):
            try:
                return p.last_redo_name()
            except Exception:
                return None
        return None

    def undo(self) -> str | None:
        # --- Case 1: ROI-local preview history ---
        if self._pundo:
            _debug_log_undo(
                "_RoiViewDocument.undo.local.entry",
                roi=self._roi,
                roi_doc_id=id(self),
                pundo_len=len(self._pundo),
                predo_len=len(self._predo),
            )
            # NEW: capture any sticky/identity keys currently in metadata
            # before we blow it away with the frozen snapshot.
            try:
                self._sync_strata_from_metadata()
            except Exception:
                pass

            # move current → redo; pop undo → current
            curr = self._current_preview_copy()
            self._predo.append((curr, dict(self.metadata), self._pundo[-1][2]))

            prev_img, prev_meta, name = self._pundo.pop()
            self._preview_override = prev_img
            self.metadata = dict(prev_meta)
            # NEW: overlay sticky/identity so ROI-level WCS + identity
            # keys survive local preview undo.
            try:
                self._overlay_strata_onto_metadata()
            except Exception:
                pass
            _debug_log_undo(
                "_RoiViewDocument.undo.local.apply",
                roi=self._roi,
                new_preview_shape=getattr(prev_img, "shape", None),
                pundo_len=len(self._pundo),
                predo_len=len(self._predo),
                name=name,
            )
            try:
                self.changed.emit()
            except Exception:
                pass

            dm = getattr(self, "_doc_manager", None)
            if dm is not None and hasattr(dm, "previewRepaintRequested"):
                try:
                    dm.previewRepaintRequested.emit(self._parent_doc, self._roi)
                except Exception:
                    pass
            return name

        # --- Case 2: no ROI-local history → delegate to parent ---
        parent = getattr(self, "_parent_doc", None)
        if parent is None or not hasattr(parent, "undo"):
            return None
        _debug_log_undo(
            "_RoiViewDocument.undo.parent.entry",
            roi=self._roi,
            roi_doc_id=id(self),
            parent_id=id(parent),
            parent_undo_len=len(getattr(parent, "_undo", [])),
            parent_redo_len=len(getattr(parent, "_redo", [])),
        )

        name = parent.undo()

        # After parent changes, clear override so we show the new parent slice
        self._preview_override = None

        try:
            self.changed.emit()
        except Exception:
            pass

        dm = getattr(self, "_doc_manager", None) or getattr(parent, "_doc_manager", None)
        if dm is not None and hasattr(dm, "previewRepaintRequested"):
            try:
                dm.previewRepaintRequested.emit(parent, self._roi)
            except Exception:
                pass
        return name

    def redo(self) -> str | None:
        # --- Case 1: ROI-local preview history ---
        if self._predo:
            # NEW: capture any sticky/identity keys currently in metadata
            # before we replace it with the redo snapshot below.
            try:
                self._sync_strata_from_metadata()
            except Exception:
                pass

            # move current → undo; pop redo → current
            curr = self._current_preview_copy()
            self._pundo.append((curr, dict(self.metadata), self._predo[-1][2]))

            nxt_img, nxt_meta, name = self._predo.pop()
            self._preview_override = nxt_img
            self.metadata = dict(nxt_meta)
            # NEW: overlay sticky/identity so ROI-level WCS + identity
            # keys survive local preview redo.
            try:
                self._overlay_strata_onto_metadata()
            except Exception:
                pass

            try:
                self.changed.emit()
            except Exception:
                pass

            dm = getattr(self, "_doc_manager", None)
            if dm is not None and hasattr(dm, "previewRepaintRequested"):
                try:
                    dm.previewRepaintRequested.emit(self._parent_doc, self._roi)
                except Exception:
                    pass
            return name

        # --- Case 2: delegate to parent’s redo ---
        parent = getattr(self, "_parent_doc", None)
        if parent is None or not hasattr(parent, "redo"):
            return None

        name = parent.redo()

        # Parent changed → reset override and repaint
        self._preview_override = None

        try:
            self.changed.emit()
        except Exception:
            pass

        dm = getattr(self, "_doc_manager", None) or getattr(parent, "_doc_manager", None)
        if dm is not None and hasattr(dm, "previewRepaintRequested"):
            try:
                dm.previewRepaintRequested.emit(parent, self._roi)
            except Exception:
                pass
        return name



class LiveViewDocument(QObject):
    """
    Drop-in proxy that mirrors an ImageDocument API but always resolves
    via DocManager + view to the ROI-aware document (if a Preview tab is active).
    Reads: delegate to current resolved doc.
    Writes: use DocManager.update_active_document(...) so ROI is pasted back.
    """
    changed = pyqtSignal()

    def __init__(self, doc_manager: "DocManager", view, base_doc: "ImageDocument"):
        super().__init__(parent=base_doc.parent())
        self._dm = doc_manager
        self._view = view              # ImageSubWindow widget
        self._base = base_doc          # true ImageDocument

        # Bridge base document change signals (ROI wrappers rarely emit)
        try:
            base_doc.changed.connect(self.changed.emit)
        except Exception:
            pass

    # ---- core resolver ----
    def _current(self):
        try:
            d = self._dm.get_document_for_view(self._view)
            return d or self._base
        except Exception:
            return self._base

    # ---- common API surface (reads) ----
    @property
    def image(self):
        d = self._current()
        return getattr(d, "image", None)

    @property
    def metadata(self):
        d = self._current()
        return getattr(d, "metadata", {}) or {}

    def display_name(self):
        d = self._current()
        if hasattr(d, "display_name"):
            try:
                return d.display_name()
            except Exception:
                pass
        return self._base.display_name() if hasattr(self._base, "display_name") else "Untitled"

    # Mask access stays consistent with whichever doc is current
    def get_active_mask(self):
        d = self._current()
        if hasattr(d, "get_active_mask"):
            try:
                return d.get_active_mask()
            except Exception:
                return None
        return None

    @property
    def masks(self):
        d = self._current()
        return getattr(d, "masks", {})

    @property
    def active_mask_id(self):
        d = self._current()
        return getattr(d, "active_mask_id", None)

    # ---- writes route through DocManager so ROI is honored ----
    def apply_edit(self, new_image, metadata=None, step_name="Edit"):
        #print("[LiveViewDocument] apply_edit called, routing via DocManager")
        self._dm.update_active_document(new_image, dict(metadata or {}), step_name)

    # ---- history helpers (optional pass-throughs) ----
    def can_undo(self):
        d = self._current()
        return bool(getattr(d, "can_undo", lambda: False)())

    def can_redo(self):
        d = self._current()
        return bool(getattr(d, "can_redo", lambda: False)())

    def last_undo_name(self):
        d = self._current()
        return getattr(d, "last_undo_name", lambda: None)()

    def last_redo_name(self):
        d = self._current()
        return getattr(d, "last_redo_name", lambda: None)()

    def undo(self):
        d = self._current()
        _debug_log_undo(
            "LiveViewDocument.undo.call",
            live_id=id(self),
            resolved_type=type(d).__name__ if d is not None else None,
            resolved_id=id(d) if d is not None else None,
            is_roi=isinstance(d, _RoiViewDocument),
            has_undo=getattr(d, "can_undo", lambda: False)(),
        )
        return getattr(d, "undo", lambda: None)()

    def redo(self):
        d = self._current()
        _debug_log_undo(
            "LiveViewDocument.redo.call",
            live_id=id(self),
            resolved_type=type(d).__name__ if d is not None else None,
            resolved_id=id(d) if d is not None else None,
            is_roi=isinstance(d, _RoiViewDocument),
            has_redo=getattr(d, "can_redo", lambda: False)(),
        )
        return getattr(d, "redo", lambda: None)()


    # ---- generic fallback so existing attributes keep working ----
    def __getattr__(self, name):
        # Prefer the current resolved doc, then base_doc
        d = object.__getattribute__(self, "_current")()
        if hasattr(d, name):
            return getattr(d, name)
        return getattr(self._base, name)

def _xisf_meta_to_fits_header(m: dict) -> fits.Header | None:
    """
    Best-effort: pull common WCS keys out of XISF FITSKeywords into a fits.Header.
    Returns None if nothing usable found.
    """
    fk = m.get("FITSKeywords", {}) if isinstance(m, dict) else {}
    if not fk:
        return None

    want = (
        "WCSAXES", "CTYPE1", "CTYPE2", "CRPIX1", "CRPIX2",
        "CRVAL1", "CRVAL2", "CD1_1", "CD1_2", "CD2_1", "CD2_2",
        "CDELT1", "CDELT2", "PC1_1", "PC1_2", "PC2_1", "PC2_2",
        "A_ORDER", "B_ORDER"
    )

    hdr = fits.Header()
    found = False
    for k in want:
        vlist = fk.get(k)
        if vlist and isinstance(vlist, list) and vlist[0].get("value") is not None:
            hdr[k] = vlist[0]["value"]
            found = True

    # also pull SIP coeffs if present
    for k, vlist in fk.items():
        if k.startswith(("A_", "B_", "AP_", "BP_")) and vlist and vlist[0].get("value") is not None:
            try:
                hdr[k] = float(vlist[0]["value"])
                found = True
            except Exception:
                pass

    return hdr if found else None

DEBUG_SAVE_DOCUMENT = False

def debug_dump_metadata_print(meta: dict, context: str = ""):
    if DEBUG_SAVE_DOCUMENT:
        print(f"\n===== METADATA DUMP ({context}) =====")
        if not isinstance(meta, dict):
            print("  (not a dict) ->", type(meta))
            print("====================================")
            return

        keys = sorted(str(k) for k in meta.keys())
        print("  keys:", ", ".join(keys))

        for key in keys:
            val = meta[key]
            if isinstance(val, fits.Header):
                print(f"  {key}: fits.Header with {len(val.cards)} cards")
            else:
                print(f"  {key}: {val!r} ({type(val).__name__})")

        print("===== END METADATA DUMP ({}) =====".format(context))

import time
_DEBUG_DND_DUP = False

class DocManager(QObject):
    documentAdded = pyqtSignal(object)   # ImageDocument
    documentRemoved = pyqtSignal(object) # ImageDocument
    imageRegionUpdated = pyqtSignal(object, object)  # (doc, roi_tuple_or_None)
    previewRepaintRequested = pyqtSignal(object, object)
    
    activeBaseChanged = pyqtSignal(object)  # emits ImageDocument | None

    def __init__(self, image_manager=None, parent=None):
        super().__init__(parent)
        self.image_manager = image_manager
        self._roi_doc_cache = {} 
        self._docs: list[ImageDocument] = []
        self._active_doc: ImageDocument | None = None
        self._mdi: "QMdiArea | None" = None  # type: ignore
        def _on_region_updated(doc, roi):
            vw = self._active_view_widget()
            if vw is not None:
                try:
                    if hasattr(vw, "refresh_from_docman") and callable(vw.refresh_from_docman):
                        vw.refresh_from_docman(doc=doc, roi=roi)
                    else:
                        vw._render()
                except Exception:
                    pass

        self.imageRegionUpdated.connect(_on_region_updated)
        self._by_uid = {}
        self._focused_base_doc: ImageDocument | None = None  # <— NEW

        def _do_preview_repaint(doc, roi):
            vw = self._active_view_widget()
            if vw is not None:
                try:
                    if hasattr(vw, "refresh_from_docman") and callable(vw.refresh_from_docman):
                        vw.refresh_from_docman(doc=doc, roi=roi)
                    else:
                        vw._render()
                except Exception:
                    pass
        self.previewRepaintRequested.connect(_do_preview_repaint)

    def resolve_doc_from_drag(self, *, uid: str | None = None,
                            doc_ptr: int | None = None,
                            file_path: str = "") -> "ImageDocument | None":
        """
        Single canonical document resolver for DnD payloads.
        Priority: UID → file_path → id() scan of _docs → subwindow scan (catches proxies/ROI docs).
        """
        # 1) UID
        if uid:
            d = self._by_uid.get(uid)
            if d is not None:
                return d

        fp = (file_path or "").strip()

        # 2) Scan registered docs
        for doc in self._docs:
            meta = getattr(doc, "metadata", {}) or {}
            d_uid = getattr(doc, "uid", None)

            if uid and d_uid == uid:
                return doc

            if fp and not uid:
                d_path = (meta.get("file_path") or "").strip()
                if d_path == fp:
                    return doc

            if doc_ptr is not None and id(doc) == doc_ptr:
                return doc

        # 3) Subwindow scan — catches _DocProxy and _RoiViewDocument which
        #    are not registered in _docs but do live in subwindows
        if doc_ptr is not None and self._mdi is not None:
            try:
                for sw in self._mdi.subWindowList():
                    try:
                        w = sw.widget()
                    except RuntimeError:
                        continue
                    d = getattr(w, "document", None)
                    if d is not None and id(d) == doc_ptr:
                        return d
                    # also check base_document in case proxy id doesn't match
                    base = getattr(w, "base_document", None)
                    if base is not None and id(base) == doc_ptr:
                        return base
            except Exception:
                pass

        return None

    def get_document_for_view(self, view):
        """
        Given an ImageSubWindow widget, return either:
        - the full base ImageDocument
        - or a cached ROI-wrapper doc if a Preview/ROI tab is active
        Works with both old (has_active_preview/current_preview_roi) and
        new (_active_roi_tuple) view APIs. Falls back to view.document.
        """
        # 1) Resolve a base document from the view
        base = (
            getattr(view, "base_document", None)
            or getattr(view, "_base_document", None)
            or getattr(view, "document", None)
        )
        if base is None:
            return None

        # 2) Try to discover an ROI (support both APIs)
        roi = None
        try:
            if hasattr(view, "has_active_preview") and callable(view.has_active_preview):
                if view.has_active_preview():
                    # preferred old API
                    try:
                        roi = view.current_preview_roi()  # (x,y,w,h)
                    except Exception:
                        roi = None
        except Exception:
            pass

        if roi is None:
            # new API candidate
            for attr in ("_active_roi_tuple", "current_roi_tuple", "selected_roi", "roi"):
                try:
                    fn = getattr(view, attr, None)
                    if callable(fn):
                        r = fn()
                        if r and len(r) == 4:
                            roi = r
                            break
                except Exception:
                    pass

        # 3) If no ROI, return the base doc
        if not roi:
            return base

        # 4) Cache and return a lightweight ROI view doc
        try:
            x, y, w, h = map(int, roi)
            key = (id(base), id(view), (x, y, w, h))

            # Trim stale entries where the view has been GC'd
            dead = [k for k in list(self._roi_doc_cache)
                    if k[1] not in {id(v) for v in self._live_views()}]
            for k in dead:
                self._roi_doc_cache.pop(k, None)

            roi_doc = self._roi_doc_cache.get(key)
            if roi_doc is None:
                roi_doc = self._build_roi_document(base, (x, y, w, h))
                self._roi_doc_cache[key] = roi_doc
            return roi_doc
        except Exception:
            return base

    def _live_views(self):
        """Return ids of currently live view widgets."""
        if self._mdi is None:
            return []
        views = []
        try:
            for sw in self._mdi.subWindowList():
                w = sw.widget()
                if w is not None:
                    views.append(w)
        except Exception:
            pass
        return views

    def _invalidate_roi_cache(self, parent_doc, roi_tuple):
        """Drop cached ROI docs that overlap an updated region of parent_doc."""
        if not roi_tuple:
            # full-image change -> drop all for this parent
            dead = [k for k in self._roi_doc_cache.keys() if k[0] == id(parent_doc)]
        else:
            px, py, pw, ph = roi_tuple
            def _overlaps(a, b):
                ax, ay, aw, ah = a; bx, by, bw, bh = b
                return not (ax+aw <= bx or bx+bw <= ax or ay+ah <= by or by+bh <= ay)
            dead = []
            for (parent_id, _view_id, aroi), _doc in list(self._roi_doc_cache.items()):
                if parent_id != id(parent_doc):
                    continue
                if _overlaps(aroi, (px, py, pw, ph)):
                    dead.append((parent_id, _view_id, aroi))
        for k in dead:
            self._roi_doc_cache.pop(k, None)

    def get_document_by_uid(self, uid: str):
        return self._by_uid.get(uid)

    def is_doc_valid(self, doc) -> bool:
        """Check if a document is currently managed/open (supports proxies)."""
        if doc in self._docs:
            return True
        # Handle proxies/wrappers that point to a real doc
        base = getattr(doc, "_base", None) or getattr(doc, "_parent_doc", None)
        return bool(base and base in self._docs)


    def _register_doc(self, doc):
        import weakref

        # Only image-like docs need the backref
        if hasattr(doc, "image") or hasattr(doc, "apply_edit"):
            try:
                doc._doc_manager = weakref.proxy(self)
            except Exception:
                doc._doc_manager = self

        self._docs.append(doc)

        if hasattr(doc, "uid"):
            self._by_uid[doc.uid] = doc

        self.documentAdded.emit(doc)

    def _build_roi_document(self, base_doc, roi):
        doc = _RoiViewDocument(base_doc, roi, name_suffix=" (Preview)")
        try:
            import weakref
            doc._doc_manager = weakref.proxy(self)
        except Exception:
            doc._doc_manager = self

        try:
            import weakref
            dm_ref = weakref.ref(self)

            # Find the view that owns this ROI right now so we can target it directly
            owner_view = None
            for sw in (self._mdi.subWindowList() if self._mdi else []):
                try:
                    w = sw.widget()
                    if w is None:
                        continue
                    base = (getattr(w, "base_document", None)
                            or getattr(w, "document", None))
                    if base is base_doc and hasattr(w, "has_active_preview"):
                        owner_view = weakref.ref(w)
                        break
                except Exception:
                    pass

            def _on_roi_changed():
                dm = dm_ref()
                if dm is None:
                    return
                # Try the specific owning view first, fall back to active view
                vw = None
                if owner_view is not None:
                    vw = owner_view()
                if vw is None:
                    vw = dm._active_view_widget()
                if vw is not None:
                    try:
                        vw._render(rebuild=True)
                    except Exception:
                        pass
                # Also nudge the parent doc's changed signal so DocProxy
                # connected views redraw even if focus was stolen
                try:
                    base_doc.changed.emit()
                except Exception:
                    pass

            doc.changed.connect(_on_roi_changed)

        except Exception:
            print("[DocManager] Failed to connect ROI view document change signal")

        return doc

    def commit_active_preview_to_parent(self, metadata: dict | None = None, step_name: str = "Edit"):
        doc = self.get_active_document()
        if isinstance(doc, _RoiViewDocument):
            doc.commit_to_parent(None, metadata=metadata or {}, step_name=step_name)
            # after commit, force an immediate view repaint
            vw = self._active_view_widget()
            if vw is not None:
                try:
                    if hasattr(vw, "refresh_from_docman") and callable(vw.refresh_from_docman):
                        vw.refresh_from_docman(doc=doc._parent_doc, roi=None)
                    else:
                        vw._render()
                except Exception:
                    pass

    def wrap_document_for_view(self, view, base_doc: ImageDocument) -> LiveViewDocument:
        """Return a live, ROI-aware proxy for this view."""
        return LiveViewDocument(self, view, base_doc)

    def open_path(self, path: str, open_auxiliary_images: bool | None = None):
        ext = os.path.splitext(path)[1].lower().lstrip('.')
        norm_ext = _normalize_ext(ext)

        lower_path = path.lower()
        is_fits = lower_path.endswith((".fit", ".fits", ".fts", ".fit.gz", ".fits.gz", ".fz"))
        is_xisf = (norm_ext == "xisf")
        is_syq = (norm_ext == "syq")

        primary_doc = None
        created_any = False

        if open_auxiliary_images is None:
            try:
                from PyQt6.QtCore import QSettings
                open_auxiliary_images = bool(
                    QSettings().value("files/open_auxiliary_images", True, type=bool)
                )
            except Exception:
                open_auxiliary_images = True
        else:
            open_auxiliary_images = bool(open_auxiliary_images)

        # ---------- local helper: build vector-style table from 1-D FITS image HDU ----------
        def _make_vector_table_doc_from_hdu(hdu, base_path: str, base_name: str, key_str: str):
            arr = np.asarray(hdu.data)
            vec = np.squeeze(arr)

            if vec.ndim != 1 or vec.size == 0:
                raise ValueError(f"HDU is not a usable 1-D vector: shape={arr.shape}")

            vec = vec.astype(np.float64, copy=False)
            hdr = hdu.header

            # ---- build X axis from 1-D WCS if available; otherwise pixel index ----
            x = np.arange(vec.size, dtype=np.float64)
            x_name = "PIXEL"
            x_unit = None

            try:
                ctype1 = str(hdr.get("CTYPE1", "") or "").strip()
                cunit1 = str(hdr.get("CUNIT1", "") or "").strip() or None

                step = hdr.get("CDELT1", None)
                if step is None:
                    step = hdr.get("CD1_1", None)

                crpix1 = float(hdr.get("CRPIX1", 1.0))
                crval1 = float(hdr.get("CRVAL1", 0.0))

                if step is not None:
                    step = float(step)
                    pix = np.arange(vec.size, dtype=np.float64) + 1.0  # FITS pixel coordinates are 1-based
                    x = crval1 + (pix - crpix1) * step

                    ctype1_up = ctype1.upper()
                    if "WAVE" in ctype1_up or "AWAV" in ctype1_up:
                        x_name = "WAVE"
                    elif "FREQ" in ctype1_up:
                        x_name = "FREQUENCY"
                    elif "VELO" in ctype1_up or "VRAD" in ctype1_up:
                        x_name = "VELOCITY"
                    elif "TIME" in ctype1_up:
                        x_name = "TIME"
                    elif ctype1:
                        x_name = ctype1.replace("-", " ").strip()
                    else:
                        x_name = "X"

                    x_unit = cunit1
            except Exception:
                pass

            # ---- build Y label/unit ----
            y_name = (
                str(hdr.get("BTYPE", "") or "").strip()
                or ("FLUX" if x_name == "WAVE" else "VALUE")
            )
            y_unit = str(hdr.get("BUNIT", "") or "").strip() or None

            # One row, two vector-in-cell columns -> your plotting code can use this
            rows = [[x, vec]]
            headers = [x_name, y_name]

            hdrlet_hint = False
            try:
                ext_up = str(key_str or "").upper()
                name_up = str(getattr(hdu, "name", "") or "").upper()
                hdrlet_hint = ("HDRLET" in ext_up) or ("HDRLET" in name_up)
            except Exception:
                hdrlet_hint = False

            tmeta = {
                "file_path": f"{base_path}::{key_str}",
                "original_header": hdr,
                "original_format": "fits",
                "display_name": f"{base_name} {key_str} (Vector)",
                "doc_type": "table",
                "doc_subtype": "vector",
                "vector_length": int(vec.size),
                "column_units": {
                    x_name: x_unit,
                    y_name: y_unit,
                },

                # NEW
                "is_hdrlet_table": bool(hdrlet_hint),
                "table_notice": (
                    "This FITS extension appears to be an HDRLET/WCS-correction reference table. "
                    "It is preserved for inspection because it is valid data, but it is not a normal "
                    "science spectrum or image-profile table. Plotting it may look garbled unless you "
                    "already know the instrument-specific meaning of the columns."
                    if hdrlet_hint else ""
                ),
            }
            _snapshot_header_for_metadata(tmeta)
            tdoc = TableDocument(rows, headers, tmeta, parent=self.parent())
            self._register_doc(tdoc)
            try:
                tdoc.changed.emit()
            except Exception as e:
                import logging
                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
            return tdoc

        # ---------- local helper: decode FITS image HDU into normal display layout ----------
        def _decode_fits_hdu_image(hdu):
            arr = np.asanyarray(hdu.data)
            hdr = hdu.header

            if arr is None:
                raise ValueError("HDU has no image data")

            # Ensure native byte order
            try:
                if arr.dtype.byteorder not in ('=', '|'):
                    arr = arr.astype(arr.dtype.newbyteorder('='))
            except Exception:
                pass

            src_dtype = arr.dtype
            bit_depth = None

            # ── NEW: detect count/integer layers that should NOT be normalized to [0,1] ──
            extname = str(hdr.get("EXTNAME", "") or "").upper().strip()
            is_count_layer = any(tag in extname for tag in ("REJ_CNT", "COUNT", "NCOMBINE"))
            
            if is_count_layer and src_dtype in (np.uint16, np.uint32, np.int32):
                # Preserve as float32 with actual count values, no normalization
                bit_depth = "32-bit floating point"
                a = arr.astype(np.float32)
                a = np.squeeze(a)
                is_mono = (a.ndim == 2)
                if a.ndim == 3 and a.shape[0] == 1:
                    a = a[0]
                    is_mono = True
                a = np.nan_to_num(a, nan=0.0)
                a = np.asarray(a, dtype=np.float32, order="C")
                return a, bit_depth, is_mono

            # ---- dtype -> float32 conversion ----
            if src_dtype == np.uint8:
                bit_depth = "8-bit"
                a = arr.astype(np.float32) / 255.0

            elif src_dtype == np.uint16:
                bit_depth = "16-bit"
                a = arr.astype(np.float32) / 65535.0

            elif src_dtype == np.int16:
                bit_depth = "16-bit signed"
                bzero = float(hdr.get('BZERO', 0))
                bscale = float(hdr.get('BSCALE', 1))
                data = arr.astype(np.float32) * bscale + bzero
                if bzero != 0.0 or bscale != 1.0:
                    a = np.clip(data / 65535.0, 0.0, 1.0)
                else:
                    dmin = float(data.min())
                    dmax = float(data.max())
                    a = (data - dmin) / (dmax - dmin) if dmax > dmin else np.zeros_like(data, dtype=np.float32)

            elif src_dtype == np.int8:
                bit_depth = "8-bit signed"
                bzero = float(hdr.get('BZERO', 0))
                bscale = float(hdr.get('BSCALE', 1))
                data = arr.astype(np.float32) * bscale + bzero
                dmin = float(data.min())
                dmax = float(data.max())
                a = (data - dmin) / (dmax - dmin) if dmax > dmin else np.zeros_like(data, dtype=np.float32)

            elif src_dtype == np.int32:
                bit_depth = "32-bit signed"
                bzero = float(hdr.get('BZERO', 0))
                bscale = float(hdr.get('BSCALE', 1))
                data = arr.astype(np.float32) * bscale + bzero
                dmin = float(data.min())
                dmax = float(data.max())
                a = (data - dmin) / (dmax - dmin) if dmax > dmin else np.zeros_like(data, dtype=np.float32)

            elif src_dtype == np.uint32:
                bit_depth = "32-bit unsigned"
                bzero = float(hdr.get('BZERO', 0))
                bscale = float(hdr.get('BSCALE', 1))
                if bzero == 0.0 and bscale == 1.0:
                    a = arr.astype(np.float32) / 4294967295.0
                else:
                    data = arr.astype(np.float32) * bscale + bzero
                    dmin = float(data.min())
                    dmax = float(data.max())
                    a = (data - dmin) / (dmax - dmin) if dmax > dmin else np.zeros_like(data, dtype=np.float32)

            elif src_dtype == np.float32:
                bit_depth = "32-bit floating point"
                a = np.array(arr, dtype=np.float32, copy=True, order="C")

            elif src_dtype == np.float64:
                bit_depth = "64-bit floating point"
                a = arr.astype(np.float32, copy=True)

            else:
                # Fallback
                bit_depth = str(src_dtype)
                a = arr.astype(np.float32, copy=False)

            # ---- squeeze singleton axes ----
            a = np.squeeze(a)

            # ---- interpret final shape ----
            # mono
            if a.ndim == 2:
                is_mono = True

            elif a.ndim == 3:
                # CHW color from FITS bundle / normal FITS RGB
                if a.shape[0] in (3, 4) and a.shape[1] > 1 and a.shape[2] > 1:
                    a = np.transpose(a[:3, :, :], (1, 2, 0))
                    is_mono = False

                # HWC color
                elif a.shape[2] in (3, 4) and a.shape[0] > 1 and a.shape[1] > 1:
                    a = a[:, :, :3]
                    is_mono = False

                # singleton channel last
                elif a.shape[2] == 1:
                    a = a[:, :, 0]
                    is_mono = True

                # singleton channel first
                elif a.shape[0] == 1:
                    a = a[0, :, :]
                    is_mono = True

                else:
                    raise ValueError(f"Unsupported FITS HDU image dimensions after squeeze: {a.shape}")

            else:
                raise ValueError(f"Unsupported FITS HDU image dimensions after squeeze: {a.shape}")

            # finalize
            a = np.nan_to_num(a, nan=0.0, posinf=1.0, neginf=0.0)
            a = np.asarray(a, dtype=np.float32, order="C")

            return a, bit_depth, is_mono

        # ---------- 1) Try the universal loader first (ALL formats) ----------
        img = header = bit_depth = is_mono = None
        meta = None
        try:
            # NEW: prefer metadata-aware return
            out = legacy_load_image(path, return_metadata=True)
            if out and len(out) == 5:
                img, header, bit_depth, is_mono, meta = out
            else:
                img, header, bit_depth, is_mono = out
        except TypeError:
            # legacy_load_image older signature → fall back
            try:
                img, header, bit_depth, is_mono = legacy_load_image(path)
            except Exception as e:
                print(f"[DocManager] legacy_load_image failed (non-fatal if FITS/XISF): {e}")
        except Exception as e:
            print(f"[DocManager] legacy_load_image failed (non-fatal if FITS/XISF): {e}")

        maybe_warn_raw_preview(path, header)

        if img is not None:
            if meta is None:
                meta = {
                    "file_path": path,
                    "original_header": header,
                    "bit_depth": bit_depth,
                    "is_mono": is_mono,
                    "original_format": norm_ext,
                }

                # NEW: attach WCS even for old loader
                meta = attach_wcs_to_metadata(meta, header)

            _snapshot_header_for_metadata(meta)

            img = _normalize_image_01(img)
            primary_doc = ImageDocument(img, meta)
            self._register_doc(primary_doc)
            created_any = True

        # ---------- 2) FITS: enumerate HDUs (tables + vector HDUs + extra images + ICC) ----------
        # Extra image HDUs (weights, rejection maps, …) each become another
        # full float32 document + view. Skip them unless explicitly requested.
        if is_fits and open_auxiliary_images:
            try:
                with fits.open(path, memmap=False) as hdul:
                    base = os.path.basename(path)

                    for i, hdu in enumerate(hdul):
                        name_up = (getattr(hdu, "name", "PRIMARY") or "PRIMARY").upper()
                        if primary_doc is not None and (i == 0 or name_up == "PRIMARY"):
                            continue

                        ext_hdr = hdu.header
                        try:
                            en = str(ext_hdr.get("EXTNAME", "")).strip()
                            ev = ext_hdr.get("EXTVER", None)
                            extname = f"{en}[{int(ev)}]" if (en and isinstance(ev, (int, np.integer))) else (en or "")
                        except Exception:
                            extname = ""

                        key_str = extname or f"HDU{i}"

                        # --- Tables → TableDocument ---
                        if isinstance(hdu, (fits.BinTableHDU, fits.TableHDU)):
                            nice = key_str
                            try:
                                rows, headers = _fits_table_to_rows_headers(hdu, max_rows=500000)
                                tmeta = {
                                    "file_path": f"{path}::{key_str}",
                                    "original_header": ext_hdr,
                                    "original_format": "fits",
                                    "display_name": f"{base} {key_str} (Table)",
                                    "doc_type": "table",
                                }
                                _snapshot_header_for_metadata(tmeta)
                                tdoc = TableDocument(rows, headers, tmeta, parent=self.parent())
                                self._register_doc(tdoc)
                                try:
                                    tdoc.changed.emit()
                                except Exception as e:
                                    import logging
                                    logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
                                created_any = True
                            except Exception as e_tab:
                                print(f"[DocManager] Table HDU {nice} → in-app view failed: {e_tab}")
                            continue

                        if hdu.data is None:
                            continue

                        arr = np.asanyarray(hdu.data)
                        arr_sq = np.squeeze(arr)

                        en_up = (extname or "").upper()
                        is_probable_icc = ("ICC" in en_up or "PROFILE" in en_up)

                        if arr.ndim == 1 and arr.dtype == np.uint8 and is_probable_icc:
                            try:
                                icc_path = f"{os.path.splitext(path)[0]}_{extname or f'HDU{i}'}_.icc".replace(" ", "_")
                                with open(icc_path, "wb") as f:
                                    f.write(arr.tobytes())
                                created_any = True
                                continue
                            except Exception as e_icc:
                                print(f"[DocManager] ICC export failed: {e_icc} — will try as image")

                        if arr_sq.ndim == 1 and arr_sq.size > 0:
                            try:
                                _make_vector_table_doc_from_hdu(hdu, path, base, key_str)
                                created_any = True
                            except Exception as e_vec:
                                print(f"[DocManager] FITS HDU {i} vector build failed: {e_vec}")
                            continue

                        try:
                            a, ext_depth, ext_mono = _decode_fits_hdu_image(hdu)
                            disp = f"{base} {key_str}"

                            aux_meta = {
                                "file_path": f"{path}::{key_str}",
                                "original_header": ext_hdr,
                                "bit_depth": ext_depth,
                                "is_mono": bool(ext_mono),
                                "original_format": "fits",
                                "image_meta": {"derived_from": path, "layer": key_str, "readonly": True},
                                "display_name": disp,
                            }
                            # For count/rejection layers, store the raw max so readout can show actual counts
                            extname_up = (extname or "").upper()
                            if any(tag in extname_up for tag in ("REJ_CNT", "COUNT", "NCOMBINE")):
                                aux_meta["is_count_layer"] = True
                                aux_meta["count_max"] = float(a.max()) if a.size else 1.0
                            aux_meta = attach_wcs_to_metadata(aux_meta, ext_hdr)
                            _snapshot_header_for_metadata(aux_meta)
                            a = _normalize_image_01(a)
                            aux_doc = ImageDocument(a, aux_meta)

                            self._register_doc(aux_doc)
                            try:
                                aux_doc.changed.emit()
                            except Exception as e:
                                import logging
                                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
                            created_any = True

                        except Exception as e_img:
                            print(f"[DocManager] FITS HDU {i} image build failed: {e_img}")
                            import traceback; traceback.print_exc()

            except Exception as _e:
                print(f"[DocManager] FITS HDU enumeration failed: {_e}")
                import traceback; traceback.print_exc()
        # ---------- 3) XISF: create primary if needed, then enumerate extras ----------
        if is_xisf:
            try:
                # helpers
                def _bit_depth_from_dtype(dt: np.dtype) -> str:
                    dt = np.dtype(dt)
                    if dt == np.float32: return "32-bit floating point"
                    if dt == np.float64: return "64-bit floating point"
                    if dt == np.uint8:   return "8-bit"
                    if dt == np.uint16:  return "16-bit"
                    if dt == np.uint32:  return "32-bit unsigned"
                    return "32-bit floating point"

                def _to_float32_01(arr: np.ndarray) -> np.ndarray:
                    a = np.asarray(arr)
                    if a.dtype == np.float32:
                        return a
                    if a.dtype.kind in "iu":
                        return (a.astype(np.float32) / np.iinfo(a.dtype).max).clip(0.0, 1.0)
                    return a.astype(np.float32, copy=False)

                def _to_float32_preserve(arr: np.ndarray) -> np.ndarray:
                    a = np.asarray(arr)
                    return a if a.dtype == np.float32 else a.astype(np.float32, copy=False)

                xisf = XISFReader(path)
                metas = xisf.get_images_metadata() or []
                base = os.path.basename(path)

                # If legacy did NOT create a primary, build image #0 now
                if primary_doc is None and len(metas) >= 1:
                    try:
                        arr0 = xisf.read_image(0, data_format="channels_last")
                        arr0_f32 = _to_float32_preserve(arr0)
                        arr0_f32 = _normalize_image_01(arr0_f32)
                        bd0 = _bit_depth_from_dtype(metas[0].get("dtype", arr0.dtype))
                        is_mono0 = (arr0_f32.ndim == 2) or (arr0_f32.ndim == 3 and arr0_f32.shape[2] == 1)

                        # Friendly label for #0
                        label0 = metas[0].get("id") or "Image[0]"
                        md0 = {
                            "file_path": f"{path}::XISF[0]",
                            "original_header": metas[0],  # will be sanitized
                            "bit_depth": bd0,
                            "is_mono": is_mono0,
                            "original_format": "xisf",
                            "image_meta": {"derived_from": path, "layer_index": 0, "readonly": True},
                            "display_name": f"{base} {label0}",
                        }
                        # NEW: attach WCS if possible
                        hdr0 = _xisf_meta_to_fits_header(metas[0])
                        if hdr0 is not None:
                            md0 = attach_wcs_to_metadata(md0, hdr0)

                        _snapshot_header_for_metadata(md0)
                        primary_doc = ImageDocument(arr0_f32, md0)
                        self._register_doc(primary_doc)
                        try:
                            primary_doc.changed.emit()
                        except Exception as e:
                            import logging
                            logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
                        created_any = True

                    except Exception as e0:
                        print(f"[DocManager] XISF primary (index 0) open failed: {e0}")

                # Add images 1..N-1 as siblings (even if primary came from legacy)
                if open_auxiliary_images:
                    for i in range(1, len(metas)):
                        try:
                            m = metas[i]
                            arr = xisf.read_image(i, data_format="channels_last")
                            arr_f32 = _to_float32_preserve(arr)
                            arr_f32 = _normalize_image_01(arr_f32)

                            bd = _bit_depth_from_dtype(m.get("dtype", arr.dtype))
                            is_mono_i = (arr_f32.ndim == 2) or (arr_f32.ndim == 3 and arr_f32.shape[2] == 1)

                            # Friendly label: prefer id, else EXTNAME/EXTVER in FITSKeywords, else index
                            label = m.get("id") or None
                            if not label:
                                try:
                                    fk = m.get("FITSKeywords", {})
                                    en = (fk.get("EXTNAME") or [{}])[0].get("value", "")
                                    ev = (fk.get("EXTVER")  or [{}])[0].get("value", "")
                                    if en:
                                        label = f"{en}[{ev}]" if ev else en
                                except Exception:
                                    pass
                            if not label:
                                label = f"Image[{i}]"

                            md = {
                                "file_path": f"{path}::XISF[{i}]",
                                "original_header": m,  # snapshot; sanitized below
                                "bit_depth": bd,
                                "is_mono": is_mono_i,
                                "original_format": "xisf",
                                "image_meta": {"derived_from": path, "layer_index": i, "readonly": True},
                                "display_name": f"{base} {label}",
                            }
                            hdri = _xisf_meta_to_fits_header(m)
                            if hdri is not None:
                                md = attach_wcs_to_metadata(md, hdri)

                            _snapshot_header_for_metadata(md)
                            sib = ImageDocument(arr_f32, md)
                            self._register_doc(sib)
                            try:
                                sib.changed.emit()
                            except Exception as e:
                                import logging
                                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
                            created_any = True

                        except Exception as _e:
                            print(f"[DocManager] XISF image {i} skipped: {_e}")
            except Exception as _e:
                print(f"[DocManager] XISF open/enumeration failed: {_e}")

        # ---------- 3b) SYQ: primary already loaded; enumerate extra image layers ----------
        # Each additional IMAGE_DESCRIPTOR (processing checkpoints, linear images,
        # masks, …) becomes a read-only sibling view — the SYQ analog of extra
        # FITS image HDUs / XISF images. The primary was opened by legacy_load_image
        # above (with its WCS already attached); here we also fold the raw SYQ
        # metadata onto it and bring in the other layers.
        if is_syq:
            try:
                from setiastro.saspro.imageops.syq_io import (
                    list_syq_images, read_syq as _syq_read_layer,
                )
                base = os.path.basename(path)
                layers = list_syq_images(path)

                if primary_doc is not None:
                    prim = next((L for L in layers if L["is_primary"]), None)
                    if prim is not None:
                        try:
                            im = primary_doc.metadata.setdefault("image_meta", {})
                            if isinstance(im, dict):
                                im.setdefault("syq_metadata", prim["metadata"])
                                im.setdefault("syq_role", prim["role"])
                        except Exception:
                            pass

                used_names = set()
                if open_auxiliary_images:
                    for L in layers:
                        if L["is_primary"]:
                            continue
                        try:
                            arr, hdr, bd, mono = _syq_read_layer(path, image_id=L["id"])
                            arr = _normalize_image_01(arr)
                            # Studio files often carry many layers sharing a role
                            # (e.g. PROCESSING_CHECKPOINT), which would produce
                            # identically-titled views. Number the repeats
                            # ("NAME", "NAME 2", …); the object id in file_path
                            # stays the stable, unique key regardless.
                            label = L["role"] or f"SYQ[{L['id']}]"
                            disp = f"{base} {label}"
                            if disp in used_names:
                                k = 2
                                while f"{base} {label} {k}" in used_names:
                                    k += 1
                                disp = f"{base} {label} {k}"
                            used_names.add(disp)
                            md = {
                                "file_path": f"{path}::SYQ[{L['id']}]",
                                "original_header": hdr,
                                "bit_depth": bd,
                                "is_mono": mono,
                                "original_format": "syq",
                                "image_meta": {
                                    "derived_from": path,
                                    "layer_id": L["id"],
                                    "syq_role": L["role"],
                                    "syq_metadata": L["metadata"],
                                    "readonly": True,
                                },
                                "display_name": disp,
                            }
                            md = attach_wcs_to_metadata(md, hdr)
                            _snapshot_header_for_metadata(md)
                            sib = ImageDocument(arr, md)
                            self._register_doc(sib)
                            try:
                                sib.changed.emit()
                            except Exception as e:
                                import logging
                                logging.debug(f"Exception suppressed: {type(e).__name__}: {e}")
                            created_any = True
                        except Exception as _e:
                            print(f"[DocManager] SYQ layer {L.get('id')} skipped: {_e}")
            except Exception as _e:
                print(f"[DocManager] SYQ open/enumeration failed: {_e}")

        # ---------- 4) Return sensible doc or raise ----------
        if primary_doc is not None:
            return primary_doc
        if created_any:
            return self._docs[-1]  # e.g., a table-only FITS, vector-only FITS, or extra XISF image

        raise IOError(f"Could not load: {path}")
    # --- Subwindow / ROI awareness -------------------------------------
    def _active_subwindow(self):
        """Return the active QMdiSubWindow (if any)."""
        if self._mdi is None:
            return None
        try:
            return self._mdi.activeSubWindow()
        except Exception:
            return None

    def _active_view_widget(self):
        """Return the active view widget (ImageSubWindow or TableSubWindow)."""
        sw = self._active_subwindow()
        if not sw:
            return None
        try:
            return sw.widget()
        except Exception:
            return None

    def _active_preview_roi(self):
        """
        Returns (x,y,w,h) if the active view is an ImageSubWindow with a selected Preview tab.
        Else returns None.
        """
        #print("[DocManager] Checking for active preview ROI")
        vw = self._active_view_widget()
        if vw and hasattr(vw, "has_active_preview") and vw.has_active_preview():
            try:
                return vw.current_preview_roi()
            except Exception:
                return None
        return None

    def get_active_image(self, prefer_preview: bool = True):
        """
        Unified read: returns the ndarray a tool should operate on.
        If a Preview tab is active and prefer_preview=True, return that crop.
        Otherwise return the full document image.
        """
        doc = self.get_active_document()
        if doc is None or doc.image is None:
            return None
        roi = self._active_preview_roi() if prefer_preview else None
        if roi is None:
            return doc.image
        x, y, w, h = roi
        return doc.image[y:y+h, x:x+w]


    # --- Slot -> Document ---
    def open_from_slot(self, slot_idx: int | None = None) -> "ImageDocument | None":
        if not self.image_manager:
            return None

        if slot_idx is None:
            slot_idx = getattr(self.image_manager, "current_slot", 0)

        img = self.image_manager.get_image_for_slot(slot_idx)
        if img is None:
            return None

        meta = {}
        try:
            meta = dict(self.image_manager._metadata.get(slot_idx, {}))
        except Exception:
            pass

        meta.setdefault("file_path", f"Slot {slot_idx}")
        meta.setdefault("bit_depth", "32-bit floating point")
        meta.setdefault("is_mono", (img.ndim == 2))
        meta.setdefault("original_header", meta.get("original_header"))  # whatever SASv2 had
        meta.setdefault("original_format", "fits")

        _snapshot_header_for_metadata(meta)

        doc = ImageDocument(img, meta)
        self._register_doc(doc)
        return doc
    
    # --- Save ---
    def _infer_bit_depth_for_format(self, img: np.ndarray, ext: str, current_bit_depth: str | None) -> str:
        # Previous heuristic fallback (used only if no override provided).
        if ext in ("png", "jpg"):
            return "8-bit"
        if ext in ("fits", "fit"):
            return "32-bit floating point"
        if ext == "tif":
            if current_bit_depth in _ALLOWED_DEPTHS["tif"]:
                return current_bit_depth
            return "16-bit" if np.issubdtype(img.dtype, np.floating) else "8-bit"
        if ext == "xisf":
            return current_bit_depth if current_bit_depth in _ALLOWED_DEPTHS["xisf"] else "32-bit floating point"
        return "32-bit floating point"

    def _normalize_bundle_export_image(self, img: np.ndarray) -> np.ndarray:
        """
        Normalize an image for bundled FITS export so every entry arrives in a
        consistent internal layout:

        mono  -> (H, W)
        color -> (H, W, 3)

        Also forces float32 so bundle export cannot drift to float64.
        """
        a = np.asarray(img)

        if a.ndim == 2:
            return np.asarray(a, dtype=np.float32, order="C")

        if a.ndim != 3:
            raise ValueError(f"Unsupported image shape for FITS bundle export: {a.shape}")

        # HWC mono
        if a.shape[2] == 1:
            return np.asarray(a[:, :, 0], dtype=np.float32, order="C")

        # CHW mono
        if a.shape[0] == 1:
            return np.asarray(a[0, :, :], dtype=np.float32, order="C")

        # HWC color
        if a.shape[2] in (3, 4):
            return np.asarray(a[:, :, :3], dtype=np.float32, order="C")

        # CHW color
        if a.shape[0] in (3, 4):
            return np.asarray(np.transpose(a[:3, :, :], (1, 2, 0)), dtype=np.float32, order="C")

        raise ValueError(f"Cannot determine channel layout for FITS bundle export: {a.shape}")

    def create_table_document(self, headers, rows, metadata=None, title="New Table"):
        meta = dict(metadata or {})
        meta.setdefault("doc_type", "table")
        meta.setdefault("editable", True)
        meta.setdefault("display_name", title)
        meta.setdefault("original_format", "internal")

        doc = TableDocument(
            rows=[list(r) for r in (rows or [])],
            headers=list(headers or []),
            metadata=meta,
            parent=self.parent(),
        )

        self._register_doc(doc)

        try:
            doc.changed.emit()
        except Exception:
            pass

        return doc

    def save_fits_bundle(
        self,
        entries: list[dict],
        path: str,
        *,
        bit_depth_override: str | None = None,
        export_opts: dict | None = None,
    ):
        """
        Save multiple open views/docs into one multi-HDU FITS.
        Supports both image docs and table docs.

        `entries` should contain dicts with at least:
            { "title": str, "doc": document-like, "kind": "image" | "table" }
        """
        from astropy.io import fits
        from setiastro.saspro.legacy.image_manager import save_fits_bundle as legacy_save_fits_bundle

        def _to_fits_header(v):
            if isinstance(v, fits.Header):
                return v
            if isinstance(v, dict):
                try:
                    return fits.Header(v)
                except Exception:
                    return None
            return None

        bundle_items = []

        for ent in entries:
            doc = ent.get("doc")
            if doc is None:
                continue

            meta = getattr(doc, "metadata", {}) or {}
            kind = str(ent.get("kind") or "").lower()

            if kind == "image" or getattr(doc, "image", None) is not None:
                img = getattr(doc, "image", None)
                if img is None:
                    continue

                effective_header = None
                for key in ("fits_header", "original_header", "header"):
                    val = _to_fits_header(meta.get(key))
                    if val is not None:
                        effective_header = val
                        break

                wcs_hdr = _to_fits_header(meta.get("wcs_header"))

                bundle_items.append({
                    "kind": "image",
                    "title": ent.get("title") or meta.get("display_name") or "IMAGE",
                    "img_array": np.asarray(img),
                    "original_header": effective_header,
                    "wcs_header": wcs_hdr,
                    "is_mono": bool(meta.get("is_mono", getattr(img, "ndim", 2) == 2)),
                    "image_meta": meta.get("image_meta"),
                    "file_meta": meta.get("file_meta"),
                    "doc_type": meta.get("doc_type"),
                    "doc_subtype": meta.get("doc_subtype"),
                })
                continue

            if kind == "table" or (
                getattr(doc, "rows", None) is not None and getattr(doc, "headers", None) is not None
            ):
                rows = getattr(doc, "rows", None)
                headers = getattr(doc, "headers", None)
                if rows is None or headers is None:
                    continue

                effective_header = None
                for key in ("fits_header", "original_header", "header"):
                    val = _to_fits_header(meta.get(key))
                    if val is not None:
                        effective_header = val
                        break

                bundle_items.append({
                    "kind": "table",
                    "title": ent.get("title") or meta.get("display_name") or "TABLE",
                    "rows": list(rows),
                    "headers": list(headers),
                    "original_header": effective_header,
                    "wcs_header": None,
                    "doc_type": meta.get("doc_type"),
                    "doc_subtype": meta.get("doc_subtype"),
                    "column_units": meta.get("column_units"),
                    "vector_length": meta.get("vector_length"),
                    "metadata": meta,
                })
                continue

        if not bundle_items:
            raise RuntimeError("No views were available for FITS bundle export.")

        final_bit_depth = bit_depth_override or "32-bit floating point"

        legacy_save_fits_bundle(
            bundle_items,
            path,
            bit_depth=final_bit_depth,
            export_opts=export_opts,
        )

    def save_document(
        self,
        doc: "ImageDocument",
        path: str,
        bit_depth: str | None = None,
        *,
        bit_depth_override: str | None = None,
        jpeg_quality: int | None = None,   # <-- NEW
        export_opts: dict | None = None,
    ):
        """
        Save the given ImageDocument to 'path'.

        bit_depth_override:
            New-style explicit choice from a dialog.

        bit_depth:
            Legacy positional argument; still honored if override is None.
        """
        ext = _normalize_ext(os.path.splitext(path)[1])
        img = doc.image
        meta = doc.metadata or {}
        export_opts = dict(export_opts or {})
        if jpeg_quality is not None:
            meta["jpeg_quality"] = int(jpeg_quality)
        # ── MASSIVE DEBUG: show everything we know coming in ───────────────
        debug_dump_metadata_print(meta, context="save_document: BEFORE HEADER PICK")

        # --- Decide final bit depth ---------------------------------------
        requested = bit_depth_override or bit_depth or meta.get("bit_depth")

        if requested:
            allowed = _ALLOWED_DEPTHS.get(ext, set())
            if allowed and requested not in allowed:
                print(f"[save_document] Requested bit depth {requested!r} "
                      f"not in allowed {allowed}, falling back to first.")
                final_bit_depth = next(iter(allowed))
            else:
                final_bit_depth = requested
        else:
            final_bit_depth = self._infer_bit_depth_for_format(
                img, ext, meta.get("bit_depth")
            )



        # --- Clip if needed for integer encodes ---------------------------
        needs_clip = (
            ext in ("png", "jpg", "jpeg", "tif", "tiff")
            and final_bit_depth in ("8-bit", "16-bit", "32-bit unsigned")
        )
        if needs_clip:
            print("[save_document] Clipping image to [0,1] for integer encode.")
        img_to_save = np.clip(img, 0.0, 1.0) if needs_clip else img

        # --- PICK THE HEADER EXPLICITLY -----------------------------------
        # We want:
        #   - effective_header: "best full FITS-like header" (fits_header/original_header/header)
        #   - wcs_hdr: explicit WCS-only header if present (to be merged by legacy_save_image)
        #
        # NOTE: do NOT use wcs_header as the "effective_header" unless that's all you have,
        # because it's often missing lots of other cards.
        def _to_fits_header(v):
            if isinstance(v, fits.Header):
                return v
            if isinstance(v, dict):
                try:
                    return fits.Header(v)
                except Exception:
                    return None
            return None

        effective_header = None
        for key in ("fits_header", "original_header", "header"):
            val = _to_fits_header(meta.get(key))
            if val is not None:
                effective_header = val
                break

        wcs_hdr = _to_fits_header(meta.get("wcs_header"))

        # --- If export requested resize, pre-scale WCS in the headers we pass ---
        # This keeps in-memory metadata aligned with the file written.
        try:
            mode = (export_opts.get("resize_mode") or "none").lower()
            h0, w0 = img.shape[:2]

            scale = 1.0
            if mode == "percent":
                pct = int(export_opts.get("resize_percent") or 100)
                pct = max(1, min(400, pct))
                scale = pct / 100.0
            elif mode == "long_edge":
                long_edge = int(export_opts.get("resize_long_edge") or 0)
                if long_edge > 0:
                    long0 = max(h0, w0)
                    if long0 > 0:
                        scale = float(long_edge) / float(long0)

            if scale != 1.0:
                # Import the helper from legacy where we added it
                from setiastro.saspro.legacy.image_manager import _scale_wcs_in_header

                if isinstance(effective_header, fits.Header):
                    effective_header = _scale_wcs_in_header(effective_header, scale)
                if isinstance(wcs_hdr, fits.Header):
                    wcs_hdr = _scale_wcs_in_header(wcs_hdr, scale)

        except Exception as e:
            print("[save_document] WCS pre-scale for resize failed:", e)

        # ── Call the legacy saver ─────────────────────────────────────────
        legacy_save_image(
            img_array=img_to_save,
            filename=path,
            original_format=ext,
            bit_depth=final_bit_depth,
            original_header=effective_header,
            is_mono=meta.get("mono", img.ndim == 2),
            image_meta=meta.get("image_meta"),
            file_meta=meta.get("file_meta"),
            wcs_header=wcs_hdr,                 # <-- use the pre-scaled wcs header
            jpeg_quality=jpeg_quality,
            export_opts=export_opts,
        )

        # ── Update metadata in memory to match what we just wrote ─────────
        meta["file_path"] = path
        meta["original_format"] = ext
        meta["bit_depth"] = final_bit_depth

        # Store the header we actually used (already scaled if resized)
        if isinstance(effective_header, fits.Header):
            meta["original_header"] = effective_header

        doc.metadata = meta
        # Post-save the in-memory metadata was replaced wholesale. Re-sync
        # sticky/identity strata so they reflect what's actually there now
        # (e.g. the refreshed original_header). Best-effort — older doc
        # types (ProjectDocument etc.) may not implement this.
        try:
            if hasattr(doc, "_sync_strata_from_metadata"):
                doc._sync_strata_from_metadata()
        except Exception:
            pass

        # reset dirty flag
        if hasattr(doc, "dirty"):
            doc.dirty = False

        if hasattr(doc, "changed"):
            doc.changed.emit()

    def _current_view_title_for_doc(self, source_doc: ImageDocument) -> str | None:
        """
        If the active MDI subwindow is showing 'source_doc' (or its parent/base),
        return the current view's title (windowTitle), otherwise None.
        """
        sw = self._active_subwindow()
        if sw is None:
            return None

        try:
            w = sw.widget()
        except Exception:
            w = None

        # Resolve what doc the active view corresponds to (base doc)
        try:
            base = (
                getattr(w, "base_document", None)
                or getattr(w, "_base_document", None)
                or getattr(w, "document", None)
                or getattr(sw, "document", None)
            )
            parent = getattr(base, "_parent_doc", None)
            if isinstance(parent, ImageDocument):
                base = parent
        except Exception:
            base = None

        if base is not source_doc:
            return None

        # Prefer the actual subwindow title (includes [View N], etc.)
        try:
            title = sw.windowTitle()
            title = title.strip() if isinstance(title, str) else ""
            return title or None
        except Exception:
            return None


    def duplicate_document(self, source_doc: ImageDocument, new_name: str | None = None) -> ImageDocument:
        # DEBUG: log the source doc WCS before we touch anything
        if _DEBUG_WCS:
            try:
                name = source_doc.display_name() if hasattr(source_doc, "display_name") else "<src>"
            except Exception:
                name = "<src>"
            
            _debug_log_wcs_context("  source.metadata", getattr(source_doc, "metadata", {}))
        if _DEBUG_DND_DUP:
            try:
                src_dn = source_doc.display_name() if hasattr(source_doc, "display_name") else None
            except Exception:
                src_dn = None
            print("\n[DNDDBG:DUPLICATE_DOCUMENT]")
            print("  source_doc:", source_doc, "id:", id(source_doc), "uid:", getattr(source_doc,"uid",None))
            print("  source_doc.display_name():", src_dn)
            print("  new_name arg:", new_name)
        # COPY-ON-WRITE: Share the source image instead of copying immediately.
        # The duplicate's apply_edit will copy when it first modifies the image.
        # This saves memory when duplicates are created but not modified.
        img_ref = source_doc.image  # Shared reference, no copy

        meta = dict(source_doc.metadata or {})

        # ✅ Use CURRENT VIEW NAME if this doc is what's active; else fall back to doc display_name()
        base = self._current_view_title_for_doc(source_doc) or source_doc.display_name()

        dup_title = (new_name or f"{base}_duplicate")

        # 🚫 strip any lingering emojis / link markers
        dup_title = dup_title.replace("🔗", "").strip()

        meta["display_name"] = dup_title
        if _DEBUG_DND_DUP:
            print("  dup_title computed:", dup_title)
        # Remove anything that makes the view look "linked/preview"
        imi = dict(meta.get("image_meta") or {})
        for k in ("readonly", "view_kind", "derived_from", "layer", "layer_index", "linked"):
            imi.pop(k, None)
        meta["image_meta"] = imi
        for k in list(meta.keys()):
            if k.startswith("_roi_") or k.endswith("_roi") or k == "roi":
                meta.pop(k, None)

        # NOTE: we intentionally DO NOT remove "roi_wcs_header" or "original_header"
        # so that a ROI doc keeps its cropped WCS in the duplicate.

        # Safe bit depth / mono flags
        meta.setdefault("original_format", meta.get("original_format", "fits"))
        if isinstance(img_ref, np.ndarray):
            meta["is_mono"] = (img_ref.ndim == 2 or (img_ref.ndim == 3 and img_ref.shape[2] == 1))

        _snapshot_header_for_metadata(meta)

        dup = ImageDocument(img_ref, meta, parent=self.parent())
        # Mark this duplicate as sharing image data with source
        dup._cow_source = source_doc
        self._register_doc(dup)
        if _DEBUG_DND_DUP:
            try:
                dn = dup.display_name() if hasattr(dup, "display_name") else None
            except Exception:
                dn = None
            print("  dup.metadata.display_name:", (dup.metadata or {}).get("display_name"))
            print("  dup.display_name():", dn)
        # DEBUG: log the duplicate doc WCS
        if _DEBUG_WCS:
            try:
                dname = dup.display_name()
            except Exception:
                dname = "<dup>"

            _debug_log_wcs_context("  duplicate.metadata", dup.metadata)

        return dup

    #def open_array(self, arr, metadata: dict | None = None, title: str | None = None) -> ImageDocument:
    #    import numpy as np
    ##    if arr is None:
    #        raise ValueError("open_array: arr is None")
    #    img = np.asarray(arr)
    #    if img.dtype != np.float32:
    #        img = img.astype(np.float32, copy=False)

    #    meta = dict(metadata or {})
    #    meta.setdefault("bit_depth", "32-bit floating point")
    #    meta.setdefault("is_mono", img.ndim == 2)
    #    meta.setdefault("original_header", meta.get("original_header"))
    #    meta.setdefault("original_format", meta.get("original_format", "fits"))
    #    if title:
    #        meta.setdefault("display_name", title)

    #    doc = ImageDocument(img, meta, parent=self.parent())
    #    self._docs.append(doc)
    #    self.documentAdded.emit(doc)
    #    return doc

    # convenient aliases used by your tool code
    def open_array(self, img: np.ndarray, metadata: dict | None = None, title: str | None = None) -> "ImageDocument":
        meta = dict(metadata or {})
        if title:
            meta["display_name"] = title
        # normalize a few expected fields if missing
        try:
            if "is_mono" not in meta and isinstance(img, np.ndarray):
                meta["is_mono"] = (img.ndim == 2 or (img.ndim == 3 and img.shape[2] == 1))
        except Exception:
            pass
        meta.setdefault("bit_depth", meta.get("bit_depth", "32-bit floating point"))

        _snapshot_header_for_metadata(meta)

        doc = ImageDocument(img, meta, parent=self.parent())
        self._register_doc(doc)
        return doc

    # (optional alias for old code)
    open_numpy = open_array


    def create_document(self, image, metadata: dict | None = None, name: str | None = None) -> ImageDocument:
        return self.open_array(image, metadata=metadata, title=name)

    def _drop_all_roi_for_parent(self, parent_doc):
        dead = [k for k in list(self._roi_doc_cache.keys()) if k[0] == id(parent_doc)]
        for k in dead:
            roi_doc = self._roi_doc_cache.pop(k, None)
            if roi_doc is not None:
                try:
                    roi_doc.close()   # you’ll implement doc.close() to release arrays
                except Exception:
                    pass

    def _hard_memory_cleanup(self):
        # 1) Drop Qt pixmap cache (can hold big chunks)
        try:
            from PyQt6.QtGui import QPixmapCache
            QPixmapCache.clear()
        except Exception:
            pass

        # 2) Let pending deleteLater() actually execute
        try:
            from PyQt6.QtWidgets import QApplication
            QApplication.processEvents()
        except Exception:
            pass

        # 3) Force Python GC to collect cycles (common with Qt signal/closure cycles)
        try:
            import gc
            gc.collect()
        except Exception:
            pass

        # 4) Optional: Linux heap trim (only helps on Linux/glibc)
        try:
            import sys
            if sys.platform.startswith("linux"):
                import ctypes
                libc = ctypes.CDLL("libc.so.6")
                libc.malloc_trim(0)
        except Exception:
            pass

    def close_document(self, doc):
        # If ROI wrapper, close parent; if parent, purge ROI cache
        try:
            parent = getattr(doc, "_parent_doc", None)
            if parent is not None:
                doc = parent
        except Exception:
            pass

        self._drop_all_roi_for_parent(doc)
        if doc in self._docs:
            self._docs.remove(doc)
            try:
                if hasattr(doc, "uid"):
                    self._by_uid.pop(doc.uid, None)
            except Exception:
                pass
            
            # Cleanup swap files
            if hasattr(doc, "close"):
                try:
                    doc.close()
                except Exception as e:
                    print(f"[DocManager] Failed to close document {doc}: {e}")

            # Drop stale active/focused references to the doc we just removed so
            # the getters below can't hand a closed document back to any panel.
            if self._active_doc is doc:
                self._active_doc = None
            if self._focused_base_doc is doc:
                self._focused_base_doc = None

            self.documentRemoved.emit(doc)
            self._hard_memory_cleanup()

            # If that was the last document, announce the empty state. Qt does not
            # reliably deliver subWindowActivated(None) on the final close, so emit
            # activeBaseChanged(None) here to guarantee panels that follow the
            # active base (e.g. the Header Viewer) clear instead of holding on to
            # the last document's header.
            if not self._docs:
                self._active_doc = None
                self._focused_base_doc = None
                self.activeBaseChanged.emit(None)
    # --- Active-document helpers (NEW) ---------------------------------
    def all_documents(self):
        return list(self._docs)

    def _find_main_window(self):
        from PyQt6.QtWidgets import QMainWindow, QApplication
        w = self.parent()
        while w is not None and not isinstance(w, QMainWindow):
            w = w.parent()
        if w:
            return w
        for tlw in QApplication.topLevelWidgets():
            if isinstance(tlw, QMainWindow):
                return tlw
        return None

    def set_active_document(self, doc: ImageDocument | None):
        if doc is not None and doc not in self._docs:
            return
        # ensure backref for legacy docs
        if doc is not None and not hasattr(doc, "_doc_manager"):
            try:
                import weakref
                doc._doc_manager = weakref.proxy(self)
            except Exception:
                doc._doc_manager = self
        self._active_doc = doc

    def set_mdi_area(self, mdi):
        """Call this once from MainWindow after MDI is created."""
        self._mdi = mdi
        try:
            mdi.subWindowActivated.connect(self._on_subwindow_activated)
        except Exception:
            pass

    def _base_from_subwindow(self, sw):
        """Best-effort: unwrap to the base ImageDocument bound to a subwindow."""
        if sw is None:
            return None
        try:
            w = sw.widget()
            base = (getattr(w, "base_document", None)
                    or getattr(w, "_base_document", None)
                    or getattr(w, "document", None))
            # unwrap ROI wrappers if any
            p = getattr(base, "_parent_doc", None)
            return p if isinstance(p, ImageDocument) else base
        except Exception:
            return None

    def _on_subwindow_activated(self, sw):
        # existing logic (keep it)
        doc = None
        try:
            if sw is not None:
                w = sw.widget()
                doc = getattr(w, "document", None) or getattr(sw, "document", None)
        except Exception:
            doc = None
        self.set_active_document(doc)

        # NEW: compute focused *base* doc and emit change only when different
        new_base = self._base_from_subwindow(sw)
        if new_base is not self._focused_base_doc:
            self._focused_base_doc = new_base
            try:
                self.activeBaseChanged.emit(new_base)
            except Exception:
                pass

    def get_focused_base_document(self):
        """
        Returns the last *activated* subwindow's base ImageDocument (sticky),
        ignoring hover/preview wrappers.
        """
        return self._focused_base_doc

    def get_active_document(self):
        """
        Return the active document-like object.
        If a Preview tab is selected on the active ImageSubWindow, return a cached
        _RoiViewDocument so tools and the Preview tab share the same instance.
        Otherwise return the real ImageDocument.
        
        IMPORTANT: Always check the currently active MDI subwindow first,
        as that's what the user expects to be the "active" document.
        """
        base_doc = None
        
        # ALWAYS check the MDI active subwindow first - this is the source of truth
        try:
            if self._mdi is not None:
                sw = self._mdi.activeSubWindow()
                if sw is not None:
                    w = sw.widget()
                    base_doc = getattr(w, "document", None) or getattr(sw, "document", None)
                    if base_doc is not None:
                        self._active_doc = base_doc
        except Exception:
            pass
        
        # Fallback to cached value only if MDI lookup failed
        if base_doc is None:
            if self._active_doc is not None and self._active_doc in self._docs:
                base_doc = self._active_doc
            else:
                base_doc = self._docs[-1] if self._docs else None

        # Non-image docs just pass through
        if base_doc is None or not isinstance(base_doc, ImageDocument) or base_doc.image is None:
            return base_doc

        # ✅ ROI-aware, CACHED preview doc
        vw = self._active_view_widget()
        if vw and hasattr(vw, "has_active_preview") and vw.has_active_preview():
            try:
                roi_doc = self.get_document_for_view(vw)  # <-- uses _roi_doc_cache
                if isinstance(roi_doc, _RoiViewDocument):
                    try:
                        name_suffix = f" (Preview {vw.current_preview_name() or ''})"
                        roi_doc.metadata["display_name"] = f"{base_doc.display_name()}{name_suffix}"
                    except Exception:
                        pass
                return roi_doc
            except Exception:
                return base_doc

        return base_doc



    def update_active_document(
        self,
        updated_image,
        metadata=None,
        step_name: str = "Edit",
        doc=None,   # 👈 NEW optional parameter
    ):

        # Prefer explicit doc if given; otherwise fall back to "active"
        view_doc = doc or self.get_active_document()

        # DEBUG: Trace why LinearFit might fail
        # print(f"[DocManager] update_active_document target: {view_doc}, type: {type(view_doc).__name__}")

        # NEW: Unwrap proxy objects (_DocProxy / LiveViewDocument)
        tname = type(view_doc).__name__
        if "LiveViewDocument" in tname:
            try:
                view_doc = view_doc._current()
            except Exception:
                pass
        elif "_DocProxy" in tname:
            try:
                view_doc = view_doc._target()
            except Exception:
                pass

        if view_doc is None:
            raise RuntimeError("No active document")

        old_img = getattr(view_doc, "image", None)
        old_shape = getattr(old_img, "shape", None)

        img = np.asarray(updated_image)
        if img.dtype != np.float32:
            img = img.astype(np.float32, copy=False)

        _debug_log_undo(
            "DocManager.update_active_document.entry",
            step_name=step_name,
            view_doc_type=type(view_doc).__name__,
            view_doc_id=id(view_doc),
            is_roi=isinstance(view_doc, _RoiViewDocument),
            old_shape=old_shape,
            new_shape=getattr(img, "shape", None),
        )

        # --- Extract operation parameters (if any) from metadata --------
        md = dict(metadata or {})
        op_params = md.pop("__op_params__", None)

        # If this is an ROI view doc, keep track of where this happened
        roi_tuple = None
        source_kind = "full"
        if isinstance(view_doc, _RoiViewDocument):
            roi_tuple = getattr(view_doc, "_roi", None)
            source_kind = "roi"

        # --- ROI preview branch: only update preview, no parent paste ----
        if isinstance(view_doc, _RoiViewDocument):
            # Update ONLY the preview; view repaint is driven by signals
            view_doc.apply_edit(img, md, step_name)

            # Record operation on the ROI doc itself
            if hasattr(view_doc, "record_operation"):
                try:
                    view_doc.record_operation(
                        step_name=step_name,
                        params=op_params,
                        roi=roi_tuple,
                        source=source_kind,
                    )
                except Exception:
                    pass
            _debug_log_undo(
                "DocManager.update_active_document.roi_after",
                step_name=step_name,
                view_doc_id=id(view_doc),
                roi=getattr(view_doc, "_roi", None),
                pundo_len=len(getattr(view_doc, "_pundo", [])),
                predo_len=len(getattr(view_doc, "_predo", [])),
            )
            return

        # --- Full image branch ------------------------------------------
        if isinstance(view_doc, ImageDocument):
            view_doc.apply_edit(img, md, step_name)
            try:
                self.imageRegionUpdated.emit(view_doc, None)
            except Exception:
                pass

            _debug_log_undo(
                "DocManager.update_active_document.full_after",
                step_name=step_name,
                view_doc_id=id(view_doc),
                undo_len=len(getattr(view_doc, "_undo", [])),
                redo_len=len(getattr(view_doc, "_redo", [])),
                final_shape=getattr(view_doc.image, "shape", None),
            )
            # Record operation on the full document
            if hasattr(view_doc, "record_operation"):
                try:
                    view_doc.record_operation(
                        step_name=step_name,
                        params=op_params,
                        roi=None,
                        source=source_kind,
                    )
                    
                except Exception:
                    pass
        else:
            raise RuntimeError("Active document is not an image")

    def get_active_operation_log(self) -> list[dict]:
        """
        Return the operation log for the *currently active* document-like
        (full image or ROI-preview). Empty list if none.
        """
        doc = self.get_active_document()
        if doc is None:
            return []
        get_log = getattr(doc, "get_operation_log", None)
        if callable(get_log):
            try:
                return get_log()
            except Exception:
                return []
        return []



    # Back-compat/aliases so tools can call any of these:
    def update_image(self, updated_image, metadata=None, step_name: str = "Edit"):
        self.update_active_document(updated_image, metadata, step_name)

    def set_image(self, img, metadata=None, step_name: str = "Edit"):
        self.update_active_document(img, metadata, step_name)

    def apply_edit_to_active(self, img, step_name: str = "Edit", metadata=None):
        self.update_active_document(img, metadata, step_name)